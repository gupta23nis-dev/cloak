# Credit Control — every address

Version **3.0.0**. Replace `cc-co.in` with your own domain if the site moves.

---

## 1. Admin — main panel

```
https://cc-co.in/info-security-desk
```

This is your door. Every screen has its own readable address, so you can
bookmark one directly instead of hunting for it in the menu.

| Screen | Address |
|---|---|
| Overview | `https://cc-co.in/info-security-desk` |
| Links | `https://cc-co.in/info-security-desk/links` |
| New link | `https://cc-co.in/info-security-desk/new` |
| One link's activity | `https://cc-co.in/info-security-desk/link/19` |
| Edit a link | `https://cc-co.in/info-security-desk/edit/19` |
| Visits | `https://cc-co.in/info-security-desk/visits` |
| Map | `https://cc-co.in/info-security-desk/map` |
| Smart monitoring | `https://cc-co.in/info-security-desk/support` |
| **Case agents** | `https://cc-co.in/info-security-desk/agents` |
| **Desk activity** | `https://cc-co.in/info-security-desk/activity` |
| Blocklist | `https://cc-co.in/info-security-desk/blocks` |
| Settings | `https://cc-co.in/info-security-desk/settings` |
| Network access | `https://cc-co.in/info-security-desk/access` |
| Tools | `https://cc-co.in/info-security-desk/tools` |

The `19` in a link address is that link's own number — open **Links** and each
row shows its address.

Old bookmarks still work:

- `https://cc-co.in/cloaklink-panel`
- `https://cc-co.in/control-room`

---

## 2. Admin — restricted console

Only opens to networks you have listed in **Network access**. Same screens as
the panel above; it exists so visitor data can be reachable from your own
network and nowhere else.

```
https://cc-co.in/secure-ops-desk
```

| Screen | Address |
|---|---|
| Overview | `https://cc-co.in/secure-ops-desk` |
| Visits | `https://cc-co.in/secure-ops-desk/visits` |
| Map | `https://cc-co.in/secure-ops-desk/map` |
| Smart monitoring | `https://cc-co.in/secure-ops-desk/support` |
| One link's activity | `https://cc-co.in/secure-ops-desk/link/19` |

If you have not listed your own network there, this address refuses you — that
is what it is for. Open it from **Network access** in the main panel instead.

---

## 3. Case desk — for the people you create

This is the **only** address the agents and admins you create ever use. Give
them this one and nothing else.

```
https://cc-co.in/case-desk
```

| Screen | Address |
|---|---|
| Sign in | `https://cc-co.in/case-desk` |
| Their panel | `https://cc-co.in/case-desk/panel` |
| One ticket | `https://cc-co.in/case-desk/panel/?cl_ticket=7` |
| Sign out | `https://cc-co.in/case-desk/out` |

A person signs in with the **username**, **password** and (if you gave one)
**6-digit access code** you set for them on **Case agents**.

### What each role sees there

| | Agent | Admin |
|---|---|---|
| Tickets listed | only their own | the whole queue |
| Allow / Hold a ticket | no | yes |
| The link, with Copy and WhatsApp | **never** | yes |
| Records, media, map | own tickets, once allowed | any ticket, once allowed |
| Recent monitoring, every released ticket | own | the whole queue |
| Clear a record from monitoring | own tickets only | any released ticket |
| Can reach your console | no | no |
| Can change a setting | no | no |

The desk locks itself after the same idle stretch as your console. The code
the person was given opens it; an account with no code uses its password.
Five wrong answers from one address wait a quarter of an hour.

---

## 4. What you create and send

A ticket makes no address until you allow it. Allowing asks three optional
things in one row under the ticket — where the link goes after the capture,
which domain it prints, and what it ends with — and the name on the file is
the name the agent typed. Leave all three empty and the link still works: it
points at your front page.

Links made this way are marked in **Links** with the agent's name, so one you
do not remember creating is explained rather than mysterious. They count in
the totals like any other link and can be paused or deleted there; deleting
one also deletes its ticket on the desk.

Stamp links are what you send to the person named on a ticket. They look like:

```
https://cc-co.in/go/HighCourt-Karnataka.Notice.E23-TP-VLW917
```

A ticket's own link is on **Case agents → Tickets → open**, and on the ticket's
page that an admin-role person sees on the case desk.

---

## 5. If an address gives a 404

Open **Tools** and press **Rebuild permalinks**. A plugin copied in by FTP or a
restored database can leave the address table stale, and this rebuilds it — no
data is touched. Saving Settings does the same thing.

If `/case-desk` is taken by a page on your site, open **Settings → Case desk
address** and choose another word. The new one works as soon as you save, and
it is refused if it would be the same word as your panel or the restricted
console.

---

## 6. Settings, by tab

**Settings** used to be one long column. It still is one page and one address —
nothing moved — but it is now cut into ten tabs down the side, plus an
**Everything** button that shows all of them at once. Every tab is part of the
same form, so one press of **Save settings** saves all of them, whether you
visited them or not. Each tab shows how many fields it holds.

| Tab | Panels it holds | What is on them |
|---|---|---|
| Branding | Branding | Platform name, tagline, logo, share card and message, and the two addresses mail is sent from |
| Visitor gating | Visitor gating | The location, camera and microphone rules a link follows |
| Links & addresses | Link behaviour | The domain links print on, extra domains, the link page, and network lock |
| Alerts & sound | Alert sound, Mail delivery test | The alert sound and its volume; a button that sends one test message |
| Mail (SMTP) | Send mail through your own mailbox | Your own mailbox: host, port, security, username, password and From address |
| Case desk rules | The desk's rules | Opening hours, quotas, pause, failed sign-ins and the desk notices |
| Security & access | Access code | The console's access code and idle lock |
| Data & retention | Data, privacy & alerts | Retention, IP masking, the audit trail, file size, and the three alert addresses |
| Walkie-talkie | Walkie-talkie | The three walkie-talkie switches |
| Support desk | Support desk, Support capture | Desk status and notices; whether a visitor may leave a name and a message |

There is also a **find** box above the tabs: type part of a setting's name and
every field it matches is shown with its tab, so you do not have to remember
which tab a switch lives on.

Two settings that had no field anywhere before now have one: the visitor
gating switches on **Visitor gating**, and the walkie-talkie switches on the
same screen's **Alerts & sound** area. Before 3.0.0 they were read on every
request but could not be seen or changed, and any value they held was wiped by
pressing Save on an unrelated screen.

The **Alert sound** panel and the **Mail delivery test** have their own buttons,
because they act immediately rather than waiting for a save; those buttons are
unchanged. The six SMTP fields save with everything else when you press
**Save settings** on any tab.

The tabs change only what you see: a save from any tab posts every field on the
screen. Opening a tab and saving cannot blank a setting on another tab, and
that is enforced by the plugin rather than by the tabs being tidy — see
`UPGRADE-3.0.md` and `tests/settings-roundtrip.php`.

---

## 7. Download addresses

Every download is a signed link, so it only works when you press it on the
screen that offers it — a link copied into an email will be refused. There is
nothing to type.

| What you get | Where the button is |
|---|---|
| The activity log, CSV / Excel / Word / PDF | **Desk activity**, the download row |
| One link's visits, CSV / Excel / Word / PDF | **Links → one link's activity** |
| Selected records, CSV / Excel / Word / PDF | **All records**, after ticking rows |
| One visitor record, CSV / Excel / Word / PDF | The record's own card |

A download follows whatever search, date range and column choice the screen is
showing, so the file matches what you were looking at when you pressed it.

---

## 8. Deleting a record, everywhere

Deleting a record — one row, or several rows at once — now removes it in all
three places it could be:

1. the row on **All records**,
2. the visit and its session on **Smart monitoring**,
3. the photographs, audio and video on disk.

The confirmation says how many rows you have ticked. Above ten rows it asks
you to type `DELETE` before it goes, so a stray press on a full page cannot
clear a day's records. The **Advanced** screen can switch the whole
confirmation off for a one-person console.

Deleting a link from **Links** still deletes its ticket on the case desk, as it
always has; it now also clears the captures behind that link.

---

## 9. Nothing removed

Every address in sections 1 to 5 above still answers exactly as before. 3.0.0
adds no new address, changes no existing one, and removes none:

- the panel at `/info-security-desk`,
- the restricted console at `/secure-ops-desk`,
- the case desk at `/case-desk` (or whatever word you chose for it),
- every `/<screen>` under each of them,
- the step addresses `/<base>/<slug>`, `/<base>/<slug>/l/<step>`,
- the old bookmarks `/cloaklink-panel` and `/control-room`.

A bookmark saved before this upgrade opens the same screen it always did.
