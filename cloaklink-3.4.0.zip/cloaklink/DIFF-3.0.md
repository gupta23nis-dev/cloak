# 3.0.0 — diff inventory

Baseline: the 2.9.111 zip that shipped before this release.
Result: the 3.0.0 zip.

Two headings matter most:

- **Removed files: none.**
- **Removed lines: 152**, and every one is accounted for below. 79 of the 152
  are the SMTP block in `settings.php` re-indented as it moved into the Mail
  tab; the other 73 were each replaced. No setting key was lost — the screen
  renders 15 more keys than before and none fewer.

---

## 1. Files

| | Count |
|---|---|
| Files in 2.9.111 | 89 |
| Files in 3.0.0 | 92 |
| Removed | **0** |
| Added | 3 |

### Added

| File | What it is |
|---|---|
| `UPGRADE-3.0.md` | What to do to install, what changed, and how to roll back |
| `tests/settings-roundtrip.php` | A standing test that proves no screen wipes a setting it does not own |
| `DIFF-3.0.md` | This inventory |

`ADMIN-URLS.md` is counted in the Modified table below because it existed
before; `readme.txt` gains its `= 3.0.0 =` entry in the same way.

### Modified

| File | Added | Removed | Net |
|---|---|---|---|
| `assets/css/admin-cyber.css` | 134 | 0 | +134 |
| `assets/css/agent.css` | 31 | 0 | +31 |
| `assets/js/admin.js` | 248 | 8 | +240 |
| `assets/js/agent.js` | 5 | 1 | +4 |
| `cloaklink.php` | 2 | 2 | 0 |
| `includes/class-cloaklink-admin.php` | 41 | 18 | +23 |
| `includes/class-cloaklink-agents.php` | 10 | 0 | +10 |
| `includes/class-cloaklink-settings.php` | 234 | 22 | +212 |
| `includes/class-cloaklink-support.php` | 63 | 0 | +63 |
| `readme.txt` | 10 | 0 | +10 |
| `views/admin/access.php` | 10 | 0 | +10 |
| `views/admin/agents.php` | 13 | 0 | +13 |
| `views/admin/links.php` | 1 | 1 | 0 |
| `views/admin/records.php` | 31 | 20 | +11 |
| `views/admin/settings.php` | 333 | 79 | +254 |
| `views/agent/panel.php` | 10 | 0 | +10 |
| `ADMIN-URLS.md` | 97 | 1 | +96 |

Totals: **+1,273 lines added, 152 removed, 17 files changed, 3 added, 0 deleted.**

These are the figures a diff of the two zips reports, counted line by line.

---

## 2. Every removed line, and what replaced it

### `cloaklink.php` (2)

| Removed | Replaced by |
|---|---|
| ` * Version:           2.9.111` | ` * Version:           3.0.0` |
| `define( 'CLOAKLINK_VERSION', '2.9.111' );` | `define( 'CLOAKLINK_VERSION', '3.0.0' );` |

### `includes/class-cloaklink-settings.php` (22)

All of these are the same defect: a key absent from the posted form was
written as a hard-coded fallback, which is how saving one screen erased
another screen's settings. Each removed line is replaced by a call that
preserves the stored value.

| Removed | Replaced by |
|---|---|
| `$d  = self::defaults();` | reads the stored option row and merges over defaults |
| `$out['brand_email'] … : '';` | `$sent()`-guarded, falls back to the stored value |
| `$out['notify_email'] … : '';` | as above |
| `$out['link_domain'] … : '';` | as above |
| `$out['extra_domains'] = array_values( array_unique( $domains ) );` | preserved unless the domain field was on this form |
| `$out['smtp_host'] … : '';` | `$sent()`-guarded (6 SMTP fields) |
| `$out['smtp_port'] … : 587;` | as above |
| `$out['smtp_user'] … : '';` | as above |
| `$out['smtp_from_email'] … : '';` | as above |
| `$out['smtp_secure'] … : 'tls';` | as above |
| `$out['link_page_id'] … : 0;` | preserved; `ensure_link_page()` still replaces a dead id |
| `$out[ $key ] = ! empty( $in[ $key ] ) ? 1 : 0;` (flag loop) | `$out[ $key ] = $flag( $key );` |
| `$out['desk_ip_lock'] …` | `$flag( 'desk_ip_lock' )` |
| `$out['desk_hours_on'] …` | `$flag( 'desk_hours_on' )` |
| `$out['desk_quota_on'] …` | `$flag( 'desk_quota_on' )` |
| `$out['desk_fail_on'] …` | `$flag( 'desk_fail_on' )` |
| `$out['desk_pause'] …` | `$flag( 'desk_pause' )` |
| `$out['desk_notify_login'] …` | `$flag( 'desk_notify_login' )` |
| `$out['desk_hours_days'] = $days ? … : '1,2,3,4,5,6,7';` | preserved when the day boxes were not on the form |
| `$val = isset( $in[ $key ] ) ? absint( $in[ $key ] ) : (int) $bounds[2];` | `$owned()`-guarded |
| `$out['single_device'] …` | `$flag( 'single_device' )` |
| `$out['country_list'] = …;` | preserved unless the country field was on this form |

Also new in this file: `form_keys()` (which form owns which keys),
`reachable_keys()`, and the `$owned` / `$sent` / `$flag` closures.

### `includes/class-cloaklink-admin.php` (18)

| Removed | Replaced by |
|---|---|
| `$none = array( null, array(), array( 'photo' => false, … ), 0 );` | the same array with the 5th element the caller reads, fixing "Undefined array key 4" |
| the inline session-delete loop in `bulk_delete` (12 lines) | one call: `cloaklink()->support->delete_visitor( … )` |
| `} elseif ( $id && 'delete' === $what && $this->db->delete_visit( $id ) ) {` | calls `delete_visitor()` first, then deletes the visit |
| `$note = 'deleted';` | `$note = 'deleted';` plus a `cl_gone` count for the flash message |

The single-row and bulk paths now behave identically, and both unlink the
captured files.

### `views/admin/records.php` (19)

The whole block between `</form>` and `<div class="cl-records__grid">` moved.
The removed lines are the old ordering, where `</form>` came *after* the grid,
which is what produced 109 nested forms and a **Delete selected** button that
did nothing. The replacement is the same markup with `</form>` above the grid
and each checkbox tied to the form by `form="cl-records-form"`. Nothing was
dropped from the page: same cards, same empty message, same capture card call.

### `views/admin/settings.php` (79)

| Removed | Replaced by |
|---|---|
| 7 `<section class="cl-panel ...">` opening tags | the same panels with `id` and `data-set-section`, so the tab bar can find them |
| the "Location & visitor privacy" panel (6 lines) | the **Visitor gating** panel |
| the six SMTP inputs and their help text (64 lines) | the same 64 lines, re-indented, inside the **Mail (SMTP)** tab |

The SMTP block was never lost: it is byte-identical apart from leading tabs,
moved out of the Data panel into the Mail panel where its own tab heading
already described it. A whitespace-normalised comparison of the two files
reports no line missing except the six of the privacy panel, and the same 73
setting keys render as before plus 15 that had no control at all.

The privacy panel is the only content actually removed. It said that precise
location "is **not requested, transmitted, or stored** by the public link
flow". That is false: `class-cloaklink-router.php` passes `gps_timeout`,
`gps_high_accuracy`, `allow_manual_location` and `block_on_deny` into the
resolver on every link open, and the visit row records the answer. A panel that
tells the operator the opposite of what the plugin does is worse than no panel,
so it is replaced by the switches it was describing.

### `views/admin/links.php` (1)

| Removed | Replaced by |
|---|---|
| `class="cl-check"` on the row checkbox | `class="cl-row-select"` |

`cl-check` was also used by the Smart monitoring screen's own checkboxes, so
the two bulk selectors could grab each other's rows. Renaming one separates
them. The input itself is unchanged: same name, same value, same column.

### `assets/js/admin.js` (8)

| Removed | Replaced by |
|---|---|
| a 5-line comment above the confirm handler | a shorter comment; the handler is now global rather than per-form |
| `document.querySelectorAll('.cl-check')` (bulk selector) | scoped to its own form, `.cl-row-select` |
| `b.checked = checkAll.checked;` | three-state logic: all, none, or indeterminate |
| `querySelectorAll('.cl-sup-check')` | `[form="ID"].cl-sup-check`, because those rows join the form by attribute, not by nesting |

### `assets/js/agent.js` (1)

| Removed | Replaced by |
|---|---|
| `var wall = document.getElementById('cl-agent-wall');` | `form.querySelector('.cl-walkins') \|\| document.getElementById('cl-agent-wall');` |

The panel's markup moved the walk-ins list inside a form, so the old
document-wide lookup found nothing on the desk.

---

## 3. What did not change

- Every URL. No rewrite rule was added, edited or removed.
- Every database table and column. The migration is additive and idempotent;
  running it on a live dataset changed 0 rows and 0 settings.
- Every option key. 3.0.0 changes how keys are *written*, never their names or
  shapes; a row written by 2.9.111 reads back identically.
- The visitor-facing pages. Not one byte of the public link flow changed.
- `uninstall.php`, `includes/class-cloaklink-*.php` other than the five listed,
  and every view other than the five listed.
