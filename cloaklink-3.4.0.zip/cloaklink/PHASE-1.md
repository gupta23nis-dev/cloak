# Phase 1 — evidence

Baseline for every comparison below: `cloaklink-3.0.0-SHIPPED.zip`.
Working tree: `cloaklink/`. Bench: `http://localhost:8899`, database intact.

## The three absolute rules, checked mechanically

| Rule | Check | Result |
|---|---|---|
| Rule 1 — nothing removed | every file in the shipped zip still present | **92 of 92, zero removed** |
| | PHP functions removed from changed files | **0** |
| | JS functions removed from changed files | **0** |
| | CSS selectors removed from changed files | **0** |
| Rule 2 — no data loss | migrations | none added; no schema change |
| | bench rows before / after all testing | visits 81 → 81, links 32 → 32 |
| Rule 3 — existing behaviour | all 13 panel screens | 200, zero PHP notices |
| | php `-l` across every file | **0 failures** |
| | JS/CSS assets per screen | **0 failing** (91 assets) |
| | JS errors and failed requests, browser, 13 screens | **0 and 0** |

Diff: **+2,432 / −58** across 21 changed files, 1 added (`views/admin/edit.php`),
0 removed. Every one of the 58 deleted lines was read individually and is a
replacement, not a removal — old redirect without a count replaced by one with
a count, old notice sentence replaced by a counted one, old array keys replaced
by defaulted ones.

## 1.1 — Media capture end to end

Voice notes reported `0:00` because MediaRecorder writes WebM/Ogg with **no
Duration element**, so `audio.duration` is `Infinity` for ever. Fixed with
`learnDuration()`, which seeks past the end and lets the browser clamp to the
real length.

- proved on the real 728 KB file: `null → 60.117 s`
- applied in `admin.js` and `agent.js`, on both the tile and the sheet player
- media endpoint itself verified sound: HTTP 200, `image/jpeg`, correct magic bytes
- 15 of the original capture files are gone from disk — a **data** problem, not
  code; `Media health` on Tools now measures it and the repair writes references
  only, never deletes

## 1.2 — Nothing falls back to the home page

| action | result |
|---|---|
| delete 2 links | `/links?cl_notice=deleted&cl_count=2&cl_asked=2` — "2 links and their visit history were deleted." |
| delete 3, 2 already gone | `/links?…cl_count=2&cl_asked=3` — "…1 of the 3 selected had already gone" |
| delete 2, both gone | `/links?cl_notice=nothing_gone` — red, explains another tab, shows current list |
| duplicate | `/edit/62?cl_notice=duplicated` — the copy opened, not the list |
| rejected save | `/edit/24?cl_notice=invalid` — 66-character URL, not a JSON blob |

Bugs found and fixed while testing this section:

1. **Every Edit button opened a blank page.** The route table has always listed
   `edit`, the Links table and every single-link screen have always linked to
   it, and there was no `views/admin/edit.php`, so `render_view()` returned
   early. Created from `new.php`, which was already written for both
   (`current_id()`); Edit → Save → link screen verified end to end.
2. **Duplicate silently did nothing.** `create()` read four keys straight off
   the form handler's array; called from duplicate they were absent, PHP 8
   raised four warnings, and the warnings were printed *before* the redirect, so
   the redirect was dropped. The copy was made and the operator never saw it.
   Defaulted in `create()`.
3. **Raw JSON in the address bar.** A failed save put `cl_error` — rawurlencoded
   JSON, up to 2 KB — into the URL. Moved to a one-shot per-user transient;
   errors are read once and discarded, so a reload does not resurrect a message
   about a form since fixed.

## 1.3 — Clicks are clicks

`capture_person_html()` and the `$people` accumulator both counted every row as
a click. Split into opens (`open`, `redirect`, empty) and recorded actions.
`link_stats()` now returns `clicks`, `events`, `sessions` so the three units
cannot be confused again.

## 1.4 — Bulk selection

- master box paints all three states; with some rows ticked, pressing it takes
  the rest rather than dropping the selection
- the bar now says `3 of 32 on this page`, names the active filters, and warns
  that deleting a link takes its visits and captured files
- a filter that hides a ticked row clears the selection and **says so**:
  "2 rows you had selected are no longer on this page, so the selection was
  cleared. Tick the rows again." — proved by removing rows and reading the DOM
- bulk delete counts come from the DELETE's own rowcount, not from how many ids
  were posted
- support keeps "remove captured media only" separate from "delete session";
  both now report exact counts
- proved with three disposable rows: asked 3, deleted 3, total returned to 81

## 1.5 — Walkie-talkie

Already present and checked: hold/latch/hands-free, ICE perfect-negotiation,
the reconnect watchdog, microphone release on blur, and a gated real-analyser
level meter for the speaking indicator.

**New: the line, measured.** A diagnostics drawer under the key, reading only
real values, which never prints a zero where nothing has been measured:

| row | source |
|---|---|
| Signalling | stamps written by the poll itself — answered/failed/tries, and why |
| ICE state | the connection's own `iceConnectionState` / `connectionState` |
| Candidates | counted from the `getStats()` report |
| Route | the succeeded `candidate-pair` and its local/remote types |
| Codec | the negotiated audio codec and clock rate |
| Received | `bytesReceived` and `packetsReceived` |
| Round trip | `remote-inbound-rtp.roundTripTime`, else the pair's |
| Packet loss | packets lost over packets lost + received, as a percentage |
| Jitter | `inbound-rtp.jitter`, in ms |
| Microphone | track state, enabled/muted, sample rate, channels, label |

Unmeasured rows print `—` and are styled as unmeasured. "Copy for a support
note" produces a plain-text block with a timestamp. Verified live on an open
line: `signalling: Last answer 0s ago, 346 of 347 requests answered`,
`candidates: 5 local, 0 remote`, `route: No candidate pair has succeeded yet` —
exactly right for a line nobody has answered.

## 1.6 — Security

- **Shipped-code banner** on every console screen until the account has its own
  code — done earlier, verified still present.
- **Changing the access code now requires the current code.** New
  `CloakLink_Login::verify_user_code()`. Proved four ways: wrong current code →
  refused, old code still works, new one not set; correct current code → new
  one works, old one refused. The error is reported and audited.
- **Server-side exclusion.** Every console route without a session returns the
  sign-in page: 15,572 bytes, zero visitor strings, zero rows.
- **Hardening headers** on every console page, read back from the live response:
  `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`,
  `Referrer-Policy: no-referrer`, `Content-Security-Policy: frame-ancestors
  'self'; base-uri 'self'; object-src 'none'`, `Permissions-Policy:
  camera=(self), microphone=(self), …`, and `Strict-Transport-Security` on TLS
  only.
- **Tools → Browser hardening** reads `headers_list()` for *this* request, so a
  header a host strips is reported as not sent instead of claimed.

## 1.7 — Sound library

16 events, each with its own file, on/off, volume, repeat count and quiet
period. Saved through one form that writes only its own key.

- formats validated by **real type** (`finfo`), not extension: a text file named
  `.mp3` resolves `text/plain` and is refused; a real WAV resolves `audio/x-wav`
  and is accepted
- a file id that is not an `audio/*` attachment is refused at save, not
  discovered at alert time
- every event plays from the saved row; the capture alert now goes through the
  library, so the file and volume chosen for it are the ones that sound
- "Play" per row is a real gesture and opens the audio context, so a file that
  will not play says so while the operator is looking at it
- "Test all alerts" walks all 16 in order, re-enables itself, and reports
- a refused file falls back to the built-in figure and warns once — a broken
  upload is a different sound, never silence
- **per-account override**: proved 35 → 95 for one operator while the shared row
  and every other event stayed untouched

Verified in the browser: cooldown refuses a second fire, `force` overrides it, a
switched-off event stays silent, an unknown event returns false, zero errors.

Two bugs found and fixed here: the save button was named `cl_sound`, colliding
with the `cl_sound[...]` field array, so pressing "Save the library" reported
"no file was chosen" and saved nothing; and an unknown event returned `true`.

## 1.8 — Monitoring honesty

Overview's labels were already honest (`Visits today` / `Total visits` /
`Count active links` with "N total created", country count falling back to
"places" and saying which source). Added to the monitoring wall:

- a provenance line naming the tables read and the refresh interval, taken from
  the setting that actually drives the poll (`adv.poll_seconds`), not typed in
- the age of the newest capture in the current view
- an empty view says so plainly — "…is genuinely empty, not still loading" —
  rather than showing a zero that could be a failure

## What was not done, and why

- **Live cc-co.in was not touched.** It cannot be tested from here and you did
  not ask for a deploy.
- **Mail to alert@ / red-alert@ / security-alert@cc.co.in is still unverified.**
  Those three mailboxes have never been confirmed to exist.
- **15 capture files are missing from disk** on the bench. That is data, not
  code; Media health measures it and the repair re-attaches references without
  ever deleting a file.
- **Visitor-facing pages were not opened, read or changed.**

## Follow-up round — the four things reported after Phase 1

### The media strip on the card

It existed and drew nothing on the cards you screenshotted, for two
separate reasons, both fixed:

1. **The strip was at the top of the card, not under the permission
   tiles.** Moved to sit directly beneath Location/Camera/Mic/Video, which
   is where the brief puts it and where you pointed.
2. **The strip was only drawn when a file's bytes were on disk.** A card
   with Camera lit and no session therefore rendered no strip at all — the
   section simply vanished, so the feature looked absent. Now every card
   that was allowed a camera, microphone or recording draws the strip. A
   kind with no file gets a compact dashed bar saying so in the same grid
   ("No photograph was stored" / "No voice note was stored"), and a card
   with no session at all says "Allowed, but nothing reached the server."

   A kind whose files the database still names is excluded from that, because
   the existing dated "no longer on disk, since removed by retention" notice
   is a more precise statement and must not be replaced by a vaguer one.

Measured on the wall: 37 cards, 32 strips, **30 cards with a media
permission and 0 without a strip**, 30 empty-slot bars, 5 real thumbnails,
**0 broken images**.

### Walkie-talkie

Root cause found and proved. The signalling table showed the operator had
sent many offers and **zero answers were ever recorded** from the desk, then
later that both ends were offering to each other in a ring:

- each offer made the other side roll back;
- a rollback raises `negotiationneeded`, which sent another offer;
- ICE reached `connected` and **DTLS sat at `connecting` for ever**, so the
  line looked up and carried no sound.

Two changes to `radio.js`:

1. **The polite side no longer offers.** One side offers, the other answers.
   Both offering is what produced the ring.
2. **`needsOffer()`** — an offer is only made when a transceiver genuinely
   has no mid yet, never for a stopped orphan, and never more than once per
   four seconds.

**Proved end to end** in a live browser with the operator panel and the agent
desk open side by side: both connections `connected`, DTLS `connected`,
signalling `stable`. A 440 Hz tone injected into the outbound track arrived
on the far side as real audio — `inbound-rtp audioLevel 0.50`,
`totalAudioEnergy 1.0`.

Also exposed a read-only `window.__clRadioDebug` so a support note can carry
the real stats (bytes, packets, track state) instead of a screenshot of a
green dot.

Not verified: a real microphone. This machine's browser refuses
`getUserMedia` (`NotAllowedError`), so the microphone→track path was proved
with a synthetic tone in its place; the transport is what was broken and the
transport is what is now measured.

### Notification latency

- The door watcher ran on a plain `setInterval` **and skipped while the tab
  was hidden**. A page timer in a background tab is throttled to about once
  a minute, so a shift change at ten past was announced whenever the tab next
  woke. It now runs on the panel's existing Web Worker clock at **2 s**, and
  polls regardless of visibility.
- The arrival feed (captures *and* tickets) now runs at **1 s** regardless of
  the operator's `pollSeconds`, which remains the battery setting for the
  wall's own repaint. A ticket is somebody standing at the desk waiting.
- Two real JS errors were found and fixed while doing this: `steady` and
  `learnDuration` were used from closures that could not see them, which had
  stopped the door watcher before its first poll. Both are now published and
  the door watcher falls back to a plain interval if publishing fails.

### The ticket popup, restyled

Rebuilt rather than nudged. The old card was four rectangles — three
bordered fact cells inside a bordered box with a text link beneath — which
read as a piece of the settings page that had fallen off.

The new card: initials in a violet ring (the same mark the queue uses), a
live pulse beside "Ticket raised", the time on the right, the person's name
at 15px, the three facts on one line separated by hairlines, the phone as a
`tel:` link, then one filled action button and one explicit dismiss. One card
per ticket id, so a one-second feed cannot stack five copies of the same
request. A ticket never expires on a timer — dismissing it leaves it in the
queue.

Fixed while doing this: the card said "Website" for a ticket whose kind was
empty. It now says "—" when no kind was recorded, rather than inventing one.

### Still not done

- **Nothing was deployed to cc-co.in.** No credentials or access exist here.
- **The 13 missing capture files** are a data problem, not code. Media health
  measures them and the repair re-attaches references only.
- **Mail to alert@ / red-alert@ / security-alert@cc.co.in remains unverified.**
