# Upgrading to 3.0.0

3.0.0 adds. It does not remove, and it does not rewrite. Every screen, route,
setting key, database table, shortcode, filter and public URL from 2.9.111 is
still there and still behaves the same way. Nothing has to be reconfigured.

## What to do

1. Back up the database. Not because this version drops anything — the
   migration is additive — but because it is the largest change since the
   desk was built, and a backup costs a minute.
2. Deactivate the old plugin in **Plugins**, delete it from the server, and
   upload the 3.0.0 folder in its place. Or use **Plugins → Add New → Upload
   Plugin**, which replaces it in one step on most hosts.
3. Activate. The schema upgrade runs on first load, exactly as it does on
   every earlier upgrade.
4. Open the panel and press **Save settings** once. This is not required, but
   it is the one action that writes the stored row through the new code, and
   watching it come back saying "saved" with the rest of the screen unchanged
   is the quickest proof on a live site that the old behaviour is gone.
5. If you have a copy you can lose, run the regression test and read the last
   line. It should say "All checks passed" and it will have restored your
   option row:

   ```
   CL_WP_LOAD=/path/to/wp-load.php php tests/settings-roundtrip.php
   ```

## What changed underneath, that you will notice

**Settings stop resetting.** This is the reason for the version number. Until
now, saving one screen silently reset the settings that belong to another.
Pressing Save on **Network access** reset eighty-one settings. If you have ever
set a country list, a VPN policy, a brand name or an SMTP password, saved
something else, and later found it back at its shipped value, that was this
bug. It is fixed, and there is now a test that proves it.

**You will find new controls on Settings.** Twelve settings that were stored
but never shown now have a field: the visitor-gating switches, the walkie-talkie
switches and tone, and the support-capture switch. If any of those were set on
this site through a direct database edit, the value you set is still there and
the control will open showing it.

**You will not find five controls.** `require_otp`, `count_unique_only`,
`link_max_clicks`, `show_map` and `lockdown` are stored and preserved, but
nothing on the request path reads them, so a switch for them would change
nothing. The Settings screen says so in one line. If you need one of them to
work, that is a feature request rather than a missing screen — say which and
it can be built properly against the code that would have to honour it.

**Delete asks first.** Four destructive buttons were marked as needing a
confirmation and had none. All seven now ask, count what they are about to
remove, demand the word DELETE above ten rows, and tell you how many went.

## If something looks wrong

The two things most likely to surprise you are both intended:

- **A setting you never touched is still where you left it.** That is the fix.
  If you were relying on the old behaviour to reset a key, that was never a
  feature — set it explicitly.
- **Settings now opens on "Everything".** The section bar above the fields is
  a reading aid. Every field is on the page and every field is saved whichever
  section you are looking at; the finder only hides things from view, never
  from the save.

If a page renders wrongly after the upgrade, clear any page cache and any CDN
cache: the stylesheet and the scripts both gained rules and blocks.

## Rolling back

Copy 2.9.111 back over the folder. The schema change is additive, so an older
version reads the database without complaint, and no option key was removed or
renamed. The only thing you lose by rolling back is the fix itself — the
settings reset comes back with it.
