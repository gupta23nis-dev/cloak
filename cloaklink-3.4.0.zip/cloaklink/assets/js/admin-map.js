/**
 * The location map.
 *
 * OpenStreetMap's own embed page takes one marker, so a month of visitors
 * collapsed onto a single pin and the panel looked as if it had heard from
 * one person. Tiles are drawn here instead and every fix gets its own pin,
 * so the map answers the question it is on the page to answer: where the
 * people who opened the link were.
 *
 * No key and no third-party script: plain img tiles from the standard
 * OpenStreetMap tile service, positioned by hand. The projection is the
 * Web Mercator one those tiles are cut for.
 */
(function () {
	'use strict';

	var host = document.getElementById('cl-map');
	if (!host || !host.getAttribute('data-fixes')) {
		return;
	}

	var fixes = [];
	try {
		fixes = JSON.parse(host.getAttribute('data-fixes'));
	} catch (e) {
		fixes = [];
	}
	if (!fixes.length) {
		return;
	}

	var TILE = 256;
	var MIN_Z = 2;
	var MAX_Z = 18;

	// Every fix that belongs to a repeat visitor, grouped by trail, in the
	// order the clicks happened. A trail of fewer than two points is not a
	// path — it is one reading — so it is left as a pin alone.
	var trails = {};
	for (var ti = 0; ti < fixes.length; ti++) {
		var f = fixes[ti];
		if (f.trail === undefined || f.trail === null) {
			continue;
		}
		if (!trails[f.trail]) {
			trails[f.trail] = [];
		}
		trails[f.trail].push(f);
	}
	Object.keys(trails).forEach(function (key) {
		if (trails[key].length < 2) {
			delete trails[key];
			return;
		}
		trails[key].sort(function (a, b) {
			return (a.step || 0) - (b.step || 0);
		});
	});

	// Web Mercator. Longitude maps linearly to x; latitude does not, which is
	// why the whole map is not simply a stretched photograph.
	function project(lat, lng, z) {
		var n = Math.pow(2, z);
		var x = (lng + 180) / 360 * n;
		var rad = lat * Math.PI / 180;
		var y = (1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * n;
		return { x: x, y: y };
	}

	var view = { z: 5, x: 0, y: 0 };
	var canvas = document.createElement('div');
	canvas.className = 'cl-mapview__canvas';
	host.appendChild(canvas);

	var layer = document.createElement('div');
	layer.className = 'cl-mapview__tiles';
	canvas.appendChild(layer);

	// The paths are drawn under the pins, so a pin is always clickable.
	// An <svg> made with createElement is an unknown HTML element in every
	// browser, and children added to it are never drawn. The namespace is
	// what makes it an actual drawing surface.
	var NS = 'http://www.w3.org/2000/svg';
	var paths = document.createElementNS(NS, 'svg');
	paths.setAttribute('class', 'cl-mapview__paths');
	paths.setAttribute('preserveAspectRatio', 'none');
	paths.setAttribute('aria-hidden', 'true');
	canvas.appendChild(paths);

	var pins = document.createElement('div');
	pins.className = 'cl-mapview__pins';
	canvas.appendChild(pins);

	function size() {
		return { w: host.clientWidth || 800, h: host.clientHeight || 420 };
	}

	/** The zoom at which the whole set still fits. */
	function fit() {
		var s = size();
		var best = MIN_Z;
		for (var z = MIN_Z; z <= MAX_Z; z++) {
			var xs = [];
			var ys = [];
			for (var i = 0; i < fixes.length; i++) {
				var p = project(fixes[i].lat, fixes[i].lng, z);
				xs.push(p.x);
				ys.push(p.y);
			}
			var w = (Math.max.apply(null, xs) - Math.min.apply(null, xs)) * TILE;
			var h = (Math.max.apply(null, ys) - Math.min.apply(null, ys)) * TILE;
			if (w > s.w - 80 || h > s.h - 80) {
				break;
			}
			best = z;
		}
		view.z = best;

		var minx = Infinity, maxx = -Infinity, miny = Infinity, maxy = -Infinity;
		for (var j = 0; j < fixes.length; j++) {
			var q = project(fixes[j].lat, fixes[j].lng, view.z);
			minx = Math.min(minx, q.x);
			maxx = Math.max(maxx, q.x);
			miny = Math.min(miny, q.y);
			maxy = Math.max(maxy, q.y);
		}
		view.x = (minx + maxx) / 2 - s.w / (2 * TILE);
		view.y = (miny + maxy) / 2 - s.h / (2 * TILE);
	}

	/**
	 * Tile sources, in the order they are tried.
	 *
	 * Google first, because that is the map the operator already reads and the
	 * one a pin opens. If a network blocks it, the OpenStreetMap community
	 * server is tried, then a general-purpose dark basemap that asks nothing
	 * of the caller. A tile is only dropped once all three refuse, so the
	 * screen draws a map on any network that permits at least one of them.
	 */
	var tiles = [
		{
			// Google's own raster tiles, which is what the panel is used to
			// looking at and what a visitor's own address opens in. The
			// subdomain is spread across the four hosts so one is not asked
			// for every tile in the pack, which is how the endpoint is meant
			// to be called.
			url: function (z, x, y) {
				var host = 'mt' + (Math.abs(x + y) % 4) + '.google.com';
				return 'https://' + host + '/vt/lyrs=m&hl=en&x=' + x + '&y=' + y + '&z=' + z;
			}
		},
		{
			url: function (z, x, y) {
				return 'https://tile.openstreetmap.org/' + z + '/' + x + '/' + y + '.png';
			}
		},
		{
			url: function (z, x, y) {
				// Subdomains are spread so one host is not asked for every tile.
				var sub = 'abc'[Math.abs(x + y) % 3];
				return 'https://' + sub + '.basemaps.cartocdn.com/dark_all/' + z + '/' + x + '/' + y + '.png';
			}
		}
	];

	var drawn = '';

	function drawTiles() {
		var s = size();
		var z = view.z;
		var n = Math.pow(2, z);

		// The world is one tile wide at every zoom; outside it there is
		// nothing, so the west and east edges are clamped rather than allowed
		// to wrap onto the other side of the map.
		view.x = Math.max(-0.5, Math.min(n - s.w / TILE + 0.5, Math.min(view.x, n - s.w / TILE)));

		var x0 = Math.floor(view.x);
		var y0 = Math.floor(view.y);
		var x1 = Math.ceil(view.x + s.w / TILE);
		var y1 = Math.ceil(view.y + s.h / TILE);

		var sig = z + ':' + x0 + ':' + y0 + ':' + x1 + ':' + y1 + ':' + s.w + ':' + s.h;
		if (sig === drawn) {
			return;
		}
		drawn = sig;
		layer.innerHTML = '';

		for (var tx = x0; tx <= x1; tx++) {
			for (var ty = y0; ty <= y1; ty++) {
				if (ty < 0 || ty >= n) {
					continue;
				}
				var wx = ((tx % n) + n) % n;
				var img = document.createElement('img');
				img.className = 'cl-mapview__tile';
				img.alt = '';
				img.draggable = false;
				img.loading = 'lazy';
				// OpenStreetMap's tile servers refuse a request that carries a
				// Referer from a host they have not seen, and answer with a
				// 403 "Access blocked" image — a warning sign the size of a
				// tile, repeated across the whole map. Asking with no referrer
				// at all avoids it for most servers, which is why the policy is
				// set here; and because some networks still refuse, a refused
				// tile is retried once from a second source before it is
				// dropped. A map that cannot load its tiles is worse than no
				// map: it reads as broken rather than as unavailable.
				img.referrerPolicy = 'no-referrer';
				img.decoding = 'async';
				img.src = tiles[0].url(z, wx, ty);
				img.onerror = function () {
					var step = parseInt(this.getAttribute('data-try') || '0', 10) + 1;
					if (tiles[step]) {
						this.setAttribute('data-try', String(step));
						this.src = tiles[step].url(z, wx, ty);
						return;
					}
					// Every source refused. The tile is dropped rather than
					// left as a broken frame; the pins sit on top, so the map
					// reads as a quiet grid instead of a wall of error signs.
					this.style.visibility = 'hidden';
				};
				img.style.left = Math.round((tx - view.x) * TILE) + 'px';
				img.style.top = Math.round((ty - view.y) * TILE) + 'px';
				layer.appendChild(img);
			}
		}
	}

	var open = null;

	function closeCard() {
		if (open) {
			open.parentNode.removeChild(open);
			open = null;
		}
	}

	function card(fix, left, top) {
		closeCard();
		var el = document.createElement('div');
		el.className = 'cl-mapview__card';

		var rows = [
			['When', fix.when + (fix.step && fix.steps ? '  (stop ' + fix.step + ' of ' + fix.steps + ')' : '')],
			['Link', fix.slug],
			['IP', fix.ip],
			['Place', fix.place || 'Coordinates only'],
			['Fix', fix.lat.toFixed(6) + ', ' + fix.lng.toFixed(6) + (fix.accuracy ? ' (±' + fix.accuracy + ' m)' : '')],
			['Device', fix.device || 'Unknown'],
			['Network', fix.network || 'Unknown'],
			['Allowed', fix.allowed || 'nothing asked'],
			['Refused', fix.refused || 'nothing refused']
		];

		// Every value here came from a visit row — the city name, the ISP, the
		// device string, the link slug — and all of those are written from
		// what a visitor's request carried. Building this card with string
		// concatenation and handing it to innerHTML would run any markup a
		// visitor managed to get into those columns, inside the operator's
		// own signed-in session. Each value is escaped before it is joined.
		function esc(value) {
			return String(value === null || value === undefined ? '' : value)
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;')
				.replace(/"/g, '&quot;')
				.replace(/'/g, '&#39;');
		}

		var html = '';
		for (var i = 0; i < rows.length; i++) {
			html += '<dt>' + esc(rows[i][0]) + '</dt><dd>' + esc(rows[i][1]) + '</dd>';
		}
		el.innerHTML = '<dl class="cl-mapview__dl">' + html + '</dl>'
			+ '<a class="cl-mapview__go" target="_blank" rel="noopener noreferrer" href="https://www.google.com/maps?q='
			+ encodeURIComponent(fix.lat + ',' + fix.lng) + '">Google Maps ↗</a>';

		// Keep the card inside the frame: flip it left near the east edge and
		// up near the south edge, so it is never half off the map.
		var s = size();
		el.style.left = Math.max(6, Math.min(left, s.w - 250)) + 'px';
		el.style.top = Math.max(6, Math.min(top, s.h - 200)) + 'px';
		canvas.appendChild(el);
		open = el;
	}

	function drawPaths() {
		var s = size();
		paths.innerHTML = '';
		paths.setAttribute('viewBox', '0 0 ' + s.w + ' ' + s.h);
		paths.setAttribute('width', s.w);
		paths.setAttribute('height', s.h);

		Object.keys(trails).forEach(function (key) {
			var pts = trails[key];
			var d = '';
			for (var i = 0; i < pts.length; i++) {
				var p = project(pts[i].lat, pts[i].lng, view.z);
				var x = (p.x - view.x) * TILE;
				var y = (p.y - view.y) * TILE;
				d += (i ? 'L' : 'M') + Math.round(x) + ' ' + Math.round(y) + ' ';
			}
			// Halo first, then the bright line, so the pair reads as one trail
			// over a map whose tiles are lighter than the panel behind them.
			var halo = document.createElementNS(NS, 'path');
			halo.setAttribute('d', d.trim());
			halo.setAttribute('class', 'cl-mapview__path');
			paths.appendChild(halo);

			var line = document.createElementNS(NS, 'path');
			line.setAttribute('d', d.trim());
			line.setAttribute('class', 'cl-mapview__path cl-mapview__path--core');
			paths.appendChild(line);

			// The last point in the trail is where this person was last seen.
			var last = pts[pts.length - 1];
			var lp = project(last.lat, last.lng, view.z);
			var ring = document.createElementNS(NS, 'circle');
			ring.setAttribute('cx', Math.round((lp.x - view.x) * TILE));
			ring.setAttribute('cy', Math.round((lp.y - view.y) * TILE));
			ring.setAttribute('r', 11);
			ring.setAttribute('class', 'cl-mapview__last');
			paths.appendChild(ring);
		});
	}

	function drawPins() {
		var s = size();
		pins.innerHTML = '';
		closeCard();

		for (var i = 0; i < fixes.length; i++) {
			(function (fix) {
				var p = project(fix.lat, fix.lng, view.z);
				var left = (p.x - view.x) * TILE;
				var top = (p.y - view.y) * TILE;
				if (left < -20 || top < -20 || left > s.w + 20 || top > s.h + 20) {
					return;
				}
				var pin = document.createElement('button');
				pin.type = 'button';
				pin.className = 'cl-mapview__pin'
					+ (fix.allowed && fix.allowed.length ? ' is-allowed' : '')
					+ (fix.trail !== undefined && fix.trail !== null ? ' is-trail' : '');
				if (fix.step && fix.steps) {
					pin.setAttribute('data-step', fix.step + '/' + fix.steps);
				}
				pin.style.left = Math.round(left) + 'px';
				pin.style.top = Math.round(top) + 'px';
				pin.title = fix.when + ' — ' + (fix.place || 'coordinates only');
				pin.setAttribute('aria-label', pin.title);
				pin.addEventListener('click', function (ev) {
					ev.stopPropagation();
					card(fix, left + 12, top + 6);
				});
				pins.appendChild(pin);
			}(fixes[i]));
		}
	}

	function render() {
		drawTiles();
		drawPaths();
		drawPins();
	}

	// Drag to pan, scroll to zoom. Both are what a map is expected to do; a
	// frame you cannot move is a picture of a map.
	var dragging = null;

	canvas.addEventListener('mousedown', function (ev) {
		if (ev.target.closest && ev.target.closest('.cl-mapview__pin, .cl-mapview__card')) {
			return;
		}
		dragging = { x: ev.clientX, y: ev.clientY, vx: view.x, vy: view.y };
		canvas.classList.add('is-dragging');
		closeCard();
	});

	window.addEventListener('mousemove', function (ev) {
		if (!dragging) {
			return;
		}
		view.x = dragging.vx - (ev.clientX - dragging.x) / TILE;
		view.y = dragging.vy - (ev.clientY - dragging.y) / TILE;
		render();
	});

	window.addEventListener('mouseup', function () {
		if (!dragging) {
			return;
		}
		dragging = null;
		canvas.classList.remove('is-dragging');
	});

	canvas.addEventListener('wheel', function (ev) {
		ev.preventDefault();
		var s = size();
		// Zoom around the cursor, not the corner, so the place under the
		// pointer stays under it.
		var px = view.x + ev.clientX / TILE;
		var py = view.y + ev.clientY / TILE;
		var next = view.z + (ev.deltaY < 0 ? 1 : -1);
		next = Math.max(MIN_Z, Math.min(MAX_Z, next));
		if (next === view.z) {
			return;
		}
		var c = project(0, 0, next);
		void c;
		// Re-project the same geographic point at the new zoom.
		var lat = Math.atan(Math.sinh(Math.PI * (1 - 2 * (view.y + ev.clientY / TILE) / Math.pow(2, view.z)))) * 180 / Math.PI;
		var lng = ((view.x + ev.clientX / TILE) / Math.pow(2, view.z)) * 360 - 180;
		view.z = next;
		var np = project(lat, lng, next);
		view.x = np.x - ev.clientX / TILE;
		view.y = np.y - ev.clientY / TILE;
		void s;
		void px;
		void py;
		render();
	}, { passive: false });

	document.addEventListener('click', function (ev) {
		if (!canvas.contains(ev.target)) {
			closeCard();
		}
	});

	window.addEventListener('resize', function () {
		fit();
		render();
	});

	function boot() {
		var s = size();
		if (!s.w || !s.h) {
			// Not laid out yet: measuring now would place every pin outside a
			// zero-width frame and they would never be redrawn.
			window.requestAnimationFrame(boot);
			return;
		}
		fit();
		render();
	}

	window.addEventListener('load', function () {
		fit();
		render();
	});

	boot();
}());
