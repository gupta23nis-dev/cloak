/**
 * The tower map.
 *
 * A network picture, not a route picture. Every covered city is a mast, its
 * height and its rings are how many devices are standing under it, and the
 * whole board carries a sweeping scan the way a radar does. The point is to
 * be legible in one glance from across a room: Bangalore at the centre and
 * brightest, the other metros ringing it, the smaller cities as quiet lights.
 *
 * Tiles come from the same three sources the console's other maps use, tried
 * in order, so a blocked host degrades to the next rather than to a blank
 * panel. The fallback is not a grey box: the grid, the masts and the sweep all
 * draw on their own, so the map still reads as an instrument if every tile
 * source refuses.
 */
(function () {
	'use strict';

	var host = document.getElementById('cl-tower');
	if (!host) {
		return;
	}

	var data = { towers: [], home: 'Bengaluru', unplaced: 0, total: 0 };
	try {
		data = JSON.parse(host.getAttribute('data-towers') || '{}') || data;
	} catch (e) {}
	if (!data.towers || !data.towers.length) {
		return;
	}

	var TILE = 256;
	var tilesEl = host.querySelector('.cl-tower__tiles');
	var linksEl = host.querySelector('.cl-tower__links');
	var mastsEl = host.querySelector('.cl-tower__masts');
	var scanEl = host.querySelector('.cl-tower__scan');
	var radarEl = host.querySelector('.cl-tower__radar');
	var beamEl = host.querySelector('.cl-tower__beam');
	var beamlineEl = host.querySelector('.cl-tower__beamline');
	var NS = 'http://www.w3.org/2000/svg';

	// Web Mercator, the projection every slippy map cuts its tiles on.
	function project(lat, lng, z) {
		var scale = Math.pow(2, z) * TILE;
		var x = (lng + 180) / 360 * scale;
		var s = Math.sin(lat * Math.PI / 180);
		s = Math.max(-0.9999, Math.min(0.9999, s));
		var y = (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * scale;
		return { x: x, y: y };
	}

	var view = { z: 5, cz: 5, cx: 0, cy: 0, w: 0, h: 0, k: 1 };
	var fitted = false;

	// The frame the towers occupy, at a zoom that is not a whole number.
	//
	// A slippy map only serves tiles at integer zooms, but there is no reason
	// the *projection* has to be one: the country is drawn at whatever scale
	// makes it fill the board, and the tiles are scaled to match. Forcing the
	// zoom to an integer is what put Bengaluru twenty-four pixels below the
	// bottom edge of a three-hundred-pixel panel — no integer zoom fits India
	// into a short wide board, so the loop ran out at the floor and drew a map
	// taller than its own frame. Everything hung off that: masts outside the
	// board, a sweep centred on a point that was off-screen.
	function fit() {
		var w = host.clientWidth || 320;
		var h = host.clientHeight || 320;
		view.w = w;
		view.h = h;

		var minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
		data.towers.forEach(function (t) {
			if (t.lat < minLat) { minLat = t.lat; }
			if (t.lat > maxLat) { maxLat = t.lat; }
			if (t.lng < minLng) { minLng = t.lng; }
			if (t.lng > maxLng) { maxLng = t.lng; }
		});

		// How tall and how wide the country is at zoom 5, measured rather than
		// assumed, then solved for the zoom that makes it fit. Room is left at
		// every edge because a mast carries a label above it and a caption
		// below, and a label that runs off the board is a name nobody reads.
		var a = project(maxLat, minLng, 5);
		var b = project(minLat, maxLng, 5);
		var spanH = Math.abs(b.y - a.y) || 1;
		var spanW = Math.abs(b.x - a.x) || 1;

		var zH = 5 + Math.log((h * 0.74) / spanH) / Math.LN2;
		var zW = 5 + Math.log((w * 0.82) / spanW) / Math.LN2;
		var z  = Math.min(zH, zW);
		// Bounded both ways: below 4 the country is a smudge between three
		// continents, and above 7 two neighbouring cities share a label.
		view.z  = Math.max(4, Math.min(7, z));
		// Tiles are served at whole zooms only. The next one up keeps labels
		// and coastlines crisp when the map is scaled down to fit.
		view.cz = Math.min(7, Math.ceil(view.z));
		view.k  = Math.pow(2, view.z - view.cz);

		var nw = project(maxLat, minLng, view.z);
		var se = project(minLat, maxLng, view.z);
		view.cx = (nw.x + se.x) / 2;
		view.cy = (nw.y + se.y) / 2;
		fitted = true;
	}

	function screenOf(lat, lng) {
		var p = project(lat, lng, view.z);
		return { x: p.x - view.cx + view.w / 2, y: p.y - view.cy + view.h / 2 };
	}

	/* ---- The sweep ---- */

	// A radar turns around one point, and that point has to be on the map.
	//
	// This is the whole of it. A sweep centred on the panel is centred on
	// whatever happens to be in the middle of a wide rectangle around a tall
	// country — which is open sea — so most of each turn lit nothing and the
	// picture read as a glow with no source. Centred on the home mast, every
	// degree of the turn passes over the network, and the beam reaches the
	// cities in a order a person can follow.
	var homePoint = null;
	var sweep = { deg: 0, last: 0, timer: 0 };

	// Where each mast sits relative to the home mast, as an angle. The blip
	// fires when the beam's leading edge crosses that angle.
	var bearings = [];

	function bearing(from, to) {
		var a = Math.atan2(to.y - from.y, to.x - from.x) * 180 / Math.PI;
		return (a + 450) % 360;
	}

	function placeRadar() {
		if (!scanEl || !radarEl) {
			return;
		}
		var home = null;
		data.towers.forEach(function (t) {
			if (t.name === data.home) {
				home = screenOf(t.lat, t.lng);
			}
		});
		if (!home) {
			return;
		}
		homePoint = home;

		// Big enough to reach the furthest corner of the board from here, so
		// the sweep is never clipped by an edge and never stops short of a
		// city. Bounded so a mast placed oddly cannot make the disc absurd.
		var far = 0;
		[[0, 0], [view.w, 0], [0, view.h], [view.w, view.h]].forEach(function (c) {
			var d = Math.sqrt(Math.pow(c[0] - home.x, 2) + Math.pow(c[1] - home.y, 2));
			if (d > far) { far = d; }
		});
		// A sweep that reaches the furthest corner of the board, so no edge
		// cuts it off, but never so large that its gradient banding shows.
		far = Math.min(far, Math.max(view.w, view.h) * 1.2);

		scanEl.style.setProperty('--cx', home.x.toFixed(1) + 'px');
		scanEl.style.setProperty('--cy', home.y.toFixed(1) + 'px');
		scanEl.style.setProperty('--r', Math.round(far) + 'px');

		bearings = [];
		data.towers.forEach(function (t) {
			if (t.name === data.home) {
				return;
			}
			var p = screenOf(t.lat, t.lng);
			bearings.push({ mast: t.__mast || null, deg: bearing(home, p), last: -1 });
		});
	}

	function blip(deg) {
		bearings.forEach(function (b) {
			// Did the leading edge cross this bearing since the last frame?
			// A plain equality test would miss it at any speed above zero, so
			// the crossing is measured, with the wrap at 360 handled.
			var prev = b.last < 0 ? deg - 0.001 : b.last;
			var crossed = prev <= deg ? (b.deg > prev && b.deg <= deg)
				: (b.deg > prev || b.deg <= deg);
			if (!crossed || !b.mast) {
				b.last = deg;
				return;
			}
			b.last = deg;
			var el = b.mast;
			el.classList.remove('is-blip');
			// Reading offsetWidth restarts the animation; without it a class
			// removed and added in the same frame does nothing.
			void el.offsetWidth;
			el.classList.add('is-blip');
			window.setTimeout(function () { el.classList.remove('is-blip'); }, 1000);
		});
	}

	var SPEED = 360 / 9; // one turn every nine seconds, the pace a real set uses

	function turn(now) {
		if (!scanEl || !scanEl.isConnected) {
			return;
		}
		var dt = sweep.last ? Math.min(0.12, (now - sweep.last) / 1000) : 0;
		sweep.last = now;
		if (document.hidden) {
			sweep.timer = window.requestAnimationFrame(turn);
			return;
		}
		sweep.deg = (sweep.deg + dt * SPEED) % 360;
		var d = sweep.deg.toFixed(2) + 'deg';
		if (beamEl) { beamEl.style.transform = 'rotate(' + d + ')'; }
		if (beamlineEl) { beamlineEl.style.transform = 'rotate(' + d + ')'; }
		blip(sweep.deg);
		sweep.timer = window.requestAnimationFrame(turn);
	}

	function startSweep() {
		if (sweep.timer) {
			return;
		}
		if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
			return;
		}
		sweep.last = 0;
		sweep.timer = window.requestAnimationFrame(turn);
	}

	/* ---- Tiles ---- */

	var SOURCES = [
		function (x, y, z) { return 'https://mt' + ((x + y) % 4) + '.google.com/vt/lyrs=m&hl=en&x=' + x + '&y=' + y + '&z=' + z; },
		function (x, y, z) { return 'https://tile.openstreetmap.org/' + z + '/' + x + '/' + y + '.png'; },
		function (x, y, z) { return 'https://basemaps.cartocdn.com/dark_all/' + z + '/' + x + '/' + y + '.png'; }
	];
	var sourceAt = 0;

	function drawTiles() {
		if (!tilesEl || !fitted) {
			return;
		}
		var z  = view.cz;
		var k  = view.k;
		var px = TILE * k;
		var left = view.cx - view.w / 2;
		var top  = view.cy - view.h / 2;

		var x0 = Math.floor(left / px);
		var y0 = Math.floor(top / px);
		var x1 = Math.floor((left + view.w) / px);
		var y1 = Math.floor((top + view.h) / px);
		var max = Math.pow(2, z);

		tilesEl.innerHTML = '';
		// Sixteen tiles is a screen; a hundred is a stall on a slow network.
		if ((x1 - x0 + 1) * (y1 - y0 + 1) > 120) {
			return;
		}
		for (var tx = x0; tx <= x1; tx++) {
			for (var ty = y0; ty <= y1; ty++) {
				if (ty < 0 || ty >= max) {
					continue;
				}
				var wx = ((tx % max) + max) % max;
				var img = document.createElement('img');
				img.className = 'cl-tower__tile';
				img.alt = '';
				img.decoding = 'async';
				img.loading = 'lazy';
				// Positioned with a fractional offset and drawn slightly larger
				// than its slot, so sub-pixel rounding leaves no hairline of
				// background between two tiles.
				img.style.left = (tx * px - left - 0.5).toFixed(1) + 'px';
				img.style.top = (ty * px - top - 0.5).toFixed(1) + 'px';
				img.style.width = Math.ceil(px) + 1 + 'px';
				img.style.height = Math.ceil(px) + 1 + 'px';
				img.src = SOURCES[sourceAt](wx, ty, z);
				img.addEventListener('error', function () {
					// One refusal is not a reason to give up: step to the next
					// source and redraw once. The previous source is not tried
					// again on this page, so a blocked host costs one pass.
					if (sourceAt < SOURCES.length - 1) {
						sourceAt++;
						window.setTimeout(drawTiles, 40);
					}
				}, { once: true });
				tilesEl.appendChild(img);
			}
		}
	}

	/* ---- Masts ---- */

	function maxLoad() {
		var m = 1;
		data.towers.forEach(function (t) { if (t.n > m) { m = t.n; } });
		return m;
	}

	function drawLinks() {
		if (!linksEl || !fitted) {
			return;
		}
		linksEl.innerHTML = '';
		linksEl.setAttribute('viewBox', '0 0 ' + view.w + ' ' + view.h);

		var home = null;
		data.towers.forEach(function (t) { if (t.name === data.home) { home = screenOf(t.lat, t.lng); } });
		if (!home) {
			return;
		}

		// A line from the home tower to every other mast that has traffic:
		// the shape of the installed network, not a route. Only live masts
		// get a line, so the picture says where the traffic is and not just
		// where the cities are.
		data.towers.forEach(function (t) {
			if (t.name === data.home || !t.n) {
				return;
			}
			var p = screenOf(t.lat, t.lng);
			var line = document.createElementNS(NS, 'line');
			line.setAttribute('x1', home.x.toFixed(1));
			line.setAttribute('y1', home.y.toFixed(1));
			line.setAttribute('x2', p.x.toFixed(1));
			line.setAttribute('y2', p.y.toFixed(1));
			line.setAttribute('class', 'cl-tower__link');
			line.style.animationDelay = (Math.random() * 2).toFixed(2) + 's';
			linksEl.appendChild(line);
		});
	}

	function drawMasts() {
		if (!mastsEl || !fitted) {
			return;
		}
		mastsEl.innerHTML = '';

		// Build every mast first, without a label, and measure it. Estimating
		// a label's width from its character count is what produced the pile
		// of overlapping names: real text is not a fixed-width font, a count
		// chip is not part of the name, and the estimate was wrong by the two
		// or three pixels that decide whether two boxes touch. The browser
		// knows the true box, so it is asked.
		var built = [];
		data.towers.forEach(function (t, i) {
			var p = screenOf(t.lat, t.lng);
			var mast = document.createElement('div');
			var isHome = t.name === data.home;
			mast.className = 'cl-tower__mast' + (t.n ? ' is-live' : ' is-quiet') + (isHome ? ' is-home' : '');
			mast.style.left = p.x.toFixed(1) + 'px';
			mast.style.top = p.y.toFixed(1) + 'px';
			mast.style.setProperty('--lv', '0');
			mast.innerHTML =
				'<span class="cl-tower__rings" aria-hidden="true"><i></i><i></i><i></i></span>' +
				'<span class="cl-tower__bar" aria-hidden="true"></span>' +
				'<span class="cl-tower__dot" aria-hidden="true"></span>';
			mast.setAttribute('title', t.name + (t.n ? ' — ' + t.n + ' device' + (t.n === 1 ? '' : 's') : ' — no devices'));
			mastsEl.appendChild(mast);
			// Kept on the tower data so the sweep can blip the right element
			// without a second lookup per frame.
			t.__mast = mast;
			built.push({ t: t, i: i, mast: mast, x: p.x, y: p.y });
		});

		// Placement order: the home tower, then the loudest, then the rest.
		// A label that would land on one already placed is not shown at all —
		// the dot and the rings stay, and the name is in the tooltip, so a
		// dropped label costs nothing but a few pixels of reading.
		built.sort(function (a, b) {
			var ha = a.t.name === data.home ? 1 : 0;
			var hb = b.t.name === data.home ? 1 : 0;
			if (ha !== hb) { return hb - ha; }
			return (b.t.n || 0) - (a.t.n || 0);
		});

		var placed = [];
		var overlaps = function (a, b) {
			return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
		};

		built.forEach(function (row) {
			var t = row.t;
			var tag = document.createElement('span');
			tag.className = 'cl-tower__tag';
			var inner = '<b></b><i></i>' + (t.n ? '<em></em>' : '');
			tag.innerHTML = inner;
			tag.querySelector('b').textContent = t.name;
			tag.querySelector('i').textContent = t.st;
			if (t.n) { tag.querySelector('em').textContent = String(t.n); }
			row.mast.appendChild(tag);

			// Measured where it will actually sit, before it is shown.
			var box = tag.getBoundingClientRect();
			var cand = {
				x: row.x + 9,
				y: row.y - 9,
				w: Math.max(24, Math.ceil(box.width)),
				h: Math.max(14, Math.ceil(box.height))
			};

			var clash = false;
			for (var k = 0; k < placed.length; k++) {
				if (overlaps(cand, placed[k])) { clash = true; break; }
			}

			// A quiet tower yields to a busy one: if it clashes, it is dropped
			// even when there is room elsewhere, because a name with no
			// devices is the least useful mark on this board.
			if (clash) {
				tag.parentNode.removeChild(tag);
				row.mast.classList.add('is-unlabelled');
				return;
			}
			placed.push(cand);
		});

		// The strength goes on last, once the order is settled, so the ring
		// animation does not start and stop as labels are added.
		var peak = maxLoad();
		built.forEach(function (row) {
			var level = row.t.n ? Math.min(1, Math.sqrt(row.t.n / peak)) : 0;
			row.mast.style.setProperty('--lv', level.toFixed(3));
		});
	}

	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	/* ---- Board ---- */

	function render() {
		var w = host.clientWidth || 0;
		var h = host.clientHeight || 0;
		if (!w || !h) {
			return;
		}
		if (!fitted || w !== view.w || h !== view.h) {
			fit();
			drawTiles();
		}
		drawLinks();
		drawMasts();
		placeRadar();
		startSweep();
	}

	var raf = 0;
	function schedule() {
		if (raf) {
			return;
		}
		raf = window.requestAnimationFrame(function () {
			raf = 0;
			render();
		});
	}

	if (window.ResizeObserver) {
		new ResizeObserver(schedule).observe(host);
	}
	window.addEventListener('resize', schedule);

	render();

	// The sweep runs on requestAnimationFrame, so it stops by itself in a
	// background tab and leaves nothing to clean up.
	window.addEventListener('pagehide', function () {
		if (sweep.timer) {
			window.cancelAnimationFrame(sweep.timer);
			sweep.timer = 0;
		}
	});
})();
