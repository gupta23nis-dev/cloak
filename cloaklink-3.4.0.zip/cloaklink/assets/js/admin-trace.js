/**
 * The tracing map.
 *
 * A phone that is finding you draws three things: a dark map, a sweep going
 * round, and a ring that pulses when it locks on. That is the whole idea
 * here, and it is the right one for this screen — the console is listening
 * for visitors, and a still photograph of a map with pins on it says the
 * opposite.
 *
 * Everything is drawn from the same tiles the Map screen uses, so there is no
 * second basemap that looks almost like the first. No key, no third-party
 * library: the projection is Web Mercator, the tiles are plain <img>, and the
 * lines are a single <svg> path.
 *
 * The map is deliberately not pannable. A box on a dashboard that answers
 * "where are they" should hold still; one that moves under the pointer is a
 * toy, and the Map screen is one click away for looking around properly.
 */
(function () {
	'use strict';

	var host = document.getElementById('cl-trace');
	if (!host) {
		return;
	}

	var data = { points: [], trails: [] };
	try {
		data = JSON.parse(host.getAttribute('data-points') || '{}') || data;
	} catch (e) {}
	if (!data.points) {
		data.points = [];
	}
	if (!data.trails) {
		data.trails = [];
	}

	var TILE = 256;
	var tilesEl = host.querySelector('.cl-trace__tiles');
	var pathsEl = host.querySelector('.cl-trace__paths');
	var pinsEl = host.querySelector('.cl-trace__pins');
	var NS = 'http://www.w3.org/2000/svg';

	// Web Mercator, the projection every slippy map cuts its tiles on.
	function project(lat, lng, z) {
		var n = Math.pow(2, z);
		var x = (lng + 180) / 360 * n;
		var rad = lat * Math.PI / 180;
		var y = (1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * n;
		return { x: x, y: y };
	}

	function size() {
		return { w: host.clientWidth || 700, h: host.clientHeight || 320 };
	}

	// The same three sources as the Map screen: Google first because it is the
	// map an operator already reads, then the community server, then a dark
	// basemap. A tile is only dropped when all three refuse, so a network that
	// blocks one still draws a map.
	var sources = [
		function (z, x, y) {
			return 'https://mt' + (Math.abs(x + y) % 4) + '.google.com/vt/lyrs=m&hl=en&x=' + x + '&y=' + y + '&z=' + z;
		},
		function (z, x, y) {
			return 'https://tile.openstreetmap.org/' + z + '/' + x + '/' + y + '.png';
		},
		function (z, x, y) {
			return 'https://' + ('abc'[Math.abs(x + y) % 3]) + '.basemaps.cartocdn.com/dark_all/' + z + '/' + x + '/' + y + '.png';
		}
	];

	var view = { z: 3, x: 0, y: 0 };
	var drawnTiles = '';

	function fit() {
		var s = size();
		if (!data.points.length) {
			// No points: the whole world, centred. The sweep needs somewhere
			// to run and a blank rectangle is not a map.
			view.z = 3;
			var c = project(20, 10, view.z);
			view.x = c.x - s.w / (2 * TILE);
			view.y = c.y - s.h / (2 * TILE);
			return;
		}

		var best = 2;
		for (var z = 2; z <= 16; z++) {
			var xs = [], ys = [];
			for (var i = 0; i < data.points.length; i++) {
				var p = project(data.points[i].lat, data.points[i].lng, z);
				xs.push(p.x);
				ys.push(p.y);
			}
			var w = (Math.max.apply(null, xs) - Math.min.apply(null, xs)) * TILE;
			var h = (Math.max.apply(null, ys) - Math.min.apply(null, ys)) * TILE;
			if (w > s.w - 140 || h > s.h - 120) {
				break;
			}
			best = z;
		}
		// One point has no spread, so a fit would zoom to the street. A city
		// is the right answer for a single visitor.
		if (data.points.length === 1 && best > 11) {
			best = 11;
		}
		view.z = best;

		var minx = Infinity, maxx = -Infinity, miny = Infinity, maxy = -Infinity;
		for (var j = 0; j < data.points.length; j++) {
			var q = project(data.points[j].lat, data.points[j].lng, view.z);
			minx = Math.min(minx, q.x);
			maxx = Math.max(maxx, q.x);
			miny = Math.min(miny, q.y);
			maxy = Math.max(maxy, q.y);
		}
		view.x = (minx + maxx) / 2 - s.w / (2 * TILE);
		view.y = (miny + maxy) / 2 - s.h / (2 * TILE);
	}

	function screenOf(lat, lng) {
		var p = project(lat, lng, view.z);
		return {
			x: (p.x - view.x) * TILE,
			y: (p.y - view.y) * TILE
		};
	}

	function drawTiles() {
		var s = size();
		var n = Math.pow(2, view.z);
		var x0 = Math.floor(view.x), y0 = Math.floor(view.y);
		var x1 = Math.ceil(view.x + s.w / TILE), y1 = Math.ceil(view.y + s.h / TILE);
		var sig = view.z + ':' + x0 + ':' + y0 + ':' + x1 + ':' + y1 + ':' + s.w + ':' + s.h;
		if (sig === drawnTiles) {
			return;
		}
		drawnTiles = sig;
		tilesEl.innerHTML = '';

		for (var tx = x0; tx <= x1; tx++) {
			for (var ty = y0; ty <= y1; ty++) {
				if (ty < 0 || ty >= n) {
					continue;
				}
				var wx = ((tx % n) + n) % n;
				var img = document.createElement('img');
				img.className = 'cl-trace__tile';
				img.alt = '';
				img.draggable = false;
				img.decoding = 'async';
				img.style.left = ((tx - view.x) * TILE) + 'px';
				img.style.top = ((ty - view.y) * TILE) + 'px';
				img.style.width = TILE + 'px';
				img.style.height = TILE + 'px';

				// Each tile walks the source list once. A source that fails is
				// swapped for the next on the same element, so a blocked CDN
				// costs one request and no visible hole.
				(function (el, z, xx, yy) {
					var idx = 0;
					el.onerror = function () {
						idx++;
						if (idx < sources.length) {
							el.src = sources[idx](z, xx, yy);
						} else {
							el.style.display = 'none';
						}
					};
					el.src = sources[0](z, xx, yy);
				}(img, view.z, wx, ty));

				tilesEl.appendChild(img);
			}
		}
	}

	function drawPaths() {
		pathsEl.innerHTML = '';
		// A trail is a route only once a person has two stops on it. One
		// stop is a dot, which the pin already draws.
		var usable = data.trails.filter(function (t) {
			return (t.line || []).length > 1;
		});
		if (!usable.length) {
			return;
		}
		var s = size();
		pathsEl.setAttribute('viewBox', '0 0 ' + s.w + ' ' + s.h);
		pathsEl.setAttribute('width', s.w);
		pathsEl.setAttribute('height', s.h);

		usable.forEach(function (trail, i) {
			var line = trail.line;
			var d = '';
			line.forEach(function (pt, k) {
				var sp = screenOf(pt[0], pt[1]);
				d += (k === 0 ? 'M' : 'L') + sp.x.toFixed(1) + ' ' + sp.y.toFixed(1);
			});

			// A soft under-stroke first, then a bright dashed one on top: the
			// glow is what makes a thin line read on a busy map, and the dashes
			// move, which is what makes it read as travelling rather than as a
			// drawn line.
			var glow = document.createElementNS(NS, 'path');
			glow.setAttribute('d', d);
			glow.setAttribute('class', 'cl-trace__glowline');
			glow.style.animationDelay = (i * 0.4) + 's';
			pathsEl.appendChild(glow);

			var path = document.createElementNS(NS, 'path');
			path.setAttribute('d', d);
			path.setAttribute('class', 'cl-trace__line');
			path.style.animationDelay = (i * 0.4) + 's';
			pathsEl.appendChild(path);
		});
	}

	// Three tones, dealt out by person, so a map with several people on it is
	// several colours rather than one. The palette is the console's own.
	var TONES = ['cyan', 'green', 'amber', 'violet'];

	function drawPins() {
		pinsEl.innerHTML = '';
		var toneOf = {};

		data.points.forEach(function (p, i) {
			if (toneOf[p.key] === undefined) {
				toneOf[p.key] = TONES[Object.keys(toneOf).length % TONES.length];
			}
			var sp = screenOf(p.lat, p.lng);

			var pin = document.createElement('span');
			pin.className = 'cl-trace__pin is-' + toneOf[p.key];
			pin.style.left = sp.x + 'px';
			pin.style.top = sp.y + 'px';
			// Dealt out down the list so the rings arrive one after the other
			// rather than all at once, which is what a sweep finding several
			// things looks like.
			pin.style.animationDelay = (0.12 * i) + 's';
			pin.title = p.name + (p.place ? ' · ' + p.place : '') + (p.at ? ' · ' + p.at : '');

			var ring = document.createElement('i');
			ring.className = 'cl-trace__ring';
			ring.style.animationDelay = (0.35 * i) + 's';

			var dot = document.createElement('i');
			dot.className = 'cl-trace__dot';

			pin.appendChild(ring);
			pin.appendChild(dot);

			if (p.n > 1) {
				var badge = document.createElement('b');
				badge.className = 'cl-trace__n';
				badge.textContent = p.n;
				pin.appendChild(badge);
			}

			pinsEl.appendChild(pin);
		});
	}

	var raf = 0;
	function render() {
		if (raf) {
			cancelAnimationFrame(raf);
		}
		raf = requestAnimationFrame(function () {
			raf = 0;
			var s = host.__clSize || {};
			var now = { w: host.clientWidth, h: host.clientHeight };
			if (s.w === now.w && s.h === now.h && host.__clDrawn) {
				return;
			}
			host.__clSize = now;
			host.__clDrawn = true;
			fit();
			drawTiles();
			drawPaths();
			drawPins();
		});
	}

	// A new arrival is added to the map rather than the map being rebuilt:
	// the rings already on it keep their place, and only the new one pulses.
	// That is what makes it read as tracing rather than as refreshing.
	window.clTraceAdd = function (item) {
		if (!item || item.lat === null || item.lng === null || item.lat === undefined) {
			return;
		}
		var key = String(item.name || 'visitor').toLowerCase();
		data.points.unshift({
			lat: Number(item.lat),
			lng: Number(item.lng),
			name: String(item.name || ''),
			place: String(item.place || ''),
			at: String(item.at || ''),
			n: 1,
			key: key
		});
		// The cap matches the one the server draws with, so a long shift does
		// not slowly turn the map into a solid disc.
		if (data.points.length > 40) {
			data.points.length = 40;
		}
		var trail = null;
		for (var i = 0; i < data.trails.length; i++) {
			if (data.trails[i].key === key) {
				trail = data.trails[i];
			}
		}
		if (!trail) {
			trail = { key: key, line: [] };
			data.trails.push(trail);
		}
		trail.line.push([Number(item.lat), Number(item.lng)]);

		// A new point widens the bounds, so the whole map is re-fitted — but
		// only the new pin is marked as arriving.
		host.__clDrawn = false;
		fit();
		drawTiles();
		drawPaths();
		drawPins();
		var newest = pinsEl.firstChild;
		if (newest) {
			newest.classList.add('is-new');
			window.setTimeout(function () {
				newest.classList.remove('is-new');
			}, 2600);
		}

		var countEl = document.getElementById('cl-trace-n');
		if (countEl) {
			countEl.innerHTML = '<b>' + data.points.length + '</b> sighting' + (data.points.length === 1 ? '' : 's');
		}
		host.classList.add('is-hot');
		window.setTimeout(function () {
			host.classList.remove('is-hot');
		}, 1800);
	};

	if ('ResizeObserver' in window) {
		new ResizeObserver(render).observe(host);
	}
	window.addEventListener('resize', render);
	render();
}());
