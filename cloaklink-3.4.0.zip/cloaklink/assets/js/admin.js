/**
 * CloakLink admin behaviour: live feed, copy, type switching, previews, bulk select.
 */
(function () {
	'use strict';

	var cfg = window.CLOAKLINK || {};
	var i18n = cfg.i18n || {};

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}

	/* ---- A clock that keeps running when the tab is not looked at ----
	 *
	 * This is the whole of "the alert arrives two minutes late".
	 *
	 * Everything on this panel is a poll, and every poll used to be a
	 * setInterval on the page. A browser slows those down the moment a tab is
	 * not the one in front: after about five minutes in the background a
	 * one-second interval is allowed to fire roughly once a minute, and a tab
	 * that has been hidden longer is throttled harder still. So the poll was
	 * still "every second" as written and one a minute in practice, and a
	 * capture that landed in between was announced whenever the browser felt
	 * like it — which is exactly the delay an operator reports as "it came two
	 * minutes after the click".
	 *
	 * A Web Worker is not subject to the page-timer throttling that a hidden
	 * tab is (its timers are their own). The worker does nothing but count and
	 * post a message; the page listens and does the work, so the page keeps its
	 * own clocks, its own visibility rules and its own back-off. When a worker
	 * cannot be created — an old browser, a Content-Security-Policy that
	 * forbids blob: workers — this falls back to a plain interval, which is
	 * exactly what ran before, so nothing is worse than it was.
	 *
	 * @param {number}   ms  Interval in milliseconds.
	 * @param {Function} fn  Called on each tick.
	 * @return {Object} Handle with a stop method.
	 */
	var steadyWorker = null;
	var steadyJobs = [];
	var STEADY_BEAT = 250;

	function steadyStart() {
		if (steadyWorker !== null) {
			return;
		}
		try {
			var src = 'var t=setInterval(function(){postMessage(1);},' + STEADY_BEAT + ');'
				+ 'onmessage=function(){clearInterval(t);};';
			var url = window.URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
			var w = new Worker(url);
			w.onmessage = function () {
				for (var i = 0; i < steadyJobs.length; i++) {
					var job = steadyJobs[i];
					job.due += STEADY_BEAT;
					if (job.due < job.every) {
						continue;
					}
					// Subtract the period instead of zeroing the debt.
					//
					// Zeroing made every period round up to the next whole
					// beat, so a job asked for at 1200ms actually ran at
					// 1250ms and one asked for at 2500ms ran at 2750ms. On a
					// one second poll that was a quarter of a second of pure
					// delay on every single arrival, which is a large part of
					// what "the notification comes late" was.
					job.due -= job.every;
					try {
						job.fn();
					} catch (e) {}
				}
			};
			steadyWorker = w;
		} catch (e) {
			steadyWorker = null;
		}
		steadyWorker = steadyWorker || false;
	}

	// Several polls, one clock.
	//
	// The panel asks for new rows once a second, the countdowns every two and a
	// half seconds, the queue every two and a half. They share one worker
	// ticking at a quarter second and each keeps its own due time, so a fast
	// poll does not drag a slow one up to its rate and the panel still makes
	// the same number of requests it did before.
	function steady(ms, fn) {
		ms = Math.max(STEADY_BEAT, Number(ms) || 1000);
		steadyStart();
		var job = { fn: fn, every: ms, due: 0 };
		steadyJobs.push(job);
		var fallback = null;
		if (!steadyWorker) {
			fallback = window.setInterval(fn, ms);
		}
		return {
			stop: function () {
				var at = steadyJobs.indexOf(job);
				if (at !== -1) {
					steadyJobs.splice(at, 1);
				}
				if (fallback) {
					window.clearInterval(fallback);
				}
			}
		};
	}

	function ajax(action, data) {
		var body = new URLSearchParams();
		body.append('action', action);
		body.append('nonce', cfg.nonce || '');
		Object.keys(data || {}).forEach(function (key) {
			body.append(key, data[key]);
		});

		return fetch(cfg.ajax, {
			method: 'POST',
			credentials: 'same-origin',
			// These are live reads, and the browser is allowed to keep a copy
			// only for as long as it takes to hand it over. Without this a
			// back-navigation or a bfcache restore could re-serve a poll from
			// before the last arrival, which is exactly the kind of "late"
			// that makes a live panel feel stale.
			cache: 'no-store',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (res) {
			return res.json();
		});
	}

	/* -------------------------------------------------------------------
	   The delete question, asked by the page rather than the browser.

	   Every destructive control on this console used a native confirm():
	   `<form onsubmit="return confirm('…')">`. That works until the one
	   moment it does not — a browser offered a "prevent this page from
	   creating additional dialogs" tick after a burst of prompts, or a
	   kiosk profile that has dialogs off entirely. From then on confirm()
	   returns false without drawing anything, onsubmit returns false, and
	   the form never submits. Nothing appears, nothing is logged, and the
	   button reads as dead. That is the exact report: "some options cannot
	   be deleted".

	   A dialog this page owns cannot be switched off by the browser, and
	   it also says which thing is about to go, which a one-line confirm
	   never could.

	   The markup is one element, built once. It traps focus while open so
	   a keyboard user cannot tab behind it, closes on Escape and on a press
	   outside the panel, and puts focus back on whatever opened it.
	   ------------------------------------------------------------------- */
	function clAsk(text, okLabel, onYes, danger) {
		var host = document.getElementById('cl-ask');
		if (!host) {
			host = document.createElement('div');
			host.id = 'cl-ask';
			host.className = 'cl-ask';
			host.hidden = true;
			host.innerHTML =
				'<div class="cl-ask__veil" data-cl-ask-no></div>' +
				'<div class="cl-ask__win" role="alertdialog" aria-modal="true" aria-labelledby="cl-ask-t">' +
				'<span class="cl-ask__ico" aria-hidden="true"></span>' +
				'<p class="cl-ask__t" id="cl-ask-t"></p>' +
				'<div class="cl-ask__acts">' +
				'<button type="button" class="cl-ask__b cl-ask__b--no" data-cl-ask-no></button>' +
				'<button type="button" class="cl-ask__b cl-ask__b--yes"></button>' +
				'</div></div>';
			document.body.appendChild(host);
		}

		var was = document.activeElement;
		var yes = host.querySelector('.cl-ask__b--yes');
		var no = host.querySelector('.cl-ask__b--no');

		host.querySelector('.cl-ask__t').textContent = text;
		yes.textContent = okLabel || (cfg.i18n && cfg.i18n.remove) || 'Remove';
		no.textContent = (cfg.i18n && cfg.i18n.cancel) || 'Cancel';
		host.classList.toggle('is-danger', !!danger);
		host.hidden = false;

		var shut = function () {
			host.hidden = true;
			document.removeEventListener('keydown', keys, true);
			host.removeEventListener('click', click);
			if (was && was.focus) {
				try { was.focus(); } catch (e) {}
			}
		};

		var keys = function (ev) {
			if (ev.key === 'Escape') {
				ev.preventDefault();
				shut();
			} else if (ev.key === 'Tab') {
				// Two buttons, one trap. Without this the tab key walks out of
				// the dialog and into the page behind it, which for a keyboard
				// user is the same as the dialog not being modal at all.
				var next = ev.shiftKey ? no : yes;
				var other = ev.shiftKey ? yes : no;
				if (document.activeElement === other) {
					ev.preventDefault();
					next.focus();
				}
			}
		};

		var click = function (ev) {
			if (ev.target.closest('[data-cl-ask-no]')) {
				ev.preventDefault();
				shut();
				return;
			}
			if (ev.target === yes || yes.contains(ev.target)) {
				ev.preventDefault();
				shut();
				onYes();
			}
		};

		host.addEventListener('click', click);
		document.addEventListener('keydown', keys, true);
		window.setTimeout(function () { yes.focus(); }, 20);
	}

	/* Any form carrying data-cl-confirm asks before it posts.
	 *
	 * Capture phase and on the document, so a form added by a live poll — the
	 * wall redraws its cards, and every card carries its own controls — is
	 * covered the moment it exists, without the poll having to know this
	 * module is here. */
	document.addEventListener('submit', function (ev) {
		var form = ev.target;
		if (!form || form.nodeName !== 'FORM' || !form.hasAttribute('data-cl-confirm')) {
			return;
		}
		if (form.getAttribute('data-cl-confirmed') === '1') {
			return;
		}
		ev.preventDefault();
		clAsk(
			form.getAttribute('data-cl-confirm'),
			(form.querySelector('[data-cl-yes]') || {}).textContent || (cfg.i18n && cfg.i18n.remove),
			function () {
				form.setAttribute('data-cl-confirmed', '1');
				if (typeof form.requestSubmit === 'function') {
					form.requestSubmit();
				} else {
					form.submit();
				}
			},
			true
		);
	}, true);

	/* Copy to clipboard with a fallback for non-secure contexts. */
	function copyText(text, done) {
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(text).then(function () {
				done(true);
			}).catch(function () {
				done(legacyCopy(text));
			});
			return;
		}
		done(legacyCopy(text));
	}

	function legacyCopy(text) {
		var el = document.createElement('textarea');
		el.value = text;
		el.setAttribute('readonly', '');
		el.style.position = 'fixed';
		el.style.opacity = '0';
		document.body.appendChild(el);
		el.select();
		var ok = false;
		try {
			ok = document.execCommand('copy');
		} catch (e) {
			ok = false;
		}
		document.body.removeChild(el);
		return ok;
	}

	function flash(el, message) {
		var previous = el.getAttribute('data-label');
		if (!previous) {
			el.setAttribute('data-label', el.textContent);
		}
		el.textContent = message;
		window.setTimeout(function () {
			var label = el.getAttribute('data-label');
			if (label) {
				el.textContent = label;
			}
		}, 1400);
	}

	/* A number that has just changed gets one lift, so a figure the operator
	   is watching is seen changing rather than found changed.
	 *
	 * It used to insist on a .cl-kpi ancestor and quietly do nothing anywhere
	 * else, which meant the archive's own figures — and every other number
	 * outside the dashboard tiles — changed without the gesture. It now lifts
	 * whatever it is handed, and still prefers the tile when there is one so
	 * the scan animation lands on the whole card rather than on the digits. */
	function settle(el) {
		if (!el) {
			return;
		}
		var tile = (el.closest && el.closest('.cl-kpi, .cl-records__stat, .cl-deskstrip__cell')) || el;
		tile.classList.remove('is-bumped');
		void tile.offsetWidth;
		tile.classList.add('is-bumped');
		window.setTimeout(function () {
			tile.classList.remove('is-bumped');
		}, 900);
	}

	/* ---- Settings: add this machine to the allowlist ----
	 * The operator is looking at the network they are on; asking them to copy
	 * it out of a line of text and paste it into a textarea is a way to end up
	 * with a typo and a closed door.
	 */
	ready(function () {
		var add = document.getElementById('cl-ip-add');
		var list = document.getElementById('cl-ip-list');
		if (!add || !list) {
			return;
		}
		add.addEventListener('click', function () {
			var ip = add.getAttribute('data-ip') || '';
			if (!ip) {
				return;
			}
			var lines = String(list.value || '').split(/\r?\n/).map(function (l) {
				return l.trim();
			}).filter(Boolean);
			if (lines.indexOf(ip) === -1) {
				lines.push(ip);
			}
			list.value = lines.join('\n');
			list.focus();
			list.scrollTop = list.scrollHeight;
			add.hidden = true;
		});
	});

	/* ---- A decision the operator just made ----
	 *
	 * Allowing a ticket is the one act on this panel that starts somebody
	 * else's work, and it used to leave no trace in the room at all: the
	 * screen reloaded with a line of text at the top and that was that. The
	 * agent's desk announces the allowance from its end; this is the same
	 * event announced from ours, so the person who pressed Allow knows it
	 * left their hands and knows which case it was.
	 *
	 * A hold is the same shape in the other direction and gets its own
	 * figure, because "I let this through" and "I stopped this" must not
	 * sound alike when both are one keystroke apart.
	 *
	 * The payload arrives from the server once and is cleared there, so a
	 * refresh does not announce it a second time.
	 */
	ready(function () {
		var d = cfg.decision;
		if (!d || !d.who && !d.ref) {
			return;
		}
		var N = window.CloakNotice;
		var S = window.CloakSound;
		var allowed = !!d.allowed;
		var name = d.who ? String(d.who) : ('#' + String(d.ref || ''));

		if (N) {
			N.quiet({
				tone: allowed ? 'allow' : 'deny',
				kicker: allowed ? 'Ticket allowed' : 'Ticket held',
				text: allowed
					? (name + ' can open the desk now.')
					: (name + ' stays in the queue.'),
				detail: d.ref ? ('#' + String(d.ref)) : '',
				sound: allowed ? 'allow' : 'deny',
				role: 'admin',
				ttl: allowed ? 11000 : 13000
			});
			return;
		}

		// No notice layer: still make the sound, because the decision
		// happened whether or not this page can draw a card for it.
		if (S) {
			S.setRole('admin');
			S.arm();
			S.play(allowed ? 'allow' : 'deny');
		}
	});

	/* ---- Capture alerts ----
	 *
	 * A capture is the one event this panel is worth interrupting for: a
	 * visitor has just handed over a position, a camera or a microphone,
	 * and an operator who is reading another screen finds out by hearing
	 * it rather than by noticing a card appear.
	 *
	 * The tone is generated with the Web Audio API rather than loaded from
	 * a file, so it works on the first capture after a page load, costs no
	 * request, and cannot 404. Browsers hold an audio context closed until
	 * the page has been clicked at least once; when that happens the alert
	 * still appears, silently, and the context opens on the next click.
	 */
	var SOUND_KEY = 'cl_alert_sound';
	var KIND_WORD = {
		position: 'location',
		camera: 'camera',
		microphone: 'microphone',
		video: 'video'
	};

	// A mark per kind, and a colour per kind, so the four cells are told
	// apart at a glance and by more than one sense. The emoji is drawn in the
	// panel's own palette rather than left as the platform's coloured glyph,
	// because a Windows emoji and an Apple emoji are different shapes and the
	// row stopped looking like one design across machines.
	var KIND_MARK = {
		position: '◎',
		camera: '◉',
		microphone: '◍',
		video: '▣',
		link: '⛓',
		risk: '⚠'
	};
	// On unless the operator switched it off for the site, or for this browser.
	// The old code defaulted to on and could only be changed by a button that
	// had to be pressed on every page — which is exactly the wrong way round.
	var soundOn = !(cfg && cfg.alertOn === 0);
	try {
		if ('0' === window.localStorage.getItem(SOUND_KEY)) {
			soundOn = false;
		}
	} catch (e) {}
	var audioCtx = null;

	function soundAllowed() {
		return soundOn && alertVolume() > 0;
	}

	/**
	 * The volume, as a number from 0 to 100.
	 *
	 * The site setting is the floor: an operator who turned the panel down
	 * expects it to stay down. The per-browser switch on the wall can still
	 * silence it entirely, because a person at a machine may need quiet for a
	 * reason the setting knows nothing about.
	 */
	function alertVolume() {
		var v = cfg && typeof cfg.alertVolume === 'number' ? cfg.alertVolume : 70;
		return Math.max(0, Math.min(100, v));
	}

	function setSound(on) {
		soundOn = !!on;
		try {
			window.localStorage.setItem(SOUND_KEY, soundOn ? '1' : '0');
		} catch (e) {}
		var btn = document.getElementById('cl-caps-sound');
		if (btn) {
			btn.setAttribute('aria-pressed', soundOn ? 'true' : 'false');
			btn.classList.toggle('is-off', !soundOn);
		}
		if (soundOn) {
			beep();
		}
	}

	/**
	 * One soft note, for the access panel's keys and the small confirmations.
	 *
	 * A sine with a short attack and a fast decay. Anything with corners in
	 * it — a square, a saw, a hard on/off — reads as an error buzzer at this
	 * volume, and this is only ever a "yes, that registered".
	 */
	function noteOnce(hz) {
		if (!audioCtx) {
			return;
		}
		var at = audioCtx.currentTime + 0.005;
		var osc = audioCtx.createOscillator();
		var gain = audioCtx.createGain();
		osc.type = 'sine';
		osc.frequency.setValueAtTime(hz, at);
		gain.gain.setValueAtTime(0.0001, at);
		gain.gain.exponentialRampToValueAtTime(0.05, at + 0.006);
		gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.06);
		osc.connect(gain);
		gain.connect(audioCtx.destination);
		osc.start(at);
		osc.stop(at + 0.08);
	}

	/* ---------------------------------------------------------------
	 * The alert voices.
	 *
	 * What was here before was a triangle wave through a lowpass: correct,
	 * audible, and thin. It read as a test tone rather than as an
	 * instrument — the sort of sound a machine makes to prove it can make
	 * one — and the operator said so ("still this sound not good").
	 *
	 * Everything below is built the way a real struck instrument is built,
	 * because that is what the ear is actually good at reading:
	 *
	 *   1. INHARMONIC PARTIALS. A struck bell does not ring at 1f, 2f, 3f.
	 *      Its overtones sit slightly off the octave — 2.76, 5.4, 8.9 times
	 *      the fundamental — and that slight wrongness is the whole
	 *      difference between a bell and a beep. Each voice here is a
	 *      fundamental plus two or three partials at those ratios, every
	 *      one with its own decay and its own level.
	 *   2. A REAL ATTACK. A 3 ms ramp into full level, not a 6 ms one. The
	 *      front of the note is what tells the ear something was struck;
	 *      too soft and it fades in like a synthesiser pad.
	 *   3. A ROOM. A short feedback delay with a soft, dark filter in the
	 *      loop stands in for the walls. It is what makes the sound sit in
	 *      a space rather than sit on the speaker — and it costs three
	 *      nodes and about 8% of one core for half a second.
	 *   4. DYNAMICS BETWEEN EVENTS. A capture is a rising three-note
	 *      figure; a repeat visit is one low note; a failure is a falling
	 *      minor third. Two sounds that mean two things are never the same
	 *      sound, and never the same loudness.
	 *
	 * Levels are set so a burst of them cannot clip: the master gain is
	 * shared and every voice is well under full scale before it reaches it.
	 * --------------------------------------------------------------- */

	/**
	 * The two voices this panel speaks with.
	 *
	 * These are deliberately NOT bells any more. The metal bell was rebuilt
	 * once already and the answer came back the same — it is harsh. The
	 * reason is physical: a struck bell rings on partials at 2.76, 5.40 and
	 * 8.93 times its fundamental, and those awkward ratios are exactly what
	 * the ear reads as clangour. They are correct for a real bell and they
	 * are tiring to hear forty times a day, which is how often this one fires.
	 *
	 * So both voices are now HARMONIC — whole-number partials only, the way
	 * a marimba, a felt piano or a plucked string behaves. A harmonic voice
	 * has no clangour to tire of: it reads as warm at any volume, and it
	 * stays legible through a laptop speaker, which is where it is heard.
	 *
	 * The two consoles are given different INSTRUMENTS rather than different
	 * notes of one instrument, because that is what makes them tellable apart
	 * across a room with the speaker turned down:
	 *
	 *   desk  (admin) — a wooden marimba: strong fundamental, a soft second
	 *                   partial, a quick bloom. Warm, low, unmistakable.
	 *   agent (desk)  — a brighter struck bar: the same harmonic series but
	 *                   with more of the third and fourth partials and a
	 *                   shorter decay, so it reads as glassy and forward.
	 *
	 * Neither is ever the same pitch as an alert on the other.
	 */
	var VOICES = {
		// fundamental, partials [ratio, level]
		desk:  [[1, 1.00], [2, 0.34], [3, 0.09], [4, 0.03]],
		agent: [[1, 1.00], [3, 0.30], [4, 0.14], [5, 0.05]]
	};

	/**
	 * One struck note on a harmonic voice.
	 *
	 * @param {number} at     Context time to strike at.
	 * @param {number} hz     Fundamental.
	 * @param {number} level  Peak gain before the master.
	 * @param {number} ring   Seconds the voice is allowed to ring for.
	 * @param {Object} out    Node to connect the voice's output to.
	 * @param {string} voice  'desk' or 'agent'.
	 * @param {number} bright 0..1, how much the upper partials are allowed
	 *                        to speak. A soft note is 0.
	 */
	function strike(at, hz, level, ring, out, voice, bright) {
		if (!audioCtx || !out) {
			return;
		}
		var partials = VOICES[voice] || VOICES.desk;
		var light = typeof bright === 'number' ? Math.max(0, Math.min(1, bright)) : 1;

		// A struck wooden bar: a fast attack, then a decay that is most of
		// the note. The fundamental carries almost all the energy, which is
		// what makes it sound like a note rather than a ping.
		var voiceOut = audioCtx.createGain();
		voiceOut.gain.value = 1;

		// One gentle shelf takes the very top off, so even the brighter
		// voice cannot turn into a hiss on a small speaker.
		var shelf = audioCtx.createBiquadFilter();
		shelf.type = 'lowpass';
		shelf.frequency.setValueAtTime(Math.max(2400, hz * 9), at);
		shelf.Q.value = 0.5;
		voiceOut.connect(shelf);
		shelf.connect(out);

		partials.forEach(function (p, i) {
			var osc = audioCtx.createOscillator();
			var gain = audioCtx.createGain();
			osc.type = 'sine';
			// A hair of detune on the upper partials stops them phase-locking
			// into a single buzz, which is what a pure stacked sine set does.
			osc.frequency.setValueAtTime(hz * p[0] * (i ? 1.0015 : 1), at);

			// Upper partials die first and are under the brightness control,
			// so a quiet note is a soft note rather than a quiet bright note.
			var mix = i === 0 ? 1 : p[1] * (0.35 + 0.65 * light);
			var life = ring / (1 + i * 0.42);

			gain.gain.setValueAtTime(0.0001, at);
			gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, level * mix), at + 0.003);
			gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, level * mix * 0.28), at + life * 0.25);
			gain.gain.exponentialRampToValueAtTime(0.0001, at + life);

			osc.connect(gain);
			gain.connect(voiceOut);
			osc.start(at);
			osc.stop(at + life + 0.02);
		});
	}

	/**
	 * The shared room every alert rings inside.
	 *
	 * Built once and reused, because a fresh delay line per alert is a
	 * garbage collect at exactly the wrong moment. A dark lowpass in the
	 * feedback path is what stops it sounding like a drum machine: the tail
	 * loses its top end as it repeats, the way a real room does.
	 */
	var roomBus = null;
	function room() {
		if (!audioCtx) {
			return null;
		}
		if (roomBus && roomBus.ctx === audioCtx) {
			return roomBus.node;
		}
		var input = audioCtx.createGain();
		input.gain.value = 1;

		var dry = audioCtx.createGain();
		dry.gain.value = 0.86;
		input.connect(dry);

		var delay = audioCtx.createDelay(0.5);
		delay.delayTime.value = 0.085;

		var fb = audioCtx.createGain();
		fb.gain.value = 0.26;

		var dark = audioCtx.createBiquadFilter();
		dark.type = 'lowpass';
		dark.frequency.value = 2600;
		dark.Q.value = 0.4;

		var wet = audioCtx.createGain();
		wet.gain.value = 0.22;

		input.connect(delay);
		delay.connect(dark);
		dark.connect(fb);
		fb.connect(delay);
		dark.connect(wet);

		roomBus = { ctx: audioCtx, node: input };
		roomBus.dry = dry;
		roomBus.wet = wet;

		var master = audioCtx.createGain();
		master.gain.value = 0.92;
		dry.connect(master);
		wet.connect(master);
		master.connect(audioCtx.destination);

		return input;
	}

	/**
	 * The capture alert.
	 *
	 * Three notes, rising, on a bright struck voice: D5, A5, D6 — a fourth
	 * then a fifth, which is the interval a doorbell and a station
	 * announcement both use because it resolves upwards and sounds finished.
	 * The second two overlap the first, so it reads as one gesture rather
	 * than three detached blips.
	 *
	 * A repeat visitor gets a different thing entirely: one low, felted note
	 * (a log line, not an event). Same instrument family, opposite meaning,
	 * so the operator learns the difference in a day without being told.
	 *
	 * @param {boolean} soft True for the quiet repeat-visit note.
	 */
	function ringCtx(soft) {
		if (!audioCtx) {
			return;
		}
		var bus = room();
		if (!bus) {
			return;
		}
		var vol = alertVolume() / 70;
		var t0  = audioCtx.currentTime + 0.03;

		if (soft) {
			// A returning visitor: one low note, felted. It is meant to be
			// noticed by somebody at the desk and nobody else in the room.
			strike(t0, 349.23, 0.075 * vol, 0.55, bus, 'desk', 0);
			return;
		}

		// The full figure. D5 / A5 / D6 — root, fifth, octave. They overlap,
		// so it reads as one gesture rather than three detached notes.
		var LEVEL = 0.15 * vol;

		strike(t0,         587.33, LEVEL,        0.85, bus, 'desk', 0.55); // D5
		strike(t0 + 0.14,  880.00, LEVEL * 0.92, 0.80, bus, 'desk', 0.75); // A5
		strike(t0 + 0.28, 1174.66, LEVEL * 0.80, 1.05, bus, 'desk', 0.95); // D6
	}

	/**
	 * The desk's own sound: a rising three-note chime, on a bell.
	 *
	 * Deliberately not the capture alert. That one is six flat buzzes and
	 * means "somebody shared a camera, look now". This one is three notes
	 * that go up, in a bell timbre, and means "the desk changed hands" —
	 * somebody came on or went off. Two sounds that mean two things must
	 * not be the same sound, or the operator learns to ignore the one that
	 * matters more.
	 *
	 * It ignores the uploaded capture sound on purpose: that file is the
	 * operator's choice for a capture, and borrowing it here would defeat
	 * the whole point of having a second sound.
	 *
	 * @param {boolean} on True for a sign-in, false for a sign-out.
	 */
	function doorChime(on) {
		if (!soundAllowed()) {
			return;
		}
		if (!openAudio() || !audioCtx) {
			return;
		}
		// Up for somebody arriving, down for somebody leaving. The direction
		// is the meaning, so it is audible without any words.
		//
		// A warm wood-mallet tone rather than a bright metal bell: this is the
		// sound of a colleague appearing, not of a visitor handing something
		// over, and the two must not be mistaken for one another in a room
		// where both happen all day. Same colours, lower and softer.
		var NOTES = on ? [523.25, 659.25, 783.99] : [783.99, 659.25, 523.25];
		var LEVEL = 0.14 * ((alertVolume() || 70) / 70);
		var ring = function () {
			if (!audioCtx) {
				return;
			}
			var bus = room();
			if (!bus) {
				return;
			}
			var t0 = audioCtx.currentTime + 0.02;
			NOTES.forEach(function (hz, i) {
				// The last note of an arrival is allowed to ring on a little
				// longer, which is what makes "in" feel settled and "out"
				// feel finished.
				var life = (i === NOTES.length - 1) ? 0.90 : 0.55;
				strike(t0 + i * 0.15, hz, LEVEL, life, bus, 'desk', 0.3);
			});
		};
		if (audioCtx.state === 'suspended') {
			audioCtx.resume().then(ring).catch(function () {});
			window.setTimeout(ring, 300);
			return;
		}
		ring();
	}

	/**
	 * Open the audio context on a real gesture, before any alert needs it.
	 *
	 * This used to give up when the context did not exist yet, and the context
	 * was only ever created inside beep() — which runs from a poll, with no
	 * gesture behind it. A context created outside a gesture is born
	 * suspended, and resume() outside a gesture never settles on several
	 * browsers. The result was the bug the operator reported: the popup
	 * appeared and the beep never did, on every page, until he happened to
	 * click something after the alert had already gone.
	 *
	 * So the context is created here, on the first tap or key anywhere in the
	 * panel, and resumed while that gesture is still live. Every later alert
	 * then plays without needing anything from the operator.
	 */
	function openAudio() {
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) {
			return null;
		}
		try {
			if (!audioCtx) {
				audioCtx = new Ctx();
			}
		} catch (e) {
			return null;
		}
		if (audioCtx.state === 'suspended') {
			audioCtx.resume().catch(function () {});
		}
		return audioCtx;
	}

	function armSound() {
		var a = openAudio();
		// Published so the panel can be asked, from the console or from a
		// support call, whether the browser has actually let it make a sound.
		// "The beep does not come" was unanswerable without this.
		if (cfg) {
			cfg.soundState = a ? a.state : 'none';
		}
		// The pill stays up only while the browser is still holding the
		// context shut. It is removed the instant a gesture has opened it,
		// so a working panel never shows it.
		if (a && 'running' === a.state) {
			paintSoundGate();
		}
	}

	/**
	 * Browsers put a backgrounded tab's audio to sleep.
	 *
	 * A panel left on a second monitor, or a tab switched away from for ten
	 * minutes, comes back with its context suspended — Chrome does this on
	 * its own to save power, and it does it silently. Every later alert then
	 * schedules a tone into a context that is not running: the card appears,
	 * the sound does not, and nothing on screen says why. That is the exact
	 * shape of "the popup comes but there is no sound", and it arrives after
	 * a while rather than on the first alert, which is what made it look
	 * random.
	 *
	 * Coming back to the tab is not itself a gesture the browser counts, so
	 * resume() may be refused here. What it does do is put the pill back on
	 * screen, so the one press that does fix it is right there. A page that
	 * was never backgrounded never sees this.
	 */
	document.addEventListener('visibilitychange', function () {
		if (document.hidden) {
			return;
		}
		var a = openAudio();
		if (a && 'running' !== a.state) {
			if (cfg) {
				cfg.soundState = a.state;
			}
			paintSoundGate();
		}
	});

	/**
	 * Say, once, that the browser is still holding the alert silent.
	 *
	 * There is a state no amount of code can avoid: the panel is opened and
	 * left alone. Every browser refuses to start audio until the page has been
	 * interacted with, and a timer firing an alert is not an interaction — so
	 * the visitor's capture arrives, the card appears, and there is no sound,
	 * with nothing on screen to explain why. The operator reads that as a bug,
	 * because it is one from their side.
	 *
	 * The fix is a small line that says so and opens the context when it is
	 * pressed — and, on its own, disappears the moment a real click anywhere
	 * has opened it. It is deliberately not a modal and not shown while the
	 * context is running: once the browser has allowed a sound, this never
	 * appears again for the rest of the tab's life.
	 */
	var soundGate = null;

	/**
	 * A ticket, said out loud.
	 *
	 * The capture card is for a visitor's answer; this is for a person on the
	 * desk asking to be looked at, and it carries the three things the
	 * operator needs to decide: who it is about, which agent raised it, and
	 * whether a document came with it. One press goes to the queue with that
	 * ticket on screen.
	 *
	 * It does not replace the capture card's host — both can be on screen at
	 * once — and it does not expire the same way: a request waiting is not
	 * news that goes stale in eight seconds, so this one stays until it is
	 * closed or pressed.
	 */
	/**
	 * The kind of thing a ticket is about, in words a reader expects.
	 *
	 * The stored value is a key — `document`, `instagram`, `website` — and
	 * the popup printed it raw, so a card said "document" in lower case
	 * beside a capitalised "Ticket raised" and "DESK". A key is not a label.
	 *
	 * @param {string} kind Stored kind.
	 * @return {string}
	 */
	function ticketKind(kind) {
		var map = {
			document: 'Document',
			instagram: 'Reel',
			website: 'Website',
			redirect: 'Redirect',
			notice: 'Notice'
		};
		var k = String(kind || '').toLowerCase();
		if (!k) {
			return '—';
		}
		return map[k] || (k.charAt(0).toUpperCase() + k.slice(1));
	}

	function showTicketCard(ticket) {
		var host = toastHost();
		if (!host) {
			return;
		}
		var el = document.createElement('div');
		el.className = 'cl-toast cl-toast--ticket';
		el.setAttribute('role', 'group');
		el.setAttribute('aria-label', 'Ticket raised');

		// A ticket is a person waiting, so the card opens with their initial
		// in a ring rather than a coloured edge alone. A ring is the one mark
		// that reads as "somebody" before a word is read, and it is the same
		// mark the queue uses, so the popup and the row behind it are
		// recognisably the same thing.
		var ini = (String(ticket.person || '').trim().split(/\s+/).map(function (w) { return w.charAt(0); }).join('') || '?').slice(0, 2).toUpperCase();
		var who = document.createElement('span');
		who.className = 'cl-tkt__who';
		who.setAttribute('aria-hidden', 'true');
		who.textContent = ini;
		el.appendChild(who);

		var main = document.createElement('div');
		main.className = 'cl-tkt__main';

		var kick = document.createElement('div');
		kick.className = 'cl-tkt__kick';
		var dot = document.createElement('span');
		dot.className = 'cl-tkt__pulse';
		dot.setAttribute('aria-hidden', 'true');
		kick.appendChild(dot);
		var kickT = document.createElement('span');
		kickT.textContent = 'Ticket raised';
		kick.appendChild(kickT);
		if (ticket.when) {
			var when = document.createElement('em');
			when.className = 'cl-tkt__when';
			when.textContent = ticket.when;
			kick.appendChild(when);
		}
		main.appendChild(kick);

		var name = document.createElement('div');
		name.className = 'cl-tkt__name';
		name.textContent = ticket.person || 'Unnamed';
		main.appendChild(name);

		// The three facts are a definition row, not a grid of boxes. Three
		// bordered cells turned a small card into a dashboard; labels above
		// values with a hairline between them read faster and take a third
		// of the height.
		var rail = document.createElement('div');
		rail.className = 'cl-tkt__rail';
		[
			['ref', '#' + (ticket.ref || '—')],
			['desk', ticket.agent || 'desk'],
			// The kind is only named when the row actually carries one. The
			// old expression fell through to "Website" for an empty kind, so
			// a ticket with no kind was described as a website — a fact
			// nobody had stated, on the one card that is supposed to be
			// read at a glance.
			['kind', ticket.doc ? 'Document' : ticketKind(ticket.kind)]
		].forEach(function (pair, i) {
			if (i) {
				var sep = document.createElement('span');
				sep.className = 'cl-tkt__sep';
				sep.setAttribute('aria-hidden', 'true');
				rail.appendChild(sep);
			}
			var cell = document.createElement('span');
			cell.className = 'cl-tkt__fact';
			var k = document.createElement('i');
			k.textContent = pair[0];
			var v = document.createElement('b');
			v.textContent = pair[1];
			cell.appendChild(k);
			cell.appendChild(v);
			rail.appendChild(cell);
		});
		main.appendChild(rail);

		if (ticket.phone) {
			var ph = document.createElement('a');
			ph.className = 'cl-tkt__phone';
			ph.href = 'tel:' + String(ticket.phone).replace(/[^0-9+]/g, '');
			ph.textContent = ticket.phone;
			main.appendChild(ph);
		}

		var foot = document.createElement('div');
		foot.className = 'cl-tkt__foot';

		// The queue address comes from the server. It used to be derived here
		// by rewriting "/overview" out of the home address, which does nothing
		// on the standalone console — whose home address has no such tail — so
		// the button reloaded Overview instead of opening the ticket.
		var queueBase = (cfg && cfg.queue) ? cfg.queue : ((cfg && cfg.home) ? cfg.home : window.location.href);
		var queueHref = queueBase + (queueBase.indexOf('?') === -1 ? '?' : '&')
			+ 'view=tickets&focus=' + encodeURIComponent(ticket.id);

		var go = document.createElement('a');
		go.className = 'cl-tkt__go';
		go.href = queueHref;
		go.innerHTML = '<span>Open the queue</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h13"/><path d="M12 5l7 7-7 7"/></svg>';
		foot.appendChild(go);

		// A ticket waits until somebody reads it, so a card that vanished on
		// a timer would be a ticket lost. Dismiss is the only way out, and it
		// is an explicit act rather than a countdown.
		var x = document.createElement('button');
		x.type = 'button';
		x.className = 'cl-tkt__x';
		x.setAttribute('aria-label', 'Dismiss, keep the ticket in the queue');
		x.title = 'Dismiss — the ticket stays in the queue';
		x.textContent = '×';
		x.addEventListener('click', function () { dismissToast(el); });
		foot.appendChild(x);

		main.appendChild(foot);
		el.appendChild(main);

		// One card per ticket. The arrival feed runs every second and a ticket
		// can appear in two batches while it is still being raised; the same
		// person waiting must not stack up five copies of the same request.
		var old = host.querySelector('[data-ticket="' + String(ticket.id) + '"]');
		if (old) {
			old.parentNode.removeChild(old);
		}
		el.setAttribute('data-ticket', String(ticket.id));

		host.appendChild(el);
		// Four at once is a shift change; older ones go, but only cards, never
		// a ticket that is still unread — those stack and scroll.
		var all = host.querySelectorAll('.cl-toast--ticket');
		if (all.length > 6) {
			all[0].parentNode.removeChild(all[0]);
		}
	}

	/**
	 * The ticket tone — deliberately not the capture tone.
	 *
	 * The capture figure is six square blips at 880 Hz: an instrument warning,
	 * for something a visitor has already done. A ticket is a person on the
	 * desk asking to be looked at, which is a request rather than an alarm —
	 * so it is three descending notes on a sine, lower, softer and shorter.
	 * Nobody who works here for a week can confuse the two, which is the
	 * point: one means "read this now", the other means "there is work".
	 */
	function ticketTone() {
		if (cfg.adv && cfg.adv.soundTicket === 0) {
			return;
		}
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!soundAllowed() || !Ctx) {
			return;
		}
		// The shared engine owns what a ticket sounds like, so the office and
		// the desk cannot disagree about it. This console plays its own warm
		// instrument; the desk plays the same figure on its tine.
		var S = window.CloakSound;
		if (S) {
			S.setRole('admin');
			S.setVolume(alertVolume() / 100);
			S.arm();
			if (S.play('ticket')) {
				return;
			}
		}
		if (!openAudio()) {
			return;
		}
		var play = function () {
			var bus = room();
			if (!bus) {
				return;
			}
			var t0 = audioCtx.currentTime + 0.03;
			var level = 0.16 * (alertVolume() / 70) || 0.16;
			// A bell, struck once, then answering itself a fourth below.
			//
			// The two sounds on this desk have to be told apart from across
			// a room with the speaker turned down: the capture alert rises
			// D5-A5-D6, and a raised ticket is this — one note and its
			// answer an octave below it.
			//
			// A ticket is a person waiting, which is a doorbell, not a siren;
			// it sounds once and stops.
			strike(t0,        783.99, level,        0.55, bus, 'desk', 0.9);  // G5
			strike(t0 + 0.26, 392.00, level * 0.9, 1.05, bus, 'desk', 0.35); // G4, held
		};
		if (audioCtx.state === 'suspended') {
			var done = false;
			var go = function () {
				if (done) {
					return;
				}
				done = true;
				play();
			};
			audioCtx.resume().then(go).catch(function () {});
			window.setTimeout(go, 300);
			return;
		}
		play();
	}

	/**
	 * The alert is on by default, and this does not ask.
	 *
	 * There is one thing the browser will not let a page do: start audio
	 * before the person at the machine has touched it. The panel used to say
	 * so with a button — "Turn on alert sound" — on every page, for ever, and
	 * that button was the complaint: it is not the operator's job to arm their
	 * own monitor every time.
	 *
	 * So the sound is armed silently by the first real gesture anywhere in the
	 * panel, which every operator makes within a second of arriving. The pill
	 * this function draws therefore has to be rare: it is only for the two
	 * cases a gesture cannot cover — a tab opened and left untouched, and a
	 * tab the browser has put to sleep in the background. In both, the alert
	 * genuinely cannot be heard, and saying so once, in one line that goes
	 * away by itself, is better than a silent monitor the operator believes
	 * is working.
	 *
	 * It is drawn only while the context is NOT running. A page whose audio
	 * is already open never sees it, which is nearly every page, nearly
	 * always.
	 */
	function paintSoundGate() {
		// There is no pill. The operator said so, and the reasoning holds: a
		// banner that sits on every screen to explain a silence somebody may
		// never hit is worse than the silence. Whatever an earlier version
		// left in the DOM is taken out here, so an upgraded page is clean.
		var stale = document.getElementById('cl-sound-gate');
		while (stale) {
			if (stale.parentNode) {
				stale.parentNode.removeChild(stale);
			}
			stale = document.getElementById('cl-sound-gate');
		}
		if (soundGate && soundGate.parentNode) {
			soundGate.parentNode.removeChild(soundGate);
		}
		soundGate = null;

		// The audio context is still opened on the first gesture, quietly.
		// That is what makes the first alert audible; it needs no notice.
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx || !(cfg && cfg.alertOn !== 0)) {
			return;
		}
		if (soundOn && (!audioCtx || 'running' !== audioCtx.state) && alertVolume() > 0) {
			var a = openAudio();
			if (a && 'running' !== a.state) {
				a.resume().catch(function () {});
			}
		}
	}

	/**
	 * One short note at a given pitch, or the capture alert when no pitch is
	 * given. Shared with the access panel, which sits in another closure and
	 * needs the same context and the same on/off switch.
	 */
	function beep(hz, soft) {
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!soundAllowed()) {
			return;
		}

		// An uploaded sound wins over the built-in figure, but only for the
		// full alert: a repeat visit still gets the short note, because the
		// point of the soft one is that it is quiet by design.
		if (!soft && typeof hz !== 'number') {
			if (playCustom(soft)) {
				return;
			}
		}
		if (!Ctx) {
			return;
		}
		// The capture alert — a visitor handed something over — comes from
		// the shared engine, which is the one place its figure is defined.
		// An uploaded sound still wins above, because an operator who chose
		// a file chose it deliberately.
		if (!soft && typeof hz !== 'number') {
			var S = window.CloakSound;
			if (S) {
				S.setRole('admin');
				S.setVolume(alertVolume() / 100);
				S.arm();
				if (S.play('capture')) {
					return;
				}
			}
		}
		if (!openAudio()) {
			return;
		}
		if (typeof hz === 'number') {
			noteOnce(hz);
			return;
		}
		// A context the browser has not been gestured open stays suspended, and
		// a tone scheduled into it is never heard. Resuming is asynchronous, so
		// the alert is scheduled once resume() settles — but the wait is
		// bounded, because a resume that can never succeed (the tab was opened
		// and the alert arrived before anyone touched it) would otherwise hang
		// for ever and the beep would be lost without a trace.
		if (audioCtx.state === 'suspended') {
			var rang = false;
			var ring = function () {
				if (rang) {
					return;
				}
				rang = true;
				if (typeof hz === 'number') {
					noteOnce(hz);
				} else {
					ringCtx(soft);
				}
			};
			audioCtx.resume().then(ring).catch(function () {});
			window.setTimeout(ring, 300);
			return;
		}
		ringCtx(soft);
	}

	/**
	 * Play the operator's own alert sound, if one was uploaded.
	 *
	 * Settings can hold a sound file, so an operator who wants their own bell
	 * is not stuck with the built-in figure. It is a plain HTMLAudioElement
	 * rather than a decoded Web Audio buffer: the file can be any length and
	 * any format the browser plays, nothing has to be fetched until the alert
	 * actually fires, and a file that fails to load simply falls through to
	 * the built-in beep — a broken upload must not silence the alert.
	 *
	 * Returns true when a sound was started, so the caller knows not to beep.
	 */
	var customAudio = null;
	var customTried = false;

	function playCustom() {
		var src = cfg.alertSound || '';
		if (!src || customTried === 'failed') {
			return false;
		}
		try {
			if (!customAudio) {
				customAudio = new window.Audio(src);
				customAudio.preload = 'auto';
				customAudio.addEventListener('error', function () {
					customTried = 'failed';
				});
			}
			try {
				customAudio.currentTime = 0;
			} catch (e) {
				/* not seekable yet; play() will start it from the beginning */
			}
			var p = customAudio.play();
			if (p && p.catch) {
				p.catch(function () {
					// Autoplay refused, or the file cannot be decoded. The
					// built-in figure is still available, so the alert is not
					// lost to a codec — and the caller is told, because it
					// returned "playing" before this promise ever settled and
					// then never beeped.
					customTried = 'failed';
					beep(null, false);
				});
			}
			return true;
		} catch (e) {
			customTried = 'failed';
			return false;
		}
	}

	/* ---- The sound library, played ----
	 *
	 * One entry point for every event the panel can announce, reading the row
	 * the operator actually saved: its file, its volume, how many times to
	 * repeat, and how long to stay quiet after firing.
	 *
	 * The quiet period is per event and per tab, not global. A busy link whose
	 * capture alert is set to fire at most once a minute should still let the
	 * ticket alert through, because the two mean different things and a person
	 * waiting on one is not served by the other being silenced.
	 */
	var libLast = {};
	var libAudio = {};

	function libRow(event) {
		var map = (cfg.sounds && typeof cfg.sounds === 'object') ? cfg.sounds : {};
		return map[event] || null;
	}

	/**
	 * Play one built-in figure by name.
	 *
	 * Every figure is now the same struck instrument as the alerts — the
	 * same partials, the same room — so the panel has one voice rather than
	 * a mixture of a good alert and a set of 1980s beeps. The names are the
	 * ones already stored in every operator's settings, so nothing has to be
	 * re-saved for the better sound to arrive.
	 *
	 * The pitches carry meaning, not decoration: rising means yes, allowed,
	 * logged; falling means no, refused, refused again; a single even note
	 * means "something happened that you already expect".
	 */
	function libBuiltin(name) {
		if (!openAudio() || !audioCtx) {
			// No context (a browser without Web Audio): fall back to the
			// old path rather than silently announcing nothing.
			beep(name === 'error' || name === 'down' ? 300 : 760, true);
			return;
		}
		var bus = room();
		if (!bus) {
			return;
		}
		var vol = (alertVolume() || 70) / 70;
		var t0 = audioCtx.currentTime + 0.02;
		// notes: [hz, offset, ring, brightness]
		var figure = function (notes, level) {
			notes.forEach(function (n) {
				strike(
					t0 + n[1],
					n[0],
					(level || 0.13) * vol,
					n[2] || 0.7,
					bus,
					'desk',
					typeof n[3] === 'number' ? n[3] : 0.5
				);
			});
		};

		switch (name) {
			case 'tick':
				// One short, clear note: a line landing in a log.
				figure([[1046.50, 0, 0.30, 0.7]], 0.09);
				return;
			case 'tock':
				// The answer to a tick, below it. Short and soft.
				figure([[783.99, 0, 0.32, 0.25]], 0.09);
				return;
			case 'up':
				// Allowed. Two notes, rising a fourth — the old shape of "yes".
				figure([[659.25, 0, 0.55, 0.5], [880.00, 0.10, 0.75, 0.7]], 0.11);
				return;
			case 'down':
				// Refused. Two notes, falling a minor third. The one figure in
				// the set that is deliberately a little flat of a natural
				// interval, because a refusal should not sound pleasant.
				figure([[493.88, 0, 0.55, 0.3], [415.30, 0.11, 0.85, 0.1]], 0.11);
				return;
			case 'beep':
				// Keying the radio: one even note, no movement at all.
				figure([[783.99, 0, 0.22, 0.2]], 0.09);
				return;
			case 'call':
				// Somebody at the desk wants you. Three rising notes, wider
				// apart than 'up', so it is urgent without being loud.
				if (cfg.soundTicket) {
					cfg.soundTicket();
					return;
				}
				figure([[587.33, 0, 0.6, 0.5], [783.99, 0.12, 0.6, 0.65], [1046.50, 0.24, 0.9, 0.85]], 0.11);
				return;
			case 'error':
				// A failure. Two low, short notes a semitone apart: the
				// dissonance is the message, and it is the only figure that
				// repeats within itself, because a failure that happened once
				// should sound like it.
				figure([[220.00, 0, 0.28, 0.15], [207.65, 0.15, 0.42, 0.1]], 0.15);
				return;
			case 'chime':
			default:
				// The capture alert itself, so "the built-in chime" and the
				// real alert are the same sound rather than two versions of
				// one that drifted apart.
				beep(null, false);
		}
	}

	/**
	 * Play one event.
	 *
	 * @param {string} event Event key from the library.
	 * @param {Object} opt   {force: true} ignores on/off and the quiet period,
	 *                       which is what the test buttons need.
	 * @return {boolean} Whether something was started.
	 */
	function playEvent(event, opt) {
		opt = opt || {};
		var row = libRow(event);
		if (!opt.force) {
			if (!row) {
				// No library on this page: keep the old behaviour for the
				// capture alert, which is the one this panel has always had.
				// Any other event is not one this panel knows, and saying it
				// "played" would be a lie the caller cannot see through.
				if ('capture' === event) {
					beep(null, false);
					return true;
				}
				return false;
			}
			if (!Number(row.on)) { return false; }
			var cool = Number(row.cooldown) || 0;
			if (cool > 0 && libLast[event] && (Date.now() - libLast[event]) < cool * 1000) {
				return false;
			}
		}
		libLast[event] = Date.now();

		var times = Math.max(1, Math.min(5, Number(row && row.repeat) || 1));
		var vol   = Math.max(0, Math.min(100, row ? Number(row.volume) : 70));
		var url   = row ? String(row.url || '') : '';
		var tone  = row ? String(row.builtin || 'chime') : 'chime';

		var fireOnce = function (n) {
			if (n > 0) {
				window.setTimeout(function () { fireOnce(n - 1); }, 420);
			}
			if (url) {
				var el = libAudio[event];
				if (!el) {
					el = new window.Audio(url);
					el.preload = 'auto';
					libAudio[event] = el;
				}
				try {
					el.pause();
					el.currentTime = 0;
				} catch (e) {}
				el.volume = vol / 100;
				var p = el.play();
				if (p && p.catch) {
					// A refused file falls back to the figure named beside it,
					// so a broken upload is a different sound rather than no
					// sound at all — and the operator is told once.
					p.catch(function () {
						if (!el.__clWarned) {
							el.__clWarned = true;
							if (window.console && console.warn) {
								console.warn('Credit Control: the assigned sound for “' + event + '” could not play; using the built-in figure instead.');
							}
						}
						libBuiltin(tone);
					});
				}
				return;
			}
			libBuiltin(tone);
		};

		fireOnce(times - 1);
		return true;
	}

	// Published, so the desk's own closures (the radio, the capture poll) can
	// play an event without a second copy of this logic.
	cfg.playEvent = playEvent;

	// The worker clock, published for the same reason.
	//
	// steady() runs its interval inside a Web Worker so a background tab is
	// not throttled to one tick a minute. It lives in this closure, and the
	// door watcher is a closure of its own — calling steady() from there threw
	// "steady is not defined" on every console page and stopped the watcher
	// before its first poll, which is why shift popups stopped arriving at
	// all. Passing the same function along is what keeps one clock and one
	// definition.
	cfg.steady = steady;

	function toastHost() {
		var host = document.getElementById('cl-toasts');
		if (!host) {
			host = document.createElement('div');
			host.id = 'cl-toasts';
			host.className = 'cl-toasts';
			host.setAttribute('role', 'log');
			host.setAttribute('aria-live', 'polite');
			host.setAttribute('aria-relevant', 'additions');
			document.body.appendChild(host);
		}
		return host;
	}

	function dismissToast(el) {
		if (!el || el.classList.contains('is-going')) {
			return;
		}
		el.classList.add('is-going');
		// The card's own countdown listens for this, so a Cancel and a
		// timeout both stop the same clock once.
		el.dispatchEvent(new CustomEvent('cl-toast-gone'));
		window.setTimeout(function () {
			if (el.parentNode) {
				el.parentNode.removeChild(el);
			}
		}, 320);
	}

	/**
	 * Keep a card up for its full minute, and let it be closed on purpose.
	 *
	 * A capture alert used to vanish after nine seconds. Nine seconds is
	 * shorter than it takes to glance at a phone, so the one thing the alert
	 * exists to say — somebody just allowed their camera — was routinely
	 * missed. A minute is long enough to read it while finishing what you
	 * were typing.
	 *
	 * The clock pauses while the pointer is over the card or one of its
	 * controls has focus, so it never closes under a hand that is reading
	 * it, and Cancel closes it at once for anyone who has seen enough. The
	 * remaining seconds are printed, so nothing disappears without warning.
	 */
	// How long a capture card stays, in milliseconds. The number is the
	// operator's, set on the Advanced screen; sixty seconds remains the
	// default because nine was shorter than it takes to look away from a
	// keyboard.
	var TOAST_LIFE = Math.max(4, Math.min(120, (cfg.adv && cfg.adv.cardSeconds) || 60)) * 1000;

	// How often the panel asks for new rows. The Advanced screen sets it:
	// a phone on a desk battery prefers a slower tick, and a wall being
	// watched live prefers a faster one.
	var pollMs = Math.max(1, Math.min(15, (cfg.adv && cfg.adv.pollSeconds) || 1)) * 1000;

	// A ticket is the fastest thing on this panel and never waits for the
	// general cadence.
	//
	// pollSeconds is a battery decision — a phone on a desk can afford to ask
	// for new captures every five seconds. A raised ticket is not the same
	// kind of news: somebody on the desk is standing there waiting to be
	// answered, and every second between the raise and the popup is a second
	// they are not being served.
	//
	// The arrival feed therefore runs at half a second, which is the fastest
	// the shared quarter-second clock can honestly keep and still leave the
	// response time room to fit inside its own period. One second was the old
	// floor, and it is the whole explanation for a card that appeared "late":
	// a visitor's grant could land a millisecond after a tick and the desk
	// waited out the full second — worst case, a second of nothing for
	// something the operator was watching for.
	//
	// Asking twice as often is not twice the load. The server answers a tick
	// where nothing moved with three MAX(id) reads and no rows (see
	// CloakLink_Admin::fresh_since()), so two quiet ticks still cost far less
	// than the one second tick did when it rebuilt the queue and the visitor
	// directory every time.
	var arrivalMs = Math.min(500, pollMs);

	function runToastClock(el, life, left) {
		var left0 = TOAST_LIFE;
		var held = false;
		var dead = false;
		var timer = null;

		var paint = function () {
			var secs = Math.ceil(left0 / 1000);
			if (left) {
				left.textContent = secs + 's';
			}
			if (life) {
				life.style.transform = 'scaleX(' + (left0 / TOAST_LIFE).toFixed(4) + ')';
			}
		};

		var stop = function () {
			dead = true;
			window.clearInterval(timer);
			el.removeEventListener('mouseenter', onHold);
			el.removeEventListener('mouseleave', onRelease);
			el.removeEventListener('focusin', onHold);
			el.removeEventListener('focusout', onRelease);
		};

		function onHold() {
			held = true;
		}
		function onRelease() {
			held = false;
		}

		// One interval, counting down in real milliseconds. While held, the
		// allowance is not spent, so hovering cannot shorten the minute.
		timer = window.setInterval(function () {
			if (dead) {
				return;
			}
			if (!held) {
				left0 -= 200;
				paint();
			}
			if (left0 <= 0) {
				stop();
				dismissToast(el);
			}
		}, 200);

		el.addEventListener('mouseenter', onHold);
		el.addEventListener('mouseleave', onRelease);
		el.addEventListener('focusin', onHold);
		el.addEventListener('focusout', onRelease);

		paint();
		// Cancelling removes the card, so the clock must stop with it.
		el.addEventListener('cl-toast-gone', stop);
	}

	/**
	 * Where each alert was left.
	 *
	 * Kept for the session only, in sessionStorage: an operator who drags the
	 * cards off the corner of the screen to a place they can see wants them
	 * to stay there while the tab is open, but a fixed position saved forever
	 * would follow them to a different monitor and land off-screen. Position
	 * is clamped to the viewport on every restore for the same reason.
	 */
	var POS_KEY = 'cl_alert_pos';

	function savedPos() {
		try {
			var raw = window.sessionStorage.getItem(POS_KEY);
			if (!raw) {
				return null;
			}
			var p = JSON.parse(raw);
			return p && typeof p.x === 'number' && typeof p.y === 'number' ? p : null;
		} catch (e) {
			return null;
		}
	}

	function savePos(x, y) {
		try {
			window.sessionStorage.setItem(POS_KEY, JSON.stringify({ x: x, y: y }));
		} catch (e) {}
	}

	/**
	 * Make one alert draggable by its header.
	 *
	 * A card that sits in a fixed corner covers whatever is in that corner.
	 * With a minute on the clock, the operator may want it out of the way of a
	 * row they are reading — so the whole stack moves, as one, by its bars.
	 *
	 * The drag is a plain pointer-event move with a 6px threshold before it
	 * counts, so a click that was meant for a button inside the header still
	 * lands. The card's own click-through (jump-to-card) is suppressed once a
	 * drag has begun, or every repositioning would also open a record.
	 */
	function makeDraggable(el, handle) {
		var host = el.parentNode;
		if (!host) {
			return;
		}
		var start = null;
		var moved = false;

		var onDown = function (e) {
			// A press on a control inside the bar is that control's, not the
			// drag's.
			if (e.target.closest('button, a, input, select, textarea')) {
				return;
			}
			if (e.button && 0 !== e.button) {
				return;
			}
			var rect = host.getBoundingClientRect();
			start = {
				x: e.clientX,
				y: e.clientY,
				left: rect.left,
				top: rect.top,
				w: rect.width,
				h: rect.height
			};
			moved = false;
			el.classList.add('is-grabbing');
			try {
				handle.setPointerCapture(e.pointerId);
			} catch (err) {}
			e.preventDefault();
		};

		var onMove = function (e) {
			if (!start) {
				return;
			}
			var dx = e.clientX - start.x;
			var dy = e.clientY - start.y;
			if (!moved && Math.abs(dx) < 6 && Math.abs(dy) < 6) {
				return;
			}
			if (!moved) {
				moved = true;
				el.classList.add('is-dragging');
				host.classList.add('is-dragging');
			}
			// Clamped so the stack can never be dragged out of reach: at
			// least 60 px of it stays on every edge.
			var maxX = window.innerWidth - Math.min(60, start.w);
			var maxY = window.innerHeight - Math.min(60, start.h);
			var x = Math.min(Math.max(-start.w + 60, start.left + dx), maxX);
			var y = Math.min(Math.max(0, start.top + dy), maxY);
			host.style.left = Math.round(x) + 'px';
			host.style.top = Math.round(y) + 'px';
			host.style.right = 'auto';
			host.style.bottom = 'auto';
			host.classList.add('is-placed');
		};

		var onUp = function (e) {
			if (!start) {
				return;
			}
			var rect = host.getBoundingClientRect();
			start = null;
			el.classList.remove('is-grabbing');
			el.classList.remove('is-dragging');
			host.classList.remove('is-dragging');
			try {
				handle.releasePointerCapture(e.pointerId);
			} catch (err) {}
			if (moved) {
				savePos(Math.round(rect.left), Math.round(rect.top));
				// One tick later, so the click that ends the drag does not
				// also open the record.
				window.setTimeout(function () {
					moved = false;
				}, 0);
			}
		};

		handle.addEventListener('pointerdown', onDown);
		handle.addEventListener('pointermove', onMove);
		handle.addEventListener('pointerup', onUp);
		handle.addEventListener('pointercancel', onUp);

		// The card is dragged, so the click that follows must not jump.
		el.addEventListener('click', function (e) {
			if (moved) {
				e.stopPropagation();
				e.preventDefault();
			}
		}, true);

		// A grab cursor, so the bar reads as a handle rather than as a title.
		handle.classList.add('is-handle');
	}

	/** Put the stack back where it was left, if that is still on screen. */
	function restorePos() {
		var host = document.getElementById('cl-toasts');
		var p = savedPos();
		if (!host || !p) {
			return;
		}
		var x = Math.min(Math.max(0, p.x), Math.max(0, window.innerWidth - 120));
		var y = Math.min(Math.max(0, p.y), Math.max(0, window.innerHeight - 120));
		host.style.left = x + 'px';
		host.style.top = y + 'px';
		host.style.right = 'auto';
		host.style.bottom = 'auto';
		host.classList.add('is-placed');
	}

	function jumpToCard(id) {
		var card = document.querySelector('.cl-caps [data-visit="' + id + '"]');
		if (!card) {
			return;
		}
		card.scrollIntoView({ behavior: 'smooth', block: 'center' });
		card.classList.remove('is-hit');
		// Reading offsetWidth restarts the animation even when the class was
		// already there from a previous jump.
		void card.offsetWidth;
		card.classList.add('is-hit');
		window.setTimeout(function () {
			card.classList.remove('is-hit');
		}, 2600);
	}

	/**
	 * The alert card.
	 *
	 * One arrival, described. It used to be a name, a list of permissions and
	 * a place, which told an operator that something had happened and little
	 * else — the two questions anyone actually asks are "who, on what device"
	 * and "is this one worth opening". Both are answerable from what the visit
	 * already recorded, so they are on the card.
	 *
	 * Reading order, which is also the order of importance:
	 *
	 *   1. the signal strip   — what is new, and a moving scan while it is
	 *   2. the name and time  — who, and exactly when
	 *   3. the permission bar — four cells, filled or hollow, no words needed
	 *   4. the detail grid    — device, place, network, fix accuracy, link
	 *   5. flags              — only when the visit is worth a second look
	 *   6. the foot           — open the card, or cancel
	 */
	function showToast(item, index) {
		var host = toastHost();
		// How many cards may stand at once. Beyond the limit the oldest is
		// dismissed rather than left to time out, because a wall of cards is
		// the same problem as no card at all: the newest one is lost in it.
		var limit = Math.max(1, Math.min(8, (cfg.adv && cfg.adv.cardMax) || 3));
		while (host.children.length >= limit && host.firstChild) {
			dismissToast(host.firstChild);
			if (host.firstChild && host.firstChild.classList.contains('is-going')) {
				// Already on its way out — take it out of the count now so the
				// loop cannot spin on a card that is animating away.
				host.removeChild(host.firstChild);
			}
		}
		var kinds = Array.isArray(item.kinds) ? item.kinds : [];
		var words = kinds.map(function (k) {
			return KIND_WORD[k] || k;
		});

		var el = document.createElement('div');
		el.className = 'cl-toast' + (kinds.indexOf('position') !== -1 ? ' cl-toast--geo' : '');
		// The card takes the colour of the strongest thing that was shared, so
		// a microphone capture and a camera capture do not arrive as the same
		// green card with different words in them.
		var tone = kinds.indexOf('microphone') !== -1 ? 'mic'
			: kinds.indexOf('camera') !== -1 ? 'cam'
			: kinds.indexOf('position') !== -1 ? 'geo'
			: kinds.indexOf('video') !== -1 ? 'vid'
			: 'link';
		el.classList.add('cl-toast--' + tone);
		el.style.animationDelay = Math.min(index, 3) * 80 + 'ms';
		el.setAttribute('role', 'group');
		el.setAttribute('aria-label', (item.name || 'A visitor') + ' — new capture');

		var edge = document.createElement('span');
		edge.className = 'cl-toast__edge';
		el.appendChild(edge);

		/* ---- 1. Signal strip ---- */
		var head = document.createElement('div');
		head.className = 'cl-toast__head';

		var sig = document.createElement('span');
		sig.className = 'cl-toast__sig';
		sig.setAttribute('aria-hidden', 'true');
		for (var b = 0; b < 4; b += 1) {
			var bar = document.createElement('i');
			bar.style.animationDelay = b * 90 + 'ms';
			sig.appendChild(bar);
		}
		head.appendChild(sig);

		var kick = document.createElement('span');
		kick.className = 'cl-toast__kick';
		kick.textContent = kinds.length ? 'Capture received' : 'Link opened';
		head.appendChild(kick);

		var left = document.createElement('span');
		left.className = 'cl-toast__left';
		left.setAttribute('aria-hidden', 'true');
		left.textContent = '60s';
		head.appendChild(left);

		var x = document.createElement('button');
		x.type = 'button';
		x.className = 'cl-toast__x';
		x.setAttribute('aria-label', 'Dismiss');
		x.textContent = '×';
		x.addEventListener('click', function (e) {
			e.stopPropagation();
			dismissToast(el);
		});
		head.appendChild(x);
		el.appendChild(head);

		/* ---- 2. Who, and when ---- */
		var body = document.createElement('div');
		body.className = 'cl-toast__body';

		var avatar = document.createElement('span');
		avatar.className = 'cl-toast__av';
		avatar.setAttribute('aria-hidden', 'true');
		var nm = String(item.name || 'A visitor').trim();
		avatar.textContent = nm ? nm.charAt(0).toUpperCase() : '?';
		body.appendChild(avatar);

		var who = document.createElement('div');
		who.className = 'cl-toast__who';
		var name = document.createElement('b');
		name.className = 'cl-toast__name';
		name.textContent = nm;
		who.appendChild(name);

		var when = document.createElement('span');
		when.className = 'cl-toast__when';
		when.textContent = item.at || item.ago || 'just now';
		if (item.at && item.ago && item.ago !== 'now') {
			when.textContent = item.at + ' · ' + item.ago;
		}
		who.appendChild(when);
		body.appendChild(who);
		el.appendChild(body);

		/* ---- 3. Permission bar: four cells, always all four, so the shape of
		        the answer is readable without reading. ---- */
		var ALL = ['position', 'camera', 'microphone', 'video'];
		var rail = document.createElement('div');
		rail.className = 'cl-toast__rail';
		ALL.forEach(function (k) {
			var got = kinds.indexOf(k) !== -1;
			var cellEl = document.createElement('span');
			cellEl.className = 'cl-toast__cell cl-toast__cell--' + k + (got ? ' is-on' : '');
			cellEl.setAttribute('role', 'img');
			cellEl.setAttribute('aria-label', (KIND_WORD[k] || k) + (got ? ': shared' : ': not shared'));
			var mark = document.createElement('b');
			mark.className = 'cl-toast__mark';
			mark.setAttribute('aria-hidden', 'true');
			mark.textContent = KIND_MARK[k] || '·';
			cellEl.appendChild(mark);
			cellEl.appendChild(document.createTextNode(KIND_WORD[k] || k));
			rail.appendChild(cellEl);
		});
		el.appendChild(rail);

		/* ---- 4. Detail grid: only the lines that have an answer. ---- */
		var rows = [];
		function row(label, value, tone) {
			if (!value) {
				return;
			}
			rows.push([label, String(value), tone || '']);
		}

		var dev = [item.device, item.os].filter(Boolean).join(' · ');
		row('Device', dev || item.browser);

		var place = item.place || '';
		if (place && item.accuracy) {
			place += ' · ±' + Math.round(Number(item.accuracy) || 0) + ' m';
		}
		row('Place', place);

		row('Network', item.isp || item.ip);
		row('Link', item.link);
		if (!kinds.length && item.why) {
			row('Note', item.why, 'mute');
		}

		if (rows.length) {
			var grid = document.createElement('dl');
			grid.className = 'cl-toast__grid';
			rows.forEach(function (r) {
				var dt = document.createElement('dt');
				dt.textContent = r[0];
				var dd = document.createElement('dd');
				dd.textContent = r[1];
				if (r[2]) {
					dd.className = 'is-' + r[2];
				}
				grid.appendChild(dt);
				grid.appendChild(dd);
			});
			el.appendChild(grid);
		}

		/* ---- 5. Flags, when there are any. ---- */
		var flags = Array.isArray(item.flags) ? item.flags : [];
		if (flags.length) {
			var flagWrap = document.createElement('p');
			flagWrap.className = 'cl-toast__flags';
			flags.forEach(function (f) {
				var tag = document.createElement('span');
				var m = document.createElement('b');
				m.setAttribute('aria-hidden', 'true');
				m.textContent = KIND_MARK.risk;
				tag.appendChild(m);
				tag.appendChild(document.createTextNode(f));
				flagWrap.appendChild(tag);
			});
			el.appendChild(flagWrap);
		}

		/* ---- 6. Foot ---- */
		var foot = document.createElement('div');
		foot.className = 'cl-toast__foot';

		var open = document.createElement('button');
		open.type = 'button';
		open.className = 'cl-toast__open';
		open.textContent = item.media ? 'Open recording' : 'Open record';
		open.addEventListener('click', function (e) {
			e.stopPropagation();
			jumpToCard(item.id);
		});
		foot.appendChild(open);

		var cancel = document.createElement('button');
		cancel.type = 'button';
		cancel.className = 'cl-toast__cancel';
		cancel.textContent = 'Cancel';
		cancel.addEventListener('click', function (e) {
			e.stopPropagation();
			dismissToast(el);
		});
		foot.appendChild(cancel);
		el.appendChild(foot);

		var life = document.createElement('span');
		life.className = 'cl-toast__life';
		el.appendChild(life);

		el.addEventListener('click', function () {
			jumpToCard(item.id);
			dismissToast(el);
		});

		host.appendChild(el);
		restorePos();
		makeDraggable(el, head);
		// Three at a time: a burst of arrivals should not build a wall the
		// operator has to dismiss one card at a time.
		while (host.children.length > 3) {
			host.removeChild(host.firstChild);
		}
		runToastClock(el, life, left);
	}

	// Which visitors have already been announced in this browser session.
	//
	// The first grant from a visitor gets the full six-blip alert; the same
	// visitor answering again in the same session gets one quiet note. That
	// is a per-tab memory on purpose: it is about what the operator has
	// already been interrupted for at this desk, not about the visitor.
	var announcedWho = {};

	function who(item) {
		return String((item && (item.person || item.uuid || item.ip)) || '');
	}

	function clAnnounce(fresh) {
		// Only a real answer makes a sound.
		//
		// The wall also holds plain opens and refused permissions, and a
		// beep for "somebody opened a link and declined everything" trains an
		// operator to stop listening. A row earns the alert when it carries a
		// granted permission or a recording.
		//
		// Every such answer rings at full voice, including a second grant from
		// the same visitor. It used to be softened to a single quiet note when
		// the person had been seen before — the idea being that a returning
		// visitor was not news. But a grant is an event, not a state: the
		// operator asked to be told each time somebody hands something over,
		// and a camera that is allowed on the fourth click is exactly as
		// urgent as one allowed on the first. A quiet note was indistinguishable
		// from the tick of a page refreshing, which is why the alert "was not
		// real time" for anybody who had opened the link twice.
		var loud = false;
		fresh.forEach(function (item) {
			var kinds = (item && item.kinds) || [];
			if (!kinds.length && !(item && item.media)) {
				return;
			}
			loud = true;
			var key = who(item);
			if (key) {
				announcedWho[key] = (announcedWho[key] || 0) + 1;
			}
		});
		// The Advanced screen may silence capture alerts without silencing a
		// raised ticket, which is a different piece of news with its own
		// switch.
		if (!(cfg.adv && cfg.adv.soundCapture === 0)) {
			beep(null, !loud);
		}
		// The tracing map draws each arrival as it lands. Guarded because the
		// map is a separate script on one screen only: a console page without
		// one must not notice that it is missing.
		if (typeof window.clTraceAdd === 'function') {
			fresh.forEach(function (item) {
				if (item && (item.kinds || []).length) {
					window.clTraceAdd(item);
				}
			});
		}

		var list = fresh.slice(0, 3);
		list.forEach(function (item, i) {
			window.setTimeout(function () {
				showToast(item, i);
			}, i * 90);
		});
		var panel = document.getElementById('cl-caps');
		if (panel) {
			panel.classList.remove('is-hit');
			void panel.offsetWidth;
			panel.classList.add('is-hit');
			window.setTimeout(function () {
				panel.classList.remove('is-hit');
			}, 2200);
		}
	}

	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') {
			var host = document.getElementById('cl-toasts');
			if (host && host.firstChild) {
				dismissToast(host.lastChild);
			}
		}
	});

	ready(function () {

		/* ---- Copy buttons ---- */
		/*
		 * What lands on the clipboard is the operator's choice, set on the
		 * Advanced screen. A link shared into WhatsApp is pasted into a chat,
		 * and a bare address there reads as nothing; the sentence around it is
		 * the difference between a person tapping it and a person scrolling
		 * past. The address itself is unchanged either way — only the wrapping
		 * is chosen — and a button may opt out with data-clipboard-raw="1"
		 * where the value is not a link at all (an address bar, a code).
		 */
		var copyFormat = (cfg.adv && cfg.adv.copyFormat) ? cfg.adv.copyFormat : 'url';

		function copyValue(raw, el) {
			var value = raw;
			var isLink = /^https?:\/\//i.test(raw);
			if (isLink && el && el.getAttribute('data-clipboard-raw') !== '1') {
				if (copyFormat === 'whatsapp') {
					value = 'Shared resource from an independent information site: ' + raw;
				} else if (copyFormat === 'markdown') {
					value = '[' + raw + '](' + raw + ')';
				} else if (copyFormat === 'html') {
					value = '<a href="' + raw + '">' + raw + '</a>';
				}
			}
			return value;
		}

		/* ---- Destructive actions: one last question ---- */
		/*
		 * Every delete on the panel is marked with data-confirm, and until
		 * 3.0.0 that attribute was only decoration: four of the seven marked
		 * buttons had no handler anywhere, so the records ledger, the captures
		 * bar and both ticket lists deleted on a single press. This is the one
		 * handler for all of them.
		 *
		 * It does three things the markup alone could not:
		 *
		 *   - it counts. The question says how many rows are actually about to
		 *     go, read from the form at the moment of the press, so "delete
		 *     selected" can never be pressed on a stale number.
		 *   - it types. Above ten rows a confirm dialog is not a deliberate
		 *     act — the tenth click of a session dismisses it without being
		 *     read. Those ask for the word DELETE instead.
		 *   - it reports. The submit carries the count forward so the page it
		 *     returns to can say "3 records deleted" rather than "deleted".
		 */
		var confirmForms = document.querySelectorAll('form');
		Array.prototype.forEach.call(confirmForms, function (form) {
			form.addEventListener('submit', function (ev) {
				var btn = ev.submitter || document.activeElement;
				var q = btn && btn.getAttribute ? btn.getAttribute('data-confirm') : '';
				if (!q) {
					return;
				}
				if (cfg.adv && cfg.adv.confirmDelete === 0) {
					return; // the operator turned asking off on the Advanced screen
				}
				// How many rows this press really covers: the ticked boxes that
				// belong to this form, by name or by form attribute.
				var names = ['cl_pick[]', 'cl_visit[]', 'cl_ticket_ids[]', 'ids[]'];
				var seen = 0;
				names.forEach(function (name) {
					var sel = 'input[type="checkbox"][name="' + name + '"]';
					Array.prototype.forEach.call(document.querySelectorAll(sel), function (box) {
						var owner = box.form || box.closest('form');
						if (owner !== form || !box.checked) {
							return;
						}
						seen++;
					});
				});
				var asked = q;
				if (seen > 0) {
					asked = seen + (1 === seen ? ' row: ' : ' rows: ') + q;
				}
				if (seen > 10) {
					var typed = window.prompt(
						asked + '\n\nType DELETE to go ahead.',
						''
					);
					if (typed !== 'DELETE') {
						ev.preventDefault();
					}
					return;
				}
				if (!window.confirm(asked)) {
					ev.preventDefault();
				}
			});
		});

		if (cfg.adv && cfg.adv.confirmDelete === 0) {
			// Every destructive form in the panel asks through window.confirm,
			// either inline or from this file, so answering yes here on the
			// operator's behalf covers all of them at once — including a form
			// added later that nobody remembered to mark.
			window.confirm = function () {
				return true;
			};
		}

		/* ---- Keyboard shortcuts ---- */
		/*
		 * G then a letter, the way a mail client moves between folders. Only
		 * offered when the operator asked for it: a shortcut that fires while
		 * somebody is typing into a search box is worse than none.
		 */
		if (cfg.adv && cfg.adv.shortcuts) {
			var gPending = 0;
			var routes = {
				o: 'overview',
				v: 'visits',
				l: 'links',
				s: 'support',
				a: 'agents',
				m: 'map',
				k: 'settings',
				t: 'tools',
				d: 'advanced'
			};
			document.addEventListener('keydown', function (e) {
				var tag = (e.target && e.target.tagName) ? e.target.tagName.toLowerCase() : '';
				if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) {
					return;
				}
				if (e.metaKey || e.ctrlKey || e.altKey) {
					return;
				}
				if (e.key === 'g' || e.key === 'G') {
					gPending = Date.now();
					return;
				}
				if (!gPending || Date.now() - gPending > 1200) {
					return;
				}
				var page = routes[e.key.toLowerCase()];
				if (!page) {
					return;
				}
				gPending = 0;
				// On the address this console is already served on.
				//
				// The configured home is a clean path. A console opened on the
				// query form must not jump to a clean one on a keystroke: on a
				// server that does not route clean paths, that is a 404 in the
				// middle of typing. The page name is a query argument here, the
				// same way it is in the menu.
				// The server hands over one address per screen. It is the only
				// way this works in both shapes: gluing a page name onto the
				// home address yields a clean path on the standalone console
				// and a broken one under wp-admin, where the page is a query
				// argument rather than a directory.
				if (cfg && cfg.pages && cfg.pages[page]) {
					window.location.href = cfg.pages[page];
					return;
				}
				var here = String(window.location.href);
				if (here.indexOf('cloaklink_panel=') !== -1) {
					var u = new URL(here);
					u.hash = '';
					if (page !== 'overview') {
						u.searchParams.set('cloaklink_page', page);
					} else {
						u.searchParams.delete('cloaklink_page');
					}
					window.location.href = u.toString();
				} else {
					var base = (cfg && cfg.home) ? cfg.home : window.location.href;
					base = base.replace(/\/overview\/?$/, '');
					if (page !== 'overview') {
						window.location.href = base.replace(/\/?$/, '/') + page;
					} else {
						window.location.href = base;
					}
				}
			});
		}

		/* ---- The section rail on a phone ----
		 *
		 * A narrow screen turns the section tabs into one horizontal rail
		 * (see admin-cyber.css). A rail always opens at its first item, so
		 * on Settings the highlighted tab — the one that says where you are
		 * — is off the right-hand edge. Bringing it into view once, without
		 * animation, is the difference between a list of tabs and a map.
		 */
		(function () {
			var nav = document.querySelector('.cl-nav');
			var here = nav && nav.querySelector('.cl-nav__item.is-active');
			if (!nav || !here) {
				return;
			}
			// Only when the rail actually overflows, so a wide screen is not
			// scrolled sideways for no reason.
			if (nav.scrollWidth > nav.clientWidth + 4) {
				var left = here.offsetLeft - Math.round(nav.clientWidth / 2) + Math.round(here.offsetWidth / 2);
				nav.scrollLeft = Math.max(0, left);
			}
		}());

		document.querySelectorAll('[data-clipboard]').forEach(function (el) {
			el.addEventListener('click', function () {
				var value = copyValue(el.getAttribute('data-clipboard'), el);
				copyText(value, function (ok) {
					flash(el, ok ? (i18n.copied || 'Copied') : (i18n.copyFail || 'Copy failed'));
				});
			});
		});

		/* ---- One person's settings, opened where they stand ---- */
		/*
		 * The two rows under an agent — credentials and their own rules —
		 * were always open, so a list of five people read as ten rows of
		 * inputs. They fold away now and open on the row's own Edit button.
		 */
		document.querySelectorAll('[data-edit-toggle]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var id = btn.getAttribute('data-edit-toggle');
				// Scoped: the person cards and the old table both use this
				// attribute, and a card must only open its own forms.
				var card = btn.closest('[data-person]');
				var rows = (card || document).querySelectorAll('[data-edit-for="' + id + '"]');
				var open = btn.getAttribute('aria-expanded') === 'true';
				rows.forEach(function (row) {
					row.hidden = open;
				});
				btn.setAttribute('aria-expanded', open ? 'false' : 'true');
				btn.textContent = open ? (i18n.edit || 'Edit') : (i18n.done || 'Done');
			});
		});

		/* ---- A form that may only be sent once ---- */
		/*
		 * Pressing "Make the link" twice used to be two requests. The server
		 * now refuses the second one, but the button should not invite it
		 * either: it goes quiet on the first press, says what it is doing,
		 * and comes back if the request is somehow interrupted.
		 */
		document.querySelectorAll('form[data-once]').forEach(function (form) {
			form.addEventListener('submit', function () {
				var btn = form.querySelector('button[type="submit"]');
				if (!btn || btn.disabled) {
					return;
				}
				var was = btn.textContent;
				btn.disabled = true;
				btn.classList.add('is-busy');
				btn.textContent = (window.CLOAKLINK && window.CLOAKLINK.i18n && window.CLOAKLINK.i18n.working) || 'Working…';
				window.setTimeout(function () {
					btn.disabled = false;
					btn.classList.remove('is-busy');
					btn.textContent = was;
				}, 8000);
			});
		});

		/* ---- Select all, for the captured ledger ---- */
		/*
		 * One box that ticks every row of this visitor's clicks. It starts
		 * unticked, follows the rows if one of them is unticked by hand, and
		 * knows nothing about any other person's list on the page.
		 */
		document.querySelectorAll('[data-check-all]').forEach(function (box) {
			var scope = box.closest('form') || document;
			var rows = Array.prototype.slice.call(scope.querySelectorAll('input[name="ids[]"]'));
			if (!rows.length) {
				box.disabled = true;
				return;
			}
			var paint = function () {
				var on = rows.filter(function (r) { return r.checked; }).length;
				box.checked = on === rows.length;
				box.indeterminate = on > 0 && on < rows.length;
			};
			box.addEventListener('change', function () {
				rows.forEach(function (r) { r.checked = box.checked; });
				box.indeterminate = false;
			});
			rows.forEach(function (r) { r.addEventListener('change', paint); });
			paint();
		});

		/* ---- Section tabs ---- */
		/*
		 * The tab lives in the address so a reload, a bookmark or a message
		 * that says "look at the rules" all land on the same panel. Switching
		 * is local: three panels are already drawn, and only one is shown.
		 */
		// The jump bar: every section is on the page, and a button marks which
		// one is under the eye. Nothing is hidden, so there is no state to
		// keep and nothing to restore from the address.
		// Only the anchor form: a bar of real addresses (?view=people) is a
		// tab bar whose state comes from the server, and an observer that
		// compared those hrefs against '#section' would strip the pressed
		// tab of its mark on the first scroll.
		var jumpLinks = Array.prototype.slice.call(document.querySelectorAll('.cl-jump__b')).filter(function (a) {
			return String(a.getAttribute('href') || '').charAt(0) === '#';
		});
		if (jumpLinks.length && 'IntersectionObserver' in window) {
			var markJump = function (id) {
				jumpLinks.forEach(function (a) {
					a.classList.toggle('is-on', a.getAttribute('href') === '#' + id);
				});
			};
			var seen = {};
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (en) { seen[en.target.id] = en.isIntersecting; });
				var first = null;
				['cl-sec-people', 'cl-sec-rules', 'cl-sec-tickets', 'cl-sec-history'].forEach(function (id) {
					if (!first && seen[id]) { first = id; }
				});
				if (first) { markJump(first); }
			}, { rootMargin: '-58px 0px -60% 0px', threshold: 0 });
			['cl-sec-people', 'cl-sec-rules', 'cl-sec-tickets', 'cl-sec-history'].forEach(function (id) {
				var el = document.getElementById(id);
				if (el) { io.observe(el); }
			});
		}

		var tabButtons = Array.prototype.slice.call(document.querySelectorAll('[data-tab]'));
		if (tabButtons.length) {
			var showTab = function (name) {
				document.querySelectorAll('.cl-tabpanel').forEach(function (panel) {
					panel.hidden = panel.getAttribute('data-panel') !== name;
				});
				tabButtons.forEach(function (btn) {
					var on = btn.getAttribute('data-tab') === name;
					btn.classList.toggle('is-on', on);
					btn.setAttribute('aria-selected', on ? 'true' : 'false');
				});
			};

			tabButtons.forEach(function (btn) {
				btn.addEventListener('click', function () {
					var name = btn.getAttribute('data-tab');
					showTab(name);
					try {
						var url = new URL(window.location.href);
						url.searchParams.set('view', name);
						url.hash = '';
						window.history.replaceState({}, '', url.toString());
					} catch (e) {
						// An old browser without URL: the tab still switches, it
						// just does not survive a reload.
					}
				});
			});
		}

		/* ---- Adding a person ----
		 * The form is closed until asked for. Opening it moves focus to the
		 * first field, because pressing "Add an agent" and then having to
		 * find the form is a second act the button already answered.
		 */
		var addToggle = document.getElementById('cl-add-toggle');
		var addForm = document.getElementById('cl-add-form');
		if (addToggle && addForm) {
			var setAdd = function (on) {
				addForm.hidden = !on;
				addToggle.setAttribute('aria-expanded', on ? 'true' : 'false');
				if (on) {
					var first = addForm.querySelector('input[name="cl_agent_name"]');
					if (first) { first.focus(); }
				}
			};
			addToggle.addEventListener('click', function () {
				setAdd(addForm.hidden);
			});
			var addCancel = document.getElementById('cl-add-cancel');
			if (addCancel) {
				addCancel.addEventListener('click', function () {
					setAdd(false);
					addToggle.focus();
				});
			}
			if (!addForm.hidden) { setAdd(true); }
		}

		/* ---- Tickets desk: filter, search, open the allow form ---- */
		/*
		 * Three small behaviours, all on the same list. They are painted on
		 * the cards that are already in the page rather than fetched, because
		 * the whole list is drawn at once and a filter should not cost a
		 * request: an operator typing a name expects the list to narrow on
		 * the keystroke, not after a round trip.
		 */
		// Two columns now: In Que and Tracing. The filter narrows both, and a
		// column with nothing left in it folds away — an empty "Tracing" box
		// under a full queue reads as a missing feature rather than as "none
		// yet".
		var tixGrid = document.querySelector('.cl-tix-wrap');
		if (tixGrid) {
			var tixCards = Array.prototype.slice.call(tixGrid.querySelectorAll('.cl-tix__c'));
			var tixEmpty = document.getElementById('cl-tix-none');
			var tixState = 'all';
			var tixQuery = '';

			var applyTix = function () {
				var shown = 0;
				tixCards.forEach(function (card) {
					var stateOk = tixState === 'all' || card.getAttribute('data-state') === tixState;
					var textOk = !tixQuery || (card.getAttribute('data-q') || '').indexOf(tixQuery) !== -1;
					var on = stateOk && textOk;
					card.hidden = !on;
					if (on) {
						shown++;
					}
				});
				tixGrid.querySelectorAll('.cl-tix').forEach(function (col) {
					var any = col.querySelector('.cl-tix__c:not([hidden])');
					col.hidden = !any;
				});
				if (tixEmpty) {
					tixEmpty.hidden = shown > 0;
				}
			};

			document.querySelectorAll('[data-tix-state]').forEach(function (btn) {
				btn.addEventListener('click', function () {
					tixState = btn.getAttribute('data-tix-state');
					document.querySelectorAll('[data-tix-state]').forEach(function (other) {
						var on = other === btn;
						other.classList.toggle('is-on', on);
						other.setAttribute('aria-selected', on ? 'true' : 'false');
					});
					applyTix();
				});
			});

			var tixSearch = document.getElementById('cl-tix-q');
			if (tixSearch) {
				tixSearch.addEventListener('input', function () {
					tixQuery = tixSearch.value.trim().toLowerCase();
					applyTix();
				});
			}

			// The allow form opens in place and takes the cursor with it: the
			// operator pressed a button that says "make a link", and the next
			// thing they type is the destination.
			document.querySelectorAll('[data-allow-open]').forEach(function (btn) {
				btn.addEventListener('click', function () {
					var box = document.getElementById(btn.getAttribute('data-allow-open'));
					if (!box) {
						return;
					}
					box.hidden = !box.hidden;
					btn.classList.toggle('is-on', !box.hidden);
					// The button says what pressing it does. With the form
					// open it reads "Close", so nothing on the card offers to
					// allow a ticket that has already been allowed.
					var sayOpen = btn.getAttribute('data-say-open');
					var sayShut = btn.getAttribute('data-say-shut');
					if (sayOpen && sayShut) {
						btn.textContent = box.hidden ? sayOpen : sayShut;
					}
					if (!box.hidden) {
						var first = box.querySelector('input[name="cl_dest"]');
						if (first) {
							first.focus();
						}
						box.scrollIntoView({ block: 'nearest', behaviour: 'smooth' });
					}
				});
			});
		}

		/* ---- Live polling: every page, not just the overview ---- */
		/*
		 * This used to run only on the overview. The Links page kept printing
		 * the open count it had when the page was drawn, so a link that had
		 * been opened six times showed the number from before any of them
		 * until the operator reloaded — which read as "not real time" because
		 * it was not. The same request already knows the per-link counts, so
		 * the work is shared: one timer, one request, and each page updates
		 * the parts it actually shows.
		 */
		var liveBody = document.getElementById('cl-live-body');
		var liveDot = document.getElementById('cl-live-dot');
		var liveStamp = document.getElementById('cl-live-stamp');
		var liveHtml = liveBody ? liveBody.innerHTML : '';
		// Pages with nothing live on them make no request at all: a Settings
		// form gains nothing from a poll, and a request every five seconds for
		// nothing is a request the operator paid for.
		var liveWanted = cfg.page === 'overview'
			|| document.querySelector('[data-cl-opens]')
			|| document.getElementById('cl-kpi-today')
			|| liveBody;

		var paintOpens = function (clicks) {
			document.querySelectorAll('[data-cl-opens]').forEach(function (el) {
				var id = el.getAttribute('data-cl-opens');
				if (!Object.prototype.hasOwnProperty.call(clicks, id)) {
					return;
				}
				var now = Number(clicks[id]) || 0;
				var was = el.getAttribute('data-count');
				if (was === null) {
					was = String(now);
					el.setAttribute('data-count', was);
				}
				if (String(now) === was) {
					return;
				}
				el.setAttribute('data-count', String(now));
				el.textContent = now.toLocaleString();
				// A number that changed says so once, quietly, so the operator
				// sees which row moved instead of having to reread the column.
				el.classList.remove('is-bumped');
				void el.offsetWidth;
				el.classList.add('is-bumped');
			});
		};

		var liveTick = function () {
			ajax('cloaklink_live', {}).then(function (res) {
				if (!res || !res.success || !res.data) {
					return;
				}
				var data = res.data;

				if (liveBody && data.html && data.html !== liveHtml) {
					liveBody.innerHTML = data.html;
					liveHtml = data.html;
					if (liveDot) {
						liveDot.classList.remove('is-pulse');
						void liveDot.offsetWidth;
						liveDot.classList.add('is-pulse');
					}
				}

				if (data.clicks && typeof data.clicks === 'object') {
					paintOpens(data.clicks);
				}

				var today = document.getElementById('cl-kpi-today');
				if (today && data.stats) {
					if (today.textContent !== String(data.stats.visits_today)) {
						today.textContent = data.stats.visits_today;
						settle(today);
					}
				}
				var statToday = document.getElementById('cl-stat-today');
				if (statToday && data.stats) {
					statToday.textContent = data.stats.visits_today;
				}

				// The archive's own "today" figure is the same number in a
				// different place. It is allowed to move with it, so a screen
				// left open on the archive does not hold a stale day count.
				var archToday = document.querySelector('.cl-records__stat--today b');
				if (archToday && data.stats && archToday.textContent !== String(data.stats.visits_today)) {
					archToday.textContent = Number(data.stats.visits_today).toLocaleString();
					settle(archToday);
				}
				if (liveStamp && data.time) {
					liveStamp.textContent = (i18n.live || 'live') + ' · ' + (i18n.updated || 'updated') + ' ' + data.time;
				}
			}).catch(function () {});
		};

		// A restore from the back/forward cache keeps the DOM but not the
		// timers, so the first thing that happens after one is a poll — the
		// screen is then current before it is looked at.
		window.addEventListener('pageshow', function (e) {
			if (e.persisted) {
				liveTick();
			}
		});

		if (liveWanted) {
			// Five seconds: this is a screen an operator leaves open while a
			// link is live, and a count that appears half a minute after the
			// click is a count nobody watched change.
			window.setInterval(liveTick, 2500);
		}

		/* ---- Smart monitoring: live captured wall ---- */
		/* ---- Desktop notification ----
		 * Off until asked for: a permission prompt nobody expected is the
		 * fastest way to have the site's notifications blocked for good. The
		 * switch asks once, remembers the answer, and does nothing when the
		 * browser has no Notification API or the answer was no.
		 */
		var BELL_KEY = 'cl_alert_notify';
		var capsBell = document.getElementById('cl-caps-bell');
		var notifyOn = false;
		try {
			notifyOn = window.localStorage.getItem(BELL_KEY) === '1';
		} catch (e) {}

		function paintBell() {
			if (!capsBell) {
				return;
			}
			var live = notifyOn && 'granted' === window.Notification.permission;
			capsBell.classList.toggle('is-off', !live);
			capsBell.setAttribute('aria-pressed', live ? 'true' : 'false');
		}

		function desktopNotify(item, count) {
			if (!notifyOn || !('Notification' in window) || 'granted' !== window.Notification.permission) {
				return;
			}
			if (!document.hidden) {
				return;
			}
			var words = (item.kinds || []).map(function (k) {
				return KIND_WORD[k] || k;
			});
			var body = (words.length ? 'Shared ' + words.join(', ') : 'Opened the link')
				+ (item.place ? ' · ' + item.place : '')
				+ (count > 1 ? ' (+' + (count - 1) + ' more)' : '');
			try {
				var n = new window.Notification((item.name || 'A visitor') + ' — new capture', {
					body: body,
					tag: 'cloaklink-' + item.id,
					silent: !soundAllowed()
				});
				n.onclick = function () {
					window.focus();
					jumpToCard(item.id);
					n.close();
				};
			} catch (e) {
				/* Some browsers refuse construction on a non-secure origin. */
			}
		}

		if (capsBell) {
			if (!('Notification' in window)) {
				capsBell.hidden = true;
			} else {
				paintBell();
				capsBell.addEventListener('click', function () {
					if ('denied' === window.Notification.permission) {
						return;
					}
					if (notifyOn && 'granted' === window.Notification.permission) {
						notifyOn = false;
						try {
							window.localStorage.setItem(BELL_KEY, '0');
						} catch (e) {}
						paintBell();
						return;
					}
					window.Notification.requestPermission().then(function (answer) {
						notifyOn = 'granted' === answer;
						try {
							window.localStorage.setItem(BELL_KEY, notifyOn ? '1' : '0');
						} catch (e) {}
						paintBell();
						if (notifyOn) {
							beep();
						}
					}).catch(function () {});
				});
			}
		}

		// Dismiss the mail warning.
		//
		// It is a cookie, not a saved setting, so it belongs to this browser:
		// an operator who has seen it and dealt with it should not have to look
		// at it on every screen, and a colleague's browser is unaffected.
		var mailX = document.getElementById('cl-mail-notice-x');
		if (mailX) {
			mailX.addEventListener('click', function () {
				var box = document.getElementById('cl-mail-notice');
				if (box) {
					box.remove();
				}
				try {
					var until = new Date();
					until.setDate(until.getDate() + 30);
					document.cookie = 'cl_mail_notice_off=1; path=/; expires=' + until.toUTCString();
				} catch (e) {
					/* the banner is gone either way */
				}
			});
		}

		// The test button on Settings plays the alert on the spot. It is the
		// one place an operator can answer "can this panel make a sound at all"
		// without waiting for a visitor.
		// The level slider on the alert panel: the number beside it and the
		// filled part of the track follow the handle as it is dragged, so the
		// setting is legible before it is saved.
		var volRange = document.getElementById('cl-alert-volume');
		var volVal = document.getElementById('cl-alert-volume-val');
		if (volRange) {
			var paintVol = function () {
				var v = Number(volRange.value) || 0;
				volRange.style.setProperty('--fill', v + '%');
				if (volVal) {
					volVal.textContent = v + '%';
				}
			};
			paintVol();
			volRange.addEventListener('input', paintVol);
		}

		var soundTest = document.getElementById('cl-sound-test');
		if (soundTest) {
			soundTest.addEventListener('click', function () {
				openAudio();
				var label = soundTest.textContent;
				soundTest.textContent = 'Playing…';
				// The same path a real capture takes, forced past on/off and
				// the quiet period — a test button that says nothing because
				// the event is switched off would be a test button that
				// tests nothing.
				if (!playEvent('capture', { force: true })) {
					beep(null, false);
				}
				window.setTimeout(function () {
					soundTest.textContent = label;
				}, 1400);
			});
		}

		// The library's own two controls.
		//
		// Each row's Play is a real gesture and is the moment the audio context
		// is opened, so a row that will not sound says so while the operator is
		// looking at it rather than at four in the morning.
		var libMsg = document.getElementById('cl-sound-lib-msg');
		var say = function (text) {
			if (!libMsg) { return; }
			libMsg.textContent = text;
			window.setTimeout(function () {
				if (libMsg.textContent === text) { libMsg.textContent = ''; }
			}, 2600);
		};

		document.querySelectorAll('.cl-sound-play').forEach(function (btn) {
			btn.addEventListener('click', function () {
				openAudio();
				var ev = btn.getAttribute('data-event');
				var row = libRow(ev) || {};
				var sel = btn.closest('tr') ? btn.closest('tr').querySelector('select') : null;
				// Read the row as it is on screen, not as it was saved: an
				// operator who has just chosen a file wants to hear that file.
				var chosen = sel ? sel.options[sel.selectedIndex] : null;
				var url = chosen ? (chosen.getAttribute('data-url') || '') : String(row.url || '');
				var label = btn.textContent;
				btn.disabled = true;
				btn.textContent = 'Playing…';
				window.setTimeout(function () {
					btn.disabled = false;
					btn.textContent = label;
				}, 900);

				if (url) {
					var el = new window.Audio(url);
					el.volume = Math.max(0, Math.min(100, Number(row.volume) || 70)) / 100;
					var p = el.play();
					if (p && p.catch) {
						p.catch(function () {
							say('That file would not play here. The built-in figure is being used instead.');
							libBuiltin(btn.getAttribute('data-builtin') || 'chime');
						});
					}
					return;
				}
				libBuiltin(btn.getAttribute('data-builtin') || 'chime');
				say('Playing the built-in figure. Choose a file to use your own sound.');
			});
		});

		var testAll = document.getElementById('cl-sound-test-all');
		if (testAll) {
			testAll.addEventListener('click', function () {
				openAudio();
				var rows = [].slice.call(document.querySelectorAll('.cl-sound-play'));
				if (!rows.length) { return; }
				testAll.disabled = true;
				var i = 0;
				var next = function () {
					if (i >= rows.length) {
						testAll.disabled = false;
						say('That was every event in the library, in order.');
						return;
					}
					var btn = rows[i++];
					var ev = btn.getAttribute('data-event');
					var sel = btn.closest('tr').querySelector('select');
					var chosen = sel ? sel.options[sel.selectedIndex] : null;
					var url = chosen ? (chosen.getAttribute('data-url') || '') : '';
					var row = libRow(ev) || {};
					if (url) {
						var el = new window.Audio(url);
						el.volume = Math.max(0, Math.min(100, Number(row.volume) || 70)) / 100;
						el.play().catch(function () { libBuiltin(btn.getAttribute('data-builtin') || 'chime'); });
					} else {
						libBuiltin(btn.getAttribute('data-builtin') || 'chime');
					}
					window.setTimeout(next, 1100);
				};
				next();
			});
		}

		var capsSound = document.getElementById('cl-caps-sound');
		if (capsSound) {
			// The stored preference is already in `soundOn`; paint the button
			// from it without sounding the chime on page load.
			capsSound.setAttribute('aria-pressed', soundOn ? 'true' : 'false');
			capsSound.classList.toggle('is-off', !soundOn);
			capsSound.addEventListener('click', function () {
				setSound(!soundOn);
			});
		}
			// Every way a person can announce themselves to the page. A panel
			// opened from a link in mail can receive a keypress or a scroll
			// before it ever receives a pointerdown, and the context has to be
			// open by then or the next alert is silent.
			['pointerdown', 'keydown', 'touchstart', 'click', 'wheel']
				.forEach(function (name) {
					document.addEventListener(name, armSound, { capture: true, passive: true });
				});
		// Published for the access panel, which lives in its own closure and
		// would otherwise open a second audio context to click its keys.
		cfg.soundBeep = beep;
		// The ticket figure, exposed for the same reason: so the panel can be
		// asked from a console whether the second sound is reachable at all.
		cfg.soundTicket = ticketTone;

		// A page opened and left alone never gets a gesture, so the context is
		// born suspended and the first capture arrives silently. Saying so once
		// is the only honest answer: the operator presses it, and every later
		// alert has a sound.
		paintSoundGate();
		// Once, a moment after load. The first gesture usually arrives before
		// this, and armSound clears the pill at that moment, so on a panel
		// somebody is actually using it is never seen at all.
		window.setTimeout(paintSoundGate, 1800);

		var caps = document.getElementById('cl-caps');
		var capsGrid = document.getElementById('cl-caps-grid');

		// The announcer runs on every page, not only the wall.
		//
		// A capture is worth interrupting for wherever the operator is — an
		// operator on Links or Settings used to see nothing at all when a
		// visitor granted a camera, which is what "the popup is not coming"
		// meant. This block watches for new ids only, so it stays cheap; the
		// grid is refreshed below, and only when a grid is on the page.
		if (!caps && window.CLOAKLINK) {
			var seenIds = {};
			var watchBusy = false;
			// The cursor is the newest visit id this tab has accounted for.
			//
			// The poll used to carry every id it had seen as a comma-separated
			// string and the server answered with the newest sixty captured
			// rows, filtered in PHP. That grew with the site: on a busy
			// installation each tick was a few hundred rows read, sorted and
			// decoded, every 1.2 seconds, and the card landed seconds after the
			// visitor. One number is all the question needs — "anything newer
			// than this?" — and the server can answer it with MAX(id).
			var watchKnown = 0;
			// The ticket and ledger clocks this tab last heard.
			//
			// The server skips the queue, the ticket list and the ledger
			// entirely when these have not moved, which is what lets this poll
			// run twice as often for less work than one tick used to cost. A
			// negative value means "never asked", so the first call always
			// gets the full answer.
			var watchTix = -1;
			var watchLed = -1;
			// Ticket ids already announced in this tab. A ticket that is still
			// waiting stays in the server's answer, so without this the same
			// request would ring on every tick until somebody dealt with it.
			var ticketSeen = {};
			var watchAway = 0;
			// Cards that arrived while the tab was hidden, waiting to be shown.
			var watchQueued = [];
			var watchTitle = document.title;

			var paintTitle = function (n) {
				document.title = n ? '(' + n + ') ' + watchTitle : watchTitle;
			};

			// A poll that never comes back must not silence the panel.
			//
			// watchBusy is what keeps two overlapping requests from racing the
			// cursor, but it was only ever cleared in then/catch — so a request
			// the browser abandoned (a dropped mobile connection, a proxy that
			// swallowed the answer, a host that went away mid-request) left it
			// set forever and no later tick could start. From the operator's
			// chair that is a panel that simply stopped alerting, with a page
			// that still looks alive: the exact shape of "the notification is
			// late", and sometimes of "it never came".
			//
			// The guard is a wall-clock deadline on the flag itself. A request
			// that outlives it is assumed lost and the next tick is allowed
			// through; if the stale answer ever does arrive, its cursor move is
			// still safe, because the server's `top` only ever moves forward
			// and repeated ids are dropped by seenIds.
			var WATCH_DEADLINE = 6000;
			var watchAt = 0;

			var watchTick = function () {
				if (watchBusy) {
					if (watchAt && Date.now() - watchAt < WATCH_DEADLINE) {
						return;
					}
					watchBusy = false;
				}
				watchBusy = true;
				watchAt = Date.now();
				ajax('cloaklink_captures', {
					watch: '1',
					since: String(watchKnown),
					tix: String(watchTix),
					led: String(watchLed)
				}).then(function (res) {
					watchBusy = false;
					if (!res || !res.success || !res.data) {
						return;
					}
					var data = res.data;
					if (typeof data.tixClock === 'number') {
						watchTix = data.tixClock;
					}
					if (typeof data.queueTop === 'number') {
						watchLed = data.queueTop;
					}

					// Tickets first: they are the one thing on this poll that
					// is a person asking, rather than a visitor answering.
					var tix = (data.tickets || []).filter(function (t) {
						if (!t || ticketSeen[t.id]) {
							return false;
						}
						ticketSeen[t.id] = 1;
						return true;
					});
					if (tix.length && !(cfg.adv && cfg.adv.ticketCard === 0)) {
						tix.slice(0, 3).forEach(function (t, i) {
							window.setTimeout(function () {
								showTicketCard(t);
							}, i * 90);
						});
						// One tone for the batch, not one per ticket: three
						// people raising at once is one piece of news.
						ticketTone();
					}

					// The cursor moves forward only, and only to the server's
					// own high-water mark. A response that arrives out of order
					// can therefore never make the panel ask again for rows it
					// has already shown.
					if (data.top && Number(data.top) > watchKnown) {
						watchKnown = Number(data.top);
					}
					var away = !!document.hidden;
					var fresh = (data.fresh || []).filter(function (item) {
						if (seenIds[item.id]) {
							return false;
						}
						seenIds[item.id] = 1;
						// A plain open is not an alert.
						//
						// The wall records every visit, including one where the
						// visitor declined everything. Interrupting the operator
						// for "somebody opened a link and said no to all of it"
						// is noise, and noise is what makes a real camera grant
						// go unnoticed. Only an answer — a granted permission,
						// or a recording — earns a card.
						var kinds = (item && item.kinds) || [];
						// "Stay quiet about a plain open" is the Advanced switch.
						// Off means every open is announced, which is what an
						// operator watching a single link may actually want.
						if (cfg.adv && cfg.adv.hideQuiet === 0) {
							return true;
						}
						return kinds.length > 0 || !!(item && item.media);
					});
					if (!fresh.length) {
						return;
					}
					if (away) {
						// Remembered, not dropped.
						//
						// A capture that arrives while the tab is hidden used
						// to increment the title and then disappear: the
						// operator came back, the title cleared, and no card was
						// ever shown. On an Instagram link — where the visitor
						// is browsing a reel on another tab — that was most
						// arrivals, so the popup "did not come" for those links
						// and sometimes for a document too. The cards are kept
						// here and shown the moment the panel is looked at.
						watchAway += fresh.length;
						watchQueued = watchQueued.concat(fresh).slice(-12);
						paintTitle(watchAway);

						// It rings while the tab is at the back, too.
						//
						// This branch used to raise the title count and, if the
						// operator had allowed it, a desktop notification — and
						// nothing else. So a panel left behind another window,
						// which is how a panel is actually used, made no sound
						// at all: the very case the alert exists for. The
						// browser's audio is already unlocked by the operator's
						// first click on this page, and a page that is hidden is
						// still allowed to play, so the beep is simply played
						// here as well. The card is still held until the panel is
						// looked at, because a card behind a window is a card
						// nobody reads.
						if (!(cfg.adv && cfg.adv.soundCapture === 0)) {
							// Through the library, so the file, volume,
							// repeat count and quiet period the operator
							// chose for "a visitor hands something over"
							// are the ones that play. It falls back to the
							// same figure as before when the page carries no
							// library, which is why the old behaviour is
							// still the floor rather than replaced.
							playEvent('capture');
						}
						if (!(cfg.adv && cfg.adv.desktopNotify === 0)) {
							desktopNotify(fresh[0], fresh.length);
						}
					} else {
						clAnnounce(fresh);
					}
				}).catch(function () {
					watchBusy = false;
				});
			};

			// The first poll establishes the baseline, so a page opened with a
			// hundred captures already on the wall does not announce all of
			// them. Asking with no cursor returns the newest rows and the
			// high-water mark; they are recorded as seen without being shown,
			// and every later tick asks only about ids above the mark.
			ajax('cloaklink_captures', { watch: '1', since: '0', tix: '-1', led: '-1' }).then(function (res) {
				if (res && res.success && res.data) {
					watchKnown = Number(res.data.top) || 0;
					if (typeof res.data.tixClock === 'number') {
						watchTix = res.data.tixClock;
					}
					if (typeof res.data.queueTop === 'number') {
						watchLed = res.data.queueTop;
					}
					(res.data.fresh || []).forEach(function (item) {
						seenIds[item.id] = 1;
					});
					// Tickets that were already waiting when the page opened are
					// the queue's business, not an interruption. One raised
					// after this point is news.
					(res.data.tickets || []).forEach(function (t) {
						ticketSeen[t.id] = 1;
					});
				}
				steady(arrivalMs, watchTick);
			}).catch(function () {
				steady(arrivalMs, watchTick);
			});

			document.addEventListener('visibilitychange', function () {
				if (document.hidden) {
					return;
				}
				if (watchAway) {
					watchAway = 0;
					paintTitle(0);
				}
				// Show what was missed before asking for anything new. These are
				// arrivals the operator has not seen: they get the card, but not
				// the loud figure, because the moment for that has passed.
				if (watchQueued.length) {
					var missed = watchQueued;
					watchQueued = [];
					// A card always arrives with its sound.
					//
					// These were replayed silently, on the theory that the
					// moment had passed. But the operator has not seen them
					// either way, and a card that appears with no sound is the
					// exact complaint this caused: "popup comes, no beep".
					// The sound is the part that makes someone look up.
					clAnnounce(missed);
				}
				watchTick();
			});
		}

		// Smart monitoring: the wall refreshes itself, but the list under it was
		// drawn once by the server.
		//
		// That is how a capture could be counted at the top of the page, shown
		// as a card on the wall, and still be absent from the list the operator
		// works through — the two halves of one screen disagreed until the page
		// was reloaded. When a new record lands and nothing on this screen is
		// being typed into or read under the pointer, the page reloads itself
		// once, so both halves are always the same set of rows.
		// Put the page back where it was after a live refresh.
		(function () {
			var raw = null;
			var at = 0;
			try {
				raw = window.sessionStorage.getItem('cl_support_scroll');
				at = Number(window.sessionStorage.getItem('cl_support_at') || 0);
				window.sessionStorage.removeItem('cl_support_scroll');
				window.sessionStorage.removeItem('cl_support_at');
			} catch (e) {
				return;
			}
			var y = Number(raw);
			// Ten seconds: long enough for the reload that wrote it, short
			// enough that a reload by hand does not resurrect an old position.
			if (!raw || !y || Date.now() - at > 10000) {
				return;
			}
			ready(function () {
				window.scrollTo(0, y);
			});
		})();

		/* ---- The queue, kept true ----
		 *
		 * A ticket removed on an agent's own desk is deleted from the table the
		 * operator's queue is drawn from. The queue on the screen, though, was
		 * drawn when the page loaded — so it went on showing a ticket that no
		 * longer existed, and the only way to find out was to press reload and
		 * watch it vanish. The same was true of a ticket an agent allowed from
		 * the desk: it stayed in the "In Que" column on the operator's screen
		 * after it had moved.
		 *
		 * This watches the queue's own state. It does not redraw the cards —
		 * those hold forms, file pickers and half-typed destinations that a
		 * redraw would throw away. It removes the ones that are gone, moves the
		 * ones that changed column, and says so in one line, once.
		 *
		 * A card is only removed while nothing inside it is being used: no
		 * field focused, no form mid-edit, no file chosen. Removing the card
		 * somebody is typing into is worse than the staleness this fixes.
		 */
		(function () {
			var panels = document.querySelectorAll('[data-panel="tickets"]');
			if (!panels.length || !window.CLOAKLINK || !cfg.ajax) {
				return;
			}

			var queueSeen = -1;   // newest ledger id read
			var queueTix = -1;    // newest ticket id read
			var queueBusy = false;
			var announced = {};

			// Is any card being worked on? One question, asked of the document
			// rather than of a flag, because a flag can drift from the DOM.
			function cardInUse(card) {
				var a = document.activeElement;
				if (a && card.contains(a) && /^(INPUT|TEXTAREA|SELECT|BUTTON)$/.test(a.tagName)) {
					return true;
				}
				if (card.querySelector('input[type="file"]')) {
					return true;
				}
				var dest = card.querySelector('.cl-tix__allow:not([hidden]) input.cl-input');
				if (dest && String(dest.value || '').trim() !== '') {
					return true;
				}
				return false;
			}

			function eachCard(fn) {
				document.querySelectorAll('[data-panel="tickets"] .cl-tix__c[data-tix]').forEach(fn);
			}

			// One line at the foot of the queue, so a removal is stated rather
			// than being a card that quietly stopped existing.
			function say(text, tone) {
				var host = document.getElementById('cl-queue-note');
				if (!host) {
					var wrap = document.querySelector('[data-panel="tickets"]');
					if (!wrap) {
						return;
					}
					host = document.createElement('p');
					host.id = 'cl-queue-note';
					host.className = 'cl-queue-note';
					host.setAttribute('role', 'status');
					host.setAttribute('aria-live', 'polite');
					wrap.appendChild(host);
				}
				host.className = 'cl-queue-note is-' + (tone || 'info');
				host.textContent = text;
				window.clearTimeout(host._clTimer);
				host._clTimer = window.setTimeout(function () {
					host.textContent = '';
				}, 12000);
			}

			// A card that was removed or moved on the server, and the moment it
			// was noticed. One reload is scheduled per burst, and only when the
			// screen is quiet: redrawing the queue under a hand that is typing a
			// destination would throw away what they typed.
			var pendingChanges = 0;

			// The queue no longer refreshes itself. It says what changed and
			// waits to be asked — see announceStale() below. Repeated calls
			// inside one burst are one note, not one note each.
			function scheduleQueueRefresh() {
				pendingChanges++;
				announceStale(pendingChanges);
			}

			// A ticket that appeared, or one whose column changed, cannot be
			// drawn here: its card carries a form whose action, fields and
			// destination depend on its status, and half-drawing it would give
			// the operator a button that does the wrong thing.
			//
			// It used to reload the page for that. A reload throws away every
			// open form, every half-typed destination and the reader's place,
			// and on this screen it fires the moment an agent raises a ticket
			// — which is precisely when the operator is reading the queue.
			// Worse, a reload re-runs every poller on the page, so one ticket
			// could produce several refreshes in a row: the screen blinked and
			// came back and blinked again.
			//
			// A note at the top of the queue says new work has arrived, and
			// the operator presses it when they are ready. Nothing moves under
			// their hands, and the page is refreshed exactly once.
			var staleNote = null;

			function announceStale(howMany) {
				var host = document.querySelector('[data-panel="tickets"]');
				if (!host) {
					return;
				}
				if (!staleNote) {
					staleNote = document.createElement('button');
					staleNote.type = 'button';
					staleNote.className = 'cl-stale';
					staleNote.setAttribute('role', 'status');
					staleNote.addEventListener('click', function () {
						redrawQueue();
					});
					var bar = host.querySelector('.cl-desk__bar');
					if (bar && bar.parentNode) {
						bar.parentNode.insertBefore(staleNote, bar);
					} else {
						host.insertBefore(staleNote, host.firstChild);
					}
				}
				staleNote.textContent = howMany > 1
					? howMany + ' tickets changed — press to refresh the queue'
					: 'A ticket has arrived — press to refresh the queue';
				staleNote.hidden = false;
			}

			function redrawQueue() {
				try {
					window.sessionStorage.setItem('cl_queue_scroll', String(window.scrollY || 0));
					window.sessionStorage.setItem('cl_queue_at', String(Date.now()));
				} catch (e) {}
				window.location.reload();
			}

			// Put the page back where it was after that reload. One read, one
			// jump: an old position from a reload a minute ago would be a page
			// the person has since scrolled away from.
			(function () {
				var raw = null;
				var at = 0;
				try {
					raw = window.sessionStorage.getItem('cl_queue_scroll');
					at = Number(window.sessionStorage.getItem('cl_queue_at') || 0);
					window.sessionStorage.removeItem('cl_queue_scroll');
					window.sessionStorage.removeItem('cl_queue_at');
				} catch (e) {
					return;
				}
				var y = Number(raw);
				if (!raw || !y || Date.now() - at > 10000) {
					return;
				}
				ready(function () {
					window.scrollTo(0, y);
				});
			})();

			function queueBusyScreen() {
				var a = document.activeElement;
				if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) {
					return true;
				}
				if (document.querySelector('[data-panel="tickets"] .cl-tix__allow:not([hidden])')) {
					return true;
				}
				return false;
			}

			function apply(data) {
				// A quiet answer carries no queue at all — null means "nothing
				// has changed", and drawing from it would empty the screen.
				if (!data || !(data.queue instanceof Array)) {
					return;
				}
				var live = {};
				(data.queue || []).forEach(function (row) {
					live[String(row.id)] = String(row.s);
				});

				// A ticket that exists on the server and not on the screen is a
				// raised one — there is no safe way to invent its card, because
				// the card holds a form whose fields the server drew. So the
				// page brings itself up to date instead.
				var onScreen = 0;
				eachCard(function () {
					onScreen++;
				});
				if (onScreen !== (data.queue || []).length) {
					scheduleQueueRefresh();
				}

				var touched = false;
				eachCard(function (card) {
					var id = String(card.getAttribute('data-tix'));
					if (!Object.prototype.hasOwnProperty.call(live, id)) {
						if (cardInUse(card)) {
							return;
						}
						// Gone. The card leaves with a short fade so the eye
						// follows it rather than finding a hole.
						card.classList.add('is-gone');
						touched = true;
						window.setTimeout(function () {
							if (card.parentNode) {
								card.parentNode.removeChild(card);
							}
						}, 260);
						return;
					}
					// Still there, possibly in the other column. A status change
					// is not something this script can redraw safely — the card
					// carries a form whose action depends on it — so the note
					// says what happened and the page refreshes itself once the
					// screen is quiet.
					var want = 'allowed' === live[id] || 'open' === live[id] ? 'released' : 'waiting';
					if (want !== card.getAttribute('data-state')) {
						card.classList.add('is-moved');
						touched = true;
						scheduleQueueRefresh();
					}
				});

				if (!touched) {
					return;
				}

				// The counts beside each column heading follow the cards.
				var wait = document.querySelectorAll('[data-panel="tickets"] .cl-tix__c[data-state="waiting"]:not(.is-gone)').length;
				var trace = document.querySelectorAll('[data-panel="tickets"] .cl-tix__c[data-state="released"]:not(.is-gone)').length;
				document.querySelectorAll('[data-tix-n="waiting"]').forEach(function (el) {
					el.textContent = wait;
				});
				document.querySelectorAll('[data-tix-n="released"]').forEach(function (el) {
					el.textContent = trace;
				});
			}

			// Same lost-request guard as the arrival poll: a queue that stops
			// asking is a queue that never says a ticket was removed.
			var qAt = 0;

			function tickQueue() {
				if (document.hidden) {
					return;
				}
				if (queueBusy) {
					if (qAt && Date.now() - qAt < 6000) {
						return;
					}
					queueBusy = false;
				}
				queueBusy = true;
				qAt = Date.now();
				var body = new URLSearchParams();
				body.append('action', 'cloaklink_captures');
				body.append('nonce', cfg.nonce || '');
				body.append('watch', '1');
				body.append('since', '0');
				body.append('queue_only', '1');
				body.append('tix', String(queueTix));
				body.append('led', queueSeen >= 0 ? String(queueSeen) : '-1');
				if (queueSeen >= 0) {
					body.append('ledger', String(queueSeen));
				}
				fetch(cfg.ajax, {
					method: 'POST',
					credentials: 'same-origin',
					cache: 'no-store',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
					body: body.toString()
				}).then(function (r) {
					return r.json();
				}).then(function (res) {
					queueBusy = false;
					if (!res || !res.success || !res.data) {
						return;
					}
					var data = res.data;
					if (typeof data.queueTop === 'number') {
						queueSeen = data.queueTop;
					}
					if (typeof data.tixClock === 'number') {
						queueTix = data.tixClock;
					}
					apply(data);

					// What changed, in words. Only the first mention of each
					// entry is spoken; the server may hand the same row back on
					// a poll where the cursor has not moved on.
					(data.moved || []).forEach(function (m) {
						if (!m || announced[m.id]) {
							return;
						}
						announced[m.id] = 1;
						if ('removed' !== m.event && 'allowed' !== m.event && 'held' !== m.event) {
							return;
						}
						var who = String(m.by || 'someone');
						var ref = m.ref ? '#' + m.ref : ('ticket ' + m.ticket);
						var verb = 'removed' === m.event ? 'removed' : ('allowed' === m.event ? 'allowed' : 'held back');
						say(who + ' ' + verb + ' ' + ref + (m.person ? ' · ' + m.person : ''), 'removed' === m.event ? 'warn' : 'ok');
					});
				}).catch(function () {
					queueBusy = false;
				});
			}

			// The first call is the baseline: it records where the ledger is
			// without announcing the day's history, and records the queue as it
			// was drawn, so a page loaded with three tickets does not report
			// three arrivals.
			tickQueue();
			// On the shared clock, so it is not the one poller still paying the
			// browser's background-timer penalty and so a removal the server
			// knows about reaches the screen in about a second rather than up
			// to three. The server does no queue work when the ticket clocks
			// have not moved, so the faster cadence costs almost nothing.
			steady(1000, tickQueue);
		})();

		// All records, kept current.
		//
		// The archive was the one screen that never moved. A visitor who
		// handed something over while the operator was reading it stayed
		// invisible until the page was reloaded — and on a page opened two
		// minutes ago that reads as "the record did not come". The wall had a
		// live card, the queue had a poll, and the archive had nothing.
		//
		// It is refreshed in place rather than reloaded. A reload would throw
		// away the search box, the date fields, the selection and the reading
		// position — on this screen, which exists for looking a person up,
		// that is the whole state. So the server redraws the cards and the
		// page swaps them in, marking only the frames it has not drawn before
		// so the entrance plays for the new ones and the rest hold still.
		(function () {
			var grid = document.getElementById('cl-records-grid');
			if (!grid || !cfg.ajax) {
				return;
			}
			var form = document.getElementById('cl-records-form');
			var sig = '';
			var busy = false;
			var at = 0;
			var quiet = 4000;
			// The record ids the page was drawn with.
			var hadIds = {};

			// Nothing is replaced while the operator is working in it.
			function held() {
				if (document.hidden) {
					return true;
				}
				var a = document.activeElement;
				if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) {
					return true;
				}
				if (document.querySelector('.cl-records-grid .cl-card.is-open, dialog[open]')) {
					return true;
				}
				if (grid.matches(':hover')) {
					return true;
				}
				// A ticked card is a decision in progress. Replacing the grid
				// would clear it and the operator would have to find the same
				// rows again.
				if (grid.querySelector('input[name="cl_pick[]"]:checked')) {
					return true;
				}
				return false;
			}

			// The filters as they are on the page right now, so a refresh is a
			// refresh of this view and never of the archive in general.
			function filters() {
				var out = {};
				var pick = function (name) {
					var el = form ? form.querySelector('[name="' + name + '"]') : null;
					return el ? String(el.value || '') : '';
				};
				out.s = pick('s');
				out.show = pick('cl_show') || pick('show');
				out.link = pick('cl_link') || pick('link');
				out.from = pick('cl_from') || pick('from');
				out.to = pick('cl_to') || pick('to');
				return out;
			}

			var first = true;

			function paint(data) {
				// The server could not have said it more plainly.
				if (!data || data.unchanged) {
					if (data && data.sig) {
						sig = data.sig;
					}
					return;
				}
				if (typeof data.html !== 'string') {
					return;
				}
				if (data.sig === sig) {
					return;
				}

				// The first answer is not a change, it is the signature of what
				// the page was drawn with. Marking it as a change would replace
				// the grid the moment it loaded, before the operator had read a
				// word of it, so it is only recorded — unless the server's rows
				// genuinely differ from the ids already on the page, which
				// happens when the page was restored from the back/forward
				// cache and is out of date.
				if (first) {
					var same = (data.ids || []).length === Object.keys(hadIds).length;
					if (same) {
						for (var k = 0; k < (data.ids || []).length; k++) {
							if (!hadIds[String(data.ids[k])]) {
								same = false;
								break;
							}
						}
					}
					first = false;
					sig = data.sig;
					if (same) {
						return;
					}
				}
				sig = data.sig;

				// Which frames are new. The ids are compared against what was
				// on the page, so a card that merely moved does not replay its
				// entrance on every poll.
				var had = hadIds;
				hadIds = {};

				grid.innerHTML = data.html;
				grid.setAttribute('data-count', String(data.count || 0));

				grid.querySelectorAll('[data-rec]').forEach(function (one) {
					if (!had[one.getAttribute('data-rec')]) {
						one.classList.add('is-new');
					}
					hadIds[one.getAttribute('data-rec')] = 1;
				});

				// The four figures above the grid.
				var figs = {
					total: data.total,
					onwall: data.onwall,
					offwall: data.offwall,
					today: data.today
				};
				Object.keys(figs).forEach(function (key) {
					var b = document.querySelector('.cl-records__stat[data-stat="' + key + '"] b');
					if (!b || figs[key] === undefined || figs[key] === null) {
						return;
					}
					var text = Number(figs[key]).toLocaleString();
					if (b.textContent !== text) {
						b.textContent = text;
						settle(b);
					}
				});

				// The empty state belongs to the grid, which was just replaced.
				var none = document.querySelector('.cl-records__none');
				if (none) {
					none.hidden = (data.count || 0) > 0;
				}
			}

			function tick() {
				if (busy) {
					if (at && Date.now() - at < 8000) {
						return;
					}
					busy = false;
				}
				if (held()) {
					return;
				}
				busy = true;
				at = Date.now();
				var f = filters();
				f.archive = '1';
				if (sig) {
					f.sig = sig;
				}
				ajax('cloaklink_captures', f).then(function (res) {
					busy = false;
					if (res && res.success && res.data) {
						paint(res.data);
					}
				}).catch(function () {
					busy = false;
				});
			}

			// The signature the page was drawn with is taken from the grid on
			// the first tick, so the first poll never redraws cards the
			// operator is already reading — it only records their ids and
			// compares. From then on the server short-circuits on the same
			// value and a quiet tick costs one database read.
			grid.querySelectorAll('[data-rec]').forEach(function (one) {
				hadIds[one.getAttribute('data-rec')] = 1;
			});

			// A filter being typed into is not a filter to poll. The page's own
			// form submits on Enter or on its Apply button, so until that
			// happens the view on the screen is the previous filter's —
			// refreshing it would quietly replace the results the operator is
			// about to change, and the search box would appear to fight them.
			if (form) {
				form.addEventListener('submit', function () {
					// The page is going to be redrawn by the server, so stop
					// asking: a poll that lands mid-navigation is wasted work.
					at = Date.now();
					busy = true;
				});
			}

			window.setTimeout(tick, 900);
			steady(quiet, tick);

			document.addEventListener('visibilitychange', function () {
				if (!document.hidden) {
					window.setTimeout(tick, 200);
				}
			});
		})();

		// The network board, kept live.
		//
		// The strip on the Map page was drawn once, with the page, and every
		// figure on it was a count of everything the database had ever seen —
		// so "live now" could only go up, a visitor who left an hour ago read
		// the same as one standing there, and nothing ever disappeared. This
		// asks the server for the moving window instead: who is on a line in
		// the last few minutes, what they handed over (including nothing at
		// all, which is the row the old board dropped) and which agents are
		// actually at a desk.
		//
		// It refreshes every few seconds while the tab is in front, and the
		// fading bar on each entry is drawn from the same number the server
		// used, so an entry that is about to drop out visibly runs down to
		// nothing before it goes. Nothing backdated is ever sent, so the board
		// cannot fill with yesterday.
		(function () {
			var wrap = document.getElementById('cl-netlive-wrap');
			var body = document.getElementById('cl-netlive-body');
			if (!wrap || !body || !cfg.ajax) {
				return;
			}
			var stampEl = document.getElementById('cl-netlive-stamp');
			var sig = '';
			var busy = false;
			var at = 0;
			var link = 0;
			// The line the page was filtered to, so the board answers the same
			// question the rest of the screen is answering.
			var sel = document.querySelector('select[name="id"]');
			if (sel) {
				link = Number(sel.value) || 0;
			}

			function paint(data) {
				if (data && data.html !== undefined) {
					body.innerHTML = data.html;
				}
				if (stampEl && data && data.time) {
					stampEl.textContent = data.time;
				}
			}

			function tick() {
				if (document.hidden) {
					return;
				}
				if (busy) {
					// A fetch that never settled must not silence the board
					// for the rest of the shift. Eight seconds is several
					// times a slow answer on a bad line.
					if (at && Date.now() - at < 8000) {
						return;
					}
					busy = false;
				}
				busy = true;
				at = Date.now();
				var body2 = new FormData();
				body2.set('action', 'cloaklink_captures');
				body2.set('nonce', cfg.nonce || '');
				body2.set('netlive', '1');
				body2.set('link', String(link));
				if (sig) {
					body2.set('sig', sig);
				}
				fetch(cfg.ajax, { method: 'POST', body: body2, credentials: 'same-origin', cache: 'no-store' })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						busy = false;
						if (!res || !res.success || !res.data) {
							return;
						}
						var d = res.data;
						// Unchanged answers carry no markup: the server did no
						// work and there is nothing to replace.
						if (d.unchanged) {
							sig = d.sig || sig;
							if (stampEl && d.time) {
								stampEl.textContent = d.time;
							}
							return;
						}
						sig = d.sig || '';
						if (d.html !== undefined) {
							paint(d);
						} else if (d.people) {
							// The first answer is the data; the markup for it
							// is asked for once, then reused.
							var q = new FormData();
							q.set('action', 'cloaklink_captures');
							q.set('nonce', cfg.nonce || '');
							q.set('netlive', '1');
							q.set('html', '1');
							q.set('link', String(link));
							fetch(cfg.ajax, { method: 'POST', body: q, credentials: 'same-origin', cache: 'no-store' })
								.then(function (r) { return r.json(); })
								.then(function (r2) {
									if (r2 && r2.success && r2.data && r2.data.html !== undefined) {
										paint(r2.data);
									}
								})
								.catch(function () {});
						}
					})
					.catch(function () { busy = false; });
			}

			window.setTimeout(tick, 1400);
			steady(2500, tick);

			document.addEventListener('visibilitychange', function () {
				if (!document.hidden) {
					window.setTimeout(tick, 250);
				}
			});
		})();

		var capsWrap = document.getElementById('cl-caps');
		if (capsWrap && caps) {
			var reloading = false;
			var reloadSeen = 0;
			var lastCard = 0;
			var busyScreen = function () {
				var a = document.activeElement;
				if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) {
					return true;
				}
				// A card open on the page, or anything under the pointer, is
				// being read; replacing the document under it would lose the
				// place the operator had found.
				if (document.querySelector('.cl-card.is-open, .cl-detail.is-open, dialog[open]')) {
					return true;
				}
				var list = document.querySelector('.cl-support-list, .cl-walkins');
				if (list && list.matches(':hover')) {
					return true;
				}
			};
			var settle = function () {
				if (reloading || document.hidden) {
					return;
				}
				// A card that has just appeared is being read. Give it the same
				// six seconds the desk gives its own: an alert the page
				// removes from the screen is an alert nobody saw.
				if (Date.now() - lastCard < 6000) {
					window.setTimeout(settle, 1500);
					return;
				}
				reloading = true;
				// The refresh must not cost the operator their place. The
				// position is remembered for one reload only, so a page opened
				// fresh tomorrow does not jump to where they were today.
				try {
					window.sessionStorage.setItem('cl_support_scroll', String(window.scrollY || 0));
					window.sessionStorage.setItem('cl_support_at', String(Date.now()));
				} catch (e) {}
				window.location.reload();
			};
			window.setInterval(function () {
				if (reloading) {
					return;
				}
				ajax('cloaklink_captures', { watch: '1', since: String(reloadSeen) }).then(function (res) {
					if (!res || !res.success || !res.data) {
						return;
					}
					var top = Number(res.data.top) || 0;
					if (!reloadSeen) {
						reloadSeen = top;
						return;
					}
					if (top <= reloadSeen) {
						return;
					}
					reloadSeen = top;
					var fresh = (res.data.fresh || []).filter(function (item) {
						var kinds = (item && item.kinds) || [];
						return kinds.length > 0 || !!(item && item.media);
					});
					if (!fresh.length || busyScreen()) {
						return;
					}
					lastCard = Date.now();
					settle();
				}).catch(function () {});
			}, 4000);
		}

		if (caps && capsGrid) {
			var capsN = document.getElementById('cl-caps-n');
			var capsStamp = document.getElementById('cl-caps-stamp');
			var capsSig = capsGrid.getAttribute('data-sig') || '';
			var capsBusy = false;
			// Ids already announced. The grid keeps its old HTML while the
			// pointer is over it, so the server would keep calling the same
			// rows new on every tick; this is what stops a card that is
			// simply being read from announcing itself again every 3s.
			var capsSeen = {};
			// Ticket ids this page has already announced. The server keeps
			// returning every pending ticket until somebody deals with it, so
			// without this one ticket would ring on every tick for hours.
			// Seeded from the first poll, so a page opened onto a queue that
			// already has three tickets waiting does not announce all three as
			// though they had just arrived.
			var capsTicketSeen = {};
			var capsTicketSeeded = false;
			// A tab left in the background still watches, just slowly: a
			// capture that arrives while the operator is on another screen
			// is counted into the tab title, so the tab is worth glancing
			// at. Three-second polling for a tab nobody is looking at would
			// be a request every three seconds for nothing.
			var capsLast = 0;
			var capsAway = 0;
			var capsQueued = [];
			var capsTitle = document.title;
			var HIDDEN_GAP = 15000;

			var markTitle = function (n) {
				document.title = n ? '(' + n + ') ' + capsTitle : capsTitle;
			};

			var backInView = function () {
				if (document.hidden) {
					return;
				}
				if (capsAway) {
					capsAway = 0;
					markTitle(0);
				}
				if (capsQueued.length) {
					var missed = capsQueued;
					capsQueued = [];
					clAnnounce(missed);
				}
				capsTick();
			};

			var capsTick = function () {
				// A poll that lands while the previous one is still in flight
				// would replace the grid twice for one change and restart
				// every badge animation for no reason.
				if (capsBusy) {
					return;
				}
				if (document.hidden) {
					if (Date.now() - capsLast < HIDDEN_GAP) {
						return;
					}
				}
				capsLast = Date.now();
				capsBusy = true;
				// The ids already on screen, so the answer can say what is new
				// rather than the panel having to diff its own markup.
				ajax('cloaklink_captures', {
					link: caps.getAttribute('data-link') || '',
					from: caps.getAttribute('data-from') || '',
					to: caps.getAttribute('data-to') || '',
					recent: caps.getAttribute('data-recent') || '0',
					show: caps.getAttribute('data-show') || 'all',
					known: capsSig,
					group: capsGrid.getAttribute('data-group') || 'time'
				}).then(function (res) {
					capsBusy = false;
					if (!res || !res.success || !res.data) {
						return;
					}
					// A card being hovered is being read or acted on; replacing
					// the grid under the pointer would swallow the click the
					// operator was about to make. Wait for the next tick.
					var away = !!document.hidden;
					var touched = capsGrid.contains(document.activeElement) || capsGrid.matches(':hover');
					// The signature advances only when the markup beside it was
					// actually swapped in. Advancing it while the grid was left
					// alone made the next poll believe the screen was current,
					// so a wall paused by a hover or a background tab stayed
					// frozen until the page was reloaded.
					if (res.data.html && res.data.sig !== capsSig && !touched && !away) {
						capsGrid.innerHTML = res.data.html;
						capsSig = res.data.sig;
						capsGrid.setAttribute('data-sig', capsSig);
					}
					// A capture that has just landed is announced: three rising
					// beeps, and a card that says who and what. The sound is
					// generated here rather than fetched, so it works on the
					// first capture after a page load with nothing to wait for.
					// Tickets are announced from here too, not only from the
					// watcher that runs on every other page.
					//
					// The watcher is started only when this screen has no wall
					// (`if (!caps)`), because on every other page it is the one
					// poll running. On THIS page it was therefore never armed —
					// and this poll, the one that does run here, never read the
					// `tickets` list it is sent. The result was that a person
					// raising a case made no sound and no card on the exact
					// screen the operator sits on all day, while it worked on
					// Links and Settings. That is what "new tickets are not
					// alerting" was: not a missing tone, a missing caller.
					if (Array.isArray(res.data.tickets)) {
						if (!capsTicketSeeded) {
							// The first answer is the queue as it stands, not
							// news. Everything in it is recorded as seen so the
							// next ticket raised after this page loaded is the
							// first one that rings.
							capsTicketSeeded = true;
							res.data.tickets.forEach(function (t) {
								if (t && t.id) {
									capsTicketSeen[t.id] = 1;
								}
							});
						} else {
						var tix = res.data.tickets.filter(function (t) {
							if (!t || capsTicketSeen[t.id]) {
								return false;
							}
							capsTicketSeen[t.id] = 1;
							return true;
						});
						if (tix.length && !(cfg.adv && cfg.adv.ticketCard === 0)) {
							tix.slice(0, 3).forEach(function (t, i) {
								window.setTimeout(function () {
									showTicketCard(t);
								}, i * 90);
							});
							ticketTone();
						}
						}
					}

					if (Array.isArray(res.data.fresh) && res.data.fresh.length) {
						var fresh = res.data.fresh.filter(function (item) {
							if (capsSeen[item.id]) {
								return false;
							}
							capsSeen[item.id] = 1;
							// Only an answer earns a card — see the note in the
							// watcher above for why a plain open stays quiet.
							var kinds = (item && item.kinds) || [];
							return kinds.length > 0 || !!(item && item.media);
						});
						if (fresh.length) {
							if (away) {
								capsAway += fresh.length;
								// Remembered so the cards appear when the tab is
								// looked at again, rather than only counting in
								// the title and then being forgotten.
								capsQueued = capsQueued.concat(fresh).slice(-12);
								markTitle(capsAway);
								desktopNotify(fresh[0], fresh.length);
							} else {
								clAnnounce(fresh);
							}
						}
					}
					if (capsN && typeof res.data.total !== 'undefined') {
						capsN.textContent = res.data.total;
					}
					// The board above the wall. Each counter carries the value
					// it last showed, so only a number that actually moved is
					// re-painted and flashed — a poll every three seconds that
					// restarted every animation would make the board look like
					// it was guessing.
					if (res.data.tally && document.getElementById('cl-board')) {
						var tally = res.data.tally;
						var total = 0;
						Object.keys(tally).forEach(function (k) {
							total += Number(tally[k]) || 0;
						});
						Object.keys(tally).forEach(function (k) {
							var el = document.querySelector('[data-board="' + k + '"]');
							if (!el) {
								return;
							}
							var next = Number(tally[k]) || 0;
							if (el.getAttribute('data-val') === String(next)) {
								return;
							}
							el.setAttribute('data-val', String(next));
							el.textContent = next.toLocaleString();
							el.classList.remove('is-bumped');
							void el.offsetWidth;
							el.classList.add('is-bumped');
							var tile = el.closest('.cl-board__tile');
							var bar = tile && tile.querySelector('.cl-board__bar i');
							if (bar && total > 0) {
								bar.style.width = Math.round(next / total * 100) + '%';
							}
						});
						['flagged', 'lastHour'].forEach(function (k) {
							if (typeof res.data[k] === 'undefined') {
								return;
							}
							var el = document.querySelector('[data-board="' + k + '"]');
							if (!el || el.getAttribute('data-val') === String(res.data[k])) {
								return;
							}
							el.setAttribute('data-val', String(res.data[k]));
							el.textContent = Number(res.data[k]).toLocaleString();
							el.classList.remove('is-bumped');
							void el.offsetWidth;
							el.classList.add('is-bumped');
						});
					}
					if (capsStamp && res.data.time) {
						capsStamp.textContent = res.data.time;
					}
				}).catch(function () {
					capsBusy = false;
				});
			};

			// Three seconds: this is the screen an operator leaves open while
			// a link is live, and a capture that shows up half a minute late
			// Two seconds. The endpoint no longer walks every captured row to
			// answer, so a poll is cheap enough to run this often: the grid
			// markup, the count and the tallies all come off cached reads, and
			// a capture that appears within two seconds is effectively
			// instant. A tab in the background backs off on its own, so only
			// the screen somebody is watching pays this.
			steady(Math.max(1000, pollMs), capsTick);
			document.addEventListener('visibilitychange', backInView);
			window.addEventListener('focus', backInView);
		}

		/* ---- Selecting captures on the wall ---- */
		/*
		 * The boxes reach the form by the `form` attribute because the wall
		 * replaces its own innerHTML on every poll: a form wrapped around the
		 * cards would be destroyed with them. Everything here reads the grid
		 * fresh on each use for the same reason — the node list taken at load
		 * is stale after the first refresh.
		 */
		// Two pages show the same cards in a bulk form now: the monitoring
		// wall (which clears and hides) and All records (which deletes). The
		// machinery is identical, so it is written once and pointed at
		// whichever pair of elements this page actually has.
		var pickForm = document.getElementById('cl-caps-bulk') || document.getElementById('cl-records-form');
		var pickGrid = document.getElementById('cl-caps-grid') || document.querySelector('.cl-records__grid');
		var pickToggle = document.getElementById('cl-pick-toggle');
		if (pickForm && pickGrid && pickToggle) {
			var pickRun = document.getElementById('cl-pickrun');
			var pickHint = document.getElementById('cl-pickhint');
			var pickN = document.getElementById('cl-pickn');
			var pickClear = document.getElementById('cl-pickclear');
			var pickHide = document.getElementById('cl-pickhide');
			var pickDelete = document.getElementById('cl-pickdelete');
			var picking = false;

			// The toggle's own word, read from the markup rather than assumed.
			//
			// The two screens this serves do not offer the same thing: the
			// archive deletes, the wall clears and hides, so its button is
			// "Select". Writing a fixed "Delete records" back onto it left the
			// wall promising a delete it does not have. Whatever the server
			// printed is what is restored when the mode ends.
			var pickIdleLabel = (function () {
				var span = pickToggle.querySelector('span');
				return (span ? span.textContent : pickToggle.textContent) || 'Select';
			}());

			var pickBoxes = function () {
				return pickGrid.querySelectorAll('input[name="cl_pick[]"]');
			};

			var paintPick = function () {
				var n = 0;
				pickBoxes().forEach(function (b) {
					if (b.checked) {
						n += 1;
					}
					var card = b.closest('.cl-cap');
					if (card) {
						card.classList.toggle('is-picked', b.checked);
					}
				});
				if (pickN) {
					// The noun is the page's, not the component's: a card on
					// the wall is a capture, the same row on the archive is a
					// record. Saying "4 captures selected" on the screen whose
					// own heading reads "All records" is the sort of small
					// disagreement that makes an operator doubt the count.
					var noun = pickGrid.classList.contains('cl-records__grid') ? ' record' : ' capture';
					pickN.textContent = n
						? n + noun + (n === 1 ? ' selected' : 's selected')
						: 'Nothing selected';
				}
				if (pickClear) { pickClear.disabled = n === 0; }
				if (pickHide) { pickHide.disabled = n === 0; }
				if (pickDelete) { pickDelete.disabled = n === 0; }
			};

			var setPicking = function (on) {
				picking = !!on;
				pickGrid.classList.toggle('is-picking', picking);
				pickToggle.setAttribute('aria-pressed', picking ? 'true' : 'false');
				// The button has a glyph and a label now, so only the label's
				// text is replaced. Writing textContent here used to be safe
				// when the button was a word; against markup it would delete
				// the icon on the first press.
				var toggleLabel = pickToggle.querySelector('span');
				if (toggleLabel) {
					toggleLabel.textContent = picking ? 'Done' : pickIdleLabel;
				} else {
					pickToggle.textContent = picking ? 'Done' : pickIdleLabel;
				}
				if (pickRun) { pickRun.hidden = !picking; }
				if (pickHint) { pickHint.hidden = !picking; }
				if (!picking) {
					pickBoxes().forEach(function (b) { b.checked = false; });
				}
				paintPick();
			};

			pickToggle.addEventListener('click', function () {
				setPicking(!picking);
			});

			// The boxes are inside the grid and only reach the form through
			// the `form` attribute, which does not carry events: a change
			// bubbles up the DOM, not across an association. So it is heard on
			// the grid, whose element survives every poll even though its
			// children do not.
			pickGrid.addEventListener('change', function (ev) {
				if (ev.target && ev.target.name === 'cl_pick[]') {
					paintPick();
				}
			});

			var pickAll = document.getElementById('cl-pickall');
			if (pickAll) {
				pickAll.addEventListener('click', function () {
					pickBoxes().forEach(function (b) { b.checked = true; });
					paintPick();
				});
			}
			var pickNone = document.getElementById('cl-picknone');
			if (pickNone) {
				pickNone.addEventListener('click', function () {
					pickBoxes().forEach(function (b) { b.checked = false; });
					paintPick();
				});
			}

			// No submit handler here.
			//
			// There used to be one, and the panel already has a handler that
			// does the same job for every destructive form in the console —
			// the one that counts the ticked rows and asks for the word DELETE
			// above ten. Having both meant "Delete selected" asked its
			// question twice, one dialog behind the other, which is the kind
			// of double prompt an operator dismisses twice without reading
			// either. The shared handler is the one that knows how many rows
			// are really going, so it is the only one that asks.

			// The records that are going, going visibly.
			//
			// The press leaves the page for the server's answer a moment
			// later, so the eye only catches the very start of this. It still
			// matters: without it the screen freezes for a whole round trip
			// with every tick still showing, which reads as a button that did
			// nothing. The cards fade out, the bar says how many are leaving,
			// and the request goes through underneath.
			pickForm.addEventListener('submit', function (ev) {
				if (ev.defaultPrevented) {
					return;
				}
				var btn = ev.submitter || document.activeElement;
				if (!btn || String(btn.name || '') !== 'cl_action') {
					return;
				}
				var going = 0;
				pickBoxes().forEach(function (b) {
					if (!b.checked) {
						return;
					}
					going++;
					var card = b.closest('.cl-cap');
					if (card) {
						card.classList.add('is-leaving');
					}
				});
				if (!going) {
					return;
				}
				if (pickN) {
					var noun = pickGrid.classList.contains('cl-records__grid') ? ' record' : ' capture';
					pickN.textContent = 'Removing ' + going + noun + (going === 1 ? '…' : 's…');
				}
				// The buttons are struck through after the payload has been
				// collected, not during. A submit button disabled inside its
				// own submit event is dropped from the form's data by most
				// browsers, and this one carries cl_action in its value — the
				// server would receive a delete with no action on it.
				window.setTimeout(function () {
					Array.prototype.forEach.call(
						pickForm.querySelectorAll('button[type="submit"]'),
						function (b) { b.disabled = true; }
					);
				}, 0);
			});

			// A poll replaces the cards, so the painted state has to be put
			// back on the new ones. The mode itself is kept: an operator who
			// is selecting should not lose the mode because a visitor arrived.
			if (window.MutationObserver) {
				new MutationObserver(function () {
					if (picking) {
						pickGrid.classList.add('is-picking');
					}
					paintPick();
				}).observe(pickGrid, { childList: true });
			}

			paintPick();
		}

		/* ---- Link type switching ---- */
		var typeCards = document.querySelectorAll('.cl-type-card input[name="cl[link_type]"]');
		var fields = document.querySelectorAll('[data-when]');

		function applyType(type) {
			typeCards.forEach(function (input) {
				var card = input.closest('.cl-type-card');
				if (card) {
					card.classList.toggle('is-checked', input.value === type);
				}
			});
			fields.forEach(function (field) {
				var allowed = (field.getAttribute('data-when') || '').split(/\s+/);
				field.hidden = allowed.indexOf(type) === -1;
			});
		}

		if (typeCards.length) {
			typeCards.forEach(function (input) {
				input.addEventListener('change', function () {
					applyType(input.value);
					if (typeof refreshActivePreview === 'function') {
						refreshActivePreview();
					}
				});
			});
			var checked = document.querySelector('.cl-type-card input:checked');
			applyType(checked ? checked.value : 'redirect');
		}

		/* ---- Expiry presets ---- */
		var expiry = document.getElementById('cl-expiry');
		document.querySelectorAll('.cl-chipbtn[data-hours]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (!expiry) {
					return;
				}
				document.querySelectorAll('.cl-chipbtn[data-hours]').forEach(function (b) {
					b.classList.remove('is-on');
				});
				btn.classList.add('is-on');

				var hours = parseInt(btn.getAttribute('data-hours'), 10) || 0;
				if (hours === 0) {
					expiry.value = '';
					return;
				}
				var d = new Date(Date.now() + hours * 3600 * 1000);
				var pad = function (n) {
					return (n < 10 ? '0' : '') + n;
				};
				expiry.value = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) +
					'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
			});
		});

		/* ---- Separate WhatsApp preview cards for each link type ---- */
		var dest = document.getElementById('cl-destination');
		var instagramDest = document.getElementById('cl-instagram-url');
		var documentPreviewUrl = document.getElementById('cl-document-preview-url');
		var instagramPreviewUrl = document.getElementById('cl-instagram-preview-url');
		var previewJobs = [];

		function wirePreview( inputElements, getUrl, blockId, prefix ) {
			var block = document.getElementById(blockId);
			if ( ! block ) { return function () {}; }
			var timer = null;
			var requestId = 0;
			var host = document.getElementById(prefix + '-host');
			var path = document.getElementById(prefix + '-path');
			var icon = document.getElementById(prefix + '-icon');
			var title = document.getElementById(prefix + '-title');
			var description = document.getElementById(prefix + '-description');
			var site = document.getElementById(prefix + '-site');
			var image = document.getElementById(prefix + '-image');

			function update() {
				window.clearTimeout(timer);
				var selected = document.querySelector('.cl-type-card input[name="cl[link_type]"]:checked');
				var currentType = selected ? selected.value : 'redirect';
				var allowedType = block.getAttribute('data-when') || '';
				var allowed = allowedType.split(/\s+/).indexOf(currentType) !== -1;
				var value = getUrl();
				var thisRequest = ++requestId;
				block.hidden = ! allowed || ! value || value.length < 8;
				if ( block.hidden ) { return; }
				timer = window.setTimeout(function () {
					ajax('cloaklink_preview', { url: value }).then(function (res) {
						if ( thisRequest !== requestId ) { return; }
						if ( ! res || ! res.success || ! res.data ) { block.hidden = true; return; }
						var data = res.data;
						block.hidden = false;
						if ( host ) { host.textContent = data.host || ''; }
						if ( path ) {
							// Show the exact URL used to build this WhatsApp preview.
							// The generated Credit Control short link remains the visitor
							// click-through URL, but it is not the preview source.
							path.textContent = value;
						}
						if ( icon ) { icon.src = data.icon || ''; icon.hidden = ! data.icon; }
						if ( title ) { title.textContent = data.title || data.host || ''; }
						if ( description ) { description.textContent = data.description || ''; }
						if ( site ) { site.textContent = data.site_name || data.host || ''; }
						if ( image ) { image.src = data.image || ''; image.hidden = ! data.image; }
					}).catch(function () {
						if ( thisRequest === requestId ) { block.hidden = true; }
					});
				}, 420);
			}

			inputElements.forEach(function (input) {
				if ( input ) { input.addEventListener('input', update); }
			});
			previewJobs.push(update);
			return update;
		}

		wirePreview([dest], function () { return dest ? dest.value.trim() : ''; }, 'cl-url-preview', 'cl-preview');
		wirePreview([instagramDest, instagramPreviewUrl], function () {
			var custom = instagramPreviewUrl ? instagramPreviewUrl.value.trim() : '';
			return custom || (instagramDest ? instagramDest.value.trim() : '');
		}, 'cl-instagram-preview-card', 'cl-instagram-preview');
		// A document link's card comes from its own preview source when one is
		// given, and otherwise from this site's document page. Before, the card
		// was hidden until a separate preview URL was typed, so a document link
		// showed no preview at all — the exact case reported.
		// A document card is built from the page the document came from, and
		// only from it. Falling back to this site's own address showed a card
		// with this service's name on it, which is not what the recipient sees.
		wirePreview([documentPreviewUrl], function () {
			return documentPreviewUrl ? documentPreviewUrl.value.trim() : '';
		}, 'cl-document-preview-card', 'cl-document-preview');

		function refreshActivePreview() {
			previewJobs.forEach(function (update) { update(); });
		}
		refreshActivePreview();

		/* ---- Domain picker and extension on the slug field ---- */
		// The address under the slug is only a preview, but it is the address the
		// operator copies, so it has to follow the domain they pick and the
		// extension they choose. Both are held in data-slug, which never carries
		// an extension, so the two choices cannot compound into "…pdf.pdf".
		var domainSelect = document.getElementById('cl-domain');
		var slugPreview = document.getElementById('cl-url-static');
		var extSelect = document.getElementById('cl-extension');
		var shareLink = document.getElementById('cl-sharelink');
		var shareCopy = document.getElementById('cl-sharelink-copy');

		function withExtension(base, ext) {
			if (!base) {
				return '';
			}
			return ext ? base + '.' + ext : base;
		}

		function paintAddress() {
			var ext = extSelect ? extSelect.value : '';
			var base = slugPreview ? (slugPreview.getAttribute('data-slug') || '') : '';
			if (slugPreview && base) {
				slugPreview.textContent = withExtension(base, ext);
			}
			var shareBase = shareLink ? (shareLink.getAttribute('data-slug') || '') : '';
			if (shareBase) {
				var address = withExtension(shareBase, ext);
				if (shareLink) {
					shareLink.textContent = address;
				}
				if (shareCopy) {
					shareCopy.setAttribute('data-clipboard', address);
				}
			}
		}

		if (extSelect) {
			extSelect.addEventListener('change', paintAddress);
		}

		if (domainSelect && slugPreview) {
			domainSelect.addEventListener('change', function () {
				var base = slugPreview.getAttribute('data-slug') || '';
				var match = base.match(/^https?:\/\/[^\/]+(\/.*)$/);
				if (!match) {
					return;
				}
				// Whatever follows the host: "/go/auto-generated".
				var scheme = /^https:/.test(base) ? 'https' : 'http';
				slugPreview.setAttribute('data-slug', scheme + '://' + domainSelect.value + match[1]);
				paintAddress();
			});
		}

		/* ---- Bulk selection ---- */
		//
		// Two things were wrong here, and both could delete something the
		// operator could not see.
		//
		// First, the row boxes were found with `document.querySelectorAll
		// ('.cl-check')`. The same class was used for an unrelated checkbox on
		// the Settings screen and for labels elsewhere, so the list could
		// contain a node that is not a row box at all — the count was then
		// wrong and "select all" and the rows drifted apart. The boxes are now
		// found inside this form only, by a class nothing else uses.
		//
		// Second, the select-all box had two states. With some rows ticked it
		// still looked unticked, so pressing it cleared the two rows that were
		// chosen instead of choosing the rest — the opposite of what a person
		// reads from it. It now paints the three states properly.
		var checkAll = document.getElementById('cl-check-all');
		var bulkScope = checkAll ? (checkAll.closest('form') || document) : document;
		var boxes = [].slice.call(bulkScope.querySelectorAll('.cl-row-select'));
		var bar = document.getElementById('cl-bulkbar');
		var countEl = document.getElementById('cl-bulk-count');

		function refreshBulk() {
			var n = 0;
			boxes.forEach(function (b) {
				if (b.checked) {
					n++;
				}
			});
			// The total is the rows the browser can actually see, counted here
			// rather than read from a server-rendered constant: a row can be
			// removed from the table by a filter chip without the page being
			// rebuilt, and a stale total is how "select all" ends up claiming
			// more rows than exist.
			var total = boxes.length;
			if (bar) {
				bar.hidden = n === 0;
			}
			if (countEl) {
				countEl.textContent = n;
			}
			var ofEl = document.getElementById('cl-bulk-of');
			if (ofEl) {
				ofEl.textContent = total ? ' of ' + total + ' on this page' : '';
			}
			if (checkAll) {
				checkAll.checked = total > 0 && n === total;
				checkAll.indeterminate = n > 0 && n < total;
				// A list with nothing on it must not offer a master box that
				// reads as "select all" of an empty set.
				checkAll.disabled = total === 0;
			}
			// Single-record buttons reuse the same form; clear the hidden id then.
			var single = document.getElementById('cl-single-id');
			if (single && n > 0) {
				single.value = '';
			}
		}

		if (checkAll) {
			checkAll.addEventListener('change', function () {
				// With some rows ticked, pressing the box means "take the rest
				// as well", not "drop what I have already chosen".
				var target = checkAll.indeterminate ? true : checkAll.checked;
				boxes.forEach(function (b) {
					b.checked = target;
				});
				refreshBulk();
			});
		}
		boxes.forEach(function (b) {
			b.addEventListener('change', refreshBulk);
		});
		// A selection belongs to the rows on screen. Coming back to a filtered
		// or paged list must not leave a tick behind on a row the operator can
		// no longer see — that is how a bulk delete takes the wrong record.
		//
		// The browser already drops the ticks on a real navigation, so this is
		// about the case where a filter is applied without one: the rows that
		// do not match are hidden, their boxes go with them, and what is left
		// selected is a subset the operator never chose. When that happens the
		// selection is cleared and said out loud, because a count quietly
		// dropping from six to two is worse than either keeping or losing it.
		var scopeEl = document.getElementById('cl-bulk-scope');
		var bulkWarnEl = null;
		var bulkWarn = function (msg) {
			if (!bulkWarnEl) {
				bulkWarnEl = document.createElement('div');
				bulkWarnEl.className = 'cl-flash cl-flash--bad';
				bulkWarnEl.setAttribute('role', 'status');
				if (bar && bar.parentNode) {
					bar.parentNode.insertBefore(bulkWarnEl, bar);
				} else if (scopeEl && scopeEl.parentNode) {
					scopeEl.parentNode.insertBefore(bulkWarnEl, scopeEl);
				}
			}
			bulkWarnEl.textContent = msg;
			bulkWarnEl.hidden = false;
		};

		// Losing a row silently is the failure this guards against.
		//
		// A watched table can drop rows without the page reloading — a poll
		// repaint, or the yield filter hiding the ones that have collected
		// nothing. Each of those used to leave `boxes` pointing at elements
		// that no longer existed while the operator's mental count stayed
		// where it was. Whenever the set of boxes changes size, a selection
		// that no longer covers every box is re-checked: if any ticked box has
		// gone, the whole selection is dropped and the operator is told.
		if (window.MutationObserver && bulkScope && bulkScope.nodeType === 1) {
			var knownBoxes = boxes.slice();
			var watchBoxes = function () {
				var now = [].slice.call(bulkScope.querySelectorAll('.cl-row-select'));
				var live = now.length;
				if (live === knownBoxes.length) {
					return;
				}
				var ticked = knownBoxes.filter(function (b) { return b.checked; });
				var gone = ticked.filter(function (b) { return now.indexOf(b) === -1; });
				knownBoxes = now;
				boxes = now;
				if (gone.length && live) {
					now.forEach(function (b) { b.checked = false; });
					bulkWarn(
						gone.length === 1
							? 'A row you had selected is no longer on this page, so the selection was cleared. Tick the rows again.'
							: gone.length + ' rows you had selected are no longer on this page, so the selection was cleared. Tick the rows again.'
					);
				}
				refreshBulk();
			};
			new MutationObserver(watchBoxes).observe(bulkScope, { childList: true, subtree: true });
		}

		refreshBulk();

		var deleteBtn = document.getElementById('cl-bulk-delete');
		if (deleteBtn) {
			deleteBtn.addEventListener('click', function (ev) {
				var n = 0;
				boxes.forEach(function (b) {
					if (b.checked) {
						n++;
					}
				});
				if (n > 0 && !window.confirm(i18n.confirm || 'Delete the selected links?')) {
					ev.preventDefault();
				}
			});
		}

		var bulkForm = document.getElementById('cl-bulk-form');
		if (bulkForm) {
			bulkForm.addEventListener('submit', function () {
				var single = document.getElementById('cl-single-id');
				if (single && single.value && single.value !== '') {
					// A row button was used: disable the bulk checkboxes so only
					// the clicked record is affected.
					boxes.forEach(function (b) {
						b.disabled = true;
					});
				}
			});
		}

		/* ---- Geo self test ---- */
		var testBtn = document.getElementById('cl-test-geo');
		var testOut = document.getElementById('cl-test-geo-out');
		if (testBtn && testOut) {
			testBtn.addEventListener('click', function () {
				testBtn.disabled = true;
				testBtn.textContent = 'Checking…';
				ajax('cloaklink_test_geo', {}).then(function (res) {
					testOut.hidden = false;
					testOut.textContent = JSON.stringify(res, null, 2);
				}).catch(function (err) {
					testOut.hidden = false;
					testOut.textContent = String(err);
				}).then(function () {
					testBtn.disabled = false;
					testBtn.textContent = 'Test my IP lookup';
				});
			});
		}
	});
	/**
	 * The access code fields.
	 *
	 * Six digits, so a letter is simply not accepted and the two fields can be
	 * compared before the form is sent. Without the comparison the operator
	 * types a code twice, one of them wrong, saves, is told "saved", and finds
	 * out at the lock.
	 */
	ready(function () {
		var one = document.getElementById('cl-access-code');
		var two = document.getElementById('cl-access-code-2');
		if (!one || !two) {
			return;
		}

		function digits(el) {
			var raw = String(el.value || '').replace(/\D/g, '').slice(0, 6);
			if (raw !== el.value) {
				el.value = raw;
			}
			return raw;
		}

		[one, two].forEach(function (el) {
			el.addEventListener('input', function () {
				digits(el);
				one.parentNode.classList.remove('is-bad');
			});
		});

		var form = one.closest('form');
		if (form) {
			form.addEventListener('submit', function (e) {
				digits(one);
				digits(two);
				// An empty pair means "leave the code alone".
				if (!one.value && !two.value) {
					return;
				}
				if (one.value !== two.value || 6 !== one.value.length) {
					e.preventDefault();
					one.parentNode.classList.add('is-bad');
					var help = document.getElementById('cl-code-help');
					if (help) {
						help.textContent = 'The two codes do not match, or one is not six digits. They must be the same six digits.';
					}
					one.focus();
				}
			});
		}
	});
})();

/**
 * Photograph lightbox.
 *
 * The stills are small in the session card. A click opens the real file,
 * full size, with a Download button and Esc to close. Nothing is added to the
 * DOM until a photograph is opened, so a page with no media costs nothing.
 */
(function () {
	'use strict';

	var box = null;

	function close() {
		if (!box) {
			return;
		}
		box.parentNode.removeChild(box);
		box = null;
		document.body.style.overflow = '';
		document.removeEventListener('keydown', onKey, true);
	}

	function onKey(e) {
		if ('Escape' === e.key) {
			close();
		}
	}

	function open(src, dl, name) {
		close();
		box = document.createElement('div');
		box.className = 'cl-lightbox';

		var img = document.createElement('img');
		img.src = src;
		img.alt = name || '';
		box.appendChild(img);

		var bar = document.createElement('div');
		bar.className = 'cl-lightbox__bar';

		var save = document.createElement('a');
		save.className = 'cl-lightbox__btn';
		save.href = dl;
		save.setAttribute('download', '');
		save.textContent = 'Download';
		bar.appendChild(save);

		var shut = document.createElement('button');
		shut.type = 'button';
		shut.className = 'cl-lightbox__btn';
		shut.textContent = 'Close';
		shut.addEventListener('click', close);
		bar.appendChild(shut);

		box.appendChild(bar);
		box.addEventListener('click', function (e) {
			if (e.target === box) {
				close();
			}
		});
		document.body.style.overflow = 'hidden';
		document.addEventListener('keydown', onKey, true);
		document.body.appendChild(box);
	}

	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.cl-gallery__open') : null;
		if (!btn) {
			return;
		}
		e.preventDefault();
		open(btn.getAttribute('data-full'), btn.getAttribute('data-dl'), btn.getAttribute('data-name'));
	});

	/* ---- Smart monitoring: tick rows, then delete or download just those ---- */
	(function () {
		var bar = document.getElementById('cl-supbulk-bar');
		var countEl = document.getElementById('cl-supbulk-n');
		var clearBtn = document.getElementById('cl-supbulk-clear');
		var delBtn = document.getElementById('cl-supbulk-del');
		if (!bar) {
			return;
		}

		// Scoped to the ledger's own form, not the whole document. A second
		// list on this page — or a future screen reusing the class — must not
		// be counted into this bar's total, because the number on the bar is
		// what a delete is pressed on.
		//
		// The rows are not inside the form: each checkbox joins it by its
		// `form` attribute, so the form can be replaced by a live refresh
		// without the rows going with it. That makes closest('form') the wrong
		// scope here, and the form's own id the right one.
		var formEl = bar.closest('form');
		var formId = formEl ? formEl.id : '';
		var boxes = function () {
			var list = formId
				? '[form="' + formId + '"].cl-sup-check'
				: '.cl-sup-check';
			return Array.prototype.slice.call(document.querySelectorAll(list));
		};

		function picked() {
			return boxes().filter(function (b) {
				return b.checked;
			}).map(function (b) {
				return b.value;
			});
		}

		function refresh() {
			var ids = picked();
			bar.hidden = ids.length === 0;
			if (countEl) {
				countEl.textContent = String(ids.length);
			}
			// Each download link carries its nonce already; the ids are added
			// here so the file covers exactly the ticked rows.
			Array.prototype.forEach.call(document.querySelectorAll('.cl-supbulk__fmt'), function (a) {
				var base = a.getAttribute('data-base') || '';
				a.href = ids.length ? base + '&ids=' + encodeURIComponent(ids.join(',')) : base;
			});
		}

		document.addEventListener('change', function (e) {
			if (e.target && e.target.classList && e.target.classList.contains('cl-sup-check')) {
				refresh();
			}
		});

		// A click on the checkbox must not also open the row it sits in.
		document.addEventListener('click', function (e) {
			var pick = e.target && e.target.closest ? e.target.closest('.cl-pick') : null;
			if (pick) {
				e.stopPropagation();
			}
		}, true);

		if (clearBtn) {
			clearBtn.addEventListener('click', function () {
				boxes().forEach(function (b) {
					b.checked = false;
				});
				refresh();
			});
		}

		if (delBtn) {
			delBtn.addEventListener('click', function (e) {
				var n = picked().length;
				if (!n) {
					e.preventDefault();
					return;
				}
				var msg = 'Delete the ' + n + ' selected session' + (n === 1 ? '' : 's') + ', with their voice notes and photographs? This cannot be undone.';
				if (!window.confirm(msg)) {
					e.preventDefault();
				}
			});
		}

		refresh();
	})();

	/* ---- Idle lock ----
	 *
	 * Sits beside the other feature blocks rather than inside them, but still
	 * within this file's outer closure so it shares `cfg`.
	 */
	(function () {
		var lock = document.getElementById('cl-lock');
		var form = document.getElementById('cl-lock-form');
		var input = document.getElementById('cl-lock-code');
		var noteEl = document.getElementById('cl-lock-note');

		function note(text, kind) {
			if (!noteEl) {
				return;
			}
			noteEl.textContent = text || '';
			noteEl.className = 'cl-lock__note' + (kind ? ' cl-lock__note--' + kind : '');
		}
		var conf = (window.CLOAKLINK && window.CLOAKLINK.lock) || {};
		if (!lock || !form || !input) {
			return;
		}

		// A minute is the shortest setting the screen offers. Anything less is
		// a locked panel nobody can use, so the floor is enforced here too.
		var idleMs = Math.max(60000, (parseInt(conf.minutes, 10) || 10) * 60000);
		// Give a visitor a warning a little before it goes.
		var warnMs = Math.max(20000, Math.min(60000, Math.round(idleMs * 0.2)));
		var last = Date.now();
		var timer = null;
		var locked = false;
		var checking = false;
		var fill = document.getElementById('cl-lock-fill');

		var cellsEl = document.getElementById('cl-lock-cells');
		var lastLen = 0;

		// A password is redacted in the cells; a code is shown digit by digit.
		// The panel asks for one or the other (conf.kind), and the cells are
		// told once so the mark is a dot in the password case and the real
		// character otherwise.
		if (cellsEl && 'password' === conf.kind) {
			cellsEl.className = 'cl-lock__cells is-secret';
		}

		/**
		 * Paint the row from what has been typed.
		 *
		 * The six cells are fixed and always drawn (see the markup); this only
		 * fills them. It used to build the row to length, which meant a locked
		 * panel showed one lone box until somebody typed into it — and if the
		 * repaint was missed for any reason, the row stayed at one box while
		 * the operator typed a whole code into an invisible field.
		 *
		 * A cell shows the digit once it is past; the cell the next character
		 * lands in is lit and carries the caret. Nothing here reads the code's
		 * real length, so the row still says nothing about how many are wanted
		 * beyond the six it can show.
		 */
		function paintCells(len) {
			if (!cellsEl) {
				return;
			}
			var typed = Math.max(0, Math.min(cellsEl.children.length, Number(len) || 0));
			var raw = String((input && input.value) || '');
			for (var j = 0; j < cellsEl.children.length; j++) {
				var cell = cellsEl.children[j];
				cell.className = j < typed ? 'is-filled' : (j === typed ? 'is-next' : '');
				// The character itself, so the row reads as what was typed
				// rather than as a count of dots. It is redacted by CSS when
				// the kind is a password.
				cell.setAttribute('data-ch', j < typed ? raw.charAt(j) : '');
			}
			// The typed digit, briefly, so the eye sees it land. This reads
			// lastLen but does not write it: the caller owns that, because it
			// also uses the same comparison to decide whether to click. Two
			// writers to one counter made the click never fire.
			if (typed > lastLen && cellsEl.children[typed - 1]) {
				var hit = cellsEl.children[typed - 1];
				hit.classList.add('is-pop');
				window.setTimeout(function () {
					hit.classList.remove('is-pop');
				}, 300);
			}
		}

		function setBar(pct) {
			if (fill) {
				fill.style.width = Math.max(0, Math.min(100, pct)) + '%';
			}
		}

		var accountEl = lock ? lock.querySelector('.cl-lock__account') : null;

		function state(kind) {
			var bar = document.getElementById('cl-lock-progress');
			if (bar) {
				bar.className = 'cl-lock__progress' + (kind ? ' is-' + kind : '');
			}
			var cells = document.getElementById('cl-lock-cells');
			if (cells) {
				cells.className = 'cl-lock__cells' + (kind ? ' is-' + kind : '');
			}
			// The avatar's ring carries the same answer as the cells, so the
			// screen has two places to see "checking" and "refused" rather
			// than one strip at the bottom.
			if (accountEl) {
				accountEl.className = 'cl-lock__account' + (kind ? ' is-' + kind : '');
			}
		}

		/* ---- The clock on the status line ----
		 * A minute and a second, ticking. Cheap, and it is what makes the
		 * cover look alive while it waits.
		 */
		var clockEl = document.getElementById('cl-lock-tele-clock');
		var clockTimer = null;
		function tickClock() {
			if (!clockEl) {
				return;
			}
			var d = new Date();
			var hh = d.getHours();
			var mm = d.getMinutes();
			var ss = d.getSeconds();
			clockEl.textContent =
				(hh < 10 ? '0' : '') + hh + ':' +
				(mm < 10 ? '0' : '') + mm + ':' +
				(ss < 10 ? '0' : '') + ss;
		}

		/* ---- The glyph rain ----
		 * A canvas of falling characters, drawn at a low frame rate on a
		 * half-scale buffer: it is scenery behind a dialog, not a game, and
		 * a cover that spins a fan up is worse than a plain one. It runs
		 * only while the cover is up, and not at all under reduced motion.
		 */
		var rain = document.getElementById('cl-lock-rain');
		var rainRaf = null;
		var rainCtx = null;
		var drops = [];
		var rainCols = 0;
		var rainRows = 0;
		var GLYPHS = '01ACCESSGRANTEDSECURED0123456789ABCDEF';
		var still = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

		function rainSetup() {
			if (!rain || still) {
				return;
			}
			var w = lock.clientWidth || window.innerWidth;
			var h = lock.clientHeight || window.innerHeight;
			var scale = 0.5;
			rain.width = Math.max(1, Math.round(w * scale));
			rain.height = Math.max(1, Math.round(h * scale));
			rainCtx = rain.getContext('2d');
			if (!rainCtx) {
				return;
			}
			rainCols = Math.max(1, Math.floor(rain.width / 9));
			rainRows = Math.max(1, Math.floor(rain.height / 15));
			drops = [];
			for (var i = 0; i < rainCols; i++) {
				drops.push({
					y: Math.random() * rainRows,
					speed: 0.35 + Math.random() * 0.9,
					len: 3 + Math.floor(Math.random() * 7),
					last: 0
				});
			}
		}

		function rainFrame(now) {
			rainRaf = window.requestAnimationFrame(rainFrame);
			// Ten frames a second is enough for falling characters and barely
			// registers as a cost.
			if (now - (rain.last || 0) < 100) {
				return;
			}
			rain.last = now;
			if (!rainCtx) {
				return;
			}
			rainCtx.fillStyle = 'rgba(4, 8, 11, 0.16)';
			rainCtx.fillRect(0, 0, rain.width, rain.height);
			rainCtx.font = '10px ui-monospace, Menlo, monospace';
			for (var i = 0; i < drops.length; i++) {
				var d = drops[i];
				var head = Math.floor(d.y);
				for (var k = 0; k < d.len; k++) {
					var row = head - k;
					if (row < 0 || row > rainRows) {
						continue;
					}
					var ch = GLYPHS.charAt((i * 31 + row * 7 + Math.floor(now / 400)) % GLYPHS.length);
					rainCtx.fillStyle = k === 0
						? 'rgba(120, 255, 212, 0.55)'
						: 'rgba(22, 224, 161, ' + (0.3 * (1 - k / d.len)).toFixed(3) + ')';
					rainCtx.fillText(ch, i * 9, row * 15);
				}
				d.y += d.speed;
				if (d.y > rainRows + d.len) {
					d.y = -Math.random() * 6;
					d.speed = 0.35 + Math.random() * 0.9;
					d.len = 3 + Math.floor(Math.random() * 7);
				}
			}
		}

		function rainStart() {
			if (!rain || still || rainRaf) {
				return;
			}
			rainSetup();
			if (!rainCtx) {
				return;
			}
			rainRaf = window.requestAnimationFrame(rainFrame);
		}

		function rainStop() {
			if (rainRaf) {
				window.cancelAnimationFrame(rainRaf);
				rainRaf = null;
			}
		}

		/* ---- Keys ----
		 * A short click on each digit, and one flat note when the code is
		 * refused. Optional: the sound switch in the panel header governs it,
		 * and a browser that has not been gestured open simply stays quiet.
		 */
		function blip(hz) {
			// One audio context and one Alert switch for the whole page: this
			// block sits in its own closure, so it borrows the chime the alert
			// module already owns rather than opening a second context. A
			// browser without audio, or with the switch off, simply stays
			// quiet — the screen has nothing that depends on the sound.
			var shared = window.CLOAKLINK && window.CLOAKLINK.soundBeep;
			if (typeof shared === 'function') {
				shared(hz);
			}
		}

		// The lock survives a reload. Reloading the tab is the first thing
		// anyone does to a screen they were not expecting, and a lock that a
		// refresh lifts is decoration.
		var KEY = 'cloaklink.locked';
		var stored = false;
		try {
			stored = '1' === window.sessionStorage.getItem(KEY);
		} catch (e) {
			stored = false;
		}

		function cover() {
			if (locked) {
				return;
			}
			locked = true;
			try {
				window.sessionStorage.setItem(KEY, '1');
			} catch (e) {
				/* private mode: the lock still covers this page */
			}
			lock.hidden = false;
			document.documentElement.style.overflow = 'hidden';
			lock.classList.remove('is-open');
			// One low note as the cover drops. It is the opposite of the
			// capture alert — the screen has just gone private — and it is
			// short and low so it can never be taken for a new capture.
			//
			// The audio context belongs to the block above this one, which
			// publishes its beep on the shared config. This closure cannot
			// reach the context itself, so it asks for the note through that
			// hook: the same context, the same gesture-unlock, no second
			// AudioContext opened behind a lock screen.
			blip(392);
			tickClock();
			if (!clockTimer) {
				clockTimer = window.setInterval(tickClock, 1000);
			}
			// The canvas needs a laid-out cover to size itself from, which it
			// does not have until the next frame.
			window.requestAnimationFrame(rainStart);
			// Every lock starts from a clean field. Without this a second lock
			// in the same tab inherits the state of the first — the field
			// disabled and `checking` still true — and refuses to verify
			// anything until a reload.
			reset();
			// The field is focused once the cover has painted: focusing a
			// hidden input scrolls the page underneath it on some browsers.
			window.setTimeout(function () {
				input.focus();
			}, 60);
		}

		function uncover() {
			locked = false;
			checking = false;
			input.disabled = false;
			try {
				window.sessionStorage.removeItem(KEY);
			} catch (e) {
				/* nothing to clear */
			}
			lock.hidden = true;
			document.documentElement.style.overflow = '';
			lock.classList.remove('is-open');
			rainStop();
			if (clockTimer) {
				window.clearInterval(clockTimer);
				clockTimer = null;
			}
			touch();
		}

		function touch() {
			last = Date.now();
		}

		function check() {
			if (locked) {
				return;
			}
			var idle = Date.now() - last;
			if (idle >= idleMs) {
				cover();
			} else if (idle >= idleMs - warnMs && noteEl && !noteEl.textContent) {
				note('Locking shortly…', 'warn');
			}
		}

		// Any of these is a person using the panel. Scrolling counts: reading a
		// long session list is work, and a panel that locked while being read
		// would be worse than one left open.
		['mousemove', 'mousedown', 'keydown', 'wheel', 'touchstart', 'scroll', 'focus'].forEach(function (name) {
			document.addEventListener(name, touch, { passive: true });
		});

		// A tab left in the background for an hour has not been *used* for an
		// hour, so coming back to it must ask again rather than trust the
		// clock that was frozen while it slept.
		document.addEventListener('visibilitychange', function () {
			if (document.hidden) {
				return;
			}
			check();
		});

		timer = window.setInterval(check, 5000);
		window.addEventListener('beforeunload', function () {
			window.clearInterval(timer);
		});

		function reset() {
			input.value = '';
			paintCells(0);
			input.disabled = false;
			checking = false;
			setBar(0);
			state('');
			note('');
			input.focus();
		}

		function attempt() {
			var value = String(input.value || '').trim();
			if (!value || checking) {
				return;
			}

			checking = true;
			input.disabled = true;
			setBar(100);
			state('busy');
			note('Verifying…');

			var body = new URLSearchParams();
			body.append('action', 'cloaklink_unlock');
			body.append('nonce', conf.nonce || '');
			body.append('code', value);

			fetch(conf.ajax, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body.toString()
			})
				.then(function (res) {
					return res.json();
				})
				.then(function (res) {
					if (res && res.success) {
						checking = false;
						input.disabled = false;
						state('ok');
						note('Access granted');
						blip(1046);
						// A beat on the acceptance, so the answer is seen before
						// the panel reappears under it, then the frame closes.
						window.setTimeout(function () {
							lock.classList.add('is-open');
						}, 260);
						window.setTimeout(uncover, 700);
						return;
					}
					var why = res && res.data && res.data.message;
					state('bad');
					blip(196);
					note(
						'wait' === why
							? 'Too many attempts. Wait a few minutes, then try again.'
							: 'That was not accepted.',
						'bad'
					);
					window.setTimeout(reset, 900);
				})
				.catch(function () {
					state('bad');
					note('The panel could not be reached. Try again.', 'bad');
					window.setTimeout(reset, 1400);
				});
		}

		// Typing fills the bar by length alone — the bar never says how many
		// characters are wanted, only that something is happening. The length
		// is bounded by a generous ceiling, not by the code's real length,
		// which this page does not know.
		input.addEventListener('input', function () {
			var raw = String(input.value || '').replace(/[^0-9A-Za-z]/g, '');
			if (raw !== input.value) {
				input.value = raw;
			}
			paintCells(raw.length);
			if (raw.length !== lastLen) {
				// The comparison has to be made before the counter moves, or
				// every keystroke reads as neither longer nor shorter and the
				// rising note is never played.
				blip(raw.length > lastLen ? 660 : 520);
				lastLen = raw.length;
			}
			setBar(Math.min(90, raw.length * 12));
			if (!checking) {
				state('');
				note('');
			}
		});

		// The cells are the visible field, and the real input is a hidden
		// element beside them. A tap on the cells has to reach it, or the
		// screen looks like it accepts typing and does not.
		if (cellsEl) {
			cellsEl.addEventListener('click', function () {
				input.focus();
			});
		}

		// Enter is the only key this screen needs, and it is enough on a
		// keyboard. On a phone the field's own Go key does the same.
		input.addEventListener('keydown', function (e) {
			if ('Enter' === e.key) {
				e.preventDefault();
				attempt();
			}
		});

		// Auto-verify. The code is six digits by definition, so the sixth digit
		// submits it: there is no button to press and no length for this page
		// to hide, because the person typing it is the one who chose it. A
		// password is not a fixed shape, so it still waits for Enter.
		var CODE_LEN = 6;
		input.addEventListener('input', function () {
			if ('password' === conf.needs) {
				return;
			}
			if (String(input.value || '').length >= CODE_LEN) {
				// A beat, so the last cell is seen filled before the screen
				// changes; short enough not to feel like waiting.
				window.setTimeout(function () {
					if (!checking && String(input.value || '').length >= CODE_LEN) {
						attempt();
					}
				}, 120);
			}
		});

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			attempt();
		});

		// The panel opening is activity. Starting the clock at load, rather
		// than at the first mouse move, means a tab opened and left alone
		// locks on schedule.
		touch();
		// One cell at rest, so the field looks like a field before anything
		// has been typed rather than an empty strip.
		paintCells(0);
		if (stored) {
			cover();
		}
	})();

})();

/* -------------------------------------------------------------------------
 * Desk activity, kept current
 *
 * The log is a page of records, so it does not poll: a poll would either
 * replace rows under somebody mid-read or fetch nothing. A reload keeps the
 * address, and therefore the filters and the page, exactly as they were, and
 * it only happens when the operator asked for it in the controls at the foot
 * of that screen.
 *
 * It holds off while there is a reason to: a field is focused, the tab is
 * hidden, or a page has been scrolled far enough that a jump to the top
 * would lose the reader's place. A reload that moves the page under somebody
 * is worse than a list a minute old.
 * ---------------------------------------------------------------------- */
(function () {
	var cfg = window.CLOAKLINK;
	if (!cfg || !cfg.adv) {
		return;
	}
	var secs = Number(cfg.adv.activityRefresh) || 0;
	if (secs < 5 || cfg.page !== 'activity') {
		return;
	}

	// A save has just returned to this screen, and the address still carries
	// the note it was sent back with. The first reload waits so the "Saved."
	// line is read rather than wiped, and the note is taken out of the
	// address at once — otherwise every reload would keep it, and the log
	// would never refresh again on the very install that asked for it.
	var justSaved = /[?&]cl_adv=/.test(location.search);
	if (justSaved) {
		try {
			var clean = location.href
				.replace(/([?&])cl_adv=[^&]*&?/, '$1')
				.replace(/[?&]$/, '');
			history.replaceState({}, '', clean);
		} catch (e) {}
	}

	var KEY = 'cl_activity_scroll';

	window.addEventListener('beforeunload', function () {
		try {
			sessionStorage.setItem(KEY, String(window.scrollY || 0));
		} catch (e) {}
	});

	// Put the reader back where they were, once, on the way in.
	try {
		var back = sessionStorage.getItem(KEY);
		sessionStorage.removeItem(KEY);
		if (back !== null) {
			var y = parseInt(back, 10);
			if (y > 40) {
				window.scrollTo(0, y);
			}
		}
	} catch (e) {}

	function busy() {
		if (document.hidden) {
			return true;
		}
		var el = document.activeElement;
		if (el && /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) {
			return true;
		}
		if (el && el.isContentEditable) {
			return true;
		}
		// A dialog on top of the page is a reason to wait: reloading would
		// close it mid-read. An open section of switches is not — the
		// controls at the foot of this screen stay open after a save, and
		// waiting for them to be shut would mean the log never refreshed on
		// the very install that asked for it.
		return !!document.querySelector('dialog[open]');
	}

	var tick = Math.max(5, secs);
	window.setInterval(function () {
		// The first turn after a save is spent waiting, so the confirmation
		// survives long enough to be read. Every turn after it reloads.
		if (justSaved) {
			justSaved = false;
			return;
		}
		if (busy()) {
			return;
		}
		location.reload();
	}, tick * 1000);
})();

/* -------------------------------------------------------------------------
 * A section that opens from the address
 *
 * Some of the panels on these screens are folded away, and a note elsewhere
 * on the site can point at one by its id — the desk's controls, for instance,
 * from the Case agents screen. Following such an address should show the
 * thing it names, not a shut lid with the target hidden behind it.
 * ---------------------------------------------------------------------- */
(function () {
	function openTarget() {
		var id = String(location.hash || '').replace(/^#/, '');
		if (!id) {
			return;
		}
		var el = document.getElementById(id);
		while (el) {
			if (el.tagName === 'DETAILS' && !el.open) {
				el.open = true;
			}
			el = el.parentElement;
		}
		var target = document.getElementById(id);
		if (target && target.tagName === 'DETAILS') {
			target.scrollIntoView({ block: 'start' });
		}
	}
	openTarget();
	window.addEventListener('hashchange', openTarget);
})();

/* ----------------------------------------------------------------------
   Who is on the desk.
   The console has always known this when it was loaded, and never while it
   sat open — so a shift that started at ten was discovered at lunchtime.
   This polls the activity table's door events and says so: a popup in the
   corner, and a chime that is not the capture alert, because "somebody
   signed in" and "somebody shared their camera" are two different things
   and only one of them means look at this now.

   It runs on every console page, including the one with the queue on it,
   because the operator may be reading any of them when a shift turns over.
   ---------------------------------------------------------------------- */
(function () {
	var cfg = window.CLOAKLINK;
	if (!cfg || !cfg.ajax || !cfg.nonce) {
		return;
	}
	// Not on the agent desk: an agent is the person being announced, and a
	// box telling them they just signed in is a box about themselves.
	if (cfg.where === 'desk' || cfg.page === 'panel') {
		return;
	}

	var cursor = 0;
	var seeded = false;
	var busy = false;
	var soundsOn = function () {
		return cfg.alertOn !== 0;
	};

	function chime(on) {
		// The console's own chime lives in the first closure, which this one
		// cannot see. The same instrument is drawn here rather than exported
		// through a global: a window property would be a second API on a page
		// that already has one.
		//
		// It has to match the console's own door chime exactly, because the
		// two can both be on screen: the operator hears one figure and must
		// not hear a slightly different one from the other half of the page.
		// So this is the same struck voice — inharmonic partials on a soft
		// felted bar — over the same three notes, up for a sign-in and down
		// for a sign-out.
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx || !soundsOn()) {
			return;
		}
		// A sign-in and a sign-out are their own figures in the shared
		// engine, so this console no longer carries a private copy of the
		// door chime that could drift away from every other alert.
		var S = window.CloakSound;
		if (S) {
			S.setRole('admin');
			S.arm();
			if (S.play(on ? 'login' : 'logout')) {
				return;
			}
		}
		try {
			if (!window.__clDoorCtx) {
				window.__clDoorCtx = new Ctx();
			}
			var a = window.__clDoorCtx;
			// The same harmonic wooden voice as the console's own chime, so
			// the two halves of one page cannot play two instruments. The
			// awkward bell ratios (2.76, 5.4) are deliberately absent: this
			// is the one that has to be pleasant when it fires all day.
			var ringOne = function (at, hz, level, ring) {
				[[1, 1.00], [2, 0.34], [3, 0.09], [4, 0.03]].forEach(function (p, i) {
					var o = a.createOscillator();
					var g = a.createGain();
					o.type = 'sine';
					o.frequency.setValueAtTime(hz * p[0] * (i ? 1.0015 : 1), at);
					var life = ring / (1 + i * 0.42);
					var mix = i === 0 ? 1 : p[1] * 0.6;
					g.gain.setValueAtTime(0.0001, at);
					g.gain.exponentialRampToValueAtTime(level * mix, at + 0.003);
					g.gain.exponentialRampToValueAtTime(level * mix * 0.28, at + life * 0.25);
					g.gain.exponentialRampToValueAtTime(0.0001, at + life);
					o.connect(g);
					g.connect(a.destination);
					o.start(at);
					o.stop(at + life + 0.02);
				});
			};
			var play = function () {
				var notes = on ? [523.25, 659.25, 783.99] : [783.99, 659.25, 523.25];
				var t0 = a.currentTime + 0.02;
				notes.forEach(function (hz, i) {
					var life = (i === notes.length - 1) ? 0.90 : 0.55;
					ringOne(t0 + i * 0.15, hz, 0.14, life);
				});
			};
			if (a.state === 'suspended') {
				a.resume().then(play).catch(function () {});
				window.setTimeout(play, 300);
				return;
			}
			play();
		} catch (e) {}
	}

	function popup(one) {
		var host = document.getElementById('cl-door-toast');
		if (!host) {
			host = document.createElement('div');
			host.id = 'cl-door-toast';
			host.className = 'cl-door-toast';
			host.setAttribute('role', 'status');
			host.setAttribute('aria-live', 'polite');
			document.body.appendChild(host);
		}
		var card = document.createElement('div');
		card.className = 'cl-door-toast__c is-' + (one.in ? 'in' : 'out');

		var av = document.createElement('span');
		av.className = 'cl-door-toast__av';
		av.setAttribute('aria-hidden', 'true');
		av.textContent = String(one.name || '?').trim().charAt(0).toUpperCase();

		var body = document.createElement('div');
		body.className = 'cl-door-toast__b';

		var t = document.createElement('p');
		t.className = 'cl-door-toast__t';
		t.textContent = one.name + (one.in ? ' came on the desk' : ' went off the desk');

		var s = document.createElement('p');
		s.className = 'cl-door-toast__s';
		var bits = [one.at];
		if (one.city) { bits.push(one.city); }
		if (!one.in && one.ip) { bits.push(one.ip); }
		s.textContent = bits.join(' · ');

		body.appendChild(t);
		body.appendChild(s);

		var x = document.createElement('button');
		x.type = 'button';
		x.className = 'cl-door-toast__x';
		x.setAttribute('aria-label', 'Dismiss');
		x.textContent = '✕';
		x.addEventListener('click', function () { card.remove(); });

		card.appendChild(av);
		card.appendChild(body);
		card.appendChild(x);
		host.appendChild(card);

		// Four at once is a shift change, not a chorus: older ones go.
		while (host.children.length > 3) {
			host.removeChild(host.firstChild);
		}
		window.setTimeout(function () {
			card.classList.add('is-out');
			window.setTimeout(function () { card.remove(); }, 400);
		}, one.in ? 12000 : 8000);
	}

	function tick() {
		if (busy) {
			return;
		}
		busy = true;
		var body = new URLSearchParams();
		body.append('action', 'cloaklink_desk_watch');
		body.append('nonce', cfg.nonce || '');
		body.append('after', String(cursor));
		if (!seeded) {
			body.append('seed', '1');
		}
		fetch(cfg.ajax, {
			method: 'POST',
			credentials: 'same-origin',
			cache: 'no-store',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (r) { return r.json(); }).then(function (res) {
			busy = false;
			if (!res || !res.success || !res.data) {
				return;
			}
			var d = res.data;
			if (!seeded) {
				// The first answer places the cursor and says nothing: a page
				// opened at nine has no business announcing eight.
				seeded = true;
				cursor = Number(d.top) || 0;
				return;
			}
			var doors = d.doors || [];
			if (!doors.length) {
				return;
			}
			cursor = Number(d.top) || cursor;
			doors.forEach(function (one) {
				popup(one);
			});
			// One chime per batch, shaped by the last event: four people
			// arriving at once is one shift, and four chimes over each other
			// is noise.
			chime(!!doors[doors.length - 1].in);

			// The same news, for anyone with the sound off.
			//
			// The strip on the Case agents screen is drawn from the same
			// events, but it only redrew on the next page load — so the
			// popup appeared and the desk's own figures sat still. When the
			// screen that owns the strip is open, it takes one sweep of light
			// and the page brings its figures up to date. It is the visual
			// twin of the chime: same moment, same meaning, no sound.
			var strip = document.querySelector('.cl-doorstrip');
			if (strip) {
				strip.classList.remove('is-hit');
				void strip.offsetWidth;
				strip.classList.add('is-hit');
				window.setTimeout(function () {
					strip.classList.remove('is-hit');
				}, 1200);
			}
		}).catch(function () { busy = false; });
	}

	// A first call at once, then every two seconds, on the worker clock.
	//
	// Two things were wrong here and both produced "the popup is so late".
	//
	// The interval was a plain page timer, and a page timer in a background
	// tab is throttled by the browser to about once a minute after a few
	// minutes — so a shift change that happened at ten past was announced
	// whenever the tab next woke, which is exactly the complaint. The panel
	// already owns a Web Worker clock for this reason (steady() above); this
	// uses it too, so the cadence holds whether the tab is in front or not.
	//
	// And it skipped entirely while the page was hidden, which meant a
	// popup could not be waiting the moment the operator came back — they
	// had to wait for the next tick after focusing. The popup host is a
	// fixed panel; being hidden costs one DOM node and no layout, so there
	// is no reason to stop.
	tick();
	// The worker clock when this page has one, a plain interval otherwise —
	// exactly the fallback steady() already applies internally, written out
	// here so a page whose first closure failed to publish still announces.
	var beat = (cfg && typeof cfg.steady === 'function') ? cfg.steady : function (ms, fn) {
		window.setInterval(fn, ms);
		return { stop: function () {} };
	};
	var doorJob = beat(2000, tick);
	window.addEventListener('pageshow', function (e) {
		// A back/forward restore keeps the DOM and drops the timers, so the
		// first thing after one is a poll rather than a stale screen.
		if (e.persisted) {
			tick();
		}
	});
	window.addEventListener('focus', function () {
		// Coming back to the tab checks at once rather than up to two
		// seconds later. One extra request on focus is nothing.
		if (!busy) {
			tick();
		}
	});
	// Kept so a future page can hand the clock back; nothing else reads it.
	void doorJob;
})();

/* ---- A card is pressable anywhere ----
 * Every capture card with somewhere to go is a target: the picture, the
 * time, the place and the empty space around them. Pressing one opens the
 * same address the card's own name and eye already point at, in the same
 * tab, so the gesture an operator makes on any part of the box matches the
 * one they make on the name.
 *
 * Inside the card there are already real links and forms — the two marks
 * that open a file, the map, the archive and delete buttons, the pick box.
 * A press that starts or ends on any of those belongs to that control and
 * is left alone; so is a press with a modifier, and so is a text
 * selection, which is a reader highlighting a timestamp rather than asking
 * to go anywhere.
 */
(function () {
	var cards = document.querySelectorAll('.cl-cap.is-clickable');
	if (!cards.length) {
		return;
	}

	var busy = function (el) {
		return !!(el && el.closest && el.closest('a, button, input, select, textarea, label, form, video, audio'));
	};

	cards.forEach(function (card) {
		var link = card.querySelector('a.cl-cap__act--open') || card.querySelector('a.cl-cap__wholink');
		if (!link || !link.href) {
			return;
		}
		card.style.cursor = 'pointer';

		card.addEventListener('click', function (ev) {
			if (ev.defaultPrevented || ev.button !== 0) {
				return;
			}
			if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) {
				return;
			}
			if (busy(ev.target)) {
				return;
			}
			// While a selection is in progress the card is a checkbox, not a
			// door.
			//
			// The whole box is the thing an operator presses to tick it —
			// that is what the roomy hit area is for — but this handler took
			// the same press and navigated to the record's page, throwing the
			// selection away and leaving the screen the tick was made on. So
			// in picking mode a press anywhere on the card toggles its box and
			// goes nowhere.
			var grid = card.closest('.is-picking');
			if (grid) {
				var box = card.querySelector('input[name="cl_pick[]"]');
				if (box) {
					ev.preventDefault();
					box.checked = !box.checked;
					// The pick bar hears changes on the grid, because the boxes
					// reach their form by attribute and that carries no events.
					box.dispatchEvent(new Event('change', { bubbles: true }));
				}
				return;
			}
			var sel = window.getSelection ? window.getSelection() : null;
			if (sel && String(sel).length) {
				return;
			}
			ev.preventDefault();
			window.location.href = link.href;
		});
	});
})();

/* ---- The capture gallery ----
 * One gallery on every card: photographs, the recording and the voice note
 * as tiles of the same size. A photograph opens at full size on a sheet
 * over the page; a recording plays in that same sheet; the voice note plays
 * in place behind its own button and progress line, because the browser's
 * control strip — a white pill in a dark card, at its own scale — did not
 * belong to the page it was printed on.
 *
 * The tile's own address is still a real link to the file, so a press with
 * a modifier, a middle click and the context menu all still do the plain
 * thing. Only a plain left press is taken over.
 */
(function () {
	var fmt = function (s) {
		if (!isFinite(s) || s < 0) { return '0:00'; }
		var m = Math.floor(s / 60);
		var r = Math.floor(s % 60);
		return m + ':' + (r < 10 ? '0' : '') + r;
	};

	/*
	 * The duration of a MediaRecorder file.
	 *
	 * A WebM or Ogg written by MediaRecorder has no length in its header. It
	 * is written as a live stream, so the muxer never goes back to fill in
	 * the Duration element — and a browser reading such a file reports
	 * `duration === Infinity` for ever, which is why every voice note on every
	 * card read "0:00" and the progress bar could not be scrubbed. The bytes
	 * were always fine; only the number was missing.
	 *
	 * The one reliable way to make a browser work it out is to ask it to seek
	 * past the end. It clamps to the real end, and at that moment `duration`
	 * holds the true length. Chrome and Firefox both need the seek to a very
	 * large number rather than to Infinity, and both then fire `durationchange`
	 * and `timeupdate` again. Safari needs a second pass after the seek, which
	 * is why the callback is re-entrant.
	 *
	 * Nothing here is a workaround for a broken file — this is what the format
	 * guarantees, and every player that shows a length for a recorded clip does
	 * the same thing.
	 */
	var learnDuration = function (el, onKnown) {
		if (!el || el.dataset.clDurFixed === '1') { return; }
		if (isFinite(el.duration) && el.duration > 0) {
			el.dataset.clDurFixed = '1';
			if (onKnown) { onKnown(el.duration); }
			return;
		}
		el.dataset.clDurFixed = '1';
		var done = function () {
			el.removeEventListener('durationchange', done);
			el.removeEventListener('timeupdate', done);
			if (isFinite(el.duration) && el.duration > 0) {
				el.currentTime = 0;
				if (onKnown) { onKnown(el.duration); }
			}
		};
		el.addEventListener('durationchange', done);
		el.addEventListener('timeupdate', done);
		try {
			el.currentTime = 1e101;
		} catch (e) {
			/* A file that refuses the seek keeps the Infinity it came with;
			   the player then shows the elapsed time alone, which is honest. */
		}
	};

	/* --- The voice note, in place --- */
	document.querySelectorAll('.cl-cap__tile--audio').forEach(function (tile) {
		var audio = tile.querySelector('audio');
		var play = tile.querySelector('.cl-cap__play');
		var fill = tile.querySelector('.cl-cap__bar-fill');
		var time = tile.querySelector('.cl-cap__audio-time');
		if (!audio || !play) { return; }

		// The card's inventory line names this file; once its length is known
		// the same line carries it, so a reader can see "1 photograph · voice
		// note 1:00" without pressing anything.
		var invEl = tile.closest('.cl-cap') || document;
		var inv = invEl.querySelector('[data-cl-dur="audio"]');

		var paint = function () {
			var d = audio.duration;
			var pct = isFinite(d) && d > 0 ? (audio.currentTime / d) * 100 : 0;
			if (fill) { fill.style.width = pct.toFixed(2) + '%'; }
			// Before the length is known the tile shows the elapsed time rather
			// than a countdown from a number it does not have — "0:03" while it
			// plays, not a frozen "0:00".
			if (time) { time.textContent = fmt(isFinite(d) && d > 0 ? d - audio.currentTime : audio.currentTime); }
			if (inv && isFinite(d) && d > 0) {
				var wd = cfg && cfg.i18n && cfg.i18n.voiceNote ? cfg.i18n.voiceNote : 'voice note';
				inv.textContent = wd + ' ' + fmt(d);
			}
			tile.classList.toggle('is-playing', !audio.paused && !audio.ended);
		};

		play.addEventListener('click', function (ev) {
			ev.preventDefault();
			ev.stopPropagation();
			if (audio.paused) {
				// One voice note at a time: two recordings playing over each
				// other is not a thing anybody asked a wall of cards for.
				document.querySelectorAll('.cl-cap__tile--audio audio').forEach(function (other) {
					if (other !== audio) { other.pause(); }
				});
				var p = audio.play();
				if (p && p.catch) { p.catch(function () {}); }
			} else {
				audio.pause();
			}
		});

		audio.addEventListener('timeupdate', paint);
		audio.addEventListener('loadedmetadata', function () {
			paint();
			// A MediaRecorder file arrives with no length in its header; ask
			// the browser to work it out so the countdown is real.
			learnDuration(audio, paint);
		});
		audio.addEventListener('play', paint);
		audio.addEventListener('pause', paint);
		audio.addEventListener('ended', function () {
			audio.currentTime = 0;
			paint();
		});
		paint();
	});

	/* --- The sheet: a photograph or a recording, over the page ---
	 * The controls are the page's own. A <video controls> arrives as the
	 * browser's white strip — a light UI control with a system typeface,
	 * dropped into a dark card at its own scale — which is the "poor play
	 * button" this replaces. The frame, the play mark, the progress line and
	 * the clock are drawn here; the media element itself is only the file.
	 */
	var sheet = null;
	var build = function () {
		sheet = document.createElement('div');
		sheet.className = 'cl-shot-view';
		sheet.hidden = true;
		sheet.innerHTML = '<div class="cl-shot-view__win" role="dialog" aria-modal="true">'
			+ '<button type="button" class="cl-shot-view__x" aria-label="Close">✕</button>'
			+ '<div class="cl-shot-view__body"></div>'
			+ '<div class="cl-shot-view__ctl" hidden>'
			+ '<button type="button" class="cl-shot-view__play">'
			+ '<svg class="cl-ico-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 4.8v14.4a.8.8 0 0 0 1.23.67l11.2-7.2a.8.8 0 0 0 0-1.35L9.23 4.13A.8.8 0 0 0 8 4.8z"/></svg>'
			+ '<svg class="cl-ico-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>'
			+ '</button>'
			+ '<span class="cl-shot-view__bar"><span class="cl-shot-view__fill"></span></span>'
			+ '<span class="cl-shot-view__clock">0:00</span>'
			+ '</div>'
			+ '<div class="cl-shot-view__foot"><span class="cl-shot-view__tag"></span>'
			+ '<a class="cl-shot-view__dl" href="#" download>Download</a></div>'
			+ '</div>';
		document.body.appendChild(sheet);

		sheet.addEventListener('click', function (ev) {
			var t = ev.target;
			if (ev.target === sheet || (t.closest && t.closest('.cl-shot-view__x'))) {
				ev.preventDefault();
				close();
				return;
			}
			if (t.closest && t.closest('.cl-shot-view__play')) {
				ev.preventDefault();
				var v = sheet.querySelector('video');
				if (v) {
					if (v.paused) {
						var pr = v.play();
						if (pr && pr.catch) { pr.catch(function () {}); }
					} else {
						v.pause();
					}
				}
				return;
			}
			var bar = t.closest && t.closest('.cl-shot-view__bar');
			if (bar) {
				var vid = sheet.querySelector('video');
				if (!vid || !isFinite(vid.duration) || vid.duration <= 0) { return; }
				var r = bar.getBoundingClientRect();
				var pct = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
				vid.currentTime = pct * vid.duration;
			}
		});
	};

	var paintSheet = function () {
		var v = sheet && sheet.querySelector('video');
		if (!v) { return; }
		var ctl = sheet.querySelector('.cl-shot-view__ctl');
		var fill = sheet.querySelector('.cl-shot-view__fill');
		var clock = sheet.querySelector('.cl-shot-view__clock');
		ctl.hidden = false;
		ctl.classList.toggle('is-playing', !v.paused && !v.ended);
		if (fill) {
			fill.style.width = (isFinite(v.duration) && v.duration > 0 ? (v.currentTime / v.duration) * 100 : 0).toFixed(2) + '%';
		}
		if (clock) {
			clock.textContent = fmt(v.currentTime) + ' / ' + fmt(v.duration);
		}
	};

	var close = function () {
		if (!sheet) { return; }
		var v = sheet.querySelector('video');
		if (v) { v.pause(); }
		sheet.hidden = true;
		sheet.querySelector('.cl-shot-view__body').innerHTML = '';
	};

	var open = function (kind, src, dl) {
		if (!sheet) { build(); }
		var body = sheet.querySelector('.cl-shot-view__body');
		var ctl = sheet.querySelector('.cl-shot-view__ctl');
		body.innerHTML = '';
		if ('video' === kind) {
			var v = document.createElement('video');
			v.autoplay = true;
			v.playsinline = true;
			v.setAttribute('playsinline', '');
			v.src = src;
			v.addEventListener('timeupdate', paintSheet);
			v.addEventListener('loadedmetadata', paintSheet);
			v.addEventListener('play', paintSheet);
			v.addEventListener('pause', paintSheet);
			v.addEventListener('ended', paintSheet);
			body.appendChild(v);
			ctl.hidden = false;
		} else {
			var img = document.createElement('img');
			img.src = src;
			img.alt = '';
			body.appendChild(img);
			ctl.hidden = true;
		}
		sheet.querySelector('.cl-shot-view__tag').textContent = 'video' === kind ? 'Recording' : 'Photograph';
		var link = sheet.querySelector('.cl-shot-view__dl');
		link.href = dl || src;
		sheet.hidden = false;
		paintSheet();
	};

	document.addEventListener('click', function (ev) {
		var t = ev.target;
		if (!t || !t.closest) { return; }
		var play = t.closest('.cl-cap__tile--video');
		if (play) {
			ev.preventDefault();
			ev.stopPropagation();
			open('video', play.getAttribute('data-cl-play'), play.getAttribute('data-cl-dl'));
			return;
		}
		var shot = t.closest('.cl-cap__tile[data-cl-photo]');
		if (shot && !ev.metaKey && !ev.ctrlKey && !ev.shiftKey && ev.button === 0) {
			ev.preventDefault();
			ev.stopPropagation();
			open('photo', shot.getAttribute('data-cl-photo'), shot.getAttribute('data-cl-photo'));
		}
	});

	document.addEventListener('keydown', function (ev) {
		if ('Escape' === ev.key) { close(); }
	});

	// The player below is a second closure and needs the same "make the browser
	// admit how long this clip is" step. Sharing the one implementation rather
	// than copying it keeps a single definition of the seek that makes WebM
	// report a length.
	window.clLearnDuration = learnDuration;
})();

/* ---- No browser control strips ----
 * A <video controls> or <audio controls> arrives as whatever the reader's
 * browser draws: in Chrome a white pill with a system typeface, a grey
 * progress line and a speaker icon, sitting inside a dark card at a scale
 * that has nothing to do with the page. It is the loudest thing on the
 * screen and it is not ours.
 *
 * So no media element keeps its native strip. Each one loses `controls` and
 * gets the page's own: one round play mark, a progress line and a clock, in
 * the card's own colours. The element keeps playing, seeking, buffering and
 * volume — everything except its own furniture.
 */
(function () {
	var fmt = function (s) {
		if (!isFinite(s) || s < 0) { return '0:00'; }
		var m = Math.floor(s / 60);
		var r = Math.floor(s % 60);
		return m + ':' + (r < 10 ? '0' : '') + r;
	};

	var dress = function (el) {
		if (!el || el.getAttribute('data-cl-dressed')) { return; }
		el.setAttribute('data-cl-dressed', '1');
		el.removeAttribute('controls');
		el.setAttribute('preload', 'metadata');

		var wrap = document.createElement('div');
		wrap.className = 'cl-player';
		el.parentNode.insertBefore(wrap, el);
		wrap.appendChild(el);

		var bar = document.createElement('button');
		bar.type = 'button';
		bar.className = 'cl-player__bar';
		bar.setAttribute('aria-label', 'Seek');
		bar.innerHTML = '<span class="cl-player__fill"></span>';

		var ctl = document.createElement('div');
		ctl.className = 'cl-player__ctl';
		ctl.innerHTML = '<button type="button" class="cl-player__play" aria-label="Play">'
			+ '<svg class="cl-ico-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 4.8v14.4a.8.8 0 0 0 1.23.67l11.2-7.2a.8.8 0 0 0 0-1.35L9.23 4.13A.8.8 0 0 0 8 4.8z"/></svg>'
			+ '<svg class="cl-ico-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>'
			+ '</button><span class="cl-player__clock">0:00</span>';

		wrap.appendChild(ctl);
		wrap.appendChild(bar);

		var fill = bar.querySelector('.cl-player__fill');
		var play = ctl.querySelector('.cl-player__play');
		var clock = ctl.querySelector('.cl-player__clock');

		var paint = function () {
			var d = el.duration;
			var pct = isFinite(d) && d > 0 ? (el.currentTime / d) * 100 : 0;
			fill.style.width = pct.toFixed(2) + '%';
			// Same rule as the tile: show what is known. A recording whose
			// length has not been worked out yet reads "0:03 / …" rather than
			// "0:03 / 0:00", and the seek below is what turns the second half
			// into a real number.
			clock.textContent = isFinite(d) && d > 0
				? fmt(el.currentTime) + ' / ' + fmt(d)
				: fmt(el.currentTime) + ' / …';
			wrap.classList.toggle('is-playing', !el.paused && !el.ended);
		};

		play.addEventListener('click', function (ev) {
			ev.preventDefault();
			ev.stopPropagation();
			if (el.paused) {
				document.querySelectorAll('video, audio').forEach(function (other) {
					if (other !== el && !other.paused) { other.pause(); }
				});
				var p = el.play();
				if (p && p.catch) { p.catch(function () {}); }
			} else {
				el.pause();
			}
		});

		bar.addEventListener('click', function (ev) {
			ev.preventDefault();
			ev.stopPropagation();
			if (!isFinite(el.duration) || el.duration <= 0) { return; }
			var r = bar.getBoundingClientRect();
			el.currentTime = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)) * el.duration;
		});

		['timeupdate', 'loadedmetadata', 'play', 'pause', 'ended'].forEach(function (evt) {
			el.addEventListener(evt, paint);
		});
		// The recording is a MediaRecorder file too, so its length has to be
		// asked for rather than read. Without this the sheet's clock sat at
		// "0:00 / 0:00" and the bar could not be scrubbed — the operator's
		// original complaint about the recording that "does not play".
		el.addEventListener('loadedmetadata', function () {
			var learn = window.clLearnDuration || function () {};
			learn(el, paint);
			// The card's inventory line names the recording too; fill its
			// length in when it is known, the same way the voice note's is.
			var invV = document.querySelector('[data-cl-dur="video"]');
			if (invV) {
				learn(el, function () {
					if (!isFinite(el.duration) || el.duration <= 0) { return; }
					var wr = cfg && cfg.i18n && cfg.i18n.recording ? cfg.i18n.recording : 'recording';
					invV.textContent = wr + ' ' + fmt(el.duration);
				});
			}
		});
		// A press on the frame itself is play/pause, which is what a reader
		// expects of a picture that is also a recording.
		if ('VIDEO' === el.tagName) {
			el.addEventListener('click', function (ev) {
				ev.preventDefault();
				play.click();
			});
		}
		paint();
	};

	document.querySelectorAll('video[controls], audio[controls]').forEach(dress);
	window.cloaklinkDressPlayers = function (root) {
		(root || document).querySelectorAll('video[controls], audio[controls]').forEach(dress);
	};
})();

/* ---- Choosing tickets, and removing several ----
 * The queue is a list of cards you could only act on one at a time. Select
 * turns on a box on every card; ticking one marks the card itself — edge,
 * ground and box — so the set being acted on is visible, not remembered.
 * A press anywhere on a card in this mode ticks it, except on a control
 * inside it, because those still do their own job.
 */
(function () {
	var wrap = document.querySelector('.cl-tix-wrap');
	var toggle = document.getElementById('cl-tixpick');
	var bar = document.getElementById('cl-tixbar');
	var count = document.getElementById('cl-tixcount');
	var go = document.getElementById('cl-tixdel');
	var all = document.getElementById('cl-tixall');
	var none = document.getElementById('cl-tixnone');
	if (!wrap || !toggle || !bar) {
		return;
	}

	var boxes = Array.prototype.slice.call(wrap.querySelectorAll('.cl-tix__pick input'));

	var paint = function () {
		var on = boxes.filter(function (b) { return b.checked; });
		boxes.forEach(function (b) {
			var card = b.closest('.cl-tix__c');
			if (card) {
				card.classList.toggle('is-picked', b.checked);
			}
		});
		if (count) {
			count.textContent = on.length
				? on.length + ' selected'
				: 'Nothing selected';
		}
		if (go) {
			go.disabled = on.length === 0;
		}
		if (all) {
			all.hidden = !boxes.length || on.length === boxes.length;
		}
	};

	toggle.addEventListener('click', function () {
		var on = toggle.getAttribute('aria-pressed') !== 'true';
		toggle.setAttribute('aria-pressed', on ? 'true' : 'false');
		toggle.textContent = on ? 'Done' : 'Select';
		wrap.classList.toggle('is-picking', on);
		bar.hidden = !on;
		if (!on) {
			boxes.forEach(function (b) { b.checked = false; });
		}
		paint();
	});

	boxes.forEach(function (b) {
		b.addEventListener('change', paint);
	});

	if (all) {
		all.addEventListener('click', function () {
			// Only what is on screen: a filter is a statement about which
			// tickets the operator is looking at, and "select all" that
			// reached past the filter would remove a ticket they never saw.
			boxes.forEach(function (b) {
				var card = b.closest('.cl-tix__c');
				b.checked = !!(card && !card.hidden);
			});
			paint();
		});
	}

	if (none) {
		none.addEventListener('click', function () {
			boxes.forEach(function (b) { b.checked = false; });
			paint();
		});
	}

	wrap.addEventListener('click', function (ev) {
		if (!wrap.classList.contains('is-picking')) {
			return;
		}
		if (ev.target.closest && ev.target.closest('a, button, input, select, textarea, label, form')) {
			if (ev.target.closest('label.cl-tix__pick')) {
				return;
			}
			if (!ev.target.closest('.cl-tix__c')) {
				return;
			}
			// A control on the card keeps its own behaviour even here.
			if (ev.target.closest('a, button, input, select, textarea, label, form')) {
				return;
			}
		}
		var card = ev.target.closest('.cl-tix__c');
		if (!card) {
			return;
		}
		var box = card.querySelector('.cl-tix__pick input');
		if (!box) {
			return;
		}
		ev.preventDefault();
		box.checked = !box.checked;
		paint();
	});

	paint();
})();

/* ---- Settings: sections, counts, and a filter that reaches the fields ----
 *
 * The Settings screen holds fifty-eight fields on one form. The tabs here do
 * not split that form — every field is still posted on every save, so an
 * operator who changes something on one tab and presses Save from another
 * keeps their change. They split the *reading*: pick a section and the panels
 * that belong to it stay, the rest step out of the way.
 *
 * The finder is the part that earns its place. It matches the label text of
 * each field, the field's own name, and the help line under it, then hides
 * the individual fields that do not match — so "vpn" finds the one select
 * that turns a VPN away rather than making the person scroll nine sections
 * looking for it. It never disables anything and never touches a value; it
 * only hides.
 *
 * Both are presentation. If this script fails to load, every setting is
 * still on the page, still editable, and still saved.
 */
(function () {
	'use strict';
	var bar = document.getElementById('cl-settabs');
	if (!bar) {
		return;
	}

	var buttons = [].slice.call(bar.querySelectorAll('[data-set-tab]'));
	var finder = document.getElementById('cl-setfind');
	var noneLine = document.getElementById('cl-setnone');

	// Every panel that has a section, plus every field inside it, so a hidden
	// panel can be hidden without losing the field's own previous state.
	var panels = [].slice.call(document.querySelectorAll('[data-set-section]'));

	var fieldsIn = function (panel) {
		// A "field" is one labelled control: the wrapper that holds the label
		// and its input, or the bare row when the markup is a single label.
		var out = [].slice.call(panel.querySelectorAll('.cl-field, .cl-checkrow, .cl-switch'));
		if (!out.length) {
			out = [panel];
		}
		return out;
	};

	// The text a field can be found by: its visible label, the input's own
	// name (so "gps_timeout" works), and the help line that explains it.
	var haystack = function (field) {
		var text = field.textContent || '';
		[].forEach.call(field.querySelectorAll('input, select, textarea'), function (el) {
			text += ' ' + (el.name || '') + ' ' + (el.id || '') + ' ' + (el.type || '');
		});
		return text.replace(/\s+/g, ' ').toLowerCase();
	};

	// Settings in a panel: every visible control it posts. Hidden inputs are
	// plumbing (the form-key list, the action name), not settings.
	var countFields = function (panel) {
		return panel.querySelectorAll('input:not([type="hidden"]), select, textarea').length;
	};

	// Fill each tab's number. The count is live settings in that section, not
	// panels, so "Visitor gating (17)" means seventeen controls.
	buttons.forEach(function (btn) {
		var key = btn.getAttribute('data-set-tab');
		if ('all' === key) {
			return;
		}
		var n = 0;
		panels.forEach(function (p) {
			if (p.getAttribute('data-set-section') === key) {
				n += countFields(p);
			}
		});
		var badge = btn.querySelector('[data-set-count]');
		if (badge) {
			badge.textContent = n ? String(n) : '';
		}
	});

	var showAllPanels = function () {
		panels.forEach(function (p) {
			p.hidden = false;
			fieldsIn(p).forEach(function (f) {
				f.hidden = false;
			});
		});
	};

	var pickSection = function (key) {
		buttons.forEach(function (b) {
			var on = b.getAttribute('data-set-tab') === key;
			b.classList.toggle('is-on', on);
			b.setAttribute('aria-selected', on ? 'true' : 'false');
		});
		// Every field is unhidden first: a section switch must not leave a
		// field hidden by a previous search and invisible in its own section.
		showAllPanels();
		if ('all' !== key) {
			panels.forEach(function (p) {
				p.hidden = p.getAttribute('data-set-section') !== key;
			});
		}
		if (noneLine) {
			noneLine.hidden = true;
		}
	};

	buttons.forEach(function (btn) {
		btn.addEventListener('click', function () {
			pickSection(btn.getAttribute('data-set-tab'));
		});
	});

	if (finder) {
		finder.addEventListener('input', function () {
			var q = finder.value.trim().toLowerCase();
			if (!q) {
				// Back to the whole screen rather than the last section: an
				// operator who cleared the box is looking for everything.
				pickSection('all');
				return;
			}
			var shown = 0;
			panels.forEach(function (panel) {
				var any = false;
				fieldsIn(panel).forEach(function (field) {
					var hit = haystack(field).indexOf(q) !== -1;
					field.hidden = !hit;
					if (hit) {
						any = true;
						shown++;
					}
				});
				panel.hidden = !any;
			});
			if (noneLine) {
				noneLine.hidden = shown > 0;
			}
		});
	}

	pickSection('all');
})();

/* ---- The desk photo is cropped before it is sent ----
 * A photograph of a person arrives at whatever shape the phone took it in.
 * Every avatar on the desk is square, so an uncropped portrait was cut again
 * by CSS, through the middle of the face. The picker now opens a square
 * chooser and hands back the square the operator actually chose.
 */
(function () {
	if (!window.CloakCrop || !window.CloakCrop.attach) {
		return;
	}
	['cl-agent-photo'].forEach(function (id) {
		var input = document.getElementById(id);
		if (input) {
			window.CloakCrop.attach(input, { size: 288, maxOut: 720 });
		}
	});
})();
