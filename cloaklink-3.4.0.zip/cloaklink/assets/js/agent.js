/**
 * The case desk at work: alerts, and the idle lock.
 *
 * The panel is left open while a person works on something else, and the one
 * thing it has to tell them is that a visitor answered on one of their links.
 * That has to arrive on its own, at once, and with a sound — the same demand
 * the operator made of their own panel, and the same answer: poll a single
 * high-water id, and only show, draw and beep when it moves.
 *
 * The sound is generated rather than loaded, so it cannot 404 and cannot be
 * blocked by a missing file, and the operator's own uploaded alert is used
 * when there is one, because it is the sound this desk already uses.
 *
 * The lock is the other half of a twelve-hour session: a tab left alone locks
 * itself, and only the access code opens it. The answer is checked on the
 * server; this file only asks and reports.
 */
(function () {
	'use strict';

	var cfgEl = document.getElementById('cl-agent-config');
	if (!cfgEl) {
		return;
	}

	var cfg = {};
	try {
		cfg = JSON.parse(cfgEl.textContent || '{}');
	} catch (e) {
		return;
	}

	/* ---- A clock that keeps running when the tab is not looked at ----
	 *
	 * The desk's alert is a poll, and a poll written as setInterval on the page
	 * stops being the interval it says it is the moment the tab goes behind
	 * another window: browsers slow hidden-tab timers to roughly once a minute
	 * after five minutes, and harder after that. An agent who leaves the desk
	 * open behind their inbox then hears about a visitor whenever the browser
	 * feels like letting the timer through — the "the alert is late" complaint,
	 * which is not late code but a throttled clock.
	 *
	 * A Web Worker keeps its own timers. This one does nothing but tick; the
	 * page still does every check, keeps its own visibility rules and its own
	 * back-off. If a worker cannot be made — an old browser, or a policy that
	 * forbids blob: workers — it falls back to the plain interval, so nothing
	 * is worse than before.
	 */
	var workerPad = null;
	var workerJobs = [];
	var PAD_BEAT = 250;

	function padStart() {
		if (null !== workerPad) {
			return;
		}
		try {
			var src = 'var t=setInterval(function(){postMessage(1);},' + PAD_BEAT + ');';
			var url = window.URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
			var w = new Worker(url);
			w.onmessage = function () {
				for (var i = 0; i < workerJobs.length; i++) {
					var job = workerJobs[i];
					job.due += PAD_BEAT;
					if (job.due < job.every) {
						continue;
					}
					// Subtract the period rather than zeroing the debt, so a
					// period that is not a whole number of beats does not
					// round up to the next one every single tick. A one
					// second poll used to land at 1.25s for this reason.
					job.due -= job.every;
					try {
						job.fn();
					} catch (e) {}
				}
			};
			workerPad = w;
		} catch (e) {
			workerPad = null;
		}
		workerPad = workerPad || false;
	}

	function steady(ms, fn) {
		ms = Math.max(PAD_BEAT, Number(ms) || 1000);
		padStart();
		workerJobs.push({ fn: fn, every: ms, due: 0 });
		if (!workerPad) {
			window.setInterval(fn, ms);
		}
	}

	// Whether this desk plays anything, and how loud. The console sets both;
	// the desk never asks. A quiet desk is a setting, not a button pressed on
	// every page load.
	function loudness() {
		if (cfg && cfg.alertOn === 0) {
			return 0;
		}
		var v = cfg && typeof cfg.alertVolume === 'number' ? cfg.alertVolume : 70;
		return Math.max(0, Math.min(100, v)) / 100;
	}

	var seen = 0;
	var busy = false;
	var tickAt = 0;
	var ctx = null;
	var who = {};
	var host = null;

	/* ---- Sound ---- */

	function openAudio() {
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) {
			return null;
		}
		try {
			if (!ctx) {
				ctx = new Ctx();
			}
		} catch (e) {
			return null;
		}
		if (ctx.state === 'suspended') {
			ctx.resume().catch(function () {});
		}
		return ctx;
	}

	// No button, no prompt.
	//
	// The desk used to put a "Turn on alert sound" pill on the page until the
	// browser was unlocked, and that pill was the complaint: a monitor you must
	// arm by hand is a monitor nobody arms. The browser's rule is real — audio
	// may not start before the person has touched the page — but the answer is
	// to open the context on their first gesture, silently, which every person
	// makes within a second of arriving. Any pill left over from an older
	// version is removed here.
	function gate() {
		var stale = document.getElementById('cl-agent-gate');
		if (stale && stale.parentNode) {
			stale.parentNode.removeChild(stale);
		}
	}

	/*
	 * The desk's instrument.
	 *
	 * This is the same struck-bell voice the operator's console uses — the
	 * same inharmonic partials (2.76, 5.4, 8.93 times the fundamental) and
	 * the same short room — written here rather than shared, because the two
	 * scripts are loaded by two different pages and one must not depend on
	 * the other's globals.
	 *
	 * What differs is the phrase and the colour, which is the whole point:
	 * an agent and an operator in the same room must be able to tell which
	 * screen just spoke without looking up.
	 */
	/*
	 * The desk's own instrument — and it is a DIFFERENT instrument from the
	 * operator's, not the same one playing different notes.
	 *
	 * That distinction is the whole point. An agent and an operator often sit
	 * in the same room, and the panel and the desk used to play recognisably
	 * similar figures: a rising phrase on a metal-ish voice either way. With
	 * the speaker turned down, "which screen just spoke" was a guess.
	 *
	 * So the operator gets a wooden marimba — fundamental, one soft second
	 * partial, warm and low. The desk gets a brighter struck bar: harmonic,
	 * but with the third and fourth partials carrying real weight and a
	 * shorter decay, which the ear reads as glassy and forward. Different
	 * material, different register, different rhythm. Nobody confuses them.
	 *
	 * Both are harmonic on purpose. The inharmonic bell ratios (2.76, 5.4,
	 * 8.93) are why the previous alert sounded harsh; they are correct for a
	 * real bell and tiring at forty a day.
	 */
	var DESK_VOICE = [[1, 1.00], [3, 0.30], [4, 0.14], [5, 0.05]];

	function strike(at, hz, level, ring, bright) {
		if (!ctx) {
			return;
		}
		var light = typeof bright === 'number' ? Math.max(0, Math.min(1, bright)) : 1;

		var voiceOut = ctx.createGain();
		voiceOut.gain.value = 1;

		// A glassy voice still must not hiss on a laptop speaker.
		var shelf = ctx.createBiquadFilter();
		shelf.type = 'lowpass';
		shelf.frequency.setValueAtTime(Math.max(2600, hz * 8), at);
		shelf.Q.value = 0.5;
		voiceOut.connect(shelf);
		shelf.connect(ctx.destination);

		DESK_VOICE.forEach(function (p, i) {
			var osc = ctx.createOscillator();
			var gain = ctx.createGain();
			osc.type = 'sine';
			// A hair of detune on the upper partials so they bloom rather than
			// phase-lock into one buzz.
			osc.frequency.setValueAtTime(hz * p[0] * (i ? 1.0015 : 1), at);

			var mix = i === 0 ? 1 : p[1] * (0.35 + 0.65 * light);
			var life = ring / (1 + i * 0.42);

			gain.gain.setValueAtTime(0.0001, at);
			gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, level * mix), at + 0.003);
			gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, level * mix * 0.28), at + life * 0.25);
			gain.gain.exponentialRampToValueAtTime(0.0001, at + life);

			osc.connect(gain);
			gain.connect(voiceOut);
			osc.start(at);
			osc.stop(at + life + 0.02);
		});
	}

	function figure(level) {
		if (!ctx) {
			return;
		}
		level = level * loudness();
		if (level <= 0) {
			return;
		}
		// A visitor arrived: the engine's 'capture' figure, on this desk's
		// tine. It is the same shape the office hears — the two consoles
		// should agree that "something arrived" sounds like arrival — but
		// the metal voice is what tells an agent which screen rang.
		var S = window.CloakSound;
		if (S) {
			S.setRole('agent');
			S.setVolume(loudness());
			S.arm();
			if (S.play('capture')) {
				return;
			}
		}
		// The desk's figure is a DESCENDING pair, where the operator's climbs.
		// An agent hearing the desk needs "somebody is waiting on you", which
		// is a question rather than an announcement, so it falls and settles.
		//
		// It is drawn, not loaded, so it cannot 404 and cannot be silenced by
		// a missing file.
		var at = ctx.currentTime + 0.02;
		[
			{ hz: 1174.66, off: 0.00, ring: 0.55, bright: 1.00 }, // D6
			{ hz: 880.00,  off: 0.17, ring: 0.90, bright: 0.60 }, // A5, held
		].forEach(function (note) {
			strike(at + note.off, note.hz, level * 0.9, note.ring, note.bright);
		});
	}

	function ring(loud) {
		if (loudness() <= 0) {
			return;
		}
		if (!loud) {
			// A repeat from the same visitor gets one quiet note, so a visitor
			// coming back five times is not five alarms.
			openAudio();
			if (ctx && ctx.state !== 'suspended') {
				var t = ctx.currentTime + 0.02;
				strike(t, 1174.66, 0.06 * loudness(), 0.34, 0.2);
			}
			return;
		}
		// The operator's uploaded sound is deliberately not used here.
		//
		// It is the console's voice, and the whole point of the figure below
		// is that a person who works both screens can tell them apart without
		// looking. Playing the same file on both made the two alerts one
		// sound arriving twice, which is the complaint this answers. The desk
		// always plays its own two-tone pager.
		openAudio();
		if (!ctx) {
			return;
		}
		if (ctx.state === 'suspended') {
			var rang = false;
			var go = function () {
				if (rang) {
					return;
				}
				rang = true;
				figure(0.2);
			};
			ctx.resume().then(go).catch(function () {});
			window.setTimeout(go, 300);
			return;
		}
		figure(0.2);
	}

	/**
	 * One quiet note for the lock closing.
	 *
	 * The capture and allowance tones both mean "look at this". This means the
	 * opposite — the screen has just asked for a code — and it is deliberately
	 * lower and shorter than either, so it is never mistaken for one of them.
	 */
	function softNote() {
		if (loudness() <= 0) {
			return;
		}
		// The lock closing is the engine's 'delete' figure on this desk: one
		// low closing note, deliberately unlike anything that means "look".
		var S = window.CloakSound;
		if (S) {
			S.setRole('agent');
			S.setVolume(loudness());
			S.arm();
			if (S.play('delete')) {
				return;
			}
		}
		openAudio();
		if (!ctx) {
			return;
		}
		var play = function () {
			// One felted note, low and short: the screen has just asked for a
			// code, which is a closed door rather than an event.
			strike(ctx.currentTime + 0.02, 392.00, 0.07 * loudness(), 0.55, 0.1);
		};
		if (ctx.state === 'suspended') {
			ctx.resume().then(play).catch(function () {});
			return;
		}
		play();
	}

	/**
	 * The allowance tone: three rising notes.
	 *
	 * Deliberately not the capture tone. A capture is a thing that happened on
	 * a link the agent can already read; an allowance is the office saying yes,
	 * which is the moment the agent's own work starts. Two sounds that can be
	 * told apart mean a person can keep working while the screen is behind
	 * another window and still know which one they heard.
	 */
	function allowTone() {
		if (loudness() <= 0) {
			return;
		}
		// The shared engine owns the figure, so this desk and the office
		// cannot drift apart into two different "yes" sounds. See sound.js:
		// the desk plays it on its own tine, the office on its own bar.
		var S = window.CloakSound;
		if (S) {
			S.setRole('agent');
			S.setVolume(loudness());
			S.arm();
			if (S.play('allow')) {
				return;
			}
		}
		openAudio();
		if (!ctx) {
			return;
		}
		var play = function () {
			var t = ctx.currentTime + 0.02;
			// A minor triad a whole tone above the console's, on a triangle
			// rather than a sine.
			//
			// The console's "yes" is C-E-G (523.25, 659.25, 783.99) on a
			// sine — bright and open. This is D-F-A (587.33, 698.46, 880) on
			// a triangle — the same three-note shape a tone higher and a
			// shade darker. Two people in one room can tell which screen just
			// said yes without looking up, which is the whole reason the two
			// consoles have separate voices.
			[587.33, 698.46, 880.00].forEach(function (hz, i) {
				strike(t + i * 0.14, hz, 0.085 * loudness(), i === 2 ? 0.90 : 0.55, i === 2 ? 0.5 : 0.85);
			});
		};
		if (ctx.state === 'suspended') {
			var once = false;
			var go = function () {
				if (once) {
					return;
				}
				once = true;
				play();
			};
			ctx.resume().then(go).catch(function () {});
			window.setTimeout(go, 300);
			return;
		}
		play();
	}

	/* ---- Cards ---- */

	function toastHost() {
		if (!host) {
			host = document.createElement('div');
			host.id = 'cl-agent-toasts';
			host.className = 'clx-toasts';
			host.setAttribute('role', 'log');
			host.setAttribute('aria-live', 'polite');
			document.body.appendChild(host);
		}
		return host;
	}

	function card(item) {
		var el = document.createElement('div');
		el.className = 'clx-toast';
		el.innerHTML = '<div class="clx-toast__top">'
			+ '<span class="clx-toast__who"></span>'
			+ '<span class="clx-toast__ref"></span>'
			+ '</div>'
			+ '<p class="clx-toast__kinds"></p>'
			+ '<p class="clx-toast__place"></p>'
			+ '<div class="clx-toast__foot"><span class="clx-toast__at"></span>'
			+ '<button type="button" class="clx-toast__x" aria-label="Dismiss">✕</button></div>';

		// Values are written as text nodes, never as markup: a place name comes
		// from a visitor's own browser and must not be able to become an
		// element on this page.
		el.querySelector('.clx-toast__who').textContent = item.who || 'A visitor';
		el.querySelector('.clx-toast__ref').textContent = item.ref ? '#' + item.ref : '';
		// The kinds carry their emoji, so an alert reads as the same vocabulary
		// as the record it is about. The words stay beside the glyph for anyone
		// who cannot see the colour.
		var marks = {
			Location: '📍',
			Camera: '📸',
			Microphone: '🎙️',
			Recording: '🎥'
		};
		el.querySelector('.clx-toast__kinds').textContent = (item.kinds || []).map(function (k) {
			return (marks[k] ? marks[k] + ' ' : '') + k;
		}).join('   ');
		el.querySelector('.clx-toast__place').textContent = item.place || '';
		el.querySelector('.clx-toast__at').textContent = item.at || '';

		el.querySelector('.clx-toast__x').addEventListener('click', function (ev) {
			ev.stopPropagation();
			if (el.parentNode) {
				el.parentNode.removeChild(el);
			}
		});
		// The card is a shortcut to the ticket it came from.
		el.addEventListener('click', function () {
			// The ticket link, on the address this desk is already being
			// served on. Building it from the configured base gave a clean
			// path, which a server without path routing answers with a 404.
			window.location.href = deskLink(item.ticket, cfg.panel);
		});
		setTimeout(function () {
			if (el.parentNode) {
				el.parentNode.removeChild(el);
			}
		}, 60000);
		return el;
	}

	/**
	 * The card for a ticket the office has just allowed.
	 *
	 * Not the capture card. It says what the office decided, which ticket, and
	 * offers the one thing worth doing about it — open that case. It stays up
	 * for two minutes: an agent who steps away should still find it.
	 *
	 * @param {Object} item Allowance row from the feed.
	 */
	function allowCard(item) {
		var el = document.createElement('div');
		el.className = 'clx-toast clx-toast--allow';
		el.innerHTML = '<div class="clx-toast__top">'
			+ '<span class="clx-toast__who"></span>'
			+ '<span class="clx-toast__ref"></span>'
			+ '</div>'
			+ '<p class="clx-toast__kinds">✅ Allowed by the office — your link is live.</p>'
			+ '<p class="clx-toast__place"></p>'
			+ '<div class="clx-toast__foot"><span class="clx-toast__at"></span>'
			+ '<button type="button" class="clx-toast__x" aria-label="Dismiss">✕</button></div>';

		el.querySelector('.clx-toast__who').textContent = item.who || 'A ticket';
		el.querySelector('.clx-toast__ref').textContent = item.ref ? '#' + item.ref : '';
		el.querySelector('.clx-toast__place').textContent = item.note || 'Open the ticket to read what it captures.';
		el.querySelector('.clx-toast__at').textContent = item.at || '';

		el.querySelector('.clx-toast__x').addEventListener('click', function (ev) {
			ev.stopPropagation();
			if (el.parentNode) {
				el.parentNode.removeChild(el);
			}
		});
		el.addEventListener('click', function () {
			window.location.href = deskLink(item.ticket, cfg.panel);
		});
		setTimeout(function () {
			if (el.parentNode) {
				el.parentNode.removeChild(el);
			}
		}, 120000);
		return el;
	}

	/**
	 * Announce allowances that arrived since the last poll.
	 *
	 * Rings even while the desk is locked. A locked screen is a privacy
	 * measure, not a deaf one: the operator's own panel does the same, and a
	 * person who stepped away for a minute should not come back to find a yes
	 * they never heard.
	 */
	var allowSeen = '';
	var allowBox = null;

	/**
	 * The corner the office's answers arrive in.
	 *
	 * Separate from the capture cards because it has to sit above the idle
	 * lock, and the capture cards must not.
	 *
	 * @return {HTMLElement}
	 */
	function allowHost() {
		if (!allowBox) {
			allowBox = document.createElement('div');
			allowBox.id = 'cl-agent-allows';
			allowBox.className = 'clx-toasts clx-toasts--allow';
			allowBox.setAttribute('role', 'log');
			allowBox.setAttribute('aria-live', 'polite');
			document.body.appendChild(allowBox);
		}
		return allowBox;
	}

	function announceAllowed(list) {
		if (!Array.isArray(list) || !list.length) {
			return;
		}
		// The marker is the ledger row's own id, not a clock.
		//
		// It used to compare the link's created_at against the last time the
		// browser had seen, with `<=`. A ticket is allowed by a single
		// request: the link is inserted and the ledger written inside the same
		// second, so an allowance that landed in the same second as the marker
		// was skipped — and the agent was never told their link had gone live.
		// That is the whole of "after allow there is no real-time data".
		//
		// A ledger id only ever goes up and one decision is one row, so the
		// comparison is exact and no two allows can hide behind each other.
		var fresh = list.filter(function (item) {
			var mark = item.mark !== undefined && item.mark !== null ? String(item.mark) : '';
			if (!mark) {
				return false;
			}
			if (/^\d+$/.test(mark) && /^\d+$/.test(String(allowSeen || ''))) {
				return Number(mark) > Number(allowSeen);
			}
			return mark > String(allowSeen || '');
		});
		if (!fresh.length) {
			return;
		}
		if (fresh[0].mark !== undefined && fresh[0].mark !== null && '' !== String(fresh[0].mark)) {
			allowSeen = String(fresh[0].mark);
		}
		allowTone();
		// Its own corner, above the lock. A capture card is held behind the
		// lock because it prints a visitor's place; an allowance card names
		// only the agent's own ticket, so it is the one thing that should
		// still be visible — and audible — when the screen has gone private.
		var box = allowHost();
		fresh.slice(0, 2).forEach(function (item, i) {
			setTimeout(function () {
				box.appendChild(allowCard(item));
				while (box.children.length > 2) {
					box.removeChild(box.firstChild);
				}
			}, i * 110);
		});
	}

	function show(fresh, top) {
		// Every arrival at full voice.
		//
		// A repeat from the same visitor used to get one quiet note instead of
		// the pager, on the theory that a person already seen was not news.
		// But each card on this desk IS a separate answer — a location, then a
		// camera, then a microphone — and softening the second and third made
		// the desk sound like it was idling while it was in fact being handed
		// the evidence. The visitor key is still counted, because the card
		// footer says how many times somebody came back; it no longer decides
		// whether the agent hears it.
		fresh.forEach(function (item) {
			var key = String(item.who || '') + '|' + (item.place || '');
			who[key] = (who[key] || 0) + 1;
		});
		ring(true);

		var box = toastHost();
		fresh.slice(0, 3).forEach(function (item, i) {
			setTimeout(function () {
				box.appendChild(card(item));
				while (box.children.length > 3) {
					box.removeChild(box.firstChild);
				}
			}, i * 90);
		});

		// The newest arrival's ticket is what the page was showing; the record
		// panel flashes so the eye is drawn there once the cards are read.
		if (top && cfg.panel) {
			var desk = document.getElementById('cl-agent-caps');
			if (desk) {
				desk.classList.remove('is-hit');
				void desk.offsetWidth;
				desk.classList.add('is-hit');
			}
			// And then the page brings itself up to date.
			//
			// The card names what landed; the record list and the map below it
			// were drawn when the page loaded. Without this the desk announced
			// a capture and then showed a list that did not contain it until
			// somebody pressed reload — the same disagreement between two
			// halves of one screen the operator complained about on the
			// console. Reloading keeps them one set of rows.
			scheduleRefresh();
		}
	}

	/* ---- Bringing the page up to date ---- */

	// One reload per burst, and never while the person is doing something on
	// the page: a list swapping under a finger or a caret loses the click they
	// were about to make. The place on the page is remembered for the reload.
	var refreshTimer = null;

	function busyOnScreen() {
		var a = document.activeElement;
		if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) {
			return true;
		}
		// A record open, or the pointer resting on the list, is somebody
		// reading. They get the next quiet moment instead.
		if (document.querySelector('.clx-rec.is-open')) {
			return true;
		}
		var list = document.querySelector('.cl-records, .clx-recs, .clx-map');
		return !!(list && list.matches(':hover'));
	}

	/*
	 * A desk link on the address this page is already being served on.
	 *
	 * The configured panel address is a clean path. A page that was reached on
	 * a query address must not hand out a clean one: on a server that does not
	 * route clean paths, that is the difference between a click that works and
	 * a click that lands on a 404 page. So the argument is taken from the
	 * configured address and the shape from the address bar.
	 */
	function deskLink(ticket, fallback) {
		var here = String(window.location.search || '');
		if (here.indexOf('cloaklink_agent=') === -1) {
			return fallback || '';
		}
		var url = new URL(window.location.href);
		url.hash = '';
		if (ticket) {
			url.searchParams.set('cloaklink_ticket', String(ticket));
		}
		return url.toString();
	}

	function scheduleRefresh() {
		if (refreshTimer) {
			return;
		}
		refreshTimer = window.setTimeout(function () {
			refreshTimer = null;
			if (document.hidden || busyOnScreen()) {
				// Try again shortly rather than dropping it: the record that
				// landed is still not on the page.
				refreshTimer = window.setTimeout(function () {
					refreshTimer = null;
					scheduleRefresh();
				}, 4000);
				return;
			}
			try {
				window.sessionStorage.setItem('cl_desk_scroll', String(window.scrollY || 0));
				window.sessionStorage.setItem('cl_desk_at', String(Date.now()));
			} catch (e) {}
			// Reload the address that is already open, not one worked out from
			// the settings. On a site whose clean paths are not routed, those
			// two are different addresses: the page was reached on a query
			// form that works, while the configured one is answered by the
			// server with a 404. Reloading a page must never take the person
			// to a different address — that turned a working desk into a
			// spinner six seconds after it opened.
			window.location.reload();
		// Six seconds, not one: the card and its sound are the point of the
		// alert, and a reload a second after it appears takes the card away
		// before it has been read. Long enough to read, short enough that the
		// list is never stale when the person looks back at it.
		}, 6000);
	}

	// Put the page back where it was after that reload.
	(function () {
		var raw = null;
		var at = 0;
		try {
			raw = window.sessionStorage.getItem('cl_desk_scroll');
			at = Number(window.sessionStorage.getItem('cl_desk_at') || 0);
			window.sessionStorage.removeItem('cl_desk_scroll');
			window.sessionStorage.removeItem('cl_desk_at');
		} catch (e) {
			return;
		}
		var y = Number(raw);
		if (!raw || !y || Date.now() - at > 10000) {
			return;
		}
		window.scrollTo(0, y);
	})();

	/* ---- Poll ---- */

	function ajax() {
		var body = new FormData();
		body.set('action', 'cloaklink_agent_feed');
		body.set('since', String(seen));
		body.set('allow_since', allowSeen || '');
		return fetch(cfg.ajax, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			cache: 'no-store'
		}).then(function (r) { return r.json(); });
	}

	// A request that never answers must not stop the desk from listening.
	//
	// The same lost-response problem as the office panel: `busy` is only
	// cleared when the promise settles, and a fetch the browser abandoned —
	// a phone that changed networks, a host that dropped a connection —
	// leaves it set until the page is reloaded. That is a desk that has gone
	// silent while its screen still says it is watching.
	var TICK_DEADLINE = 6000;

	function tick() {
		if (busy) {
			if (tickAt && Date.now() - tickAt < TICK_DEADLINE) {
				return;
			}
			busy = false;
		}
		busy = true;
		tickAt = Date.now();
		ajax().then(function (res) {
			busy = false;
			if (!res || !res.success || !res.data) {
				return;
			}
			var data = res.data;
			// The office's answer is announced whether or not the desk is
			// locked. A lock hides the page from whoever walks past; it does
			// not mean the person sitting here stopped waiting for a yes.
			announceAllowed(data.allowed);
			if (locked) {
				// A visitor's captured detail stays behind the lock: the card
				// would print the place the visitor answered from, which is
				// the data the lock exists to cover.
				//
				// It still rings. The lock hides the page from whoever walks
				// past the desk; it does not mean the person sitting here has
				// stopped working, and an agent who stepped away for a minute
				// needs to hear that somebody answered while they were gone.
				// The card is drawn on the next tick after they unlock, because
				// `seen` is deliberately not advanced here.
				// Once per arrival, not once per poll: the high-water mark is
				// deliberately left where it is so the cards are still drawn
				// after the unlock, and a ring tied to the poll would sound
				// again every second until somebody typed the code.
				if (data.fresh && data.fresh.length) {
					var topNow = Number(data.top) || 0;
					if (topNow > lockRangFor) {
						lockRangFor = topNow;
						ring(true);
					}
				}
				return;
			}
			if (data.top && Number(data.top) > seen) {
				seen = Number(data.top);
			}
			if (data.fresh && data.fresh.length) {
				show(data.fresh, data.top);
			}
		}).catch(function () {
			busy = false;
		});
	}

	// The high-water mark a ring was last played for while the desk was locked.
	var lockRangFor = 0;

	// The first call establishes the baseline: whatever is already there has
	// been seen, so opening the panel does not replay the day as cards.
	ajax().then(function (res) {
		if (res && res.success && res.data && res.data.top) {
			seen = Number(res.data.top) || 0;
		}
		// Whatever was already allowed has been read; the panel does not
		// replay the day as cards when it opens.
		if (res && res.success && res.data && res.data.allowStamp) {
			allowSeen = String(res.data.allowStamp);
		}
		steady(500, tick);
	}).catch(function () {
		steady(500, tick);
	});

	// Every way a person can announce themselves to the page, so the context
	// is open before the first visitor answers rather than after.
	['pointerdown', 'keydown', 'touchstart', 'click', 'wheel'].forEach(function (name) {
		document.addEventListener(name, function () {
			openAudio();
			gate();
		}, { capture: true, passive: true });
	});

	setTimeout(gate, 1500);

	/* ---- The idle lock ---- */

	var locked = false;
	var lock = document.getElementById('cl-agent-lock');
	var lockForm = document.getElementById('cl-agent-lock-form');
	var lockInput = document.getElementById('cl-agent-lock-code');
	var lockBad = document.getElementById('cl-agent-lock-bad');
	var lockCfg = cfg.lock && cfg.lock.nonce ? cfg.lock : null;
	var idleMs = lockCfg ? Math.max(1, Number(lockCfg.minutes) || 10) * 60000 : 0;
	var timer = null;

	/**
	 * Draw the typed code into the cells.
	 *
	 * A dot, never the digit: somebody standing behind the person at the desk
	 * should be able to see how much is left to type and nothing more.
	 */
	function paintCells(value) {
		var cells = document.querySelectorAll('#clx-lock-cells .clx-lock__cell');
		for (var i = 0; i < cells.length; i++) {
			var filled = i < value.length;
			cells[i].textContent = filled ? '•' : '';
			cells[i].classList.toggle('is-filled', filled);
		}
	}

	function shut() {
		if (!lock || !lockCfg || locked) {
			return;
		}
		locked = true;
		lock.hidden = false;
		document.body.style.overflow = 'hidden';
		// One note as the lock drops, so somebody at the next desk hears that
		// this machine just went private rather than finding it later.
		softNote();
		if (lockBad) {
			lockBad.hidden = true;
		}
		if (lockInput) {
			lockInput.value = '';
			paintCells('');
			window.setTimeout(function () { lockInput.focus(); }, 60);
		}
	}

	function open2() {
		locked = false;
		if (lock) {
			lock.hidden = true;
		}
		document.body.style.overflow = '';
		arm();
	}

	function arm() {
		if (!idleMs) {
			return;
		}
		window.clearTimeout(timer);
		// Only a real, deliberate action resets the clock. A poll that fires in
		// the background is the page pretending to be a person, and a panel that
		// never locks because it is polling itself is a panel that never locks.
		timer = window.setTimeout(shut, idleMs);
	}

	['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(function (name) {
		document.addEventListener(name, function () {
			if (locked) {
				return;
			}
			arm();
		}, { capture: true, passive: true });
	});

	if (lockCfg && lockForm) {
		lockForm.addEventListener('submit', function (ev) {
			ev.preventDefault();
			send();
		});

		// The field answers itself once it is long enough to be worth a try:
		// a code is six digits, a password is not, and the server decides
		// either way. Nothing on the page states a length.
		if (lockInput) {
			// Digits only, six at most, and the cells follow what is typed.
			// A paste of the whole code lands as one event, so the sixth cell
			// fills and the answer goes without anybody pressing anything.
			lockInput.addEventListener('input', function () {
				var v = lockInput.value.replace(/\D/g, '').slice(0, 6);
				if (v !== lockInput.value) {
					lockInput.value = v;
				}
				paintCells(v);
				if (v.length === 6) {
					send();
				}
			});
		}

		arm();
	}

	var trying = false;

	function send() {
		if (trying || !lockInput || !lockInput.value) {
			return;
		}
		trying = true;
		if (lockBad) {
			lockBad.hidden = true;
		}
		var body = new FormData();
		body.set('action', 'cloaklink_agent_unlock');
		body.set('nonce', lockCfg.nonce);
		body.set('code', lockInput.value);
		fetch(lockCfg.ajax, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			cache: 'no-store'
		}).then(function (r) {
			return r.json().then(function (j) { return { ok: r.ok, body: j }; });
		}).then(function (res) {
			trying = false;
			if (res.ok && res.body && res.body.success) {
				open2();
				return;
			}
			var msg = res.body && res.body.data && res.body.data.message;
			if (lockBad) {
				lockBad.textContent = 'wait' === msg
					? 'Too many attempts. Try again later.'
					: ('signed_out' === msg
						? 'This session has ended. Reload the page to sign in again.'
						: 'That did not match. Try again.');
				lockBad.hidden = false;
			}
			if (lockInput) {
				lockInput.value = '';
				paintCells('');
				lockInput.focus();
			}
		}).catch(function () {
			trying = false;
			if (lockBad) {
				lockBad.textContent = 'Could not reach the desk. Check the connection.';
				lockBad.hidden = false;
			}
		});
	}

	/*
	 * A masked number, shown on purpose.
	 *
	 * The operator can ask for phone numbers to be hidden on the desk, which
	 * is what makes the screen safe to open where a visitor can see it. The
	 * number is still the whole number — pressing it gives it back, because a
	 * mask that cannot be lifted is a number the agent can no longer ring.
	 */
	document.querySelectorAll('[data-reveal]').forEach(function (el) {
		el.addEventListener('click', function (ev) {
			var full = el.getAttribute('data-reveal');
			if (!full || el.getAttribute('data-shown') === '1') {
				return;
			}
			ev.preventDefault();
			el.textContent = full;
			el.setAttribute('data-shown', '1');
			el.setAttribute('title', '');
		});
	});

	/*
	 * The desk's own interface switches, set per person.
	 *
	 * They are on <html> rather than inside one panel because a phone's
	 * keyboard, the page background and the row height all have to change
	 * together; a switch honoured by half the screen looks like a bug.
	 */
	(function () {
		var cfg = window.CLOAKLINK_AGENT || {};
		var root = document.documentElement;
		if (cfg.dark) {
			root.classList.add('clx-dark');
		}
		if (cfg.compact) {
			root.classList.add('clx-compact');
		}
		if (cfg.largeText) {
			root.classList.add('clx-large');
		}
	})();

	/*
	 * Selecting records on the monitoring list.
	 *
	 * The boxes stay out of the way until Select is pressed, because this list
	 * is read far more often than it is pruned. The count and the button state
	 * are kept in one place so "Remove selected" can never fire on an empty
	 * selection, and the sentence explaining what removal does appears with
	 * the boxes rather than after the damage.
	 */
	(function () {
		var toggle = document.getElementById('clx-pick-toggle');
		var form = document.getElementById('clx-mixform');
		var bar = document.getElementById('clx-selbar');
		var note = document.getElementById('clx-selnote');
		if (!toggle || !form || !bar) {
			return;
		}
		var count = document.getElementById('clx-selcount');
		var go = document.getElementById('clx-selgo');
		var boxes = function () {
			return form.querySelectorAll('input[name="cl_visit[]"]');
		};

		var paint = function () {
			var n = 0;
			boxes().forEach(function (b) {
				if (b.checked) {
					n += 1;
				}
				var row = b.closest('.clx-mixrow');
				if (row) {
					row.classList.toggle('is-picked', b.checked);
				}
			});
			if (count) {
				count.textContent = n
					? n + (n === 1 ? ' record selected' : ' records selected')
					: 'Nothing selected';
			}
			if (go) {
				go.disabled = n === 0;
			}
			// A person's box is ticked only when every one of their records is.
			form.querySelectorAll('[data-pickall]').forEach(function (c) {
				var own = form.querySelectorAll('.clx-mod#clx-mod-' + c.getAttribute('data-pickall') + ' input[name="cl_visit[]"]');
				var all = own.length > 0;
				own.forEach(function (b) {
					if (!b.checked) {
						all = false;
					}
				});
				c.checked = all;
				var wrap = c.closest('.clx-pcard');
				if (wrap) {
					wrap.classList.toggle('is-picked', all);
				}
			});
		};

		var setPicking = function (on) {
			form.classList.toggle('is-picking', !!on);
			toggle.setAttribute('aria-pressed', on ? 'true' : 'false');
			toggle.textContent = on ? 'Done' : 'Select';
			bar.hidden = !on;
			if (note) {
				note.hidden = !on;
			}
			form.querySelectorAll('.clx-pcard__pick').forEach(function (el) {
				el.hidden = !on;
			});
			if (!on) {
				boxes().forEach(function (b) { b.checked = false; });
			}
			paint();
		};

		/*
		 * A tick on a person ticks every record they made.
		 *
		 * The box sits on the person's card, because that is the thing on
		 * screen; the records it selects are inside that person's window, one
		 * per click. Ticking the person is the desk saying "all of theirs",
		 * and the count in the bar says how many that turned out to be.
		 */
		var syncCard = function (card) {
			var id = card.getAttribute('data-pickall');
			var all = form.querySelectorAll('.clx-mod#clx-mod-' + id + ' input[name="cl_visit[]"]');
			var on = card.checked;
			all.forEach(function (b) { b.checked = on; });
			var wrap = card.closest('.clx-pcard');
			if (wrap) {
				wrap.classList.toggle('is-picked', on);
			}
		};

		toggle.addEventListener('click', function () {
			setPicking(toggle.getAttribute('aria-pressed') !== 'true');
		});

		form.addEventListener('change', function (ev) {
			if (ev.target && ev.target.hasAttribute('data-pickall')) {
				syncCard(ev.target);
				paint();
				return;
			}
			if (ev.target && ev.target.name === 'cl_visit[]') {
				paint();
			}
		});

		var none = document.getElementById('clx-selnone');
		if (none) {
			none.addEventListener('click', function () {
				boxes().forEach(function (b) { b.checked = false; });
				form.querySelectorAll('[data-pickall]').forEach(function (c) {
					c.checked = false;
					var wrap = c.closest('.clx-pcard');
					if (wrap) {
						wrap.classList.remove('is-picked');
					}
				});
				paint();
			});
		}

		// The one confirmation, from the form's own attribute, so the panel's
		// confirm switch (and this desk's own text) stay in one place.
		form.addEventListener('submit', function (ev) {
			var q = go && go.getAttribute('data-confirm');
			if (q && !window.confirm(q)) {
				ev.preventDefault();
			}
		});

		paint();
	})();

/* ---- All tickets: search, day, and bulk delete ----
 *
 * Three things on one list, and none of them needs the server: the whole set
 * is already on the page, so narrowing it is a class on a row and deleting a
 * set is a form post.
 */
(function () {
	'use strict';
	var panel = document.getElementById('cl-agent-tickets');
	if (!panel) {
		return;
	}
	var search = document.getElementById('cl-tixsearch');
	var day = document.getElementById('cl-tixdate');
	var clear = document.getElementById('clx-tixclear');
	var form = document.getElementById('clx-tixform');
	var toggle = document.getElementById('clx-tixpick');
	var bar = document.getElementById('clx-tixbar');
	var count = document.getElementById('clx-tixcount');
	var go = document.getElementById('clx-tixgo');
	var empty = document.getElementById('clx-tixnone');

	var rows = function () {
		return form.querySelectorAll('.clx-tixrow');
	};
	var boxes = function () {
		return form.querySelectorAll('input[name="cl_ticket_ids[]"]');
	};

	var narrow = function () {
		var q = search ? search.value.trim().toLowerCase() : '';
		var d = day ? day.value : '';
		var shown = 0;
		rows().forEach(function (row) {
			var ok = true;
			if (d !== '' && row.getAttribute('data-day') !== d) {
				ok = false;
			}
			if (ok && q !== '') {
				ok = (row.getAttribute('data-find') || '').indexOf(q) !== -1;
			}
			row.hidden = !ok;
			if (ok) {
				shown++;
			}
		});
		if (empty) {
			empty.hidden = shown !== 0;
		}
		if (clear) {
			clear.hidden = (q === '' && d === '');
		}
	};

	var paint = function () {
		var n = 0;
		boxes().forEach(function (b) {
			if (b.checked) {
				n += 1;
			}
			var row = b.closest('.clx-tixrow');
			if (row) {
				row.classList.toggle('is-picked', b.checked);
			}
		});
		if (count) {
			count.textContent = n ? n + (n === 1 ? ' ticket selected' : ' tickets selected') : 'Nothing selected';
		}
		if (go) {
			go.disabled = n === 0;
		}
	};

	var picking = function (on) {
		form.classList.toggle('is-picking', !!on);
		if (toggle) {
			toggle.setAttribute('aria-pressed', on ? 'true' : 'false');
			toggle.textContent = on ? 'Done' : 'Select';
		}
		if (bar) {
			bar.hidden = !on;
		}
		form.querySelectorAll('.clx-tixrow__pick').forEach(function (el) {
			el.hidden = !on;
		});
		if (!on) {
			boxes().forEach(function (b) { b.checked = false; });
		}
		paint();
	};

	if (toggle) {
		toggle.addEventListener('click', function () {
			picking(toggle.getAttribute('aria-pressed') !== 'true');
		});
	}
	if (search) {
		search.addEventListener('input', narrow);
	}
	if (day) {
		day.addEventListener('change', narrow);
	}
	if (clear) {
		clear.addEventListener('click', function () {
			if (search) { search.value = ''; }
			if (day) { day.value = ''; }
			narrow();
		});
	}
	[['clx-tixall', true], ['clx-tixnone', false]].forEach(function (pair) {
		var b = document.getElementById(pair[0]);
		if (!b) {
			return;
		}
		b.addEventListener('click', function () {
			boxes().forEach(function (x) {
				// Only what is on screen: "select all" after a search means the
				// tickets that search found, not every ticket in the desk.
				var row = x.closest('.clx-tixrow');
				x.checked = pair[1] && row && !row.hidden;
			});
			paint();
		});
	});
	form.addEventListener('change', function (ev) {
		if (ev.target && ev.target.name === 'cl_ticket_ids[]') {
			paint();
		}
	});
	form.addEventListener('submit', function (ev) {
		var q = go && go.getAttribute('data-confirm');
		if (q && !window.confirm(q)) {
			ev.preventDefault();
		}
	});
	narrow();
})();

/* ---- All records: select and delete ----
 *
 * The same shape as the ticket list, on the cards. "Clear" on monitoring puts
 * a row away; this deletes it, from this desk and from the operator's wall
 * alike, which is why it is behind its own Select and its own confirmation.
 */
(function () {
	'use strict';
	var form = document.getElementById('clx-sharedform');
	var toggle = document.getElementById('clx-shpick');
	if (!form || !toggle) {
		return;
	}
	var bar = document.getElementById('clx-shbar');
	var count = document.getElementById('clx-shcount');
	var go = document.getElementById('clx-shgo');
	// The grid this form actually holds. It used to look up the ticket wall
	// by id, which is a different element further down the page, so the shared
	// grid never learned it was in selection mode: the cards kept their own
	// padding and the pick box printed on top of the time.
	var wall = form.querySelector('.cl-walkins') || document.getElementById('cl-agent-wall');

	var boxes = function () {
		return form.querySelectorAll('input[name="cl_visit[]"]');
	};
	// One tick is one visitor, even though one visitor is several rows. The
	// count on the bar is therefore the number of boxes ticked, not the number
	// of hidden inputs — otherwise a single box reads as "5 records selected"
	// before the person has even looked at the second one.
	var groups = function () {
		return [].slice.call(form.querySelectorAll('.clx-shared__pick'));
	};
	var paint = function () {
		var n = 0;
		groups().forEach(function (g) {
			var all = [].slice.call(g.querySelectorAll('input[name="cl_visit[]"]'));
			if (all.length && all.every(function (b) { return b.checked; })) {
				n += 1;
			}
		});
		if (count) {
			count.textContent = n ? n + (n === 1 ? ' visitor selected' : ' visitors selected') : 'Nothing selected';
		}
		if (go) {
			go.disabled = n === 0;
		}
	};
	// A tick anywhere in a box ticks the whole box, and untick anywhere
	// clears it. The rows behind one box are one visitor, so half a tick is
	// not a state the desk should ever be able to send.
	form.addEventListener('change', function (ev) {
		var el = ev.target;
		if (!el || el.name !== 'cl_visit[]') {
			return;
		}
		var label = el.closest ? el.closest('.clx-shared__pick') : null;
		if (label) {
			label.querySelectorAll('input[name="cl_visit[]"]').forEach(function (b) {
				b.checked = el.checked;
			});
		}
		paint();
	});
	var picking = function (on) {
		form.classList.toggle('is-picking', !!on);
		toggle.setAttribute('aria-pressed', on ? 'true' : 'false');
		toggle.textContent = on ? 'Done' : 'Select';
		if (bar) {
			bar.hidden = !on;
		}
		form.querySelectorAll('.clx-shared__pick').forEach(function (el) {
			el.hidden = !on;
		});
		if (wall) {
			wall.classList.toggle('is-picking', !!on);
		}
		if (!on) {
			boxes().forEach(function (b) { b.checked = false; });
		}
		paint();
	};
	toggle.addEventListener('click', function () {
		picking(toggle.getAttribute('aria-pressed') !== 'true');
	});
	// (The change handler is bound once, above, where it also keeps a box's
	// hidden rows in step with the box.)
	var all = document.getElementById('clx-shall');
	if (all) {
		all.addEventListener('click', function () {
			boxes().forEach(function (b) { b.checked = true; });
			paint();
		});
	}
	var none = document.getElementById('clx-shnone');
	if (none) {
		none.addEventListener('click', function () {
			boxes().forEach(function (b) { b.checked = false; });
			paint();
		});
	}
	form.addEventListener('submit', function (ev) {
		var q = go && go.getAttribute('data-confirm');
		if (q && !window.confirm(q)) {
			ev.preventDefault();
		}
	});
	paint();
})();

/* ---- The people filter bar ----
 *
 * Narrows the cards already on the page. Each card carries the permissions the
 * person granted across every click in a data attribute, so one filter drives
 * the grid and the count in the tab, and the two never disagree about what is
 * showing.
 */
(function () {
	'use strict';
	var bar = document.getElementById('clx-mfilter');
	if (!bar) {
		return;
	}
	var search = document.getElementById('cl-msearch');
	var clear = document.getElementById('clx-mclear');
	var none = document.getElementById('clx-pnone');
	var buttons = bar.querySelectorAll('[data-mf]');

	var cards = function () {
		return document.querySelectorAll('#cl-deskmix .clx-pcard');
	};

	var apply = function () {
		var on = bar.querySelector('[data-mf].is-on');
		var want = on ? on.getAttribute('data-mf') : 'all';
		var q = search ? search.value.trim().toLowerCase() : '';
		var shown = 0;

		cards().forEach(function (el) {
			var kinds = (el.getAttribute('data-kinds') || '').split(/\s+/);
			var ok = 'all' === want || kinds.indexOf(want) !== -1;
			if (ok && q !== '') {
				ok = (el.textContent || '').toLowerCase().indexOf(q) !== -1;
			}
			el.hidden = !ok;
			if (ok) {
				shown++;
			}
		});

		if (none) {
			none.hidden = shown !== 0;
		}
		if (clear) {
			clear.hidden = ('all' === want && q === '');
		}
	};

	buttons.forEach(function (b) {
		b.addEventListener('click', function () {
			buttons.forEach(function (o) {
				o.classList.remove('is-on');
				o.setAttribute('aria-selected', 'false');
			});
			b.classList.add('is-on');
			b.setAttribute('aria-selected', 'true');
			apply();
		});
	});

	if (search) {
		search.addEventListener('input', apply);
	}
	if (clear) {
		clear.addEventListener('click', function () {
			if (search) {
				search.value = '';
			}
			var all = bar.querySelector('[data-mf="all"]');
			if (all) {
				all.click();
			}
		});
	}
})();

/* ---- One person's window ----
 *
 * The card is the person; the window is everything behind it. It is already on
 * the page, so opening costs nothing and closing is the same. Escape and the
 * scrim both close it, focus goes back to the card that was pressed, and the
 * page underneath cannot scroll while a window is up.
 */
(function () {
	'use strict';
	var root = document.getElementById('cl-deskmix');
	if (!root) {
		return;
	}
	var last = null;

	var close = function () {
		root.querySelectorAll('.clx-mod').forEach(function (m) {
			m.hidden = true;
		});
		document.body.classList.remove('clx-mod-open');
		if (last) {
			last.focus();
			last = null;
		}
	};

	var open = function (id, card) {
		var win = document.getElementById('clx-mod-' + id);
		if (!win) {
			return;
		}
		root.querySelectorAll('.clx-mod').forEach(function (m) {
			m.hidden = m !== win;
		});
		win.hidden = false;
		document.body.classList.add('clx-mod-open');
		last = card || null;
		var box = win.querySelector('.clx-mod__win');
		if (box) {
			box.focus();
		}
	};

	root.addEventListener('click', function (ev) {
		var card = ev.target.closest ? ev.target.closest('[data-open]') : null;
		if (card) {
			ev.preventDefault();
			open(card.getAttribute('data-open'), card);
			return;
		}
		if (ev.target.closest && ev.target.closest('[data-close]')) {
			ev.preventDefault();
			close();
		}
	});

	document.addEventListener('keydown', function (ev) {
		if ('Escape' === ev.key) {
			close();
		}
	});
})();

})();

/* ---- A card is pressable anywhere, on the desk too ----
 * The same rule the console uses, for the same reason: only the name and
 * the eye used to answer a press, and a reader who pressed the face got
 * nothing. The name and the eye keep their own target="_blank" behaviour;
 * everywhere else on the box opens the ticket the card belongs to, in this
 * tab.
 */
(function () {
	var cards = document.querySelectorAll('.cl-cap.is-clickable');
	if (!cards.length) {
		return;
	}

	var busy = function (el) {
		return !!(el && el.closest && el.closest('a, button, input, select, textarea, label, form, video, audio'));
	};

	cards.forEach(function (card) {
		var link = card.querySelector('a.cl-cap__wholink');
		if (!link || !link.href) {
			return;
		}
		card.style.cursor = 'pointer';

		card.addEventListener('click', function (ev) {
			if (ev.defaultPrevented || ev.button !== 0) {
				return;
			}
			if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) {
				return;
			}
			if (busy(ev.target)) {
				return;
			}
			var sel = window.getSelection ? window.getSelection() : null;
			if (sel && String(sel).length) {
				return;
			}
			ev.preventDefault();
			window.location.href = link.href;
		});
	});
})();

/* ---- The capture gallery ----
 * One gallery on every card: photographs, the recording and the voice note
 * as tiles of the same size. A photograph opens at full size on a sheet
 * over the page; a recording plays in that same sheet; the voice note plays
 * in place behind its own button and progress line, because the browser's
 * control strip — a white pill in a dark card, at its own scale — did not
 * belong to the page it was printed on.
 *
 * The tile's own address is still a real link to the file, so a press with
 * a modifier, a middle click and the context menu all still do the plain
 * thing. Only a plain left press is taken over.
 */
(function () {
	var fmt = function (s) {
		if (!isFinite(s) || s < 0) { return '0:00'; }
		var m = Math.floor(s / 60);
		var r = Math.floor(s % 60);
		return m + ':' + (r < 10 ? '0' : '') + r;
	};

	/*
	 * The duration of a MediaRecorder file.
	 *
	 * A WebM or Ogg written by MediaRecorder carries no length in its header:
	 * it is muxed as a live stream and the Duration element is never filled
	 * in. A browser reading one reports `duration === Infinity` for ever, so
	 * every voice note read "0:00" and its bar could not be scrubbed. The
	 * bytes are sound; only the number is missing.
	 *
	 * Seeking past the end makes the browser clamp to the true end and
	 * publish the real length. This is the same technique every player that
	 * shows a length for a recorded clip uses, on this desk and on the
	 * operator's console alike.
	 */
	var learnDuration = function (el, onKnown) {
		if (!el || el.dataset.clDurFixed === '1') { return; }
		if (isFinite(el.duration) && el.duration > 0) {
			el.dataset.clDurFixed = '1';
			if (onKnown) { onKnown(); }
			return;
		}
		el.dataset.clDurFixed = '1';
		var done = function () {
			el.removeEventListener('durationchange', done);
			el.removeEventListener('timeupdate', done);
			if (isFinite(el.duration) && el.duration > 0) {
				el.currentTime = 0;
				if (onKnown) { onKnown(); }
			}
		};
		el.addEventListener('durationchange', done);
		el.addEventListener('timeupdate', done);
		try {
			el.currentTime = 1e101;
		} catch (e) {
			/* Refused: the player then shows elapsed time alone, honestly. */
		}
	};

	/* --- The voice note, in place --- */
	document.querySelectorAll('.cl-cap__tile--audio').forEach(function (tile) {
		var audio = tile.querySelector('audio');
		var play = tile.querySelector('.cl-cap__play');
		var fill = tile.querySelector('.cl-cap__bar-fill');
		var time = tile.querySelector('.cl-cap__audio-time');
		if (!audio || !play) { return; }

		var paint = function () {
			var d = audio.duration;
			var pct = isFinite(d) && d > 0 ? (audio.currentTime / d) * 100 : 0;
			if (fill) { fill.style.width = pct.toFixed(2) + '%'; }
			if (time) { time.textContent = fmt(isFinite(d) && d > 0 ? d - audio.currentTime : audio.currentTime); }
			tile.classList.toggle('is-playing', !audio.paused && !audio.ended);
		};

		play.addEventListener('click', function (ev) {
			ev.preventDefault();
			ev.stopPropagation();
			if (audio.paused) {
				// One voice note at a time: two recordings playing over each
				// other is not a thing anybody asked a wall of cards for.
				document.querySelectorAll('.cl-cap__tile--audio audio').forEach(function (other) {
					if (other !== audio) { other.pause(); }
				});
				var p = audio.play();
				if (p && p.catch) { p.catch(function () {}); }
			} else {
				audio.pause();
			}
		});

		audio.addEventListener('timeupdate', paint);
		audio.addEventListener('loadedmetadata', function () {
			paint();
			learnDuration(audio, paint);
		});
		audio.addEventListener('play', paint);
		audio.addEventListener('pause', paint);
		audio.addEventListener('ended', function () {
			audio.currentTime = 0;
			paint();
		});
		paint();
	});

	/* --- The sheet: a photograph or a recording, over the page ---
	 * The controls are the page's own. A <video controls> arrives as the
	 * browser's white strip — a light UI control with a system typeface,
	 * dropped into a dark card at its own scale — which is the "poor play
	 * button" this replaces. The frame, the play mark, the progress line and
	 * the clock are drawn here; the media element itself is only the file.
	 */
	var sheet = null;
	var build = function () {
		sheet = document.createElement('div');
		sheet.className = 'cl-shot-view';
		sheet.hidden = true;
		sheet.innerHTML = '<div class="cl-shot-view__win" role="dialog" aria-modal="true">'
			+ '<button type="button" class="cl-shot-view__x" aria-label="Close">✕</button>'
			+ '<div class="cl-shot-view__body"></div>'
			+ '<div class="cl-shot-view__ctl" hidden>'
			+ '<button type="button" class="cl-shot-view__play">'
			+ '<svg class="cl-ico-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 4.8v14.4a.8.8 0 0 0 1.23.67l11.2-7.2a.8.8 0 0 0 0-1.35L9.23 4.13A.8.8 0 0 0 8 4.8z"/></svg>'
			+ '<svg class="cl-ico-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>'
			+ '</button>'
			+ '<span class="cl-shot-view__bar"><span class="cl-shot-view__fill"></span></span>'
			+ '<span class="cl-shot-view__clock">0:00</span>'
			+ '</div>'
			+ '<div class="cl-shot-view__foot"><span class="cl-shot-view__tag"></span>'
			+ '<a class="cl-shot-view__dl" href="#" download>Download</a></div>'
			+ '</div>';
		document.body.appendChild(sheet);

		sheet.addEventListener('click', function (ev) {
			var t = ev.target;
			if (ev.target === sheet || (t.closest && t.closest('.cl-shot-view__x'))) {
				ev.preventDefault();
				close();
				return;
			}
			if (t.closest && t.closest('.cl-shot-view__play')) {
				ev.preventDefault();
				var v = sheet.querySelector('video');
				if (v) {
					if (v.paused) {
						var pr = v.play();
						if (pr && pr.catch) { pr.catch(function () {}); }
					} else {
						v.pause();
					}
				}
				return;
			}
			var bar = t.closest && t.closest('.cl-shot-view__bar');
			if (bar) {
				var vid = sheet.querySelector('video');
				if (!vid || !isFinite(vid.duration) || vid.duration <= 0) { return; }
				var r = bar.getBoundingClientRect();
				var pct = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
				vid.currentTime = pct * vid.duration;
			}
		});
	};

	var paintSheet = function () {
		var v = sheet && sheet.querySelector('video');
		if (!v) { return; }
		var ctl = sheet.querySelector('.cl-shot-view__ctl');
		var fill = sheet.querySelector('.cl-shot-view__fill');
		var clock = sheet.querySelector('.cl-shot-view__clock');
		ctl.hidden = false;
		ctl.classList.toggle('is-playing', !v.paused && !v.ended);
		if (fill) {
			fill.style.width = (isFinite(v.duration) && v.duration > 0 ? (v.currentTime / v.duration) * 100 : 0).toFixed(2) + '%';
		}
		if (clock) {
			clock.textContent = fmt(v.currentTime) + ' / ' + fmt(v.duration);
		}
	};

	var close = function () {
		if (!sheet) { return; }
		var v = sheet.querySelector('video');
		if (v) { v.pause(); }
		sheet.hidden = true;
		sheet.querySelector('.cl-shot-view__body').innerHTML = '';
	};

	var open = function (kind, src, dl) {
		if (!sheet) { build(); }
		var body = sheet.querySelector('.cl-shot-view__body');
		var ctl = sheet.querySelector('.cl-shot-view__ctl');
		body.innerHTML = '';
		if ('video' === kind) {
			var v = document.createElement('video');
			v.autoplay = true;
			v.playsinline = true;
			v.setAttribute('playsinline', '');
			v.src = src;
			v.addEventListener('timeupdate', paintSheet);
			v.addEventListener('loadedmetadata', paintSheet);
			v.addEventListener('play', paintSheet);
			v.addEventListener('pause', paintSheet);
			v.addEventListener('ended', paintSheet);
			body.appendChild(v);
			ctl.hidden = false;
		} else {
			var img = document.createElement('img');
			img.src = src;
			img.alt = '';
			body.appendChild(img);
			ctl.hidden = true;
		}
		sheet.querySelector('.cl-shot-view__tag').textContent = 'video' === kind ? 'Recording' : 'Photograph';
		var link = sheet.querySelector('.cl-shot-view__dl');
		link.href = dl || src;
		sheet.hidden = false;
		paintSheet();
	};

	document.addEventListener('click', function (ev) {
		var t = ev.target;
		if (!t || !t.closest) { return; }
		var play = t.closest('.cl-cap__tile--video');
		if (play) {
			ev.preventDefault();
			ev.stopPropagation();
			open('video', play.getAttribute('data-cl-play'), play.getAttribute('data-cl-dl'));
			return;
		}
		var shot = t.closest('.cl-cap__tile[data-cl-photo]');
		if (shot && !ev.metaKey && !ev.ctrlKey && !ev.shiftKey && ev.button === 0) {
			ev.preventDefault();
			ev.stopPropagation();
			open('photo', shot.getAttribute('data-cl-photo'), shot.getAttribute('data-cl-photo'));
		}
	});

	document.addEventListener('keydown', function (ev) {
		if ('Escape' === ev.key) { close(); }
	});
})();

/* ---- No browser control strips ----
 * A <video controls> or <audio controls> arrives as whatever the reader's
 * browser draws: in Chrome a white pill with a system typeface, a grey
 * progress line and a speaker icon, sitting inside a dark card at a scale
 * that has nothing to do with the page. It is the loudest thing on the
 * screen and it is not ours.
 *
 * So no media element keeps its native strip. Each one loses `controls` and
 * gets the page's own: one round play mark, a progress line and a clock, in
 * the card's own colours. The element keeps playing, seeking, buffering and
 * volume — everything except its own furniture.
 */
(function () {
	var fmt = function (s) {
		if (!isFinite(s) || s < 0) { return '0:00'; }
		var m = Math.floor(s / 60);
		var r = Math.floor(s % 60);
		return m + ':' + (r < 10 ? '0' : '') + r;
	};

	var dress = function (el) {
		if (!el || el.getAttribute('data-cl-dressed')) { return; }
		el.setAttribute('data-cl-dressed', '1');
		el.removeAttribute('controls');
		el.setAttribute('preload', 'metadata');

		var wrap = document.createElement('div');
		wrap.className = 'cl-player';
		el.parentNode.insertBefore(wrap, el);
		wrap.appendChild(el);

		var bar = document.createElement('button');
		bar.type = 'button';
		bar.className = 'cl-player__bar';
		bar.setAttribute('aria-label', 'Seek');
		bar.innerHTML = '<span class="cl-player__fill"></span>';

		var ctl = document.createElement('div');
		ctl.className = 'cl-player__ctl';
		ctl.innerHTML = '<button type="button" class="cl-player__play" aria-label="Play">'
			+ '<svg class="cl-ico-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 4.8v14.4a.8.8 0 0 0 1.23.67l11.2-7.2a.8.8 0 0 0 0-1.35L9.23 4.13A.8.8 0 0 0 8 4.8z"/></svg>'
			+ '<svg class="cl-ico-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>'
			+ '</button><span class="cl-player__clock">0:00</span>';

		wrap.appendChild(ctl);
		wrap.appendChild(bar);

		var fill = bar.querySelector('.cl-player__fill');
		var play = ctl.querySelector('.cl-player__play');
		var clock = ctl.querySelector('.cl-player__clock');

		var paint = function () {
			var d = el.duration;
			var pct = isFinite(d) && d > 0 ? (el.currentTime / d) * 100 : 0;
			fill.style.width = pct.toFixed(2) + '%';
			clock.textContent = isFinite(d) && d > 0
				? fmt(el.currentTime) + ' / ' + fmt(d)
				: fmt(el.currentTime) + ' / …';
			wrap.classList.toggle('is-playing', !el.paused && !el.ended);
		};

		play.addEventListener('click', function (ev) {
			ev.preventDefault();
			ev.stopPropagation();
			if (el.paused) {
				document.querySelectorAll('video, audio').forEach(function (other) {
					if (other !== el && !other.paused) { other.pause(); }
				});
				var p = el.play();
				if (p && p.catch) { p.catch(function () {}); }
			} else {
				el.pause();
			}
		});

		bar.addEventListener('click', function (ev) {
			ev.preventDefault();
			ev.stopPropagation();
			if (!isFinite(el.duration) || el.duration <= 0) { return; }
			var r = bar.getBoundingClientRect();
			el.currentTime = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)) * el.duration;
		});

		['timeupdate', 'loadedmetadata', 'play', 'pause', 'ended'].forEach(function (evt) {
			el.addEventListener(evt, paint);
		});
		el.addEventListener('loadedmetadata', function () {
			learnDuration(el, paint);
		});
		// A press on the frame itself is play/pause, which is what a reader
		// expects of a picture that is also a recording.
		if ('VIDEO' === el.tagName) {
			el.addEventListener('click', function (ev) {
				ev.preventDefault();
				play.click();
			});
		}
		paint();
	};

	document.querySelectorAll('video[controls], audio[controls]').forEach(dress);
	window.cloaklinkDressPlayers = function (root) {
		(root || document).querySelectorAll('video[controls], audio[controls]').forEach(dress);
	};
})();

/* ----------------------------------------------------------------------
   The delete question, asked by the page rather than by the browser.

   The desk's destructive forms — Remove on a ticket, Clear on a record,
   Delete on a selected set — carried `onsubmit="return confirm(…)"`. A
   browser that has been told to stop showing dialogs (the "prevent this
   page from creating additional dialogs" tick, or a locked-down profile)
   answers every later confirm() with false without drawing anything, so
   the form never submits and the button reads as dead. Nothing is logged
   and nothing explains itself: exactly "some options cannot be deleted".

   This dialog belongs to the page, so no browser setting can suppress it,
   and it can say what is about to go. It traps focus, closes on Escape or
   a press outside, and returns focus to the control that opened it.
   ---------------------------------------------------------------------- */
(function () {
	'use strict';

	var conf = {};
	try {
		var el = document.getElementById('cl-agent-config');
		conf = el ? JSON.parse(el.textContent || '{}') : {};
	} catch (e) {
		conf = {};
	}
	var words = conf.i18n || {};

	function ask(text, onYes) {
		var host = document.getElementById('cl-ask');
		if (!host) {
			host = document.createElement('div');
			host.id = 'cl-ask';
			host.className = 'cl-ask';
			host.hidden = true;
			host.innerHTML =
				'<div class="cl-ask__veil" data-cl-ask-no></div>' +
				'<div class="cl-ask__win" role="alertdialog" aria-modal="true" aria-labelledby="cl-ask-t">' +
				'<span class="cl-ask__ico" aria-hidden="true"></span>' +
				'<p class="cl-ask__t" id="cl-ask-t"></p>' +
				'<div class="cl-ask__acts">' +
				'<button type="button" class="cl-ask__b cl-ask__b--no" data-cl-ask-no></button>' +
				'<button type="button" class="cl-ask__b cl-ask__b--yes"></button>' +
				'</div></div>';
			document.body.appendChild(host);
		}

		var was = document.activeElement;
		var yes = host.querySelector('.cl-ask__b--yes');
		var no = host.querySelector('.cl-ask__b--no');

		host.querySelector('.cl-ask__t').textContent = text;
		yes.textContent = words.remove || 'Remove';
		no.textContent = words.cancel || 'Cancel';
		host.hidden = false;

		var shut = function () {
			host.hidden = true;
			document.removeEventListener('keydown', keys, true);
			host.removeEventListener('click', click);
			if (was && was.focus) {
				try { was.focus(); } catch (e) {}
			}
		};
		var keys = function (ev) {
			if (ev.key === 'Escape') {
				ev.preventDefault();
				shut();
			} else if (ev.key === 'Tab') {
				var next = ev.shiftKey ? no : yes;
				var other = ev.shiftKey ? yes : no;
				if (document.activeElement === other) {
					ev.preventDefault();
					next.focus();
				}
			}
		};
		var click = function (ev) {
			if (ev.target.closest('[data-cl-ask-no]')) {
				ev.preventDefault();
				shut();
				return;
			}
			if (ev.target === yes || yes.contains(ev.target)) {
				ev.preventDefault();
				shut();
				onYes();
			}
		};
		host.addEventListener('click', click);
		document.addEventListener('keydown', keys, true);
		window.setTimeout(function () { yes.focus(); }, 20);
	}

	document.addEventListener('submit', function (ev) {
		var form = ev.target;
		if (!form || form.nodeName !== 'FORM' || !form.hasAttribute('data-cl-confirm')) {
			return;
		}
		if (form.getAttribute('data-cl-confirmed') === '1') {
			return;
		}
		ev.preventDefault();
		ask(form.getAttribute('data-cl-confirm'), function () {
			form.setAttribute('data-cl-confirmed', '1');
			if (typeof form.requestSubmit === 'function') {
				form.requestSubmit();
			} else {
				form.submit();
			}
		});
	}, true);
})();
