/**
 * Picture cropper for the desk photo.
 *
 * A profile photo is square wherever it is shown: the radio card, the queue
 * row, the log. Handing a phone's 3:4 portrait straight to the server meant
 * every one of those places cropped it again, differently, and usually
 * through the middle of somebody's forehead — the face was wherever the CSS
 * happened to land. Choosing the square here, before it is sent, is the only
 * point at which the person can say which part of the picture is them.
 *
 * No dependency: a canvas, a pointer, and two numbers. The file is read
 * locally, drawn into a square frame the reader can drag and zoom, and the
 * export is the frame at whatever resolution the source can afford, so a
 * large photo leaves as a large square instead of a upscaled thumbnail.
 *
 * @package CloakLink
 */
(function () {
	'use strict';

	var DEFAULTS = {
		// The square the reader sees. The export is this shape at up to
		// MAX_OUT pixels a side, never upscaled past the source.
		size: 288,
		maxOut: 720,
		// How far the picture may be enlarged. 3x is enough to fill a face
		// from a group photograph without turning it into a smear.
		maxZoom: 3,
		quality: 0.9
	};

	function fit(state, view) {
		// Cover the frame: the smaller of the two scale factors that makes the
		// image at least as big as the square in both directions. Below this
		// the picture would not reach the corners.
		state.base = Math.max(view / state.w, view / state.h);
		state.min = state.base;
		state.max = state.base * DEFAULTS.maxZoom;
	}

	function clampPan(state, view) {
		var drawW = state.w * state.scale;
		var drawH = state.h * state.scale;
		// The picture is always at least as big as the frame, so the offset it
		// may take is the overhang on each side. Centred is offset zero.
		var maxX = Math.max(0, (drawW - view) / 2);
		var maxY = Math.max(0, (drawH - view) / 2);
		state.x = Math.min(maxX, Math.max(-maxX, state.x));
		state.y = Math.min(maxY, Math.max(-maxY, state.y));
	}

	function paint(state, ctx, view) {
		var drawW = state.w * state.scale;
		var drawH = state.h * state.scale;
		ctx.clearRect(0, 0, view, view);
		ctx.drawImage(
			state.img,
			(view - drawW) / 2 + state.x,
			(view - drawH) / 2 + state.y,
			drawW,
			drawH
		);
	}

	/**
	 * Open the cropper on a chosen file.
	 *
	 * @param {File}   file  The picture the reader picked.
	 * @param {Object} opts  Optional overrides for DEFAULTS.
	 * @return {Promise} Resolves with a Blob, or null if the file was not an image.
	 */
	function crop(file, opts) {
		var o = Object.assign({}, DEFAULTS, opts || {});
		var view = o.size;

		return new Promise(function (resolve) {
			if (!file || !/^image\//.test(file.type || '')) {
				resolve(null);
				return;
			}

			var url = URL.createObjectURL(file);
			var img = new Image();

			img.onload = function () {
				URL.revokeObjectURL(url);
				build(img);
			};
			img.onerror = function () {
				URL.revokeObjectURL(url);
				resolve(null);
			};
			img.src = url;

			function build(image) {
				var state = {
					img: image,
					w: image.naturalWidth,
					h: image.naturalHeight,
					x: 0,
					y: 0,
					scale: 0
				};
				fit(state, view);
				state.scale = state.base;
				clampPan(state, view);

				var host = document.createElement('div');
				host.className = 'cl-crop';
				host.innerHTML =
					'<div class="cl-crop__panel" role="dialog" aria-modal="true" aria-label="Crop your picture">' +
						'<header class="cl-crop__head">' +
							'<h3 class="cl-crop__title">Crop your picture</h3>' +
							'<button type="button" class="cl-crop__x" aria-label="Cancel">&times;</button>' +
						'</header>' +
						'<div class="cl-crop__stage">' +
							'<canvas class="cl-crop__canvas" width="' + view + '" height="' + view + '"></canvas>' +
							'<div class="cl-crop__frame" aria-hidden="true">' +
								'<span class="cl-crop__rule cl-crop__rule--v1"></span>' +
								'<span class="cl-crop__rule cl-crop__rule--v2"></span>' +
								'<span class="cl-crop__rule cl-crop__rule--h1"></span>' +
								'<span class="cl-crop__rule cl-crop__rule--h2"></span>' +
							'</div>' +
						'</div>' +
						'<div class="cl-crop__zoom">' +
							'<button type="button" class="cl-crop__z" data-step="-1" aria-label="Zoom out">&minus;</button>' +
							'<input type="range" class="cl-crop__range" min="0" max="1000" value="0" aria-label="Zoom">' +
							'<button type="button" class="cl-crop__z" data-step="1" aria-label="Zoom in">+</button>' +
						'</div>' +
						'<p class="cl-crop__hint">Drag to position. The square is what will be used everywhere.</p>' +
						'<footer class="cl-crop__foot">' +
							'<button type="button" class="cl-crop__btn cl-crop__btn--ghost" data-act="cancel">Cancel</button>' +
							'<button type="button" class="cl-crop__btn cl-crop__btn--go" data-act="use">Use this picture</button>' +
						'</footer>' +
					'</div>';

				var canvas = host.querySelector('.cl-crop__canvas');
				var ctx = canvas.getContext('2d');
				var range = host.querySelector('.cl-crop__range');

				function redraw() {
					paint(state, ctx, view);
					var span = state.max - state.min;
					range.value = span > 0 ? String(Math.round(((state.scale - state.min) / span) * 1000)) : '0';
				}

				function setScale(next) {
					state.scale = Math.min(state.max, Math.max(state.min, next));
					clampPan(state, view);
					redraw();
				}

				range.addEventListener('input', function () {
					var span = state.max - state.min;
					setScale(state.min + (Number(range.value) / 1000) * span);
				});

				host.querySelectorAll('.cl-crop__z').forEach(function (b) {
					b.addEventListener('click', function () {
						var step = Number(b.getAttribute('data-step')) || 1;
						// Steps in proportion to the current scale, so zooming
						// feels the same whether the picture is small or large.
						setScale(state.scale * (step > 0 ? 1.16 : 1 / 1.16));
					});
				});

				// Pointer drag. Set pointer capture so a drag that leaves the
				// canvas keeps steering instead of stopping at the edge.
				var drag = null;
				canvas.addEventListener('pointerdown', function (ev) {
					drag = { x: ev.clientX, y: ev.clientY, ox: state.x, oy: state.y };
					try { canvas.setPointerCapture(ev.pointerId); } catch (e) {}
				});
				canvas.addEventListener('pointermove', function (ev) {
					if (!drag) { return; }
					state.x = drag.ox + (ev.clientX - drag.x);
					state.y = drag.oy + (ev.clientY - drag.y);
					clampPan(state, view);
					redraw();
				});
				var endDrag = function () { drag = null; };
				canvas.addEventListener('pointerup', endDrag);
				canvas.addEventListener('pointercancel', endDrag);

				// Wheel zoom, so a mouse user does not have to reach for the
				// slider. Prevented so the page behind does not scroll away.
				canvas.addEventListener('wheel', function (ev) {
					ev.preventDefault();
					setScale(state.scale * (ev.deltaY < 0 ? 1.08 : 1 / 1.08));
				}, { passive: false });

				function close(result) {
					document.removeEventListener('keydown', onKey);
					if (host.parentNode) { host.parentNode.removeChild(host); }
					resolve(result);
				}

				function onKey(ev) {
					if ('Escape' === ev.key) { close(null); }
				}
				document.addEventListener('keydown', onKey);

				host.querySelector('.cl-crop__x').addEventListener('click', function () { close(null); });
				host.querySelector('[data-act="cancel"]').addEventListener('click', function () { close(null); });

				host.querySelector('[data-act="use"]').addEventListener('click', function () {
					exportSquare(state, view, o).then(close);
				});

				document.body.appendChild(host);
				redraw();
				host.querySelector('[data-act="use"]').focus();
			}
		});
	}

	/**
	 * Draw the chosen square at the best size the source allows.
	 *
	 * The visible frame is a fixed number of CSS pixels; the picture behind it
	 * may be far larger. Rendering at the source's own resolution keeps detail
	 * that the 288px preview threw away, and capping at maxOut stops a 40
	 * megapixel phone photo from being stored as a 40 megapixel avatar.
	 *
	 * @return {Promise} Resolves with a Blob.
	 */
	function exportSquare(state, view, o) {
		var out = Math.max(1, Math.min(o.maxOut, Math.round(Math.max(state.w, state.h) * state.scale)));

		var c = document.createElement('canvas');
		c.width = out;
		c.height = out;
		var cx = c.getContext('2d');
		// One scale factor for both axes: the frame is square and the source
		// is not, so the vertical stretch is whatever covers it.
		var k = out / view;
		var drawW = state.w * state.scale * k;
		var drawH = state.h * state.scale * k;

		cx.fillStyle = '#ffffff';
		cx.fillRect(0, 0, out, out);
		cx.drawImage(
			state.img,
			(out - drawW) / 2 + state.x * k,
			(out - drawH) / 2 + state.y * k,
			drawW,
			drawH
		);

		return new Promise(function (resolve) {
			if (c.toBlob) {
				c.toBlob(function (blob) { resolve(blob); }, 'image/jpeg', o.quality);
				return;
			}
			// Older engines without toBlob: the data URL is a working square
			// too, so the picture is not lost over a missing method.
			try {
				var data = c.toDataURL('image/jpeg', o.quality);
				var bin = atob(data.split(',')[1]);
				var bytes = new Uint8Array(bin.length);
				for (var i = 0; i < bin.length; i += 1) { bytes[i] = bin.charCodeAt(i); }
				resolve(new Blob([bytes], { type: 'image/jpeg' }));
			} catch (e) {
				resolve(null);
			}
		});
	}

	window.CloakCrop = { crop: crop };
})();

/**
 * Wire a file input to the cropper.
 *
 * The reader picks a picture, chooses their square, and the cropper's blob is
 * put back into the same input as a File — so the form, the server, and every
 * existing validation keep working exactly as they did, and no upload path
 * has to learn about this. The original name is kept so the stored image is
 * recognisable, with .jpg because that is what the crop exports.
 *
 * @param {HTMLInputElement} input File input.
 * @param {Object}           opts  Cropper options.
 */
window.CloakCrop.attach = function (input, opts) {
	if (!input || input.__clCrop) { return; }
	input.__clCrop = true;

	input.addEventListener('change', function () {
		var file = input.files && input.files[0];
		if (!file || !/^image\//.test(file.type || '')) { return; }

		// Hold the chosen file so cancelling can put it back. Without this a
		// reader who cancels the crop is left with the raw file still in the
		// input, which uploads uncropped — the opposite of what Cancel means.
		var previous = input.__clCropPrevious || null;
		input.__clCropPrevious = file;

		window.CloakCrop.crop(file, opts).then(function (blob) {
			if (!blob) {
				input.value = '';
				if (previous) {
					try {
						var dt = new DataTransfer();
						dt.items.add(previous);
						input.files = dt.files;
					} catch (e) {}
				}
				return;
			}
			var name = (file.name || 'photo').replace(/\.[^.]+$/, '') + '-square.jpg';
			try {
				var transfer = new DataTransfer();
				transfer.items.add(new File([blob], name, { type: 'image/jpeg' }));
				input.files = transfer.files;
			} catch (e) {
				/* A browser that will not let us replace the file list still
				   has the crop in hand; nothing to do but let the original go. */
			}
			input.dispatchEvent(new CustomEvent('cloaklink:cropped', { bubbles: true, detail: { name: name } }));
		});
	});
};
