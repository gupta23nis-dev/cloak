/**
 * Notices: the thing that tells you something happened.
 *
 * ---------------------------------------------------------------------
 * Why this exists
 * ---------------------------------------------------------------------
 *
 * Both consoles had a card, and both consoles had a sound engine, and the
 * two had never been introduced. The office drew a ticket card and played
 * the ticket figure; the desk drew an allowance card and played the
 * allowance figure; and then four things — an allowance reaching the office,
 * a sign-in and a sign-out — happened with no card at all, so a person
 * looking at the screen saw nothing change and concluded the desk was
 * broken. They were not broken. They were silent on purpose, because nobody
 * had ever decided what they should say.
 *
 * So: one layer, two kinds of notice, one vocabulary.
 *
 *   quiet   A small strip that names a thing and leaves. Sign-ins,
 *           sign-outs, an allowance going out, a refusal. These are
 *           facts about the shift, not work. They stack bottom-right,
 *           they do not steal focus, and they are gone in a few seconds
 *           unless they matter.
 *
 *   loud    A card that holds until it is read. A ticket waiting, a
 *           visitor who handed something over. These are work, and a
 *           card that vanished on a timer would be work lost.
 *
 * The rule for which is which is not "how important" — everything here is
 * important — but "does somebody have to do something". A ticket does. A
 * sign-in does not.
 *
 * ---------------------------------------------------------------------
 * What it deliberately does not do
 * ---------------------------------------------------------------------
 *
 * It does not queue. If six things arrive at once the six notices are shown
 * and the oldest quiet one goes, because a queue that plays out over ten
 * seconds means the last notice describes a moment that has passed.
 *
 * It does not use the browser's Notification API. That needs a permission
 * prompt, it looks like a different product, and on the panel's own
 * standalone address it is not allowed at all. Everything here is drawn in
 * the page, so it works everywhere the panel works.
 *
 * @package CloakLink
 */
( function () {
	'use strict';

	var HOST_ID = 'cl-notices';

	// Above this many quiet notices the oldest is retired. Loud cards are
	// never retired here — they are dismissed, or they would be work lost.
	var QUIET_MAX = 4;

	var host = null;
	var sound = null;

	function engine() {
		if ( ! sound ) {
			sound = window.CloakSound || null;
		}
		return sound;
	}

	function layer() {
		if ( host && host.parentNode ) {
			return host;
		}
		host = document.getElementById( HOST_ID );
		if ( ! host ) {
			host = document.createElement( 'div' );
			host.id = HOST_ID;
			host.className = 'cl-notices';
			host.setAttribute( 'role', 'log' );
			host.setAttribute( 'aria-live', 'polite' );
			host.setAttribute( 'aria-relevant', 'additions' );
			document.body.appendChild( host );
		}
		return host;
	}

	/**
	 * One strip.
	 *
	 * @param {Object} spec { tone, kicker, text, detail, icon, ttl, action }
	 * @return {Element}
	 */
	function build( spec ) {
		var el = document.createElement( 'div' );
		el.className = 'cl-note cl-note--' + ( spec.tone || 'info' );
		el.setAttribute( 'role', spec.loud ? 'alert' : 'status' );

		// The mark: a drawn glyph, not an emoji. Emoji render at a different
		// weight on every platform and the strip would look borrowed.
		var mark = document.createElement( 'span' );
		mark.className = 'cl-note__mark';
		mark.setAttribute( 'aria-hidden', 'true' );
		mark.innerHTML = spec.icon || glyph( spec.tone );
		el.appendChild( mark );

		var body = document.createElement( 'div' );
		body.className = 'cl-note__body';

		if ( spec.kicker ) {
			var kick = document.createElement( 'span' );
			kick.className = 'cl-note__kick';
			kick.textContent = spec.kicker;
			body.appendChild( kick );
		}

		var text = document.createElement( 'span' );
		text.className = 'cl-note__text';
		text.textContent = spec.text || '';
		body.appendChild( text );

		if ( spec.detail ) {
			var detail = document.createElement( 'span' );
			detail.className = 'cl-note__detail';
			detail.textContent = spec.detail;
			body.appendChild( detail );
		}

		el.appendChild( body );

		if ( spec.action && spec.action.href ) {
			var a = document.createElement( 'a' );
			a.className = 'cl-note__go';
			a.href = spec.action.href;
			a.textContent = spec.action.label || 'Open';
			el.appendChild( a );
		}

		var x = document.createElement( 'button' );
		x.type = 'button';
		x.className = 'cl-note__x';
		x.setAttribute( 'aria-label', 'Dismiss' );
		x.textContent = '×';
		x.addEventListener( 'click', function () { retire( el ); } );
		el.appendChild( x );

		return el;
	}

	var ICONS = {
		allow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5L20 6.5"/></svg>',
		deny: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
		login: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h4a2 2 0 012 2v12a2 2 0 01-2 2h-4"/><path d="M10 8l4 4-4 4"/><path d="M14 12H4"/></svg>',
		logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M10 4H6a2 2 0 00-2 2v12a2 2 0 002 2h4"/><path d="M14 8l-4 4 4 4"/><path d="M10 12h10"/></svg>',
		ticket: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8a2 2 0 012-2h12a2 2 0 012 2v2a2 2 0 000 4v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2a2 2 0 000-4z"/><path d="M12 6v12"/></svg>',
		capture: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M3 8.5A2.5 2.5 0 015.5 6h2L9 4h6l1.5 2h2A2.5 2.5 0 0121 8.5v8A2.5 2.5 0 0118.5 19h-13A2.5 2.5 0 013 16.5z"/></svg>',
		info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5"/><path d="M12 8h.01"/></svg>'
	};

	function glyph( tone ) {
		return ICONS[ tone ] || ICONS.info;
	}

	function retire( el ) {
		if ( ! el || el.__clgone ) {
			return;
		}
		el.__clgone = true;
		el.classList.add( 'is-out' );
		// Remove after the exit transition. A timer rather than
		// transitionend because a reduced-motion stylesheet removes the
		// transition and the event never fires — and a notice nobody can
		// dismiss is worse than one that leaves abruptly.
		setTimeout( function () {
			if ( el.parentNode ) {
				el.parentNode.removeChild( el );
			}
		}, 220 );
	}

	/**
	 * Show a notice.
	 *
	 * @param {Object} spec { tone, kicker, text, detail, ttl, loud, action, sound }
	 * @return {Element}
	 */
	function show( spec ) {
		spec = spec || {};
		var h = layer();
		if ( ! h ) {
			return null;
		}

		var el = build( spec );
		h.appendChild( el );

		// A quiet notice is capped; a loud one is not.
		if ( ! spec.loud ) {
			var quiet = h.querySelectorAll( '.cl-note:not(.cl-note--loud)' );
			for ( var i = 0; i < quiet.length - QUIET_MAX; i++ ) {
				retire( quiet[ i ] );
			}
		}

		// The figure. `sound` is an event name from sound.js, or false for a
		// notice that should be seen and not heard.
		if ( false !== spec.sound ) {
			var s = engine();
			if ( s ) {
				if ( spec.role ) {
					s.setRole( spec.role );
				}
				s.arm();
				s.play( spec.sound || spec.tone || 'info' );
			}
		}

		if ( spec.ttl ) {
			setTimeout( function () { retire( el ); }, spec.ttl );
		}

		return el;
	}

	/**
	 * A small strip that leaves on its own.
	 *
	 * @param {Object} spec
	 */
	function quiet( spec ) {
		spec = spec || {};
		spec.loud = false;
		if ( undefined === spec.ttl ) {
			spec.ttl = 5200;
		}
		return show( spec );
	}

	/**
	 * A card that waits to be read.
	 *
	 * @param {Object} spec
	 */
	function loud( spec ) {
		spec = spec || {};
		spec.loud = true;
		return show( spec );
	}

	window.CloakNotice = {
		show: show,
		quiet: quiet,
		loud: loud,
		glyph: glyph,
		/** Dismiss everything, for a console that is being torn down. */
		clear: function () {
			if ( host ) {
				while ( host.firstChild ) {
					host.removeChild( host.firstChild );
				}
			}
		}
	};
} )();
