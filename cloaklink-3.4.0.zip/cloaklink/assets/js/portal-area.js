/**
 * Practice-area sheets.
 *
 * The eight words in the header are the practice areas this desk works in.
 * Choosing one explains what it is and how it runs before the visitor has to
 * ask, and hands over to the desk with the subject already set.
 */
(function () {
	'use strict';

	var $ = function (id) {
		return document.getElementById(id);
	};

	var sheet = $('cc-area');
	if (!sheet || !window.clAreas) {
		return;
	}

	var data = window.clAreas;
	var els = {
		abbr: $('cc-area-abbr'),
		title: $('cc-area-title'),
		summary: $('cc-area-summary'),
		what: $('cc-area-what'),
		how: $('cc-area-how'),
		best: $('cc-area-best'),
		close: $('cc-area-close'),
		ask: $('cc-area-ask')
	};
	var current = '';
	var previousFocus = null;

	function close() {
		sheet.hidden = true;
		document.body.style.overflow = '';
		if (previousFocus && previousFocus.focus) {
			previousFocus.focus();
		}
	}

	function open(key) {
		var area = data[key];
		if (!area) {
			return;
		}
		current = key;
		// A badge, not a label: the short form where the area has one (ODR, ADR,
		// IMW), otherwise the first three letters of the name.
		var badge = { odr: 'ODR', adr: 'ADR', imw: 'IMW' };
		els.abbr.textContent = badge[key] || area.full.replace(/[^A-Za-z ]/g, '').slice(0, 3).toUpperCase();
		els.title.textContent = area.full;
		els.summary.textContent = area.summary;
		els.what.textContent = area.what;
		els.best.textContent = area.best;

		els.how.textContent = '';
		(area.how || []).forEach(function (step) {
			var li = document.createElement('li');
			li.textContent = step;
			els.how.appendChild(li);
		});

		previousFocus = document.activeElement;
		sheet.hidden = false;
		document.body.style.overflow = 'hidden';
		sheet.querySelector('.cc-dialog').focus();
	}

	document.querySelectorAll('[data-desk-area]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			open(btn.getAttribute('data-desk-area'));
		});
	});

	if (els.close) {
		els.close.addEventListener('click', close);
	}

	sheet.addEventListener('click', function (e) {
		if (e.target === sheet) {
			close();
		}
	});

	document.addEventListener('keydown', function (e) {
		if ('Escape' === e.key && !sheet.hidden) {
			close();
		}
	});

	// Asking about what was just read: the desk opens with that subject set.
	if (els.ask) {
		els.ask.addEventListener('click', function () {
			var topic = document.getElementById('cc-desk-topic');
			if (topic && current) {
				topic.value = current;
			}
			close();
			var opener = document.getElementById('cc-desk-open');
			if (opener) {
				opener.click();
			}
		});
	}
})();
