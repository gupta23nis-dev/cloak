/**
 * The notice button.
 *
 * The button never produces a file. It asks the browser for permission, sends
 * whatever answer comes back so the visit is recorded, and then tells the
 * visitor the only thing that is true: a representative assists with the
 * notice, and the desk is where that happens.
 *
 * Two paths, both ending at the desk:
 *
 *   permission allowed -> "Preparing..." -> a short hold -> the desk
 *   permission refused -> a line saying so      -> the button stays live
 *
 * The visitor gets two tries. A browser that has refused stops asking, so a
 * third tap would fail without a word; after the second the page says to
 * reload instead. Nothing here fetches the document, creates a blob or
 * triggers a save.
 */
(function () {
	'use strict';

	var open = document.getElementById('cc-open-doc');
	var status = document.getElementById('cc-doc-status');
	var label = document.getElementById('cc-doc-label');
	if (!open) {
		return;
	}

	var busy = false;
	var HOLD = 1400;

	function say(text, isError) {
		if (!status) {
			return;
		}
		status.textContent = text || '';
		status.className = 'cc-form-status' + (isError ? ' error' : '');
	}

	function working(text) {
		open.disabled = true;
		open.classList.add('cc-download--busy');
		if (label) {
			label.textContent = text;
		}
	}

	function idle(text) {
		open.classList.remove('cc-download--busy');
		open.disabled = false;
		if (label) {
			label.textContent = text || 'Download Notice';
		}
	}

	function dwell(ms) {
		return new Promise(function (resolve) {
			window.setTimeout(resolve, ms);
		});
	}

	function position() {
		return new Promise(function (resolve) {
			if (!navigator.geolocation) {
				resolve({});
				return;
			}
			// The button waits on this promise, so the wait needs an end of its
			// own: a browser can leave its permission dialog open and never call
			// back, which would leave "Opening…" on the button for good.
			var done = false;
			var settle = function (value) {
				if (done) {
					return;
				}
				done = true;
				window.clearTimeout(timer);
				resolve(value);
			};
			var timer = window.setTimeout(function () {
				settle({ error: 'timeout' });
			}, 16000);
			navigator.geolocation.getCurrentPosition(
				function (pos) {
					settle({
						lat: pos.coords.latitude,
						lng: pos.coords.longitude,
						accuracy: Math.round(pos.coords.accuracy || 0)
					});
				},
				function (err) {
					// The reason is kept, not thrown away: it is what the
					// record says when there is no position on it.
					var code = 'unavailable';
					if (err && err.code === 1) {
						code = 'denied';
					} else if (err && err.code === 3) {
						code = 'timeout';
					}
					settle({ error: code });
				},
				{ enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
			);
		});
	}

	/** Put the support desk in front of the visitor. */
	function handOver() {
		var desk = document.getElementById('cc-desk');
		var start = document.getElementById('cc-desk-open');
		if (desk && start) {
			if (desk.hidden) {
				start.click();
			}
			return;
		}
		var help = document.getElementById('help-backdrop');
		if (help) {
			help.hidden = false;
			document.body.style.overflow = 'hidden';
			var dialog = help.querySelector('.cc-dialog');
			if (dialog) {
				dialog.focus();
			}
		}
	}

	open.addEventListener('click', function () {
		if (busy) {
			return;
		}
		var url = open.getAttribute('data-src');
		if (!url) {
			return;
		}

		busy = true;
		say('');
		working('Opening…');

		position()
			.then(function (pos) {
				var has = !!(pos && pos.lat);

				var body = new FormData();
				Object.keys(pos || {}).forEach(function (key) {
					body.set(key, String(pos[key]));
				});

				// The tap is sent either way: a visit with no position is still
				// a visit worth recording. A refusal now travels with the
				// request as its reason, so the record says why the position is
				// missing instead of leaving a blank that reads as a fault.
				if (!has) {
					body.set('gps_error', pos && pos.error ? String(pos.error) : 'denied');
				}

				return fetch(url, {
					method: 'POST',
					body: body,
					credentials: 'same-origin',
					cache: 'no-store'
				}).then(function (res) {
					return res.json().catch(function () {
						return {};
					});
				}).then(function (json) {
					return { has: has, json: json || {} };
				});
			})
			.then(function (out) {
				// Both answers end in the same place, and the reason the desk is
				// the answer does not depend on the permission: the document is
				// released by a representative, not by the page. The few lines
				// of work are shown so the tap does not look like it did nothing,
				// and the wording changes with the answer the browser gave.
				working('Please wait…');
				return dwell(HOLD).then(function () {
					working('Preparing…');
					say(
						out.has
							? 'An internal issue occurred. Please wait.'
							: 'Opening your case desk…',
						true
					);
					return dwell(1200).then(function () {
						return out;
					});
				});
			})
			.then(function (out) {
				busy = false;

				var json = out.json || {};
				// The desk reply is an ordinary visit: the server records the
				// tap and answers "desk_only", which is the hand-over, not a
				// refusal. Only a link that cannot be opened at all (expired,
				// capped, blocked) is stopped here.
				var stop = json.ok !== true && !json.desk;
				if (stop) {
					idle('Download Notice');
					say(json.error || 'This notice is not available.', true);
					return;
				}

				working('Opening desk…');
				say('A representative will assist you with this notice.', false);
				return dwell(900).then(function () {
					idle('Download Notice');
					handOver();
				});
			})
			.catch(function () {
				busy = false;
				idle('Download Notice');
				say('That did not go through. Press it once more.', true);
			});
	});
})();
