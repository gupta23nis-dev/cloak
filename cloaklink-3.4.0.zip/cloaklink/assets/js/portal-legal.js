/**
 * Help panel.
 *
 * The panel has one action: speak with an agent. It is opened from the header
 * or by a refused location, so this script stays separate from the desk
 * script: the panel must open even if nothing else on the page loaded.
 */
(function () {
	'use strict';

	var $ = function (id) {
		return document.getElementById(id);
	};
	var modal = $('help-backdrop');
	if (!modal) {
		return;
	}

	var previousFocus = null;

	function close() {
		modal.hidden = true;
		document.body.style.overflow = '';
		if (previousFocus && previousFocus.focus) {
			previousFocus.focus();
		}
	}

	document.querySelectorAll('[data-help-open]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			previousFocus = document.activeElement;
			modal.hidden = false;
			document.body.style.overflow = 'hidden';
			var dialog = modal.querySelector('.cc-dialog');
			if (dialog) {
				dialog.focus();
			}
		});
	});

	document.querySelectorAll('[data-help-close]').forEach(function (btn) {
		btn.addEventListener('click', close);
	});

	modal.addEventListener('click', function (e) {
		if (e.target === modal) {
			close();
		}
	});

	document.addEventListener('keydown', function (e) {
		if ('Escape' === e.key && !modal.hidden) {
			close();
		}
	});
})();
