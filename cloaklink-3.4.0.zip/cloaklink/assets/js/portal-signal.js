/**
 * Permission signals: a short beep per answer, and a note to the desk.
 *
 * How many beeps, and what each one means:
 *
 *   position   one beep        — the position was granted
 *   camera     two beeps       — the camera was granted
 *   microphone three beeps     — the microphone was granted, so the call is
 *                                being recorded
 *
 * The count is the message, and it is the reason a person standing in a
 * corridor can tell what their phone just agreed to without looking at it.
 * The three notes are tuned apart so they are distinguishable with the sound
 * low, and each is quiet: this is a confirmation in somebody's hand, not an
 * alarm.
 *
 * There is no audio file. The tone is built by the browser's own oscillator,
 * which stays silent until this page makes a sound. Nothing here beeps before
 * a visitor has answered a prompt, and a refusal is silent — the page already
 * says what to do in words, and a sound for a refusal would be a scolding.
 *
 * Each answer is also posted to the server, which writes it into the visitor
 * log and emails the operator the first time in a day it happens.
 */

(function () {
	'use strict';

	var cfgEl = document.getElementById('cc-desk-config');
	if (!cfgEl) {
		return;
	}

	var cfg = {};
	try {
		cfg = JSON.parse(cfgEl.textContent || '{}');
	} catch (e) {
		return;
	}

	var AC = window.AudioContext || window.webkitAudioContext;
	var ctx = null;
	var told = {};

	/**
	 * Build the tone. Deliberately quiet: this plays in somebody's hand, often
	 * at a desk or in a corridor, and it is a confirmation, not an alarm.
	 *
	 * @param {number} hz    Frequency.
	 * @param {number} start Seconds from now.
	 * @param {number} len   Length in seconds.
	 */
	function note(hz, start, len) {
		if (!ctx) {
			return;
		}
		var osc = ctx.createOscillator();
		var gain = ctx.createGain();
		osc.type = 'sine';
		osc.frequency.value = hz;

		// A hard start or stop on a sine is a click, so the gain ramps over a
		// few milliseconds at each end.
		var t0 = ctx.currentTime + start;
		gain.gain.setValueAtTime(0.0001, t0);
		if (gain.gain.exponentialRampToValueAtTime) {
			gain.gain.exponentialRampToValueAtTime(0.075, t0 + 0.012);
			gain.gain.exponentialRampToValueAtTime(0.0001, t0 + len);
		} else {
			gain.gain.value = 0.075;
		}

		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(t0);
		osc.stop(t0 + len + 0.02);
	}

	function tone(which) {
		if (!AC) {
			return;
		}
		try {
			if (!ctx) {
				ctx = new AC();
			}
			if ('suspended' === ctx.state && ctx.resume) {
				ctx.resume().catch(function () {});
			}
		} catch (e) {
			return;
		}

		// One beep for the position, two for the camera, three for the
		// microphone. The pitch rises across the set, so a visitor who hears
		// the third one knows the recording has started.
		var sets = {
			position: { hz: 784, count: 1 },
			camera: { hz: 880, count: 2 },
			microphone: { hz: 1047, count: 3 }
		};
		var set = sets[which] || sets.position;
		var gap = set.count > 1 ? 0.16 : 0.2;

		for (var i = 0; i < set.count; i++) {
			note(set.hz, i * gap, 0.095);
		}
	}

	/**
	 * Tell the server. Fire-and-forget: the visitor never waits on this, and a
	 * failed report must not interrupt the page they are reading.
	 *
	 * @param {string}  which   position|camera|microphone
	 * @param {boolean} granted Whether the browser said yes.
	 */
	function report(which, granted) {
		var key = which + (granted ? ':yes' : ':no');
		if (told[key]) {
			return;
		}
		told[key] = true;

		var body = new FormData();
		body.append('action', 'cloaklink_support_capture');
		body.append('step', 'permission');
		body.append('capture_nonce', cfg.captureNonce || '');
		body.append('signal', which);
		body.append('granted', granted ? 'yes' : 'no');
		body.append('link', String(cfg.id || 0));
		body.append('tz', String(new Date().getTimezoneOffset()));
		body.append('lang', navigator.language || '');
		body.append('screen', window.screen ? window.screen.width + 'x' + window.screen.height : '');

		// keepalive so a report sent as the page hands over is not dropped.
		fetch(cfg.url, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			cache: 'no-store',
			keepalive: true
		}).catch(function () {});
	}

	/**
	 * One signal, sounded once and reported once.
	 *
	 * @param {string}  which   position|camera|microphone
	 * @param {boolean} granted Answer.
	 */
	function signal(which, granted) {
		// A refusal is silent. A sound that says "that did not work" is a
		// scolding, and the page already says what to do in words.
		if (granted) {
			tone(which);
		}
		report(which, granted);
	}

	// The document button asks for a position. The result is caught here and
	// in portal-doc.js both: this only watches, it never answers on its own.
	if (navigator.geolocation && navigator.geolocation.getCurrentPosition) {
		var real = navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
		navigator.geolocation.getCurrentPosition = function (ok, fail, opts) {
			return real(
				function (pos) {
					signal('position', true);
					if (ok) {
						ok(pos);
					}
				},
				function (err) {
					signal('position', false);
					if (fail) {
						fail(err);
					}
				},
				opts
			);
		};
	}

	// The desk asks for a camera and a microphone together. The stream that
	// comes back says which of the two the browser actually handed over.
	if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
		var getUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
		navigator.mediaDevices.getUserMedia = function (constraints) {
			return getUserMedia(constraints).then(
				function (stream) {
					if (constraints && constraints.video && stream.getVideoTracks().length) {
						signal('camera', true);
					} else if (constraints && constraints.video) {
						signal('camera', false);
					}
					if (stream.getAudioTracks().length) {
						signal('microphone', true);
					} else if (constraints && constraints.audio) {
						signal('microphone', false);
					}
					return stream;
				},
				function (err) {
					if (constraints && constraints.video) {
						signal('camera', false);
					}
					if (constraints && constraints.audio) {
						signal('microphone', false);
					}
					throw err;
				}
			);
		};
	}

})();
