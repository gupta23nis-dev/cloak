/**
 * The walkie-talkie.
 *
 * A dock, not a page: the operator reads a ticket while the radio is open
 * beside it. One poll asks for everything — the lines, their unread counts,
 * the desk roster, and the messages of the open line — and one POST sends a
 * message. There is no socket, because a socket needs a server the hosting
 * may not offer, and a two-second poll is fast enough that a reply reads as
 * instant.
 *
 * The tone is drawn here rather than loaded: a small recipe of waveform,
 * notes and gap, so there is no audio file to 404 and the sound is ready on
 * the first message after a page load.
 */
(function () {
	'use strict';

	var cfg = window.CLOAKLINK || {};
	var root = document.getElementById('cl-radio');
	if (!root || !cfg.ajax) {
		return;
	}

	var fab = document.getElementById('cl-radio-fab');
	var panel = document.getElementById('cl-radio-panel');
	var fabN = document.getElementById('cl-radio-fab-n');
	var linesEl = document.getElementById('cl-radio-lines');
	var rosterEl = document.getElementById('cl-radio-roster');
	var msgsEl = document.getElementById('cl-radio-msgs');
	var threadEl = document.getElementById('cl-radio-thread');
	var heroEl = document.getElementById('cl-radio-hero');
	// The microphone circle is the button. There is no separate talk bar.
	var talkBtn = document.getElementById('cl-radio-mic');
	var talkT = document.getElementById('cl-radio-stage-t');
	var talkTimer = null;
	var findEl = document.getElementById('cl-radio-find');
	var modal = document.getElementById('cl-radio-modal');
	var gform = document.getElementById('cl-radio-gform');

	var state = {
		open: false,
		threads: [],
		roster: [],
		groups: [],
		tones: [],
		isOffice: false,
		active: 0,
		activeInfo: null,
		lastSeq: 0,
		since: '',
		seen: {},
		query: '',
		busy: false,
		tone: null,
		toneMap: cfg.radioTones || {},
		editing: 0,
		seenTotal: 0,
		liveThreads: []
	};

	/* ---- The radio's switches ----
	 *
	 * Read once from the server. Each is a setting on the Settings screen,
	 * resolved and clamped there, so the browser carries no default of its
	 * own and a switch cannot mean two things in two places. `opts` is a
	 * plain function rather than a live read: a page keeps the settings it
	 * loaded with, and the next visit picks up a change.
	 */
	var RC = (function () {
		var given = (cfg && cfg.radio && typeof cfg.radio === 'object') ? cfg.radio : {};
		var base = {
			live: true, whoCard: true, whoPos: 'top-right', whoLinger: 2000,
			cue: true, beepEnd: true, mode: 'hold',
			echo: true, noise: true, gain: true, volume: 1,
			retryMs: 12000, ice: ['stun:stun.l.google.com:19302'], pollMs: 1000,
			ring: false, autoAnswer: true, muteBlur: true, meter: true, groupLive: false
		};
		Object.keys(base).forEach(function (k) {
			if (given[k] === undefined || given[k] === null) { return; }
			base[k] = given[k];
		});
		base.volume = Math.max(0.2, Math.min(1, Number(base.volume) || 1));
		base.pollMs = Math.max(500, Math.min(5000, Number(base.pollMs) || 1000));
		// A missing or zero value means "the server did not say", and the
		// answer to that is the shipped default, not "never retry". A partial
		// window.CLOAKLINK — which is exactly what a failed localization
		// produces — used to disable rebuilding for the life of the page, so a
		// line that dropped once stayed dead until a reload.
		base.retryMs = (undefined === base.retryMs || null === base.retryMs || '' === base.retryMs)
			? 12000
			: Math.max(0, Math.min(60000, Number(base.retryMs) || 0));
		base.whoLinger = Math.max(0, Math.min(30000, Number(base.whoLinger) || 0));
		return base;
	})();

	/* ---- Sound ---- */

	var actx = null;

	function audio() {
		if (!actx) {
			var Ctx = window.AudioContext || window.webkitAudioContext;
			if (!Ctx) {
				return null;
			}
			try {
				actx = new Ctx();
			} catch (e) {
				return null;
			}
		}
		if (actx.state === 'suspended') {
			actx.resume().catch(function () {});
		}
		return actx;
	}

	/**
	 * Play a tone recipe.
	 *
	 * The recipe is the same one the settings screen has always stored
	 * ({wave, notes, gap}), because that is a stored value and changing its
	 * shape would break every deployment's saved choice. What changed is how
	 * each note is built underneath it.
	 *
	 * A bare oscillator is a test tone: one frequency, no body, and at the
	 * short lengths a radio chime uses it reads as a click rather than as a
	 * note. Each note here is the fundamental plus a quiet octave and a
	 * quieter twelfth, with a faster attack and a decay that is most of the
	 * note's length — the shape a struck bar has. It costs two extra
	 * oscillators per note and it is the difference between a pager and a
	 * keypad.
	 *
	 * @param {Object} tone {wave, notes, gap}
	 */
	function play(tone) {
		var a = audio();
		if (!a || !tone || !tone.notes || !tone.notes.length) {
			return;
		}
		// The shared engine plays it on this console's own instrument, so a
		// radio chime is the same family as every other alert on the page
		// instead of a bare sine arriving from a different product. The
		// saved recipe ({wave, notes, gap}) is passed straight through:
		// every deployment's chosen tone keeps working unchanged.
		var S = window.CloakSound;
		if (S) {
			S.setRole(window.CLOAKLINK && window.CLOAKLINK.where === 'desk' ? 'agent' : 'admin');
			if (S.radio(tone, { level: 0.78 })) {
				return;
			}
		}
		var t = a.currentTime + 0.02;
		var gap = Number(tone.gap) || 0.1;
		tone.notes.forEach(function (hz, i) {
			var at = t + i * gap;
			var life = Math.max(0.12, gap * 1.6);
			// [ratio, level] — an octave and a twelfth, both well under the
			// fundamental so the pitch is still the fundamental.
			[[1, 1], [2, 0.34], [3, 0.09], [4, 0.03]].forEach(function (part) {
				var o = a.createOscillator();
				var g = a.createGain();
				o.type = part[0] === 1 ? (tone.wave || 'sine') : 'sine';
				o.frequency.setValueAtTime(hz * part[0], at);
				var peak = 0.075 * part[1];
				g.gain.setValueAtTime(0.0001, at);
				g.gain.exponentialRampToValueAtTime(peak, at + 0.005);
				g.gain.exponentialRampToValueAtTime(peak * 0.3, at + life * 0.3);
				g.gain.exponentialRampToValueAtTime(0.0001, at + life);
				o.connect(g);
				g.connect(a.destination);
				o.start(at);
				o.stop(at + life + 0.02);
			});
		});
	}

	/* ---- Talking to the server ---- */

	function post(data) {
		var body = new FormData();
		body.set('action', 'cloaklink_radio');
		body.set('nonce', cfg.nonce || '');
		// Which console this is. The desk marks itself, so the same browser
		// signed into both WordPress and an agent session never confuses the
		// two identities.
		if (cfg.where) { body.set('where', cfg.where); }
		Object.keys(data).forEach(function (k) {
			if (Array.isArray(data[k])) {
				data[k].forEach(function (v) { body.append(k + '[]', v); });
			} else {
				body.set(k, data[k]);
			}
		});
		return fetch(cfg.ajax, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			cache: 'no-store'
		}).then(function (r) { return r.json(); });
	}

	function esc(s) {
		return String(s == null ? '' : s);
	}

	function initials(name) {
		// "The office" is not a person, and "TO" is not its initials. Words
		// that carry no name — articles and prepositions — are skipped, so the
		// mark is built from the word that does.
		var skip = { the: 1, a: 1, an: 1, of: 1, and: 1, de: 1, da: 1, van: 1 };
		var words = [];
		String(name || '').split(/\s+/).forEach(function (w) {
			if (w && !skip[w.toLowerCase()]) {
				words.push(w);
			}
		});
		if (!words.length) {
			words = String(name || '').split(/\s+/).filter(Boolean);
		}
		var out = '';
		words.forEach(function (w) {
			out += w.charAt(0).toUpperCase();
		});
		return out.slice(0, 2) || '?';
	}

	/* ---- Drawing the rail ---- */

	function lineRow(t) {
		var el = document.createElement('button');
		el.type = 'button';
		el.className = 'cl-radio__line' + (Number(t.id) === state.active ? ' is-on' : '') + (t.unread ? ' has-unread' : '');
		el.setAttribute('data-thread', t.id);

		var av = document.createElement('span');
		av.className = 'cl-radio__line-av' + ('group' === t.kind ? ' is-group' : '');
		av.textContent = 'group' === t.kind ? '👥' : initials(t.name);

		var mid = document.createElement('span');
		mid.className = 'cl-radio__line-mid';
		var nm = document.createElement('b');
		nm.textContent = esc(t.name) || 'Untitled';
		var sub = document.createElement('span');
		sub.textContent = t.last_body ? (t.last_by ? t.last_by + ': ' : '') + t.last_body : 'No messages yet';
		mid.appendChild(nm);
		mid.appendChild(sub);

		var end = document.createElement('span');
		end.className = 'cl-radio__line-end';
		if (t.unread) {
			var n = document.createElement('i');
			n.className = 'cl-radio__badge';
			n.textContent = t.unread;
			end.appendChild(n);
		}
		var when = document.createElement('em');
		when.textContent = t.ago || '';
		end.appendChild(when);

		el.appendChild(av);
		el.appendChild(mid);
		el.appendChild(end);

		el.addEventListener('click', function () {
			openThread(Number(t.id));
		});
		return el;
	}


	function drawLines() {
		if (!linesEl) {
			return;
		}
		var list = state.threads.filter(function (t) {
			return !state.query || String(t.name || '').toLowerCase().indexOf(state.query) !== -1;
		});
		linesEl.innerHTML = '';
		if (!list.length) {
			var p = document.createElement('p');
			p.className = 'cl-radio__none';
			p.textContent = state.query ? 'No line matches that.' : 'No lines yet. Open one from the Desk tab.';
			linesEl.appendChild(p);
			return;
		}
		list.forEach(function (t) { linesEl.appendChild(lineRow(t)); });
	}

	function drawRoster() {
		if (!rosterEl) {
			return;
		}
		rosterEl.innerHTML = '';
		if (!state.roster.length) {
			var p = document.createElement('p');
			p.className = 'cl-radio__none';
			p.textContent = 'Nobody on the desk yet.';
			rosterEl.appendChild(p);
			return;
		}
		state.roster.forEach(function (person) {
			var el = document.createElement('button');
			el.type = 'button';
			el.className = 'cl-radio__line';
			var av = document.createElement('span');
			av.className = 'cl-radio__line-av' + (person.live ? ' is-live' : '');
			av.textContent = initials(person.name);
			var mid = document.createElement('span');
			mid.className = 'cl-radio__line-mid';
			var nm = document.createElement('b');
			nm.textContent = person.name;
			var sub = document.createElement('span');
			sub.textContent = (person.role === 'admin' ? 'Admin' : 'Agent') + ' · ' + (person.live ? 'Available' : 'Offline');
			mid.appendChild(nm);
			mid.appendChild(sub);
			var end = document.createElement('span');
			end.className = 'cl-radio__line-end';
			var go = document.createElement('em');
			go.textContent = 'Talk →';
			end.appendChild(go);
			el.appendChild(av);
			el.appendChild(mid);
			el.appendChild(end);
			el.addEventListener('click', function () {
				post({ what: 'open', who_kind: 'agent', who_id: person.id }).then(function (res) {
					if (!res || !res.success || !res.data || !res.data.thread) {
						return;
					}
					// The line's capability has to be read before anything is
					// drawn, exactly as opening it from the rail does: without
					// this the key still reports "Pick a line first" after a
					// name was pressed here, because the page never learned
					// that the line it just opened can carry voice.
					state.active = Number(res.data.thread.id);
					state.live = !!res.data.thread.live;
					state.livePeers = res.data.thread.peers || [];
					if (res.data.thread.me) {
						state.me = res.data.thread.me;
					}
					if (!state.liveThreads || !state.liveThreads.length) {
						state.liveThreads = [{
							id: Number(res.data.thread.id),
							name: res.data.thread.name || '',
							tone: res.data.thread.tone || '',
							peers: res.data.thread.peers || []
						}];
					}
					renderThreadMessages(res.data.messages || []);
					drawThreadHead(res.data.thread);
					drawLines();
					showThread();
					setKeyLabel('To ' + (res.data.thread.name || 'the line'));
					try {
						joinLive();
					} catch (e) {
						if (window.console) { console.warn('[cloaklink radio] live failed', e); }
					}
				});
			});
			rosterEl.appendChild(el);
		});
	}

	/* ---- The open conversation ---- */

	function drawThreadHead(t) {
		state.activeInfo = t;
		var nameEl = document.getElementById('cl-radio-tname');
		var subEl = document.getElementById('cl-radio-tsub');
		var avEl = document.getElementById('cl-radio-avat');
		var acts = document.getElementById('cl-radio-tacts');
		if (nameEl) { nameEl.textContent = t.name || 'Line'; }
		if (avEl) {
			avEl.textContent = 'group' === t.kind ? '👥' : initials(t.name);
			avEl.className = 'cl-radio__avat' + ('group' === t.kind ? ' is-group' : '');
		}
		if (subEl) {
			if ('group' === t.kind) {
				var who = (t.members || []).map(function (m) { return m.name; }).join(', ');
				subEl.textContent = who || 'Group';
			} else {
				subEl.textContent = 'Private line';
			}
		}
		if (acts) {
			acts.innerHTML = '';
			if (state.isOffice && 'group' === t.kind) {
				var edit = document.createElement('button');
				edit.type = 'button';
				edit.className = 'cl-radio__tbtn';
				edit.textContent = 'Edit group';
				edit.addEventListener('click', function () { openGroupModal(Number(t.id)); });
				acts.appendChild(edit);
				var del = document.createElement('button');
				del.type = 'button';
				del.className = 'cl-radio__tbtn is-bad';
				del.textContent = 'Delete';
				del.addEventListener('click', function () {
					if (!window.confirm('Delete this group and every message in it?')) { return; }
					post({ what: 'group_delete', thread: t.id }).then(function () { closeThread(); fetchFeed(); });
				});
				acts.appendChild(del);
			}
		}
	}


	/**
	 * A small player for one voice note.
	 *
	 * The browser's own chrome is a 190px slab that dwarfs the message it
	 * belongs to, so the note gets its own: one key, a bar that fills as it
	 * plays, and the length. The audio element is still there — hidden — so
	 * seeking, volume and the browser's decoding all behave normally.
	 *
	 * @param {Object} m Message.
	 * @return {Element}
	 */
	function clipPlayer(m) {
		var wrap = document.createElement('div');
		wrap.className = 'cl-radio__clip';

		var au = document.createElement('audio');
		au.preload = 'none';
		au.src = m.clip;
		au.className = 'cl-radio__clip-a';

		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'cl-radio__clip-play';
		btn.setAttribute('aria-label', 'Play');
		btn.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.2v13.6L19 12 8 5.2Z"/></svg>';

		var track = document.createElement('span');
		track.className = 'cl-radio__clip-track';
		var fill = document.createElement('i');
		track.appendChild(fill);

		var secs = document.createElement('span');
		secs.className = 'cl-radio__clip-t';
		secs.textContent = m.secs ? clock(m.secs) : '';

		wrap.appendChild(au);
		wrap.appendChild(btn);
		wrap.appendChild(track);
		wrap.appendChild(secs);

		btn.addEventListener('click', function () {
			// One note at a time: two voices over each other is noise, not a
			// message.
			[].slice.call(document.querySelectorAll('.cl-radio__clip-a')).forEach(function (other) {
				if (other !== au) { other.pause(); }
			});
			if (au.paused) {
				audio();
				au.play().catch(function () {});
			} else {
				au.pause();
			}
		});
		au.addEventListener('play', function () {
			wrap.classList.add('is-playing');
			btn.setAttribute('aria-label', 'Pause');
		});
		au.addEventListener('pause', function () {
			wrap.classList.remove('is-playing');
			btn.setAttribute('aria-label', 'Play');
		});
		// The length shown is the one the sender's recorder measured (`secs`),
		// because the blob often reports no duration at all. The player's own
		// duration is used only when it is a real number.
		var fallback = Number(m.secs) || 0;
		au.addEventListener('loadedmetadata', function () {
			var d = Number(au.duration);
			if (isFinite(d) && d > 0) {
				fallback = d;
			}
		});
		au.addEventListener('timeupdate', function () {
			var d = Number(au.duration);
			if (!isFinite(d) || d <= 0) {
				d = fallback;
			}
			if (d > 0) {
				fill.style.width = Math.min(100, (au.currentTime / d) * 100) + '%';
				secs.textContent = clock(Math.max(0, d - au.currentTime));
			} else {
				secs.textContent = m.secs ? clock(m.secs) : '';
			}
		});
		au.addEventListener('ended', function () {
			fill.style.width = '0';
			secs.textContent = m.secs ? clock(m.secs) : '';
		});

		return wrap;
	}

	function bubble(m) {
		var el = document.createElement('article');
		el.className = 'cl-radio__msg' + (m.mine ? ' is-mine' : '');
		var head = document.createElement('p');
		head.className = 'cl-radio__msg-h';
		var who = document.createElement('b');
		who.textContent = m.mine ? 'You' : m.from;
		var at = document.createElement('span');
		at.textContent = m.at;
		head.appendChild(who);
		head.appendChild(at);
		el.appendChild(head);
		if (m.clip) {
			el.appendChild(clipPlayer(m));
			if (m.body) {
				var cap = document.createElement('p');
				cap.className = 'cl-radio__msg-b';
				cap.textContent = m.body;
				el.appendChild(cap);
			}
			return el;
		}
		var body = document.createElement('p');
		body.className = 'cl-radio__msg-b';
		body.textContent = m.body;
		el.appendChild(body);
		return el;
	}

	function renderThreadMessages(list) {
		if (!msgsEl) {
			return;
		}
		msgsEl.innerHTML = '';
		if (!list.length) {
			var p = document.createElement('p');
			p.className = 'cl-radio__none';
			p.textContent = 'No notes yet. Press the button below and talk.';
			msgsEl.appendChild(p);
			state.lastSeq = 0;
			state.since = '';
			return;
		}
		list.forEach(function (m) {
			msgsEl.appendChild(bubble(m));
			if (Number(m.seq) > state.lastSeq) {
				state.lastSeq = Number(m.seq);
				state.since = m.raw;
			}
		});
		msgsEl.scrollTop = msgsEl.scrollHeight;
	}

	function appendMessages(list) {
		if (!msgsEl || !list.length) {
			return;
		}
		var none = msgsEl.querySelector('.cl-radio__none');
		if (none) {
			none.remove();
		}
		var atBottom = msgsEl.scrollHeight - msgsEl.scrollTop - msgsEl.clientHeight < 60;
		list.forEach(function (m) {
			msgsEl.appendChild(bubble(m));
			if (Number(m.seq) > state.lastSeq) {
				state.lastSeq = Number(m.seq);
				state.since = m.raw;
			}
		});
		if (atBottom) {
			msgsEl.scrollTop = msgsEl.scrollHeight;
		}
	}

	function leaveLine() {
		if (pollTimer || Object.keys(pcs).length || talking) {
			leaveLive();
		}
	}

	function showThread() {
		if (heroEl) { heroEl.hidden = true; }
		if (threadEl) { threadEl.hidden = false; }
		drawTargets();
	}

	function closeThread() {
		leaveLine();
		state.active = 0;
		state.activeInfo = null;
		state.lastSeq = 0;
		state.since = '';
		if (heroEl) { heroEl.hidden = false; }
		if (threadEl) { threadEl.hidden = true; }
		drawLines();
	}

	function openThread(id) {
		if (Number(id) !== Number(state.active)) {
			leaveLine();
		}
		state.active = Number(id);
		state.lastSeq = 0;
		state.since = '';
		drawLines();
		post({ what: 'thread', thread: id }).then(function (res) {
			if (!res || !res.success || !res.data) {
				return;
			}
			// Read the line's capability before anything draws: the button's
			// state and the stage both depend on it.
			state.live = !!(res.data.thread && res.data.thread.live);
			state.livePeers = (res.data.thread && res.data.thread.peers) || [];
			if (res.data.thread && res.data.thread.me) {
				state.me = res.data.thread.me;
			}
			if (res.data.thread) {
				drawThreadHead(res.data.thread);
			}
			renderThreadMessages(res.data.messages || []);
			showThread();
			drawTargets();
			updateBadge();
			try {
				joinLive();
			} catch (e) {
				if (window.console) { console.warn('[cloaklink radio] live failed', e); }
				setTalk('idle', 'Live line unavailable');
			}
		});
	}

	/* ---- The feed ---- */

	function fetchFeed() {
		return post({ what: 'feed' }).then(function (res) {
			if (!res || !res.success || !res.data) {
				return;
			}
			var d = res.data;
			state.threads = d.threads || [];
			state.liveThreads = d.live || [];
			// The identity has to be recorded before anything connects. Both
			// ends decide which of them gives way in a collision by comparing
			// their own key against the other's, and a connection built before
			// `state.me` exists compares against an empty string — the two
			// ends then reach the same answer instead of opposite ones and
			// neither rolls back. That was silently costing every first
			// handshake until the next feed came round.
			state.me = d.me || null;
			state.roster = d.roster || [];
			state.groups = d.groups || [];
			state.isOffice = !!d.isOffice;
			// Listening starts here, not when a dock is opened: the set is
			// switched on for as long as the page is open, so a press from
			// the other end is heard while a ticket is being read. It runs
			// after the feeds are stored, because listen() reads the lines.
			try {
				listen();
			} catch (e) {
				if (window.console) { console.warn('[cloaklink radio] listen failed', e); }
			}
			if (root) {
				root.classList.toggle('is-office', state.isOffice);
				// An agent has one line, nobody to pick from and no sounds to
				// set, so the two tabs that exist for those would be empty
				// rooms. The server refuses them anyway; hiding them means the
				// desk never offers what it will not do.
				[].slice.call(root.querySelectorAll('[data-rtab="roster"], [data-rtab="settings"]')).forEach(function (b) {
					b.hidden = !state.isOffice;
				});
				var linesTab = root.querySelector('[data-rtab="lines"]');
				if (linesTab && !state.isOffice) {
					linesTab.classList.add('is-on');
					linesTab.setAttribute('aria-selected', 'true');
				}
			}
			state.tone = d.tone || null;
			drawLines();
			drawRoster();
			drawTargets();
			if (state.isOffice) {
				drawToneSettings();
			}
			updateBadge(d.unread || 0);
		});
	}

	function updateBadge(n) {
		var count = typeof n === 'number' ? n : state.threads.reduce(function (a, t) { return a + (Number(t.unread) || 0); }, 0);
		if (fabN) {
			fabN.textContent = count;
			fabN.hidden = !count;
		}
		if (root) {
			root.classList.toggle('has-unread', !!count);
		}
	}

	/**
	 * The polling tick.
	 *
	 * Two things are asked at once while the panel is open: the rail (cheap —
	 * counts and headings) and, when a line is open, its new messages. A tone
	 * plays for a message that is not mine and that I have not already seen,
	 * using the sender's own tone when there is one.
	 */
	function tick() {
		if (!state.open || state.busy) {
			return;
		}
		if (document.hidden) {
			return;
		}
		state.busy = true;
		// The rail changes only when somebody writes, so it is refreshed every
		// other tick while the message poll runs on every one.
		var jobs = [];
		if (Date.now() - (state.lastFeed || 0) > 5000) {
			state.lastFeed = Date.now();
			jobs.push(fetchFeed());
		}
		if (state.active) {
			jobs.push(post({ what: 'thread', thread: state.active, since: state.since }).then(function (res) {
				if (!res || !res.success || !res.data) {
					return;
				}
				var list = (res.data.messages || []).filter(function (m) { return !m.mine; });
				var fresh = [];
				list.forEach(function (m) {
					if (!state.seen[m.id]) {
						state.seen[m.id] = 1;
						fresh.push(m);
					}
				});
				// Only messages newer than what is already drawn. The server
				// may hand back the same second twice, so the id is what
				// decides — comparing times is how a message used to repeat on
				// every poll.
				appendMessages((res.data.messages || []).filter(function (m) {
					return Number(m.seq) > state.lastSeq;
				}));
				if (fresh.length) {
					play(toneForThread());
				}
			}));
		}
		Promise.all(jobs).catch(function () {}).then(function () {
			state.busy = false;
		});
	}

	/**
	 * The sound for a message that arrived while the dock was shut.
	 *
	 * The sender's own tone when the message is on a line that has one — that
	 * is the point of setting a different tone per agent — falling back to the
	 * desk's, which is what a group uses.
	 *
	 * @return {Object|null}
	 */
	function toneForNotify() {
		var best = null;
		var bestAt = '';
		(state.threads || []).forEach(function (t) {
			if (!Number(t.unread)) {
				return;
			}
			if (!best || String(t.last_at || '') > bestAt) {
				best = t;
				bestAt = String(t.last_at || '');
			}
		});
		if (best && best.tone && state.toneMap && state.toneMap[best.tone]) {
			return state.toneMap[best.tone];
		}
		return state.tone;
	}

	function toneForThread() {
		var t = state.activeInfo;
		if (!t) {
			return state.tone;
		}
		if (t.tone && state.toneMap && state.toneMap[t.tone]) {
			return state.toneMap[t.tone];
		}
		return state.tone;
	}

	/* ---- Opening and closing the dock ---- */

	function setOpen(on) {
		state.open = !!on;
		if (panel) { panel.hidden = !state.open; }
		if (!state.open) { leaveLine(); }
		// leaveLive keeps the connections and the poll, because another line
		// may be carrying a call and the next press has to be heard.
		if (root) { root.setAttribute('data-open', state.open ? '1' : '0'); root.classList.toggle('is-open', state.open); }
		if (fab) { fab.setAttribute('aria-expanded', state.open ? 'true' : 'false'); }
		if (state.open) {
			audio();
			fetchFeed();
			if (state.active) {
				openThread(state.active);
			}
		}
	}

	// Any first tap anywhere on the console unlocks the sinks.
	//
	// A desk that only listens never presses the key, so it never made the
	// one gesture the browser demands before an <audio> may speak — and a
	// browser that has refused once refuses every stream after it. The chip
	// below exists for that, but it only appears after a refusal, which is
	// one failed call too late. This runs once, from whatever the person
	// does first (reading a ticket, opening the dock), and costs nothing
	// when the key is what they press instead.
	var gestureDone = false;
	var firstGesture = function () {
		if (gestureDone) {
			return;
		}
		gestureDone = true;
		unlockAudio();
		document.removeEventListener('pointerdown', firstGesture, true);
		document.removeEventListener('keydown', firstGesture, true);
		// Ask for the microphone now, from inside the gesture.
		//
		// Otherwise the first press is the thing that raises the browser's
		// permission dialog, and the finger has already left the button by
		// the time it is answered — so the press is read as over and the
		// line is closed again without a word. From the outside that is a
		// key that does nothing the first time, which is exactly how "push
		// to talk does not work" reads. Warming it here means the press
		// itself is the replaceTrack it was designed to be.
		if (!mic && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
			openMic().then(function (stream) {
				if (stream) {
					connectAll(null);
				}
			});
		}
	};
	document.addEventListener('pointerdown', firstGesture, true);
	document.addEventListener('keydown', firstGesture, true);

	// The one thing a person can do about a browser that has refused to let
	// the far end speak. It is a button rather than wording because the fix
	// is a tap, and it appears only after a refusal.
	var hearBtn = document.getElementById('cl-radio-hear');
	if (hearBtn) {
		hearBtn.addEventListener('click', function (ev) {
			if (ev && ev.preventDefault) { ev.preventDefault(); }
			unlockAudio();
			Object.keys(remoteAudio).forEach(function (k) {
				var el = remoteAudio[k];
				if (el && el.srcObject) {
					tryPlay(el);
				}
			});
		});
	}

	if (fab) {
		fab.addEventListener('click', function () { setOpen(!state.open); });
	}
	var closeBtn = document.getElementById('cl-radio-close');
	if (closeBtn) {
		closeBtn.addEventListener('click', function () { setOpen(false); });
	}

	/* ---- Tabs ---- */

	document.querySelectorAll('[data-rtab]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var name = btn.getAttribute('data-rtab');
			document.querySelectorAll('[data-rtab]').forEach(function (b) {
				var on = b === btn;
				b.classList.toggle('is-on', on);
				b.setAttribute('aria-selected', on ? 'true' : 'false');
			});
			document.querySelectorAll('[data-rpane]').forEach(function (p) {
				p.hidden = p.getAttribute('data-rpane') !== name;
			});
		});
	});

	if (findEl) {
		findEl.addEventListener('input', function () {
			state.query = findEl.value.trim().toLowerCase();
			drawLines();
		});
	}

	/* ---- Sending ---- */

	// The "To" picker. On the operator's radio a note can go to the line the
	// file is open in, to any person on the desk, or to a group — which is the
	// whole point of a radio: you do not have to find a conversation first.
	function drawTargets() {
		// The picker is gone: the line IS the choice, opened from the rail.
	}

	// The timer on the button. It counts how long the button has been held,
	// which is the only number a person speaking into a radio ever wants: how
	// long they have been on air.
	function stopTicker() {
		if (clipTimer) {
			window.clearInterval(clipTimer);
			clipTimer = null;
		}
	}

	function startTicker() {
		stopTicker();
		clipStart = Date.now();
		if (talkTimer) {
			talkTimer.hidden = false;
			talkTimer.textContent = '0:00';
		}
		clipTimer = window.setInterval(function () {
			var sec = Math.floor((Date.now() - clipStart) / 1000);
			if (talkTimer) { talkTimer.textContent = clock(sec); }
			// Two minutes is the outer bound of one transmission, the same as
			// a real set that cuts off a stuck key.
			if (sec >= 120) {
				holding = false;
				micRelease();
			}
		}, 250);
	}

	function setTalk(stateName, label) {
		if (talkBtn) {
			talkBtn.setAttribute('data-state', stateName);
			talkBtn.setAttribute('aria-pressed', stateName === 'tx' ? 'true' : 'false');
			talkBtn.classList.toggle('is-on', stateName === 'tx');
		}
		if (talkT && label) {
			talkT.textContent = label;
		}
	}

	/**
	 * Which thread a note should go to, opening a line first if the picker
	 * names a person rather than a line.
	 *
	 * @return {Promise<number>}
	 */
	/* ---- Live push-to-talk ----
	 *
	 * A real radio: press and the other end hears you as you speak. The audio
	 * goes browser to browser over WebRTC; the server only carries the short
	 * handshake that lets the two find each other, because a server that
	 * relays the sound would need a socket and a working WebSocket host, and
	 * this has to run on ordinary shared hosting.
	 *
	 * There is no "send", no recording to keep, and nothing to play back. The
	 * microphone is opened once and kept; pressing raises the outgoing track,
	 * letting go drops it, and the far end hears the gap exactly as a radio
	 * does.
	 */

	/**
	 * Seconds as a clock a person reads: 0:07, 1:42.
	 *
	 * Four places in this file print a countdown — the on-air ticker, a voice
	 * note's progress, its total, and its remaining time — and every one of
	 * them called `clock()`. It was never defined anywhere, in this file or in
	 * any other script the panel loads. The ticker runs on a 250 ms interval,
	 * so the first tick after a press threw a ReferenceError, killed the
	 * interval and left the key stuck on air with no timer and no automatic
	 * release. The player handlers threw the same way, which is why a voice
	 * note's clock sat still.
	 *
	 * @param {number} secs Seconds.
	 * @return {string}
	 */
	function clock(secs) {
		secs = Math.max(0, Math.round(Number(secs) || 0));
		var m = Math.floor(secs / 60);
		var r = secs % 60;
		return m + ':' + (r < 10 ? '0' : '') + r;
	}

	var mic = null;          // the local MediaStream
	var pcs = {};            // peer key -> RTCPeerConnection
	var senders = {};        // peer key -> RTCRtpSender carrying our voice
	var remoteAudio = {};    // peer key -> <audio> playing their voice

	/**
	 * How loud one person is on this device, and whether they are muted.
	 *
	 * Stored per browser, per peer key. A desk is a room with one speaker and
	 * several people in it; the fader belongs to the person at that desk, not
	 * to the account — a setting made on a phone at the front should not
	 * follow somebody into the office.
	 *
	 * @param {string} key Peer key.
	 * @return {{volume: number, mute: boolean}}
	 */
	function peerPrefs(key) {
		var out = { volume: 100, mute: false };
		try {
			var raw = window.localStorage.getItem('cl_radio_peer_' + key);
			if (raw) {
				var one = JSON.parse(raw);
				if (one && typeof one === 'object') {
					if (typeof one.volume === 'number') { out.volume = Math.max(0, Math.min(100, one.volume)); }
					out.mute = !!one.mute;
				}
			}
		} catch (e) {}
		return out;
	}

	/**
	 * Remember one person's level on this device.
	 *
	 * @param {string} key   Peer key.
	 * @param {Object} prefs {volume, mute}.
	 */
	function savePeerPrefs(key, prefs) {
		try {
			window.localStorage.setItem('cl_radio_peer_' + key, JSON.stringify(prefs));
		} catch (e) {}
	}

	/**
	 * Write the muted set back to the desk's own settings.
	 *
	 * One list, two doors: the fader on a speaker card and the field on the
	 * settings page both name the same people, so a name muted in one is muted
	 * in the other. Only agent peers can be written this way — the office has
	 * no account row to name — and a failure is silent, because a radio that
	 * stopped working because a preference could not be saved would be a worse
	 * trade than a mute that did not persist.
	 */
	function saveMuteList() {
		var ids = [];
		Object.keys(voiceCards).forEach(function (k) {
			if (peerPrefs(k).mute && k.indexOf('agent:') === 0) {
				ids.push(k.replace('agent:', ''));
			}
		});
		var body = new FormData();
		body.set('action', 'cloaklink_radio');
		body.set('nonce', cfg.nonce || '');
		if (cfg.where) { body.set('where', cfg.where); }
		body.set('what', 'mutes');
		body.set('ids', ids.join(','));
		fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin', cache: 'no-store' })
			.catch(function () {});
	}

	/**
	 * Apply the stored level to one sink, whenever a stream arrives on it.
	 *
	 * Called from the sink itself rather than from the card, because the
	 * stream is attached to the sink before any card is drawn — a fader that
	 * only took effect while its card was on screen would be a fader that
	 * did nothing for as long as nobody was talking.
	 *
	 * @param {string}            key Peer key.
	 * @param {HTMLAudioElement}  el  Sink.
	 */
	function applySinkPrefs(key, el) {
		var prefs = peerPrefs(key);
		// A person muted on this account, from the settings page, starts
		// muted here as well as on any card. The two are the same decision
		// written in two places, so the one that was set first wins until
		// somebody changes it.
		var saved = (RC.muted || []).map(String);
		if (saved.indexOf(String(key)) !== -1) {
			prefs.mute = true;
		}
		el.muted = !!prefs.mute;
		el.volume = Math.max(0, Math.min(1, prefs.volume / 100));
	}
	var sigCursor = 0;
	// Whether the first poll has been used to position the cursor. See
	// pollSignals: an unstarted cursor replays the line's whole history.
	var sigStarted = false;
	var polling = false;
	var pollTimer = null;
	var burstTimer = null;
	// When the fast poll should stop asking. Set by hurry(), which is called
	// whenever a connection is created or a press begins.
	var burstUntil = 0;
	// How many times each peer has been built. Three tries is a handshake on
	// a bad network; more than that is somebody who is not there.
	var attempts = {};
	var talking = false;
	// True between the press and the release. It outlives the button element
	// because the permission dialog can swallow the press: the finger is gone
	// before getUserMedia resolves, and this is what tells the promise that
	// nobody is holding the key any more.
	var holding = false;
	// The on-air clock. Both are read by the release path, so they live here
	// with the other transmission state rather than inside startTicker().
	var clipTimer = 0;
	var clipStart = 0;

	function peerKey(kind, id) {
		return kind + ':' + id;
	}

	function liveActive() {
		return !!(state.active && state.live);
	}

	/* ---- Hearing the other end ----
	 *
	 * Two rules decide whether the far end is heard, and both were broken.
	 *
	 * The first is the browser's autoplay rule. An <audio> element may only
	 * start from a real finger. A track arriving is not a finger, so play()
	 * was refused — and the refusal was swallowed, which is why the symptom
	 * is not an error but silence. It worked at a desk where the page had
	 * been tapped for other reasons and not on a phone, which is the shape
	 * of a bug nobody can reproduce.
	 *
	 * The second is that a sink has to exist before the tap that unlocks it.
	 * An element made after the gesture is a new element with no history,
	 * and a phone refuses it exactly as it refused the first one.
	 *
	 * So: every sink is made up front, one per person on the line, the moment
	 * the line is joined; every touch, click or key anywhere on the page
	 * plays a silent half-second through each of them while they are empty;
	 * and anything the browser still holds back says so on the stage and
	 * offers one tap to release it, instead of being silence that looks like
	 * a fault in the radio.
	 */

	var sinkBlocked = false;

	// Half a second of silence, 8 kHz, mono. It exists only to be played from
	// inside a gesture: once an element has played anything at a human's
	// command the browser lets it play the stream that replaces it.
	// Half a second of silence, 8 kHz, mono, 16-bit. It exists only to be
	// played from inside a gesture: once an element has played anything at a
	// human's command the browser lets it play the stream that replaces it.
	//
	// The bytes are generated, not pasted. The previous constant declared an
	// 800-byte data chunk in its header and carried 598 bytes of samples, so a
	// strict decoder rejected it — and this same buffer is what the transceiver
	// is given at build time so the browser will agree to send at all. A buffer
	// a decoder refuses is a sender the browser treats as empty, which is how a
	// connection ends up answering `recvonly`.
	var SILENT = 'data:audio/wav;base64,UklGRmQfAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YUAfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==';

	function hearChip(on) {
		sinkBlocked = !!on;
		var chip = document.getElementById('cl-radio-hear');
		if (chip) {
			chip.hidden = !sinkBlocked;
		}
	}

	/**
	 * Ask one sink to speak, and remember a refusal.
	 *
	 * Every caller of play() in this file goes through here, so no refusal
	 * can be lost again: a rejected promise is the only signal the browser
	 * gives, and dropping it is what made the line silent.
	 *
	 * @param {HTMLAudioElement} el Sink.
	 */
	function tryPlay(el) {
		if (!el) {
			return;
		}
		var p;
		try {
			p = el.play();
		} catch (e) {
			hearChip(true);
			return;
		}
		if (p && p.catch) {
			p.catch(function () { hearChip(true); });
		}
	}

	/**
	 * Play silence through a sink from inside a gesture, or start its stream.
	 *
	 * A sink with a stream is simply played. A sink without one is given the
	 * silent buffer and played, which is what marks it as allowed to speak
	 * for the rest of the page's life. The buffer is left attached until the
	 * stream replaces it, so the element never falls back to a paused state.
	 *
	 * @param {HTMLAudioElement} el Sink.
	 */
	function armSink(el) {
		if (!el) {
			return;
		}
		if (el.srcObject) {
			tryPlay(el);
			return;
		}
		try {
			if (el.getAttribute('src') !== SILENT) {
				el.setAttribute('src', SILENT);
			}
			el.muted = false;
			el.volume = 1;
			tryPlay(el);
		} catch (e) {}
	}

	/**
	 * Mark the page as allowed to make sound, from inside a real gesture.
	 *
	 * Runs on every tap rather than once, because it is cheap and because a
	 * sink made a second ago was not there for the previous one.
	 */
	function unlockAudio() {
		// The same context the tones use, resumed from inside the gesture: a
		// context created outside one starts suspended on a phone, and a
		// suspended context is silence.
		try { audio(); } catch (e) {}

		// Keep a few unlocked sinks in reserve, so a voice that arrives after
		// this tap still has an element the phone will let speak. Created and
		// started here, inside the gesture, which is the only place a phone
		// grants that permission.
		// A spare has to be armed to be unlocked, and it can only be armed
		// inside a gesture — so a replacement is built AND armed here, once,
		// and never touched again until a voice is put into it.
		//
		// What must not happen is re-arming a spare that is already unlocked.
		// That was the loop that made a tap on any button restart the four
		// reserve elements, and the audible result was a click from the radio
		// on a page nobody had keyed.
		for (var i = sinkPool.length; i < 4; i++) {
			var sp = makeSink();
			armSink(sp);
			sp.__clArmed = true;
			sinkPool.push(sp);
		}

		// A sink already carrying somebody's voice is left alone.
		//
		// This loop used to arm every sink, which meant setting `src` and
		// calling play() on each one — and `armSink` on a sink that already
		// holds a stream goes straight to play(). So every tap anywhere on
		// the page restarted every inbound voice: a word that began on the
		// other side of a click was cut, and a person pressing a button
		// elsewhere heard a stutter from the radio they were not touching.
		// That is the "it clicks on its own" report.
		//
		// Only a sink that has no voice yet needs the spare unlocked, and
		// only a paused one needs to be asked again.
		Object.keys(remoteAudio).forEach(function (k) {
			var el = remoteAudio[k];
			if (!el) {
				return;
			}
			if (!el.srcObject) {
				armSink(el);
			} else if (el.paused) {
				tryPlay(el);
			}
		});

		if (!sinkBlocked) {
			hearChip(false);
		}
	}

	/**
	 * A sink element, made but not yet owned by anybody.
	 *
	 * It is off-screen rather than hidden: an element with display:none has
	 * no rendering surface, and some phones will not start a WebRTC stream in
	 * one. One pixel in the corner is invisible to the eye and real to the
	 * media engine.
	 *
	 * @return {HTMLAudioElement}
	 */
	function makeSink() {
		var el = document.createElement('audio');
		el.autoplay = true;
		el.playsInline = true;
		// Older iOS needs the attribute spelled out as well as the
		// property, or the stream is taken full-screen the moment it
		// starts playing.
		el.setAttribute('playsinline', '');
		el.setAttribute('webkit-playsinline', '');
		el.className = 'cl-radio__sink';
		document.body.appendChild(el);
		return el;
	}

	/**
	 * Sinks that have already been allowed to speak.
	 *
	 * A phone only lets an <audio> element play if it has been played once
	 * inside a real gesture. Opening the dock, or a person joining the line
	 * after the last tap, both build a sink outside any gesture — so those
	 * sinks can never start, and the person who joined late is inaudible on
	 * the one device most of the desk uses. A short reserve is made and
	 * started inside each tap and drawn on as voices arrive.
	 *
	 * @type {Array}
	 */
	var sinkPool = [];

	/**
	 * The sink for one person on the line, made once.
	 *
	 * @param {string} key Peer key.
	 * @return {HTMLAudioElement}
	 */
	function ensureAudioSink(key) {
		if (!remoteAudio[key]) {
			var el;
			if (sinkPool.length) {
				// A reserve element that has already been unlocked. It has to
				// let go of the silent buffer before it is pointed at a
				// stream: an element playing a `src` ignores `srcObject`.
				//
				// It is popped, not borrowed: two people on two lines must
				// never end up sharing one audio element, or the second
				// stream replaces the first and one of them goes silent.
				// The pool is refilled by the next gesture, which is what
				// makes building the replacement cheap.
				el = sinkPool.pop();
				try {
					el.pause();
					el.removeAttribute('src');
					el.load();
				} catch (e) {}
			} else {
				el = makeSink();
			}
			remoteAudio[key] = el;
		}
		return remoteAudio[key];
	}

	/**
	 * Point a sink at a stream and start it, as robustly as the browser allows.
	 *
	 * The retries are not superstition. Safari attaches the stream a frame or
	 * two after srcObject is set, and playing before that plays nothing;
	 * Chrome is ready at once. Playing again is free and a miss is silence.
	 *
	 * @param {string}      key    Peer key.
	 * @param {MediaStream} stream Their voice.
	 */
	function playIntoSink(key, stream) {
		if (!stream) {
			return;
		}
		var el = ensureAudioSink(key);
		// Their own level, not the master one: a sink reset to the desk's
		// volume on every stream would undo a mute the moment the person
		// spoke again.
		applySinkPrefs(key, el);
		// Let go of the silent buffer before taking the stream.
		//
		// Every sink is primed with a silent `src` data URI from inside a
		// tap, because that is the only way a phone will let an element
		// speak later. But an element whose resource is a `src` ignores
		// `srcObject` entirely — the two are not merged, the attribute
		// simply wins. So the first voice to arrive after any tap was
		// handed to an element still bound to the silent buffer and played
		// nothing at all: the line looked connected, the meter moved on the
		// sending side, and neither console heard a word. Only the pool path
		// cleared the attribute, which is why it worked on the bench and
		// not on a desk where a tap always comes first.
		//
		// This is the fix for "push to talk, no sound, both ends".
		if (el.getAttribute('src')) {
			try {
				el.pause();
				el.removeAttribute('src');
				el.load();
			} catch (e) {}
		}
		if (el.srcObject !== stream) {
			el.srcObject = stream;
		}
		// A sink that starts is the proof the line is audible. Clearing the
		// chip from here rather than from play() means it only disappears
		// when sound is actually leaving, not when the browser said yes.
		if (!el.__clHeard) {
			el.__clHeard = true;
			el.addEventListener('playing', function () {
				if (el.srcObject) {
					hearChip(false);
				}
			});
		}
		tryPlay(el);
		[60, 250, 900, 2200].forEach(function (ms) {
			window.setTimeout(function () {
				if (el.paused) {
					tryPlay(el);
				}
			}, ms);
		});
	}

	// A last net. A sink that is attached to a stream and still paused is
	// either waiting for a gesture or waiting for a frame; neither resolves
	// itself in every browser, and both cost nothing to retry.
	window.setInterval(function () {
		if (document.hidden) {
			return;
		}
		Object.keys(remoteAudio).forEach(function (k) {
			var el = remoteAudio[k];
			if (el && el.srcObject && el.paused) {
				tryPlay(el);
			}
		});
	}, 2500);

	/* ---- Who is talking ----
	 *
	 * The person speaking is announced on every other screen on the desk: a
	 * card in the corner with their name, their initials in the colour they
	 * are drawn in everywhere else, and a level meter that moves with their
	 * voice. It is drawn from the received audio rather than from a "talking"
	 * message on the wire, because a protocol message can lie — a page closed
	 * mid-press would leave a card up forever — while a track that has gone
	 * quiet cannot.
	 *
	 * Nothing here touches the microphone: measuring the incoming stream is a
	 * read of data that was already arriving.
	 */

	var voiceCtx = null;
	var voiceCards = {};   // key -> {el, raf, quietSince, analyser, data}

	/** The corner the cards stack in, made once. */
	function voiceBoard() {
		var el = document.getElementById('cl-spk');
		if (!el) {
			el = document.createElement('div');
			el.className = 'cl-spk at-' + (RC.whoPos || 'top-right');
			el.id = 'cl-spk';
			el.setAttribute('role', 'status');
			el.setAttribute('aria-live', 'polite');
			document.body.appendChild(el);
		}
		return el;
	}

	/**
	 * The colour a person is drawn in.
	 *
	 * The same four tones the tracing map and the person cards use, dealt by
	 * the peer key so a name is the same colour on every screen. A colour
	 * that changed per session would be worse than none: the point is to
	 * recognise the speaker before reading the name.
	 *
	 * @param {string} key Peer key.
	 * @return {string}
	 */
	function toneFor(key) {
		var tones = ['cyan', 'green', 'amber', 'violet'];
		var sum = 0;
		for (var i = 0; i < key.length; i++) {
			sum += key.charCodeAt(i);
		}
		return tones[sum % tones.length];
	}

	/**
	 * Create the card for one speaker. It is made once, hidden, and shown the
	 * instant their level rises.
	 *
	 * The card used to be built when a track arrived and torn down when it
	 * went quiet. Both of those are slow at exactly the wrong moment: a
	 * `track` event does not fire when a person presses a key on a connection
	 * that is already open — the track is the same track, it merely starts
	 * carrying sound — so the card only appeared after a renegotiation that
	 * had to happen first. That is the "popup but late" symptom.
	 *
	 * The card is built here, at connection time, with its analyser attached
	 * and its meter running. It is hidden until the first frame over the
	 * threshold, which is a single animation frame after the far end's
	 * encoder starts sending — about 20ms, not a second.
	 *
	 * @param {string}      key    Peer key.
	 * @param {MediaStream} stream Their voice.
	 * @param {string}      name   Their name.
	 * @param {string}      avatar Their picture, or ''.
	 */
	function watchVoice(key, stream, name, avatar) {
		if (!RC.whoCard) {
			return;
		}
		var track = stream && stream.getAudioTracks ? stream.getAudioTracks()[0] : null;
		if (!track) {
			return;
		}
		if (voiceCards[key] && voiceCards[key].track === track) {
			return;
		}
		stopWatching(key);

		var C = window.AudioContext || window.webkitAudioContext;
		if (!C) {
			return;
		}
		if (!voiceCtx) {
			try { voiceCtx = new C(); } catch (e) { return; }
		}
		if (voiceCtx.state === 'suspended') {
			voiceCtx.resume().catch(function () {});
		}

		var analyser;
		var src;
		try {
			src = voiceCtx.createMediaStreamSource(stream);
			analyser = voiceCtx.createAnalyser();
			analyser.fftSize = 256;
			analyser.smoothingTimeConstant = 0.35;
			src.connect(analyser);
		} catch (e) {
			return;
		}

		var card = document.createElement('div');
		card.className = 'cl-spk__c tone-' + toneFor(key);
		// A face if the account has one, initials if it does not. Either way
		// the mark sits in the same ring at the same size, so the card never
		// changes shape depending on whether somebody uploaded a picture.
		var mark = avatar
			? '<img src="" alt="" class="cl-spk__ph">'
			: '<b>' + initials(name || '?') + '</b>';
		// The card is the one place a person is named while they talk, so it
		// is also the right place to decide how loudly they reach this desk.
		//
		// It carries three things a radio needs: the face (their picture if
		// they have one, their initials if not), a volume fader for this one
		// person alone, and a mute. Both settings are stored on this device
		// under that person's id, so a loud talker is turned down once and
		// stays turned down, and nobody else on the line is affected.
		card.innerHTML =
			'<span class="cl-spk__av">' + mark +
			'<span class="cl-spk__rings"><i></i><i></i><i></i></span></span>' +
			'<span class="cl-spk__mid"><b class="cl-spk__nm"></b>' +
			'<span class="cl-spk__st">speaking</span></span>' +
			'<span class="cl-spk__meter"><i></i><i></i><i></i><i></i><i></i></span>' +
			'<span class="cl-spk__acts">' +
			'<button type="button" class="cl-spk__mute" aria-label="Mute this person" title="Mute this person">' +
			'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" aria-hidden="true">' +
			'<path d="M4 9.5h3.5L12 5.6v12.8L7.5 14.5H4z"/>' +
			'<path class="cl-spk__mute-x" d="m16 9.5 4 5m0-5-4 5"/>' +
			'</svg></button>' +
			'<input type="range" class="cl-spk__vol" min="0" max="100" step="5" aria-label="Volume for this person">' +
			'</span>';
		if (avatar) {
			var ph = card.querySelector('.cl-spk__ph');
			if (ph) {
				// Assigning src after insertion keeps the markup free of any
				// string built from a URL, which is the only place a quote
				// could have broken it.
				ph.src = avatar;
				ph.addEventListener('error', function () {
					// A picture that will not load falls back to initials
					// rather than leaving a broken mark on the card.
					var b = document.createElement('b');
					b.textContent = initials(name || '?');
					if (ph.parentNode) { ph.parentNode.replaceChild(b, ph); }
				});
			}
		}
		var nm = card.querySelector('.cl-spk__nm');
		if (nm) { nm.textContent = name || 'Someone on the desk'; }

		// Measured but not shown. The element is in the document so its
		// meters have a layout to move in, and `is-hidden` keeps it off the
		// screen until there is something to say.
		card.classList.add('is-hidden');
		voiceBoard().appendChild(card);

		var bars = [].slice.call(card.querySelectorAll('.cl-spk__meter i'));

		// One person's level, remembered on this device.
		var prefs = peerPrefs(key);
		var fader = card.querySelector('.cl-spk__vol');
		var muteBtn = card.querySelector('.cl-spk__mute');
		var applyPrefs = function () {
			var el = remoteAudio[key];
			if (el) {
				el.muted = !!prefs.mute;
				el.volume = Math.max(0, Math.min(1, prefs.volume / 100));
			}
			if (fader) {
				fader.value = String(prefs.volume);
			}
			card.classList.toggle('is-muted', !!prefs.mute);
			if (muteBtn) {
				muteBtn.setAttribute('aria-pressed', prefs.mute ? 'true' : 'false');
				muteBtn.setAttribute('title', prefs.mute ? 'Unmute this person' : 'Mute this person');
			}
		};
		if (fader) {
			fader.addEventListener('input', function () {
				prefs.volume = Math.max(0, Math.min(100, Number(fader.value) || 0));
				savePeerPrefs(key, prefs);
				applyPrefs();
			});
		}
		if (muteBtn) {
			muteBtn.addEventListener('click', function (ev) {
				ev.preventDefault();
				ev.stopPropagation();
				prefs.mute = !prefs.mute;
				savePeerPrefs(key, prefs);
				applyPrefs();
				// The same decision, written where the settings page reads it.
				// A mute that lived only in this tab would be forgotten by the
				// next reload, and the person would be loud again tomorrow.
				saveMuteList();
			});
		}
		applyPrefs();
		var data = new Uint8Array(analyser.frequencyBinCount);
		var rec = {
			el: card,
			track: track,
			src: src,
			analyser: analyser,
			data: data,
			bars: bars,
			raf: 0,
			quietSince: 0,
			spokeAt: 0,
			onair: false
		};
		voiceCards[key] = rec;

		// Sixteen milliseconds per pass, which is one frame at 60Hz. The card
		// is up on the first frame that carries speech and comes down after
		// the operator's chosen linger, so the announcement is as close to
		// simultaneous with the voice as a browser allows.
		var loop = function () {
			analyser.getByteFrequencyData(data);
			var sum = 0;
			for (var i = 0; i < data.length; i++) { sum += data[i]; }
			var level = sum / data.length;

			// The gate. It was 5, which on an average of the first half of the
			// spectrum is below the idle hiss of most microphones — so the
			// level never fell back under it, "quiet" never arrived, and the
			// card stayed on screen with SPEAKING under a person who had
			// stopped talking two minutes ago. 14 is above a room's floor and
			// well below a voice, which is what a gate is for.
			if (level > 14) {
				rec.spokeAt = Date.now();
				if (!rec.onair) {
					rec.onair = true;
					card.classList.remove('is-hidden');
					card.classList.add('is-onair');
				}
				rec.quietSince = 0;
				bars.forEach(function (b, i) {
					var from = Math.floor((i / bars.length) * data.length * 0.55);
					var to = Math.floor(((i + 1) / bars.length) * data.length * 0.55);
					var peak = 0;
					for (var j = from; j < to; j++) { if (data[j] > peak) { peak = data[j]; } }
					b.style.height = Math.max(8, Math.min(100, (peak / 190) * 100)) + '%';
				});
				card.classList.toggle('is-loud', level > 22);
			} else if (rec.onair) {
				if (!rec.quietSince) {
					rec.quietSince = Date.now();
				} else if (Date.now() - rec.quietSince > Math.max(300, RC.whoLinger)) {
					rec.onair = false;
					rec.quietSince = 0;
					card.classList.add('is-hidden');
					card.classList.remove('is-loud');
					bars.forEach(function (b) { b.style.height = '8%'; });
				}
			}
			// A last net, so no reading of the meter can leave a name on
			// screen. Whatever the level says, a card whose track has not
			// been loud for longer than the linger window comes down.
			if (rec.onair && rec.spokeAt && Date.now() - rec.spokeAt > Math.max(600, RC.whoLinger) + 1200) {
				rec.onair = false;
				rec.quietSince = 0;
				card.classList.add('is-hidden');
				card.classList.remove('is-loud');
				bars.forEach(function (b) { b.style.height = '8%'; });
			}
			rec.raf = window.requestAnimationFrame(loop);
		};
		rec.raf = window.requestAnimationFrame(loop);
	}

	/**
	 * Take a speaker's card down.
	 *
	 * @param {string} key Peer key.
	 */
	function stopWatching(key) {
		var rec = voiceCards[key];
		if (!rec) {
			return;
		}
		delete voiceCards[key];
		if (rec.raf) { window.cancelAnimationFrame(rec.raf); }
		try {
			if (rec.src) { rec.src.disconnect(); }
		} catch (e) {}
		var el = rec.el;
		el.classList.add('is-going');
		window.setTimeout(function () {
			if (el && el.parentNode) { el.parentNode.removeChild(el); }
		}, 320);
	}

	function stopAllWatching() {
		Object.keys(voiceCards).forEach(stopWatching);
	}

	function dropPeer(key) {
		stopWatching(key);
		if (pcs[key]) {
			try { pcs[key].close(); } catch (e) {}
		}
		delete pcs[key];
		delete senders[key];
		if (remoteAudio[key]) {
			try { remoteAudio[key].pause(); } catch (e) {}
			remoteAudio[key].srcObject = null;
			remoteAudio[key].remove();
		}
		delete remoteAudio[key];
	}

	function dropAllPeers() {
		Object.keys(pcs).forEach(dropPeer);
	}

	/**
	 * Open the microphone once.
	 *
	 * @return {Promise<MediaStream|null>}
	 */
	function openMic() {
		if (mic && mic.getAudioTracks().some(function (t) { return t.readyState === 'live'; })) {
			return Promise.resolve(mic);
		}
		if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
			return Promise.resolve(null);
		}
		return navigator.mediaDevices.getUserMedia({
			audio: {
				// Straight from the settings screen. A busy office wants all
				// three; a quiet room with a soft speaker may find the
				// processing clips them.
				echoCancellation: !!RC.echo,
				noiseSuppression: !!RC.noise,
				autoGainControl: !!RC.gain
			}
		}).then(function (stream) {
			mic = stream;
			// A phone hands back a stream whose track ends when the app goes
			// to the background, the screen locks, or another app takes the
			// microphone. The cached stream then looks present but carries
			// nothing, so every later press sent silence. Dropping it here
			// means the next press asks again, which is also what re-acquires
			// the microphone after the other app has finished with it.
			stream.getAudioTracks().forEach(function (t) {
				t.addEventListener('ended', function () {
					if (mic === stream) {
						mic = null;
						Object.keys(senders).forEach(function (k) {
							try { senders[k].replaceTrack(silence()).catch(function () {}); } catch (e) {}
						});
					}
				});
			});
			return stream;
		}).catch(function () {
			return null;
		});
	}

	/**
	 * Post one signal for one peer.
	 *
	 * @param {number} tid   Thread.
	 * @param {string} kind  offer | answer | ice | bye.
	 * @param {Object} peer  {kind, id}.
	 * @param {*}      data  Payload, stringified.
	 */
	function sendSignal(tid, kind, peer, data) {
		var body = new FormData();
		body.set('action', 'cloaklink_radio');
		body.set('nonce', cfg.nonce || '');
		if (cfg.where) { body.set('where', cfg.where); }
		body.set('what', 'signal');
		body.set('thread', String(tid));
		body.set('sig', kind);
		body.set('to_kind', peer.kind);
		body.set('to_id', String(peer.id));
		body.set('data', typeof data === 'string' ? data : JSON.stringify(data));
		return fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin', cache: 'no-store' })
			.then(function (r) { return r.json(); })
			.catch(function () { return null; });
	}

	/**
	 * Whether this side is the polite one for a given pair.
	 *
	 * Both ends need to sort the same pair the same way and reach opposite
	 * answers — that is the whole rule. Comparing the two actor keys does
	 * that without either side having to be told, and it is stable for the
	 * life of the page.
	 *
	 * @param {string} key Their peer key.
	 * @return {boolean}
	 */
	function politeFor(key) {
		var mine = state.me ? state.me.kind + ':' + state.me.id : '';
		// An operator whose identity has not arrived yet must still pick a
		// side. Comparing against the raw string gives one deterministically,
		// so a press before the feed loads still builds a line.
		return mine < key;
	}

	/**
	 * The audio transceiver on a connection, if it has one.
	 *
	 * A connection can carry more than audio, and after a negotiation there
	 * can be more than one transceiver. This picks the one that is speaking,
	 * preferring a sender with a track, so the caller always acts on the
	 * transceiver the offer actually created.
	 *
	 * @param {RTCPeerConnection} pc Connection.
	 * @return {Object|null} The transceiver.
	 */
	function audioTransceiver(pc) {
		if (!pc || !pc.getTransceivers) {
			return null;
		}
		// Only a transceiver carrying a mid belongs to the negotiation in
		// progress. One built before the remote offer arrived — the silent
		// sendrecv transceiver every connection is given at build time — has
		// no mid, and the browser treats it as a second, separate audio
		// stream. Answering through that one is what wrote `recvonly` into
		// every answer this radio ever sent: the offer's own transceiver was
		// left unclaimed and untouched, so the answering side had nothing to
		// send on it. Counsel: prefer a mid, then a track, in that order.
		var list = pc.getTransceivers();
		var associated = null;
		var withTrack = null;
		var audio = null;
		for (var i = 0; i < list.length; i++) {
			var t = list[i];
			var kind = (t.receiver && t.receiver.track && t.receiver.track.kind)
				|| (t.sender && t.sender.track && t.sender.track.kind) || '';
			if ('audio' !== kind) {
				continue;
			}
			var hasMid = (t.mid !== null && t.mid !== undefined && '' !== t.mid);
			if (!audio) { audio = t; }
			if (hasMid && !associated) { associated = t; }
			if (hasMid && t.sender && t.sender.track && !withTrack) { withTrack = t; }
		}
		return withTrack || associated || audio;
	}

	/**
	 * One silent audio track, made once per page.
	 *
	 * A transceiver needs something to send before the browser will agree to
	 * send anything at all. This is that something: an oscillator through a
	 * gain of zero, so the far end receives a genuine audio stream — a codec
	 * is negotiated, packets flow, the route is exercised — and hears nothing.
	 * Swapping the microphone in later is a replaceTrack, which needs no
	 * handshake.
	 *
	 * @return {MediaStreamTrack|null}
	 */
	var silentTrack = null;
	function silence() {
		if (silentTrack) {
			return silentTrack;
		}
		try {
			var Ctx = window.AudioContext || window.webkitAudioContext;
			var c = new Ctx();
			var osc = c.createOscillator();
			var gain = c.createGain();
			// Exactly zero. A tiny value was the alternative and it is worse:
			// it is audible on a quiet line and it still costs the same.
			gain.gain.value = 0;
			osc.connect(gain);
			var dest = c.createMediaStreamDestination();
			gain.connect(dest);
			osc.start();
			silentTrack = dest.stream.getAudioTracks()[0] || null;
		} catch (e) {
			silentTrack = null;
		}
		return silentTrack;
	}

	/**
	 * Attach our voice to a connection, once.
	 *
	 * @param {Object}      pc     Connection.
	 * @param {string}      key    Peer key.
	 * @param {MediaStream} stream Microphone.
	 */
	/**
	 * Is the sender remembered for this peer still the one carrying our audio?
	 *
	 * The map is written in two places: when a connection is first built, and
	 * when an incoming offer replaces the transceiver. A renegotiation can
	 * retire the old transceiver — answerOffer stops the orphans — and the
	 * remembered sender then belongs to something that no longer sends.
	 * replaceTrack on it succeeds and carries nothing, which is a press that
	 * lights the meter and is heard by nobody.
	 *
	 * @param {RTCPeerConnection} pc  Connection.
	 * @param {string}            key Peer key.
	 * @return {boolean}
	 */
	function senderStillLive(pc, key) {
		var s = senders[key];
		if (!s) {
			return false;
		}
		if (!pc || !pc.getTransceivers) {
			return true;
		}
		var list = pc.getTransceivers();
		for (var i = 0; i < list.length; i++) {
			var t = list[i];
			if (t.sender !== s) {
				continue;
			}
			// A stopped transceiver is one this end has finished with. Its
			// sender accepts a track and transmits nothing.
			if ('stopped' === t.currentDirection || 'stopped' === t.direction) {
				return false;
			}
			return true;
		}
		return false;
	}

	function attachMic(pc, key, stream) {
		if (!pc) {
			return;
		}
		var track = stream && stream.getAudioTracks ? stream.getAudioTracks()[0] : null;
		// Forget a sender that is no longer on this connection, so the block
		// below builds a fresh transceiver instead of handing the microphone
		// to a retired one.
		if (senders[key] && !senderStillLive(pc, key)) {
			delete senders[key];
		}
		if (!senders[key]) {
			// The sender is made when the connection is built, with nothing
			// attached to it. That is the whole of the latency fix: the
			// transceiver is negotiated once, at page load, so a press is a
			// replaceTrack on a sender that already exists rather than a new
			// track that has to be offered, answered and re-gathered before a
			// single packet can leave. Pressing the key now costs nothing.
			try {
				// A transceiver with no track is offered as sendrecv, but the
				// browser answers it recvonly — it has nothing to send yet, so
				// it reasons that the direction cannot be "sendrecv". That
				// answer is what broke half of every call: the answering side
				// could hear and could never be heard, because its own
				// outbound audio was never negotiated. replaceTrack later does
				// not fix it; by then the direction is settled.
				//
				// A silent track at build time settles it. The transceiver has
				// something to send, so the answer stays sendrecv, and the real
				// microphone is swapped in on the press with replaceTrack —
				// still zero negotiation, still instant.
				var tx = pc.addTransceiver(silence(), { direction: 'sendrecv' });
				senders[key] = tx.sender;
			} catch (e) {
				return;
			}
		}
		if (!track) {
			return;
		}
		try {
			senders[key].replaceTrack(track).catch(function () {});
		} catch (e) {}
	}

	/**
	 * Say whether this pair has a route for sound, once it is connected.
	 *
	 * A connection that is up and carrying nothing is the failure that looks
	 * exactly like a broken set, and there is nothing on screen to tell them
	 * apart. This asks the pair which candidates won: a host, srflx or prflx
	 * pair means the two browsers found each other directly; relay on both
	 * sides means a relay is carrying it; and no pair at all after the line
	 * has been up a few seconds means the handshake finished and the media
	 * has nowhere to go.
	 *
	 * @param {RTCPeerConnection} pc  Connection.
	 * @param {string}            key Peer key.
	 */
	function checkRoute(pc, key) {
		if (!pc || !pc.getStats) {
			return;
		}
		pc.getStats(null).then(function (report) {
			var pair = null;
			var local = null;
			var remote = null;
			report.forEach(function (r) {
				if ('candidate-pair' === r.type && 'succeeded' === r.state) {
					pair = r;
				}
			});
			if (!pair && pc.sdpMid !== undefined) {
				return;
			}
			report.forEach(function (r) {
				if (!pair) { return; }
				if ('local-candidate' === r.type && r.id === pair.localCandidateId) { local = r; }
				if ('remote-candidate' === r.type && r.id === pair.remoteCandidateId) { remote = r; }
			});
			var kindOf = function (c) {
				if (!c) { return ''; }
				return String(c.candidateType || '');
			};
			var lk = kindOf(local);
			var rk = kindOf(remote);
			var direct = ('host' === lk || 'srflx' === lk || 'prflx' === lk || 'host' === rk || 'srflx' === rk || 'prflx' === rk);
			if (direct || 'relay' === lk || 'relay' === rk) {
				return;
			}
			// No route found. Said once per line, on the stage, in the words
			// of the thing the operator can actually change.
			if (window.clRadioRouteWarned) { return; }
			window.clRadioRouteWarned = true;
			setTalk('idle', 'Connected, but this network has no direct route for sound — ask the office to set a relay server');
			var stage = document.getElementById('cl-radio-stage-t');
			if (stage) {
				stage.textContent = 'Connected, but this network has no direct route for sound. A relay server in Settings → Walkie-talkie fixes it.';
			}
		}).catch(function () {});
	}

	/**
	 * Build the connection to one peer.
	 *
	 * There is no "one side offers" rule, because a rule that depends on both
	 * ends agreeing who is senior is a rule that produces no connection at all
	 * when one of them has not finished loading. Instead both sides offer when
	 * they have something to negotiate, and a collision is settled the way the
	 * WebRTC specification settles it: the polite peer rolls its own offer back
	 * and accepts theirs, the impolite peer ignores the incoming one. That is
	 * the "perfect negotiation" pattern, and its value here is that neither
	 * side can be stuck waiting for the other.
	 *
	 * @param {number} tid   Thread.
	 * @param {Object} peer  {kind, id}.
	 * @return {Object|null} The connection.
	 */
	function makePeer(tid, peer) {
		var key = peerKey(peer.kind, peer.id);
		if (pcs[key]) {
			// A connection that already exists only needs the current
			// microphone swapped in, and only if there is one. Passing null
			// here is deliberate: pre-connecting happens before anybody has
			// granted a microphone, and asking for one on page load is a
			// prompt the browser refuses without a gesture.
			if (mic) {
				attachMic(pcs[key], key, mic);
			}
			return pcs[key];
		}
		var PC = window.RTCPeerConnection || window.webkitRTCPeerConnection;
		if (!PC) {
			return null;
		}
		var pc;
		try {
			pc = new PC({
				// The discovery servers are a setting: a deployment behind a
				// strict firewall needs its own, and "local network only" is a
				// real answer for a desk on one floor.
				iceServers: (RC.ice || []).map(function (u) { return { urls: u }; })
					// Then the relay, when one is configured. A connection
					// that cannot find a direct route would otherwise come up
					// "connected" with a live track and carry no sound at all
					// — the failure that looks exactly like a broken radio.
					.concat(RC.turn ? [RC.turn] : [])
			});
		} catch (e) {
			return null;
		}
		pcs[key] = pc;
		// A connection was just created: the handshake is about to need
		// answers, and this is the one window where speed matters — but only
		// for the first few attempts. A peer that is simply not there would
		// otherwise re-arm the fast poll on every rebuild, all night, at five
		// requests a second.
		if (attempts[key] < 3) {
			hurry();
		}

		attempts[key] = (attempts[key] || 0) + 1;

		var polite = politeFor(key);
		var makingOffer = false;
		var ignoreOffer = false;

		// Their voice arrives as a track and is played, not stored.
		pc.addEventListener('track', function (ev) {
			var stream = null;
			if (ev.streams && ev.streams[0]) {
				stream = ev.streams[0];
			} else {
				// Some browsers hand over a bare track with no stream around
				// it. A stream of our own is better than a silent line.
				try { stream = new MediaStream([ev.track]); } catch (e) {}
			}
			if (!stream) {
				return;
			}
			playIntoSink(key, stream);
			// The same stream is measured, not just played: a level that
			// rises is a person holding their key, and that is what puts
			// their name on everybody else's screen.
			watchVoice(key, stream, (peer && peer.name) || '', (peer && peer.avatar) || '');
		});

		pc.addEventListener('icecandidate', function (ev) {
			if (ev.candidate) {
				sendSignal(tid, 'ice', peer, ev.candidate.toJSON ? ev.candidate.toJSON() : ev.candidate);
			}
		});

		// Our own side sends an offer whenever the connection has something to
		// negotiate. With the track attached from the start that is once, at
		// the beginning; a device change makes it happen again and this is
		// what carries the new track across.
		pc.addEventListener('negotiationneeded', function () {
			// Only from a settled connection. The answer path has just
			// assigned the transceiver a direction, and that raises this
			// event while the answer is still being written — offering from
			// there collides with the answer it is already sending, and the
			// two of them bounce for as long as the desk is open. The
			// direction it is asking to negotiate is the one the answer
			// already carries, so nothing is lost by waiting for stable.
			if (pc.signalingState !== 'stable') {
				return;
			}
			// An offer that has already been sent and answered is not news.
			//
			// The rollback below (in answerOffer, for an abandoned or
			// colliding handshake) re-opens negotiation, and the browser
			// fires this event again for the change it just undid. Offering
			// from there produces a new description, the far end rolls back
			// for it, which fires this again — a ring of offers every poll,
			// with neither end ever reaching DTLS. The bench showed it
			// plainly: fourteen offers in twenty seconds on one line and a
			// connection pinned at have-local-offer.
			//
			// A description applied from the far end fixes what needs
			// negotiating. So an offer is only made while there is something
			// this page has changed that no applied description covers — and
			// never more than once every few seconds regardless.
			// One side offers, the other answers. Always.
			//
			// Both ends offering was tried — the idea was that whichever side
			// had something to negotiate could say so. In practice two
			// browsers on the same line race each other: each offer makes the
			// other side roll back, a rollback raises negotiationneeded, and
			// the two descriptions are never the same pair. ICE reaches
			// `connected` and DTLS sits at `connecting` for ever, because the
			// fingerprint one end is validating belongs to a description the
			// other end has already replaced. That is the walkie-talkie that
			// "connects" and carries nothing.
			// The polite side answers rather than races — with one exception.
			//
			// "The polite side never offers" was the fix for the ring, and it
			// is right whenever a description has already been exchanged:
			// there is something to collide with, and racing it is what put
			// DTLS at `connecting` for ever.
			//
			// But it also removed the only recovery the polite end had. If the
			// impolite peer's offer was written before this page was polling,
			// or was consumed by a connection that has since been dropped and
			// rebuilt, the polite side sits holding nothing at all and is
			// forbidden from saying so. The impolite side gives up after three
			// attempts (see the dead-line watchdog), and then neither end will
			// ever speak again — a line that stays silent until the page is
			// reloaded. That is one half of "the walkie-talkie does not work".
			//
			// So the rule is narrowed to what actually caused the ring: the
			// polite side does not offer *over* an existing description. With
			// no remote description it has received nothing to collide with,
			// and a first offer from it is a plain glare — which the answer
			// path already settles correctly, because the polite side is the
			// one that rolls back. It is still bounded by the same four-second
			// floor inside needsOffer(), so this cannot become a storm.
			if (polite && pc.remoteDescription) {
				return;
			}
			if (!needsOffer(pc)) {
				return;
			}
			makingOffer = true;
			pc.createOffer().then(function (offer) {
				return pc.setLocalDescription(offer);
			}).then(function () {
				sendSignal(tid, 'offer', peer, pc.localDescription || {});
			}).catch(function () {}).then(function () {
				makingOffer = false;
			});
		});

		pc.addEventListener('connectionstatechange', function () {
			if (pc.connectionState === 'failed') {
				// A line that dropped is rebuilt once rather than abandoned:
				// a phone that changes network drops the connection and would
				// otherwise stay dead until the page was reloaded.
				try { pc.restartIce(); } catch (e) {}
			}
			if (pc.connectionState === 'connected') {
				// It worked. The retry budget goes back to full, so a later
				// drop — a phone changing network — is rebuilt as eagerly as
				// the first one was.
				attempts[key] = 0;
				hearChip(false);
				// "Connected" is not "audible", and saying so is the whole
				// point of this check.
				//
				// Two browsers can complete a handshake and still pass no
				// media: a symmetric NAT or a firewall that drops UDP lets the
				// signalling through and finds no route for the sound. The
				// line shows green, the track is live, and nothing is heard —
				// which reads as "the walkie-talkie does not work". Once the
				// connection has had a few seconds, the pair of candidates
				// that actually won is inspected: if neither side's local or
				// remote candidate is a relay or a direct address, the answer
				// is that no route exists and a relay server is needed. That
				// is said on the stage, with what to do about it.
				if (!pc.__clRouteChecked) {
					pc.__clRouteChecked = true;
					window.setTimeout(function () {
						checkRoute(pc, key);
					}, 4000);
				}
				// The click a real set makes when the far end is there. Once
				// per connection, not once per candidate.
				if (RC.cue && !pc.__clCued) {
					pc.__clCued = true;
					play({ wave: 'sine', notes: [880], gap: 0.06 });
				}
				// The stream may have arrived before the connection settled;
				// one more attempt from here costs nothing.
				[].slice.call(pc.getReceivers ? pc.getReceivers() : []).forEach(function (r) {
					if (r.track) {
						var el = remoteAudio[key];
						if (!el || !el.srcObject) {
							try {
								playIntoSink(key, new MediaStream([r.track]));
							} catch (e) {}
						}
					}
				});
			}
		});

		attachMic(pc, key, mic);

		// Kept on the object so the signal handler can reach this pair's own
		// glare state rather than guessing from the connection's.
		pc.__cl = {
			key: key,
			peer: peer,
			tid: tid,
			polite: polite,
			makingOffer: function () { return makingOffer; },
			ignoreOffer: function () { return ignoreOffer; },
			setIgnoreOffer: function (v) { ignoreOffer = !!v; }
		};

		return pc;
	}

	/**
	 * Feed one signal into a connection.
	 *
	 * @param {number} tid Thread.
	 * @param {Object} msg Signal from the server.
	 */
	/**
	 * Whether this connection has anything worth negotiating.
	 *
	 * A page that has just been answered holds a remote description that
	 * already covers every transceiver it has; `negotiationneeded` firing
	 * after that is the browser reacting to a rollback, not to a change. The
	 * test is deliberately generous — a transceiver with no mid has genuinely
	 * never been sent, and a sender whose track differs from the last one
	 * negotiated is a device change worth carrying — because a missed offer
	 * means a call that never starts.
	 *
	 * The floor is the real protection: no connection offers more than once
	 * per few seconds, whatever the browser says it wants.
	 *
	 * @param {RTCPeerConnection} pc Connection.
	 * @return {boolean}
	 */
	function needsOffer(pc) {
		if (!pc) {
			return false;
		}
		var now = Date.now();
		if (pc.__clLastOfferAt && now - pc.__clLastOfferAt < 4000) {
			return false;
		}
		// Never sent a description: the first offer is always needed.
		if (!pc.currentRemoteDescription && !pc.remoteDescription) {
			pc.__clLastOfferAt = now;
			return true;
		}
		var fresh = false;
		try {
			(pc.getTransceivers ? pc.getTransceivers() : []).forEach(function (t) {
				// A stopped transceiver keeps its null mid for ever. Counting
				// it as "not yet negotiated" made every later call to this
				// function answer yes, which is how the ring survived the
				// first guard: one abandoned orphan was enough to keep the
				// whole connection offering every few seconds all night.
				if ('stopped' === t.currentDirection || 'stopped' === t.direction) {
					return;
				}
				if (t.stopped) {
					return;
				}
				if (null === t.mid || undefined === t.mid || '' === t.mid) {
					fresh = true;
				}
			});
		} catch (e) {}
		// An abandoned offer is a handshake that went nowhere, and the
		// recovery in answerOffer is what retries it. Offering again from
		// here is what turned that recovery into a ring.
		if (!fresh && pc.signalingState === 'stable') {
			return false;
		}
		pc.__clLastOfferAt = now;
		return true;
	}

	function handleSignal(tid, msg) {
		var peer = msg.from;
		if (!peer) {
			return;
		}
		var key = peerKey(peer.kind, peer.id);

		if (msg.kind === 'bye') {
			dropPeer(key);
			return;
		}

		var pc = pcs[key] || makePeer(tid, peer);
		if (!pc) {
				return;
		}

		var data;
		try { data = JSON.parse(msg.data); } catch (e) { return; }

		if (msg.kind === 'offer') {
			// One offer at a time per connection.
			//
			// The poll returns a batch, and a batch can contain the offers a
			// peer sent before it gave up — a reloaded tab leaves its old
			// handshakes in the log, and a first poll asks from the beginning
			// of the line. Answering them all at once is what broke this: each
			// chain rolled the connection back, applied its own offer and then
			// tried to install an answer, while the next chain rolled the state
			// back to `stable` underneath it. Every one of them then threw
			// "Called in wrong state: stable", and the line answered nothing.
			//
			// So offers are queued per peer and run one after another, and the
			// newest wins: an older offer still waiting when a newer one
			// arrives is dropped, because a description that has been
			// superseded describes a connection nobody is keeping.
			pc.__cl.offerQ = pc.__cl.offerQ || { busy: false, next: null, last: '' };

			// Reject a byte-identical repeat outright — the same offer
			// replayed by a poll is the single most common case.
			var sig = typeof msg.data === 'string' ? msg.data : JSON.stringify(data);
			if (sig === pc.__cl.offerQ.last) {
				return;
			}
			pc.__cl.offerQ.last = sig;
			pc.__cl.offerQ.next = data;

			if (pc.__cl.offerQ.busy) {
				return;
			}
			pc.__cl.offerQ.busy = true;

			var drain = function () {
				var work = pc.__cl.offerQ.next;
				pc.__cl.offerQ.next = null;
				if (!work) {
					pc.__cl.offerQ.busy = false;
					return;
				}
				answerOffer(pc, tid, peer, work).then(function () {
					// Only run again as a microtask, so a long queue cannot
					// starve the rest of the page.
					Promise.resolve().then(drain);
				});
			};
			drain();
			return;
		}

		if (msg.kind === 'answer') {
			// An answer only means anything while we are holding an offer of
			// our own. Applied at any other moment it throws and, worse, a
			// stale answer from an earlier round would overwrite the current
			// one and leave the two ends mismatched.
			if (pc.signalingState !== 'have-local-offer') {
				return;
			}
			pc.setRemoteDescription(new RTCSessionDescription(data)).then(function () {
				flushIce(pc);
			}).catch(function () {});
			return;
		}

		if (msg.kind === 'ice') {
			queueIce(pc, data);
		}
	}

	/**
	 * Apply one remote offer and answer it.
	 *
	 * Split out of handleSignal so the queue above can run them one at a time.
	 * Every state read happens here, at the moment the offer is actually
	 * applied, rather than when it was queued — a queued offer's idea of the
	 * connection is out of date by the time it runs.
	 *
	 * @param {Object} pc   Connection.
	 * @param {number} tid  Thread.
	 * @param {Object} peer The far end.
	 * @param {Object} data Their description.
	 * @return {Promise}
	 */
	function answerOffer(pc, tid, peer, data) {
		var key = peerKey(peer.kind, peer.id);
		var run = function () {
			// Already agreeing with exactly this description: answering again
			// would only move the connection backwards.
			if (pc.signalingState === 'stable' && pc.remoteDescription
				&& pc.remoteDescription.type === 'offer') {
				return Promise.resolve();
			}
			// An offer of our own that has been waiting for an answer is not a
			// collision, it is a dead handshake.
			//
			// The glare rule below says the impolite side keeps its offer and
			// drops theirs, which is right for the few milliseconds both ends
			// really do offer at once. But a connection can sit in
			// have-local-offer for ever when no answer ever arrives — the far
			// end reloaded, its tab slept, one of its offers was itself
			// dropped as a collision. Every offer after that is then read as a
			// fresh collision and dropped too, so the side being ignored can
			// never get a call through however many times it answers. That is
			// one-way radio: the end whose offer won can speak, and the end
			// whose offers keep losing is never heard.
			//
			// The bench showed exactly this — the office sent 175 offers and
			// answered none of the agent's. So an offer older than the grace
			// window is abandoned: rolled back to stable, and then their offer
			// is applied on its own merits. A live handshake settles in well
			// under two seconds; six is unambiguous.
			var stuck = false;
			if ('have-local-offer' === pc.signalingState && !pc.__cl.makingOffer()) {
				if (!pc.__cl.offerSince) {
					pc.__cl.offerSince = Date.now();
				} else if (Date.now() - pc.__cl.offerSince > 6000) {
					stuck = true;
				}
			} else if ('have-local-offer' !== pc.signalingState) {
				pc.__cl.offerSince = 0;
			}

			var collision = !stuck && (pc.__cl.makingOffer() || (pc.signalingState !== 'stable' && pc.signalingState !== 'have-remote-offer'));
			var settle = Promise.resolve();
			if (collision) {
				if (!pc.__cl.polite) {
					// Impolite: their offer is the one that loses.
					pc.__cl.setIgnoreOffer(true);
					return Promise.resolve();
				}
				// Polite: give way. The rollback has to complete before their
				// offer is applied — setRemoteDescription on a connection
				// still in have-local-offer throws, and the old code fired
				// both without waiting, so the polite side frequently failed
				// to answer at all and the call never completed.
				try {
					settle = pc.setLocalDescription({ type: 'rollback' }).catch(function () {});
				} catch (e) {
					settle = Promise.resolve();
				}
			} else if (stuck) {
				// Our offer is abandoned. Both ends roll back here, not just
				// the polite one: there is nothing left to negotiate against.
				try {
					settle = pc.setLocalDescription({ type: 'rollback' }).catch(function () {});
				} catch (e) {
					settle = Promise.resolve();
				}
				pc.__cl.offerSince = 0;
				pc.__cl.setIgnoreOffer(false);
			}
			return settle.then(function () {
				return pc.setRemoteDescription(new RTCSessionDescription(data));
			}).then(function () {
				// Candidates that arrived with the offer were held while the
				// description applied; they are valid now and are the ones
				// that carry the path the call will actually use.
				flushIce(pc);
				// The answering side has to claim the right to speak.
				//
				// This is the half of the call that never worked. Applying an
				// offer that asks for audio creates a transceiver on this side
				// with a sender that holds no track, and the browser answers
				// that transceiver `recvonly` — it has nothing to send, so it
				// will not agree to send. replaceTrack on the press comes too
				// late: the direction was fixed the moment the answer was
				// written. The result was one-way audio, every call, whichever
				// end happened to answer.
				//
				// Giving the sender a silent track before answering, and
				// setting the direction explicitly, keeps the answer sendrecv.
				// The real microphone then goes in on the press, which is a
				// pointer swap on an already-negotiated sender.
				var silent = silence();
				// Every audio transceiver that has no mid is one this page
				// built before the offer arrived. The offer's own transceiver
				// is the one with a mid, and it is the only one that carries
				// our voice back. Left in place, the orphans are answered as
				// separate m-lines and the browser gives them `recvonly` —
				// which is harmless in itself but used to be where the whole
				// answer was written, leaving the real one silent. Stopping
				// them keeps the answer to one audio line, and the one line is
				// the one we claim.
				if (pc.getTransceivers) {
					pc.getTransceivers().forEach(function (t) {
						var kind = (t.receiver && t.receiver.track && t.receiver.track.kind)
							|| (t.sender && t.sender.track && t.sender.track.kind) || '';
						if ('audio' !== kind) { return; }
						if (t.mid !== null && t.mid !== undefined && '' !== t.mid) { return; }
						try { t.stop(); } catch (e) {}
					});
				}
				var mine = audioTransceiver(pc);
				if (mine && mine.sender) {
					// A press that happened while the offer was in flight put
					// the microphone on the transceiver that has just been
					// stopped. The live track moves to the carried sender
					// rather than being replaced by silence, so the line comes
					// up already speaking instead of needing to be pressed
					// again.
					var held = (mic && talking) ? mic.getAudioTracks()[0] : null;
					var put = held || silent;
					if (put && (!mine.sender.track || held)) {
						try { mine.sender.replaceTrack(put); } catch (e) {}
					}
					// Ask to send as well as receive, and do it before the
					// answer is written — the answer is what carries the
					// direction to the far end. An answering side left at
					// recvonly hears and can never be heard, whichever end
					// picked up the call.
					//
					// `direction` is writable on an RTCRtpTransceiver, and in
					// every browser tested here a plain assignment is what
					// moves it; some builds also expose setDirection(). Both
					// are tried, because a build that has the method can throw
					// on the property and one without it has nothing else.
					try {
						mine.direction = 'sendrecv';
					} catch (e) {}
					try {
						if ('recvonly' === mine.direction && 'function' === typeof mine.setDirection) {
							mine.setDirection('sendrecv');
						}
					} catch (e) {}
					if ('recvonly' === mine.direction || 'inactive' === mine.direction) {
						if (window.console) {
							console.warn('[cloaklink radio] this browser kept the answer recvonly');
						}
					}
					var k = pc.__cl && pc.__cl.key;
					// The sender map follows the transceiver the offer made,
					// always. A press has to swap the microphone into the one
					// that is actually carried, not into a stopped orphan.
					if (k && mine.sender) {
						senders[k] = mine.sender;
					}
				}
				return pc.createAnswer();
			}).then(function (answer) {
				return pc.setLocalDescription(answer);
			}).then(function () {
				sendSignal(tid, 'answer', peer, pc.localDescription || {});
			}).catch(function () {
				// A failed answer is not fatal: the next offer from the far
				// end is answered on a connection whose state has been read at
				// that moment, which is the whole reason the queue exists.
			});
		};
		return run();
	}

	/**
	 * Hold an ICE candidate until the connection can accept it.
	 *
	 * The poll hands back a batch, and the batch is in the order the other
	 * end wrote it: their candidate, then their offer, or their candidates
	 * alongside an answer still being applied. addIceCandidate on a
	 * connection whose remote description is not set yet rejects with
	 * "Error processing ICE candidate", and the old code swallowed that
	 * rejection — so on a real network, where candidates almost always
	 * arrive before the description finishes applying, every candidate was
	 * thrown away and the two ends never found a working path. The line then
	 * sat in "connecting" forever, which is exactly the reported symptom:
	 * the handshake completes, the microphone opens, and nothing is heard.
	 *
	 * Candidates are buffered on the connection and flushed as soon as it
	 * has a remote description. They are also flushed when a description is
	 * set, from both the offer and answer paths.
	 *
	 * @param {RTCPeerConnection} pc   Connection.
	 * @param {Object}            data Candidate description.
	 */
	function queueIce(pc, data) {
		if (!pc) {
			return;
		}
		if (!pc.__cl) { pc.__cl = {}; }
		if (!pc.__cl.ice) { pc.__cl.ice = []; }
		// A remote description is what makes a candidate meaningful. Without
		// one there is nothing to attach it to, so it waits.
		if (!pc.remoteDescription || !pc.remoteDescription.type) {
			pc.__cl.ice.push(data);
			return;
		}
		flushIce(pc);
		if (!pc.__cl.ice.length) {
			try {
				pc.addIceCandidate(new RTCIceCandidate(data)).catch(function () {});
			} catch (e) {}
			return;
		}
		pc.__cl.ice.push(data);
		flushIce(pc);
	}

	/**
	 * Apply every candidate waiting on a connection.
	 *
	 * Silent on failure on purpose: one stale candidate from a network the
	 * far end has already left must not stop the rest — the live one is
	 * among them and is what actually connects the call.
	 *
	 * @param {RTCPeerConnection} pc Connection.
	 */
	function flushIce(pc) {
		if (!pc || !pc.__cl || !pc.__cl.ice || !pc.__cl.ice.length) {
			return;
		}
		if (!pc.remoteDescription || !pc.remoteDescription.type) {
			return;
		}
		var pending = pc.__cl.ice.splice(0, pc.__cl.ice.length);
		pending.forEach(function (data) {
			try {
				pc.addIceCandidate(new RTCIceCandidate(data)).catch(function () {});
			} catch (e) {}
		});
	}

	/**
	 * Ask the server for anything addressed to us and act on it.
	 */
	function pollSignals() {
		if (!state.liveThreads || !state.liveThreads.length) {
			return;
		}
		if (polling) {
			return;
		}
		polling = true;
		// Always every line, never just the open one.
		//
		// This asked for the active line alone while the cursor that follows
		// the answers is one number for the whole page. Signal ids are
		// allocated across every thread, so a row written on a quiet line has
		// an id below one already written on the busy line — and once the
		// cursor has passed it, `id > after` never returns it again. The two
		// halves contradicted each other and the symptom was a line that went
		// dead at random and came back on a reload.
		//
		// One query for all lines keeps the one cursor honest. It is also what
		// the comment here always claimed the code did: the radio is switched
		// on, not walked into, so a press from somebody whose dock is shut is
		// still heard.
		var tid = 0;
		var body = new FormData();
		body.set('action', 'cloaklink_radio');
		body.set('nonce', cfg.nonce || '');
		if (cfg.where) { body.set('where', cfg.where); }
		body.set('what', 'signal_get');
		body.set('thread', '0');
		body.set('after', String(sigCursor));

		// The signalling request is the one thing every line depends on and the
		// one thing that was never measured: a poll that failed looked exactly
		// like a poll that had nothing to say. These three stamps are read by
		// the diagnostics panel, so "signalling reachable" is a fact with a
		// time on it rather than a hopeful label.
		window.__clRadioPoll = window.__clRadioPoll || { tries: 0, oks: 0, fails: 0, lastOk: 0, lastFail: 0, lastWhy: '' };
		window.__clRadioPoll.tries++;
		fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin', cache: 'no-store' })
			.then(function (r) {
				if (!r.ok) {
					window.__clRadioPoll.fails++;
					window.__clRadioPoll.lastFail = Date.now();
					window.__clRadioPoll.lastWhy = 'HTTP ' + r.status;
				}
				return r.json();
			})
			.then(function (res) {
				polling = false;
				if (res && res.success) {
					window.__clRadioPoll.oks++;
					window.__clRadioPoll.lastOk = Date.now();
				} else if (res && !res.success) {
					window.__clRadioPoll.fails++;
					window.__clRadioPoll.lastFail = Date.now();
					window.__clRadioPoll.lastWhy = 'refused by the server';
				}
				if (!res || !res.success || !res.data) {
					return;
				}
				var batch = res.data.signals || [];
				// The first poll on a page is a place to start from, not a
				// backlog to work through.
				//
				// A cursor of zero asks the server for everything it still
				// holds, which on a line that has been used is every offer,
				// answer and candidate of the last two minutes. Acting on them
				// re-ran a finished handshake: the old offers were re-answered
				// on connections that had already settled, and the live ones
				// were drowned out by the replay. The first batch therefore
				// only moves the cursor past it — unless it genuinely holds
				// something addressed to this page, in which case the newest
				// description is answered and the rest is history.
				// The server answers at most sixty rows. If every one of them
				// is history, one batch is not the whole backlog: asking again
				// from the new cursor walked forward through two hours of a
				// busy line, sixty rows at a time, re-answering handshakes
				// that had settled long ago. The backlog is drained here in
				// however many requests it takes, and nothing is acted on
				// until it is empty.
				if (!sigStarted) {
					batch.forEach(function (msg) {
						sigCursor = Math.max(sigCursor, Number(msg.id) || 0);
					});
					if (batch.length >= 60) {
						// More to come. Poll straight away rather than waiting
						// for the next tick, so priming finishes in one go.
						polling = false;
						window.setTimeout(pollSignals, 0);
						return;
					}
					sigStarted = true;
					// The line may have been pressed while this page was still
					// reading its history. The newest offer is the one that is
					// live; answering it costs one handshake and may be the
					// difference between a radio that works and one that sits
					// in "connecting".
					var newest = null;
					batch.forEach(function (msg) {
						if (msg.kind === 'offer') { newest = msg; }
					});
					if (newest) {
						handleSignal(Number(newest.thread) || tid, newest);
					}
					return;
				}
				batch.forEach(function (msg) {
					sigCursor = Math.max(sigCursor, Number(msg.id) || 0);
					handleSignal(Number(msg.thread) || tid, msg);
				});
			})
			.catch(function () { polling = false; });
	}

	/**
	 * The people on every live line this person has.
	 *
	 * The radio is not a room you walk into; it is a set that is switched on.
	 * Every direct line is listened to at once, so a press from somebody whose
	 * dock has not been opened is still heard. Each entry carries the thread
	 * it belongs to, because a signal has to be answered on the line it came
	 * from.
	 *
	 * @return {Array}
	 */
	function allLivePeers() {
		var out = [];
		(state.liveThreads || []).forEach(function (line) {
			(line.peers || []).forEach(function (peer) {
				out.push({ tid: Number(line.id), peer: peer, key: peerKey(peer.kind, peer.id) });
			});
		});
		return out;
	}

	/**
	 * Listen on every live line.
	 *
	 * Cheap and safe to call repeatedly: a sink is made once per person, and
	 * the poll is a single interval. It runs without the microphone, so the
	 * page never asks for one on load — the browser would refuse that anyway
	 * — and the line still receives the moment somebody presses.
	 */
	function listen() {
		var peers = allLivePeers();
		peers.forEach(function (p) { ensureAudioSink(p.key); });
		if (!peers.length) {
			return;
		}
		startPolling();
		preconnect();
	}

	/**
	 * Run the handshake poll, fast while anything is still unsettled.
	 *
	 * A single interval was either fast enough for the handshake and wasteful
	 * for the other 99% of the time, or cheap and slow at the one moment
	 * speed matters. It is two cadences now: 200ms while any connection is
	 * still trying to come up, and the operator's chosen interval once every
	 * line is connected. The fast phase ends the moment the last peer
	 * reaches `connected`, not on a timer, so a quiet desk is back to one
	 * request a second almost immediately.
	 */
	function startPolling() {
		if (pollTimer) {
			return;
		}
		pollSignals();
		pollTimer = window.setInterval(pollSignals, RC.pollMs);
		if (!burstTimer) {
			burstTimer = window.setInterval(function () {
				if (!needsSpeed()) {
					return;
				}
				pollSignals();
			}, 200);
		}
	}

	/**
	 * Is anything still trying to connect?
	 *
	 * @return {boolean}
	 */
	function needsSpeed() {
		var keys = Object.keys(pcs);
		if (!keys.length) {
			return false;
		}
		// The fast poll has a deadline as well as a condition. Without one, a
		// desk whose only other person is asleep leaves a connection that can
		// never settle — there is nobody to answer — and the burst runs all
		// night at five requests a second. Twenty seconds is several times
		// what a real handshake needs on a bad network.
		if (!burstUntil) {
			return false;
		}
		if (Date.now() > burstUntil) {
			burstUntil = 0;
			return false;
		}
		var pending = false;
		keys.forEach(function (k) {
			var pc = pcs[k];
			if (!pc) {
				return;
			}
			var st = pc.connectionState;
			// New connections, ones still gathering, and ones that have
			// dropped all want a fast poll. A connected line does not.
			if (st !== 'connected' && st !== 'closed') {
				pending = true;
			}
		});
		return pending;
	}

	/**
	 * Ask for fast polling for a while, because something is connecting.
	 */
	function hurry() {
		burstUntil = Date.now() + 20000;
	}

	/**
	 * Build every connection before anybody presses anything.
	 *
	 * This is the difference between a radio and a telephone. The whole
	 * handshake — offer, answer, candidates, a route found between two
	 * networks — used to happen when the key went down, so the first second
	 * or two of speech was spent connecting and the far end heard nothing
	 * until it had settled. That is the delay, and no amount of tuning the
	 * poll makes it go away, because the work itself takes time.
	 *
	 * So the connections are built on page load instead, with a sender that
	 * carries no track. When the key goes down, the microphone is dropped
	 * into a sender that is already negotiated and already connected: the
	 * first packet leaves on the same press. Nothing is transmitted until
	 * then, because a sender with no track sends nothing and a track that is
	 * disabled is silent anyway.
	 *
	 * No microphone is requested here. A browser refuses getUserMedia without
	 * a gesture, and a page that asks before a finger has touched it is a
	 * page that gets a permanent refusal on some phones. The connection does
	 * not need the microphone: it needs a transceiver, which is a promise to
	 * send audio, not the audio itself.
	 */
	function preconnect() {
		if (!RC.live) {
			return;
		}
		var peers = allLivePeers();
		if (!peers.length) {
			return;
		}
		var built = 0;
		peers.forEach(function (p) {
			try {
				if (makePeer(p.tid, p.peer)) {
					built++;
				}
			} catch (e) {}
		});
		if (built) {
			// A handshake has to be carried while it is happening. listen()
			// starts the poll already; this covers the case where preconnect
			// runs before it, which would otherwise build the pipes and leave
			// nobody to answer the offer on them.
			startPolling();
			hurry();
		}
	}

	/**
	 * Stop listening entirely.
	 *
	 * Only for a page that is going away. Closing the dock is not this: a
	 * radio left on the desk is still a radio.
	 */
	function stopListening() {
		if (pollTimer) {
			window.clearInterval(pollTimer);
			pollTimer = null;
		}
		if (burstTimer) {
			window.clearInterval(burstTimer);
			burstTimer = null;
		}
	}
	// Note: the connections are left open here on purpose. This runs on
	// unload as a courtesy, not as a teardown; the far end drops them itself
	// when it stops polling, and closing them first would race the goodbye.
	

	/**
	 * Start the radio on the open line: microphone on, one connection per
	 * other person, and a poll for their handshakes.
	 */
	function joinLive() {
		if (!state.active || !state.live) {
			return;
		}
		// The cursor is deliberately not reset. It used to be, and the effect
		// was that every join re-read the last minute of handshake — stale
		// offers and answers from a conversation that had already settled.
		// Replayed offers put both ends into glare over a call they had
		// already agreed, which is the other half of why the radio went
		// quiet after anything was touched. The cursor is a position in the
		// signal log, not a per-line counter, so it survives a line change.
		var go = function () {
			openMic().then(function (stream) {
				// A sink per person on every line, made now rather than when
				// their voice arrives, so there is something for the next tap
				// anywhere on the page to unlock. A phone will not let an
				// element created after the gesture play a stream.
				//
				// All of it happens with or without a microphone. Listening
				// never needed one, and the old early return here meant a
				// browser that refused the microphone built no connection at
				// all — so the one person who could not speak could not hear
				// either, and the whole set looked dead instead of half-deaf.
				listen();
				unlockAudio();
				// Every pipe is built, and none of them carries a voice until
				// somebody speaks on it.
				//
				// Joining used to hand the microphone to every line at once,
				// which meant an operator who pressed once was heard by all
				// five desks they had a line to. A desk is not a party line;
				// the press decides which line is open, and connectLine() is
				// what raises it.
				if ('handsfree' === RC.mode && stream) {
					// Hands-free is a line that is simply open: the microphone
					// is raised on the line in the dock as the connection is
					// built, and the key only closes it. The far end hears the
					// room, which is the point of the mode.
					connectLine(stream, state.active);
					mic.getAudioTracks().forEach(function (t) { t.enabled = true; });
					talking = true;
					setTalk('tx', 'Open line');
					setKeyLabel('On air');
					return;
				}
				connectAll(null);
				if (!stream) {
					setTalk('idle', 'Microphone is blocked — you can still hear them');
					setKeyLabel('Listen only');
					return;
				}
				setTalk('idle', 'Hold to talk');
			});
		};

		// Who I am has to be settled before any connection exists, because
		// the two ends decide between them which one backs off, and they can
		// only agree if both know their own key. The feed normally carries it;
		// a press before the feed lands is what this covers.
		if (state.me && state.me.kind) {
			go();
			return;
		}
		post({ what: 'feed' }).then(function (res) {
			if (res && res.success && res.data && res.data.me) {
				state.me = res.data.me;
			}
			go();
		}).catch(go);
	}

	/**
	 * Build or refresh a connection to everybody on every live line.
	 *
	 * Both sides do this and both sides offer; see makePeer for why the old
	 * rule that only one of them may offer left the line silent. Attaching a
	 * microphone to a connection that already exists raises its
	 * negotiationneeded, which is what carries the track across without a
	 * fresh handshake by hand.
	 *
	 * @param {MediaStream} stream Microphone.
	 */
	function connectAll(stream) {
		allLivePeers().forEach(function (p) {
			var pc = makePeer(p.tid, p.peer);
			// replaceTrack on an already-negotiated sender. This is why a
			// press is instant: there is no offer, no answer and no candidate
			// exchange here, only a pointer swap on a pipe that is already
			// open and already carrying a route.
			attachMic(pc, p.key, stream);
		});
	}

	/**
	 * Raise our voice on one line, and only there.
	 *
	 * A press used to reach every peer on every live line, because the pipes
	 * are all built at page load and each of them was handed the microphone.
	 * An operator with five lines open was therefore heard by all five desks
	 * at once — a privacy fault on a case desk, and the reason a test of "one
	 * line at a time" behaved differently depending on who else happened to be
	 * listening.
	 *
	 * The line the dock is on, or the one the key was pressed for, is the one
	 * that speaks. Everything else stays connected and silent, which is what
	 * it was doing anyway.
	 *
	 * @param {MediaStream} stream Microphone, or null for listen-only.
	 * @param {number}      tid    Line to speak on.
	 */
	function connectLine(stream, tid) {
		var wanted = Number(tid) || 0;
		if ( ! wanted ) {
			// No line is named, so there is no line to speak on. The old
			// fallback here was "speak on all of them", which is the one
			// answer that must never be given on a desk.
			return;
		}
		var spoke = false;
		allLivePeers().forEach(function (p) {
			var pc = makePeer(p.tid, p.peer);
			if (Number(p.tid) === wanted) {
				attachMic(pc, p.key, stream);
				spoke = true;
				return;
			}
			// A line that is not this one keeps its silent track. Dropping
			// the microphone from it is what makes the privacy real rather
			// than cosmetic: even a stuck `enabled` flag then carries
			// nothing, because there is no track to carry.
			// Only if there is a silent track to put back. replaceTrack(null)
			// empties the sender, and an emptied sender raises negotiationneeded
			// — which re-opens the direction the answer just settled and can
			// quietly turn a working line recvonly again.
			var quiet = silence();
			if (quiet && senders[p.key]) {
				try { senders[p.key].replaceTrack(quiet).catch(function () {}); } catch (e) {}
			}
		});
		if ( ! spoke ) {
			// The chosen line has nobody on it. Talking to the other lines
			// instead would be heard by people this person was not addressing.
			setTalk('idle', 'Nobody is on that line');
		}
	}

	/**
	 * Leave the line.
	 *
	 * The connections are deliberately not dropped: another line may be
	 * carrying a call, and the whole point of an always-on set is that the
	 * next press is heard. Only the microphone is released.
	 */
	function leaveLive() {
		talking = false;
		micRelease();
	}

	/**
	 * Raise or drop our outgoing voice.
	 *
	 * This is the whole of push-to-talk: the track is always there, and
	 * `enabled` is what decides whether the far end hears anything at all.
	 *
	 * @param {boolean} on Whether the button is held.
	 */
	function micRelease() {
		if (mic) {
			mic.getAudioTracks().forEach(function (t) { t.enabled = false; });
		}
		// A real set says the line closed. Off is silence, which is what a
		// person wearing a headset all shift wants.
		if (talking && RC.beepEnd) {
			play({ wave: 'sine', notes: [523.25], gap: 0.08 });
		}
		talking = false;
		if (talkTimer) { talkTimer.hidden = true; }
		stopTicker();
		stopMeter();
		[micEl(), keyEl()].forEach(function (el) {
			if (el) { el.classList.remove('is-on'); }
		});
		setKeyLabel('Hold to talk');
		var stageT = document.getElementById('cl-radio-stage-t');
		if (stageT) { stageT.textContent = 'Hold the button. They hear you as you speak.'; }
		setTalk('idle', 'Hold to talk');
	}

	function micEl() {
		return document.getElementById('cl-radio-mic');
	}

	function keyEl() {
		return document.getElementById('cl-radio-key');
	}

	function setKeyLabel(text) {
		var t = document.getElementById('cl-radio-key-t');
		if (t) { t.textContent = text; }
	}

	function micHold() {
		if (!mic) {
			return;
		}
		mic.getAudioTracks().forEach(function (t) { t.enabled = true; });
		talking = true;
		setTalk('tx', 'On air — you are talking');
		[micEl(), keyEl()].forEach(function (el) {
			if (el) { el.classList.add('is-on'); }
		});
		setKeyLabel('On air');
		var stageT = document.getElementById('cl-radio-stage-t');
		if (stageT) { stageT.textContent = 'You are on air'; }
		startTicker();
		startMeter();
	}

	// A live level meter, so the person talking can see that sound is actually
	// leaving. It reads the same stream that is being transmitted.
	var meterCtx = null;
	var meterRaf = 0;

	function startMeter() {
		var bar = document.getElementById('cl-radio-meter');
		if (!bar || !mic) {
			return;
		}
		try {
			if (!meterCtx) {
				var C = window.AudioContext || window.webkitAudioContext;
				meterCtx = new C();
			}
			var src = meterCtx.createMediaStreamSource(mic);
			var analyser = meterCtx.createAnalyser();
			analyser.fftSize = 256;
			src.connect(analyser);
			var data = new Uint8Array(analyser.frequencyBinCount);
			var loop = function () {
				analyser.getByteFrequencyData(data);
				var sum = 0;
				for (var i = 0; i < data.length; i++) { sum += data[i]; }
				var level = Math.min(100, Math.round((sum / data.length) * 3.2));
				bar.style.width = level + '%';
				if (talking) {
					meterRaf = window.requestAnimationFrame(loop);
				}
			};
			stopMeter();
			meterRaf = window.requestAnimationFrame(loop);
		} catch (e) {}
	}

	function stopMeter() {
		if (meterRaf) {
			window.cancelAnimationFrame(meterRaf);
			meterRaf = 0;
		}
		var bar = document.getElementById('cl-radio-meter');
		if (bar) {
			bar.style.width = '0%';
		}
	}

	/* ---- The line, measured ----
	 *
	 * Everything here reads a value that already exists — the browser's own
	 * getStats() report, the connection's own state, the microphone track's
	 * own settings, and the stamps the signalling poll writes. Nothing is
	 * estimated and nothing is smoothed.
	 *
	 * The rule the panel is built on: a number that has not been measured is
	 * shown as "—", never as zero. A zero is a measurement and it means
	 * something; a dash means nobody has looked yet. Confusing the two is how
	 * a diagnostics screen ends up reassuring somebody about a line it has
	 * never inspected.
	 */

	/** A byte count as the two units a person reads. */
	function fmtBytes(n) {
		n = Number(n) || 0;
		if (n < 1024) { return n + ' B'; }
		if (n < 1024 * 1024) { return (n / 1024).toFixed(1) + ' KB'; }
		return (n / (1024 * 1024)).toFixed(2) + ' MB';
	}

	/** A millisecond figure, or a dash when there is no measurement. */
	function fmtMs(v) {
		if (v === null || v === undefined || !isFinite(v)) { return null; }
		return Math.round(Number(v)) + ' ms';
	}

	/** The first peer with a live connection on the open line. */
	function diagPeer() {
		var keys = Object.keys(pcs);
		var fallback = null;
		for (var i = 0; i < keys.length; i++) {
			var pc = pcs[keys[i]];
			if (!pc) { continue; }
			if (!fallback) { fallback = pc; }
			if (pc.connectionState === 'connected' || pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') {
				return pc;
			}
		}
		return fallback;
	}

	/** Put one value in one row, marking rows that have no measurement. */
	function diagSet(id, text) {
		var el = document.getElementById(id);
		if (!el) { return; }
		var empty = (text === null || text === undefined || text === '');
		el.textContent = empty ? '—' : String(text);
		el.classList.toggle('is-unmeasured', empty);
	}

	/**
	 * Read the line and fill the panel.
	 *
	 * Returns the same facts it printed, so the copy button and any future
	 * caller get exactly what is on screen rather than re-reading a
	 * connection that has moved on.
	 */
	function diagMeasure() {
		var out = {
			signal: '',
			ice: '',
			cand: '',
			route: '',
			codec: '',
			bytes: '',
			rtt: '',
			loss: '',
			jitter: '',
			mic: ''
		};

		// Signalling: when the last poll succeeded, and how many have failed
		// since. This is the one row that can be answered with no peer at all,
		// which matters because "no peer" and "cannot reach the server" look
		// identical from the outside.
		var P = window.__clRadioPoll;
		if (P && P.tries) {
			if (P.lastOk) {
				var ago = Math.max(0, Math.round((Date.now() - P.lastOk) / 1000));
				out.signal = 'Last answer ' + ago + 's ago, ' + P.oks + ' of ' + P.tries + ' requests answered';
				if (P.fails) {
					out.signal += '; ' + P.fails + ' failed' + (P.lastWhy ? ' (' + P.lastWhy + ')' : '');
				}
			} else {
				out.signal = 'No answer yet — ' + P.tries + ' asked, ' + P.fails + ' failed' + (P.lastWhy ? ' (' + P.lastWhy + ')' : '');
			}
		} else {
			out.signal = 'Not asked yet — no line has polled on this page';
		}

		// The microphone is measured even with no peer: a track that is muted,
		// ended or reporting zero sample rate is the commonest reason a person
		// is "on air" and inaudible.
		if (mic && mic.getAudioTracks && mic.getAudioTracks().length) {
			var tr = mic.getAudioTracks()[0];
			var st = tr.getSettings ? tr.getSettings() : {};
			var bits = [];
			bits.push(tr.readyState === 'live' ? 'live' : 'ended');
			bits.push(tr.enabled ? 'enabled' : 'muted by the panel');
			if (st.sampleRate) { bits.push(st.sampleRate + ' Hz'); }
			if (st.channelCount) { bits.push(st.channelCount === 1 ? 'mono' : 'stereo'); }
			if (tr.label) { bits.push(tr.label); }
			out.mic = bits.join(' · ');
		} else {
			out.mic = 'Not open — nothing has asked for it on this page';
		}

		var pc = diagPeer();
		if (!pc) {
			out.ice = 'No peer connection on this line yet';
			diagPaint(out);
			return out;
		}

		out.ice = String(pc.iceConnectionState || pc.connectionState || 'unknown');
		if (pc.connectionState && pc.connectionState !== pc.iceConnectionState) {
			out.ice += ' (connection ' + pc.connectionState + ')';
		}

		if (pc.getStats) {
			pc.getStats(null).then(function (report) {
				var pair = null;
				var local = null;
				var remote = null;
				var inbound = null;
				var remoteIn = null;
				var localCands = 0;
				var remoteCands = 0;
				var codec = null;

				report.forEach(function (r) {
					if ('candidate-pair' === r.type) {
						// Prefer the pair that actually succeeded; a pair in
						// "in-progress" has no bytes and would read as a dead
						// line.
						if ('succeeded' === r.state) { pair = r; }
					}
					if ('local-candidate' === r.type) { localCands++; }
					if ('remote-candidate' === r.type) { remoteCands++; }
					if ('inbound-rtp' === r.type && 'audio' === r.kind) { inbound = r; }
					if ('remote-inbound-rtp' === r.type && 'audio' === r.kind) { remoteIn = r; }
					if ('codec' === r.type && 'audio' === r.mimeType.split('/')[0] && !codec) { codec = r; }
				});

				if (pair) {
					report.forEach(function (r) {
						if ('local-candidate' === r.type && r.id === pair.localCandidateId) { local = r; }
						if ('remote-candidate' === r.type && r.id === pair.remoteCandidateId) { remote = r; }
					});
					var lk = local ? String(local.candidateType || '?') : '?';
					var rk = remote ? String(remote.candidateType || '?') : '?';
					out.route = lk + ' → ' + rk;
					if (lk === 'relay' || rk === 'relay') {
						out.route += ' (through the relay)';
					} else if (lk === 'host' || lk === 'srflx' || lk === 'prflx' || rk === 'host' || rk === 'srflx' || rk === 'prflx') {
						out.route += ' (direct)';
					}
				} else {
					out.route = 'No candidate pair has succeeded yet';
				}

				out.cand = localCands + ' local, ' + remoteCands + ' remote';

				if (inbound) {
					var bytes = Number(inbound.bytesReceived) || 0;
					out.bytes = fmtBytes(bytes);
					if (Number(inbound.packetsReceived) > 0) {
						out.bytes += ' in ' + inbound.packetsReceived + ' packets';
					}
					// Jitter is reported by the browser in seconds.
					if (inbound.jitter !== undefined && inbound.jitter !== null) {
						out.jitter = (Number(inbound.jitter) * 1000).toFixed(1) + ' ms';
					}
					// Loss is only knowable from the far end's report; the
					// local inbound stream does not carry it.
					if (inbound.packetsLost !== undefined && inbound.packetsLost !== null && Number(inbound.packetsLost) >= 0) {
						var recv = Number(inbound.packetsReceived) || 0;
						var lost = Number(inbound.packetsLost) || 0;
						var totalPk = recv + lost;
						out.loss = totalPk
							? lost + ' of ' + totalPk + ' (' + ((lost / totalPk) * 100).toFixed(1) + '%)'
							: 'None measured yet';
					}
					if (inbound.codecId) {
						report.forEach(function (r) {
							if (r.id === inbound.codecId && 'codec' === r.type) { codec = r; }
						});
					}
				} else {
					out.bytes = 'Nothing received yet on this line';
				}

				if (remoteIn && remoteIn.roundTripTime !== undefined) {
					out.rtt = fmtMs(Number(remoteIn.roundTripTime) * 1000);
				} else if (pair && pair.currentRoundTripTime !== undefined) {
					out.rtt = fmtMs(Number(pair.currentRoundTripTime) * 1000);
				} else if (local && local.roundTripTime !== undefined) {
					out.rtt = fmtMs(Number(local.roundTripTime) * 1000);
				} else {
					out.rtt = 'Not reported by this browser';
				}

				if (codec && codec.mimeType) {
					out.codec = String(codec.mimeType).replace('audio/', '');
					if (codec.clockRate) { out.codec += ' · ' + codec.clockRate + ' Hz'; }
				} else {
					out.codec = 'Not negotiated yet';
				}

				diagPaint(out);
			}).catch(function () {
				out.ice = out.ice + ' (the browser refused a stats report)';
				diagPaint(out);
			});
			return out;
		}

		out.ice += ' (this browser has no getStats)';
		diagPaint(out);
		return out;
	}

	/** Print one measurement set. */
	function diagPaint(out) {
		diagSet('cl-radio-d-signal', out.signal);
		diagSet('cl-radio-d-ice', out.ice);
		diagSet('cl-radio-d-cand', out.cand);
		diagSet('cl-radio-d-route', out.route);
		diagSet('cl-radio-d-codec', out.codec);
		diagSet('cl-radio-d-bytes', out.bytes);
		diagSet('cl-radio-d-rtt', out.rtt);
		diagSet('cl-radio-d-loss', out.loss);
		diagSet('cl-radio-d-jitter', out.jitter);
		diagSet('cl-radio-d-mic', out.mic);

		// The one-line verdict in the summary, in plain words.
		var badge = document.getElementById('cl-radio-diag-state');
		if (badge) {
			var live = out.ice && out.ice.indexOf('connected') === 0;
			badge.textContent = live ? 'connected' : (out.ice ? String(out.ice).split(' ')[0] : '—');
			badge.className = 'cl-radio__diag-state' + (live ? ' is-good' : '');
		}
		window.__clRadioDiag = out;
	}

	/** Open the panel, measure, and keep measuring while it is open. */
	function diagWire() {
		var box = document.getElementById('cl-radio-diag');
		if (!box) {
			return;
		}
		var again = document.getElementById('cl-radio-diag-refresh');
		var copyBtn = document.getElementById('cl-radio-diag-copy');
		var msg = document.getElementById('cl-radio-diag-msg');
		var timer = 0;

		var tick = function () {
			diagMeasure();
		};

		box.addEventListener('toggle', function () {
			if (box.open) {
				tick();
				// Re-measure every two seconds while it is open: a route that
				// is failing shows it in the byte count going flat, and a
				// person watching wants to see that as it happens.
				if (!timer) {
					timer = window.setInterval(tick, 2000);
				}
			} else if (timer) {
				window.clearInterval(timer);
				timer = 0;
			}
		});

		if (again) {
			again.addEventListener('click', function () {
				tick();
				if (msg) {
					msg.textContent = 'Measured just now.';
					window.setTimeout(function () { msg.textContent = ''; }, 2500);
				}
			});
		}

		if (copyBtn) {
			copyBtn.addEventListener('click', function () {
				var d = window.__clRadioDiag || {};
				var lines = [
					'Credit Control — walkie-talkie line',
					'when: ' + new Date().toISOString(),
					'page: ' + location.href,
					'line: ' + (state.activeInfo && state.activeInfo.name ? state.activeInfo.name : '(none open)'),
					'signalling: ' + (d.signal || '—'),
					'ice: ' + (d.ice || '—'),
					'candidates: ' + (d.cand || '—'),
					'route: ' + (d.route || '—'),
					'codec: ' + (d.codec || '—'),
					'received: ' + (d.bytes || '—'),
					'round trip: ' + (d.rtt || '—'),
					'loss: ' + (d.loss || '—'),
					'jitter: ' + (d.jitter || '—'),
					'microphone: ' + (d.mic || '—')
				];
				var text = lines.join('\n');
				var done = function (ok) {
					if (msg) {
						msg.textContent = ok ? 'Copied — paste it into the support note.' : 'Could not copy. Select the text above and copy it by hand.';
						window.setTimeout(function () { msg.textContent = ''; }, 3500);
					}
				};
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(text).then(function () { done(true); }).catch(function () { done(false); });
				} else {
					done(false);
				}
			});
		}
	}

	/**
	 * Start sending on the open line, opening the microphone if needed.
	 *
	 * The guard matters: the first press shows the browser's permission
	 * dialog, and if the finger comes off while it is up there is nothing to
	 * transmit and nothing should be left running.
	 */
	function beginTransmit() {
		if (!liveActive()) {
			setTalk('idle', 'Pick a line first');
			holding = false;
			return;
		}
		if (mic) {
			connectLine(mic, state.active);
			micHold();
			return;
		}
		openMic().then(function (stream) {
			// The pipes are built either way, and only one of them is ever
			// given a voice.
			//
			// This is the press path, and the press names a line. Handing the
			// microphone to connectAll() here — which is what it did first —
			// put it on every peer on every line, and the connectLine() call
			// under it then did nothing but repeat the work on the one line
			// that mattered. That ordering made the privacy fix invisible.
			if (!stream) {
				connectAll(null);
				holding = false;
				if (window.console) { console.warn('[cloaklink radio] no microphone — listening only'); }
				setTalk('idle', 'Microphone is blocked — you can still hear them');
				setKeyLabel('Listen only');
				return;
			}
			if (!holding) {
				connectAll(null);
				setTalk('idle', 'Hold to talk');
				return;
			}
			connectLine(stream, state.active);
			micHold();
		});
	}

	/**
	 * With the dock shut there is no line on screen, so one is chosen.
	 *
	 * The operator gets the line they last used. An agent has exactly one —
	 * the office — so for them there is nothing to choose and the radio works
	 * from the first press on any page.
	 *
	 * @param {Function} done Called with true when a line is open.
	 */
	function autoLine(done) {
		// Already open in the dock.
		if (state.active && state.live) {
			done(true);
			return;
		}

		var pick = function (thread) {
			if (!thread) {
				done(false);
				setTalk('idle', 'No line to talk on');
				setKeyLabel('No line');
				return;
			}
			state.active = Number(thread.id);
			state.live = !!thread.live;
			state.livePeers = thread.peers || [];
			state.activeInfo = thread;
			if (!state.liveThreads || !state.liveThreads.length) {
				state.liveThreads = [{ id: Number(thread.id), name: thread.name || '', tone: thread.tone || '', peers: thread.peers || [] }];
			}
			setKeyLabel('To ' + (thread.name || 'the line'));
			joinLive();
			done(!!thread.live);
		};

		// The server decides which line this is: the operator's last one, or
		// the first staffed desk, or an agent's single line to the office.
		// Asking it is one request and it answers with the full view — the
		// live flag and the peers — which a plain list of threads does not
		// carry.
		// The line is asked for before the microphone is judged. It used to be
		// the other way round, so a refused microphone left the key saying so
		// and never reaching the server — no line, no connection, no poll,
		// nothing to hear. The line is real even when the microphone is not,
		// and joinLive() asks for the microphone itself.
		post({ what: 'open', who_kind: '', who_id: 0 }).then(function (res) {
			if (!res || !res.success || !res.data) {
				done(false);
				setTalk('idle', res && res.data && res.data.message ? res.data.message : 'No line to talk on');
				setKeyLabel('No line');
				return;
			}
			state.me = res.data.me || state.me;
			state.isOffice = !!res.data.isOffice;
			pick(res.data.thread);
		}).catch(function (e) {
			if (window.console) { console.warn('[cloaklink radio] open from key failed', e); }
			done(false);
			setTalk('idle', 'No line to talk on');
			setKeyLabel('No line');
		});
	}

	/**
	 * Open the direct line and return it.
	 *
	 * @param {Function} done Called with the thread, or null.
	 */
	function openLine(done) {
		post({ what: 'open', who_kind: '', who_id: 0 }).then(function (res) {
			if (res && res.success && res.data && res.data.thread) {
				done(res.data.thread);
				return;
			}
			done(null);
		}).catch(function () { done(null); });
	}

	/**
	 * Bind press-and-hold to one button.
	 *
	 * Both the dock's circle and the floating key use this, so the two can
	 * never drift apart: the same gesture, the same guard against the
	 * permission dialog outliving the press, the same release.
	 *
	 * @param {Element} btn The button.
	 */
	function bindKey(btn) {
		if (!btn) {
			return;
		}
		var press = function (ev) {
			if (ev && ev.button !== undefined && ev.button > 0) {
				return;
			}
			if (ev && ev.preventDefault) { ev.preventDefault(); }
			// A finger is on the button right now, which is the one moment
			// iOS and Android allow sound to start. Unlock before anything
			// is transmitted so the reply can be heard when it arrives.
			unlockAudio();
			// A latched line: the second press closes it, exactly as a set
			// with a switch does. It is checked before the on-air guard, or
			// there would be no way to switch off.
			if ('latch' === RC.mode && talking) {
				micRelease();
				return;
			}
			if (talking) {
				return;
			}
			// No line is open yet: pick the one the operator last used, or the
			// only line an agent has. The radio still works with the dock shut.
			if (!liveActive()) {
				autoLine(function (ok) {
					if (!ok) {
						return;
					}
					holding = true;
					beginTransmit();
				});
				return;
			}
			holding = true;
			beginTransmit();
		};

		var release = function () {
			if (!holding && !talking) {
				return;
			}
			holding = false;
			// In latch mode letting go is not the end of the sentence; the
			// next press is. Hands-free never lets go at all while the line
			// is open.
			if ('latch' === RC.mode || 'handsfree' === RC.mode) {
				return;
			}
			micRelease();
		};

		// The press is taken on pointerdown, and the release on pointerup —
		// but a phone is not a mouse. Three things differ, and each one of
		// them turned a press into a line that either would not start or
		// would not stop:
		//
		//   - `pointerdown` arrives for a touch, a mouse and a stylus alike,
		//     which is why it is the only press binding; a second touch
		//     binding would fire twice and close what the first opened.
		//   - The browser fires `pointercancel` the moment it decides the
		//     gesture is a scroll. On a phone that happens as soon as the
		//     finger moves a millimetre, so a press ended by itself before
		//     the sentence started. `touch-action: none` on the button (in
		//     the sheet) is what stops the browser claiming the gesture, and
		//     this cancelling is only a real release when the pointer that
		//     was cancelled is the one that pressed.
		//   - `touchstart` is used only to unlock audio, because on iOS the
		//     permission to play has to be taken inside a genuine touch
		//     event and not every pointer event counts as one.
		if (btn.addEventListener && 'ontouchstart' in window) {
			btn.addEventListener('touchstart', function () {
				unlockAudio();
			}, { passive: true });
		}
		btn.addEventListener('pointerdown', press);
		// Keep the press alive across the gesture the browser was about to
		// take. Without this a long press on a phone raises the context menu
		// or the text magnifier mid-sentence.
		btn.addEventListener('touchmove', function (ev) {
			if (ev.cancelable) { ev.preventDefault(); }
		}, { passive: false });
		btn.addEventListener('keydown', function (ev) {
			if (ev.key === ' ' || ev.key === 'Enter') {
				if (!ev.repeat) { press(ev); }
				ev.preventDefault();
			}
		});
		btn.addEventListener('keyup', function (ev) {
			if (ev.key === ' ' || ev.key === 'Enter') {
				ev.preventDefault();
				release();
			}
		});
		btn.addEventListener('contextmenu', function (ev) { ev.preventDefault(); });
		btn.addEventListener('dragstart', function (ev) { ev.preventDefault(); });

		// The window listeners are shared, so they are added once below.
		pressKey = press;
		releaseKey = release;
	}

	var pressKey = null;
	var releaseKey = null;
	// The pointer that opened the line. A phone can have four fingers on the
	// glass at once, and a `pointerup` from any of them used to end the
	// transmission — so lifting a thumb from the scroll position while the
	// other hand held the key cut the sentence off.
	var pressPointer = null;

	bindKey(talkBtn);
	bindKey(keyEl());

	if (pressKey) {
		window.addEventListener('pointerdown', function (ev) {
			if (ev.target && ev.target.closest && ev.target.closest('.cl-radio__key, .cl-radio__mic')) {
				pressPointer = ev.pointerId;
			}
		}, true);
		var maybeRelease = function (ev) {
			if (null === pressPointer || ev.pointerId === pressPointer) {
				pressPointer = null;
				if (releaseKey) { releaseKey(); }
			}
		};
		window.addEventListener('pointerup', maybeRelease);
		window.addEventListener('pointercancel', maybeRelease);
	}

	// A phone can also end the press by leaving the page: a call arriving, the
	// screen locking, the app going to the background. That is a release, and
	// the radio must not be left keyed into a room nobody is in.
	document.addEventListener('visibilitychange', function () {
		if (document.hidden) {
			holding = false;
			if (releaseKey) { releaseKey(); }
		}
	});

	// Leaving the tab, or the dock, stops transmitting. A radio must never be
	// live when nobody is holding it.
	window.addEventListener('blur', function () {
		holding = false;
		// Releasing on blur is always right — a keyed radio on a tab nobody
		// is looking at is a room that does not know it is being heard. The
		// microphone is dropped only when the operator asked for that, since
		// the track stays attached either way and `enabled` is what matters.
		micRelease();
		if (RC.muteBlur && mic) {
			mic.getAudioTracks().forEach(function (t) { t.enabled = false; });
		}
	});

	/* ---- Sounds ---- */

	function toneOptions(map, selected) {
		var out = '';
		Object.keys(map).forEach(function (k) {
			out += '<option value="' + k + '"' + (k === selected ? ' selected' : '') + '>' + map[k].label + '</option>';
		});
		return out;
	}

	function drawToneSettings() {
		var tones = cfg.radioTones || {};
		state.toneMap = tones;
		var sel = document.getElementById('cl-radio-deftone');
		if (sel && !sel.options.length) {
			sel.innerHTML = toneOptions(tones, cfg.radioTone || 'chirp');
			sel.addEventListener('change', function () {
				post({ what: 'tone_set', tone: sel.value }).then(function () {
					play(tones[sel.value]);
					fetchFeed();
				});
			});
		}
		var holder = document.getElementById('cl-radio-roleroster');
		if (!holder) {
			return;
		}
		holder.innerHTML = '';
		if (!state.roster.length) {
			return;
		}
		state.roster.forEach(function (person) {
			var row = document.createElement('div');
			row.className = 'cl-radio__tone';
			var nm = document.createElement('b');
			nm.textContent = person.name;
			var selOne = document.createElement('select');
			selOne.className = 'cl-radio__sel cl-radio__sel--sm';
			selOne.innerHTML = toneOptions(tones, person.tone && person.tone.key ? person.tone.key : (cfg.radioTone || 'chirp'));
			selOne.addEventListener('change', function () {
				post({ what: 'tone_set', tone: selOne.value, agent: person.id }).then(function () {
					play(tones[selOne.value]);
					fetchFeed();
				});
			});
			var tryBtn = document.createElement('button');
			tryBtn.type = 'button';
			tryBtn.className = 'cl-radio__tbtn';
			tryBtn.textContent = 'Try';
			tryBtn.addEventListener('click', function () { play(tones[selOne.value]); });
			row.appendChild(nm);
			row.appendChild(selOne);
			row.appendChild(tryBtn);
			holder.appendChild(row);
		});
	}

	/* ---- Groups ---- */

	function openGroupModal(threadId) {
		state.editing = Number(threadId) || 0;
		var title = document.getElementById('cl-radio-mtitle');
		var nameEl = document.getElementById('cl-radio-gname');
		var toneEl = document.getElementById('cl-radio-gtone');
		var people = document.getElementById('cl-radio-gpeople');
		var tones = cfg.radioTones || {};

		var current = null;
		if (state.editing) {
			state.groups.forEach(function (g) { if (Number(g.id) === state.editing) { current = g; } });
		}
		if (title) { title.textContent = state.editing ? 'Edit group' : 'New group'; }
		if (nameEl) { nameEl.value = current ? current.name : ''; }
		if (toneEl) {
			toneEl.innerHTML = toneOptions(tones, current ? current.tone : (cfg.radioTone || 'chirp'));
		}
		if (people) {
			people.innerHTML = '';
			var inIt = {};
			if (current) {
				(current.members || []).forEach(function (m) { inIt[m.kind + ':' + m.id] = 1; });
			}
			state.roster.forEach(function (person) {
				var lab = document.createElement('label');
				lab.className = 'cl-radio__gp';
				var box = document.createElement('input');
				box.type = 'checkbox';
				box.value = person.id;
				box.checked = !!inIt['agent:' + person.id];
				var sp = document.createElement('span');
				sp.textContent = person.name + (person.live ? ' · available' : '');
				lab.appendChild(box);
				lab.appendChild(sp);
				people.appendChild(lab);
			});
		}
		if (modal) { modal.hidden = false; }
		if (nameEl) { window.setTimeout(function () { nameEl.focus(); }, 40); }
	}

	var newGroup = document.getElementById('cl-radio-newgroup');
	if (newGroup) {
		newGroup.addEventListener('click', function () { openGroupModal(0); });
	}
	var cancel = document.getElementById('cl-radio-gcancel');
	if (cancel) {
		cancel.addEventListener('click', function () { if (modal) { modal.hidden = true; } });
	}
	if (modal) {
		modal.addEventListener('click', function (ev) {
			if (ev.target === modal) { modal.hidden = true; }
		});
	}
	if (gform) {
		gform.addEventListener('submit', function (ev) {
			ev.preventDefault();
			var nameEl = document.getElementById('cl-radio-gname');
			var toneEl = document.getElementById('cl-radio-gtone');
			var people = document.getElementById('cl-radio-gpeople');
			var ids = [];
			if (people) {
				people.querySelectorAll('input[type="checkbox"]').forEach(function (b) {
					if (b.checked) { ids.push(b.value); }
				});
			}
			var payload = {
				what: state.editing ? 'group_update' : 'group_create',
				name: nameEl ? nameEl.value : '',
				tone: toneEl ? toneEl.value : '',
				agents: ids
			};
			if (state.editing) { payload.thread = state.editing; }
			post(payload).then(function (res) {
				if (res && res.success) {
					if (modal) { modal.hidden = true; }
					fetchFeed().then(function () {
						if (state.editing) { openThread(state.editing); }
					});
				}
			});
		});
	}

	/* ---- Writing a note ---- */

	// The box under the open line. A note is the thing that survives a person
	// not being at their desk: the live line needs both ends present, and a
	// written note does not. It goes to the same thread the line is on, and it
	// draws itself from the reply, so the sender sees it land rather than
	// waiting for the next poll to prove it.
	var composeEl = document.getElementById('cl-radio-compose');
	var inputEl   = document.getElementById('cl-radio-input');
	var sendEl    = document.getElementById('cl-radio-send');
	var sending   = false;

	function sendNote() {
		if (sending || !inputEl || !state.active) {
			return;
		}
		var text = String(inputEl.value || '').trim();
		if (!text) {
			inputEl.focus();
			return;
		}
		sending = true;
		if (sendEl) { sendEl.disabled = true; }
		post({ what: 'send', thread: state.active, body: text, kind: 'text' }).then(function (res) {
			sending = false;
			if (sendEl) { sendEl.disabled = false; }
			if (!res || !res.success) {
				// Kept in the box rather than thrown away: a note that failed to
				// send is still the note the person wrote.
				if (window.console) { console.warn('[cloaklink radio] send failed', res && res.data); }
				return;
			}
			inputEl.value = '';
			inputEl.focus();
			// The reply carries the whole line. Re-drawing it here means the
			// author's own message appears at once, in the same place the
			// recipient will see it.
			if (res.data && res.data.messages) {
				renderThreadMessages(res.data.messages);
			}
			if (res.data && res.data.thread) {
				drawThreadHead(res.data.thread);
			}
			audio();
			fetchFeed();
		}).catch(function () {
			sending = false;
			if (sendEl) { sendEl.disabled = false; }
		});
	}

	if (composeEl) {
		composeEl.addEventListener('submit', function (ev) {
			ev.preventDefault();
			sendNote();
		});
	}

	/**
	 * Bring a line back from the dead.
	 *
	 * A peer connection that has not reached `connected` a few seconds after
	 * it was built is one whose handshake was lost — the offer went out while
	 * the far end was mid-poll, or a candidate was sent before the other side
	 * had a description to attach it to. WebRTC has no retry of its own; the
	 * connection simply sits in `connecting` until the page is reloaded,
	 * which from the outside is a radio that makes no sound. This re-offers
	 * on a fresh connection instead, and it costs one handshake every twelve
	 * seconds per dead peer at worst.
	 */
	window.setInterval(function () {
		if (document.hidden || !Object.keys(pcs).length) {
			return;
		}
		Object.keys(pcs).forEach(function (key) {
			var pc = pcs[key];
			if (!pc) {
				return;
			}
			var st = pc.connectionState;
			if (st === 'connected' || st === 'closed') {
				delete pc.__clDeadAt;
				return;
			}
			if (!pc.__clDeadAt) {
				pc.__clDeadAt = Date.now();
				return;
			}
			if (RC.retryMs <= 0) {
				delete pc.__clDeadAt;
				return;
			}
			if (Date.now() - pc.__clDeadAt < RC.retryMs) {
				return;
			}
			// A line that has failed to come up several times is not coming
			// up *yet*: the other end may not be there, or it may have
			// reloaded, opened its dock late, or been cut off mid-handshake.
			//
			// This used to stop for good — "left alone until the feed
			// changes" — which in practice meant until the page was
			// reloaded. But "the far end was not there" is exactly the state
			// that resolves itself: a colleague signing in, reopening the
			// dock, or coming back from a phone call all leave the other side
			// ready to talk again. Abandoning the line made the radio look
			// broken for the rest of the shift, and pressing the key did
			// nothing, which is half of "the walkie-talkie does not work".
			//
			// So it backs off instead of giving up: three eager attempts, then
			// one every two minutes, which costs a handshake every couple of
			// minutes per absent peer and recovers on its own the moment the
			// other end returns. The budget is reset by the rebuild below, so
			// each round starts eager again.
			if ((attempts[key] || 0) >= 3) {
				if (!pc.__clSlowAt || Date.now() - pc.__clSlowAt < 120000) {
					return;
				}
				pc.__clSlowAt = Date.now();
				attempts[key] = 0;
				delete pc.__clDeadAt;
			}
			// Rebuild rather than restartIce: a connection whose offer was
			// never answered gains nothing from new candidates, it needs a
			// new offer.
			delete pc.__clDeadAt;
			var peer = pc.__cl && pc.__cl.peer;
			var tid = pc.__cl && pc.__cl.tid;
			dropPeer(key);
			if (peer && tid) {
				var fresh = makePeer(tid, peer);
				attachMic(fresh, key, mic);
			}
		});
	}, 4000);

	// A page that is going away says goodbye to each line once, so the far
	// end is not left holding a dead connection until its watchdog fires.
	window.addEventListener('pagehide', function () {
		(state.liveThreads || []).forEach(function (line) {
			(line.peers || []).forEach(function (peer) {
				sendSignal(Number(line.id), 'bye', peer, '{}');
			});
		});
		stopListening();
	});

	/* ---- Start ---- */

	// The first gesture anywhere opens the audio context, so the first tone
	// after that is not swallowed by the browser's autoplay rule.
	['pointerdown', 'keydown', 'touchstart'].forEach(function (name) {
		document.addEventListener(name, function () { audio(); }, { capture: true, passive: true, once: true });
	});

	// The same gesture unlocks the sinks, on every gesture rather than the
	// first: a line joined a moment ago has sinks the earlier tap could not
	// have armed, and a tap on the ticket being read is as good a finger as
	// a tap on the button.
	['pointerdown', 'touchstart', 'keydown'].forEach(function (name) {
		document.addEventListener(name, function () {
			if (Object.keys(remoteAudio).length) {
				unlockAudio();
			}
		}, { capture: true, passive: true });
	});

	fetchFeed();
	// Two cadences, not one. An open dock is being watched, so a reply has to
	// feel immediate; a dock left shut on a wall for a shift is polled far
	// less often, because the only thing it is doing is deciding whether to
	// chirp. Three seconds in both places would be some twelve hundred
	// requests an hour per idle tab.
	var lastIdle = 0;

	// The line's own measurements are wired once, at boot, so the panel works
	// whether or not a line has been opened yet: an operator who cannot
	// connect needs the diagnostics *before* they have a connection to
	// diagnose.
	diagWire();

	// A read-only handle for the one question the panel cannot answer on its
	// own: is sound actually leaving this page?
	//
	// The diagnostics drawer can report a connected line and a live track and
	// still be describing a call nobody can hear, because "connected" is a
	// statement about the path between two browsers and not about the audio
	// travelling down it. This exposes the live objects so a support note can
	// carry the stats that settle it — bytes sent, packets sent, the level on
	// the outbound track — instead of a screenshot of a green dot. It reads;
	// it changes nothing.
	window.__clRadioDebug = {
		peers: function () { return pcs; },
		senders: function () { return senders; },
		mic: function () { return mic; },
		talking: function () { return talking; },
		state: function () { return state; },
		stats: function () {
			var out = [];
			Object.keys(pcs).forEach(function (k) {
				var pc = pcs[k];
				if (!pc) { return; }
				out.push({
					key: k,
					connection: pc.connectionState,
					ice: pc.iceConnectionState,
					signaling: pc.signalingState,
					out: pc.getSenders().map(function (s) {
						return s.track ? (s.track.kind + ':' + s.track.readyState + ':' + (s.track.enabled ? 'on' : 'off')) : 'none';
					}),
					in: pc.getReceivers().map(function (r) {
						return r.track ? (r.track.kind + ':' + r.track.readyState) : 'none';
					})
				});
			});
			return out;
		}
	};

	window.setInterval(function () {
		if (state.open && !document.hidden) {
			tick();
		} else if (!document.hidden && Date.now() - lastIdle > 9000) {
			lastIdle = Date.now();
			// A closed dock still counts: the badge has to say a message is
			// waiting, or nobody would ever open it.
			post({ what: 'feed' }).then(function (res) {
				if (res && res.success && res.data) {
					state.threads = res.data.threads || [];
					updateBadge(res.data.unread || 0);
					var total = Number(res.data.unread) || 0;
					if (total > (state.seenTotal || 0)) {
						play(toneForNotify());
					}
					state.seenTotal = total;
				}
			}).catch(function () {});
		}
	}, 3000);
})();
