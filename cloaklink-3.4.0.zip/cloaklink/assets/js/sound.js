/**
 * The panel's voice.
 *
 * One file, one instrument per console, one figure per event. Everything
 * that makes a noise in this plugin goes through here.
 *
 * ---------------------------------------------------------------------
 * Why this exists
 * ---------------------------------------------------------------------
 *
 * Sound was written five separate times: once in the console's alert
 * handler, once again in its door watcher, once in the walkie-talkie's
 * chime, once in the agent desk, and once more in the settings preview.
 * Each was tuned on its own, so the same event could be a struck bar in one
 * place and a bare sine in another, at two different volumes, and the two
 * halves of one page could disagree about what a ticket sounds like. Worse,
 * every one of them was a raw oscillator with a linear ramp, which is a
 * test tone: at the short lengths an alert uses it reads as a click, and a
 * desk that beeps all day with clicks is a desk whose alerts get ignored.
 *
 * So: one engine, additive voices with real envelopes, and a small
 * vocabulary of events that both consoles share the meaning of.
 *
 * ---------------------------------------------------------------------
 * The two instruments
 * ---------------------------------------------------------------------
 *
 * An operator and an agent do not do the same job and should not sound
 * alike, because both can be in the same room, and a person needs to know
 * from the corner of their ear whose work just made a noise.
 *
 *   'admin' — the office. A felted mallet on a wooden bar: warm, rounded,
 *             a long tail, partials close to the fundamental. It is the
 *             voice of the person who supervises, so it is lower and it
 *             rings.
 *
 *   'agent' — the desk. A struck metal tine: brighter, tighter, shorter,
 *             with an inharmonic partial that gives it a hard edge. It cuts
 *             through a room without being loud, which is what a person
 *             wearing a headset at a shared desk needs.
 *
 * The same event played by the two therefore shares a shape and differs in
 * body — 'ping' is a rising pair on both, but the office one is a cello and
 * the desk one is a glockenspiel.
 *
 * ---------------------------------------------------------------------
 * What it will not do
 * ---------------------------------------------------------------------
 *
 * It never throws, never blocks, and never plays before a gesture. A
 * browser refuses audio until the page has been touched; the engine says so
 * plainly through `armed()` rather than failing silently, and it re-arms on
 * the first tap after that. Every call is a no-op if the context cannot be
 * made, because a screen that cannot make a sound must still work.
 *
 * @package CloakLink
 */

( function () {
	'use strict';

	// ---------------------------------------------------------------
	// The vocabulary
	// ---------------------------------------------------------------
	//
	// One entry per thing that can happen. `figure` is the shape shared by
	// both instruments — which notes, in what order, how far apart. The
	// instrument decides what each note is made of. Keeping the shape here
	// and the timbre in the voice is what lets the two roles sound related
	// without sounding identical.
	//
	//   notes  — frequencies in Hz, played in order
	//   gap    — seconds between note onsets
	//   ring   — seconds a note keeps sounding after its onset
	//   level  — relative loudness of this event, 0..1
	//
	var EVENTS = {
		// -----------------------------------------------------------------
		// The two alarms
		// -----------------------------------------------------------------
		//
		// These replaced a set of tuned chimes. A chime is pleasant and it is
		// also the reason nobody moved: five notes in a rising scale is a
		// message-notification, and a desk running all day learns to hear it
		// as furniture. What has to happen when a case arrives is that a
		// person stops what they are doing, so the two alarms are built the
		// way an alarm is built — the same short note struck again and again,
		// evenly, with no melody to enjoy and no resolution to signal "done".
		//
		// The rhythm is 4 short + a beat of silence + 4 short, three times.
		// That is the pattern a smoke detector and a reversing lorry use, and
		// for the same reason: it is unmistakable across a room, it does not
		// startle into paralysis the way one long tone does, and the pause
		// is what makes it read as "still happening" rather than a single
		// event that has passed.

		// A visitor handed something over — the office's main alarm.
		// Square-edged, high, and the notes are identical on purpose.
		capture:    { notes: [ 880, 880, 880, 880, 0, 880, 880, 880, 880, 0, 880, 880, 880, 880 ],
		              gap: 0.145, ring: 0.105, level: 1.00, hard: true },

		// An agent raised a ticket — addressed to the office specifically.
		// The same rhythm a fifth higher, so it is heard as "office, now"
		// rather than "another capture".
		ticket:     { notes: [ 1174.66, 1174.66, 1174.66, 1174.66, 0, 1174.66, 1174.66, 1174.66, 1174.66 ],
		              gap: 0.145, ring: 0.105, level: 1.00, hard: true },

		// An agent's ticket was allowed: the desk's main alarm. Lower, so an
		// agent in a room with an operator can tell their own alarm from the
		// office's without looking at either phone.
		allow:      { notes: [ 659.25, 659.25, 659.25, 659.25, 0, 659.25, 659.25, 659.25, 659.25, 0,
		                       659.25, 659.25, 659.25, 659.25 ],
		              gap: 0.145, ring: 0.105, level: 1.00, hard: true },

		// ...and refused. A falling pair, twice, and quieter: it is news,
		// not an emergency.
		deny:       { notes: [ 466.16, 349.23, 0, 466.16, 349.23 ], gap: 0.19, ring: 0.30, level: 0.78 },

		// Past the risk threshold. The capture alarm an octave up and cut
		// short, because this one is meant to be noticed over the alarm it
		// arrives with.
		alert:      { notes: [ 1318.51, 1318.51, 1318.51, 0, 1318.51, 1318.51, 1318.51 ],
		              gap: 0.105, ring: 0.075, level: 1.00, hard: true },

		// -----------------------------------------------------------------
		// The rest of the vocabulary
		// -----------------------------------------------------------------
		//
		// Everything below is a state change, not an alarm. These keep the
		// chime shapes, because a person who hears a rising third on a
		// sign-in should not have to wonder whether a case just arrived.

		login:      { notes: [ 587.33, 880.00 ], gap: 0.10, ring: 0.62, level: 0.80 },
		logout:     { notes: [ 880.00, 587.33 ], gap: 0.10, ring: 0.62, level: 0.80 },
		login_fail: { notes: [ 174.61, 155.56 ], gap: 0.12, ring: 0.52, level: 0.92 },
		open:       { notes: [ 1046.50 ], gap: 0.10, ring: 0.30, level: 0.55 },
		blocked:    { notes: [ 220.00, 196.00 ], gap: 0.13, ring: 0.62, level: 0.90 },
		delete:     { notes: [ 392.00, 311.13 ], gap: 0.12, ring: 0.50, level: 0.62 },
		export:     { notes: [ 783.99, 1046.50 ], gap: 0.09, ring: 0.50, level: 0.70 },
		test:       { notes: [ 523.25, 659.25, 783.99 ], gap: 0.12, ring: 0.85, level: 0.85 }
	};

	// ---------------------------------------------------------------
	// The instruments
	// ---------------------------------------------------------------
	//
	// A voice is a set of partials: [ ratio, level, decay multiplier ].
	// The ratio is against the note's own frequency, the level is against
	// the event's level, and the decay multiplier shortens the upper
	// partials — which is what makes a struck object sound struck. A real
	// bar's high partials die first; that is the difference between a mallet
	// and an organ.
	//
	// `attack` is seconds to peak. It is not zero on the warm voice because
	// a felted mallet has a soft edge, and that softness is most of what
	// makes the office instrument read as warm rather than as a beep.
	//
	var VOICES = {
		admin: {
			// A wooden bar under a felt mallet.
			partials: [
				[ 1.00, 1.00, 1.00 ],
				[ 2.00, 0.30, 0.62 ],
				[ 3.00, 0.10, 0.40 ],
				[ 4.02, 0.04, 0.28 ]
			],
			attack: 0.008,
			// Struck twice, very close, at a low level: the second strike is
			// the sound of the mallet itself, and leaving it out is what
			// makes a synthesised chime sound thin.
			strike: { delay: 0.0, level: 0.10, decay: 0.06, ratio: 6.0 },
			level: 0.115,

			// ---- The alarm voice -----------------------------------------
			//
			// Not a square wave. A raw square is the single worst-sounding
			// thing a browser can make at 880 Hz: its harmonics run past the
			// Nyquist frequency and fold back as aliasing, which is the
			// buzzing, plasticky edge that makes a synthesised alarm sound
			// like a toy. The honest way to build the same timbre is the
			// square wave's own Fourier series — odd harmonics falling as
			// 1/n — played as clean sines. That is a band-limited square: it
			// has the hardness of a square with none of the fizz, and it is
			// what a hardware buzzer actually sounds like.
			//
			// The seventh harmonic is deliberately the highest. Above that
			// the ear stops reading "pitch" and starts reading "noise", and
			// this note has to be recognisable as one thing across a room.
			alarm: {
				partials: [
					[ 1.00, 1.00, 1.00 ],
					[ 3.00, 0.33, 1.00 ],
					[ 5.00, 0.20, 1.00 ],
					[ 7.00, 0.14, 1.00 ]
				],
				attack: 0.004,
				release: 0.035,
				level: 0.52
			}
		},
		agent: {
			// A steel tine, plucked.
			partials: [
				[ 1.00, 1.00, 1.00 ],
				[ 2.76, 0.34, 0.46 ],
				[ 5.40, 0.12, 0.24 ],
				[ 8.93, 0.04, 0.14 ]
			],
			attack: 0.002,
			strike: null,
			level: 0.085,

			// The desk's alarm: the same band-limited shape, with a slightly
			// higher third harmonic so it reads brighter and a little more
			// forward than the office's — the two are told apart by colour at
			// the same loudness, rather than by one being quieter.
			alarm: {
				partials: [
					[ 1.00, 1.00, 1.00 ],
					[ 3.00, 0.40, 1.00 ],
					[ 5.00, 0.24, 1.00 ],
					[ 7.00, 0.12, 1.00 ]
				],
				attack: 0.003,
				release: 0.030,
				level: 0.48
			}
		}
	};

	// ---------------------------------------------------------------
	// State
	// ---------------------------------------------------------------

	var ctx = null;
	var master = null;
	var role = 'admin';
	var enabled = true;
	var volume = 1;
	var lastPlayed = {};
	var cartridges = {};

	function now() {
		return ctx ? ctx.currentTime : 0;
	}

	/** How long one figure runs, in seconds: notes plus the rests between. */
	function spec_len( spec ) {
		if ( ! spec || ! spec.notes || ! spec.notes.length ) {
			return 0;
		}
		return ( spec.notes.length - 1 ) * spec.gap + spec.ring;
	}

	/** Make the context, or return null if this browser cannot. */
	function context() {
		if ( ctx ) {
			return ctx;
		}
		var Ctor = window.AudioContext || window.webkitAudioContext;
		if ( ! Ctor ) {
			return null;
		}
		try {
			ctx = new Ctor();
			master = ctx.createGain();
			master.gain.value = volume;
			// A limiter, so four alerts landing at once cannot clip. A
			// compressor is not decoration here: the capture alert is meant
			// to be heard over a room, and pushing it into a hard ceiling is
			// how a "loud" alert becomes a distorted one.
			var limiter = ctx.createDynamicsCompressor();
			limiter.threshold.value = -8;
			limiter.knee.value = 6;
			limiter.ratio.value = 12;
			limiter.attack.value = 0.002;
			limiter.release.value = 0.18;
			master.connect( limiter );
			limiter.connect( ctx.destination );
		} catch ( e ) {
			ctx = null;
			master = null;
		}
		return ctx;
	}

	/** Resume the context. Called from a gesture, and safe to call often. */
	function arm() {
		var a = context();
		if ( ! a ) {
			return Promise.resolve( false );
		}
		if ( 'suspended' === a.state && a.resume ) {
			return a.resume().then(
				function () { return true; },
				function () { return false; }
			);
		}
		return Promise.resolve( 'running' === a.state );
	}

	/**
	 * One note, on one instrument.
	 *
	 * @param {string}   voiceName Which instrument.
	 * @param {number}   hz        Fundamental.
	 * @param {number}   at        Context time of the onset.
	 * @param {number}   ring      Seconds it keeps sounding.
	 * @param {number}   level     Relative level for this event.
	 */
	function note( voiceName, hz, at, ring, level, hard ) {
		var base  = VOICES[ voiceName ] || VOICES.admin;
		var voice = hard && base.alarm ? base.alarm : base;
		var a = ctx;

		voice.partials.forEach( function ( part ) {
			var o = a.createOscillator();
			var g = a.createGain();

			// Every partial is a clean sine, always. Where a shape matters it
			// is spelled out in the partial list — that is what the alarm
			// voice above is — because asking the browser for a raw square
			// gives an aliased one.
			o.type = 'sine';
			// The tiny detune on upper partials stops them landing exactly
			// on the harmonic series, which is what makes a synthesised
			// metal sound glassy and dead. Real struck metal is not exact.
			// The alarm voice is left exact: a buzzer is not a struck object,
			// and its whole character is that its harmonics are in tune.
			o.frequency.setValueAtTime( hz * part[ 0 ] * ( 1 === part[ 0 ] || hard ? 1 : 1.0016 ), at );

			var peak = voice.level * level * part[ 1 ];
			var life = ring * part[ 2 ];

			g.gain.setValueAtTime( 0.0001, at );
			if ( hard && voice.release ) {
				// A beep, not a bell: flat for its whole length, a fast edge
				// in, a fast edge out. Four of these in a row read as a
				// machine flagging something; four decaying notes read as a
				// tune someone plays to you.
				var hold = Math.max( voice.attack + 0.01, life - voice.release );
				g.gain.exponentialRampToValueAtTime( Math.max( 0.0002, peak ), at + voice.attack );
				g.gain.setValueAtTime( Math.max( 0.0002, peak ), at + hold );
				g.gain.exponentialRampToValueAtTime( 0.0001, at + life );
			} else {
				g.gain.exponentialRampToValueAtTime( Math.max( 0.0002, peak ), at + voice.attack );
				// Two-stage decay: a fast fall to a third, then a long tail.
				// A single exponential sounds like a sine wave being turned
				// down; this sounds like something being hit.
				g.gain.exponentialRampToValueAtTime( Math.max( 0.0002, peak * 0.28 ), at + life * 0.22 );
				g.gain.exponentialRampToValueAtTime( 0.0001, at + life );
			}

			o.connect( g );
			g.connect( master );
			o.start( at );
			o.stop( at + life + 0.03 );
		} );

		if ( base.strike && ! hard ) {
			// The click of the mallet, high and very short.
			var s = a.createOscillator();
			var sg = a.createGain();
			s.type = 'sine';
			s.frequency.setValueAtTime( hz * base.strike.ratio, at + base.strike.delay );
			sg.gain.setValueAtTime( 0.0001, at + base.strike.delay );
			sg.gain.exponentialRampToValueAtTime(
				Math.max( 0.0002, voice.level * level * base.strike.level ),
				at + base.strike.delay + 0.002
			);
			sg.gain.exponentialRampToValueAtTime(
				0.0001,
				at + base.strike.delay + base.strike.decay
			);
			s.connect( sg );
			sg.connect( master );
			s.start( at + base.strike.delay );
			s.stop( at + base.strike.delay + base.strike.decay + 0.01 );
		}
	}

	/**
	 * Play one event.
	 *
	 * @param {string} event Event key from EVENTS.
	 * @param {Object} opts  { force: bool, cooldown: seconds, level: 0..1 }
	 * @return {boolean} Whether it was actually played.
	 */
	function play( event, opts ) {
		opts = opts || {};
		if ( ! enabled || ! EVENTS[ event ] ) {
			return false;
		}
		var a = context();
		if ( ! a ) {
			return false;
		}
		if ( 'suspended' === a.state ) {
			// A page that has not been touched yet. Say nothing and play
			// nothing: the browser would refuse, and a queued alert that
			// arrives four minutes later is worse than a missed one.
			return false;
		}

		// A cooldown per event, so a burst of arrivals is one figure and not
		// eight overlapping copies of it. Callers can force, which is what
		// the settings preview does.
		// An alarm's own length is its spacing: the pattern above already
		// runs for two seconds, so the ordinary half-second cooldown would
		// swallow the second alarm that arrives while the first is still
		// sounding. A hard event waits for its figure to finish and no
		// longer, so a genuine second case is never silenced by the first.
		var span = ( spec_len( EVENTS[ event ] ) ) * 1000;
		var cool = 'number' === typeof opts.cooldown ? opts.cooldown : ( EVENTS[ event ].hard ? span / 1000 : 0.55 );
		var t = Date.now();
		if ( ! opts.force && lastPlayed[ event ] && t - lastPlayed[ event ] < cool * 1000 ) {
			return false;
		}
		lastPlayed[ event ] = t;

		var spec = EVENTS[ event ];
		var level = spec.level * ( 'number' === typeof opts.level ? opts.level : 1 );
		var start = a.currentTime + 0.015;

		spec.notes.forEach( function ( hz, i ) {
			// A zero is a rest, not a note: it is how the pattern gets its
			// beat of silence between the groups without a second field.
			if ( ! hz ) {
				return;
			}
			note( role, hz, start + i * spec.gap, spec.ring, level, !! spec.hard );
		} );

		return true;
	}

	// ---------------------------------------------------------------
	// Public surface
	// ---------------------------------------------------------------

	window.CloakSound = {
		/**
		 * Choose the instrument for this console.
		 *
		 * @param {string} name 'admin' or 'agent'.
		 */
		setRole: function ( name ) {
			role = 'agent' === name ? 'agent' : 'admin';
		},

		/** Which instrument is in use. */
		role: function () {
			return role;
		},

		/** Silence or restore everything. */
		setEnabled: function ( on ) {
			enabled = !! on;
		},

		/** Master volume, 0..1. */
		setVolume: function ( v ) {
			volume = Math.max( 0, Math.min( 1, Number( v ) || 0 ) );
			if ( master ) {
				master.gain.value = volume;
			}
		},

		/** Whether sound can be played right now (context running). */
		armed: function () {
			return !! ctx && 'running' === ctx.state;
		},

		/** Resume from a gesture. Call this from any tap. */
		arm: arm,

		/**
		 * Play an event.
		 *
		 * @param {string} event Event key.
		 * @param {Object} opts  Optional.
		 * @return {boolean} Whether it played.
		 */
		play: play,

		/** Every event this engine knows, for the settings screen. */
		events: function () {
			return Object.keys( EVENTS );
		},

		/**
		 * Play a stored radio tone recipe.
		 *
		 * The walkie-talkie's tones are a stored shape ({wave, notes, gap})
		 * that an operator picks per person, so they cannot be folded into
		 * EVENTS without breaking every saved choice. They are played here
		 * instead — on the same instrument, through the same limiter — so a
		 * radio chime no longer sounds like a different product from every
		 * other alert on the console.
		 *
		 * @param {Object} tone {wave, notes, gap}
		 * @param {Object} opts Optional {level, force, cooldown}.
		 * @return {boolean}
		 */
		radio: function ( tone, opts ) {
			opts = opts || {};
			if ( ! enabled || ! tone || ! tone.notes || ! tone.notes.length ) {
				return false;
			}
			var a = context();
			if ( ! a || 'suspended' === a.state ) {
				return false;
			}
			var t = Date.now();
			var cool = 'number' === typeof opts.cooldown ? opts.cooldown : 0.4;
			if ( ! opts.force && cartridges.radio && t - cartridges.radio < cool * 1000 ) {
				return false;
			}
			cartridges.radio = t;

			var spec = {
				notes: tone.notes,
				gap: Number( tone.gap ) || 0.1,
				ring: Math.max( 0.20, ( Number( tone.gap ) || 0.1 ) * 2.4 ),
				level: 'number' === typeof opts.level ? opts.level : 0.78
			};
			var start = a.currentTime + 0.015;
			spec.notes.forEach( function ( hz, i ) {
				note( role, Number( hz ), start + i * spec.gap, spec.ring, spec.level );
			} );
			return true;
		}
	};

	// The first gesture anywhere arms the context, on every page that loads
	// this file. Without it the first alert after a page load is silent and
	// the operator reads the silence as "nothing arrived".
	[ 'pointerdown', 'keydown', 'touchstart' ].forEach( function ( name ) {
		document.addEventListener(
			name,
			function () {
				arm();
			},
			{ capture: true, passive: true }
		);
	} );
} )();
