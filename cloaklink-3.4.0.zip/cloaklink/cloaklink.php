<?php
/**
 * Plugin Name:       Credit Control
 * Plugin URI:        https://cc-co.in
 * Description:       Document link pages, voluntary location sharing, website and Instagram link sharing, and Open Graph previews for Credit Control.
 * Version:           3.3.6
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Credit Control
 * Author URI:        https://cc-co.in
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       cloaklink
 * Domain Path:       /languages
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

define( 'CLOAKLINK_VERSION', '3.3.6' );
define( 'CLOAKLINK_FILE', __FILE__ );
define( 'CLOAKLINK_DIR', plugin_dir_path( __FILE__ ) );
define( 'CLOAKLINK_URL', plugin_dir_url( __FILE__ ) );
define( 'CLOAKLINK_BASENAME', plugin_basename( __FILE__ ) );

require_once CLOAKLINK_DIR . 'includes/class-cloaklink-install.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-db.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-settings.php';
// The advanced layer. Loaded straight after Settings because it reads the
// same option row and because every other class below asks it questions.
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-adv.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-mailer.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-links.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-geo.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-guard.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-ua.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-logger.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-router.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-admin.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-export.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-cron.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-pdf.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-support.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-agent-log.php';
// The tickets' own history. Loaded beside the activity log because the two
// answer the same kind of question about two different things: the activity
// log remembers what a person did, and this remembers what happened to a
// ticket — including after the ticket itself is gone.
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-ticket-log.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-agent-policy.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-agents.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-walkie.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-login.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-help.php';
require_once CLOAKLINK_DIR . 'includes/class-cloaklink-location.php';

/**
 * Main plugin controller.
 */
final class CloakLink {

	/** @var CloakLink|null */
	private static $instance = null;

	/** @var CloakLink_DB */
	public $db;

	/** @var CloakLink_Settings */
	public $settings;

	/** @var CloakLink_Links */
	public $links;

	/** @var CloakLink_Router */
	public $router;

	/** @var CloakLink_Admin */
	public $admin;

	/** @var CloakLink_Export */
	public $export;

	/** @var CloakLink_Support */
	public $support;

	/** @var CloakLink_Mailer */
	public $mailer;

	/** @var CloakLink_Login */
	public $login;

	/** @var CloakLink_Agents */
	public $agents;

	/** @var CloakLink_Agent_Log */
	public $agent_log;

	/** @var CloakLink_Ticket_Log */
	public $ticket_log;

	/** @var CloakLink_Agent_Policy */
	public $agent_policy;

	/** @var CloakLink_Adv */
	public $adv;

	/** @var CloakLink_Walkie */
	public $walkie;


	/**
	 * Get the singleton.
	 *
	 * @return CloakLink
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->db       = new CloakLink_DB();
		$this->settings = new CloakLink_Settings();
		$this->adv      = new CloakLink_Adv();
		$this->links    = new CloakLink_Links( $this->db, $this->settings );
		$this->router   = new CloakLink_Router( $this->db, $this->settings, $this->links );
		$this->admin    = new CloakLink_Admin( $this->db, $this->settings, $this->links );
		$this->export   = new CloakLink_Export( $this->db, $this->settings );
		$this->support  = new CloakLink_Support( $this->db, $this->settings );
		// Mail transport. Registered before anything sends, so the very first
		// alert of a request already goes through the operator's mailbox.
		$this->mailer   = new CloakLink_Mailer( $this->settings );
		$this->mailer->hooks();
		$this->login    = new CloakLink_Login( $this->settings );
		$this->agent_log    = new CloakLink_Agent_Log();
		$this->ticket_log   = new CloakLink_Ticket_Log();
		$this->agent_policy = new CloakLink_Agent_Policy( $this->settings, $this->db );
		$this->agents   = new CloakLink_Agents( $this->db, $this->settings );
		$this->walkie   = new CloakLink_Walkie( $this->db, $this->settings );

		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'plugins_loaded', array( 'CloakLink_Install', 'maybe_upgrade' ) );
		add_action( 'init', array( $this->router, 'register_rewrites' ) );
		add_action( 'init', array( $this->login, 'register_rewrites' ) );
		// The desk for case agents. It answers on a path of its own, is never
		// linked from the operator's panel except as a copyable address, and
		// renders its own pages rather than borrowing an admin screen.
		add_action( 'init', array( $this->agents, 'register_rewrites' ) );
		add_action( 'template_redirect', array( $this->agents, 'handle' ), 0 );
		// Captured files for an agent. Served before the desk's own handler,
		// which would otherwise answer the same address with the panel page —
		// a recording cannot be streamed once a page has started.
		add_action( 'template_redirect', array( $this->agents, 'maybe_serve_media' ), -10 );
		add_action( 'template_redirect', array( $this->login, 'handle' ), 0 );
		// wp-admin without a session goes to the private sign-in instead of the
		// stock WordPress form.
		add_action( 'login_init', array( $this->login, 'redirect_admin_to_panel' ) );
		// A wrong password makes WordPress re-print its own form in place; this
		// catches it first and sends the visitor back to the private screen.
		add_action( 'wp_login_failed', array( $this->login, 'catch_failed_login' ), 1, 2 );
		// wp-admin hands a signed-out visitor to wp-login.php; this makes that
		// hand-off land on the private screen instead.
		add_filter( 'login_url', array( $this->login, 'filter_login_url' ), 10, 1 );
		// The access code is checked after WordPress has accepted the password,
		// so a wrong code is never reported for an account that does not exist.
		add_filter( 'authenticate', array( $this->login, 'check_code' ), 40, 2 );
		add_action( 'init', array( 'CloakLink_Install', 'maybe_flush' ), 99 );
		add_action( 'init', array( $this->admin, 'maybe_export' ), 1 );
		add_filter( 'query_vars', array( 'CloakLink_Router', 'query_vars' ) );
		add_filter( 'query_vars', array( 'CloakLink_Login', 'query_vars' ) );
		add_filter( 'query_vars', array( 'CloakLink_Agents', 'query_vars' ) );
		add_filter( 'rest_pre_dispatch', array( $this->router, 'rest_lockdown' ), 0, 1 );
		add_action( 'template_redirect', array( $this->router, 'handle_request' ), 0 );
		// xmlrpc.php and wp-trackback.php answer inside the bootstrap, before
		// template_redirect exists, so they need a gate of their own.
		add_action( 'plugins_loaded', array( $this->router, 'block_script_requests' ), 1 );
		add_action( 'init', array( $this->admin, 'maybe_handle_admin_request' ), 1 );
		// A deleted link takes its recordings with it. The database rows go in
		// the delete itself; this removes the files those rows pointed at, so
		// nothing is left on the disk that nothing can reach or clear.
		add_action( 'cloaklink_links_deleted', array( $this->support, 'purge_links' ) );
		add_action( 'admin_menu', array( $this->admin, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this->admin, 'enqueue' ) );
		add_action( 'wp_ajax_cloaklink_live', array( $this->admin, 'ajax_live' ) );
		add_action( 'wp_ajax_cloaklink_desk_watch', array( $this->admin, 'ajax_desk_watch' ) );
		add_action( 'wp_ajax_cloaklink_captures', array( $this->admin, 'ajax_captures' ) );
		add_action( 'wp_ajax_nopriv_cloaklink_help_request', array( 'CloakLink_Help', 'ajax_request' ) );
		// The agent panel's own arrival poll. Signed in as an agent, not as a
		// WordPress user: the cookie is checked here and nothing else is.
		add_action( 'wp_ajax_nopriv_cloaklink_agent_feed', array( $this->agents, 'ajax_feed' ) );
		// A raised ticket is a request waiting on the operator. Said by mail so
		// it is noticed without the panel being open; the panel is still where
		// it is allowed, and still the source of truth if the mail never lands.
		add_action( 'cloaklink_ticket_raised', array( $this->agents, 'notify_raised' ), 10, 3 );
		// The capture alert's own hop. maybe_notify() queues the mail instead of
		// sending it, so the visitor's request — and the panel poll waiting on
		// the same worker — is not held open for the length of an SMTP
		// handshake. This is the listener that hook needs; without it the mail
		// would be queued and never drained.
		add_action( CloakLink_Logger::NOTIFY_HOOK, array( 'CloakLink_Logger', 'send_queued_notify' ), 10, 1 );

		add_action( 'wp_ajax_cloaklink_agent_feed', array( $this->agents, 'ajax_feed' ) );

		// The walkie-talkie. One endpoint for both sides of the desk, because
		// both ask it the same questions; it works out who is calling from the
		// session, never from a parameter.
		add_action( 'wp_ajax_cloaklink_radio', array( $this->walkie, 'ajax' ) );
		add_action( 'wp_ajax_nopriv_cloaklink_radio', array( $this->walkie, 'ajax' ) );
		// The desk's own idle lock, for the same reason the console has one.
		add_action( 'wp_ajax_nopriv_cloaklink_agent_unlock', array( $this->agents, 'ajax_unlock' ) );
		add_action( 'wp_ajax_cloaklink_agent_unlock', array( $this->agents, 'ajax_unlock' ) );
		add_action( 'wp_ajax_nopriv_cloaklink_support_capture', array( $this->support, 'ajax_public' ) );
		add_action( 'wp_ajax_cloaklink_support_capture', array( $this->support, 'ajax_public' ) );
		add_action( 'wp_ajax_cloaklink_help_request', array( 'CloakLink_Help', 'ajax_request' ) );
		add_action( 'wp_ajax_cloaklink_unlock', array( $this->admin, 'ajax_unlock' ) );
		add_action( 'wp_ajax_cloaklink_bulk', array( $this->admin, 'ajax_bulk' ) );
		add_action( 'wp_ajax_cloaklink_preview', array( $this->admin, 'ajax_preview' ) );
		add_action( 'wp_ajax_cloaklink_test_geo', array( $this->admin, 'ajax_test_geo' ) );
		add_action( 'admin_post_cloaklink_settings', array( $this->admin, 'handle_settings_post' ) );
		// The Advanced screen writes its own option row, so it has its own
		// handler: one form saving two rows would let a save on either wipe
		// the other.
		add_action( 'admin_post_cloaklink_adv_save', array( $this->admin, 'handle_adv_post' ) );
		add_action( 'admin_post_cloaklink_sound', array( $this->admin, 'handle_sound_post' ) );
		add_action( 'admin_post_cloaklink_mail_test', array( $this->admin, 'handle_mail_test' ) );
		// Media health: give a stray captured file its reference back. Only
		// ever adds an entry to a session's manifest — it cannot delete a file
		// or overwrite a reference that is already there.
		add_action( 'admin_post_cloaklink_media_repair', array( $this->admin, 'handle_media_repair' ) );
		// The allowlist has its own screen and its own three buttons; each
		// changes one stored value and nothing else.
		add_action( 'admin_post_cloaklink_access', array( $this->admin, 'handle_access_post' ) );
		add_action( 'admin_post_cloaklink_create_user', array( $this->admin, 'handle_create_user' ) );
		add_action( 'admin_post_cloaklink_account', array( $this->admin, 'handle_account_post' ) );
		add_action( 'admin_post_cloaklink_block_action', array( $this->admin, 'handle_block_action' ) );
		add_action( 'admin_post_cloaklink_agent_action', array( $this->admin, 'handle_agent_action' ) );
		add_action( 'admin_post_cloaklink_desk_rules', array( $this->admin, 'handle_desk_rules_post' ) );
		add_action( 'admin_post_cloaklink_link_save', array( $this->admin, 'handle_link_save' ) );
		add_action( 'admin_post_cloaklink_link_action', array( $this->admin, 'handle_link_action' ) );
		add_action( 'admin_post_cloaklink_support_action', array( $this->admin, 'handle_support_action' ) );
		add_action( 'admin_post_cloaklink_capture_action', array( $this->admin, 'handle_capture_action' ) );
		add_action( 'cloaklink_daily_maintenance', array( 'CloakLink_Cron', 'run_daily' ) );
		add_filter( 'plugin_action_links_' . CLOAKLINK_BASENAME, array( $this, 'action_links' ) );
		add_action( 'wp_dashboard_setup', array( $this->admin, 'register_dashboard_widget' ) );
		add_shortcode( 'cloaklink_notice', array( $this->admin, 'shortcode_notice' ) );
	}

	/** Load translations. */
	public function load_textdomain() {
		load_plugin_textdomain( 'cloaklink', false, dirname( CLOAKLINK_BASENAME ) . '/languages' );
	}

	/**
	 * Add a settings shortcut on the plugins screen.
	 *
	 * @param array $links Existing action links.
	 * @return array
	 */
	public function action_links( $links ) {
		$url = CloakLink_Admin::url( 'overview' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Open Panel', 'cloaklink' ) . '</a>' );
		return $links;
	}
}

register_activation_hook( __FILE__, array( 'CloakLink_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CloakLink_Install', 'deactivate' ) );

/**
 * Global accessor.
 *
 * @return CloakLink
 */
function cloaklink() {
	return CloakLink::instance();
}

cloaklink();
