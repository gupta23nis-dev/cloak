# Credit Control — Install and test guide (2.8.0)

## Update
1. Back up the WordPress site and current `cloaklink` plugin folder.
2. Go to **Plugins → Add New → Upload Plugin**, upload the new ZIP, and replace the previous plugin.
3. Open **WordPress Settings → Permalinks → Save Changes**.
4. In **CloakLink → Settings**, set the organization name, contact email, telephone number and the support desk state.
5. Select **CloakLink → New Link → Upload document**, give it a title, attach a PDF or image, and create the link. Open it on a phone to test.

## Visitor interface
- One document card and a Help section. Nothing about data collection is printed on the page: no consent essay, no retention paragraph, no countdown.
- The whole link is one page: the document card, then the viewer once opened. There is no separate briefing.
- **A document is never served as a file.** There is no URL for it. A tap asks the browser for location; if the browser answers, the site replies with the document's bytes and the page draws each page onto a canvas. The browser never receives a PDF, so it shows no save button, no reader toolbar, and nothing appears in Downloads.
- The viewer shows one page at a time with a page counter. Pages are pictures, so text cannot be selected or copied from them.
- If location is refused or unavailable, the help panel opens instead: speak with an agent, call, or email.
- Help → **Speak with our agent** asks for location, camera and microphone only after one consent tick, and only when the desk is open. A busy or closed desk says so first, with the hours, and offers email and phone instead.
- The written message form always works, whatever the desk state.

## What cannot be guaranteed
- A picture of a screen can always be taken with another phone. No website can prevent that. What this removes is every ordinary route: no file, no link to the file, no address in the page source.
- A browser may keep what it has already drawn in memory or cache. The site sends no cache headers that let the reply be stored.

## Checks before launch
- Test a document link on a real phone: confirm the location dialog appears, the page draws, and **nothing appears in Downloads**.
- Confirm the button label and page copy on the phone match what is intended.
- On nginx, block direct requests to `wp-content/uploads/cloaklink-private` at the web-server level as a second line of defence.
- The plugin is syntax-checked and packaged; live WordPress deployment has not been verified here.
