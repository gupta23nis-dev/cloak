<?php
/**
 * Admin panel controller.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Builds the control panel: routes, forms, AJAX, rendering.
 */
class CloakLink_Admin {

	/**
	 * The operator's own brand mark, drawn wherever the panel used to draw
	 * a glyph.
	 *
	 * The logo ships in the plugin rather than in the media library: it is
	 * part of what this build looks like, not a setting a visitor could
	 * change, and it is present on a fresh install before anyone has opened
	 * Settings. WebP first with a PNG fallback underneath, both sized by the
	 * caller so one file serves a 42px tile and a 96px login seal.
	 *
	 * @param string $class Extra CSS classes.
	 * @param int    $size  Square size in CSS pixels.
	 * @return string
	 */
	public static function logo( $class = '', $size = 42 ) {
		$size = max( 12, (int) $size );
		$alt  = (string) cloaklink()->settings->get( 'brand_name', 'Credit Control' );
		$alt  = '' !== trim( $alt ) ? $alt : 'Credit Control';

		return '<img class="cl-brandmark ' . esc_attr( $class ) . '"'
			. ' src="' . esc_url( CLOAKLINK_URL . 'assets/img/logo.png' ) . '"'
			. ' alt="' . esc_attr( $alt ) . '"'
			. ' width="' . esc_attr( $size ) . '" height="' . esc_attr( $size ) . '"'
			. ' loading="eager" decoding="async">';
	}

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/** @var CloakLink_Links */
	private $links;

	/** @var array The filters the captured wall is currently showing. */
	private $capture_scope = array();

	/** Menu slug. */
	const MENU = 'cloaklink';

	/** @var array Route table: key => [title, subtitle]. */
	private $routes = array(
		'overview'  => array( 'Overview', 'Live picture of every link and visitor.' ),
		'links'     => array( 'Links', 'Create, share, pause and retire your links.' ),
		'new'       => array( 'New link', 'Build a private link in three steps.' ),
		'edit'      => array( 'Edit link', 'Change destination, expiry or gate rules.' ),
		'link'      => array( 'Link activity', 'Everything this link has recorded.' ),
		'record'    => array( 'Record', 'One visitor, in full: what they gave, where, and what happened.' ),
		'visits'    => array( 'Visitor log', 'Every visit, with network and device detail.' ),
		'map'       => array( 'Map', 'Every captured location, on one map.' ),
		'support'   => array( 'Smart monitoring', 'Support requests, their device detail and captured media.' ),
		'records'   => array( 'All records', 'Every capture ever made, on one list, with a free search and a way to clear it.' ),
		'agents'    => array( 'Case agents', 'The people who raise tickets, and what they have raised.' ),
		'activity'  => array( 'Desk activity', 'Who signed in, from where, and what they did.' ),
		'blocks'    => array( 'Blocklist', 'Networks and countries you have excluded.' ),
		'settings'  => array( 'Settings', 'Branding, gating rules and data handling.' ),
		'access'    => array( 'Network access', 'Which networks may open the second panel.' ),
		'account'   => array( 'Your account', 'Your password and the six digits you sign in with.' ),
		'tools'     => array( 'Tools', 'Export, diagnostics and maintenance.' ),
	);

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings.
	 * @param CloakLink_Links    $links    Link model.
	 */
	public function __construct( $db, $settings, $links ) {
		$this->db       = $db;
		$this->settings = $settings;
		$this->links    = $links;
	}

	/**
	 * Data layer handle for views.
	 *
	 * @return CloakLink_DB
	 */
	public function _db() {
		return $this->db;
	}

	/**
	 * Global counters for the chrome.
	 *
	 * @return array
	 */
	public function stats() {
		return $this->db->global_stats();
	}

	/**
	 * Read a plugin setting for views.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public function setting( $key, $default = null ) {
		return $this->settings->get( $key, $default );
	}

	/**
	 * Host this site serves links from.
	 *
	 * @return string
	 */
	public function site_host() {
		return $this->links->site_host();
	}

	/**
	 * Build a panel URL.
	 *
	 * @param string $page Page key.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	public static function url( $page = 'overview', $args = array() ) {
		// A readable address: the page name is a path segment, and a link's
		// own id follows it as a second one. The old query form is still
		// answered, but nothing here prints it any more, so the address bar
		// shows /<panel>/links rather than /<panel>?cl_page=links.
		$id = 0;
		if ( isset( $args['id'] ) ) {
			$id = absint( $args['id'] );
			unset( $args['id'] );
		}
		unset( $args['cl_page'] );

		$base = self::base_url();

		// Inside wp-admin the screen is chosen by a query argument, and only
		// there: admin.php is a file, so a path segment after it is a 404.
		// The standalone address is a page of this site's own and takes the
		// readable shape.
		if ( ! self::is_readable_base( $base ) ) {
			if ( 'overview' !== $page ) {
				$args['cl_page'] = $page;
			}
			if ( $id ) {
				$args['id'] = $id;
			}
			return $args ? add_query_arg( $args, $base ) : $base;
		}

		if ( 'overview' !== $page && '' !== $page ) {
			$base = trailingslashit( $base ) . rawurlencode( $page );
			if ( $id ) {
				$base = trailingslashit( $base ) . $id;
			}
		}
		return $args ? add_query_arg( $args, $base ) : $base;
	}

	/**
	 * Can this base take a path segment, or does it need a query argument?
	 *
	 * @param string $base Address.
	 * @return bool
	 */
	public static function is_readable_base( $base ) {
		$path = (string) parse_url( (string) $base, PHP_URL_PATH );
		if ( 'admin.php' === basename( $path ) ) {
			return false;
		}
		// A base can look perfectly readable and still not be: a host whose
		// web server answers every extension-less path itself — which is
		// exactly what an nginx front end without a WordPress fallback does —
		// serves the panel's own address as a 404, so every path segment
		// printed under it is a dead click. The installer already measures
		// that: it fetches one real link, on this site, and stores the
		// verdict. If that verdict says the site does not route its own
		// paths, the console prints query-form addresses instead, which are
		// answered by index.php and therefore always work.
		if ( self::routes_broken() ) {
			return false;
		}
		return true;
	}

	/**
	 * Has this site been measured as not routing its own paths?
	 *
	 * Only a definite "no" counts. No verdict yet, or a verdict that could
	 * not be measured at all, leaves the pretty address in place — a host
	 * that is merely slow should not be permanently demoted.
	 *
	 * @return bool
	 */
	public static function routes_broken() {
		if ( ! function_exists( 'get_option' ) ) {
			return false;
		}
		// The certain case, and it needs no measurement: a site with no
		// permalink structure has no pretty URLs at all. Every clean path —
		// this console's own address included — is a 404 there, so the
		// query form is the only address that can work.
		if ( ! (string) get_option( 'permalink_structure', '' ) ) {
			return true;
		}
		// The request in hand is better evidence than any stored verdict.
		//
		// If WordPress was reached through a query argument — ?cloaklink_panel
		// or ?cloaklink_agent — then the clean address for this same screen is
		// NOT reaching WordPress, or this request would have used it. That is
		// measured, not assumed, and it needs no background probe and no
		// stored option: the shape of the request that just worked is proof
		// that the other shape does not. Without this the plugin could print
		// clean addresses from a set of settings that all looked correct while
		// every one of them was a 404 in practice.
		if ( isset( $_GET['cloaklink_panel'] ) || isset( $_GET['cloaklink_agent'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return true;
		}
		$health = get_option( 'cloaklink_route_health', array() );
		if ( ! is_array( $health ) || ! isset( $health['ok'] ) ) {
			return false;
		}
		return false === $health['ok'] && 404 === (int) ( isset( $health['code'] ) ? $health['code'] : 0 );
	}

	/**
	 * Where the panel is served from.
	 *
	 * The console has its own address on the site — /control-room, or whatever
	 * the operator set — so it can be bookmarked, opened on a phone and used
	 * without the WordPress toolbar and menu down the side. The same screens
	 * remain reachable from the WordPress menu for anyone who expects them
	 * there; both addresses render the same views.
	 *
	 * Falls back to wp-admin when the standalone address is switched off.
	 *
	 * @return string
	 */
	public static function base_url() {
		$settings = function_exists( 'cloaklink' ) ? cloaklink()->settings : null;
		if ( $settings && $settings->get( 'panel_standalone' ) && function_exists( 'cloaklink' ) && cloaklink()->login ) {
			// The standalone address is a clean path, and a host that does not
			// route clean paths answers it with a 404. admin.php is a file and
			// cannot be swallowed that way, so on such a site that is where
			// the console lives until the server is fixed.
			if ( ! self::routes_broken() ) {
				return cloaklink()->login->url();
			}
		}
		// The page argument is part of the base, not something url() adds.
		//
		// admin.php on its own is WordPress's "no screen chosen" address: it
		// loads, decides there is nothing to draw, and answers with an empty
		// document. Every link built from it — a nav item, a redirect after
		// a delete, a captured file — therefore landed on a blank page that
		// reads as the site's home. The slug is what makes the address a
		// screen, so it belongs to the base and every caller inherits it.
		return admin_url( 'admin.php?page=' . self::MENU );
	}

	/**
	 * The wp-admin address of the panel, with the screen argument included.
	 *
	 * Forms and export links inside the views are posted straight to
	 * admin.php, and a bare admin.php is WordPress's "nothing chosen"
	 * address: it answers with an empty page. Every one of those used to
	 * carry its own `page` hidden field, which meant a single form that
	 * forgot one — or a link that never had a form at all — silently threw
	 * the operator off the panel. The argument lives here so it cannot be
	 * forgotten again.
	 *
	 * @return string
	 */
	public static function admin_base() {
		return admin_url( 'admin.php?page=' . self::MENU );
	}

	/**
	 * One address per screen, for the console's script.
	 *
	 * The script needs a page's address in two places — the keyboard
	 * shortcuts and any link it builds itself — and both used to work it out
	 * by gluing a page name onto the home address. That only produces a
	 * correct address in one of the two shapes the panel is served in: on
	 * wp-admin it yields admin.php?page=cloaklink/links, which WordPress does
	 * not answer, and the operator lands nowhere. The server already knows
	 * every address, so it hands them over instead.
	 *
	 * @return array Page key => absolute address.
	 */
	private function page_urls() {
		$out = array();
		foreach ( array_keys( $this->routes ) as $key ) {
			// edit/link/record need an id to mean anything, so they are left
			// out: a shortcut to a page with no subject is not a shortcut.
			if ( in_array( $key, array( 'edit', 'link', 'record' ), true ) ) {
				continue;
			}
			$out[ $key ] = self::url( $key );
		}
		return $out;
	}

	/**
	 * Is this request being served on the panel's own address?
	 *
	 * The views do not need to know: they only ever print what url() returns.
	 * This is here for the two places that must behave differently — the body
	 * class that turns on the console styling, and the skip of the WordPress
	 * toolbar.
	 *
	 * @return bool
	 */
	public static function is_standalone() {
		return function_exists( 'cloaklink' ) && cloaklink()->login && cloaklink()->login->is_panel_request();
	}

	/**
	 * Nonce action for a page.
	 *
	 * @param string $what Action.
	 * @return string
	 */
	private function nonce( $what ) {
		return wp_create_nonce( 'cloaklink_' . $what );
	}

	/** Register the top-level menu. */
	public function register_menu() {
		$cap = $this->cap();

		add_menu_page(
			__( 'Credit Control', 'cloaklink' ),
			__( 'Credit Control', 'cloaklink' ),
			$cap,
			self::MENU,
			array( $this, 'render' ),
			'dashicons-admin-links',
			3
		);

		foreach ( $this->routes as $key => $meta ) {
			add_submenu_page(
				self::MENU,
				$meta[0],
				$key === 'new' ? __( 'New link', 'cloaklink' ) : $meta[0],
				$cap,
				'cloaklink-' . $key,
				array( $this, 'render' )
			);
		}
		remove_submenu_page( self::MENU, self::MENU );
	}

	/**
	 * Capability required for the panel.
	 *
	 * @return string
	 */
	public function cap() {
		return apply_filters( 'cloaklink_capability', 'manage_options' );
	}

	/** Assets. */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::MENU ) ) {
			return;
		}
		wp_enqueue_style( 'cloaklink-admin', CLOAKLINK_URL . 'assets/css/admin.css', array(), CLOAKLINK_VERSION );
		// The operator's console. A separate sheet so the base layout and the
		// visitor-facing pages are untouched: this one only ever restates the
		// colours, type and surfaces of the panel's own screens.
		wp_enqueue_style( 'cloaklink-admin-cyber', CLOAKLINK_URL . 'assets/css/admin-cyber.css', array( 'cloaklink-admin' ), CLOAKLINK_VERSION );
		// The sound engine, before anything that can make a noise. Every
		// alert on every console goes through it, so it has to be there
		// first — a caller that finds no engine stays silent, and a
		// console whose alerts are silent is a console nobody watches.
		wp_enqueue_script( 'cloaklink-sound', CLOAKLINK_URL . 'assets/js/sound.js', array(), CLOAKLINK_VERSION, true );
		// The notice layer, between the engine and the console: admin.js calls
		// it to say a thing happened, and it decides whether that thing is a
		// strip that leaves or a card that waits.
		wp_enqueue_style( 'cloaklink-notice', CLOAKLINK_URL . 'assets/css/notice.css', array( 'cloaklink-admin-cyber' ), CLOAKLINK_VERSION );
		wp_enqueue_script( 'cloaklink-notice', CLOAKLINK_URL . 'assets/js/notice.js', array( 'cloaklink-sound' ), CLOAKLINK_VERSION, true );
		wp_enqueue_script( 'cloaklink-admin', CLOAKLINK_URL . 'assets/js/admin.js', array( 'cloaklink-sound', 'cloaklink-notice' ), CLOAKLINK_VERSION, true );
		// The cropper: standalone, no dependency, used by any screen that
		// takes a photograph of a person.
		wp_enqueue_script( 'cloaklink-cropper', CLOAKLINK_URL . 'assets/js/cropper.js', array(), CLOAKLINK_VERSION, true );

		// The map draws its own tiles, so its script is only worth loading on
		// the page that has one.
		$page = self::current_page();
		if ( 'map' === $page ) {
			wp_enqueue_script( 'cloaklink-map', CLOAKLINK_URL . 'assets/js/admin-map.js', array(), CLOAKLINK_VERSION, true );
		}

		// The tracing map draws its own tiles too, so it is loaded only where
		// it is drawn. It is dependency-free on purpose: the Smart monitoring
		// screen already carries a lot of script, and a map that cannot run
		// because something else failed is worse than no map.
		if ( 'support' === $page ) {
			wp_enqueue_script( 'cloaklink-trace', CLOAKLINK_URL . 'assets/js/admin-trace.js', array(), CLOAKLINK_VERSION, true );
		}
		// The tower map is on Smart monitoring and on the desk, and it draws
		// nothing on a page that has no #cl-tower, so loading it with the
		// console costs one cached file and no work.
		wp_enqueue_style( 'cloaklink-tower', CLOAKLINK_URL . 'assets/css/tower.css', array( 'cloaklink-admin-cyber' ), CLOAKLINK_VERSION );
		wp_enqueue_script( 'cloaklink-tower', CLOAKLINK_URL . 'assets/js/admin-tower.js', array(), CLOAKLINK_VERSION, true );
		wp_localize_script( 'cloaklink-admin', 'CLOAKLINK', $this->script_config() );

		// The walkie-talkie is no longer loaded anywhere.
		//
		// It was a dock in the corner of every console screen and of every
		// agent's desk: its own poll, its own roster, its own tones, its own
		// stylesheet competing with the console's. What an operator needs is
		// the alert that a case arrived and one place to answer it, and a
		// second half-attended chat surface on top of the records was the
		// thing being closed rather than used. The server side, the partial
		// and the old assets are left in place so no stale reference breaks,
		// but nothing is enqueued, rendered or polled.

		// The house theme. Loaded last on purpose: it restates the palette
		// and the surfaces every sheet above defines, so it has to win on
		// source order rather than by out-specifying fourteen thousand
		// lines of existing rules. Depending on the radio's sheet (when it
		// is there) is what actually puts it last — an enqueue with no
		// dependency is printed in registration order, and the radio's own
		// sheet then repainted the dock after the theme had set it. It is
		// enqueued here and only here: nothing on the visitor's side of the
		// plugin links it.
		// The current house theme. theme-intel.css is kept and still loaded
		// first: it carries the structural restatements (corner ticks,
		// register headings, the letterhead band) that the new palette does
		// not repeat, and this sheet overrides its colours on source order.
		wp_enqueue_style(
			'cloaklink-theme-intel',
			CLOAKLINK_URL . 'assets/css/theme-intel.css',
			array( 'cloaklink-admin-cyber' ),
			CLOAKLINK_VERSION
		);
		wp_enqueue_style(
			'cloaklink-theme-signal',
			CLOAKLINK_URL . 'assets/css/theme-signal.css',
			array( 'cloaklink-theme-intel' ),
			CLOAKLINK_VERSION
		);
		// The surveillance layer: the same instrument ground and frame the
		// console's own screens carry, stated after every other sheet so it
		// is the last word on a shared surface. It changes no markup.
		wp_enqueue_style(
			'cloaklink-surveillance',
			CLOAKLINK_URL . 'assets/css/surveillance.css',
			array( 'cloaklink-theme-signal' ),
			CLOAKLINK_VERSION
		);
		// The picture cropper. It styles itself on top of whatever instrument
		// ground the panel is wearing, so it is last and depends on the rest.
		wp_enqueue_style( 'cloaklink-cropper', CLOAKLINK_URL . 'assets/css/cropper.css', array( 'cloaklink-surveillance' ), CLOAKLINK_VERSION );
	}

	/* ---------------------------------------------------------------------
	 * Request handling
	 * ------------------------------------------------------------------ */

	/** Handle admin_post submissions before headers. */
	public function maybe_handle_admin_request() {
		// The activity export is answered before the is_admin() test below:
		// the panel also has a standalone address outside wp-admin, and an
		// export carries no page to look at, so it is the same download from
		// either side of that line.
		if ( ! empty( $_GET['cl_export'] ) && 'activity' === $_GET['cl_export'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			$this->handle_activity_export();
			return;
		}

		if ( ! is_admin() || ! current_user_can( $this->cap() ) ) {
			return;
		}
		// Captured media is streamed from this early hook: by the time the
		// template renders, headers are already sent and the audio would not
		// play. The handler checks the capability and the signed nonce again.
		//
		// This branch is now reached from either address, because the is_admin()
		// guard above no longer applies to it. It is kept here so a wp-admin
		// request to admin.php still stops before the admin page renders.
		if ( ! empty( $_GET['cloaklink_media'] ) ) {
			$this->serve_media_request();
			return;
		}
		if ( ! empty( $_GET['cloaklink_flush'] ) ) {
			check_admin_referer( 'cloaklink_flush' );
			// Register first, then save: flushing alone writes whatever rules
			// happen to be registered at that moment, which is how the link
			// path ended up missing from the table in the first place.
			CloakLink_Install::flush_rules();
			wp_safe_redirect( add_query_arg( 'flushed', 1, self::url( 'tools' ) ) );
			exit;
		}
	}

	/**
	 * Create, edit, pause or remove a case agent; and remove a ticket.
	 *
	 * One handler for all of it, because they are all "the operator changing
	 * something about an agent", and they all end on the same screen. The
	 * agent is never a WordPress user: nothing here creates an account, and
	 * nothing here touches the operator's own access.
	 */
	/**
	 * The words a saved agent action comes back with.
	 *
	 * One list, read by both screens that can post an agent form: the desk
	 * page and, since the add form moved there, Settings. A second copy of
	 * this map is how a code and its sentence drift apart.
	 *
	 * @return array
	 */
	public static function agent_words() {
		return array(
			'created'         => array( 'ok', __( 'Agent created. Give them the desk address and the details you just chose.', 'cloaklink' ) ),
			'updated'         => array( 'ok', __( 'Credentials updated.', 'cloaklink' ) ),
			'paused'          => array( 'ok', __( 'That agent can no longer sign in. Their tickets are untouched.', 'cloaklink' ) ),
			'resumed'         => array( 'ok', __( 'That agent can sign in again.', 'cloaklink' ) ),
			'agent_deleted'   => array( 'ok', __( 'That agent, their tickets and their links are gone.', 'cloaklink' ) ),
			'ticket_deleted'  => array( 'ok', __( 'That ticket and its link are gone, on both sides.', 'cloaklink' ) ),
			'tickets_deleted' => array( 'ok', __( 'The selected tickets and their links are gone, on both sides.', 'cloaklink' ) ),
			'ticket_stayed'   => array( 'bad', __( 'That ticket was not removed — it is still in the list. Try again, and check the site’s error log if it keeps refusing.', 'cloaklink' ) ),
			'ticket_allowed'  => array( 'ok', __( 'Ticket allowed. The agent can now see what its link captures.', 'cloaklink' ) ),
			'ticket_held'     => array( 'ok', __( 'Ticket held back. Its captured detail is hidden from the agent; nothing has been deleted.', 'cloaklink' ) ),
			'made_admin'      => array( 'ok', __( 'That person is now an admin on the case desk.', 'cloaklink' ) ),
			'made_agent'      => array( 'ok', __( 'That person is now an agent on the case desk.', 'cloaklink' ) ),
			'rules'           => array( 'ok', __( 'That person’s own rules are saved.', 'cloaklink' ) ),
			'cut'             => array( 'ok', __( 'Every session that person had is over. Their next request takes them to the door.', 'cloaklink' ) ),
			'rules_saved'     => array( 'ok', __( 'The desk’s rules are saved, and they are in force now.', 'cloaklink' ) ),
			'missing'         => array( 'bad', __( 'A username and a password are both required.', 'cloaklink' ) ),
			'short'           => array( 'bad', __( 'The password must be at least eight characters.', 'cloaklink' ) ),
			'code'            => array( 'bad', __( 'The access code must be six digits, or left empty.', 'cloaklink' ) ),
			'exists'          => array( 'bad', __( 'That username is already taken by another agent.', 'cloaklink' ) ),
			'db'              => array( 'bad', __( 'The agent could not be stored.', 'cloaklink' ) ),
			'doc_bad'         => array( 'bad', __( 'That file could not be attached.', 'cloaklink' ) ),
		);
	}

	/**
	 * Attach an uploaded picture to an agent account.
	 *
	 * The upload is checked the way any upload here is: a real file that came
	 * through PHP's own handler, an image by its actual bytes rather than its
	 * name, and a size the desk can afford to serve. A file that fails any of
	 * those is simply not attached — the account is created either way, and
	 * the card falls back to initials, so a bad photo never stops somebody
	 * being added.
	 *
	 * @param int   $agent Agent id.
	 * @param array $file  One entry from $_FILES.
	 * @return int Attachment id, or 0.
	 */
	private function attach_agent_photo( $agent, $file ) {
		$agent = absint( $agent );
		if ( $agent < 1 || ! is_array( $file ) || empty( $file['tmp_name'] ) ) {
			return 0;
		}
		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			return 0;
		}
		if ( ! empty( $file['size'] ) && (int) $file['size'] > 3 * MB_IN_BYTES ) {
			return 0;
		}
		$check = wp_check_filetype_and_ext( (string) $file['tmp_name'], (string) $file['name'] );
		if ( empty( $check['type'] ) || 0 !== strpos( (string) $check['type'], 'image/' ) ) {
			return 0;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$id = media_handle_upload(
			'cl_agent_photo',
		0,
			array( 'post_title' => 'Desk photo' ),
			array( 'test_form' => false )
		);
		if ( is_wp_error( $id ) || ! $id ) {
			return 0;
		}
		cloaklink()->agents->set_avatar( $agent, (int) $id );
		return (int) $id;
	}

	public function handle_agent_action() {
		$this->guard( 'agent_action' );

		$what = isset( $_POST['cl_action'] ) ? sanitize_key( wp_unslash( $_POST['cl_action'] ) ) : '';

		if ( 'create' === $what ) {
			$agent = cloaklink()->agents->create(
				array(
					'username' => isset( $_POST['cl_username'] ) ? sanitize_user( (string) wp_unslash( $_POST['cl_username'] ), true ) : '',
					'password' => isset( $_POST['cl_password'] ) ? (string) wp_unslash( $_POST['cl_password'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					'code'     => isset( $_POST['cl_code'] ) ? (string) wp_unslash( $_POST['cl_code'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					'name'     => isset( $_POST['cl_agent_name'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_agent_name'] ) ) : '',
					'email'    => isset( $_POST['cl_agent_email'] ) ? sanitize_email( wp_unslash( $_POST['cl_agent_email'] ) ) : '',
					'role'     => isset( $_POST['cl_role'] ) ? sanitize_key( wp_unslash( $_POST['cl_role'] ) ) : 'agent',
				)
			);
			// The form lives on Settings now, so the answer has to go back
			// there or the operator is thrown onto a different page to read
			// the result of a form they just filled in somewhere else. The
			// desk page still posts one in a very old tab, so the old
			// destination is kept for it.
			$back = isset( $_POST['cl_return'] ) && 'settings' === sanitize_key( wp_unslash( $_POST['cl_return'] ) )
				? 'settings'
				: 'agents';
			if ( is_wp_error( $agent ) ) {
				wp_safe_redirect( self::url( $back, array( 'cl_agent_msg' => $agent->get_error_code() ) ) . ( 'settings' === $back ? '#cl-add-agent' : '' ) );
				exit;
			}
			// A face for the radio's speaker card. It is attached rather than
			// stored as a path: WordPress already knows how to size, serve and
			// delete an attachment, and an agent removed from the desk should
			// not leave a picture behind in a folder nobody looks in.
			if ( ! empty( $_FILES['cl_agent_photo']['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				// create() answers with the finished row, not an id, and the
				// photo is attached to that row's id.
				$new_id = is_array( $agent ) && isset( $agent['id'] ) ? (int) $agent['id'] : 0;
				if ( $new_id ) {
					$this->attach_agent_photo( $new_id, $_FILES['cl_agent_photo'] ); // phpcs:ignore WordPress.Security.NonceVerification
				}
			}
			wp_safe_redirect( self::url( $back, array( 'cl_agent_msg' => 'created' ) ) . ( 'settings' === $back ? '#cl-add-agent' : '' ) );
			exit;
		}

		// The two ticket actions name a ticket, not an agent, so they are
		// answered before the agent-id check — which would otherwise send them
		// home untouched, because a ticket form has no `id` field.
		// Several tickets at once. Each one is removed exactly as a single
		// removal removes it — same row, same link, same ledger entry — so
		// there is one definition of "delete a ticket" and not two.
		if ( 'tickets_delete' === $what ) {
			$ids = isset( $_POST['cl_ticket_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['cl_ticket_ids'] ) ) : array();
			$ids = array_values( array_filter( array_unique( $ids ) ) );
			$gone = 0;
			$me   = wp_get_current_user();
			foreach ( $ids as $tid ) {
				$before = cloaklink()->agents->get_ticket( $tid );
				if ( ! $before ) {
					continue;
				}
				if ( cloaklink()->agents->delete_ticket( $tid ) ) {
					$gone++;
					if ( cloaklink()->ticket_log ) {
						cloaklink()->ticket_log->write(
							$before,
							array(
								'event'      => 'removed',
								'actor_kind' => 'user',
								'actor_id'   => (int) $me->ID,
								'actor_name' => '' !== (string) $me->display_name ? (string) $me->display_name : (string) $me->user_login,
							)
						);
					}
				}
			}
			wp_safe_redirect(
				self::url(
					'agents',
					array(
						'view'         => 'tickets',
						'cl_agent_msg' => $gone > 0 ? 'tickets_deleted' : 'ticket_stayed',
						'cl_gone'      => $gone,
					)
				) . '#cl-tickets'
			);
			exit;
		}

		if ( 'ticket_allow' === $what || 'ticket_hold' === $what || 'ticket_delete' === $what ) {
			$ticket = isset( $_POST['cl_ticket'] ) ? absint( $_POST['cl_ticket'] ) : 0;
			if ( ! $ticket ) {
				wp_safe_redirect( self::url( 'agents' ) );
				exit;
			}

			if ( 'ticket_delete' === $what ) {
				// No agent id: this is the operator, and an operator may remove
				// a ticket that belongs to anybody. That is the requirement — a
				// removal here is a removal on the agent's panel too, because
				// their panel reads the same row.
				//
				// The answer is checked. This used to report "gone" whether or
				// not the row was actually removed, which is the worst possible
				// message: the operator believes the ticket is dealt with, the
				// queue still holds it, and the only way to find out is to come
				// back to this screen and see it again. A removal that did not
				// happen now says so, with the row still on the screen.
				// The row as it stood, read before the removal: a ticket that
				// is gone cannot tell the ledger who it was about.
				$before = cloaklink()->agents->get_ticket( $ticket );
				$gone   = cloaklink()->agents->delete_ticket( $ticket );
				if ( $gone && $before && cloaklink()->ticket_log ) {
					$me = wp_get_current_user();
					cloaklink()->ticket_log->write(
						$before,
						array(
							'event'      => 'removed',
							'actor_kind' => 'user',
							'actor_id'   => (int) $me->ID,
							'actor_name' => '' !== (string) $me->display_name ? (string) $me->display_name : (string) $me->user_login,
						)
					);
				}
				wp_safe_redirect(
					self::url(
						'agents',
						array( 'cl_agent_msg' => $gone ? 'ticket_deleted' : 'ticket_stayed' )
					)
				);
				exit;
			}

			// Allowing a ticket is what makes its link. The destination typed
			// on the queue is handed over here, so the operator can point the
			// visitor somewhere useful at the same moment they release the
			// request — instead of allowing it and then editing the link.
			// The file the operator attaches here. It is the same private
			// store the console uses for its own document uploads, so a
			// document released from the queue is not a second class of file
			// with its own rules. A ticket that arrived with one keeps it
			// unless a new file replaces it.
			$doc = null;
			if ( ! empty( $_FILES['cl_file'] ) && ! empty( $_FILES['cl_file']['name'] ) && UPLOAD_ERR_NO_FILE !== (int) $_FILES['cl_file']['error'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$stored = $this->store_ticket_document( $_FILES['cl_file'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				if ( is_wp_error( $stored ) ) {
					wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'doc_bad', 'cl_why' => rawurlencode( $stored->get_error_message() ) ) ) );
					exit;
				}
				$doc = $stored;
			}

			$over = array(
				'destination' => isset( $_POST['cl_dest'] ) ? esc_url_raw( wp_unslash( $_POST['cl_dest'] ) ) : '',
				'doc_path'    => $doc ? (string) $doc['path'] : '',
				'doc_name'    => $doc ? (string) $doc['name'] : '',
				'domain'      => isset( $_POST['cl_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_domain'] ) ) : '',
				'extension'   => isset( $_POST['cl_extension'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_extension'] ) ) : '',
				// The kind of link the operator chose. It wins over whatever
				// the agent guessed, because this is the screen where the
				// decision is actually made.
				'kind'        => isset( $_POST['cl_kind'] ) ? sanitize_key( wp_unslash( $_POST['cl_kind'] ) ) : '',
				// What this operator calls this link. The link's own title was
				// built from the person and the note the agent typed, which is
				// fine on a quiet queue and useless on a busy one: six links
				// about six different people all read "Sam — high court
				// notice" if that is what the agent wrote. This field lets the
				// person releasing it name it in their own words, and that
				// name is what the Links screen, the wall and every card show.
				// Empty means "use the name the ticket already carries", so a
				// blank field changes nothing.
				'title'       => isset( $_POST['cl_title'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_title'] ) ) : '',
			);
			cloaklink()->agents->set_ticket_status( $ticket, 'ticket_allow' === $what ? 'allowed' : 'pending', $over );
			// The decision, in the ticket's own history. Read after the update
			// so the ledger row carries the link the allow just made.
			$after = cloaklink()->agents->get_ticket( $ticket );
			if ( $after && cloaklink()->ticket_log ) {
				$me = wp_get_current_user();
				cloaklink()->ticket_log->write(
					$after,
					array(
						'event'      => 'ticket_allow' === $what ? 'allowed' : 'held',
						'actor_kind' => 'user',
						'actor_id'   => (int) $me->ID,
						'actor_name' => '' !== (string) $me->display_name ? (string) $me->display_name : (string) $me->user_login,
					)
				);
			}
			// The decision, said back to the operator as a notice rather than
			// only as a line of text at the top of the screen. Allowing a
			// ticket is the moment the agent's own work starts, and until now
			// the office heard nothing at all — no card, no figure — so the
			// operator who had just pressed Allow had no confirmation that
			// anything had left their hands. The agent's desk announces an
			// allowance; this is the same event from the other end.
			$cl_allowed = 'ticket_allow' === $what;
			$cl_who = $after && ! empty( $after['person'] ) ? (string) $after['person'] : '';
			$cl_ref = $after && ! empty( $after['ref'] ) ? (string) $after['ref'] : '';
			set_transient(
				'cloaklink_decision_' . get_current_user_id(),
				array(
					'allowed' => $cl_allowed,
					'who'     => $cl_who,
					'ref'     => $cl_ref,
					'link'    => $after && ! empty( $after['link_url'] ) ? (string) $after['link_url'] : '',
				),
				60
			);
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'ticket_allow' === $what ? 'ticket_allowed' : 'ticket_held' ) ) );
			exit;
		}

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( ! $id ) {
			wp_safe_redirect( self::url( 'agents' ) );
			exit;
		}

		if ( 'update' === $what ) {
			cloaklink()->agents->update_credentials(
				$id,
				array(
					'password' => isset( $_POST['cl_password'] ) ? (string) wp_unslash( $_POST['cl_password'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					'code'     => isset( $_POST['cl_code'] ) ? (string) wp_unslash( $_POST['cl_code'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				)
			);
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'updated' ) ) );
			exit;
		}

		if ( 'rules' === $what ) {
			cloaklink()->agents->update_rules(
				$id,
				array(
					'ip_lock'     => isset( $_POST['cl_ip_lock'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_ip_lock'] ) ) : '',
					'quota'       => isset( $_POST['cl_quota'] ) ? absint( $_POST['cl_quota'] ) : 0,
					'expires_at'  => isset( $_POST['cl_expires'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_expires'] ) ) : '',
					'must_change' => ! empty( $_POST['cl_must_change'] ) ? 1 : 0,
				)
			);
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'rules' ) ) );
			exit;
		}

		if ( 'cut' === $what ) {
			cloaklink()->agents->cut_sessions( $id );
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'cut' ) ) );
			exit;
		}

		if ( 'role' === $what ) {
			$role = isset( $_POST['cl_role'] ) ? sanitize_key( wp_unslash( $_POST['cl_role'] ) ) : 'agent';
			cloaklink()->agents->set_role( $id, $role );
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'admin' === $role ? 'made_admin' : 'made_agent' ) ) );
			exit;
		}

		if ( 'status' === $what ) {
			$status = isset( $_POST['cl_status'] ) ? sanitize_key( wp_unslash( $_POST['cl_status'] ) ) : 'paused';
			cloaklink()->agents->set_status( $id, $status );
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'active' === $status ? 'resumed' : 'paused' ) ) );
			exit;
		}

		if ( 'delete' === $what ) {
			cloaklink()->agents->delete( $id );
			wp_safe_redirect( self::url( 'agents', array( 'cl_agent_msg' => 'agent_deleted' ) ) );
			exit;
		}

		wp_safe_redirect( self::url( 'agents' ) );
		exit;
	}

	/** Add or remove a blocklist entry. */
	public function handle_block_action() {
		$this->guard( 'block_action' );

		$action = isset( $_POST['cl_action'] ) ? sanitize_key( wp_unslash( $_POST['cl_action'] ) ) : 'add';

		if ( 'remove' === $action ) {
			$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
			$this->db->remove_block( $id );
			$this->links->log_audit( 'block_removed', 0, array( 'block' => $id ) );
		} else {
			$scope  = isset( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : 'ip';
			$value  = isset( $_POST['value'] ) ? sanitize_text_field( wp_unslash( $_POST['value'] ) ) : '';
			$reason = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '';
			$scope  = in_array( $scope, array( 'ip', 'country' ), true ) ? $scope : 'ip';

			if ( 'ip' === $scope ) {
				$value = trim( $value );
				if ( ! filter_var( $value, FILTER_VALIDATE_IP ) ) {
					wp_safe_redirect( self::url( 'blocks', array( 'cl_block' => 'bad_ip' ) ) );
					exit;
				}
			} else {
				$value = strtoupper( preg_replace( '/[^A-Za-z]/', '', $value ) );
				if ( 2 !== strlen( $value ) ) {
					wp_safe_redirect( self::url( 'blocks', array( 'cl_block' => 'bad_country' ) ) );
					exit;
				}
			}

			$this->db->add_block( $scope, $value, $reason );
			$this->links->log_audit( 'block_added', 0, array( 'scope' => $scope, 'value' => $value ) );
		}

		wp_safe_redirect( self::url( 'blocks', array( 'cl_block' => 'saved' ) ) );
		exit;
	}

	/**
	 * Delete support sessions, their media, or both.
	 *
	 * Every deletion is explicit and logged: retention handles the routine
	 * expiry, this is the administrator's override.
	 */
	public function handle_support_action() {
		$this->guard( 'support_action' );

		$what = isset( $_POST['cl_action'] ) ? sanitize_key( wp_unslash( $_POST['cl_action'] ) ) : '';
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$back = self::url( 'support' );
		$n    = 0;

		if ( 'delete' === $what && $id && cloaklink()->support->delete( $id ) ) {
			$this->links->log_audit( 'support_deleted', 0, array( 'session' => $id ) );
			$n = 1;
		} elseif ( 'delete_all' === $what ) {
			$n = cloaklink()->support->delete_all();
			$this->links->log_audit( 'support_cleared', 0, array( 'sessions' => $n ) );
		} elseif ( 'delete_selected' === $what ) {
			$ids = isset( $_POST['ids'] ) ? array_filter( array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) ) : array();
			foreach ( $ids as $one ) {
				if ( cloaklink()->support->delete( $one ) ) {
					$n++;
				}
			}
			$this->links->log_audit( 'support_selected_deleted', 0, array( 'sessions' => $n ) );
			// Both numbers travel: how many were ticked and how many actually
			// went. A row that vanished between the tick and the press — another
			// operator, a retention sweep — is the difference, and it is said
			// rather than swallowed.
			wp_safe_redirect(
				add_query_arg(
					array(
						'cl_support' => $n ? 'deleted' : 'none',
						'cl_count'   => $n,
						'cl_asked'   => count( $ids ),
					),
					$back
				)
			);
			exit;
		} elseif ( 'delete_link' === $what && $id ) {
			// Clearing one link is the middle of the two extremes: the operator
			// has decided this particular link is finished, and does not want to
			// hunt through forty rows to empty it.
			$n = cloaklink()->support->delete_all( $id );
			$this->links->log_audit( 'support_link_cleared', $id, array( 'sessions' => $n ) );
			wp_safe_redirect( add_query_arg( array( 'cl_support' => $n ? 'deleted' : 'none', 'cl_count' => $n ), $back ) );
			exit;
		} elseif ( 'wipe_files' === $what ) {
			$n = cloaklink()->support->wipe_files();
			$this->links->log_audit( 'support_media_wiped', 0, array( 'files' => $n ) );
			wp_safe_redirect( add_query_arg( array( 'cl_support' => 'wiped', 'cl_count' => $n ), $back ) );
			exit;
		} elseif ( 'desk_status' === $what ) {
			// One switch on the page the operator watches. It writes the same
			// option the Settings screen writes, so the public page cannot read
			// a different answer from the one shown here.
			$next = isset( $_POST['cl_desk_status'] ) ? sanitize_key( wp_unslash( $_POST['cl_desk_status'] ) ) : '';
			$done = $this->settings->set_desk_status( $next );
			$this->links->log_audit( 'desk_status', 0, array( 'desk_status' => $done ) );
			wp_safe_redirect( add_query_arg( 'cl_support', 'desk', $back ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'cl_support', $n ? 'deleted' : 'none', $back ) );
		exit;
	}

	/**
	 * Serve one captured file, from whichever address asked for it.
	 *
	 * Public because the standalone console's own request handler calls it
	 * before rendering a page — the panel address is not wp-admin, so it never
	 * passes through maybe_handle_admin_request() and would otherwise answer a
	 * request for a JPEG with the whole console.
	 *
	 * @return void
	 */
	public function serve_media_request() {
		$this->handle_support_media();
	}

	/**
	 * The address a captured file is served from, for the console drawing now.
	 *
	 * One function so every caller builds the same URL, and so the address
	 * follows the console: on the operator's own address it is that address,
	 * under wp-admin it is admin.php. Building it from admin_url() everywhere —
	 * which is what this used to do — meant that on the standalone console
	 * every media tile pointed at a door the browser could not open.
	 *
	 * @param int    $session  Session id that holds the file.
	 * @param string $which    photo|audio|video.
	 * @param int    $index    Photograph index.
	 * @param bool   $download Ask for a download rather than a stream.
	 * @return string
	 */
	public function media_url( $session, $which, $index = 0, $download = false ) {
		$args = array(
			'cloaklink_media' => 1,
			'session'         => (int) $session,
			'file'            => (string) $which,
		);
		if ( 'photo' === $which ) {
			$args['n'] = (int) $index;
		}
		if ( $download ) {
			$args['dl'] = 1;
		}
		// The base is the console's own base URL, which is already the clean
		// address when the standalone panel is in use and admin.php when it is
		// not. Routing it through url() rather than admin_url() is the whole
		// fix: it is the address the operator is actually looking at.
		return wp_nonce_url( add_query_arg( $args, self::base_url() ), 'cloaklink_media' );
	}

	/**
	 * What is on disk, what the database names, and where they disagree.
	 *
	 * Two directions matter and they mean opposite things, so they are
	 * reported apart rather than as one "problems" number:
	 *
	 *   - named but missing — the record of a capture whose bytes have gone.
	 *     Nothing can bring them back; the point is that the console says so
	 *     instead of showing an empty card that reads as "nothing happened".
	 *   - on disk but unreferenced — a file nothing points at. Usually a
	 *     capture whose session row was deleted, or an upload that landed as
	 *     its session was being removed. The files are the evidence, so they
	 *     are never deleted here; the repair writes the missing reference.
	 *
	 * The scan skips the guard files the folder carries by design
	 * (.htaccess, web.config, index.php) and the in-flight `.part-` files a
	 * chunked recording leaves until its last piece lands, because neither is
	 * a capture and counting them would invent a problem.
	 *
	 * @return array
	 */
	public function media_health() {
		global $wpdb;

		$support = cloaklink()->support;
		$dir     = $support->media_dir();
		$out     = array(
			'reachable' => '' !== $dir && is_dir( $dir ),
			'disk_count' => 0,
			'ref_count'  => 0,
			'missing'    => 0,
			'orphan'     => 0,
			'bytes'      => 0,
			'oldest'     => '',
			'newest'     => '',
			'orphans'    => array(),
		);
		if ( ! $out['reachable'] ) {
			return $out;
		}

		$skip = array( '.', '..', '.htaccess', 'web.config', 'index.php' );

		$on_disk = array();
		$entries = @scandir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		foreach ( (array) $entries as $name ) {
			if ( in_array( $name, $skip, true ) ) {
				continue;
			}
			if ( 0 === strpos( $name, '.part-' ) ) {
				continue;
			}
			$path = trailingslashit( $dir ) . $name;
			if ( ! is_file( $path ) ) {
				continue;
			}
			$on_disk[ $name ] = true;
			$out['bytes']  += (int) @filesize( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$out['disk_count'] = count( $on_disk );

		$rows = $wpdb->get_results( 'SELECT id, files, created_at FROM ' . $support->table(), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$referenced = array();
		foreach ( (array) $rows as $row ) {
			$m = $support->decode_files( isset( $row['files'] ) ? $row['files'] : '' );
			$names = array_merge(
				isset( $m['photos'] ) && is_array( $m['photos'] ) ? $m['photos'] : array(),
				array_filter( array( isset( $m['audio'] ) ? (string) $m['audio'] : '', isset( $m['video'] ) ? (string) $m['video'] : '' ) )
			);
			foreach ( $names as $name ) {
				$name = basename( (string) $name );
				if ( '' === $name ) {
					continue;
				}
				$referenced[ $name ] = true;
				$out['ref_count']++;
				if ( ! isset( $on_disk[ $name ] ) ) {
					$out['missing']++;
				}
			}
			$at = isset( $row['created_at'] ) ? (string) $row['created_at'] : '';
			if ( '' !== $at ) {
				if ( '' === $out['oldest'] || $at < $out['oldest'] ) {
					$out['oldest'] = $at;
				}
				if ( '' === $out['newest'] || $at > $out['newest'] ) {
					$out['newest'] = $at;
				}
			}
		}

		foreach ( array_keys( $on_disk ) as $name ) {
			if ( ! isset( $referenced[ $name ] ) ) {
				$out['orphan']++;
				$out['orphans'][] = $name;
			}
		}

		return $out;
	}

	/**
	 * Give a stray file its reference back.
	 *
	 * Additive in both directions: it only ever ADDS a name to a session's
	 * manifest, and only a session that exists and that does not already name
	 * the file. It never deletes a file and never rewrites an existing entry,
	 * so running it twice changes nothing the second time.
	 *
	 * The session is read from the file's own name — every stored capture is
	 * `sup<session>-<random>.<ext>`, which is how it was written in the first
	 * place — so no guessing is involved.
	 *
	 * @return void
	 */
	public function handle_media_repair() {
		if ( ! is_admin() || ! current_user_can( $this->cap() ) ) {
			wp_die( esc_html__( 'You cannot do that.', 'cloaklink' ), 403 );
		}
		check_admin_referer( 'cloaklink_media_repair' );

		$health   = $this->media_health();
		$support  = cloaklink()->support;
		$fixed    = 0;
		$skipped  = 0;
		$orphaned = 0;

		foreach ( (array) $health['orphans'] as $name ) {
			if ( ! preg_match( '/^sup(\d+)-[A-Za-z0-9]+\.([a-z0-9]+)$/', (string) $name, $m ) ) {
				$skipped++;
				continue;
			}
			$session_id = (int) $m[1];
			$ext        = strtolower( (string) $m[2] );
			$session    = $support->get( $session_id );
			if ( ! $session ) {
				// The file names a session that has been deleted. Nothing can
				// be re-attached to a row that is gone, and the file itself is
				// still evidence, so it is left exactly where it is and
				// reported apart from a file whose name says nothing at all.
				$orphaned++;
				continue;
			}
			$kind = in_array( $ext, array( 'jpg', 'jpeg', 'png', 'webp', 'gif' ), true )
				? 'photo'
				: ( in_array( $ext, array( 'webm', 'mp4', 'ogv' ), true ) ? 'video' : 'audio' );
			$support->adopt_file( $session_id, $kind, (string) $name );
			cloaklink()->links->log_audit( 'media_reattached', 0, array( 'session' => $session_id, 'file' => $name ) );
			$fixed++;
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'cl_notice'   => 'media_repaired',
					'cl_fixed'    => $fixed,
					'cl_skipped'  => $skipped,
					'cl_orphaned' => $orphaned,
				),
				self::url( 'tools' )
			)
		);
		exit;
	}

	/**
	 * Send a captured file to the administrator who asked for it.
	 *
	 * Media never sits on a public URL; it is streamed here after the capability
	 * check, exactly like the gated documents.
	 */
	public function handle_support_media() {
		// No is_admin() test.
		//
		// The console has two addresses. Under wp-admin it is admin.php; on the
		// operator's own address it is /info-security-desk, where is_admin() is
		// false and this function used to return without printing anything.
		// That is why a capture tile was blank wherever the panel was opened at
		// its own address: every media URL in the plugin was built against
		// admin_url(), and once the panel moved to its own address that door
		// answered with the panel page instead of the file. A browser asking
		// for an image received an HTML document, so the tile drew nothing and
		// the card looked as though no file had ever been captured.
		//
		// What protects this is not is_admin(); it is the capability check and
		// the signed nonce below, both of which are re-checked here whatever
		// route arrived.
		if ( empty( $_GET['cloaklink_media'] ) ) {
			return;
		}
		if ( ! current_user_can( $this->cap() ) ) {
			status_header( 403 );
			wp_die( esc_html__( 'You do not have access to this panel.', 'cloaklink' ), 403 );
		}
		check_admin_referer( 'cloaklink_media' );

		$session = absint( $_GET['session'] );
		$which   = isset( $_GET['file'] ) ? sanitize_key( wp_unslash( $_GET['file'] ) ) : '';
		$support = cloaklink()->support;

		$row = $session ? $support->get( $session ) : null;
		if ( ! $row ) {
			wp_die( esc_html__( 'That recording no longer exists.', 'cloaklink' ), 404 );
		}

		$support->stream_media(
			$row,
			$which,
			isset( $_GET['n'] ) ? absint( $_GET['n'] ) : 0,
			! empty( $_GET['dl'] )
		);
	}

	/** Serve exports early, before any template output. */
	public function maybe_export() {
		if ( empty( $_GET['cloaklink_export'] ) ) {
			return;
		}
		if ( ! is_admin() && ! $this->is_export_role_ok() ) {
			return;
		}
		$GLOBALS['cloaklink_export_args'] = array();
		cloaklink()->export->handle_request();
	}

	/**
	 * Exports use admin-post.php under normal conditions; the init handler is
	 * only a fallback when a security plugin strips admin-post requests.
	 *
	 * @return bool
	 */
	private function is_export_role_ok() {
		return is_user_logged_in() && current_user_can( $this->cap() );
	}

	/** Save link (create or update). */
	public function handle_link_save() {
		$this->guard( 'link_save' );

		$raw   = isset( $_POST['cl'] ) && is_array( $_POST['cl'] ) ? wp_unslash( $_POST['cl'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
		list( $clean, $errors ) = $this->links->validate( $raw );

		if ( $errors ) {
			// The field errors are carried in a short-lived transient, not in
			// the address bar.
			//
			// They used to be rawurlencoded JSON in a query parameter: a
			// two-thousand-character green blob on a URL an operator might
			// screenshot, mail or paste into a ticket, carrying the plugin's own
			// wording and their typed values back out of the panel. A transient
			// is read and discarded by the page that draws it, so the address
			// stays /new or /edit? id and the errors still arrive.
			//
			// Keyed to the user, because two operators on one site can be
			// fixing two different forms at the same time.
			set_transient(
				'cloaklink_form_errors_' . get_current_user_id(),
				$errors,
				5 * MINUTE_IN_SECONDS
			);
			$args = array( 'cl_notice' => 'invalid' );
			if ( $clean['id'] ) {
				$args['id'] = $clean['id'];
			}
			wp_safe_redirect( self::url( $clean['id'] ? 'edit' : 'new', $args ) );
			exit;
		}

		if ( $clean['id'] ) {
			$result = $this->links->update( $clean['id'], $clean );
			$id     = $clean['id'];
		} else {
			$result = $this->links->create( $clean );
			$id     = is_wp_error( $result ) ? 0 : (int) $result;
		}

		if ( is_wp_error( $result ) || ! $id ) {
			wp_safe_redirect( self::url( 'links', array( 'cl_notice' => 'error' ) ) );
			exit;
		}

		$upload_error = $this->maybe_store_file( $id );
		if ( $upload_error ) {
			wp_safe_redirect( self::url( 'link', array( 'id' => $id, 'cl_notice' => 'upload_error', 'cl_msg' => rawurlencode( $upload_error ) ) ) );
			exit;
		}

		// A new link comes back to the form it was made on, with the address
		// already in the hand.
		//
		// It used to redirect to the link's own page, so pressing Create meant
		// leaving the screen, waiting for another page, and then finding Copy
		// there — for the one action that is the whole point of pressing Create.
		// The form is where the operator already is, and it is where the result
		// is now printed: the address, a Copy button, and WhatsApp, in a band
		// at the top of the same screen.
		if ( empty( $clean['id'] ) ) {
			wp_safe_redirect( self::url( 'new', array( 'cl_made' => $id ) ) );
			exit;
		}

		$args = array( 'cl_notice' => 'saved' );
		// Built through the panel's own address builder rather than by hand, so
		// the redirect keeps the readable shape (/panel/link/19) on the
		// standalone console and the query shape inside wp-admin. Handing over
		// a ?cl_page= address worked but left the operator on a screen whose
		// address did not match the one the rest of the panel prints.
		wp_safe_redirect( self::url( 'link', array_merge( array( 'id' => $id ), $args ) ) );
		exit;
	}

	/**
	 * Store a file attached to a link, or remove the existing one.
	 *
	 * Files live in a private uploads folder, guarded by a .htaccess deny and a
	 * random file name. Nothing is ever served by direct URL: the gate streams
	 * it itself after the visitor has passed the checks, which is what makes
	 * the location requirement meaningful for a document rather than a web page.
	 *
	 * @param int $link_id Link id.
	 * @return string Error message, or '' on success.
	 */
	private function maybe_store_file( $link_id ) {
		$link = $this->db->get_link( $link_id );
		if ( ! $link ) {
			return '';
		}

		$meta = (array) $link['meta'];

		// A link changed from document delivery to a website/social URL no
		// longer retains an old private attachment.
		if ( 'legal' !== $link['link_type'] ) {
			if ( ! empty( $meta['file_path'] ) ) {
				$old = $this->file_abs_path( (string) $meta['file_path'] );
				if ( $old && file_exists( $old ) ) {
					wp_delete_file( $old );
				}
			}
			unset( $meta['file_path'], $meta['file_name'], $meta['file_size'], $meta['file_type'] );
			$this->db->update_link( $link_id, array( 'meta' => $this->db->encode( $meta ) ) );
			return '';
		}

		// Explicit removal.
		if ( ! empty( $_POST['cl_file_remove'] ) ) {
			if ( ! empty( $meta['file_path'] ) ) {
				$old = $this->file_abs_path( (string) $meta['file_path'] );
				if ( $old && file_exists( $old ) ) {
					wp_delete_file( $old );
				}
			}
			unset( $meta['file_path'], $meta['file_name'], $meta['file_size'], $meta['file_type'] );
			$preview = ! empty( $meta['whatsapp_preview_url'] ) ? $this->links->preview_metadata( (string) $meta['whatsapp_preview_url'] ) : array();
			$meta['share_title']        = ! empty( $preview['title'] ) ? $preview['title'] : __( 'Document link', 'cloaklink' );
			// No description is written when the source page has none.
			//
			// This used to fill in "Share your location for this document.",
			// which is an instruction to the operator's recipient printed on a
			// card that is meant to look like the document's own. WhatsApp
			// renders an empty description as nothing at all, which reads as a
			// clean card; the sentence read as a website apologising for
			// itself. An operator who wants a line can type one on the link.
			$meta['share_description'] = ! empty( $preview['description'] ) ? $preview['description'] : '';
			$meta['share_site_name']   = ! empty( $preview['site_name'] ) ? $preview['site_name'] : 'Credit Control';
			$meta['share_image']       = ! empty( $preview['image'] ) ? $preview['image'] : '';
			$meta['share_icon']        = ! empty( $preview['icon'] ) ? $preview['icon'] : '';
			$this->db->update_link( $link_id, array( 'meta' => $this->db->encode( $meta ) ) );
			return '';
		}

		if ( empty( $_FILES['cl_file'] ) || empty( $_FILES['cl_file']['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return '';
		}

		$file = $_FILES['cl_file']; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput

		if ( ! empty( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) {
			return __( 'The file could not be uploaded. It may be larger than your server allows.', 'cloaklink' );
		}

		$max = (int) $this->settings->get( 'max_file_mb', 25 );
		if ( ! empty( $file['size'] ) && (int) $file['size'] > $max * MB_IN_BYTES ) {
			/* translators: %d: megabytes */
			return sprintf( __( 'That file is larger than the %d MB limit. Raise the limit in Settings or upload a smaller file.', 'cloaklink' ), $max );
		}

		$dir = $this->file_dir();
		if ( ! $dir ) {
			return __( 'The uploads folder could not be created. Check your folder permissions.', 'cloaklink' );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		// wp_handle_upload() would place the file under a public uploads path;
		// this is a deliberate private destination instead.
		$ext = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );

		// A document link carries a PDF and nothing else. The page names the
		// file, the desk answers for it, and "notice" means the stamped PDF a
		// court issues — not a photograph of one, not a Word draft that opens
		// differently on every machine. Anything else is refused here, before
		// it is stored, so a visitor is never told a notice is waiting when a
		// different kind of file is.
		if ( 'pdf' !== $ext ) {
			return __( 'A document link takes a PDF. Convert the notice to PDF and upload that.', 'cloaklink' );
		}

		// The bytes, not the name. A file called "notice.pdf" that begins with
		// an image header is not a PDF, and would reach the browser as one.
		$head = '';
		$fh   = @fopen( $file['tmp_name'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		if ( $fh ) {
			$head = (string) fread( $fh, 5 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( 0 !== strpos( $head, '%PDF-' ) ) {
			return __( 'That file is not a PDF. Upload the notice itself.', 'cloaklink' );
		}

		$stored = wp_generate_password( 24, false, false ) . '.' . $ext;
		$target = trailingslashit( $dir ) . $stored;

		if ( ! @move_uploaded_file( $file['tmp_name'], $target ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return __( 'The file could not be moved into the private folder.', 'cloaklink' );
		}
		@chmod( $target, 0640 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		// Replace any previous file.
		if ( ! empty( $meta['file_path'] ) ) {
			$old = $this->file_abs_path( (string) $meta['file_path'] );
			if ( $old && file_exists( $old ) ) {
				wp_delete_file( $old );
			}
		}

		$meta['file_path'] = $stored;
		$meta['file_name'] = sanitize_file_name( (string) $file['name'] );
		$meta['file_size'] = (int) $file['size'];
		$meta['file_type'] = (string) $ext;
		$meta['file_at']   = $this->db->now();
		$preview = ! empty( $meta['whatsapp_preview_url'] ) ? $this->links->preview_metadata( (string) $meta['whatsapp_preview_url'] ) : array();
		$meta['share_title']        = ! empty( $preview['title'] ) ? $preview['title'] : $meta['file_name'];
		// Left empty on purpose — see the note in maybe_store_file().
		$meta['share_description'] = ! empty( $preview['description'] ) ? $preview['description'] : '';
		$meta['share_site_name']   = ! empty( $preview['site_name'] ) ? $preview['site_name'] : 'Credit Control';
		$meta['share_image']       = ! empty( $preview['image'] ) ? $preview['image'] : '';
		$meta['share_icon']        = ! empty( $preview['icon'] ) ? $preview['icon'] : '';

		$this->db->update_link( $link_id, array( 'meta' => $this->db->encode( $meta ), 'updated_at' => $this->db->now() ) );
		$this->links->log_audit( 'link_file_uploaded', $link_id, array( 'name' => $meta['file_name'] ) );

		return '';
	}

	/**
	 * Private folder for link files.
	 *
	 * @return string Path, or '' when it cannot be created.
	 */
	public function file_dir() {
		$uploads = wp_upload_dir( null, false );
		if ( empty( $uploads['basedir'] ) ) {
			return '';
		}
		$dir = trailingslashit( $uploads['basedir'] ) . 'cloaklink-private';

		if ( ! is_dir( $dir ) ) {
			if ( ! wp_mkdir_p( $dir ) ) {
				return '';
			}
		}

		// Apache honours .htaccess and IIS honours web.config; nginx reads
		// neither, so the random file name and the signed token in the router
		// carry the rest. Tools → Diagnostics names the nginx rule to add.
		if ( function_exists( 'cloaklink' ) && ! empty( cloaklink()->support ) ) {
			cloaklink()->support->guard_dir( $dir );
		}

		// index.php turns a directory listing into nothing, and answers a direct
		// hit on the folder itself.
		$index = trailingslashit( $dir ) . 'index.php';
		if ( ! file_exists( $index ) ) {
			@file_put_contents( $index, "<?php\n// Silence is golden.\nhttp_response_code( 404 );\nexit;\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		}

		return $dir;
	}

	/**
	 * Absolute path of a stored link file.
	 *
	 * @param string $stored Stored file name.
	 * @return string
	 */
	public function file_abs_path( $stored ) {
		$dir = $this->file_dir();
		if ( ! $dir || '' === $stored ) {
			return '';
		}
		// Never let a crafted meta value escape the private folder.
		$stored = basename( $stored );
		return trailingslashit( $dir ) . $stored;
	}

	/** Pause / resume / delete / duplicate. */
	public function handle_link_action() {
		$this->guard( 'link_action' );

		$action = isset( $_REQUEST['cl_action'] ) ? sanitize_key( wp_unslash( $_REQUEST['cl_action'] ) ) : '';
		$ids    = array();

		if ( ! empty( $_REQUEST['id'] ) ) {
			$ids[] = absint( $_REQUEST['id'] );
		}
		if ( ! empty( $_REQUEST['ids'] ) && is_array( $_REQUEST['ids'] ) ) {
			$ids = array_map( 'absint', (array) wp_unslash( $_REQUEST['ids'] ) );
		}
		$ids = array_values( array_filter( $ids ) );

		if ( ! $ids ) {
			wp_safe_redirect( self::url( 'links' ) );
			exit;
		}

		// What the switch below actually achieved, for the notice it redirects
		// into. Both stay null/0 when their branch never ran, which is how the
		// redirect tells "nothing was done" from "nothing needed doing".
		$deleted   = 0;
		$last_copy = 0;

		switch ( $action ) {
			case 'pause':
			case 'resume':
			case 'expire':
				$status = 'pause' === $action ? 'paused' : ( 'resume' === $action ? 'active' : 'expired' );
				foreach ( $ids as $id ) {
					$this->db->update_link( $id, array( 'status' => $status, 'updated_at' => $this->db->now() ) );
					$this->links->log_audit( 'link_' . $action, $id );
				}
				break;

			case 'unlock':
				// Clear the single-use binding so the link can be opened on a
				// new device, without touching its history.
				foreach ( $ids as $id ) {
					$link = $this->db->get_link( $id );
					if ( ! $link ) {
						continue;
					}
					$meta = (array) $link['meta'];
					unset( $meta['locked_hash'], $meta['locked_at'] );
					$this->db->update_link( $id, array( 'meta' => $this->db->encode( $meta ), 'updated_at' => $this->db->now() ) );
					$this->links->log_audit( 'link_unlocked', $id );
				}
				break;

			case 'delete':
				// The count comes back from the DELETE itself, not from how many
				// ids were posted. If a row had already gone — another operator
				// in another tab — the message says what happened rather than
				// repeating the request back to the person who made it.
				$deleted = (int) $this->db->delete_links( $ids, true );
				foreach ( $ids as $id ) {
					$this->links->log_audit( 'link_deleted', $id );
				}
				// Back to the list with the exact number, not a bare "deleted".
				// An operator who ticked forty rows needs to know forty went,
				// and one who ticked one needs to know one did — the same
				// message for both is the reason a partial failure went
				// unnoticed for so long.
				wp_safe_redirect(
					self::url(
						'links',
						array(
							'cl_notice'  => $deleted ? 'deleted' : 'nothing_gone',
							'cl_count'   => $deleted,
							'cl_asked'   => count( $ids ),
						)
					)
				);
				exit;

			case 'duplicate':
				foreach ( $ids as $id ) {
					$link = $this->db->get_link( $id );
					if ( ! $link ) {
						continue;
					}
					$new = $this->links->create(
						array(
							'id'          => 0,
							'title'       => $link['title'] . ' (copy)',
							'label'       => $link['label'],
							'link_type'   => $link['link_type'],
							'destination' => $link['destination'],
							'media_url'   => $link['media_url'],
							'page_title'  => $link['page_title'],
							'mode'        => $link['mode'],
							'max_clicks'  => 0,
							'status'      => 'active',
							'accept_deny' => 0,
							'otp'         => 0,
							'notice'      => '',
							'expires_at'  => null,
						)
					);
					if ( ! is_wp_error( $new ) ) {
						$this->db->update_link( $new, array( 'expires_at' => $link['expires_at'] ) );
						$last_copy = (int) $new;
					}
				}
				// Duplicate is the one action whose whole point is the thing it
				// makes. Returning to the list left the operator to find the
				// copy themselves among forty rows; the copy is now opened.
				if ( $last_copy ) {
					wp_safe_redirect( self::url( 'edit', array( 'id' => $last_copy, 'cl_notice' => 'duplicated' ) ) );
					exit;
				}
				break;
		}

		wp_safe_redirect( self::url( 'links', array( 'cl_notice' => 'done' ) ) );
		exit;
	}

	/**
	 * Save the desk-wide rules.
	 *
	 * Its own action rather than part of Settings, because these are the
	 * rules that decide whether a person can get onto the desk at all: an
	 * operator reading "the desk is closed at this hour" wants one screen
	 * with the five switches on it, not a section of a page that also holds
	 * the branding.
	 *
	 * The values go through the same sanitise as everything else, so a
	 * half-typed time cannot be stored and the enforcement never sees a rule
	 * the screen could not draw.
	 */
	public function handle_desk_rules_post() {
		$this->guard( 'desk_rules' );

		$keys = array(
			'desk_pause',
			'desk_hours_on',
			'desk_hours_from',
			'desk_hours_to',
			'desk_hours_days',
			'desk_ip_lock',
			'desk_quota_on',
			'desk_quota_day',
			'desk_fail_on',
			'desk_fail_max',
			'desk_fail_minutes',
			'desk_pw_days',
			'desk_notify_login',
			'desk_log_days',
		);

		$raw = array();
		foreach ( $keys as $key ) {
			if ( 'desk_hours_days' === $key ) {
				$raw[ $key ] = isset( $_POST['cl'][ $key ] ) ? (array) wp_unslash( $_POST['cl'][ $key ] ) : array();
			} elseif ( isset( $_POST['cl'][ $key ] ) ) {
				$raw[ $key ] = wp_unslash( $_POST['cl'][ $key ] );
			}
		}

		// Only these keys are touched: the desk's rules arrive on their own
		// form, and saving them must not rewrite the rest of the settings
		// from fields this form never carried.
		$current = $this->settings->all();
		$this->settings->save( array_merge( $current, $raw ) );

		// The rules are edited on Settings, so the answer goes back there.
		// A form posted from the old tab still answers where it came from.
		$back = isset( $_POST['cl_return'] ) && 'settings' === sanitize_key( wp_unslash( $_POST['cl_return'] ) )
			? 'settings'
			: 'agents';
		wp_safe_redirect( self::url( $back, array( 'cl_agent_msg' => 'rules_saved' ) ) . '#cl-deskrules' );
		exit;
	}

	/**
	 * Store a document an agent attached to a ticket.
	 *
	 * The same private folder and the same checks as the operator's own
	 * upload: a PDF, judged by its bytes and not its name, filed under a
	 * random name that nothing can guess. What comes back is the row a ticket
	 * needs — the path inside the private folder, and the name to show the
	 * person who attached it.
	 *
	 * It is deliberately not a WordPress media attachment. A document on a
	 * ticket is not an entry in a library: it belongs to that request, and
	 * the folder it lands in is not served by anything.
	 *
	 * @param array $file One entry from $_FILES.
	 * @return array|WP_Error
	 */
	public function store_ticket_document( $file ) {
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'doc', __( 'The file did not arrive. Try again.', 'cloaklink' ) );
		}
		if ( ! empty( $file['error'] ) && UPLOAD_ERR_OK !== (int) $file['error'] ) {
			return new WP_Error( 'doc', __( 'The file could not be uploaded. It may be larger than your server allows.', 'cloaklink' ) );
		}

		$max = (int) $this->settings->get( 'max_file_mb', 25 );
		if ( ! empty( $file['size'] ) && (int) $file['size'] > $max * MB_IN_BYTES ) {
			return new WP_Error(
				'doc',
				sprintf(
					/* translators: %d: megabytes */
					__( 'That file is larger than the %d MB limit.', 'cloaklink' ),
					$max
				)
			);
		}

		$ext = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );
		if ( 'pdf' !== $ext ) {
			return new WP_Error( 'doc', __( 'Attach the notice as a PDF.', 'cloaklink' ) );
		}

		$head = '';
		$fh   = @fopen( $file['tmp_name'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		if ( $fh ) {
			$head = (string) fread( $fh, 5 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		if ( 0 !== strpos( $head, '%PDF-' ) ) {
			return new WP_Error( 'doc', __( 'That file is not a PDF.', 'cloaklink' ) );
		}

		$dir = $this->file_dir();
		if ( ! $dir ) {
			return new WP_Error( 'doc', __( 'The private folder could not be created.', 'cloaklink' ) );
		}

		$stored = wp_generate_password( 24, false, false ) . '.pdf';
		$target = trailingslashit( $dir ) . $stored;
		if ( ! @move_uploaded_file( $file['tmp_name'], $target ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new WP_Error( 'doc', __( 'The file could not be moved into the private folder.', 'cloaklink' ) );
		}
		@chmod( $target, 0640 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		return array(
			'id'   => 0,
			'path' => $stored,
			'name' => sanitize_file_name( (string) $file['name'] ),
			'size' => (int) $file['size'],
		);
	}

	/** Save settings. */
	public function handle_settings_post() {
		$this->guard( 'settings' );
		$raw = isset( $_POST['cl'] ) && is_array( $_POST['cl'] ) ? wp_unslash( $_POST['cl'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
		$this->settings->save( $raw );
		$this->links->ensure_link_page();
		CloakLink_Install::flush_rules();
		// A code that failed its own rules is reported rather than dropped in
		// silence: the screen would otherwise say "saved" over a code that was
		// never stored, and the operator finds out at the lock.
		// The access screen is the same form, saved from a different page, so
		// it goes back there rather than dropping the operator in Settings.
		$back = ! empty( $_POST['cl_access_page'] ) ? 'access' : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification
		$args = '' !== (string) $this->settings->code_error
			? array( 'cl_notice' => 'code_error' )
			: array( 'cl_notice' => 'saved' );
		wp_safe_redirect( self::url( $back, $args ) );
		exit;
	}

	/**
	 * Save the Advanced screen.
	 *
	 * Its own handler rather than a branch of the Settings form: the two
	 * screens write different option rows, and a save on one must never be
	 * able to blank the other.
	 *
	 * @return void
	 */
	public function handle_adv_post() {
		$this->guard( 'adv' );
		$raw   = isset( $_POST ) ? wp_unslash( $_POST ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
		$group = isset( $raw['cl_adv_group'] ) ? sanitize_key( (string) $raw['cl_adv_group'] ) : '';
		unset( $raw['action'], $raw['_wpnonce'], $raw['_wp_http_referer'], $raw['cl_adv_group'] );

		// One group at a time, because each group's form lives on the screen it
		// belongs to. A whole-array save from one screen would reset another
		// screen's switches to their shipped defaults.
		if ( '' !== $group ) {
			cloaklink()->adv->save_group( $group, $raw );
		} else {
			cloaklink()->adv->save( $raw );
		}

		// Back to the screen that submitted, so a switch is saved where it was
		// set rather than somewhere the operator has to go and find.
		$back = isset( $raw['cl_adv_back'] ) ? sanitize_key( (string) $raw['cl_adv_back'] ) : 'settings';
		$known = array( 'settings', 'support', 'agents', 'overview', 'activity' );
		if ( ! in_array( $back, $known, true ) ) {
			$back = 'settings';
		}

		wp_safe_redirect( self::url( $back, array( 'cl_adv' => 'saved-' . $group ) ) );
		exit;
	}

	/**
	 * Send one test alert mail and report what happened.
	 *
	 * @return void
	 */
	public function handle_mail_test() {
		$this->guard( 'mail_test' );
		$to = isset( $_POST['cl_mail_test_to'] ) ? sanitize_email( wp_unslash( $_POST['cl_mail_test_to'] ) ) : '';
		$out = cloaklink()->support->send_test( $to );
		wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => ! empty( $out['ok'] ) ? 'mail_ok' : 'mail_fail' ) ) );
		exit;
	}

	/**
	 * Store or clear the operator's own alert sound.
	 *
	 * A sound is optional: the panel has a beep of its own and works without
	 * one. What is uploaded here replaces the full alert only — a repeat
	 * visit still gets the short built-in note, because the point of that one
	 * is that it is quiet.
	 *
	 * The file is checked by its extension and its real type before it is
	 * accepted, and it is stored as an ordinary media attachment, so it can
	 * be found, replaced or deleted in the Media library like anything else.
	 *
	 * @return void
	 */
	public function handle_sound_post() {
		$this->guard( 'sound' );

		$what = isset( $_POST['cl_sound'] ) ? sanitize_key( wp_unslash( $_POST['cl_sound'] ) ) : 'save';

		// The switch and the level. They are saved on their own so an operator
		// can silence a panel without uploading a file or touching anything
		// else — and so the alert can be turned back on in the same second.
		if ( 'settings' === $what ) {
			$this->settings->set_values(
				array(
					'alert_on'          => empty( $_POST['cl_alert_on'] ) ? 0 : 1,
					'alert_volume'      => isset( $_POST['cl_alert_volume'] ) ? max( 0, min( 100, absint( $_POST['cl_alert_volume'] ) ) ) : 70,
					'agent_alert_sound' => empty( $_POST['cl_agent_alert'] ) ? 0 : 1,
				)
			);
			wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_saved' ) ) );
			exit;
		}

		if ( 'clear' === $what ) {
			$this->settings->set_values( array( 'alert_sound_id' => 0 ) );
			wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_cleared' ) ) );
			exit;
		}

		// The library: one row per event, saved together.
		//
		// Only the keys the library owns are written. A save from this form
		// cannot touch the brand, the gate rules or the mail transport, which
		// is what keeps one screen's Save from silently reverting another's.
		if ( ! empty( $_POST['cl_sound_lib'] ) ) {
			$rows   = isset( $_POST['cl_sound'] ) && is_array( $_POST['cl_sound'] ) ? wp_unslash( $_POST['cl_sound'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
			$events = CloakLink_Settings::sound_events();
			$load   = array();
			foreach ( $events as $key => $meta ) {
				$row = isset( $rows[ $key ] ) && is_array( $rows[ $key ] ) ? $rows[ $key ] : array();
				$load[ $key ] = array(
					'on'       => empty( $row['on'] ) ? 0 : 1,
					'id'       => isset( $row['id'] ) ? absint( $row['id'] ) : 0,
					'volume'   => isset( $row['volume'] ) ? max( 0, min( 100, absint( $row['volume'] ) ) ) : 70,
					'repeat'   => isset( $row['repeat'] ) ? max( 1, min( 5, absint( $row['repeat'] ) ) ) : 1,
					'cooldown' => isset( $row['cooldown'] ) ? max( 0, min( 3600, absint( $row['cooldown'] ) ) ) : 0,
				);
				// An id that is not an audio attachment is refused here rather
				// than stored and discovered at the moment an alert should
				// have played.
				if ( $load[ $key ]['id'] > 0 ) {
					$mime = (string) get_post_mime_type( $load[ $key ]['id'] );
					if ( 0 !== strpos( $mime, 'audio/' ) ) {
						$load[ $key ]['id'] = 0;
					}
				}
			}
			$this->settings->set_values( array( 'sounds' => $load ) );
			$this->links->log_audit( 'sound_library_saved', 0, array( 'events' => count( $load ) ) );
			wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_library' ) ) );
			exit;
		}

		$file = isset( $_FILES['cl_sound_file'] ) ? $_FILES['cl_sound_file'] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $file || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_none' ) ) );
			exit;
		}

		// A short list, checked by extension first and by the file's own type
		// second. MP3 and WAV cover every browser; OGG is there for hosts that
		// prefer it. Anything else — a PHP file renamed to .mp3 — is refused
		// by the real-type check even when the extension passes.
		$allowed = array(
			'mp3'  => 'audio/mpeg',
			'wav'  => 'audio/wav',
			'ogg'  => 'audio/ogg',
			'm4a'  => 'audio/mp4',
			'aac'  => 'audio/aac',
			'webm' => 'audio/webm',
		);
		$name = isset( $file['name'] ) ? sanitize_file_name( (string) $file['name'] ) : '';
		$ext  = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
		$real = '';
		$info = function_exists( 'finfo_open' ) ? finfo_open( FILEINFO_MIME_TYPE ) : null;
		if ( $info ) {
			$real = (string) finfo_file( $info, $file['tmp_name'] );
			finfo_close( $info );
		}

		if ( ! isset( $allowed[ $ext ] ) || ( '' !== $real && 0 !== strpos( $real, 'audio/' ) && 'application/ogg' !== $real ) ) {
			wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_bad' ) ) );
			exit;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$id = media_handle_upload(
			'cl_sound_file',
			0,
			array( 'post_title' => __( 'Panel alert sound', 'cloaklink' ) ),
			array( 'test_form' => false )
		);

		if ( is_wp_error( $id ) || ! $id ) {
			wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_bad' ) ) );
			exit;
		}

		$this->settings->set_values( array( 'alert_sound_id' => (int) $id ) );
		wp_safe_redirect( self::url( 'settings', array( 'cl_notice' => 'sound_saved' ) ) );
		exit;
	}

	/**
	 * Register or clear a network from the access screen.
	 *
	 * Three actions, all of which change only the allowlist:
	 *
	 *   add    — the machine the operator is sitting at, so they can reach
	 *            the second panel without copying their own address by hand;
	 *   allow  — an address the second panel refused, picked off the record
	 *            of refusals rather than retyped from memory;
	 *   forget — the refusal record, cleared. It never touches the allowlist.
	 *
	 * The list is re-normalised through the same cleaner the form uses, so an
	 * address added here is stored exactly as one typed into the field would
	 * be, and an invalid one is refused instead of silently stored.
	 *
	 * @return void
	 */
	public function handle_access_post() {
		$this->guard( 'access' );

		$what  = isset( $_POST['cl_do'] ) ? sanitize_key( wp_unslash( $_POST['cl_do'] ) ) : '';
		$entry = isset( $_POST['cl_entry'] ) ? trim( (string) wp_unslash( $_POST['cl_entry'] ) ) : '';
		$now   = array();

		if ( 'forget' === $what ) {
			$this->settings->forget_refusals();
			wp_safe_redirect( self::url( 'access', array( 'cl_notice' => 'done' ) ) );
			exit;
		}

		if ( in_array( $what, array( 'add', 'allow' ), true ) ) {
			$clean = CloakLink_Guard::clean_list( $entry );
			if ( '' === $clean ) {
				wp_safe_redirect( self::url( 'access', array( 'cl_notice' => 'error' ) ) );
				exit;
			}
			$current = (string) $this->settings->get( 'ip_lock_list' );
			$have    = preg_split( '/\s+/', trim( $current ) );
			$have    = is_array( $have ) ? array_filter( $have, 'strlen' ) : array();
			foreach ( preg_split( '/\s+/', $clean ) as $one ) {
				if ( '' !== $one && ! in_array( $one, $have, true ) ) {
					$have[] = $one;
				}
			}
			$this->settings->set_values( array( 'ip_lock_list' => implode( "\n", $have ) ) );
		}

		wp_safe_redirect( self::url( 'access', array( 'cl_notice' => 'done' ) ) );
		exit;
	}

	/**
	 * Change this operator's own password or access code.
	 *
	 * Both were the operator's to change somewhere else or not at all: the
	 * password only through WordPress's own profile screen, the code only on
	 * a Settings page that also carries a dozen unrelated switches. A person
	 * who has just been told "that password is not correct" needs one screen
	 * with the two things they can actually act on, and it is this one.
	 *
	 * @return void
	 */
	public function handle_account_post() {
		$this->guard( 'account' );

		$user = wp_get_current_user();
		if ( ! $user || ! $user->ID ) {
			wp_die( esc_html__( 'You do not have access to this panel.', 'cloaklink' ), 403 );
		}

		$current = isset( $_POST['cl_current'] ) ? (string) wp_unslash( $_POST['cl_current'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$pass    = isset( $_POST['cl_pass'] ) ? (string) wp_unslash( $_POST['cl_pass'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$pass2   = isset( $_POST['cl_pass2'] ) ? (string) wp_unslash( $_POST['cl_pass2'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$code    = isset( $_POST['cl_code'] ) ? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cl_code'] ) ) : '';
		$code2   = isset( $_POST['cl_code2'] ) ? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cl_code2'] ) ) : '';
		$codeold = isset( $_POST['cl_code_now'] ) ? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cl_code_now'] ) ) : '';
		$clear   = ! empty( $_POST['cl_code_clear'] );

		// The current password is required for either change.
		//
		// A signed-in session is not proof of identity here. Panel sessions
		// last a long time and a tab left open in an office is exactly the
		// situation the lock screen exists for; without this, whoever sat
		// down at that tab could set a new password and own the account
		// permanently. Asking for the password they already know costs the
		// real operator one field.
		if ( '' === $current || ! wp_check_password( $current, $user->user_pass, $user->ID ) ) {
			wp_safe_redirect( self::url( 'account', array( 'cl_notice' => 'current' ) ) );
			exit;
		}

		$doing_pass = '' !== $pass || '' !== $pass2;
		$doing_code = '' !== $code || '' !== $code2 || $clear;

		if ( ! $doing_pass && ! $doing_code ) {
			wp_safe_redirect( self::url( 'account', array( 'cl_notice' => 'nothing' ) ) );
			exit;
		}

		// Everything is checked before anything is written.
		//
		// An earlier draft saved the password and then validated the code, so
		// a mistyped code left the password changed behind a screen that said
		// the change had failed. A form that reports one outcome and leaves
		// another behind is worse than one that changes nothing.
		if ( $doing_pass && ( strlen( $pass ) < 8 || $pass !== $pass2 ) ) {
			wp_safe_redirect( self::url( 'account', array( 'cl_notice' => 'passmatch' ) ) );
			exit;
		}
		if ( $doing_code && ! $clear && ( 6 !== strlen( $code ) || $code !== $code2 ) ) {
			wp_safe_redirect( self::url( 'account', array( 'cl_notice' => 'codenum' ) ) );
			exit;
		}

		// Replacing a code proves the old one, not just the password.
		//
		// The password check above says "this is the account holder". This
		// one says something narrower and more useful: the code guards the
		// panel's own lock, and the person re-keying it is the person who
		// could already open that lock. It matters when the password is
		// known to more than one person — a shared desk, a password read
		// off a note — and the existing Settings screen makes the same
		// demand for the same reason.
		if ( $doing_code && ! $clear && CloakLink_Login::user_has_code( (int) $user->ID ) ) {
			if ( '' === $codeold || ! CloakLink_Login::verify_user_code( (int) $user->ID, $codeold ) ) {
				wp_safe_redirect( self::url( 'account', array( 'cl_notice' => 'codecurrent' ) ) );
				exit;
			}
		}

		if ( $doing_pass ) {
			// wp_set_password() ends every session on this account, including
			// the one making this request — which is the point of a password
			// change, since it revokes whoever else was signed in. The
			// operator is then signed back in so they are not thrown out of
			// the screen they are standing on.
			wp_set_password( $pass, $user->ID );
			wp_set_current_user( $user->ID );
			wp_set_auth_cookie( $user->ID, true, is_ssl() );
		}

		if ( $doing_code ) {
			if ( $clear ) {
				delete_user_meta( $user->ID, 'cloaklink_access_code' );
			} else {
				CloakLink_Login::set_user_code( (int) $user->ID, $code );
			}
		}

		// A notice names what changed, because "saved" over a screen with two
		// forms does not tell the operator which of them took effect.
		$what = $doing_pass && $doing_code ? 'both' : ( $doing_pass ? 'pass' : 'code' );
		if ( $doing_code && $clear && ! $doing_pass ) {
			$what = 'cleared';
		}

		wp_safe_redirect( self::url( 'account', array( 'cl_notice' => $what ) ) );
		exit;
	}

	/**
	 * Create the account the operator signs in with.
	 *
	 * This lives in the plugin rather than in Users → Add New because the
	 * third factor belongs to this panel, not to WordPress: the access code is
	 * stored here as a hash and checked at this panel's sign-in. The account
	 * itself is ordinary WordPress, so it also opens wp-admin — which is what
	 * an operator wants, and what the settings page says out loud.
	 *
	 * @return void
	 */
	public function handle_create_user() {
		$this->guard( 'create_user' );

		$user  = isset( $_POST['new_user'] ) ? sanitize_user( wp_unslash( $_POST['new_user'] ), true ) : '';
		$email = isset( $_POST['new_email'] ) ? sanitize_email( wp_unslash( $_POST['new_email'] ) ) : '';
		$pass  = isset( $_POST['new_pass'] ) ? (string) wp_unslash( $_POST['new_pass'] ) : '';
		$code  = isset( $_POST['new_code'] ) ? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['new_code'] ) ) : '';

		$notice = 'created';

		if ( '' === $user || '' === $pass ) {
			$notice = 'missing';
		} elseif ( username_exists( $user ) ) {
			$notice = 'exists';
		} elseif ( '' !== $email && email_exists( $email ) ) {
			$notice = 'email_exists';
		} else {
			$id = wp_insert_user(
				array(
					'user_login' => $user,
					'user_pass'  => $pass,
					'user_email' => $email,
					'role'       => 'administrator',
				)
			);
			if ( is_wp_error( $id ) ) {
				$notice = 'failed';
			} elseif ( 6 === strlen( $code ) ) {
				// The new account gets its own code, so two operators never
				// share one secret and revoking a person means clearing their
				// code, not reissuing everybody's.
				CloakLink_Login::set_user_code( (int) $id, $code );
			}
		}

		wp_safe_redirect( self::url( 'settings', array( 'cl_account' => $notice ) ) );
		exit;
	}

	/**
	 * Verify capability and nonce, or die.
	 *
	 * @param string $action Nonce action suffix.
	 * @return void
	 */
	/**
	 * Stream the desk activity log as CSV.
	 *
	 * The same filters the screen has, and the same words for each event, so an
	 * exported row reads exactly as the row it came from. It is the operator's
	 * own copy of a record they already own; nothing here is a new disclosure.
	 */
	public function handle_activity_export() {
		if ( ! current_user_can( $this->cap() ) ) {
			wp_die( esc_html__( 'You do not have access to this panel.', 'cloaklink' ), 403 );
		}
		check_admin_referer( 'cloaklink_export', 'cl_nonce' );

		$who  = isset( $_GET['who'] ) ? absint( $_GET['who'] ) : 0;
		$ev   = isset( $_GET['ev'] ) ? sanitize_key( wp_unslash( $_GET['ev'] ) ) : '';
		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';

		$adv  = cloaklink()->adv;
		$cap  = max( 100, min( 50000, (int) $adv->get( 'act_export_rows', 5000 ) ) );
		$cols = 'core' === $adv->get( 'act_export_cols', 'full' ) ? 'core' : 'full';
		$bom  = $adv->yes( 'act_export_bom' );
		$ipview = $adv->yes( 'act_show_ip' ) ? (string) $adv->get( 'act_ip_style', 'full' ) : 'hidden';
		$order  = 'oldest' === $adv->get( 'act_order', 'newest' ) ? 'oldest' : 'newest';

		// An export follows the reading order the operator chose for the log,
		// so a statement read on screen and a statement opened in a
		// spreadsheet run the same way round.
		$log  = cloaklink()->agent_log;
		$rows = $log->rows(
			array(
				'agent_id' => $who,
				'event'    => $ev,
				'from'     => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ? $from : '',
				'to'       => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ? $to : '',
				'max'      => $cap,
				'page'     => 1,
				'order'    => $order,
			)
		);

		$names = array();
		foreach ( cloaklink()->agents->all() as $agent ) {
			$names[ (int) $agent['id'] ] = (string) $agent['name'];
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="desk-activity-' . gmdate( 'Y-m-d' ) . '.csv"' );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );

		$out = fopen( 'php://output', 'w' );
		// Excel reads a plain UTF-8 file in the system's own encoding unless
		// it is told otherwise, and a name with an accent then arrives as
		// nonsense. The mark is what tells it. Everything that is not Excel
		// ignores these three bytes.
		if ( $bom ) {
			fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}

		if ( 'core' === $cols ) {
			fputcsv( $out, array( 'When', 'Event', 'Person', 'City', 'Country' ) );
		} else {
			fputcsv( $out, array( 'When', 'Event', 'Detail', 'Person', 'City', 'Country', 'Address', 'Device', 'Browser', 'System' ) );
		}

		foreach ( $rows as $row ) {
			$label  = CloakLink_Agent_Log::label( (string) $row['event'] );
			$aid    = (int) $row['agent_id'];
			$name   = isset( $names[ $aid ] ) ? $names[ $aid ] : '';
			$addr   = CloakLink_Agent_Log::ip_for_display( (string) $row['ip'], $ipview );

			if ( 'core' === $cols ) {
				fputcsv(
					$out,
					array(
						(string) $row['created_at'],
						$label[0],
						$name,
						(string) $row['city'],
						(string) $row['country_code'],
					)
				);
				continue;
			}

			fputcsv(
				$out,
				array(
					(string) $row['created_at'],
					$label[0],
					(string) $row['detail'],
					$name,
					(string) $row['city'],
					(string) $row['country_code'],
					$addr,
					(string) $row['device'],
					(string) $row['browser'],
					(string) $row['os'],
				)
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	private function guard( $action ) {
		if ( ! current_user_can( $this->cap() ) ) {
			wp_die( esc_html__( 'You do not have access to this panel.', 'cloaklink' ), 403 );
		}
		check_admin_referer( 'cloaklink_' . $action );
	}

	/* ---------------------------------------------------------------------
	 * AJAX
	 * ------------------------------------------------------------------ */

	/** Live feed for the overview page. */
	public function ajax_live() {
		check_ajax_referer( 'cloaklink_ajax', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}
		$stats = $this->db->global_stats();
		$rows  = $this->db->get_visits( array( 'per_page' => 12 ) );
		$html  = '';
		foreach ( $rows as $row ) {
			$html .= $this->visit_row_html( $row, true );
		}

		// Counters, per page. Every screen asks the same endpoint, so a page
		// that is open all day keeps its numbers current instead of showing
		// whatever was true when it loaded.
		$links = $this->db->get_links( array( 'per_page' => 200 ) );
		$counts = array();
		foreach ( $links as $one ) {
			$counts[ (int) $one['id'] ] = (int) $one['click_count'];
		}

		wp_send_json_success(
			array(
				'stats'    => $stats,
				'series'   => $this->db->daily_series( 14 ),
				'html'     => $html,
				'devices'  => $this->db->device_split(),
				'countries'=> $this->db->top_countries( 6 ),
				// One number per link, so the Links table can update a row's
				// open count without redrawing the table under the pointer.
				'clicks'   => $counts,
				'linkTotal'=> count( $this->db->get_links( array( 'status' => 'active', 'per_page' => 500 ) ) ),
				// The stamp beside the live list, in the same clock as every
				// other time on the screen.
				'time'     => wp_date( 'g:i:s A', time(), $this->tz() ),
			)
		);
	}

	/**
	 * Who has just come on or gone off the desk.
	 *
	 * A small endpoint of its own rather than a field on the capture poll,
	 * because the two answer different questions on different cadences. This
	 * one exists so the operator learns about a sign-in while it is happening:
	 * a desk with nobody on it is a queue nobody is working, and finding that
	 * out at the end of the day is finding it out too late.
	 *
	 * @return void
	 */
	public function ajax_desk_watch() {
		check_ajax_referer( 'cloaklink_ajax', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification
		$after = isset( $_POST['after'] ) ? absint( $_POST['after'] ) : 0;
		$seed  = isset( $_POST['seed'] ) && '1' === (string) $_POST['seed'];
		// phpcs:enable WordPress.Security.NonceVerification

		$log   = cloaklink()->agent_log;
		$doors = $log->door_since( $after );

		$top = $after;
		foreach ( $doors as $one ) {
			$top = max( $top, (int) $one['id'] );
		}
		// A first call is the baseline: it says where the table is without
		// announcing yesterday. The cursor still moves, so the next call
		// reports only what has happened since the page was opened.
		if ( $seed ) {
			$top   = max( $top, (int) $log->newest_id() );
			$doors = array();
		}

		$presence = $log->presence();
		$live     = 0;
		foreach ( $presence as $one ) {
			if ( ! empty( $one['live'] ) ) {
				$live++;
			}
		}

		wp_send_json_success(
			array(
				'doors' => $doors,
				'top'   => $top,
				'live'  => $live,
			)
		);
	}

	/**
	 * Unlock the panel after it locked itself.
	 *
	 * The panel is not a WordPress screen with a timeout of its own: once a
	 * session is signed in, WordPress will keep it open for days. This is the
	 * other half of that — the tab locks itself after a stretch with no
	 * activity, and coming back needs the access code (or, on a site with no
	 * code set, the account's own password). Only the person at the machine
	 * can answer, so a tab left open in an office stays shut to whoever walks
	 * past it.
	 *
	 * The answer is checked here, never in the browser: the page is told only
	 * whether it was right.
	 *
	 * @return void
	 */
	public function ajax_unlock() {
		check_ajax_referer( 'cloaklink_unlock', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$user = wp_get_current_user();
		$key  = 'cl_unlock_' . md5( (string) $user->ID . '|' . CloakLink_Geo::ip() );
		$fail = (int) get_transient( $key );
		if ( $fail >= 5 ) {
			wp_send_json_error( array( 'message' => 'wait' ), 429 );
		}

		$given = isset( $_POST['code'] ) ? (string) wp_unslash( $_POST['code'] ) : '';
		$given = trim( $given );

		// The code belongs to the account sitting here, not to the site: two
		// operators on the same install have two codes, and one leaked code
		// does not open the other's panel.
		$stored = cloaklink()->login->code_for( $user );
		$good   = false;

		if ( '' !== $stored ) {
			// The code is digits only, and nothing says how many. Stripping
			// non-digits here would let "abc1234" pass as "1234", so the
			// comparison is made on exactly what was typed.
			$digits = preg_replace( '/\D/', '', $given );
			if ( $digits === $given && '' !== $digits ) {
				$good = wp_check_password( $digits, $stored, strlen( $digits ) );
			}
		} else {
			// No code set: the account's own password is the only secret this
			// panel has, and asking for it costs the operator nothing.
			$good = $given !== '' && wp_check_password( $given, $user->user_pass, $user->ID );
		}

		if ( ! $good ) {
			set_transient( $key, $fail + 1, 15 * MINUTE_IN_SECONDS );
			wp_send_json_error( array( 'message' => 'refused' ), 403 );
		}

		delete_transient( $key );
		wp_send_json_success( array( 'unlocked' => 1 ) );
	}

	/** Bulk operations from the links table. */
	public function ajax_bulk() {
		check_ajax_referer( 'cloaklink_ajax', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}
		$ids    = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array();
		$action = isset( $_POST['cl_action'] ) ? sanitize_key( wp_unslash( $_POST['cl_action'] ) ) : '';
		$ids    = array_values( array_filter( $ids ) );
		if ( ! $ids ) {
			wp_send_json_error( array( 'message' => 'no selection' ), 400 );
		}
		if ( 'delete' === $action ) {
			$this->db->delete_links( $ids, true );
		} elseif ( 'pause' === $action || 'resume' === $action ) {
			foreach ( $ids as $id ) {
				$this->db->update_link( $id, array( 'status' => 'pause' === $action ? 'paused' : 'active' ) );
			}
		} elseif ( 'expire' === $action ) {
			foreach ( $ids as $id ) {
				$this->db->update_link( $id, array( 'status' => 'expired' ) );
			}
		}
		wp_send_json_success( array( 'count' => count( $ids ) ) );
	}

	/** Destination preview. */
	public function ajax_preview() {
		check_ajax_referer( 'cloaklink_ajax', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}
		$raw = isset( $_POST['url'] ) ? trim( (string) wp_unslash( $_POST['url'] ) ) : '';
		$url = $this->links->normalise_url( $raw );

		// This site's own address is a valid preview source even when it has no
		// dot in the host, as on a local or staging install. normalise_url()
		// rejects dotless hosts to stop a relative path being treated as a
		// destination, which is the right rule for a link and the wrong one
		// here.
		$brand = (string) $this->settings->get( 'brand_name' );
		if ( ! $url && '' !== $raw ) {
			$is_own = 0 === strpos( $raw, (string) home_url( '/' ) ) || 0 === strpos( $raw, (string) site_url( '/' ) );
			if ( $is_own ) {
				$url = esc_url_raw( $raw );
			}
		}
		if ( ! $url ) {
			wp_send_json_error( array( 'message' => __( 'That does not look like a valid URL.', 'cloaklink' ) ) );
		}

		$preview = $this->links->preview_metadata( $url );

		// The card must show what the recipient will actually see, not what the
		// destination happens to publish. These fallbacks are the same ones the
		// public preview page applies, so the panel cannot promise a card the
		// sent link will not have.
		$host  = isset( $preview['host'] ) ? (string) $preview['host'] : '';
		// A card built from another site's address must read as that site: its
		// host in the title, its own picture, its own icon. Falling back to this
		// service's brand name here showed a card that did not match the page
		// it pointed at.
		$own_hosts = array(
			strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ),
			strtolower( (string) wp_parse_url( site_url(), PHP_URL_HOST ) ),
		);
		$is_own    = '' === $host || in_array( strtolower( $host ), array_filter( $own_hosts ), true );

		if ( empty( $preview['title'] ) || $preview['title'] === $host ) {
			$preview['title'] = $is_own && '' !== $brand ? $brand : $host;
		}
		if ( empty( $preview['description'] ) && $is_own ) {
			$preview['description'] = (string) $this->settings->get( 'brand_tagline' );
		}
		if ( empty( $preview['image'] ) && $is_own ) {
			$preview['image'] = (string) $this->settings->get( 'share_card_image' );
		}
		if ( empty( $preview['site_name'] ) || $preview['site_name'] === $host ) {
			$preview['site_name'] = $host;
		}
		// A favicon is a 16 or 64 pixel square. Blowing it up to fill the card
		// picture shows a blurred blob where the source page published no
		// picture at all, so it is offered as the little site icon only.
		if ( empty( $preview['image'] ) && $is_own && ! empty( $preview['icon'] ) ) {
			$preview['image'] = (string) $preview['icon'];
		}

		wp_send_json_success( $preview );
	}

	/** Test the geo pipeline with the current admin IP. */
	public function ajax_test_geo() {
		check_ajax_referer( 'cloaklink_ajax', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}
		$ip = CloakLink_Geo::ip();
		$geo = CloakLink_Geo::lookup( $ip, (string) $this->settings->get( 'geo_api' ) );
		wp_send_json_success(
			array(
				'ip'  => $ip,
				'geo' => $geo,
				'ua'  => CloakLink_UA::parse( isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '' ),
			)
		);
	}

	/* ---------------------------------------------------------------------
	 * Rendering
	 * ------------------------------------------------------------------ */

	/**
	 * Print the panel on its own page, outside wp-admin.
	 *
	 * The same views, the same header and the same scripts, on a page with no
	 * WordPress menu, no admin bar and no theme. The console was always
	 * designed to stand alone — a dark field with its own navigation — and the
	 * WordPress frame only ever added a second set of menus around it.
	 *
	 * Posting still goes to admin-post.php, which is a public endpoint and
	 * checks the same capability and nonce as before: nothing about how a
	 * change is saved moves with the address.
	 *
	 * @return void
	 */
	public function render_standalone( $vault = false ) {
		if ( ! current_user_can( $this->cap() ) ) {
			wp_safe_redirect( cloaklink()->login->url() );
			exit;
		}

		if ( ! $vault ) {
			$this->maybe_send_to_vault();
		}

		// On the restricted address the network is checked again here, not
		// only at the route: a page reached by any other path must not render
		// what the gate exists to protect.
		if ( $vault && ! CloakLink_Guard::passes() ) {
			status_header( 403 );
			wp_die( esc_html__( 'This address is not open to your network.', 'cloaklink' ), 403 );
		}

		$data = $this->page_data();
		// The address itself, so a nav link inside the restricted console stays
		// on the restricted console rather than dropping to the open one.
		$data['vault']     = (bool) $vault;
		$data['vault_url'] = $vault ? home_url( '/' . cloaklink()->login->vault_path() ) : '';

		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Referrer-Policy: no-referrer' );
		// The rest of the hardening set, on every console screen.
		//
		// These are cheap and they close the ordinary holes: the panel could
		// be framed by another site (so a click on what looked like a normal
		// page could land on Delete), a browser could sniff a served file as a
		// type it is not, and the browser's own powerful features — camera,
		// microphone, geolocation — were available to any frame on any origin
		// that managed to embed the panel. `sameorigin` keeps the walkie-
		// talkie working (it is on this origin) while ending the rest.
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-Content-Type-Options: nosniff' );
		header( "Content-Security-Policy: frame-ancestors 'self'; base-uri 'self'; object-src 'none'" );
		header( 'Permissions-Policy: camera=(self), microphone=(self), geolocation=(self), payment=(), usb=()' );
		$cl_tls = is_ssl() || ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === strtolower( (string) wp_unslash( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ) );
		if ( $cl_tls ) {
			header( 'Strict-Transport-Security: max-age=31536000' );
		}

		$ver = CLOAKLINK_VERSION;
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive">
<?php
		// Added to the home screen, the console opens without a browser frame.
		//
		// These are the four tags that make a phone treat a site as an app
		// rather than as a page: the capability switch (iOS and Android read
		// different names), the bar colour that matches the console's own
		// near-black, and the name that appears under the icon. Without them
		// the "Add to Home Screen" entry opens a Safari window with a
		// toolbar across the top of an instrument the operator is meant to
		// read at a glance.
		?>
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="<?php echo esc_attr( $this->site_label() ); ?>">
<meta name="theme-color" content="#07090d">
<meta name="format-detection" content="telephone=no">
<title><?php echo esc_html( $data['route'][0] . ' — ' . $this->site_label() ); ?></title>
<?php
		// Only the dashicons the panel actually uses, and only the panel's own
		// two sheets. Asking WordPress for "every queued style" here would also
		// print core's emoji sheet, which raises a deprecation notice that lands
		// on the page as a line of text above the header.
		wp_print_styles( array( 'dashicons' ) );
?>
<?php
		// The tab's own mark. Without it the browser asks the install for
		// /favicon.ico and shows WordPress's logo, which is somebody else's
		// brand on a screen that is ours.
		$cl_icon_url = CLOAKLINK_URL . 'assets/img/logo.png';
		$cl_icon_ver = '';
		if ( defined( 'CLOAKLINK_PATH' ) && file_exists( CLOAKLINK_PATH . 'assets/img/logo.png' ) ) {
			$cl_icon_ver = (string) filemtime( CLOAKLINK_PATH . 'assets/img/logo.png' );
		}
		?>
<link rel="icon" href="<?php echo esc_url( $cl_icon_url . ( $cl_icon_ver ? '?v=' . $cl_icon_ver : '' ) ); ?>" sizes="any">
<link rel="apple-touch-icon" href="<?php echo esc_url( $cl_icon_url ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/admin.css?ver=' . $ver ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/admin-cyber.css?ver=' . $ver ); ?>">
<?php
		wp_print_head_scripts();
?>
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-intel.css?ver=' . $ver ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-signal.css?ver=' . $ver ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/surveillance.css?ver=' . $ver ); ?>">
</head>
<body class="toplevel_page_cloaklink cloaklink-standalone wp-core-ui">
<?php
		$this->render_view( 'partials/chrome', $data );
		// The restricted console opens on the data it exists for, and says so
		// in the header, so an operator always knows which of the two doors
		// they came through.
		//
		// That is only true of the landing. This used to draw the monitoring
		// wall for EVERY page on the restricted address, so /vault/visits and
		// /vault/map and a single record all silently showed the same screen —
		// the address said one thing and the page another. The default is
		// still the wall; a page that was actually asked for is honoured.
		$cl_vault_page = ( ! empty( $data['vault'] ) && 'overview' === $data['page'] ) ? 'support' : $data['page'];
		$this->render_view( $cl_vault_page, $data );
		$this->render_view( 'partials/footer', $data );
		$this->render_view( 'partials/lock', array_merge( $data, array( 'cl_lock_cfg' => $this->lock_config() ) ) );

		// The sound engine, first, and by hand.
		//
		// The standalone console does not fire admin_enqueue_scripts, so
		// nothing this class enqueues is printed here — this block is its
		// whole script list. Without this line the open console had no sound
		// engine at all and every caller above it fell back to its own
		// private synthesis, which is exactly the drift the engine exists to
		// end.
		?>
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/notice.css?ver=' . $ver ); ?>">
<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/sound.js?ver=' . $ver ); ?>"></script>
<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/notice.js?ver=' . $ver ); ?>"></script>
<script>if (window.CloakSound) { window.CloakSound.setRole('admin'); }</script>
<?php
		// The configuration, BEFORE the scripts that read it.
		//
		// admin.js opens with `var cfg = window.CLOAKLINK || {}` and keeps
		// that object for the whole page. This assignment used to come after
		// wp_print_footer_scripts(), which is what actually prints admin.js
		// on this address — so the script captured an empty object and every
		// `cfg.ajax`, `cfg.nonce`, `cfg.decision` and `cfg.page` below it was
		// undefined. Live polling, the capture alert, the door watcher, the
		// ticket card and the decision notice were all silently inert on the
		// standalone console, and only there: wp-admin prints its own footer
		// after the inline config, which is why the same code worked inside
		// WordPress and not on the address the operator actually uses.
?>
<script>window.CLOAKLINK = window.CLOAKLINK || <?php echo wp_json_encode( $this->script_config() ); ?>;</script>
<?php
		wp_print_footer_scripts();
?>
</body>
</html>
		<?php
	}

	/**
	 * Pages that carry a visitor's own detail.
	 *
	 * The restricted address exists to hold these. When it is switched on,
	 * the open panel keeps everything needed to run the links — the list, the
	 * editor, the blocklist, the settings, the tools — and sends a request for
	 * one of these pages to the address that is gated by network.
	 *
	 * @return array
	 */
	private function vault_pages() {
		return array( 'visits', 'map', 'support', 'link', 'record' );
	}

	/**
	 * Move a request for a protected page to the restricted address.
	 *
	 * Only when the restriction is on, and only from the open panel: the
	 * restricted console renders these pages itself, so this never loops.
	 * The reason travels in the query so the page that answers can say why
	 * the operator arrived there.
	 *
	 * @return void
	 */
	private function maybe_send_to_vault() {
		if ( ! $this->settings->get( 'ip_lock_enabled' ) ) {
			return;
		}
		$page = self::current_page();
		if ( ! in_array( $page, $this->vault_pages(), true ) ) {
			return;
		}
		$base = home_url( '/' . cloaklink()->login->vault_path() );
		$id   = self::current_id();
		$to   = trailingslashit( $base ) . rawurlencode( $page );
		if ( $id ) {
			$to = trailingslashit( $to ) . $id;
		}
		wp_safe_redirect( $to );
		exit;
	}

	/**
	 * The page this request asks for, in either address shape.
	 *
	 * Read from the path first and the query second, so every screen keeps
	 * working across the change from one form to the other without either
	 * having to know which it was given.
	 *
	 * @return string
	 */
	public static function current_page() {
		$page = '';
		if ( function_exists( 'cloaklink' ) && cloaklink()->login ) {
			$page = cloaklink()->login->requested_page();
		} elseif ( isset( $_GET['cl_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$page = sanitize_key( wp_unslash( $_GET['cl_page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		return '' !== $page ? $page : 'overview';
	}

	/**
	 * The link id this request asks for, in either address shape.
	 *
	 * @return int
	 */
	public static function current_id() {
		if ( function_exists( 'cloaklink' ) && cloaklink()->login ) {
			$id = cloaklink()->login->requested_id();
			if ( $id ) {
				return $id;
			}
		}
		return isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	}

	/** Route the panel page and render it. */
	public function render() {
		if ( ! current_user_can( $this->cap() ) ) {
			wp_die( esc_html__( 'You do not have access to this panel.', 'cloaklink' ), 403 );
		}

		$this->maybe_send_to_vault();

		$data = $this->page_data();

		$this->render_view( 'partials/chrome', $data );
		$this->render_view( $data['page'], $data );
		$this->render_view( 'partials/footer', $data );
		// The lock covers the whole page, so it is printed last and outside
		// the panel's own wrapper.
		$this->render_view( 'partials/lock', array_merge( $data, array( 'cl_lock_cfg' => $this->lock_config() ) ) );
	}

	/**
	 * The page the panel should draw, and the words for its heading.
	 *
	 * @return array
	 */
	private function page_data() {
		$page = self::current_page();
		if ( ! isset( $this->routes[ $page ] ) ) {
			$page = 'overview';
		}

		return array(
			'page'    => $page,
			'route'   => $this->routes[ $page ],
			'notce'   => isset( $_GET['cl_notice'] ) ? sanitize_key( wp_unslash( $_GET['cl_notice'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
			// A separate key for account creation, so one form's result can
			// never be read as the other's.
			'account' => isset( $_GET['cl_account'] ) ? sanitize_key( wp_unslash( $_GET['cl_account'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification
		);
	}

	/**
	 * What the lock screen knows about the session sitting in front of it.
	 *
	 * @return array
	 */
	private function lock_config() {
		$needs = '' !== cloaklink()->login->code_for( wp_get_current_user() ) ? 'code' : 'password';
		return array(
			'needs' => $needs,
			// The same answer under the name the script reads. The cells are
			// redacted for a password and shown for a code, and that choice is
			// made from here rather than guessed in the browser.
			'kind'  => $needs,
			// Who the panel thinks is sitting here. Printed on the lock so a
			// shared machine shows whose session it is before anybody types.
			'name'  => wp_get_current_user()->display_name,
			'email' => wp_get_current_user()->user_email,
		);
	}

	/**
	 * The name the panel signs its own tab with.
	 *
	 * @return string
	 */
	private function site_label() {
		$brand = trim( (string) $this->settings->get( 'brand_name' ) );
		return '' !== $brand ? $brand : 'Credit Control';
	}

	/**
	 * The same config, for the standalone page's asset setup.
	 *
	 * @return array
	 */
	public function script_config_public() {
		return $this->script_config();
	}

	/**
	 * Everything admin.js expects to find on window.CLOAKLINK.
	 *
	 * @return array
	 */
	/**
	 * The decision this operator just made, once.
	 *
	 * Reads and deletes the transient written by the ticket handler. A
	 * transient rather than a query argument because the notice has to
	 * survive the redirect without putting a person's name into the address
	 * bar, and because it must be shown exactly once — a refresh that
	 * announced an allowance again would read as a second allowance.
	 *
	 * @return array|false
	 */
	private function take_decision() {
		$key  = 'cloaklink_decision_' . get_current_user_id();
		$data = get_transient( $key );
		if ( ! $data ) {
			return false;
		}
		delete_transient( $key );
		return $data;
	}

	private function script_config() {
		$page = self::current_page();
		return array(
			'ajax'    => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'cloaklink_ajax' ),
			// The few words the console's script writes into the page after it
			// loads. They are translated here rather than echoed as literals in
			// the JavaScript, so a site running a translation gets them in its
			// own language like every other string on the screen.
			'i18n'    => array(
				'voiceNote' => __( 'voice note', 'cloaklink' ),
				'recording' => __( 'recording', 'cloaklink' ),
				'play'      => __( 'Play', 'cloaklink' ),
				'pause'     => __( 'Pause', 'cloaklink' ),
			),
			// The panel locks itself after a stretch with no activity and opens
			// only on the access code. The wait is the operator's to set.
			'lock'    => array_merge(
				array(
					'ajax'    => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'cloaklink_unlock' ),
					'minutes' => max( 1, (int) $this->settings->get( 'idle_lock_minutes', 10 ) ),
				),
				$this->lock_config()
			),
			'page'    => $page,
			'linkId'  => self::current_id(),
			// A ticket decision the operator made on the previous request.
			// It arrives here rather than through the redirect query because
			// the words are already on the screen by then; this is the card
			// and the figure that say it happened. Read and cleared in the
			// same breath so a refresh does not announce it twice.
			'decision' => $this->take_decision(),
			// The console's behaviour switches, resolved here so the script
			// never reads a key that does not exist. These are the ones that
			// change something in the browser rather than on the server:
			// how long a card stays, how many stack, and which sounds play.
			'adv'     => array(
				'cardSeconds'    => max( 4, min( 120, (int) cloaklink()->adv->get( 'card_seconds', 60 ) ) ),
				'cardMax'        => max( 1, min( 8, (int) cloaklink()->adv->get( 'card_max', 3 ) ) ),
				'ticketCard'     => cloaklink()->adv->yes( 'ticket_card' ) ? 1 : 0,
				'soundCapture'   => cloaklink()->adv->yes( 'sound_capture' ) ? 1 : 0,
				'soundTicket'    => cloaklink()->adv->yes( 'sound_ticket' ) ? 1 : 0,
				'desktopNotify'  => cloaklink()->adv->yes( 'desktop_notify' ) ? 1 : 0,
				'hideQuiet'      => cloaklink()->adv->yes( 'hide_quiet' ) ? 1 : 0,
				'pollSeconds'    => max( 1, min( 15, (int) cloaklink()->adv->get( 'poll_seconds', 1 ) ) ),
				'confirmDelete'  => cloaklink()->adv->yes( 'confirm_delete' ) ? 1 : 0,
				'shortcuts'      => cloaklink()->adv->yes( 'shortcuts' ) ? 1 : 0,
				'copyFormat'     => (string) cloaklink()->adv->get( 'copy_format', 'url' ),
				'bodyClass'      => cloaklink()->adv->body_class(),
				// Desk activity reloads itself when the operator asked it to.
				// Zero is the default the screen shipped with: a log does not
				// move under a reader's eyes unless they said they wanted it to.
				'activityRefresh' => max( 0, min( 300, (int) cloaklink()->adv->get( 'act_autorefresh', 0 ) ) ),
			),
			// The operator's own alert sound, when one has been uploaded. The
			// alert module plays it instead of its built-in figure and falls
			// back to the figure if it cannot be decoded, so a bad upload can
			// never leave the panel silent.
			'alertSound' => (string) $this->settings->alert_sound_url(),
			// The whole library, resolved: one row per event with its own
			// file, volume, repeat count and quiet period. The page plays from
			// this and nothing else, so what the screen shows and what the
			// panel sounds like cannot drift apart.
			// Overrides applied: an operator who set a louder capture alert on
			// their own account hears theirs, and everybody else hears the
			// desk's. The map handed to the page is already resolved, so the
			// script never has to know which layer a value came from.
			'sounds'     => $this->settings->sound_map_for( get_current_user_id() ),
			// Whether the panel plays anything at all, and how loud. Both are
			// settings, because a monitor that has to be armed by hand on every
			// page load is a monitor nobody arms.
			'alertOn'     => (int) $this->settings->get( 'alert_on', 1 ) ? 1 : 0,
			'alertVolume' => max( 0, min( 100, (int) $this->settings->get( 'alert_volume', 70 ) ) ),
			// Used as the preview source for a document link that has no
			// separate preview URL: this site's own public page.
			'siteUrl' => home_url( '/' ),
			// The walkie-talkie's sound vocabulary and the desk's own tone.
			// Both are resolved on the server so the browser never has to
			// guess a name it has no recipe for.
			'radioTone'  => (string) $this->settings->get( 'radio_tone', 'chirp' ),
			'radioTones' => CloakLink_Walkie::tones_json(),
			// The radio's behaviour, resolved on the server so the browser
			// never has to carry a default of its own. Every one of these is
			// a switch on the Settings screen; none of them is a control the
			// operator has to touch while a line is open.
			'radio'      => CloakLink_Walkie::radio_config(),
			// Where the panel's own screens live, so a card in the corner can
			// link to one without the page it was drawn on knowing whether it
			// is the standalone address or wp-admin.
			'home'    => self::url( 'overview' ),
			// The desk's ticket queue, resolved here rather than patched out of
			// `home` in the browser.
			//
			// The arrival card used to build this link by rewriting the home
			// address's "/overview" tail into "/agents". On the standalone
			// console the home address is /info-security-desk with no tail at
			// all, so the rewrite matched nothing and "Open the queue" reloaded
			// Overview — the one button on a ticket alert that must not be a
			// dead end. The address is built by the same helper as every other
			// link now, so it is right in both address shapes.
			'queue'   => self::url( 'agents' ),
			// One address per screen, resolved on the server. The keyboard
			// shortcuts used to assemble these by gluing a page name onto the
			// home address, which produces admin.php?page=cloaklink/links on
			// the wp-admin shape — an address WordPress does not answer.
			'pages'   => $this->page_urls(),
			'i18n'    => array(
				'copied'   => __( 'Copied', 'cloaklink' ),
				'copyFail' => __( 'Press Ctrl/Cmd + C to copy', 'cloaklink' ),
				'confirm'  => __( 'Delete the selected links? This also removes their visit history.', 'cloaklink' ),
				'live'     => __( 'Live', 'cloaklink' ),
				'paused'   => __( 'Paused', 'cloaklink' ),
				// The two buttons on every delete question. They live here
				// rather than in the script so a translated site reads the
				// dialog in its own language like everything else.
				'remove'   => __( 'Remove', 'cloaklink' ),
				'cancel'   => __( 'Cancel', 'cloaklink' ),
			),
		);
	}

	/**
	 * Include a view with data in scope.
	 *
	 * @param string $name View name.
	 * @param array  $data Data.
	 * @return void
	 */
	public function render_view( $name, $data = array() ) {
		// A template name, optionally in a subfolder ("partials/chrome"), and
		// nothing else: no leading separator, no dots in any segment. Then the
		// resolved path is confirmed to still be inside the views folder, which
		// is what actually stops traversal. An earlier version of this guard
		// refused the slash as well and silently stopped rendering the panel's
		// own header and footer.
		$name = trim( (string) $name, '/' );
		if ( '' === $name || ! preg_match( '#^[a-z0-9_-]+(/[a-z0-9_-]+)*$#i', $name ) ) {
			return;
		}

		$base = realpath( CLOAKLINK_DIR . 'views/admin' );
		$file = CLOAKLINK_DIR . 'views/admin/' . $name . '.php';
		$real = realpath( $file );

		if ( ! $base || ! $real || 0 !== strpos( $real, $base . DIRECTORY_SEPARATOR ) || ! is_file( $real ) ) {
			return;
		}
		$file = $real;

		// Objects and data the views expect as locals.
		$admin    = $this;
		$links    = $this->links;
		$settings = $this->settings;
		$cl_db    = $this->db;

		if ( is_array( $data ) ) {
			foreach ( $data as $cl_key => $cl_value ) {
				if ( ! isset( $$cl_key ) ) {
					$$cl_key = $cl_value; // phpcs:ignore WordPress.PHP.DontExtract
				}
			}
		}

		include $file;
	}

	/** Dashboard widget. */
	public function register_dashboard_widget() {
		if ( ! current_user_can( $this->cap() ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'cloaklink_widget',
			__( 'CloakLink activity', 'cloaklink' ),
			array( $this, 'dashboard_widget' )
		);
	}

	/** Widget body. */
	public function dashboard_widget() {
		$stats = $this->db->global_stats();
		$rows  = $this->db->get_visits( array( 'per_page' => 5 ) );
		echo '<p><strong>' . esc_html( number_format_i18n( $stats['visits_today'] ) ) . '</strong> ' . esc_html__( 'visits today', 'cloaklink' ) . ' · <strong>' . esc_html( number_format_i18n( $stats['links_active'] ) ) . '</strong> ' . esc_html__( 'active links', 'cloaklink' ) . '</p>';
		echo '<ul class="cl-widget-list">';
		foreach ( $rows as $row ) {
			echo '<li>' . esc_html( $this->fmt_dt( $row['created_at'], 'short' ) ) . ' — ' . esc_html( $row['city'] ? $row['city'] . ', ' . $row['country_name'] : $row['country_name'] ) . ' · ' . esc_html( $row['slug'] ) . '</li>';
		}
		echo '</ul>';
		echo '<p><a class="button" href="' . esc_url( self::url( 'overview' ) ) . '">' . esc_html__( 'Open panel', 'cloaklink' ) . '</a></p>';
	}

	/**
	 * Shortcode that prints the compliance note anywhere on the site.
	 *
	 * @return string
	 */
	public function shortcode_notice() {
		return '<div class="cl-compliance">' . esc_html( (string) $this->settings->get( 'brand_note' ) ) . '</div>';
	}

	/* ---------------------------------------------------------------------
	 * Formatting helpers used by the views
	 * ------------------------------------------------------------------ */

	/**
	 * The timezone every panel timestamp is printed in.
	 *
	 * Rows are stored in UTC, but an operator reads the panel in their own
	 * working hours. "17 Nov 12:50 GMT+0000" is correct and useless: it makes
	 * the reader do arithmetic to find out whether something happened this
	 * morning. The panel therefore states one fixed zone — India Standard Time
	 * by default — and every screen prints the same clock.
	 *
	 * @return DateTimeZone
	 */
	public function tz() {
		$name = (string) $this->settings->get( 'panel_timezone', '' );
		try {
			return new DateTimeZone( '' !== $name ? $name : 'Asia/Kolkata' );
		} catch ( Exception $e ) {
			return new DateTimeZone( 'Asia/Kolkata' );
		}
	}

	/**
	 * Format a stored UTC datetime in the panel timezone.
	 *
	 * Times are printed on a 12-hour clock ("12:50 pm") because that is how a
	 * time is spoken in the place this panel is used, and the trailing zone
	 * abbreviation is left off every line that already carries the date: it
	 * was the same three letters on all of them.
	 *
	 * @param string $mysql Datetime.
	 * @param string $style 'full', 'short', 'time', 'clock' or 'day'.
	 * @return string
	 */
	public function fmt_dt( $mysql, $style = 'full' ) {
		$ts = $this->db->to_ts( $mysql );
		if ( ! $ts ) {
			return '—';
		}
		$tz = $this->tz();
		// The clock shape is the operator's choice on the Advanced screen: a
		// duty log is kept in 24 hours, and a desk that reads 12-hour times
		// should not have to convert every row.
		$adv = function_exists( 'cloaklink' ) ? cloaklink()->adv : null;
		if ( 'time' === $style ) {
			// A trail is read as a sequence, and the date is the same on every
			// line of it; repeating the day eight times buries the sequence.
			return wp_date( $adv ? $adv->time_format( true ) : 'g:i:s A', $ts, $tz );
		}
		if ( 'clock' === $style ) {
			// Just the time, no seconds: a table column, not a log line.
			return wp_date( $adv ? $adv->time_format( false ) : 'g:i A', $ts, $tz );
		}
		if ( 'day' === $style ) {
			return wp_date( 'd M Y', $ts, $tz );
		}
		$clock  = $adv ? $adv->time_format( false ) : 'g:i A';
		$format = ( 'short' === $style ? 'd M, ' : 'd M Y, ' ) . $clock;
		return wp_date( $format, $ts, $tz );
	}

	/**
	 * A stored datetime, printed in the panel's own zone.
	 *
	 * Every timestamp this plugin stores is written with current_time( 'mysql' ),
	 * which is the site's local time — not UTC. Everything printed used to go
	 * through mysql2date(), which also reads the site's local time, and that is
	 * correct only while the site's timezone is the one the operator is
	 * standing in. On a site whose WordPress timezone is still UTC it printed
	 * the stored value untouched: a ticket raised at 16:30 showed as 11:00.
	 *
	 * This does the conversion explicitly — read as site-local, print as the
	 * panel's — so the two clocks cannot drift apart whatever the site
	 * setting happens to be.
	 *
	 * @param string $mysql  Datetime as stored.
	 * @param string $format PHP date format.
	 * @return string
	 */
	public static function stamp( $mysql, $format = 'j M, g:i A' ) {
		$mysql = trim( (string) $mysql );
		if ( '' === $mysql || '0000-00-00 00:00:00' === $mysql ) {
			return '—';
		}
		$panel = function_exists( 'cloaklink' ) ? cloaklink()->admin->tz() : null;
		try {
			$dt = new DateTime( $mysql, wp_timezone() );
		} catch ( Exception $e ) {
			return '—';
		}
		if ( $panel ) {
			$dt->setTimezone( $panel );
		}
		// A caller that asked for the default "g:i A" shape gets the operator's
		// clock instead. A caller that named its own format keeps it.
		if ( 'j M, g:i A' === $format && function_exists( 'cloaklink' ) && cloaklink()->adv && cloaklink()->adv->yes( 'clock_24' ) ) {
			$format = 'j M, H:i';
		}
		return wp_date( $format, $dt->getTimestamp(), $panel );
	}

	/**
	 * The panel's timezone label, for a heading that needs to name it once.
	 *
	 * @return string
	 */
	public function tz_label() {
		return wp_date( 'T', time(), $this->tz() );
	}

	/**
	 * Relative time ("4m ago").
	 *
	 * @param string $mysql Datetime.
	 * @return string
	 */
	public function ago( $mysql ) {
		$ts = $this->db->to_ts( $mysql );
		if ( ! $ts ) {
			return '—';
		}
		$diff = time() - $ts;
		if ( $diff < 0 ) {
			return sprintf( /* translators: %s: human time diff */ __( 'in %s', 'cloaklink' ), human_time_diff( time(), $ts ) );
		}
		if ( $diff < 60 ) {
			return __( 'just now', 'cloaklink' );
		}
		return sprintf( /* translators: %s: human time diff */ __( '%s ago', 'cloaklink' ), human_time_diff( $ts ) );
	}

	/**
	 * Risk badge markup.
	 *
	 * @param int $risk Score.
	 * @return string
	 */
	public function risk_badge( $risk ) {
		$risk  = (int) $risk;
		$class = 'cl-risk cl-risk--low';
		if ( $risk >= 60 ) {
			$class = 'cl-risk cl-risk--high';
		} elseif ( $risk >= 30 ) {
			$class = 'cl-risk cl-risk--mid';
		}
		return '<span class="' . esc_attr( $class ) . '">' . esc_html( $risk ) . '</span>';
	}

	/**
	 * Event label.
	 *
	 * @param string $event Event key.
	 * @param array  $row   Visit row, unused; kept so callers can pass it.
	 * @return string
	 */
	public function event_label( $event, $row = array() ) {
		$map = array(
			'view'     => __( 'Viewed', 'cloaklink' ),
			'open'     => __( 'Opened', 'cloaklink' ),
			'redirect' => __( 'Redirected', 'cloaklink' ),
			'blocked'  => __( 'Blocked', 'cloaklink' ),
			'download' => __( 'Locked page opened', 'cloaklink' ),
			'location'      => __( 'Location shared', 'cloaklink' ),
			'location_no'   => __( 'Location refused', 'cloaklink' ),
			'camera'        => __( 'Camera shared', 'cloaklink' ),
			'camera_no'     => __( 'Camera refused', 'cloaklink' ),
			'microphone'    => __( 'Microphone shared', 'cloaklink' ),
			'microphone_no' => __( 'Microphone refused', 'cloaklink' ),
			'pin_ok'   => __( 'PIN accepted', 'cloaklink' ),
			'pin_fail' => __( 'PIN refused', 'cloaklink' ),
		);
		return isset( $map[ $event ] ) ? $map[ $event ] : ucfirst( (string) $event );
	}

	/**
	 * Flag list as chips.
	 *
	 * @param string $flags Semicolon separated.
	 * @return string
	 */
	public function flag_chips( $flags ) {
		if ( ! $flags ) {
			return '<span class="cl-muted">—</span>';
		}
		$out = '';
		foreach ( array_filter( array_map( 'trim', explode( ';', $flags ) ) ) as $flag ) {
			$out .= '<span class="cl-chip cl-chip--flag">' . esc_html( $flag ) . '</span>';
		}
		return $out;
	}

	/**
	 * Place string from a visit row.
	 *
	 * @param array $row Visit.
	 * @return string
	 */
	public function place( $row ) {
		$bits = array_filter(
			array(
				$row['city'],
				$row['region'],
				$row['country_name'],
			)
		);
		if ( ! $bits ) {
			// The network lookup answers with a city name only sometimes. A
			// row that has real coordinates next to "Unknown" reads as a
			// failure, so name the source of the position instead.
			if ( ! empty( $row['lat'] ) && ! empty( $row['lng'] ) ) {
				return '<span class="cl-muted">' . esc_html__( 'Device GPS', 'cloaklink' ) . '</span>';
			}
			return __( 'Unknown', 'cloaklink' );
		}
		$country = '';
		if ( ! empty( $row['country_code'] ) ) {
			// A flag glyph, when the operator asked for it. Regional indicator
			// pairs are the code drawn as a flag, so nothing is downloaded; a
			// machine with no emoji flag font simply shows the letters back,
			// which is why the country code is printed beside it either way.
			$flag = '';
			$code = strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) $row['country_code'] ) );
			if ( 2 === strlen( $code ) && cloaklink()->adv->yes( 'country_flag' ) ) {
				$flag = '<span class="cl-flag" aria-hidden="true">'
					. mb_chr( 0x1F1E6 + ( ord( $code[0] ) - 65 ) ) . mb_chr( 0x1F1E6 + ( ord( $code[1] ) - 65 ) )
					. '</span> ';
			}
			$country = $flag . '<span class="cl-cc">' . esc_html( $row['country_code'] ) . '</span> ';
		}
		return $country . esc_html( implode( ', ', $bits ) );
	}

	/**
	 * Short device cell.
	 *
	 * @param array $row Visit.
	 * @return string
	 */
	public function device_cell( $row ) {
		$icon = CloakLink_UA::icon( $row['device'] );
		$line = CloakLink_UA::summary( $row );
		return '<span class="cl-dev">' . esc_html( $icon ) . ' <span>' . esc_html( $line ) . '</span></span>';
	}

	/**
	 * One row in the live/visitor table.
	 *
	 * @param array $row  Visit row.
	 * @param bool  $live Live flag.
	 * @return string
	 */
	public function visit_row_html( $row, $live = false ) {
		$av = isset( $row['accuracy'] ) ? $row['accuracy'] : '';
		$gps = ( $row['lat'] && $row['lng'] )
			? '<a class="cl-map" target="_blank" rel="noopener noreferrer" title="' . esc_attr__( 'Open this location in Google Maps', 'cloaklink' ) . '" href="' . esc_url( $this->map_url( $row['lat'], $row['lng'] ) ) . '">'
				. '<span class="cl-map__pin" aria-hidden="true">◉</span>'
				. esc_html( $row['lat'] ) . ', ' . esc_html( $row['lng'] )
				. ( $av ? ' <span class="cl-map__acc">±' . esc_html( $av ) . 'm</span>' : '' )
				. '</a>'
			: '<span class="cl-muted">' . esc_html( $row['gps_error'] ? 'no gps (' . $row['gps_error'] . ')' : '—' ) . '</span>';

		$ip = $this->settings->get( 'mask_ip' ) ? $this->mask_ip( $row['ip'] ) : $row['ip'];

		$html  = '<tr class="cl-vrow' . ( $live ? ' cl-vrow--new' : '' ) . '">';
		// "4m ago" is a second line under the exact stamp, and it is the
		// operator's choice: a log read as a sequence wants the stamp alone,
		// and a log read to see what just happened wants both.
		$cl_ago = cloaklink()->adv->yes( 'relative_time' )
			? '<span class="cl-ago">' . esc_html( $this->ago( $row['created_at'] ) ) . '</span>'
			: '';
		$html .= '<td class="cl-td-time"><span class="cl-time">' . esc_html( $this->fmt_dt( $row['created_at'], 'short' ) ) . '</span>' . $cl_ago . '</td>';
		$html .= '<td><span class="cl-badge cl-badge--sm">' . esc_html( $this->event_label( $row['event'], $row ) ) . '</span><code class="cl-slug" title="' . esc_attr( $row['slug'] ) . '">' . esc_html( $row['slug'] ) . '</code>'
			. $this->slug_words( $row )
			. $this->permission_marks( $row ) . '</td>';
		$html .= '<td>' . $this->device_cell( $row ) . '</td>';
		$html .= '<td>' . $this->place( $row ) . '</td>';
		$html .= '<td class="cl-td-gps">' . $gps . '</td>';
		$html .= '<td><div class="cl-ip">' . esc_html( $ip ) . '</div><div class="cl-isp">' . esc_html( $row['isp'] ) . '</div></td>';
		$html .= '<td>' . $this->risk_badge( $row['risk'] ) . '</td>';
		$html .= '</tr>';
		return $html;
	}

	/**
	 * The link a visit came from, in plain words, under its address.
	 *
	 * The slug is the only thing a visit row knows about its link, and a slug
	 * is a machine's name for a thing: "TS-JEZ-705" says nothing to somebody
	 * deciding whether a click matters. This prints the title the operator
	 * actually gave the link, quietly, under the address — so the dashboard
	 * answers "which link was clicked" in the words the operator used.
	 *
	 * @param array $row Visit row.
	 * @return string
	 */
	private function slug_words( $row ) {
		static $map = null;
		if ( null === $map ) {
			$map = array();
			foreach ( $this->db->get_links( array( 'per_page' => 500 ) ) as $l ) {
				$title = trim( (string) $l['title'] );
				if ( '' === $title ) {
					$title = trim( (string) $l['label'] );
				}
				if ( '' === $title ) {
					continue;
				}
				$map[ (string) $l['slug'] ] = $title;
			}
		}
		$slug  = isset( $row['slug'] ) ? (string) $row['slug'] : '';
		$title = isset( $map[ $slug ] ) ? $map[ $slug ] : '';
		if ( '' === $title ) {
			// No live link: the visit outlived it. The slug with its file
			// extension and separator marks cleaned up is still better than
			// nothing, and nothing here invents a name that was never given.
			$title = trim( (string) preg_replace( '/[-_.]+/', ' ', preg_replace( '/\.(pdf|docx?|xlsx?|pptx?|zip|jpe?g|png)$/i', '', $slug ) ) );
		}
		// A one or two letter slug tells nobody anything: it is a test link or
		// a placeholder, and a row that prints it is noise under every row.
		if ( mb_strlen( $title ) < 3 || mb_strtolower( $title ) === mb_strtolower( $slug ) ) {
			return '';
		}
		return '<span class="cl-slugwords" title="' . esc_attr( $title ) . '">' . esc_html( $title ) . '</span>';
	}

	/**
	 * The panel's icon set.
	 *
	 * Every mark in the panel is one of these, drawn on the same 24 grid at
	 * one stroke weight. Before, the navigation used text characters — ◈ ⛓ ☰
	 * ◐ ⚙ — which a system font renders at four different weights and sizes
	 * in one row, and which read as punctuation rather than as iconography.
	 * Drawing them makes the panel look like one designed thing instead of a
	 * page that borrowed its marks from a keyboard.
	 *
	 * @param string $name  Icon name.
	 * @param int    $size  Square size in CSS pixels.
	 * @param string $class Extra classes.
	 * @return string
	 */
	public static function icon( $name, $size = 16, $class = '' ) {
		$paths = array(
			'overview'  => '<rect x="3" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.6"/>',
			'links'     => '<path d="M10.5 13.5a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7L12 6.2"/><path d="M13.5 10.5a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.5-1.4"/>',
			'plus'      => '<path d="M12 5v14"/><path d="M5 12h14"/>',
			'visits'    => '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h10"/>',
			'map'       => '<path d="M12 21s6.5-5.7 6.5-10.4A6.5 6.5 0 0 0 5.5 10.6C5.5 15.3 12 21 12 21Z"/><circle cx="12" cy="10.4" r="2.4"/>',
			'activity'  => '<path d="M3 12h3.4l2.2-6 3.4 12 2.4-8 1.8 4H21"/>',
			'monitoring'=> '<circle cx="12" cy="12" r="2.2"/><path d="M7.8 7.8a6 6 0 0 0 0 8.4"/><path d="M16.2 16.2a6 6 0 0 0 0-8.4"/><path d="M4.9 4.9a10 10 0 0 0 0 14.2"/><path d="M19.1 19.1a10 10 0 0 0 0-14.2"/>',
			'block'     => '<circle cx="12" cy="12" r="8.4"/><path d="m6.2 6.2 11.6 11.6"/>',
			'settings'  => '<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4"/><path d="M12 18.8v2.4"/><path d="M21.2 12h-2.4"/><path d="M5.2 12H2.8"/><path d="m18.5 5.5-1.7 1.7"/><path d="m7.2 16.8-1.7 1.7"/><path d="m18.5 18.5-1.7-1.7"/><path d="m7.2 7.2-1.7-1.7"/>',
			'tools'     => '<path d="M14.5 6.5a3.5 3.5 0 0 0 4.6 4.6L21 13l-8 8-2-2 7.2-7.2"/><path d="M3 21l4.5-4.5"/><path d="M9.5 3.5 12 6l-2 2-2.5-2.5a2 2 0 0 1 2-2Z"/>',
			'access'    => '<path d="M12 3 4.8 6v6c0 4.4 3 7.6 7.2 9 4.2-1.4 7.2-4.6 7.2-9V6L12 3Z"/><path d="m8.7 12 2.2 2.2 4.4-4.4"/>',
			// The person, for the one page that is about them. A head and
			// shoulders rather than a padlock: the page is not a barrier, it
			// is the account holder's own two secrets.
			'who'       => '<circle cx="12" cy="8.2" r="3.6"/><path d="M4.8 20.4a7.2 7.2 0 0 1 14.4 0"/>',
			'camera'    => '<path d="M4 8.6A1.6 1.6 0 0 1 5.6 7h1.9l1.2-1.8h6.6L16.5 7h1.9A1.6 1.6 0 0 1 20 8.6v8.8A1.6 1.6 0 0 1 18.4 19H5.6A1.6 1.6 0 0 1 4 17.4V8.6Z"/><circle cx="12" cy="12.8" r="3.1"/>',
			'microphone'=> '<rect x="9" y="2.6" width="6" height="11" rx="3"/><path d="M5.4 11a6.6 6.6 0 0 0 13.2 0"/><path d="M12 17.6V21"/><path d="M9 21h6"/>',
			'video'     => '<rect x="2.6" y="6" width="12" height="12" rx="2.4"/><path d="m14.6 11 6.8-3.6v9.2l-6.8-3.6"/>',
			'position'  => '<path d="M12 21s6.5-5.7 6.5-10.4A6.5 6.5 0 0 0 5.5 10.6C5.5 15.3 12 21 12 21Z"/><circle cx="12" cy="10.4" r="2.4"/>',
			'area'      => '<path d="M3 20h18"/><path d="M5 20V9.5L12 5l7 4.5V20"/><path d="M9.6 20v-4.6h4.8V20"/>',
			'archive'   => '<rect x="3" y="4" width="18" height="4.4" rx="1.2"/><path d="M5 8.4V19a1.4 1.4 0 0 0 1.4 1.4h11.2A1.4 1.4 0 0 0 19 19V8.4"/><path d="M10 12.4h4"/>',
			'restore'   => '<path d="M4 10.5A8 8 0 1 1 6.2 17"/><path d="M3.6 4.8v5.8h5.8"/>',
			'trash'     => '<path d="M4.5 7h15"/><path d="M9.2 7V4.8h5.6V7"/><path d="M6.4 7l.9 12.4a1.4 1.4 0 0 0 1.4 1.3h6.6a1.4 1.4 0 0 0 1.4-1.3L17.6 7"/>',
			'wave'      => '<path d="M3 12h2.2"/><path d="M8 5.5v13"/><path d="M12 8.5v7"/><path d="M16 4v16"/><path d="M20 9.5v5"/>',
			'eye'       => '<path d="M2.4 12S5.6 5.6 12 5.6 21.6 12 21.6 12 18.4 18.4 12 18.4 2.4 12 2.4 12Z"/><circle cx="12" cy="12" r="2.8"/>',
			'copy'      => '<rect x="8.6" y="8.6" width="12" height="12" rx="2"/><path d="M15.4 5.4H5.4a2 2 0 0 0-2 2v10"/>',
			'edit'      => '<path d="M4 20h4l10-10-4-4L4 16v4Z"/><path d="m14.4 5.6 4 4"/>',
			'pause'     => '<rect x="7" y="5" width="3.6" height="14" rx="1"/><rect x="13.4" y="5" width="3.6" height="14" rx="1"/>',
			'play'      => '<path d="M7.4 5.4 18.4 12 7.4 18.6Z"/>',
			'check'     => '<path d="m4.6 12.6 5 5L19.6 7"/>',
			'close'     => '<path d="m6 6 12 12"/><path d="m18 6-12 12"/>',
			'search'    => '<circle cx="11" cy="11" r="6.6"/><path d="m16 16 4.6 4.6"/>',
			'download'  => '<path d="M12 3.6v11"/><path d="m7.6 10.8 4.4 4.4 4.4-4.4"/><path d="M4.6 19.4h14.8"/>',
			// The card's fact row. A globe for the network the visitor came
			// through, a handset for the number the desk raised the case with,
			// and a routed square for the address itself — so the three are
			// told apart before any of them is read.
			'isp'       => '<circle cx="12" cy="12" r="8.4"/><path d="M3.6 12h16.8"/><path d="M12 3.6c2.4 2.4 3.6 5.2 3.6 8.4S14.4 18 12 20.4C9.6 18 8.4 15.2 8.4 12S9.6 6 12 3.6Z"/>',
			'tel'       => '<path d="M6.4 3.6h3.1l1.5 3.9-2 1.3a11.4 11.4 0 0 0 6.2 6.2l1.3-2 3.9 1.5v3.1a1.9 1.9 0 0 1-2.1 1.9A16.8 16.8 0 0 1 4.5 5.7a1.9 1.9 0 0 1 1.9-2.1Z"/>',
			'ip'        => '<rect x="3.4" y="4.4" width="17.2" height="15.2" rx="2.2"/><path d="M7.4 9.4h2"/><path d="M7.4 14.6h5"/><path d="M15.4 9.4h1.2"/><path d="M15.4 14.6h1.2"/>',
		);

		$body = isset( $paths[ $name ] ) ? $paths[ $name ] : $paths['overview'];
		$size = max( 10, (int) $size );
		return '<svg class="cl-ico ' . esc_attr( $class ) . '" width="' . esc_attr( $size ) . '" height="' . esc_attr( $size ) . '"'
			. ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"'
			. ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
			. $body . '</svg>';
	}

	/**
	 * One capture glyph, drawn rather than typed.
	 *
	 * An emoji renders differently on every machine — a colour blob on a Mac,
	 * a flat monochrome shape on Windows, a missing box on some Linux desktops
	 * — so a wall of them looks like four different designs at once. These
	 * are single-weight line marks that inherit the badge's own colour, which
	 * is what makes the wall read as one system.
	 *
	 * @param string $kind position|camera|microphone|video|area.
	 * @return string SVG markup.
	 */
	public static function capture_icon( $kind ) {
		$map = array(
			'position'   => 'position',
			'camera'     => 'camera',
			'microphone' => 'microphone',
			'video'      => 'video',
			'area'       => 'area',
			'isp'        => 'isp',
			'tel'        => 'tel',
			'ip'         => 'ip',
		);
		return self::icon( isset( $map[ $kind ] ) ? $map[ $kind ] : 'position', 13, 'cl-cico' );
	}

	/**
	 * Turn one captured visit into the animated card the desk shows.
	 *
	 * The three badges are the whole point of the card: a position, a camera
	 * and a microphone are the only things a visitor can actually hand over,
	 * and each one lights up in its own colour and pulses, so a captured
	 * position is visible across a room without reading a word.
	 *
	 * @param array $row   Visit row, with a 'capture' key from capture_of().
	 * @param array $names Link titles, keyed by link id.
	 * @return string
	 */
	/**
	 * The key a captured row is filed under in the name-wise view.
	 *
	 * A named visitor is one person however many links they opened. A visitor
	 * who typed no name is not "everybody anonymous" — five such people are
	 * five separate rows, told apart by the network they came from, or the
	 * list would report one visitor where there were five.
	 *
	 * @param array $row    Visit row.
	 * @param array $people Visitor-name map.
	 * @return string
	 */
	private function capture_person_key( $row, $people = array() ) {
		$who  = $people ? cloaklink()->support->name_for( $row, $people ) : null;
		$name = $who ? trim( (string) $who['name'] ) : '';
		if ( '' === $name ) {
			$name = trim( (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) );
		}
		if ( '' !== $name ) {
			return 'n:' . mb_strtolower( $name );
		}
		return 'x:' . (string) ( isset( $row['ip_hash'] ) && '' !== (string) $row['ip_hash'] ? $row['ip_hash'] : ( isset( $row['id'] ) ? $row['id'] : 'na' ) );
	}

	/**
	 * The four things a capture can carry, with the mark that says which.
	 *
	 * @return array
	 */
	private static function capture_kinds() {
		return array(
			'position'   => array( '📍', __( 'Location', 'cloaklink' ), 'geo' ),
			'camera'     => array( '📸', __( 'Camera', 'cloaklink' ), 'cam' ),
			'microphone' => array( '🎙️', __( 'Mic', 'cloaklink' ), 'mic' ),
			'video'      => array( '🎥', __( 'Recording', 'cloaklink' ), 'vid' ),
		);
	}

	/**
	 * Who, how many, and what — the name-wise ledger above the wall.
	 *
	 * The question this answers is not "what happened last" but "who are these
	 * people and what did each of them hand over". One row per person: their
	 * name and number, how many times they came, the marks for what they gave
	 * up, when they were last here, and one press to open everything about
	 * them. It is built from the same rows the wall draws, so a name here and
	 * the cards below it can never disagree.
	 *
	 * @param array $rows   Captured rows.
	 * @param array $people Visitor-name map.
	 * @return array{html:string,people:array}
	 */
	/**
	 * The tracing map: where the last few people were, drawn live.
	 *
	 * This replaces two paragraphs of grey text that said "nothing here yet"
	 * on a screen whose whole point is that something is about to be here.
	 * A page that says it is waiting is a page that looks broken; a map with
	 * a sweep on it is a page that looks like it is listening.
	 *
	 * The idea is the one every phone has when it is finding you: a dark
	 * basemap, a radar sweep going round, the last known position pulsing as
	 * it locks on, and a thin line running between the stops a person made.
	 * It is drawn with weights and colours the panel already uses, so it
	 * belongs to the console rather than sitting on it.
	 *
	 * Nothing here is a new kind of record. The points are the ones the wall
	 * already has; the dots are people; the line is one person's own trail.
	 * What it adds is the shape those facts make when they are drawn instead
	 * of listed.
	 *
	 * @param array $rows   The rows the wall read.
	 * @param array $people Name book from visitor_names().
	 * @return string
	 */
	/**
	 * The tower map.
	 *
	 * A second map, for a second question. The tracing map answers "where did
	 * these people go": rings, trails, one line per person. This one answers
	 * "who is on the network, and how well are they heard": every covered
	 * city is a tower, and each tower's signal is how many people are standing
	 * under it. It is the picture a telecom engineer reads, and it is the
	 * picture that makes an Indian deployment legible — Bangalore at the
	 * centre, the other metros ringing it, the smaller cities as smaller
	 * lights.
	 *
	 * The towers are fixed: a city is on this map because it is a city, not
	 * because a visitor happened to be there. A tower with nobody under it
	 * still draws, dim, which is what makes the busy ones mean something. The
	 * signal is the count under that city's radius, drawn as expanding rings
	 * whose speed and brightness rise with it.
	 *
	 * The map takes the rows it is given. It does no filtering of its own, so
	 * whichever panel calls it decides what may be seen — the operator's
	 * console passes every captured row, the desk passes only the rows of the
	 * ticket that person is allowed to read.
	 *
	 * @param array $rows    Capture rows. Only lat/lng/city are used.
	 * @param array $args    height, title, tone.
	 * @return string
	 */
	public function tower_map_html( $rows = array(), $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				// Tall enough for the country to be read.
				//
				// At 320 the fitted map put the southern tip of India below
				// the frame and the sweep turned in a band across the middle
				// of a picture whose subject did not fit. 420 is the point at
				// which every one of the twenty towers has its label on screen
				// on a laptop, and the home mast is not against an edge.
				'height' => 420,
				'title'  => __( 'Network coverage', 'cloaklink' ),
				// The board reads a moving window rather than the whole
				// history. The strip across the top is an instrument — "how
				// does the network stand right now" — and every number on it
				// was a count of everything the database had ever seen, so
				// "live now" could only go up and nothing ever left. The
				// window is how long an entry stays on the board after its
				// last activity.
				'window' => 10,
			)
		);

		// The cities this map knows. Chosen for an Indian deployment: the six
		// metros first, then the state capitals, then the tech cities that
		// actually produce traffic. A visitor anywhere else still counts — the
		// nearest tower takes them — so nobody is invisible for being in an
		// unlisted town.
		$cities = array(
			array( 'n' => 'Bengaluru', 's' => 'KA', 'lat' => 12.9716, 'lng' => 77.5946, 'r' => 0.9, 'w' => 3.0 ),
			array( 'n' => 'Mumbai', 's' => 'MH', 'lat' => 19.0760, 'lng' => 72.8777, 'r' => 0.8, 'w' => 2.6 ),
			array( 'n' => 'Delhi', 's' => 'DL', 'lat' => 28.7041, 'lng' => 77.1025, 'r' => 0.8, 'w' => 2.6 ),
			array( 'n' => 'Hyderabad', 's' => 'TG', 'lat' => 17.3850, 'lng' => 78.4867, 'r' => 0.7, 'w' => 2.2 ),
			array( 'n' => 'Chennai', 's' => 'TN', 'lat' => 13.0827, 'lng' => 80.2707, 'r' => 0.7, 'w' => 2.2 ),
			array( 'n' => 'Kolkata', 's' => 'WB', 'lat' => 22.5726, 'lng' => 88.3639, 'r' => 0.7, 'w' => 2.2 ),
			array( 'n' => 'Pune', 's' => 'MH', 'lat' => 18.5204, 'lng' => 73.8567, 'r' => 0.6, 'w' => 1.8 ),
			array( 'n' => 'Ahmedabad', 's' => 'GJ', 'lat' => 23.0225, 'lng' => 72.5714, 'r' => 0.6, 'w' => 1.6 ),
			array( 'n' => 'Jaipur', 's' => 'RJ', 'lat' => 26.9124, 'lng' => 75.7873, 'r' => 0.5, 'w' => 1.4 ),
			array( 'n' => 'Lucknow', 's' => 'UP', 'lat' => 26.8467, 'lng' => 80.9462, 'r' => 0.5, 'w' => 1.3 ),
			array( 'n' => 'Chandigarh', 's' => 'CH', 'lat' => 30.7333, 'lng' => 76.7794, 'r' => 0.5, 'w' => 1.3 ),
			array( 'n' => 'Kochi', 's' => 'KL', 'lat' => 9.9312, 'lng' => 76.2673, 'r' => 0.5, 'w' => 1.3 ),
			array( 'n' => 'Coimbatore', 's' => 'TN', 'lat' => 11.0168, 'lng' => 76.9558, 'r' => 0.45, 'w' => 1.1 ),
			array( 'n' => 'Indore', 's' => 'MP', 'lat' => 22.7196, 'lng' => 75.8577, 'r' => 0.45, 'w' => 1.1 ),
			array( 'n' => 'Nagpur', 's' => 'MH', 'lat' => 21.1458, 'lng' => 79.0882, 'r' => 0.45, 'w' => 1.1 ),
			array( 'n' => 'Bhopal', 's' => 'MP', 'lat' => 23.2599, 'lng' => 77.4126, 'r' => 0.4, 'w' => 1.0 ),
			array( 'n' => 'Surat', 's' => 'GJ', 'lat' => 21.1702, 'lng' => 72.8311, 'r' => 0.4, 'w' => 1.0 ),
			array( 'n' => 'Visakhapatnam', 's' => 'AP', 'lat' => 17.6868, 'lng' => 83.2185, 'r' => 0.4, 'w' => 1.0 ),
			array( 'n' => 'Patna', 's' => 'BR', 'lat' => 25.5941, 'lng' => 85.1376, 'r' => 0.4, 'w' => 0.9 ),
			array( 'n' => 'Guwahati', 's' => 'AS', 'lat' => 26.1445, 'lng' => 91.7362, 'r' => 0.4, 'w' => 0.9 ),
		);

		// Everyone is placed under the tower whose radius they fall inside.
		// The nearest one wins when two overlap, because a person in Whitefield
		// belongs to Bangalore and not to Chennai just because the radii touch.
		$load = array();
		foreach ( $cities as $i => $c ) {
			$load[ $i ] = 0;
		}
		$unplaced = 0;

		// The strip across the top of the board answers the four questions an
		// operator asks before reading a single pin: how many devices opened a
		// link, how many were seen, how many handed something over, and how
		// many said no. They are counted here, in the same pass that places
		// The window, applied before anything is counted.
		//
		// Every figure below is a count of these rows, and every mast's load
		// is a count of the ones under it — so narrowing the rows here
		// narrows the picture and the strip together. Nothing backdated is
		// let through: the board answers "how does the network stand right
		// now", and the record of what happened is Visits and All records.
		$window_mins = max( 2, min( 120, (int) ( isset( $args['window'] ) ? $args['window'] : 10 ) ) );
		$cutoff      = time() - ( $window_mins * MINUTE_IN_SECONDS );
		$in_window   = array();
		foreach ( (array) $rows as $cl_wr_row ) {
			$cl_wr_ts = $this->db->to_ts( (string) ( isset( $cl_wr_row['created_at'] ) ? $cl_wr_row['created_at'] : '' ) );
			if ( $cl_wr_ts && $cl_wr_ts >= $cutoff ) {
				$in_window[] = $cl_wr_row;
			}
		}
		$rows = $in_window;

		// everyone, so the numbers and the masts can never disagree.
		$tally = array(
			'seen'    => 0,
			'devices' => array(),
			'granted' => 0,
			'refused' => 0,
			'held'    => 0,
			'cities'  => array(),
			'late'    => 0,
		);
		foreach ( (array) $rows as $row ) {
			$ex = array();
			if ( isset( $row['extra'] ) ) {
				$ex = is_array( $row['extra'] ) ? $row['extra'] : $this->db->decode( (string) $row['extra'] );
			}
			$ex = is_array( $ex ) ? $ex : array();
			$tally['seen']++;
			$granted = isset( $ex['granted'] ) && is_array( $ex['granted'] ) ? $ex['granted'] : array();
			$refused = isset( $ex['refused'] ) && is_array( $ex['refused'] ) ? $ex['refused'] : array();
			if ( $granted ) {
				$tally['granted']++;
			}
			if ( $refused ) {
				$tally['refused']++;
			}
			// "Clicked but nothing allowed": a click that produced neither a
			// permission nor a fix. It is the one number that says how much of
			// the traffic looked and left.
			$has_fix = isset( $row['lat'], $row['lng'] ) && '' !== (string) $row['lat'] && '' !== (string) $row['lng'];
			if ( ! $granted && ! $refused && ! $has_fix ) {
				$tally['held']++;
			}
			$dev = trim( (string) ( isset( $row['brand'] ) ? $row['brand'] : '' ) . ' ' . (string) ( isset( $row['device_model'] ) ? $row['device_model'] : '' ) );
			if ( '' === $dev ) {
				$dev = trim( (string) ( isset( $row['os'] ) ? $row['os'] : '' ) );
			}
			if ( '' !== $dev ) {
				if ( ! isset( $tally['devices'][ $dev ] ) ) {
					$tally['devices'][ $dev ] = 0;
				}
				$tally['devices'][ $dev ]++;
			}
			$city = trim( (string) ( isset( $row['city'] ) ? $row['city'] : '' ) );
			if ( '' !== $city ) {
				$tally['cities'][ $city ] = isset( $tally['cities'][ $city ] ) ? $tally['cities'][ $city ] + 1 : 1;
			}
		}
		arsort( $tally['devices'] );
		arsort( $tally['cities'] );
		$top_device = $tally['devices'] ? (string) array_key_first( $tally['devices'] ) : '';
		$top_city   = $tally['cities'] ? (string) array_key_first( $tally['cities'] ) : '';
		$top_ip     = '';
		foreach ( (array) $rows as $row ) {
			$one = trim( (string) ( isset( $row['ip'] ) ? $row['ip'] : '' ) );
			if ( '' !== $one ) {
				$top_ip = $this->settings->get( 'mask_ip' ) ? $this->mask_ip( $one ) : $one;
				break;
			}
		}

		foreach ( (array) $rows as $row ) {
			$lat = isset( $row['lat'] ) ? (float) $row['lat'] : 0;
			$lng = isset( $row['lng'] ) ? (float) $row['lng'] : 0;
			if ( ! $lat && ! $lng ) {
				continue;
			}
			$best  = -1;
			$score = PHP_FLOAT_MAX;
			foreach ( $cities as $i => $c ) {
				$d = sqrt( pow( $lat - $c['lat'], 2 ) + pow( $lng - $c['lng'], 2 ) );
				if ( $d < $score ) {
					$score = $d;
					$best  = $i;
				}
			}
			// Half a degree is roughly the width of a metro; anything further
			// is a town this map does not name, and it is counted separately
			// rather than being drawn on top of a city it is nowhere near.
			if ( $best >= 0 && $score <= 0.75 ) {
				$load[ $best ]++;
			} else {
				$unplaced++;
			}
		}

		$towers = array();
		foreach ( $cities as $i => $c ) {
			$towers[] = array(
				'name' => $c['n'],
				'st'   => $c['s'],
				'lat'  => $c['lat'],
				'lng'  => $c['lng'],
				'n'    => $load[ $i ],
				'w'    => $c['w'],
			);
		}

		// Bangalore is the home tower: the map opens on it, and it keeps the
		// strongest signal of the six metros whether or not it has the most
		// traffic, because a deployment is judged from where it is run.
		$data = array(
			'towers'   => $towers,
			'home'     => 'Bengaluru',
			'unplaced' => $unplaced,
			'total'    => array_sum( $load ),
		);

		$n     = (int) $data['total'];
		$busy  = 0;
		foreach ( $towers as $t ) {
			if ( $t['n'] > 0 ) {
				$busy++;
			}
		}

		$html  = '<div class="cl-tower" id="cl-tower"';
		$html .= ' data-towers="' . esc_attr( wp_json_encode( $data ) ) . '"';
		$html .= ' style="--cl-tower-h:' . esc_attr( (string) max( 200, (int) $args['height'] ) ) . 'px"';
		$html .= ' aria-label="' . esc_attr__( 'Network coverage across India', 'cloaklink' ) . '">';

		$html .= '<div class="cl-tower__tiles" aria-hidden="true"></div>';
		$html .= '<div class="cl-tower__grid" aria-hidden="true"></div>';
		$html .= '<div class="cl-tower__vignette" aria-hidden="true"></div>';
		// The sweep is a radar around the home mast: a disc sized from the
		// script, a cone that turns inside it, one bright leading edge, and
		// range rings. The disc is placed by the script because its centre is
		// the home city's position on screen, which is not known until the map
		// has been fitted.
		$html .= '<div class="cl-tower__scan" aria-hidden="true">';
		$html .= '<div class="cl-tower__radar">';
		$html .= '<span class="cl-tower__beam"></span>';
		$html .= '<span class="cl-tower__ranges"><i></i><i></i><i></i><i></i></span>';
		$html .= '<span class="cl-tower__axis"></span>';
		// The leading edge turns around the same point as the cone. It used to
		// sit outside the disc, which meant it pivoted on the centre of the
		// panel while the cone pivoted on the home mast — two different
		// centres, so the bright line crossed the board at an angle the sweep
		// did not follow.
		$html .= '<span class="cl-tower__beamline"></span>';
		$html .= '</div>';
		$html .= '</div>';
		$html .= '<svg class="cl-tower__links" aria-hidden="true" preserveAspectRatio="none"></svg>';
		$html .= '<div class="cl-tower__masts"></div>';

		// The strip across the top of the board.
		//
		// It is the console's own readout: one line of small monospaced figures
		// in the language the rest of this desk uses — devices, seen, handed
		// over, declined — rather than the words "links" and "clicks", which
		// describe a web page and not the people on it. Every number comes
		// from the pass that placed the masts, so the strip and the picture
		// under it are the same data.
		$html .= '<div class="cl-tower__hud">';
		$html .= '<span class="cl-tower__live"><i aria-hidden="true"></i>';
		$html .= esc_html(
			sprintf(
				/* translators: %d: window in minutes */
				__( 'Network · last %dm', 'cloaklink' ),
				$window_mins
			)
		) . '</span>';

		$html .= '<span class="cl-tower__stat"><b>' . esc_html( number_format_i18n( $busy ) ) . '</b> ';
		$html .= esc_html__( 'live now', 'cloaklink' ) . '</span>';

		$html .= '<span class="cl-tower__stat"><b>' . esc_html( number_format_i18n( (int) $tally['seen'] ) ) . '</b> ';
		$html .= esc_html__( 'opened', 'cloaklink' ) . '</span>';

		$html .= '<span class="cl-tower__stat cl-tower__stat--ok"><b>' . esc_html( number_format_i18n( (int) $tally['granted'] ) ) . '</b> ';
		$html .= esc_html__( 'allowed', 'cloaklink' ) . '</span>';

		$html .= '<span class="cl-tower__stat cl-tower__stat--no"><b>' . esc_html( number_format_i18n( (int) $tally['refused'] ) ) . '</b> ';
		$html .= esc_html__( 'declined', 'cloaklink' ) . '</span>';

		$html .= '<span class="cl-tower__stat cl-tower__stat--held"><b>' . esc_html( number_format_i18n( (int) $tally['held'] ) ) . '</b> ';
		$html .= esc_html__( 'opened, gave nothing', 'cloaklink' ) . '</span>';

		$html .= '<span class="cl-tower__stat"><b>' . esc_html( number_format_i18n( count( $towers ) ) ) . '</b> ';
		$html .= esc_html__( 'cities', 'cloaklink' ) . '</span>';
		$html .= '</div>';

		// The three facts a board like this is read for at a glance, named
		// once underneath it: which device, which address, which city. They
		// are the most common of each, not an example — an operator looking
		// for the shape of their traffic wants the mode, not one row.
		$html .= '<div class="cl-tower__readout">';
		$html .= '<span class="cl-tower__ro"><i>' . esc_html__( 'Device', 'cloaklink' ) . '</i><b>' . esc_html( '' !== $top_device ? $top_device : '—' ) . '</b></span>';
		$html .= '<span class="cl-tower__ro"><i>' . esc_html__( 'Address', 'cloaklink' ) . '</i><b>' . esc_html( '' !== $top_ip ? $top_ip : '—' ) . '</b></span>';
		$html .= '<span class="cl-tower__ro"><i>' . esc_html__( 'City', 'cloaklink' ) . '</i><b>' . esc_html( '' !== $top_city ? $top_city : '—' ) . '</b></span>';
		$html .= '</div>';

		$html .= '<p class="cl-tower__legend">';
		$html .= esc_html__( 'Each mast is a city. The rings are the signal, and the number is how many devices are standing under it.', 'cloaklink' );
		$html .= '</p>';

		$html .= '</div>';

		return $html;
	}

	public function trace_map_html( $rows, $people = array() ) {
		// One point per person per position, newest first, capped: a map is
		// read at a glance and a hundred pins is not a glance.
		$points = array();
		$seen   = array();
		foreach ( (array) $rows as $row ) {
			if ( '' === (string) $row['lat'] || '' === (string) $row['lng'] ) {
				continue;
			}
			$who   = cloaklink()->support->name_for( $row, (array) $people );
			$label = ( $who && '' !== trim( (string) $who['name'] ) )
				? trim( (string) $who['name'] )
				: __( 'A visitor', 'cloaklink' );
			$key   = mb_strtolower( $label );
			$at    = $this->fmt_dt( $row['created_at'], 'short' );

			// The same person at the same place twice is one dot with a
			// count, not two dots on top of each other.
			$spot = $key . '|' . number_format( (float) $row['lat'], 4, '.', '' ) . ',' . number_format( (float) $row['lng'], 4, '.', '' );
			if ( isset( $seen[ $spot ] ) ) {
				$points[ $seen[ $spot ] ]['n']++;
				continue;
			}
			$seen[ $spot ] = count( $points );

			$place = implode(
				', ',
				array_filter(
					array(
						(string) $row['city'],
						(string) ( '' !== (string) $row['country_name'] ? $row['country_name'] : $row['country_code'] ),
					)
				)
			);

			$points[] = array(
				'lat'   => (float) $row['lat'],
				'lng'   => (float) $row['lng'],
				'name'  => $label,
				'place' => $place,
				'at'    => $at,
				'n'     => 1,
				'key'   => $key,
			);
			if ( count( $points ) >= 40 ) {
				break;
			}
		}

		// A trail is the stops of one person, oldest first, so the line is a
		// route rather than a scribble. Each carries its own key so the
		// browser can join a new stop to the right line without re-deriving
		// which person it belongs to.
		$trails = array();
		foreach ( array_reverse( $points ) as $p ) {
			if ( ! isset( $trails[ $p['key'] ] ) ) {
				$trails[ $p['key'] ] = array( 'key' => $p['key'], 'line' => array() );
			}
			$trails[ $p['key'] ]['line'][] = array( $p['lat'], $p['lng'] );
		}
		foreach ( $trails as $k => $t ) {
			if ( count( $t['line'] ) < 2 ) {
				unset( $trails[ $k ] );
			}
		}

		$data = array(
			'points' => $points,
			'trails' => array_values( $trails ),
		);

		$n = count( $points );

		$html  = '<div class="cl-trace" id="cl-trace"';
		$html .= ' data-points="' . esc_attr( wp_json_encode( $data ) ) . '"';
		$html .= ' data-total="' . esc_attr( (string) $n ) . '"';
		$html .= ' aria-label="' . esc_attr__( 'Live tracing map of the last visitors', 'cloaklink' ) . '">';

		// The tiles are the same three sources the Map screen uses, so this is
		// the console's map and not a second one that looks almost the same.
		$html .= '<div class="cl-trace__tiles" aria-hidden="true"></div>';
		$html .= '<div class="cl-trace__grid" aria-hidden="true"></div>';
		$html .= '<div class="cl-trace__glow" aria-hidden="true"></div>';
		$html .= '<div class="cl-trace__sweep" aria-hidden="true"><i></i></div>';
		$html .= '<svg class="cl-trace__paths" aria-hidden="true" preserveAspectRatio="none"></svg>';
		$html .= '<div class="cl-trace__pins"></div>';

		// The caption. With nobody on the map it says what will appear — in
		// the same breath as showing the radar, so the screen reads as armed
		// rather than empty.
		$html .= '<div class="cl-trace__hud">';
		$html .= '<span class="cl-trace__live"><i class="cl-trace__blip" aria-hidden="true"></i>';
		$html .= esc_html__( 'Tracing', 'cloaklink' ) . '</span>';
		$html .= '<span class="cl-trace__count" id="cl-trace-n">';
		$html .= '<b>' . esc_html( number_format_i18n( $n ) ) . '</b> ';
		$html .= esc_html( sprintf( /* translators: %d: number of people */ _n( 'place', 'places', $n, 'cloaklink' ), $n ) );
		$html .= '</span>';
		$html .= '<span class="cl-trace__hint">';
		$html .= esc_html__( 'Each ring is a visitor. The line is one person’s own route.', 'cloaklink' );
		$html .= '</span>';
		$html .= '</div>';

		if ( ! $n ) {
			$html .= '<p class="cl-trace__note">';
			$html .= '<b>' . esc_html__( 'Tracking is armed.', 'cloaklink' ) . '</b> ';
			$html .= esc_html__( 'The first visitor who allows a location appears here as a ring, and the line follows them from one stop to the next.', 'cloaklink' );
			$html .= '</p>';
		}

		$html .= '</div>';

		return $html;
	}

	public function capture_lead_html( $rows, $people = array() ) {
		$kinds = self::capture_kinds();
		$book  = array();

		foreach ( $rows as $row ) {
			// A row taken off this list is off this list. The visit still
			// exists — on the wall's Everything view and in Visits — but a
			// ledger that kept counting it would make "remove" look broken.
			if ( ! empty( $row['hidden'] ) ) {
				continue;
			}
			$key = $this->capture_person_key( $row, $people );
			$cap = isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row );
			$who = $people ? cloaklink()->support->name_for( $row, $people ) : null;

			if ( ! isset( $book[ $key ] ) ) {
				$place = implode(
					', ',
					array_filter(
						array(
							(string) $row['city'],
							(string) $row['region'],
							(string) ( '' !== (string) $row['country_name'] ? $row['country_name'] : $row['country_code'] ),
						)
					)
				);
				$book[ $key ] = array(
					'key'    => $key,
					'name'   => $who ? trim( (string) $who['name'] ) : trim( (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) ),
					'phone'  => $who ? trim( (string) $who['phone'] ) : trim( (string) ( isset( $row['visitor_phone'] ) ? $row['visitor_phone'] : '' ) ),
					'count'  => 0,
					// Opens and events are counted apart so the list can say
					// "1 click · 4 actions" rather than reporting four clicks
					// for one person who clicked once and answered four
					// prompts. See the note on the visitor panel below.
					'opens'  => 0,
					'events' => 0,
					'kinds'  => array(),
					'links'  => array(),
					'first'  => (string) $row['created_at'],
					'last'   => (string) $row['created_at'],
					'place'  => $place,
					'hidden' => 0,
				);
			}

			$p = &$book[ $key ];
			$p['count']++;
			// One row is one event. An open (or its redirect) is also a click;
			// a camera grant is not. Kept beside `count` so callers that still
			// want the honest total of everything can use it, and the labels
			// that say "clicks" use `opens`.
			$cl_ev = isset( $row['event'] ) ? (string) $row['event'] : '';
			if ( '' === $cl_ev || 'open' === $cl_ev || 'redirect' === $cl_ev ) {
				$p['opens']++;
			} else {
				$p['events']++;
			}
			if ( ! empty( $row['hidden'] ) ) {
				$p['hidden']++;
			}
			foreach ( $kinds as $kind => $meta ) {
				if ( ! empty( $cap[ $kind ] ) ) {
					$p['kinds'][ $kind ] = 1;
				}
			}
			if ( '' !== (string) $row['link_id'] ) {
				$p['links'][ (int) $row['link_id'] ] = 1;
			}
			if ( '' === $p['place'] ) {
				$p['place'] = implode( ', ', array_filter( array( (string) $row['city'], (string) $row['region'] ) ) );
			}
			if ( strcmp( (string) $row['created_at'], $p['first'] ) < 0 ) {
				$p['first'] = (string) $row['created_at'];
			}
			if ( strcmp( (string) $row['created_at'], $p['last'] ) > 0 ) {
				$p['last'] = (string) $row['created_at'];
			}
			unset( $p );
		}

		uasort(
			$book,
			static function ( $a, $b ) {
				if ( $a['count'] === $b['count'] ) {
					return strcmp( $b['last'], $a['last'] );
				}
				return $b['count'] <=> $a['count'];
			}
		);

		$base = CloakLink_Admin::url( 'support' );

		$html = '';
		if ( ! $book ) {
			$html .= '<p class="cl-caps__empty"><span class="cl-caps__empty-ico" aria-hidden="true">' . self::icon( 'wave', 22 ) . '</span>'
				. '<b>' . esc_html__( 'The ledger is waiting for its first name.', 'cloaklink' ) . '</b> '
				. esc_html__( 'As soon as somebody allows a location, a camera or a microphone, their name, their count and the marks for what they gave appear here.', 'cloaklink' ) . '</p>';
		} else {
			$html .= '<div class="cl-caps__people">';
			foreach ( $book as $p ) {
				$shown = '' !== $p['name'] ? $p['name'] : __( 'No name given', 'cloaklink' );
				$init  = '';
				foreach ( preg_split( '/\s+/', $shown ) as $word ) {
					if ( '' !== $word ) {
						$init .= mb_strtoupper( mb_substr( $word, 0, 1 ) );
					}
					if ( mb_strlen( $init ) >= 2 ) {
						break;
					}
				}
				if ( '' === $init ) {
					$init = '?';
				}

				$html .= '<a class="cl-who2" href="' . esc_url( add_query_arg( 'person', rawurlencode( $p['key'] ), $base ) ) . '">';
				$html .= '<span class="cl-who2__av" aria-hidden="true">' . esc_html( $init ) . '</span>';
				$html .= '<span class="cl-who2__mid">';
				$html .= '<b class="cl-who2__name">' . esc_html( $shown ) . '</b>';
				$html .= '<span class="cl-who2__sub">';
				// What this person did, said in the two units that differ: how
				// many times they opened a link, and how many prompts they
				// answered. One open with three permissions is "1 click ·
				// 3 actions recorded", never "4 clicks".
				$html .= esc_html( sprintf( /* translators: %d: number of clicks */ _n( '%d click', '%d clicks', (int) $p['opens'], 'cloaklink' ), (int) $p['opens'] ) );
				if ( ! empty( $p['events'] ) ) {
					$html .= ' · ' . esc_html( sprintf( /* translators: %d: number of actions */ _n( '%d action recorded', '%d actions recorded', (int) $p['events'], 'cloaklink' ), (int) $p['events'] ) );
				}
				if ( '' !== $p['phone'] ) {
					$html .= ' · ' . esc_html( $p['phone'] );
				}
				if ( count( $p['links'] ) > 1 ) {
					$html .= ' · ' . esc_html( sprintf( /* translators: %d: number of links */ _n( '%d link', '%d links', count( $p['links'] ), 'cloaklink' ), count( $p['links'] ) ) );
				}
				$html .= '</span></span>';

				$html .= '<span class="cl-who2__kinds" aria-hidden="true">';
				foreach ( $kinds as $kind => $meta ) {
					$html .= '<span class="cl-who2__k' . ( isset( $p['kinds'][ $kind ] ) ? ' is-on' : '' ) . '" title="' . esc_attr( $meta[1] ) . '">' . esc_html( $meta[0] ) . '</span>';
				}
				$html .= '</span>';

				$html .= '<span class="cl-who2__end">';
				$html .= '<span class="cl-who2__when">' . esc_html( $this->ago( $p['last'] ) ) . '</span>';
				$html .= '<span class="cl-who2__go">' . esc_html__( 'Open all', 'cloaklink' ) . ' →</span>';
				$html .= '</span>';
				$html .= '</a>';
			}
			$html .= '</div>';
		}

		return array( 'html' => $html, 'people' => $book );
	}

	/**
	 * The newest handful of clicks, as one compact list.
	 *
	 * The wall's cards answer "what came in" in full; this answers it in the
	 * one line an operator actually scans, with the person's name, the link,
	 * the place and a mark per thing that was handed over.
	 *
	 * @param array $rows   Captured rows.
	 * @param array $names  Link-name map.
	 * @param array $people Visitor-name map.
	 * @param int   $max    How many to show.
	 * @return string
	 */
	public function capture_recent_html( $rows, $names = array(), $people = array(), $max = 10 ) {
		$kinds = self::capture_kinds();
		$out   = '';
		$n     = 0;

		// One line per visitor, with the clicks folded into it.
		//
		// Every permission a visitor allows is its own row, so one person who
		// allowed the location, the camera and the microphone produced three
		// lines here that differed only in the marks beside them — and the
		// wall above already shows those three as one card. Folding keeps
		// the two in step, and the count on the line states exactly what was
		// folded rather than hiding it.
		$folded = array();
		$walk   = array();
		foreach ( $rows as $row ) {
			if ( ! empty( $row['hidden'] ) ) {
				continue;
			}
			$who1 = $people ? cloaklink()->support->name_for( $row, $people ) : null;
			$hash = trim( (string) ( isset( $row['ip_hash'] ) ? $row['ip_hash'] : '' ) );
			$fk   = '' !== $hash
				? 'h:' . mb_strtolower( $hash )
				: 'n:' . mb_strtolower( $who1 ? (string) $who1['name'] : (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) )
					. '|' . (string) ( isset( $row['city'] ) ? $row['city'] : '' );
			if ( ! isset( $folded[ $fk ] ) ) {
				$folded[ $fk ] = count( $walk );
				$row['cl_clicks'] = 0;
				$row['cl_marks']  = array();
				$walk[] = $row;
			}
			$at = $folded[ $fk ];
			$walk[ $at ]['cl_clicks']++;
			$one1 = $this->db->capture_of( $row );
			foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $k1 ) {
				if ( ! empty( $one1[ $k1 ] ) ) {
					$walk[ $at ]['cl_marks'][ $k1 ] = true;
				}
			}
			// The newest row keeps the line, but a row with detail beats a
			// newer row that was cleared: a cleared row has no place, no
			// device and no coordinates, and drawing it as the face of the
			// visitor makes the line look empty while their real answer sits
			// behind it.
			$new_ok  = empty( $row['extra'] ) || false === strpos( (string) $row['extra'], '"removed"' );
			$held    = $walk[ $at ];
			$held_ok = empty( $held['extra'] ) || false === strpos( (string) $held['extra'], '"removed"' );
			if ( ( $new_ok && ! $held_ok )
				|| ( $new_ok === $held_ok && (int) $row['id'] > (int) $held['id'] ) ) {
				$row['cl_clicks'] = $walk[ $at ]['cl_clicks'];
				$row['cl_marks']  = $walk[ $at ]['cl_marks'];
				$walk[ $at ] = $row;
			}
		}

		foreach ( $walk as $row ) {
			if ( $n >= $max ) {
				break;
			}
			$n++;
			$cap = isset( $row['cl_marks'] ) && $row['cl_marks']
				? array_merge( isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row ), $row['cl_marks'] )
				: ( isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row ) );
			$who = $people ? cloaklink()->support->name_for( $row, $people ) : null;
			$nm  = $who ? trim( (string) $who['name'] ) : trim( (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) );
			if ( '' === $nm ) {
				$nm = __( 'No name given', 'cloaklink' );
			}
			$lid  = (int) $row['link_id'];
			$link = isset( $names[ $lid ] ) ? trim( (string) $names[ $lid ]['name'] ) : (string) $row['slug'];
			$link = preg_replace( '/\.(pdf|docx?|xlsx?|pptx?|zip|jpe?g|png)$/i', '', $link );
			$bits = array_filter( array( (string) $row['city'], (string) $row['region'] ) );

			$out .= '<a class="cl-rc" href="' . esc_url( add_query_arg( 'person', rawurlencode( $this->capture_person_key( $row, $people ) ), CloakLink_Admin::url( 'support' ) ) ) . '">';
			$out .= '<span class="cl-rc__t"><b>' . esc_html( $this->fmt_dt( $row['created_at'], 'clock' ) ) . '</b><i>' . esc_html( $this->ago( $row['created_at'] ) ) . '</i></span>';
			$out .= '<span class="cl-rc__name">' . esc_html( $nm ) . '</span>';
			$out .= '<span class="cl-rc__link">' . esc_html( '' !== $link ? $link : __( 'Unknown link', 'cloaklink' ) ) . '</span>';
			$out .= '<span class="cl-rc__where">' . esc_html( $bits ? implode( ', ', $bits ) : __( 'area not named', 'cloaklink' ) ) . '</span>';
			$out .= '<span class="cl-rc__k">';
			foreach ( $kinds as $kind => $meta ) {
				if ( ! empty( $cap[ $kind ] ) ) {
					$out .= '<span title="' . esc_attr( $meta[1] ) . '">' . esc_html( $meta[0] ) . '</span>';
				}
			}
			$out .= '</span>';
			if ( isset( $row['cl_clicks'] ) && (int) $row['cl_clicks'] > 1 ) {
				$out .= '<span class="cl-rc__folds">×' . esc_html( number_format_i18n( (int) $row['cl_clicks'] ) ) . '</span>';
			}
			$out .= '</a>';
		}

		if ( '' === $out ) {
			return '';
		}

		return '<div class="cl-rc-list">' . $out . '</div>';
	}

	/**
	 * Everything about one person, and every click they made.
	 *
	 * The name-wise list on the wall is a summary; this is the file behind it.
	 * Counts by kind, the first and last time, the places, the devices, and
	 * one row per click with the hour, the link, where it was, what it
	 * carried, and the two things an operator does with a row: hide it from
	 * this view, or remove its detail from the record.
	 *
	 * @param array  $rows   Captured rows.
	 * @param string $key    Person key from capture_person_key().
	 * @param array  $names  Link-name map.
	 * @param array  $people Visitor-name map.
	 * @return string
	 */
	public function capture_person_html( $rows, $key, $names = array(), $people = array() ) {
		$kinds = self::capture_kinds();
		$mine  = array();
		foreach ( $rows as $row ) {
			if ( ! empty( $row['hidden'] ) ) {
				continue;
			}
			if ( $this->capture_person_key( $row, $people ) === $key ) {
				$row['capture'] = isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row );
				$mine[] = $row;
			}
		}

		if ( ! $mine ) {
			return '';
		}

		$first   = end( $mine );
		$last    = $mine[0];
		$who     = $people ? cloaklink()->support->name_for( $last, $people ) : null;
		$name    = $who ? trim( (string) $who['name'] ) : trim( (string) ( isset( $last['visitor_name'] ) ? $last['visitor_name'] : '' ) );
		$phone   = $who ? trim( (string) $who['phone'] ) : '';
		$tally   = array();
		$places  = array();
		$devices = array();
		foreach ( $mine as $row ) {
			foreach ( $kinds as $kind => $meta ) {
				if ( ! empty( $row['capture'][ $kind ] ) ) {
					$tally[ $kind ] = isset( $tally[ $kind ] ) ? $tally[ $kind ] + 1 : 1;
				}
			}
			$place = implode( ', ', array_filter( array( (string) $row['city'], (string) $row['region'] ) ) );
			if ( '' !== $place ) {
				$places[ $place ] = isset( $places[ $place ] ) ? $places[ $place ] + 1 : 1;
			}
			$dev = trim( (string) $row['brand'] . ' ' . (string) $row['device_model'] );
			if ( '' === $dev ) {
				$dev = trim( (string) $row['os'] );
			}
			if ( '' !== $dev ) {
				$devices[ $dev ] = isset( $devices[ $dev ] ) ? $devices[ $dev ] + 1 : 1;
			}
		}
		arsort( $places );
		arsort( $devices );

		$shown = '' !== $name ? $name : __( 'No name given', 'cloaklink' );

		$html  = '<section class="cl-person" id="cl-person">';
		$html .= '<header class="cl-person__head">';
		$html .= '<div>';
		$html .= '<p class="cl-person__eyebrow">' . esc_html__( 'Everything on this visitor', 'cloaklink' ) . '</p>';
		$html .= '<h3 class="cl-person__name">' . esc_html( $shown ) . ( '' !== $phone ? ' <span>' . esc_html( $phone ) . '</span>' : '' ) . '</h3>';
		// A click is one page open; an event is one thing that happened on it.
		//
		// Every permission a visitor grants files its own row beside the open
		// that started it, so a single person who opened a link once and
		// granted location, camera and microphone left four rows. Counting
		// rows and calling the total "clicks" reported that person as four
		// clicks on a link they opened once, which is the number the operator
		// read as invented. The two are counted apart here and each is named.
		$opens  = 0;
		$events = 0;
		foreach ( $mine as $row ) {
			$ev = isset( $row['event'] ) ? (string) $row['event'] : '';
			if ( '' === $ev || 'open' === $ev || 'redirect' === $ev ) {
				$opens++;
			} else {
				$events++;
			}
		}

		$html .= '<p class="cl-person__line">' . esc_html(
			sprintf(
				/* translators: 1: number of opens, 2: number of events, 3: first time, 4: last time */
				__( '%1$s · %2$s · first seen %3$s · last seen %4$s', 'cloaklink' ),
				sprintf( /* translators: %d: number of opens */ _n( '%d click', '%d clicks', $opens, 'cloaklink' ), $opens ),
				sprintf( /* translators: %d: number of events */ _n( '%d action recorded', '%d actions recorded', $events, 'cloaklink' ), $events ),
				$this->stamp( $first['created_at'], 'j M, g:i A' ),
				$this->stamp( $last['created_at'], 'j M, g:i A' )
			)
		) . '</p>';
		$html .= '</div>';
		$html .= '<a class="cl-btn cl-btn--ghost cl-btn--sm" href="' . esc_url( CloakLink_Admin::url( 'support' ) ) . '">' . esc_html__( 'Back to everyone', 'cloaklink' ) . '</a>';
		$html .= '</header>';

		$html .= '<div class="cl-person__stats">';
		foreach ( $kinds as $kind => $meta ) {
			$html .= '<div class="cl-person__stat">'
				. '<span class="cl-person__stat-i" aria-hidden="true">' . esc_html( $meta[0] ) . '</span>'
				. '<b>' . esc_html( number_format_i18n( isset( $tally[ $kind ] ) ? $tally[ $kind ] : 0 ) ) . '</b>'
				. '<span>' . esc_html( $meta[1] ) . '</span></div>';
		}
		$html .= '<div class="cl-person__stat"><span class="cl-person__stat-i" aria-hidden="true">🗺️</span><b>' . esc_html( number_format_i18n( count( $places ) ) ) . '</b><span>' . esc_html__( 'Places', 'cloaklink' ) . '</span></div>';
		$html .= '<div class="cl-person__stat"><span class="cl-person__stat-i" aria-hidden="true">📱</span><b>' . esc_html( number_format_i18n( count( $devices ) ) ) . '</b><span>' . esc_html__( 'Devices', 'cloaklink' ) . '</span></div>';
		$html .= '</div>';

		if ( $places || $devices ) {
			$html .= '<p class="cl-person__facts">';
			if ( $places ) {
				$html .= '<span><b>' . esc_html__( 'Where', 'cloaklink' ) . '</b> ' . esc_html( implode( ' · ', array_map( static function ( $k, $v ) { return $k . ' (' . $v . ')'; }, array_keys( array_slice( $places, 0, 4, true ) ), array_values( array_slice( $places, 0, 4, true ) ) ) ) ) . '</span>';
			}
			if ( $devices ) {
				$html .= '<span><b>' . esc_html__( 'On', 'cloaklink' ) . '</b> ' . esc_html( implode( ' · ', array_keys( array_slice( $devices, 0, 3, true ) ) ) ) . '</span>';
			}
			$html .= '</p>';
		}

		$html .= '<form class="cl-person__bulk" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-cl-confirm="' . esc_attr( __( 'Take the selected clicks off this list? They stay in Visits and on the record.', 'cloaklink' ) ) . '">';
		$html .= '<input type="hidden" name="action" value="cloaklink_capture_action">';
		$html .= '<input type="hidden" name="cl_action" value="bulk_hide">';
		$html .= wp_nonce_field( 'cloaklink_capture_action', '_wpnonce', true, false );

		$html .= '<div class="cl-person__rows">';
		$html .= '<div class="cl-person__row cl-person__row--head">'
			. '<span></span><span>' . esc_html__( 'When', 'cloaklink' ) . '</span><span>' . esc_html__( 'Link', 'cloaklink' ) . '</span>'
			. '<span>' . esc_html__( 'Where', 'cloaklink' ) . '</span><span>' . esc_html__( 'Captured', 'cloaklink' ) . '</span>'
			. '<span>' . esc_html__( 'Device', 'cloaklink' ) . '</span><span></span></div>';

		foreach ( $mine as $row ) {
			$cap   = $row['capture'];
			$lid   = (int) $row['link_id'];
			$link  = isset( $names[ $lid ] ) ? trim( (string) $names[ $lid ]['name'] ) : (string) $row['slug'];
			$link  = preg_replace( '/\.(pdf|docx?|xlsx?|pptx?|zip|jpe?g|png)$/i', '', $link );
			$place = implode( ', ', array_filter( array( (string) $row['city'], (string) $row['region'], (string) $row['country_name'] ) ) );
			$dev   = trim( (string) $row['brand'] . ' ' . (string) $row['device_model'] );
			if ( '' === $dev ) {
				$dev = trim( (string) $row['os'] );
			}
			$maps  = ( '' !== (string) $row['lat'] && '' !== (string) $row['lng'] ) ? $this->map_url( $row['lat'], $row['lng'] ) : '';

			$html .= '<div class="cl-person__row' . ( ! empty( $row['hidden'] ) ? ' is-hidden' : '' ) . '">';
			$html .= '<span><input type="checkbox" name="ids[]" value="' . esc_attr( (int) $row['id'] ) . '" aria-label="' . esc_attr__( 'Select this click', 'cloaklink' ) . '"></span>';
			$html .= '<span class="cl-person__when"><b>' . esc_html( $this->stamp( $row['created_at'], 'j M, H:i' ) ) . '</b><i>' . esc_html( $this->ago( $row['created_at'] ) ) . '</i></span>';
			$html .= '<span class="cl-person__l">' . esc_html( '' !== $link ? $link : __( 'Unknown link', 'cloaklink' ) ) . '</span>';
			$html .= '<span class="cl-person__p">' . esc_html( '' !== $place ? $place : __( 'area not named', 'cloaklink' ) );
			if ( '' !== $maps ) {
				$html .= ' <a href="' . esc_url( $maps ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'map', 'cloaklink' ) . ' ↗</a>';
			}
			$html .= '</span>';
			$html .= '<span class="cl-person__k">';
			foreach ( $kinds as $kind => $meta ) {
				$html .= '<span class="' . ( ! empty( $cap[ $kind ] ) ? 'is-on' : 'is-off' ) . '" title="' . esc_attr( $meta[1] ) . '">' . esc_html( $meta[0] ) . '</span>';
			}
			$html .= '</span>';
			$html .= '<span class="cl-person__d">' . esc_html( '' !== $dev ? $dev : '—' ) . '</span>';
			$html .= '<span class="cl-person__x">' . esc_html( ! empty( $row['hidden'] ) ? __( 'hidden here', 'cloaklink' ) : '' ) . '</span>';
			$html .= '</div>';
		}

		$html .= '</div>';
		$html .= '<div class="cl-person__foot">'
			. '<label class="cl-check"><input type="checkbox" data-check-all="1"><span>' . esc_html__( 'Select all', 'cloaklink' ) . '</span></label>'
			. '<button class="cl-btn cl-btn--ghost cl-btn--danger cl-btn--sm" type="submit">' . esc_html__( 'Remove selected from this list', 'cloaklink' ) . '</button>'
			. '<span class="cl-help cl-help--inline">' . esc_html__( 'Only taken off this list. The visits stay in Visits and in the record.', 'cloaklink' ) . '</span>'
			. '</div>';
		$html .= '</form>';

		$html .= '</section>';

		return $html;
	}

	public function capture_card_html( $row, $names = array(), $people = array(), $media_url = null, $record_url = null ) {
		$cap = isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row );
		$id  = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 );
		$nm  = isset( $names[ $id ] ) ? $names[ $id ] : array( 'name' => '', 'label' => '', 'slug' => '', 'type' => '' );

		// A visit outlives the link it came from: deleting a link keeps the
		// record. "Deleted link" on a card is true and useless, so when the
		// link is gone the slug the visitor actually opened stands in for it.
		$nm_name = trim( (string) $nm['name'] );
		if ( '' === $nm_name ) {
			$nm_name = trim( (string) ( isset( $row['slug'] ) ? $row['slug'] : '' ) );
		}
		if ( '' === $nm_name ) {
			$nm_name = __( 'Unknown link', 'cloaklink' );
		}
		$nm_name = preg_replace( '/\.(pdf|docx?|xlsx?|pptx?|zip|jpe?g|png)$/i', '', $nm_name );
		$has = '' !== (string) $row['lat'] && '' !== (string) $row['lng'];

		$bits = array_filter(
			array(
				(string) $row['city'],
				(string) $row['region'],
				(string) ( '' !== (string) $row['country_name'] ? $row['country_name'] : $row['country_code'] ),
			)
		);
		$place = $bits ? implode( ', ', $bits ) : __( 'Area not named', 'cloaklink' );

		// Whose click this was. The name only exists if the visitor typed one
		// on the desk form; when they did not, the card names them by what the
		// browser did say rather than by a number the reader has to decode.
		$who = $people ? cloaklink()->support->name_for( $row, $people ) : null;
		$who_name  = $who ? trim( (string) $who['name'] ) : '';
		$who_phone = $who ? trim( (string) $who['phone'] ) : '';
		if ( '' === $who_name ) {
			$who_name = trim( (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) );
		}

		$device = trim( (string) $row['brand'] . ' ' . (string) $row['device_model'] );
		if ( '' === $device ) {
			$device = trim( (string) $row['os'] );
		}
		if ( '' === $device ) {
			$device = 'desktop' === (string) $row['device'] ? __( 'Desktop', 'cloaklink' ) : __( 'Unidentified device', 'cloaklink' );
		}

		$ip = $this->settings->get( 'mask_ip' ) ? $this->mask_ip( (string) $row['ip'] ) : (string) $row['ip'];
		$ts = $this->db->to_ts( (string) $row['created_at'] );

		$badges = array(
			'position'   => array( __( 'Location', 'cloaklink' ), 'geo', ! empty( $cap['position'] ) ),
			'camera'     => array( __( 'Camera', 'cloaklink' ), 'cam', ! empty( $cap['camera'] ) ),
			'microphone' => array( __( 'Mic', 'cloaklink' ), 'mic', ! empty( $cap['microphone'] ) ),
			'video'      => array( __( 'Video', 'cloaklink' ), 'vid', ! empty( $cap['video'] ) ),
		);

		$hidden  = ! empty( $row['hidden'] );
		$removed = ! empty( $cap['removed'] );

		// Where "the whole record" lives depends on who is asking.
		//
		// The console has a record page of its own. The desk has no such page
		// and no right to open one: a card on the desk that pointed at the
		// operator's address would be a link to a sign-in screen an agent
		// cannot pass. A caller that knows which console it is passes its own
		// builder, the same way it already passes one for media.
		$rec_url = '';
		if ( is_callable( $record_url ) ) {
			$rec_url = (string) call_user_func( $record_url, (int) $row['id'] );
		} elseif ( null === $record_url ) {
			$rec_url = self::url( 'record', array( 'id' => (int) $row['id'] ) );
		}

		// Which bulk form the card's checkbox belongs to. The monitoring wall
		// wraps its grid in one form and the archive wraps its grid in
		// another, and the same card has to serve both — a checkbox names its
		// form by id because it is a child of the grid, not of the form.
		$pick_form = ( 'records' === self::current_page() ) ? 'cl-records-form' : 'cl-caps-bulk';

		// The card's tone is the strongest thing it carries, so a column of
		// cards can be sorted by colour before any of them is read. The order
		// matches the popup: microphone, camera, position, recording.
		$tone = '';
		foreach ( array( 'microphone', 'camera', 'position', 'video' ) as $cl_kind ) {
			if ( ! empty( $cap[ $cl_kind ] ) ) {
				$tone = $cl_kind;
				break;
			}
		}
		// A card with somewhere to go is a card that answers a press anywhere
		// on it. The two links still exist and still work on their own — the
		// script below defers to them — but the picture, the time and the
		// empty corners are no longer dead space.
		$html  = '<article class="cl-cap' . ( '' !== $rec_url ? ' is-clickable' : '' ) . ( $hidden ? ' is-archived' : '' ) . ( $removed ? ' is-removed' : '' ) . ( ( time() - $ts ) < 120 ? ' is-fresh' : '' ) . '" data-visit="' . esc_attr( $row['id'] ) . '"' . ( '' !== $tone ? ' data-tone="' . esc_attr( $tone ) . '"' : '' ) . '>';
		// A box for picking this card, drawn only when the wall is in selection
		// mode. It is a span with an input inside rather than a bare input so
		// the card can be wrappered by the form without an input being a child
		// of the whole grid — the wall is refreshed by replacing its innerHTML,
		// and a form around the grid would be replaced with it.
		$html .= '<label class="cl-cap__pick" title="' . esc_attr__( 'Select this capture', 'cloaklink' ) . '">'
			. '<input type="checkbox" name="cl_pick[]" value="' . esc_attr( (int) $row['id'] ) . '" form="' . esc_attr( $pick_form ) . '">'
			. '<span aria-hidden="true"></span>'
			. '<span class="screen-reader-text">' . esc_html__( 'Select this capture', 'cloaklink' ) . '</span>'
			. '</label>';
		$html .= '<header class="cl-cap__head">';
		$html .= '<span class="cl-cap__when"><b>' . esc_html( $this->fmt_dt( $row['created_at'], 'clock' ) ) . '</b><span>' . esc_html( $this->ago( $row['created_at'] ) ) . '</span></span>';
		// How many clicks one card stands for.
		//
		// A card is now one visitor, and one visitor is several rows — the
		// location, then the camera, then the microphone, each its own click.
		// Without the count the card silently claimed to be one event, and a
		// reader comparing it with the row count could not tell whether the
		// list had lost anything. Only shown when it is more than one, so the
		// ordinary single click is not decorated with a redundant "1".
		$cl_n_clicks = isset( $row['cl_clicks'] ) ? (int) $row['cl_clicks'] : 0;
		if ( $cl_n_clicks > 1 ) {
			$html .= '<span class="cl-cap__folds" title="' . esc_attr__( 'Clicks folded into this card', 'cloaklink' ) . '">'
				. esc_html( number_format_i18n( $cl_n_clicks ) ) . ' '
				. esc_html__( 'clicks', 'cloaklink' )
				. '</span>';
		}
		if ( '' !== $rec_url ) {
			$html .= '<a class="cl-cap__link cl-cap__wholink" href="' . esc_url( $rec_url ) . '" target="_blank" rel="noopener" title="' . esc_attr( sprintf( /* translators: %s: visitor name */ __( 'Open %s\'s record in full', 'cloaklink' ), $nm_name ) ) . '">' . esc_html( $nm_name ) . '</a>';
		} else {
			$html .= '<span class="cl-cap__link" title="' . esc_attr( $nm_name ) . '">' . esc_html( $nm_name ) . '</span>';
		}
		$html .= '<span class="cl-cap__acts">';
		if ( ! $removed ) {
			// Take the detail out and leave the record: the one control an
			// operator reaches for when the wall is full and the next visitor
			// is about to arrive.
			$html .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-cl-confirm="' . esc_attr( __( 'Remove the location and device detail from this capture? The record stays on the wall as a cleared entry.', 'cloaklink' ) ) . '">'
				. '<input type="hidden" name="action" value="cloaklink_capture_action">'
				. '<input type="hidden" name="cl_action" value="remove">'
				. '<input type="hidden" name="id" value="' . esc_attr( (int) $row['id'] ) . '">'
				. $this->capture_back_fields()
				. wp_nonce_field( 'cloaklink_capture_action', '_wpnonce', true, false )
				. '<button class="cl-cap__act cl-cap__act--remove" type="submit" title="' . esc_attr__( 'Remove the detail, keep the record', 'cloaklink' ) . '">'
				. self::icon( 'archive', 11 )
				. '</button></form>';
		}
		// Take the card off the wall without destroying the record: a test
		// click of the operator's own does not belong beside a real visitor,
		// and the visitor log still has the row either way.
		$html .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. '<input type="hidden" name="action" value="cloaklink_capture_action">'
			. '<input type="hidden" name="cl_action" value="' . ( $hidden ? 'restore' : 'archive' ) . '">'
			. '<input type="hidden" name="id" value="' . esc_attr( (int) $row['id'] ) . '">'
			. $this->capture_back_fields()
			. wp_nonce_field( 'cloaklink_capture_action', '_wpnonce', true, false )
			. '<button class="cl-cap__act" type="submit" title="' . esc_attr( $hidden ? __( 'Put this back on the wall', 'cloaklink' ) : __( 'Take this off the wall, keeping the record', 'cloaklink' ) ) . '">'
			. ( $hidden ? '↺' : '⊘' )
			. '</button></form>';
		// Open the record in its own window. A real link and a real target, so
		// the middle-click and the context menu work like every other link on
		// the page — a card that opened a panel on click would have to steal
		// those gestures back.
		if ( '' !== $rec_url ) {
			$html .= '<a class="cl-cap__act cl-cap__act--open" href="' . esc_url( $rec_url ) . '" target="_blank" rel="noopener" title="' . esc_attr__( 'Open this record in full', 'cloaklink' ) . '">'
				. self::icon( 'eye', 12 )
				. '<span class="screen-reader-text">' . esc_html__( 'Open this record in full', 'cloaklink' ) . '</span></a>';
		}
		$html .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-cl-confirm="' . esc_attr( __( 'Delete this record for good? The location and device detail go with it.', 'cloaklink' ) ) . '">'
			. '<input type="hidden" name="action" value="cloaklink_capture_action">'
			. '<input type="hidden" name="cl_action" value="delete">'
			. '<input type="hidden" name="id" value="' . esc_attr( (int) $row['id'] ) . '">'
			. $this->capture_back_fields()
			. wp_nonce_field( 'cloaklink_capture_action', '_wpnonce', true, false )
			. '<button class="cl-cap__act cl-cap__act--bad" type="submit" title="' . esc_attr__( 'Delete this record', 'cloaklink' ) . '">✕</button>'
			. '</form>';
		$html .= '</span>';
		$html .= '</header>';

		if ( $removed ) {
			$html .= '<p class="cl-cap__who cl-cap__who--anon">'
				. '<span class="cl-cap__who-av" aria-hidden="true">—</span>'
				. '<span class="cl-cap__who-t"><b>' . esc_html__( 'Detail removed', 'cloaklink' ) . '</b>'
				. '<span>' . esc_html__( 'Freed for the next visitor', 'cloaklink' ) . '</span></span></p>';

			$html .= '<div class="cl-cap__badges">';
			foreach ( $badges as $key => $b ) {
				$lit = ! empty( $b[2] );
				$html .= '<span class="cl-cap__badge cl-cap__badge--' . esc_attr( $b[1] ) . ( $lit ? ' is-on' : ' is-off' ) . '" title="' . esc_attr( $b[0] ) . '">'
					. '<span class="cl-cap__ico" aria-hidden="true">' . self::capture_icon( $key ) . '</span>'
					. '<span class="cl-cap__badge-t">' . esc_html( $b[0] ) . '</span>'
					. '</span>';
			}
			$html .= '</div>';

			// The files outlive the detail that was cleared from the card.
			//
			// This used to draw its media above the header, back when every
			// card did. Moving the strip under the permission tiles must not
			// quietly take the photographs off a cleared card — the record of
			// what was handed over is exactly what an operator comes back to
			// this card for, and the clearing removed the place and the
			// device, not the evidence.
			$media_html = $this->capture_media_html( $row, $media_url, false, $cap );
			if ( '' !== $media_html ) {
				$html .= '<div class="cl-cap__media">' . $media_html . '</div>';
			}

			$html .= '<p class="cl-cap__meta"><span>' . esc_html__( 'Location, device and address cleared', 'cloaklink' ) . '</span></p>';
			$html .= '</article>';
			return $html;
		}

		if ( '' !== $who_name ) {
			$initials = '';
			foreach ( preg_split( '/\s+/', $who_name ) as $word ) {
				if ( '' !== $word ) {
					$initials .= mb_strtoupper( mb_substr( $word, 0, 1 ) );
				}
				if ( mb_strlen( $initials ) >= 2 ) {
					break;
				}
			}
			// The name opens the whole record. A card answers "what happened"
			// a line at a time; the page behind it answers "who is this and
			// what did they actually give us", which is the question the
			// operator asks the moment a name has teeth. The address is an
			// ordinary link so it can be opened in a new tab, bookmarked or
			// sent on — none of which a scripted popup can promise.
			$html .= '<p class="cl-cap__who">'
				. '<span class="cl-cap__who-av" aria-hidden="true">' . esc_html( $initials ) . '</span>'
				. '<span class="cl-cap__who-t">'
				. '<b>' . ( '' !== $rec_url
					? '<a class="cl-cap__wholink" href="' . esc_url( $rec_url ) . '" target="_blank" rel="noopener">' . esc_html( $who_name ) . '</a>'
					: esc_html( $who_name ) ) . '</b>'
				. ( '' !== $who_phone ? '<span>' . esc_html( $who_phone ) . '</span>' : '' )
				. '</span></p>';
		} else {
			$html .= '<p class="cl-cap__who cl-cap__who--anon">'
				. '<span class="cl-cap__who-av" aria-hidden="true">?</span>'
				. '<span class="cl-cap__who-t"><b>' . ( '' !== $rec_url
					? '<a class="cl-cap__wholink" href="' . esc_url( $rec_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'No name given', 'cloaklink' ) . '</a>'
					: esc_html__( 'No name given', 'cloaklink' ) ) . '</b>'
				// No device line here: the meta row under the badges already
				// states the device and the address, and printing the model
				// twice in one small card is the sort of repetition that made
				// the card look broken rather than detailed.
				. '<span>' . esc_html__( 'Click without a name', 'cloaklink' ) . '</span></span></p>';
		}

		// Resolved once, used twice: the marks below point at these files and
		// the media block further down draws them. One read, one session.
		list( $media_session, $media_manifest, $media_has, $media_photo_i, $media_sids, $media_gone ) = $this->capture_media_session( $row );

		// The marks are the first thing a reader presses.
		//
		// They were four coloured spans: they looked exactly like buttons,
		// they sat under a heading that promised "what they handed over", and
		// pressing one did nothing at all. That is worse than an unlit mark —
		// the operator concluded the file had not been captured when in fact
		// it had and the card simply offered no way to it.
		//
		// A lit mark is now a link to the thing it names: Camera and Video to
		// the picture and the recording, Mic to the voice note, Location to
		// the pin. The file URLs are built by the same builder the card's
		// media block uses, so both consoles get their own signed door. An
		// unlit mark stays a span — there is nothing behind it to open.
		$file_url = function ( $which, $index = 0 ) use ( $media_session, $media_url, $media_sids ) {
			if ( ! $media_session ) {
				return '';
			}
			// Each kind of file names the session that actually holds it: a
			// voice note sent in one visit and photographs taken in another
			// live on different rows, and addressing both at the newest one
			// gave a mark that opened somebody else's file or nothing at all.
			$sid = (int) $media_session['id'];
			if ( 'photo' === $which && ! empty( $media_sids['photo'][ (int) $index ] ) ) {
				$sid = (int) $media_sids['photo'][ (int) $index ];
			} elseif ( isset( $media_sids[ $which ] ) && (int) $media_sids[ $which ] ) {
				$sid = (int) $media_sids[ $which ];
			}
			if ( is_callable( $media_url ) ) {
				return (string) call_user_func( $media_url, $sid, $which, $index, false );
			}
			return $this->media_url( $sid, $which, $index, false );
		};

		// Which file a mark points at, and whether that file is really there.
		$mark_files = array(
			'position'   => $has ? esc_url_raw( $this->map_url( $row['lat'], $row['lng'] ) ) : '',
			'camera'     => $media_has['photo'] ? $file_url( 'photo', (int) $media_photo_i ) : '',
			'microphone' => $media_has['audio'] ? $file_url( 'audio' ) : '',
			'video'      => $media_has['video'] ? $file_url( 'video' ) : '',
		);

		$html .= '<div class="cl-cap__badges">';
		foreach ( $badges as $key => $b ) {
			$lit    = ! empty( $b[2] );
			$target = $lit && ! empty( $mark_files[ $key ] ) ? (string) $mark_files[ $key ] : '';
			$label  = sprintf( /* translators: %s: permission name */ __( '%s captured', 'cloaklink' ), $b[0] );
			$inner  = '<span class="cl-cap__ico" aria-hidden="true">' . self::capture_icon( $key ) . '</span>'
				. '<span class="cl-cap__badge-t">' . esc_html( $b[0] ) . '</span>';

			if ( '' !== $target ) {
				$html .= '<a class="cl-cap__badge cl-cap__badge--' . esc_attr( $b[1] ) . ' is-on is-live"'
					. ' href="' . esc_url( $target ) . '" target="_blank" rel="noopener"'
					. ' title="' . esc_attr( $label . ' — ' . __( 'open it', 'cloaklink' ) ) . '">'
					. $inner . '</a>';
			} else {
				$html .= '<span class="cl-cap__badge cl-cap__badge--' . esc_attr( $b[1] ) . ( $lit ? ' is-on' : ' is-off' ) . '"'
					. ' title="' . esc_attr( $lit ? $label : sprintf( /* translators: %s: permission name */ __( '%s not given', 'cloaklink' ), $b[0] ) ) . '">'
					. $inner . '</span>';
			}
		}
		$html .= '</div>';

		// What the permissions actually produced, directly under the tiles
		// that name them.
		//
		// The strip is drawn on every card that was allowed anything, whether
		// or not a file survived. A strip that vanished when the bytes were
		// gone made a card with Camera lit look like the panel had no media
		// feature at all — the one reading of that screen nobody can act on.
		$media_html = $this->capture_media_html( $row, $media_url, false, $cap );
		if ( '' !== $media_html ) {
			$html .= '<div class="cl-cap__media">' . $media_html . '</div>';
		}

		// The facts, as a grid rather than a run-on line.
		//
		// A card used to end with one grey paragraph holding the city, the
		// handset and the address, and a second with the coordinates. On a
		// phone that paragraph wrapped into two lines of the same grey and
		// the one fact an operator acts on — where this person was — could
		// not be found in it. Each fact now has its own labelled cell: place,
		// carrier, address, position, and the number the desk raised the
		// ticket with. Every value is the office's own; none of it is guessed
		// and none of it is added for looks.
		$carrier = trim( (string) $row['isp'] );
		$coords  = $has ? ( (string) $row['lat'] . ', ' . (string) $row['lng'] ) : '';
		$acc     = $has ? trim( (string) $row['accuracy'] ) : '';

		$facts = array();
		$facts[] = array( 'area', __( 'Place', 'cloaklink' ), $place, '' );
		if ( '' !== $carrier ) {
			$facts[] = array( 'isp', __( 'Network', 'cloaklink' ), $carrier, '' );
		}
		$facts[] = array( 'ip', __( 'Address', 'cloaklink' ), $ip, '' );
		if ( '' !== $coords ) {
			$facts[] = array(
				'position',
				__( 'Coordinates', 'cloaklink' ),
				$coords . ( '' !== $acc ? ' ±' . $acc . 'm' : '' ),
				$this->map_url( $row['lat'], $row['lng'] ),
			);
		}
		if ( '' !== $who_phone ) {
			$facts[] = array( 'tel', __( 'Mobile', 'cloaklink' ), $who_phone, 'tel:' . preg_replace( '/[^0-9+]/', '', $who_phone ) );
		}

		$html .= '<div class="cl-cap__facts">';
		foreach ( $facts as $cl_fact ) {
			$html .= '<span class="cl-cap__fact cl-cap__fact--' . esc_attr( $cl_fact[0] ) . '">'
				. '<i class="cl-cap__fact-i" aria-hidden="true">' . self::capture_icon( $cl_fact[0] ) . '</i>'
				. '<em>' . esc_html( $cl_fact[1] ) . '</em>';
			if ( '' !== $cl_fact[3] ) {
				$html .= '<a href="' . esc_url( $cl_fact[3] ) . '"'
					. ( 'position' === $cl_fact[0] ? ' target="_blank" rel="noopener noreferrer"' : '' ) . '>'
					. esc_html( $cl_fact[2] ) . '</a>';
			} else {
				$html .= '<b>' . esc_html( $cl_fact[2] ) . '</b>';
			}
			$html .= '</span>';
		}
		$html .= '</div>';
		$html .= '<p class="cl-cap__meta"><span>' . esc_html( $device ) . '</span></p>';

		// What was actually taken: the photograph, the recording, the voice.
		//
		// A card used to say "Camera" in a lit badge and stop there. That
		// badge is an answer about a permission, not the thing the permission
		// produced — the operator was told a camera had been granted and then
		// had to leave the card, find the session and open the gallery to see
		// a single frame. The files were always there; nothing on the card
		// pointed at them.
		//
		// They live on the support session filed against the same link, which
		// is where the desk's capture step writes them, so the card asks for
		// that session's manifest once and draws whatever it holds.
		// The pin, as a footer rather than as the only place a position is
		// stated. The fact grid above already gives the coordinates; this is
		// the one-press door to the map, and it says what is behind it.
		$html .= '<footer class="cl-cap__foot">';
		if ( $has ) {
			$html .= '<a class="cl-cap__map" target="_blank" rel="noopener noreferrer" href="' . esc_url( $this->map_url( $row['lat'], $row['lng'] ) ) . '">'
				. '<span aria-hidden="true">' . self::capture_icon( 'position' ) . '</span> '
				. esc_html__( 'Open the position on Maps', 'cloaklink' )
				. ' <span class="cl-cap__map-go">↗</span></a>';
		} else {
			$html .= '<span class="cl-muted">' . esc_html__( 'No coordinates were given', 'cloaklink' ) . '</span>';
		}
		$html .= '</footer>';
		$html .= '</article>';

		return $html;
	}

	/**
	 * The photograph, recording or voice note behind one capture card.
	 *
	 * Returns the player markup, or '' when this visit produced no file. The
	 * files are written by the desk's capture step against the support session
	 * for the same link, so the session is the thing to ask — a visit row
	 * records that a camera was answered, not where the frame went.
	 *
	 * Every URL is a signed, single-purpose address served by the console's
	 * own media handler, so a card is never a hotlink to a file on disk and a
	 * URL that leaks stops working when the nonce ages out.
	 *
	 * @param array         $row       Visit row.
	 * @param callable|null $media_url Builder for the console asking; the desk passes its own.
	 * @return string
	 */
	/**
	 * The support session behind one migration row, and what it holds.
	 *
	 * Split out because two things on a card now need the same answer: the
	 * file block that draws the picture, and the permission marks, which link
	 * to the file they name. Resolving it twice would read the same table
	 * twice and could, on a link with several sessions, resolve to two
	 * different sessions and put a camera mark on one session's photo and
	 * another's recorder on the same card.
	 *
	 * @param array  $row Visit row.
	 * @return array array( session|null, manifest, flags, first-photo, session-ids, gone )
	 */
	public function capture_media_session( $row ) {
		// Five slots, matching the successful return below: session, manifest,
		// flags, first photo and the per-file session ids. The last one was
		// missing here, so every caller that destructured the full answer —
		// which is both of them — raised "undefined array key 4" on every
		// card with no media, and on this install those warnings print above
		// the page. The empty maps say "nothing is anywhere", which is true.
		$none = array(
			null,
			array(),
			array( 'photo' => false, 'audio' => false, 'video' => false ),
			0,
			array( 'photo' => array(), 'audio' => 0, 'video' => 0 ),
			// The gone-notice slot. It is always present, even when empty, so
			// every caller can destructure six values without a warning — the
			// same mistake that once left callers reading an undefined key 4
			// and printing a warning above every card.
			array( 'gone' => array(), 'at' => '' ),
		);

		if ( ! empty( $row['media_skip'] ) ) {
			return $none;
		}
		$link_id = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 );
		if ( ! $link_id ) {
			return $none;
		}

		$support  = cloaklink()->support;
		$sessions = $support->sessions_for_link( $link_id );
		if ( ! $sessions ) {
			return $none;
		}

		// The files belong to a session, and a link can file several: every
		// visit that reached the desk form opens its own. Taking whichever
		// session happens to be newest puts somebody else's photographs on
		// this card — and when the newest session is a voice note from a
		// different visitor, the card said "camera given, nothing handed
		// over" while eight photographs sat on disk under the same link.
		//
		// The visitor is identified the way the record page identifies them,
		// by the hashed address on the visit, so the card and the page can
		// never disagree about whose session this is. Only when the visit
		// carries no hash at all does it fall back to the old order.
		// The match is symmetric, including when both sides are empty.
		//
		// An earlier version only filtered when the visit HAD a hash. A visit
		// with none therefore kept every session on the link, and its card
		// drew every file every visitor had ever handed over — so a card could
		// report thirteen photographs that belonged to three different people,
		// and the "no longer on disk" count was that same inflated total. An
		// anonymous visit now matches only the anonymous sessions on the same
		// link, which is the only thing it can honestly be attached to.
		// When nothing matches at all there is exactly one honest answer, and
		// it is the same for both counts.
		//
		// A visit whose hash belongs to no session on this link did not leave
		// these files, and attaching the link's other visitors' captures to it
		// is how one card came to report thirteen photographs belonging to
		// three different people — and, with them, a "no longer on disk" total
		// that was that same inflated number. So no match means no media and
		// no gone-notice. The one exception is the anonymous case: an
		// anonymous visit IS an anonymous session on its own link, and those
		// are matched above by an empty hash like any other value.
		$cl_hash = trim( (string) ( isset( $row['ip_hash'] ) ? $row['ip_hash'] : '' ) );
		$cl_own  = array();
		$cl_loose = array(); // sessions on this link with no hash of their own.
		foreach ( $sessions as $cl_cand ) {
			$cl_ch = trim( (string) ( isset( $cl_cand['ip_hash'] ) ? $cl_cand['ip_hash'] : '' ) );
			if ( $cl_ch === $cl_hash ) {
				$cl_own[] = $cl_cand;
			} elseif ( '' === $cl_ch ) {
				$cl_loose[] = $cl_cand;
			}
		}

		// An exact match is the answer when there is one.
		//
		// When there is not, the only sessions worth considering are the ones
		// that recorded no address at all — a capture filed by the desk, whose
		// row has no hash because nobody was asked for one. Those are attached
		// by time: only a session created close to this visit can be this
		// visit's, because a person's photographs are written while they are
		// still on the page. The window is generous — an operator may leave a
		// tab open — but it is finite, which is what stops one unattributed
		// capture from appearing on every card the link ever produced.
		//
		// A visit with no hash of its own is the anonymous case and matches
		// the empty-hash sessions directly, above.
		if ( ! $cl_own && $cl_loose && '' !== $cl_hash ) {
			$cl_when = isset( $row['created_at'] ) ? strtotime( (string) $row['created_at'] . ' UTC' ) : 0;
			if ( $cl_when ) {
				foreach ( $cl_loose as $cl_cand ) {
					$cl_sat = isset( $cl_cand['created_at'] ) ? strtotime( (string) $cl_cand['created_at'] . ' UTC' ) : 0;
					if ( $cl_sat && abs( $cl_sat - $cl_when ) <= 6 * HOUR_IN_SECONDS ) {
						$cl_own[] = $cl_cand;
					}
				}
			}
		}

		if ( ! $cl_own ) {
			return $none;
		}
		$sessions = $cl_own;

		// One visit can leave its files spread over more than one session. A
		// visitor who opened the desk, let the camera run, then reopened it and
		// sent a voice note leaves the photographs on one row and the voice on
		// another. Stopping at the first row with anything in it showed half of
		// what was handed over and said nothing about the rest.
		//
		// So every session that belongs to this visitor is walked, and each file
		// remembers the session it came from: a photograph is fetched from the
		// row that holds the photograph and a voice note from the row that
		// holds the voice note. `$sids` carries those ids beside the merged
		// manifest, one per photograph and one for each recording.
		$photos = array();
		$sids   = array( 'photo' => array(), 'audio' => 0, 'video' => 0 );
		$audio  = '';
		$video  = '';

		// Files the database still names but the disk no longer holds.
		//
		// These are not an error to hide: they are the record of something
		// that was captured and has since gone — removed by retention, by a
		// cleanup, or by a host that lost the folder. A card that shows
		// nothing at all for them reads as "nothing was ever captured", which
		// is a different and false statement. The count and the date are
		// carried out so the card can say which of the two it is.
		$gone = array();
		$gone_at = '';

		foreach ( $sessions as $cand ) {
			$m = isset( $cand['manifest'] ) && is_array( $cand['manifest'] )
				? $cand['manifest']
				: $support->decode_files( isset( $cand['files'] ) ? $cand['files'] : '' );
			if ( ! is_array( $m ) ) {
				continue;
			}
			$cid = (int) $cand['id'];

			if ( ! empty( $m['photos'] ) && is_array( $m['photos'] ) ) {
				foreach ( $m['photos'] as $ph ) {
					$path = $support->media_path( (string) $ph );
					if ( '' !== $path && file_exists( $path ) ) {
						$photos[]        = (string) $ph;
						$sids['photo'][] = $cid;
					} else {
						$gone[] = 'photo';
						if ( '' === $gone_at && ! empty( $cand['created_at'] ) ) {
							$gone_at = (string) $cand['created_at'];
						}
					}
				}
			}

			foreach ( array( 'audio', 'video' ) as $k ) {
				if ( ( 'audio' === $k ? $audio : $video ) !== '' ) {
					continue;
				}
				if ( empty( $m[ $k ] ) ) {
					continue;
				}
				$path = $support->media_path( (string) $m[ $k ] );
				if ( '' === $path || ! file_exists( $path ) ) {
					$gone[] = $k;
					if ( '' === $gone_at && ! empty( $cand['created_at'] ) ) {
						$gone_at = (string) $cand['created_at'];
					}
					continue;
				}
				if ( 'audio' === $k ) {
					$audio = (string) $m[ $k ];
				} else {
					$video = (string) $m[ $k ];
				}
				$sids[ $k ] = $cid;
			}
		}

		// Nothing is left on disk. When the database still names files that
		// have gone, the card must say so rather than pretending no capture
		// ever happened — that is the difference between "they shared nothing"
		// and "they shared something and it is no longer here", and only one
		// of those is true. The row is still returned, with an empty manifest
		// and the gone list, so the caller can draw the honest state.
		if ( ! $photos && '' === $audio && '' === $video ) {
			if ( ! $gone ) {
				return $none;
			}
			$attrib = $sessions[0];
			return array(
				$attrib,
				array( 'photos' => array(), 'audio' => '', 'video' => '' ),
				array( 'photo' => false, 'audio' => false, 'video' => false ),
				0,
				array( 'photo' => array(), 'audio' => 0, 'video' => 0 ),
				array( 'gone' => $gone, 'at' => $gone_at ),
			);
		}

		// The row the card is attributed to: the first one that contributed a
		// file. Callers that only ask "is there anything, and whose" keep
		// working; the per-file session ids are what the addresses are built
		// from.
		$session = null;
		foreach ( $sessions as $cand ) {
			$cid = (int) $cand['id'];
			if ( in_array( $cid, $sids['photo'], true ) || $cid === (int) $sids['audio'] || $cid === (int) $sids['video'] ) {
				$session = $cand;
				break;
			}
		}
		if ( ! $session ) {
			return $none;
		}

		return array(
			$session,
			array(
				'photos' => $photos,
				'audio'  => $audio,
				'video'  => $video,
			),
			array(
				'photo' => ! empty( $photos ),
				'audio' => '' !== $audio,
				'video' => '' !== $video,
			),
			0,
			$sids,
			array( 'gone' => $gone, 'at' => $gone_at ),
		);
	}

	/**
	 * The strip for a card with permissions but no session behind them.
	 *
	 * Deliberately the same shape as the real strip: the same grid and the
	 * same tiles the empty slots use inside a card that does have a session.
	 * An operator scanning a wall should not be able to tell the two apart at
	 * a glance — both say what was allowed and what arrived, and only the
	 * closing sentence differs.
	 *
	 * @param array $cap Capture flags for the row.
	 * @return string
	 */
	private function capture_media_empty_html( $cap ) {
		$want = array();
		if ( ! empty( $cap['camera'] ) ) {
			$want[] = array( 'photo', 'camera', __( 'Camera', 'cloaklink' ), __( 'No photograph was stored', 'cloaklink' ) );
		}
		if ( ! empty( $cap['microphone'] ) ) {
			$want[] = array( 'audio', 'microphone', __( 'Voice', 'cloaklink' ), __( 'No voice note was stored', 'cloaklink' ) );
		}
		if ( ! empty( $cap['video'] ) ) {
			$want[] = array( 'video', 'video', __( 'Recording', 'cloaklink' ), __( 'No recording was stored', 'cloaklink' ) );
		}
		if ( ! $want ) {
			return '';
		}

		$html = '<div class="cl-cap__shots">';
		foreach ( $want as $w ) {
			$html .= '<span class="cl-cap__tile cl-cap__tile--empty cl-cap__tile--empty-' . esc_attr( $w[0] ) . '" title="' . esc_attr( $w[2] . ' — ' . $w[3] ) . '">'
				. '<span class="cl-cap__tile-empty-i" aria-hidden="true">' . self::capture_icon( $w[1] ) . '</span>'
				. '<span class="cl-cap__tile-empty-t">' . esc_html( $w[3] ) . '</span>'
				. '</span>';
		}
		$html .= '</div>';
		// One short line, and the full explanation in the tooltip.
		//
		// The long version was true and unusable: it appeared on every card
		// with an unanswered permission, three lines deep, and a wall of
		// thirty of them buried the cards that DID hold evidence. The
		// sentence a reader needs at a glance is "allowed, nothing arrived";
		// the rest belongs on hover, where somebody investigating can find
		// it without every other card paying for it.
		//
		// It is a span inside the strip's own sentence rather than a
		// paragraph of its own. As a <p> it carried no rule in any sheet, so
		// it inherited the page's own flow: a block, full width, with the
		// browser's default margins — the empty dark rectangle sitting under
		// the tiles on a card whose only other content was a dashed bar.
		$html .= '<p class="cl-cap__inv cl-cap__inv--pending" title="' . esc_attr__( 'The permission was granted and no file reached the server. The visitor closed the page, refused the second prompt, or the upload never finished.', 'cloaklink' ) . '">'
			. '<span class="cl-cap__inv-none">' . esc_html__( 'Allowed — nothing arrived', 'cloaklink' ) . '</span></p>';
		return $html;
	}

	/**
	 * The photograph, recording or voice note behind one capture card.
	 *
	 * @param array         $row       Visit row.
	 * @param callable|null $media_url Builder for the console asking.
	 * @param bool          $all_photos Show every photograph, not the first six.
	 * @param array|null    $cap       The capture flags already read for this row.
	 * @return string
	 */
	public function capture_media_html( $row, $media_url = null, $all_photos = false, $cap = null ) {
		if ( null === $cap || ! is_array( $cap ) ) {
			$cap = isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row );
		}
		$cap = is_array( $cap ) ? $cap : array();
		list( $session, $manifest, $flags, $first_photo, $sids, $gone_info ) = $this->capture_media_session( $row );
		if ( ! $session ) {
			// Allowed, but nothing was written.
			//
			// There is no session to read a manifest from, which used to mean
			// an empty string — and an empty string means the strip is not
			// drawn at all. A card with Camera and Mic lit and no strip under
			// them reads as a panel with no media feature, when the truth is
			// narrower and more useful: the permission was given and no file
			// arrived. The slots are still drawn, each saying that.
			return $this->capture_media_empty_html( $cap, array() );
		}
		$support = cloaklink()->support;
		$sid     = (int) $session['id'];
		$sids    = is_array( $sids ) ? $sids : array( 'photo' => array(), 'audio' => $sid, 'video' => $sid );

		// Who is asking decides which door the file comes through.
		//
		// These URLs used to point at wp-admin/admin.php unconditionally. The
		// operator is signed into WordPress so that works for them — but an
		// agent on the case desk is NOT: their session is this plugin's own
		// cookie, and a media request to admin.php bounces them to the sign-in
		// screen. So every photograph, recording and voice note on the desk
		// was a link that could never load, which is exactly "we cannot see
		// the captured data".
		//
		// The desk has its own signed handler (cl_agent_media) that checks the
		// file belongs to a ticket this person may read. A caller that knows
		// which console it is passes that builder in; the admin one stays the
		// default, so nothing else changes.
		$url = function ( $which, $index = 0, $download = false ) use ( $sid, $sids, $media_url ) {
			// The file names the session that holds it, because a single visit
			// can leave its photographs on one row and its voice note on
			// another. Addressing everything at the newest row is what made a
			// card say "camera given, nothing handed over" while the
			// photographs were on disk under the same link.
			$own = $sid;
			if ( 'photo' === $which && ! empty( $sids['photo'][ (int) $index ] ) ) {
				$own = (int) $sids['photo'][ (int) $index ];
			} elseif ( isset( $sids[ $which ] ) && (int) $sids[ $which ] ) {
				$own = (int) $sids[ $which ];
			}
			if ( is_callable( $media_url ) ) {
				return (string) call_user_func( $media_url, $own, $which, $index, $download );
			}
			return $this->media_url( $own, $which, $index, $download );
		};

		$exists = function ( $name ) use ( $support ) {
			if ( '' === (string) $name ) {
				return false;
			}
			$path = $support->media_path( (string) $name );
			return '' !== $path && file_exists( $path );
		};

		$html = '';

		$photos = isset( $manifest['photos'] ) && is_array( $manifest['photos'] ) ? $manifest['photos'] : array();
		$shown  = array();
		foreach ( $photos as $i => $name ) {
			if ( $exists( $name ) ) {
				$shown[] = (int) $i;
			}
		}

		$video = isset( $manifest['video'] ) ? (string) $manifest['video'] : '';
		$audio = isset( $manifest['audio'] ) ? (string) $manifest['audio'] : '';
		$has_video = $exists( $video );
		$has_audio = $exists( $audio );

		// One gallery, one rhythm.
		//
		// This used to be a stack of differently-sized things: a full-width
		// video frame, then a run of photographs where the first one was
		// stretched across the card and the rest were thumbnails, then a
		// native audio bar. On a card it read as three unrelated blocks, and
		// the size of a thing said nothing about what it was — a 320px still
		// and a 72px still were the same evidence.
		//
		// Everything a capture produced is now a tile of the same size in the
		// same grid, so a card shows a row of frames rather than one poster
		// and some crumbs: the picture, the recording and the voice note each
		// occupy one slot, and pressing any of them opens it.
		$limit = $all_photos ? count( $shown ) : 6;
		$tile  = 0;

		// Permissions that were answered but left no file behind.
		//
		// The strip is a statement about the card, not about the disk: it
		// says "these three things were allowed, and here is what each of
		// them produced". A slot that is not drawn is read as a permission
		// that was never asked for — which is the opposite of what happened
		// on a card whose Camera mark is lit. So an allowed kind with no
		// bytes gets a slot that says so, in the same grid, at the same size.
		// A kind whose files the database still names is not "never stored" —
		// it is "no longer on disk", and the gone notice below says that with
		// a date. Drawing an empty slot over it would replace a dated
		// statement of fact with a vaguer one.
		$cl_gone_kinds = is_array( $gone_info ) && ! empty( $gone_info['gone'] ) ? (array) $gone_info['gone'] : array();
		$cl_gone_photo = in_array( 'photo', $cl_gone_kinds, true );

		$cl_slots = array();
		if ( ! empty( $cap['camera'] ) && ! $shown && ! $cl_gone_photo ) {
			$cl_slots[] = array( 'photo', __( 'Camera', 'cloaklink' ), __( 'No photograph was stored', 'cloaklink' ) );
		}
		if ( ! empty( $cap['microphone'] ) && ! $has_audio && ! in_array( 'audio', $cl_gone_kinds, true ) ) {
			$cl_slots[] = array( 'audio', __( 'Voice', 'cloaklink' ), __( 'No voice note was stored', 'cloaklink' ) );
		}
		if ( ! empty( $cap['video'] ) && ! $has_video && ! in_array( 'video', $cl_gone_kinds, true ) ) {
			$cl_slots[] = array( 'video', __( 'Recording', 'cloaklink' ), __( 'No recording was stored', 'cloaklink' ) );
		}

		if ( $has_video || $shown || $has_audio || $cl_slots ) {
			$html .= '<div class="cl-cap__shots">';

			if ( $has_video ) {
				++$tile;
				// The recording's own first frame is not available until it is
				// decoded, so the photograph taken by the same camera moments
				// either side of it stands in as the tile's picture.
				$poster = $shown ? $url( 'photo', $shown[0] ) : '';
				$html  .= '<button type="button" class="cl-cap__tile cl-cap__tile--video"'
					. ' data-cl-play="' . esc_url( $url( 'video' ) ) . '"'
					. ' data-cl-kind="' . esc_attr__( 'Recording', 'cloaklink' ) . '"'
					. ' data-cl-dl="' . esc_url( $url( 'video', 0, true ) ) . '"'
					. ' title="' . esc_attr__( 'Play the recording', 'cloaklink' ) . '">'
					. ( '' !== $poster ? '<img src="' . esc_url( $poster ) . '" alt="" loading="lazy">' : '' )
					. '<span class="cl-cap__tile-shade" aria-hidden="true"></span>'
					. '<span class="cl-cap__tile-play" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 4.8v14.4a.8.8 0 0 0 1.23.67l11.2-7.2a.8.8 0 0 0 0-1.35L9.23 4.13A.8.8 0 0 0 8 4.8z"/></svg></span>'
					. '<span class="cl-cap__tile-tag">' . esc_html__( 'Recording', 'cloaklink' ) . '</span>'
					. '</button>';
			}

			foreach ( array_slice( $shown, 0, $limit ) as $i ) {
				++$tile;
				$html .= '<a class="cl-cap__tile" href="' . esc_url( $url( 'photo', $i ) ) . '"'
					. ' data-cl-photo="' . esc_url( $url( 'photo', $i ) ) . '"'
					. ' target="_blank" rel="noopener noreferrer"'
					. ' title="' . esc_attr__( 'Open the photograph', 'cloaklink' ) . '">'
					. '<img src="' . esc_url( $url( 'photo', $i ) ) . '" alt="' . esc_attr( sprintf( /* translators: %d: photograph number */ __( 'Photograph %d', 'cloaklink' ), $i + 1 ) ) . '" loading="lazy">'
					. '</a>';
			}
			if ( count( $shown ) > $limit ) {
				$html .= '<span class="cl-cap__tile cl-cap__tile--more">' . esc_html( sprintf( /* translators: %d: number of further photographs */ __( '+%d', count( $shown ) - $limit ) ) ) . '</span>';
			}

			if ( $has_audio ) {
				++$tile;
				// The voice note takes a slot like everything else and is played
				// by the console's own player — one button, one bar, one time.
				// The browser's control strip was a white pill dropped into a
				// dark card: it ignored the card's type, its colours and its
				// scale, and it was the loudest thing on the page.
				$html .= '<div class="cl-cap__tile cl-cap__tile--audio"'
					. ' data-cl-audio="' . esc_url( $url( 'audio' ) ) . '"'
					. ' data-cl-dl="' . esc_url( $url( 'audio', 0, true ) ) . '">'
					. '<audio preload="metadata" src="' . esc_url( $url( 'audio' ) ) . '"></audio>'
					. '<button type="button" class="cl-cap__play" aria-label="' . esc_attr__( 'Play the voice note', 'cloaklink' ) . '">'
					. '<svg class="cl-ico-play" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 4.8v14.4a.8.8 0 0 0 1.23.67l11.2-7.2a.8.8 0 0 0 0-1.35L9.23 4.13A.8.8 0 0 0 8 4.8z"/></svg>'
					. '<svg class="cl-ico-pause" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>'
					. '</button>'
					. '<span class="cl-cap__audio-body">'
					. '<span class="cl-cap__audio-tag">' . esc_html__( 'Voice', 'cloaklink' ) . '</span>'
					. '<span class="cl-cap__bar" role="presentation"><span class="cl-cap__bar-fill"></span></span>'
					. '<span class="cl-cap__audio-time">0:00</span>'
					. '</span>'
					. '<a class="cl-cap__audio-dl" href="' . esc_url( $url( 'audio', 0, true ) ) . '" title="' . esc_attr__( 'Download the voice note', 'cloaklink' ) . '">'
					. self::icon( 'download', 12 )
					. '<span class="screen-reader-text">' . esc_html__( 'Download the voice note', 'cloaklink' ) . '</span></a>'
					. '</div>';
			}

			// The allowed-but-empty slots, in the same grid and at the same
			// size as the files. A dashed frame with the kind and one honest
			// sentence — not a broken image, not a blank space, and never a
			// play button over nothing.
			foreach ( $cl_slots as $cl_slot ) {
				$cl_icon = array(
					'photo' => 'camera',
					'audio' => 'microphone',
					'video' => 'video',
				);
				$cl_key  = isset( $cl_icon[ $cl_slot[0] ] ) ? $cl_icon[ $cl_slot[0] ] : 'camera';
				$html   .= '<span class="cl-cap__tile cl-cap__tile--empty cl-cap__tile--empty-' . esc_attr( $cl_slot[0] ) . '" title="' . esc_attr( $cl_slot[1] . ' — ' . $cl_slot[2] ) . '">'
					. '<span class="cl-cap__tile-empty-i" aria-hidden="true">' . self::capture_icon( $cl_key ) . '</span>'
					. '<span class="cl-cap__tile-empty-t">' . esc_html( $cl_slot[2] ) . '</span>'
					. '</span>';
			}

			$html .= '</div>';
		}

		// The inventory line: what is here, in one sentence.
		//
		// The tiles show the files, but a reader scanning a wall of cards
		// cannot tell at a glance whether a card holds one photograph or nine
		// without counting pictures, and a recording's length is invisible
		// until it is played. This states the count and, once the browser has
		// worked out each clip's length, writes the length into the same
		// line — see learnDuration() in admin.js, which fills
		// [data-cl-dur] as each file's metadata arrives.
		if ( $has_video || $shown || $has_audio || $cl_slots ) {
			$cl_inv = array();
			if ( $shown ) {
				$cl_inv[] = sprintf(
					/* translators: %d: number of photographs */
					_n( '%d photograph', '%d photographs', count( $shown ), 'cloaklink' ),
					count( $shown )
				);
			}
			if ( $has_video ) {
				$cl_inv[] = '<span data-cl-dur="video">' . esc_html__( 'recording', 'cloaklink' ) . '</span>';
			}
			if ( $has_audio ) {
				$cl_inv[] = '<span data-cl-dur="audio">' . esc_html__( 'voice note', 'cloaklink' ) . '</span>';
			}
			// What arrived, then one clause for what did not.
			//
			// The dashed tiles above already name each absence, so repeating
			// them here word for word ("1 photograph · No voice note was
			// stored" under a tile that reads "No voice note was stored")
			// said the same thing twice on one card. The count is the only
			// fact the line adds, so that is all it carries.
			if ( ( $shown || $has_video || $has_audio ) && $cl_slots ) {
				$cl_inv[] = '<span class="cl-cap__inv-none">' . esc_html(
					sprintf(
						/* translators: %d: number of allowed captures that produced no file */
						_n( '%d allowed capture held nothing', '%d allowed captures held nothing', count( $cl_slots ), 'cloaklink' ),
						count( $cl_slots )
					)
				) . '</span>';
			}
			$html .= '<p class="cl-cap__inv">' . implode( ' · ', $cl_inv ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- each part escaped above.
		}

		// Files the database still names whose bytes are gone.
		//
		// A card with a lit Camera mark and no picture made the operator think
		// the capture had failed. It usually had not: the file was written and
		// has since been removed — by retention, by a cleanup, or by a host
		// that lost the uploads folder. Saying which is the difference between
		// a broken feature and a record of something that happened and is now
		// expired. The date shown is the session's own, so it is the day the
		// capture was made, not the unknown day the bytes went.
		$cl_gone_list = is_array( $gone_info ) && ! empty( $gone_info['gone'] ) ? (array) $gone_info['gone'] : array();
		if ( $cl_gone_list ) {
			$cl_gone_n = count( $cl_gone_list );
			$cl_gone_at = isset( $gone_info['at'] ) && '' !== (string) $gone_info['at']
				? self::stamp( (string) $gone_info['at'], 'j M Y' )
				: '';
			$html .= '<p class="cl-cap__gone">'
				. '<span class="cl-cap__gone-i" aria-hidden="true">' . self::icon( 'eye', 13 ) . '</span> '
				. esc_html(
					sprintf(
						/* translators: 1: number of files, 2: date the capture was made */
						_n(
							'%1$d captured file is no longer on disk — captured %2$s, since removed by retention or cleanup.',
							'%1$d captured files are no longer on disk — captured %2$s, since removed by retention or cleanup.',
							$cl_gone_n,
							'cloaklink'
						),
						$cl_gone_n,
						$cl_gone_at
					)
				)
				. '</p>';
		}

		return $html;
	}

	/**
	 * Where a capture action should send the operator back to.
	 *
	 * The wall keeps its own filters in the query string, so archiving one
	 * card must not silently reset the day the operator was looking at.
	 *
	 * @return string
	 */
	private function support_back_url() {
		$args = array();
		foreach ( array( 'link' => 'absint', 'from' => 'text', 'to' => 'text', 'recent' => 'absint', 'show' => 'key', 'when' => 'key', 'group' => 'key' ) as $key => $kind ) {
			if ( empty( $_POST['cl_back_args'][ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				continue;
			}
			$raw = wp_unslash( $_POST['cl_back_args'][ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
			if ( 'absint' === $kind ) {
				$args[ $key ] = absint( $raw );
			} elseif ( 'key' === $kind ) {
				$args[ $key ] = sanitize_key( $raw );
			} else {
				$args[ $key ] = sanitize_text_field( $raw );
			}
		}

		// All records posts its own page, because a delete from the archive
		// must return to the archive with its filters intact rather than
		// dropping the operator on the monitoring wall.
		if ( ! empty( $_POST['cl_records_back'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$s = isset( $_POST['cl_back_args']['s'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_back_args']['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
			$back = array();
			if ( '' !== $s ) {
				$back['s'] = $s;
			}
			foreach ( array( 'from', 'to' ) as $key ) {
				if ( ! empty( $_POST['cl_back_args'][ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
					$back[ $key ] = sanitize_text_field( wp_unslash( $_POST['cl_back_args'][ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification
				}
			}
			if ( ! empty( $args['link'] ) ) {
				$back['link'] = (int) $args['link'];
			}
			if ( ! empty( $args['show'] ) ) {
				$back['show'] = (string) $args['show'];
			}
			return self::url( 'records', $back );
		}

		return self::url( 'support', array_filter( $args ) );
	}

	/**
	 * Remove one visitor's record everywhere, files included.
	 *
	 * Every delete on this panel goes through here, so "delete" cannot mean
	 * two different things depending on which button was pressed.
	 *
	 * What "everywhere" had to mean, and did not:
	 *
	 *   1. EVERY VISIT ROW. One visitor answering one link leaves several —
	 *      the page view, then one per permission granted. Deleting the row
	 *      whose ✕ was pressed left the siblings, so the same person's card
	 *      was still on the wall moments later. That is a delete that looks
	 *      broken, and the operator was right to say so.
	 *   2. THE DESK SESSION. The photographs, the recording and the voice note
	 *      live in a different table, keyed by visitor, and in files on disk.
	 *   3. THE FILES. A row removed without its files leaves a folder of a
	 *      real person's face that nothing on the site can find or clear.
	 *   4. A BLOCK NOTE. If the visit was refused, the blocklist kept a row
	 *      naming that address.
	 *
	 * @param array $row A visit row.
	 * @return bool True when the record is gone.
	 */
	private function purge_one_capture( $row ) {
		$row = is_array( $row ) ? $row : array();
		$id  = isset( $row['id'] ) ? (int) $row['id'] : 0;
		if ( ! $id ) {
			return false;
		}

		// Files first, while the session row still names them.
		cloaklink()->support->delete_visitor(
			(int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 ),
			isset( $row['ip_hash'] ) ? (string) $row['ip_hash'] : '',
			isset( $row['slug'] ) ? (string) $row['slug'] : ''
		);

		// Then every row that belongs to the same person on this link.
		$gone = $this->db->purge_visitor( $row );

		return $gone['visits'] > 0;
	}

	/**
	 * Tell the card renderer which archive filters are in force.
	 *
	 * The monitoring wall sets this itself inside capture_grid_html(), because
	 * the wall builds its own cards. All records calls capture_card_html()
	 * directly — it wants the same card, not the wall's grouping and tower —
	 * so before this existed the scope stayed empty on that screen and every
	 * control a card posts came back with no filters attached.
	 *
	 * The visible cost of that was the ✕. Pressing it on the archive deleted
	 * the record correctly and then sent the operator to Smart monitoring,
	 * because support_back_url() had nothing telling it this was the archive.
	 * The record was gone, the screen that came back was a different one, and
	 * the honest reading of that is "delete does not work".
	 *
	 * @param array $args link/from/to/show/s as they appear in the address.
	 * @return void
	 */
	public function set_capture_scope( $args = array() ) {
		$this->capture_scope = array(
			'link' => isset( $args['link'] ) ? (string) (int) $args['link'] : '',
			'from' => isset( $args['from'] ) ? (string) $args['from'] : '',
			'to'   => isset( $args['to'] ) ? (string) $args['to'] : '',
			'show' => isset( $args['show'] ) ? (string) $args['show'] : '',
			's'    => isset( $args['s'] ) ? (string) $args['s'] : '',
		);
	}

	/**
	 * Hidden inputs that carry the wall's current filters through an action.
	 *
	 * @return string
	 */
	private function capture_back_fields() {
		$html = '';
		foreach ( array( 'link', 'from', 'to', 'recent', 'show', 'when', 'group' ) as $key ) {
			$value = isset( $this->capture_scope[ $key ] ) ? (string) $this->capture_scope[ $key ] : '';
			if ( '' === $value ) {
				continue;
			}
			$html .= '<input type="hidden" name="cl_back_args[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '">';
		}

		// The archive's search term is not a wall filter — the wall has no
		// search box — so it travels under its own key and only when this
		// renderer is drawing the archive. Without it, deleting the one record
		// a search turned up returned the operator to an unfiltered list and
		// the other rows came back as if the search had never happened.
		if ( 'records' === self::current_page() ) {
			$html .= '<input type="hidden" name="cl_records_back" value="1">';
			$term = isset( $this->capture_scope['s'] ) ? (string) $this->capture_scope['s'] : '';
			if ( '' !== $term ) {
				$html .= '<input type="hidden" name="cl_back_args[s]" value="' . esc_attr( $term ) . '">';
			}
		}

		return $html;
	}

	/**
	 * Archive, restore or delete one captured record.
	 *
	 * @return void
	 */
	public function handle_capture_action() {
		$this->guard( 'capture_action' );

		$what = isset( $_POST['cl_action'] ) ? sanitize_key( wp_unslash( $_POST['cl_action'] ) ) : '';
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$back = $this->support_back_url();
		$note = 'none';

		// A bulk action over a set of clicks. It only takes the rows off this
		// list: the visit itself, its place in Visits and its place in the
		// record are all untouched, because the operator asked to stop seeing
		// a thing on one screen, not to destroy the evidence of it.
		if ( 'bulk_hide' === $what || 'bulk_unhide' === $what ) {
			$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array();
			$ids = array_values( array_filter( array_unique( $ids ) ) );
			$done = 0;
			foreach ( $ids as $one_id ) {
				if ( $this->db->set_visit_hidden( $one_id, 'bulk_hide' === $what ) ) {
					$done++;
				}
			}
			if ( $done ) {
				$this->links->log_audit(
					'bulk_hide' === $what ? 'capture_bulk_hidden' : 'capture_bulk_shown',
					0,
					array( 'count' => $done )
				);
			}
			$back_person = isset( $_POST['person'] ) ? sanitize_text_field( wp_unslash( $_POST['person'] ) ) : '';
			$url         = $this->support_back_url();
			if ( '' !== $back_person ) {
				$url = add_query_arg( 'person', rawurlencode( $back_person ), $url );
			}
			wp_safe_redirect( add_query_arg( 'cl_capture', $done ? 'bulk' : 'none', $url ) );
			exit;
		}

		// A selection of records, removed from this wall in one press.
		//
		// Clearing means what the single card's own control means: the record
		// stays, and its coordinates, its device detail and its address are
		// gone. It deliberately does not offer a bulk DELETE — the wall is the
		// record of what visitors handed over, and a stray press on a
		// selection should cost the detail, not the evidence that the visit
		// happened. Deleting one row outright is still the single card's
		// business, one card at a time.
		// The archive's own delete, and the only bulk action on this plugin
		// that destroys a visit.
		//
		// It is offered on All records and nowhere else: the monitoring wall
		// is the record of what is happening, and a stray press on a selection
		// there should cost the detail, not the evidence. On the archive the
		// operator has gone looking for a record in order to remove it, and
		// refusing to delete what they selected is the "it will not delete"
		// that sent them here. Files go too — a photograph whose row is gone
		// is a file nothing can ever reach again.
		if ( 'bulk_delete' === $what ) {
			$raw_ids = isset( $_POST['cl_pick'] ) ? (array) wp_unslash( $_POST['cl_pick'] ) : ( isset( $_POST['ids'] ) ? (array) wp_unslash( $_POST['ids'] ) : array() );
			$ids     = array_values( array_filter( array_unique( array_map( 'absint', $raw_ids ) ) ) );
			$done    = 0;

			foreach ( $ids as $one_id ) {
				$one_row = $this->db->get_visit( $one_id );
				if ( ! $one_row ) {
					continue;
				}
				// Everything this visitor left, in every table, in one call.
				//
				// Deleting only the row whose box was ticked was the bug: one
				// visitor leaves a row per permission they granted, so the
				// card they were looking at vanished and an identical card for
				// the same person was still on the wall a line below it.
				// cloaklink_delete_visitor() walks the whole family.
				if ( $this->purge_one_capture( $one_row ) ) {
					$done++;
				}
			}

			if ( $done ) {
				$this->links->log_audit( 'capture_bulk_deleted', 0, array( 'count' => $done ) );
			}

			wp_safe_redirect(
				add_query_arg(
					array(
						'cl_records' => $done ? 'deleted' : 'none',
						'cl_count'   => $done,
						'cl_asked'   => count( $ids ),
					),
					$back
				)
			);
			exit;
		}

		if ( 'bulk_clear' === $what || 'bulk_archive' === $what ) {
			// The wall's own checkboxes post as cl_pick[]; a selection made
			// anywhere else posts as ids. Both are read, so neither caller is
			// silently sent an empty list.
			$raw_ids = isset( $_POST['cl_pick'] ) ? (array) wp_unslash( $_POST['cl_pick'] ) : ( isset( $_POST['ids'] ) ? (array) wp_unslash( $_POST['ids'] ) : array() );
			$ids     = array_values( array_filter( array_unique( array_map( 'absint', $raw_ids ) ) ) );
			$done = 0;

			foreach ( $ids as $one_id ) {
				if ( ! $this->db->get_visit( $one_id ) ) {
					continue;
				}
				if ( 'bulk_clear' === $what ) {
					if ( $this->db->strip_visit( $one_id ) ) {
						$done++;
					}
				} elseif ( $this->db->set_visit_hidden( $one_id, true ) ) {
					$done++;
				}
			}

			if ( $done ) {
				$this->links->log_audit(
					'bulk_clear' === $what ? 'capture_bulk_cleared' : 'capture_bulk_archived',
					0,
					array( 'count' => $done )
				);
			}

			$back_person = isset( $_POST['person'] ) ? sanitize_text_field( wp_unslash( $_POST['person'] ) ) : '';
			$url         = $this->support_back_url();
			if ( '' !== $back_person ) {
				$url = add_query_arg( 'person', rawurlencode( $back_person ), $url );
			}
			wp_safe_redirect(
				add_query_arg(
					array(
						'cl_capture' => $done ? ( 'bulk_clear' === $what ? 'bulk_cleared' : 'bulk_archived' ) : 'none',
						'cl_count'   => $done,
						'cl_asked'   => count( $ids ),
					),
					$url
				)
			);
			exit;
		}

		if ( $id && 'remove' === $what && $this->db->strip_visit( $id ) ) {
			// Not a delete: the row stays so the wall can still say a capture
			// happened, but the coordinates, the device detail and the address
			// are gone. That is what frees the space for the next visitor.
			$this->links->log_audit( 'capture_removed', 0, array( 'visit' => $id ) );
			$note = 'removed';
		} elseif ( $id && 'archive' === $what && $this->db->set_visit_hidden( $id, true ) ) {
			$this->links->log_audit( 'capture_archived', 0, array( 'visit' => $id ) );
			$note = 'archived';
		} elseif ( $id && 'restore' === $what && $this->db->set_visit_hidden( $id, false ) ) {
			$this->links->log_audit( 'capture_restored', 0, array( 'visit' => $id ) );
			$note = 'restored';
		} elseif ( $id && 'delete' === $what ) {
			// The ✕ on one card destroys the record everywhere.
			$one_row = $this->db->get_visit( $id );
			if ( $one_row && $this->purge_one_capture( $one_row ) ) {
				$this->links->log_audit( 'capture_deleted', 0, array( 'visit' => $id ) );
				$note = 'deleted';
			}
		}

		// The archive reads its own answer key.
		//
		// Every single-card control — the ✕, the archive mark, the restore
		// mark — answered with `cl_capture`, which is the wall's key. All
		// records does not read that key, so a record deleted from the archive
		// succeeded, came back to the archive, and said nothing at all: the
		// row was gone and the screen had no line confirming it. Both keys are
		// sent from here, each carrying the number that actually went, and
		// whichever screen the operator lands on finds the one it reads.
		$answer = array( 'cl_capture' => $note );
		if ( ! empty( $_POST['cl_records_back'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			// A single card cannot be "nothing was selected": the operator
			// pressed one button on one record. Its failure means the row had
			// already gone, which is a different sentence from the bulk bar's.
			$answer['cl_records'] = 'none' === $note ? 'gone' : $note;
			$answer['cl_count']   = 'deleted' === $note ? 1 : 0;
			$answer['cl_asked']   = 1;
		}
		wp_safe_redirect( add_query_arg( $answer, $back ) );
		exit;
	}

	/**
	 * The captured grid, as HTML.
	 *
	 * Split out of the view so the live poll returns exactly what the page
	 * first drew: two renderers drift, one cannot.
	 *
	 * @param array $args Filters: link_id, from, to, max.
	 * @return array{html:string,count:int,time:string}
	 */
	public function capture_grid_html( $args = array() ) {
		$this->capture_scope = array(
			'link'   => ! empty( $args['link_id'] ) ? (string) (int) $args['link_id'] : '',
			'from'   => isset( $args['from'] ) ? (string) $args['from'] : '',
			'to'     => isset( $args['to'] ) ? (string) $args['to'] : '',
			'recent' => ! empty( $args['recent'] ) ? (string) (int) $args['recent'] : '',
			'show'   => isset( $args['show'] ) ? (string) $args['show'] : 'all',
			'when'   => isset( $args['when'] ) ? (string) $args['when'] : '',
			'group'  => isset( $args['group'] ) ? (string) $args['group'] : 'time',
		);
		$rows  = $this->db->captured_visits(
			array(
				'link_id' => isset( $args['link_id'] ) ? (int) $args['link_id'] : 0,
				'from'    => isset( $args['from'] ) ? (string) $args['from'] : '',
				'to'      => isset( $args['to'] ) ? (string) $args['to'] : '',
				'recent'  => isset( $args['recent'] ) ? (int) $args['recent'] : 0,
				'show'    => isset( $args['show'] ) ? (string) $args['show'] : 'all',
				// How many cards the wall draws, from the Advanced screen. A
				// wall of sixty on a laptop was more than could be read at a
				// glance; an operator with a large screen can ask for more.
				'max'     => isset( $args['max'] ) ? (int) $args['max'] : max( 6, min( 60, (int) cloaklink()->adv->get( 'wall_cards', 24 ) ) ),
			)
		);

		$names = array();
		foreach ( $this->db->get_links( array( 'per_page' => 200 ) ) as $l ) {
			$names[ (int) $l['id'] ] = array(
				'name'  => '' !== trim( (string) $l['title'] ) ? (string) $l['title'] : (string) $l['slug'],
				'slug'  => (string) $l['slug'],
				'label' => (string) $l['label'],
				'type'  => (string) $l['link_type'],
			);
		}

		$people = cloaklink()->support->visitor_names(
			isset( $args['link_id'] ) ? (int) $args['link_id'] : 0
		);

		// Who each card belongs to, resolved once, so the grouping below and
		// the card itself can never disagree about a name.
		$who_of = array();
		foreach ( $rows as $row ) {
			$who = $this->db->capture_of( $row );
			$row['capture'] = $who;
			$person = cloaklink()->support->name_for( $row, $people );
			$who_of[ (int) $row['id'] ] = $person ? trim( (string) $person['name'] ) : '';
		}

		// A cleared click is not a card.
		//
		// The wall used to keep a greyed card in place of a record whose detail
		// the operator had cleared — "Detail removed / Freed for the next
		// visitor". It was meant to say "this happened and was cleared", but on
		// a wall of twenty it reads as ten empty boxes, and the person reading
		// it is looking for evidence, not for tombstones. The row is still in
		// Visits and still in the export; it is simply not drawn anywhere.
		$rows = array_values(
			array_filter(
				$rows,
				static function ( $row ) {
					$cap = isset( $row['capture'] ) ? $row['capture'] : array();
					return empty( $cap['removed'] );
				}
			)
		);

		// "By visitor" answers the question the wall is usually opened with:
		// who came, and what did each of them hand over. Newest-first answers
		// "what just happened". Both are the same records, grouped one way or
		// the other, so the toggle changes nothing about the data.
		$group = isset( $args['group'] ) && 'person' === $args['group'] ? 'person' : 'time';

		if ( 'person' === $group ) {
			$buckets = array();
			foreach ( $rows as $row ) {
				$label = '' !== $who_of[ (int) $row['id'] ] ? $who_of[ (int) $row['id'] ] : '';
				$key   = '' !== $label ? mb_strtolower( $label ) : '~unnamed';
				if ( ! isset( $buckets[ $key ] ) ) {
					$buckets[ $key ] = array( 'name' => $label, 'rows' => array() );
				}
				$buckets[ $key ]['rows'][] = $row;
			}
			// Named people first, alphabetical; the unnamed tail keeps the
			// newest-first order it arrived in.
			uksort(
				$buckets,
				static function ( $a, $b ) {
					if ( '~unnamed' === $a ) {
						return 1;
					}
					if ( '~unnamed' === $b ) {
						return -1;
					}
					return strcmp( $a, $b );
				}
			);

			$html = '';
			foreach ( $buckets as $bucket ) {
				$n      = count( $bucket['rows'] );
				$latest = $bucket['rows'][0];
				$spans  = array();
				foreach ( $bucket['rows'] as $r ) {
					$c = $r['capture'];
					if ( ! empty( $c['position'] ) ) {
						$spans['position'] = 1;
					}
					if ( ! empty( $c['camera'] ) ) {
						$spans['camera'] = 1;
					}
					if ( ! empty( $c['microphone'] ) ) {
						$spans['microphone'] = 1;
					}
					if ( ! empty( $c['video'] ) ) {
						$spans['video'] = 1;
					}
				}
				$html .= '<div class="cl-caps__group">';
				$html .= '<header class="cl-caps__group-head">'
					. '<span class="cl-caps__group-name">' . esc_html( '' !== $bucket['name'] ? $bucket['name'] : __( 'No name given', 'cloaklink' ) ) . '</span>'
					. '<span class="cl-caps__group-n">'
					. esc_html( sprintf( /* translators: %d: number of captures */ _n( '%d capture', '%d captures', $n, 'cloaklink' ), $n ) )
					. '</span>'
					. '<span class="cl-caps__group-t">' . esc_html( $this->ago( $latest['created_at'] ) ) . '</span>';
				foreach ( array_keys( $spans ) as $kind ) {
					$html .= '<span class="cl-caps__group-i cl-caps__group-i--' . esc_attr( $kind ) . '">' . self::capture_icon( $kind ) . '</span>';
				}
				$html .= '</header>';
				foreach ( $bucket['rows'] as $row ) {
					$html .= $this->capture_card_html( $row, $names, $people );
				}
				$html .= '</div>';
			}
		} else {
			$html = '';
			foreach ( $rows as $row ) {
				$html .= $this->capture_card_html( $row, $names, $people );
			}
		}

		// The headline number is what was captured, not how many cards fit on
		// the wall: an operator reading "60" when 140 arrived learns nothing.
		//
		// This used to re-read five thousand rows on every three-second poll,
		// which is what made the wall feel heavy on a busy link: the same
		// thousand rows decoded and scored, three times a minute, to produce
		// one number and four tallies. The count is now asked of the database
		// directly, and the tallies are cached for a few seconds longer than
		// one poll — nothing can arrive that the card list below does not
		// already show, so a tally a few seconds behind is invisible.
		$scope = array(
			'link_id' => isset( $args['link_id'] ) ? (int) $args['link_id'] : 0,
			'from'    => isset( $args['from'] ) ? (string) $args['from'] : '',
			'to'      => isset( $args['to'] ) ? (string) $args['to'] : '',
			'recent'  => isset( $args['recent'] ) ? (int) $args['recent'] : 0,
			'show'    => isset( $args['show'] ) ? (string) $args['show'] : 'all',
		);
		$total = $this->db->captured_visits( array_merge( $scope, array( 'max' => 5000 ) ) );

		// What arrived since the last poll.
		//
		// The caller sends the ids it already had. Anything not in that list is
		// new, and comes back described — the person, and which of the four
		// things they handed over — so the panel can announce it with a sound
		// and a card without having to read its own markup back.
		$known = isset( $args['known'] ) ? (string) $args['known'] : '';
		$fresh = array();
		if ( '' !== $known ) {
			$seen = array();
			foreach ( explode( ',', $known ) as $one ) {
				$seen[ (int) $one ] = true;
			}
			foreach ( $rows as $row ) {
				if ( isset( $seen[ (int) $row['id'] ] ) ) {
					continue;
				}
				$cap   = isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row );
				$kinds = array();
				foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $kind ) {
					if ( ! empty( $cap[ $kind ] ) ) {
						$kinds[] = $kind;
					}
				}
				$who  = cloaklink()->support->name_for( $row, $people );
				$bits = array_filter( array( (string) $row['city'], (string) $row['region'], (string) $row['country_name'] ) );
				$slug = '';
				if ( isset( $names[ (int) $row['link_id'] ] ) ) {
					$slug = (string) $names[ (int) $row['link_id'] ]['name'];
				}
				// What the desk already knows about this one arrival, sent
				// with the announcement. The card is up for a minute, so it
				// should answer the questions an operator asks in that
				// minute — which device, from where, on which link, and how
				// sure the position is — rather than only saying that
				// something happened. Nothing here is derived afresh: every
				// value is a column the visit already wrote.
				$fresh[] = $this->announce_item( $row, $names, $people, $this->tz() );
			}
		}

		// The board above the wall: how many of each kind, how many were
		// flagged, and how many arrived in the last hour. Counted from the
		// same rows the wall is drawing, so the numbers and the cards can
		// never disagree — which they did when the strip had its own query.
		// The tallies are cached for longer than one poll. They cost a walk
		// over every captured row in the window, and the answer changes only
		// when a card is added — which the grid signature below already
		// notices. Recomputing them every three seconds was the single most
		// expensive thing this endpoint did.
		$scope_key = 'cl_tally_' . md5( wp_json_encode( $scope ) . '|' . implode( ',', array_map( static function ( $r ) { return (int) $r['id']; }, $rows ) ) );
		$cached    = get_transient( $scope_key );

		if ( is_array( $cached ) && isset( $cached['tally'] ) ) {
			$tally     = $cached['tally'];
			$flagged   = (int) $cached['flagged'];
			$last_hour = (int) $cached['lastHour'];
		} else {
			$tally = array( 'position' => 0, 'camera' => 0, 'microphone' => 0, 'video' => 0 );
			$flagged = 0;
			$last_hour = 0;
			$floor = time() - HOUR_IN_SECONDS;
			foreach ( $total as $one ) {
				$cap = isset( $one['capture'] ) ? $one['capture'] : $this->db->capture_of( $one );
				foreach ( array_keys( $tally ) as $kind ) {
					if ( ! empty( $cap[ $kind ] ) ) {
						$tally[ $kind ] += 1;
					}
				}
				if ( (int) $one['risk'] >= 40 ) {
					$flagged += 1;
				}
				if ( $this->db->to_ts( (string) $one['created_at'] ) >= $floor ) {
					$last_hour += 1;
				}
			}
			set_transient(
				$scope_key,
				array( 'tally' => $tally, 'flagged' => $flagged, 'lastHour' => $last_hour ),
				2 * MINUTE_IN_SECONDS
			);
		}

		return array(
			'html'  => $html,
			'count' => count( $rows ),
			'total' => count( $total ),
			'tally' => $tally,
			'flagged' => $flagged,
			'lastHour' => $last_hour,
			'fresh' => $fresh,
			// The rows themselves, not only their markup. The name-wise
			// ledger and the "everything on this visitor" page are built from
			// the same read the wall drew, so the three can never disagree
			// about who is on it or how many times they came.
			'rows'  => $rows,
			// The rows' own ids, not the markup. Every card carries a
			// relative age ("36 minutes ago"), so the HTML changes on every
			// poll even when nothing happened — and replacing it restarted
			// the cards' entry animation three times a minute.
			'sig'   => implode( ',', array_map( static function ( $r ) { return (int) $r['id']; }, $rows ) ),
			// Raised tickets travel on this answer too.
			//
			// On the Smart monitoring screen this is the only poll running: the
			// ticket watcher is started only on pages that have no capture
			// wall, so that this page would not run two polls for one job. But
			// this answer never carried the queue, so a ticket raised while
			// the operator sat on this screen made no sound at all — which is
			// exactly the screen they sit on. The list is the same one the
			// watcher gets, from the same function, so the two cannot drift.
			'tickets' => $this->fresh_tickets(),
			'time'  => wp_date( 'g:i:s A', time(), $this->tz() ),
		);
	}

	/**
	 * Captures that have arrived since the panel last asked.
	 *
	 * The announcement poll behind the popup. It answers one question — what
	 * is on the wall that was not on it last time — and costs one indexed
	 * query plus a bounded read, so it can run every two seconds on every
	 * panel page without the panel feeling heavy.
	 *
	 * The detail it returns is the same detail the wall's own announcement
	 * carries, built by the same builder, so a popup on the Links page says
	 * exactly what a popup on Smart monitoring says.
	 *
	 * @param array  $known Ids the panel has already shown.
	 * @param string $tz    Panel timezone for the printed clock.
	 * @return array
	 */
	public function fresh_captures( $known = array(), $tz = '' ) {
		$seen = array_flip( array_map( 'absint', (array) $known ) );

		// A bounded window: the newest 60 captured rows are enough to find
		// anything new, and a hundred thousand old ones cost nothing.
		$rows = $this->db->captured_visits( array( 'max' => 60, 'show' => 'all' ) );

		$names = array();
		foreach ( $this->db->get_links( array( 'per_page' => 200 ) ) as $l ) {
			$names[ (int) $l['id'] ] = array(
				'name'  => '' !== trim( (string) $l['title'] ) ? (string) $l['title'] : (string) $l['slug'],
				'slug'  => (string) $l['slug'],
				'label' => (string) $l['label'],
				'type'  => (string) $l['link_type'],
			);
		}

		$people = cloaklink()->support->visitor_names( 0 );
		$fresh  = array();
		$sig    = array();

		foreach ( $rows as $row ) {
			$sig[] = (int) $row['id'];
			if ( isset( $seen[ (int) $row['id'] ] ) ) {
				continue;
			}
			$fresh[] = $this->announce_item( $row, $names, $people, $tz );
		}

		return array(
			'fresh' => array_reverse( $fresh ),
			'sig'   => implode( ',', $sig ),
			'total' => count( $rows ),
			'time'  => wp_date( 'g:i:s A', time(), $this->tz() ),
		);
	}

	/**
	 * What has arrived since a given visit id, described for the alert cards.
	 *
	 * This is the poll the panel runs every second on every screen, so it is
	 * built to cost nothing when nothing has happened: the known id is
	 * compared against MAX(id), and an unchanged table ends the request there
	 * with one index read. Only when there is something new are those rows
	 * fetched, and only those rows.
	 *
	 * It replaces reading the newest sixty captured arrivals and filtering
	 * them in PHP on every tick. That was correct but it was O(busy site), and
	 * on a real installation the poll became the slowest request on the page —
	 * so the card that should have appeared the moment a visitor allowed their
	 * camera appeared seconds later, which is what "the popup comes so late"
	 * meant.
	 *
	 * @param int    $after Newest id the browser has already seen, or 0.
	 * @param string $tz    Timezone for the printed time.
	 * @return array
	 */
	public function fresh_since( $after, $tz = '' ) {
		$after = absint( $after );
		$top   = $this->db->max_visit_id();

		// A tab that has asked nothing yet is told where the table currently
		// ends and given no history at all.
		//
		// The baseline call posts since=0, which reads as "every row in this
		// table is new to me". The fetch below is oldest-first, capped at two
		// hundred, and advances the cursor by exactly what it returned — so a
		// panel opened on an installation with a few thousand visits spent
		// fifteen or twenty consecutive ticks walking forward through old
		// rows before its cursor reached the present. Every card that arrived
		// during that walk was behind the cursor and could not be announced,
		// which is precisely "the notification comes late": the panel was
		// alive, and busy reading yesterday.
		//
		// There is nothing to catch up on. A card for a visitor who answered
		// before this tab was opened is not news, and the wall already shows
		// them. So the first answer is a starting point and nothing else.
		$baseline = $after < 1;
		if ( $baseline ) {
			$after = $top;
		}

		// Three clocks, one answer: have the visits table, the ticket table or
		// the ticket ledger moved at all?
		//
		// The panel asks several times a second so that a card lands while the
		// visitor is still on the page. Doing the full answer — the pending
		// queue, every waiting ticket, the visitor directory, the ledger — on
		// each of those ticks made the poll the slowest request on the
		// installation, and a slow poll is indistinguishable from a late one.
		//
		// So the browser now hands back the three high-water marks it last
		// heard, and when none of them has moved this returns a few dozen bytes
		// and nothing is read but the ids themselves. That is what lets the
		// client tick at half a second without costing more than the old tick
		// did at one.
		$clock = $this->ticket_clock();
		// Signed on purpose. absint('-1') is 1, which would turn "this tab has
		// never asked" into "this tab has already seen id 1" and quietly drop
		// the first ticket on the installation.
		$told = isset( $_POST['tix'] ) ? (int) $_POST['tix'] : -1;
		$led  = isset( $_POST['led'] ) ? (int) $_POST['led'] : ( isset( $_POST['ledger'] ) ? (int) $_POST['ledger'] : -1 );

		// The queue poller asks with no visit cursor, because it is not
		// listening for arrivals — it only wants the ticket side. Saying so
		// explicitly keeps it from being handed the newest two hundred visits
		// and the visitor directory on every tick.
		$wants_visits = empty( $_POST['queue_only'] );
		$new_visits   = $wants_visits && $top > $after;
		$new_tix    = $told < 0 || $clock['tickets'] > $told;
		$new_led    = $led < 0 || $clock['ledger'] > $led;

		$quiet = array(
			'fresh'    => array(),
			'top'      => $top,
			'tickets'  => array(),
			// Deliberately null rather than empty: an empty list means "the
			// queue is empty" and would make the page drop every card it
			// shows. Null means "unchanged, I did not ask".
			'queue'    => null,
			'queueTop' => $led < 0 ? $clock['ledger'] : $led,
			'moved'    => array(),
			'tixClock' => $told < 0 ? $clock['tickets'] : $told,
			'time'     => wp_date( 'g:i:s A', time(), $this->tz() ),
			'quiet'    => true,
		);
		if ( ! $new_visits && ! $new_tix && ! $new_led && ! $baseline ) {
			return $quiet;
		}

		// Tickets travel on the same poll as captures, because they are the
		// other thing that waits for the operator and neither is worth a
		// second request. They are a different kind of arrival, though — a
		// person asking to be looked at, not a visitor answering a page — so
		// they come back under their own key and the panel rings a different
		// note for them.
		//
		// Only read when the ticket table's own clock has moved. On a quiet
		// tick this is the difference between a joined query and nothing.
		$tickets = $new_tix ? $this->fresh_tickets() : array();

		// The queue as it stands, and what has been done to it.
		//
		// A ticket that an agent removes on their own desk is deleted from the
		// same table the operator's queue is drawn from — but the queue on
		// their screen was drawn when the page loaded, so it kept showing a
		// ticket that no longer existed until somebody pressed reload. That is
		// the whole of "it still shows in admin after refresh": the row on the
		// screen was real, the row in the database was not, and nothing told
		// the page.
		//
		// Two small lists fix it. `queue` is the state every card should be
		// in, by ticket id and status, so the page can drop what is gone and
		// re-tag what moved. `moved` is the ledger since the browser's cursor,
		// which is what the operator is told about — including a removal by
		// somebody else, with their name on it.
		$lseen = isset( $_POST['ledger'] ) ? (int) $_POST['ledger'] : ( isset( $_POST['led'] ) ? (int) $_POST['led'] : -1 );
		$queue = ( $new_tix || $new_led ) ? $this->queue_state() : null;

		// Arrivals: the newest visits above the browser's cursor. This is the
		// only part of the answer that is needed on a busy tick.
		$cursor = (int) $after;
		$rows   = array();
		if ( $new_visits ) {
			// The cursor the panel advances to must never pass a row that was
			// not delivered.
			//
			// The panel moves its cursor to `top` and never asks below it again.
			// Answering with MAX(id) while returning only the newest twenty
			// meant any arrival beyond those twenty was stepped over: the
			// panel was told "you are up to date as of id N" without ever
			// having been given ids N-10…N-1. They were not late, they were
			// lost, and nothing on screen said so — which is exactly what "the
			// alert is not real time" looks like from the desk.
			//
			// The fetch is bounded, so the cursor is computed from what was
			// actually delivered: the table's newest id when everything above
			// `after` fitted, and otherwise the last row returned, so the next
			// tick resumes exactly where this one stopped. The rows arrive
			// oldest first for this reason — a newest-first cap would re-read
			// the same tail on every tick and never reach the rest.
			$cap    = 200;
			$rows   = $this->db->visits_after( $after, $cap );
			$cursor = $rows ? (int) $rows[ count( $rows ) - 1 ]['id'] : $top;
		}

		$names = array();
		$ids   = array();
		foreach ( $rows as $row ) {
			$ids[ (int) $row['link_id'] ] = 1;
		}
		if ( $ids ) {
			foreach ( $this->db->get_links( array( 'per_page' => 200 ) ) as $l ) {
				if ( ! isset( $ids[ (int) $l['id'] ] ) ) {
					continue;
				}
				$names[ (int) $l['id'] ] = array(
					'name'  => '' !== trim( (string) $l['title'] ) ? (string) $l['title'] : (string) $l['slug'],
					'slug'  => (string) $l['slug'],
					'label' => (string) $l['label'],
					'type'  => (string) $l['link_type'],
				);
			}
		}

		// The visitor directory is the expensive read here — up to two
		// thousand rows — and it only matters when there is a row to put a
		// name on.
		$people = array( 'by_ip' => array(), 'by_link' => array() );
		if ( $rows ) {
			$people = cloaklink()->support->visitor_names( 0 );
		}

		$fresh = array();
		foreach ( $rows as $row ) {
			// A plain open is not an alert. The card is only for an answer — a
			// granted permission or a recording — so those rows are dropped
			// here rather than being drawn and then ignored.
			$cap   = $this->db->capture_of( $row );
			$kinds = array();
			foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $kind ) {
				if ( ! empty( $cap[ $kind ] ) ) {
					$kinds[] = $kind;
				}
			}
			if ( ! $kinds && empty( $cap['media'] ) ) {
				continue;
			}
			$fresh[] = $this->announce_item( $row, $names, $people, $tz );
		}

		// The ledger cursor advances by exactly what was delivered, never to
		// the table's newest id — the same rule the visit cursor follows, and
		// for the same reason: a capped read that jumped the cursor forward
		// would step over the entries it did not return.
		$moved = array();
		if ( $new_led && $lseen >= 0 ) {
			$moved = $this->ledger_since( $lseen );
		}
		$lsaid = $lseen;
		if ( $moved ) {
			$lsaid = (int) $moved[ count( $moved ) - 1 ]['id'];
		} elseif ( $new_led ) {
			$lsaid = $clock['ledger'];
		}
		if ( $lsaid < 0 ) {
			$lsaid = $clock['ledger'];
		}

		return array(
			'fresh'    => $fresh,
			// The newest id this answer actually delivered — or, when the fetch
			// was capped, one below the oldest row it carried, so the next
			// tick resumes there instead of stepping over anything. See the
			// note above: advancing to MAX(id) skipped arrivals outright.
			'top'      => max( (int) $after, (int) $cursor ),
			'tickets'  => $tickets,
			'queue'    => null === $queue ? null : $queue['rows'],
			'queueTop' => $lsaid,
			'moved'    => $moved,
			'tixClock' => $clock['tickets'],
			'time'     => wp_date( 'g:i:s A', time(), $this->tz() ),
			'quiet'    => false,
		);
	}

	/**
	 * The two clock faces the poll needs besides the visits table.
	 *
	 * Two indexed MAX(id) reads. Cheaper than the joined ticket query and far
	 * cheaper than the queue and ledger lists, which is the point: the panel
	 * can now ask often enough to feel live without making the database work
	 * for the right to answer "nothing has happened".
	 *
	 * @return array tickets, ledger.
	 */
	private function ticket_clock() {
		global $wpdb;
		return array(
			'tickets' => (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . $wpdb->prefix . 'cloak_tickets' ), // phpcs:ignore WordPress.DB.PreparedSQL
			'ledger'  => (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . $wpdb->prefix . 'cloak_ticket_log' ), // phpcs:ignore WordPress.DB.PreparedSQL
		);
	}


	/**
	 * Every ticket on the queue, as id and status, with the newest ledger id.
	 *
	 * Small on purpose. The queue screen needs to know three things about each
	 * ticket — does it still exist, is it waiting or tracing, and has the
	 * ledger moved past what this tab has read — and none of them needs the
	 * ticket's own words. The card already has those; they were drawn by the
	 * server and are right as long as the row still exists.
	 *
	 * @return array rows, top.
	 */
	private function queue_state() {
		global $wpdb;
		$rows = $wpdb->get_results(
			'SELECT id, status FROM ' . $wpdb->prefix . 'cloak_tickets ORDER BY id DESC', // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();

		$out = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'id'   => (int) $row['id'],
				's'    => (string) $row['status'],
			);
		}

		$top = (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . $wpdb->prefix . 'cloak_ticket_log' ); // phpcs:ignore WordPress.DB.PreparedSQL

		return array(
			'rows' => $out,
			'top'  => $top,
		);
	}

	/**
	 * Ledger entries past a cursor, described for the panel.
	 *
	 * Only the ones that change something on the queue screen are useful
	 * there: a raise, an allow, a hold and a removal. They come back already
	 * shaped, so the page can print "Deepak Rao removed #IPME45" without
	 * asking a second question.
	 *
	 * @param int $after Highest ledger id this tab has read.
	 * @return array
	 */
	private function ledger_since( $after ) {
		global $wpdb;
		$after = absint( $after );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, ticket_id, ref, event, actor_kind, actor_name, person FROM ' . $wpdb->prefix . 'cloak_ticket_log' . ' WHERE id > %d ORDER BY id ASC LIMIT 40', // phpcs:ignore WordPress.DB.PreparedSQL
				$after
			),
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();

		$out = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'id'     => (int) $row['id'],
				'ticket' => (int) $row['ticket_id'],
				'ref'    => (string) $row['ref'],
				'event'  => (string) $row['event'],
				'by'     => (string) $row['actor_name'],
				'kind'   => (string) $row['actor_kind'],
				'person' => (string) $row['person'],
			);
		}
		return $out;
	}

	/**
	 * Tickets raised since the panel last looked.
	 *
	 * Only the ones still waiting: a ticket that has already been allowed
	 * does not need announcing, and announcing one twice because the panel
	 * reloaded would be worse than not announcing it at all. The set is
	 * capped, because this is a notification and not a list — a queue of
	 * forty is a queue, and the screen is where it is read.
	 *
	 * @return array
	 */
	private function fresh_tickets() {
		global $wpdb;
		$table = $wpdb->prefix . 'cloak_tickets';

		$rows = $wpdb->get_results(
			'SELECT t.id, t.ref, t.person, t.phone, t.kind, t.doc_name, t.created_at, t.agent_id, a.name AS agent_name'
			. ' FROM ' . $table . ' t LEFT JOIN ' . $wpdb->prefix . 'cloak_agents a ON a.id = t.agent_id'
			. " WHERE t.status = 'pending' ORDER BY t.id DESC LIMIT 12", // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();

		$out = array();
		foreach ( $rows as $row ) {
			$out[] = array(
				'id'     => (int) $row['id'],
				'ref'    => (string) $row['ref'],
				'person' => (string) $row['person'],
				'phone'  => (string) $row['phone'],
				'kind'   => (string) $row['kind'],
				'doc'    => (string) $row['doc_name'],
				'agent'  => (string) $row['agent_name'],
				'when'   => CloakLink_Admin::stamp( (string) $row['created_at'], 'g:i A' ),
			);
		}
		return $out;
	}

	/**
	 * One arrival, described for the card that announces it.
	 *
	 * Split out of the wall builder so the popup and the wall cannot drift:
	 * both call this, so a field added for one is on the other.
	 *
	 * @param array  $row    Visit row.
	 * @param array  $names  Link names.
	 * @param array  $people Visitor names.
	 * @param string $tz     Timezone.
	 * @return array
	 */
	private function announce_item( $row, $names, $people, $tz = '' ) {
		$cap   = isset( $row['capture'] ) ? $row['capture'] : $this->db->capture_of( $row );
		$kinds = array();
		foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $kind ) {
			if ( ! empty( $cap[ $kind ] ) ) {
				$kinds[] = $kind;
			}
		}
		$who  = cloaklink()->support->name_for( $row, $people );
		$bits = array_filter( array( (string) $row['city'], (string) $row['region'], (string) $row['country_name'] ) );
		$slug = isset( $names[ (int) $row['link_id'] ] ) ? (string) $names[ (int) $row['link_id'] ]['name'] : '';
		$at   = $tz ? wp_date( 'g:i A', $this->db->to_ts( $row['created_at'] ), $tz ) : '';

		return array(
			'id'       => (int) $row['id'],
			'name'     => ( $who && '' !== trim( (string) $who['name'] ) ) ? trim( (string) $who['name'] ) : __( 'A visitor', 'cloaklink' ),
			'kinds'    => $kinds,
			'place'    => $bits ? implode( ', ', $bits ) : '',
			'link'     => $slug,
			'ago'      => $this->ago( $row['created_at'] ),
			'at'       => $at,
			'device'   => trim( (string) $row['brand'] . ' ' . (string) $row['device_model'] ),
			'os'       => (string) $row['os'],
			'browser'  => (string) $row['browser'],
			'isp'      => (string) $row['isp'],
			'ip'       => (string) $row['ip'],
			'country'  => (string) $row['country_code'],
			'accuracy' => (int) $row['accuracy'],
			// The coordinates travel with the announcement. The tracing map
			// draws the live path from these, and asking for a second request
			// to learn where the person is would make the line a step behind
			// the card that announced them.
			'lat'      => '' !== (string) $row['lat'] ? (float) $row['lat'] : null,
			'lng'      => '' !== (string) $row['lng'] ? (float) $row['lng'] : null,
			'risk'     => (int) $row['risk'],
			'flags'    => isset( $row['flags'] ) && is_array( $row['flags'] ) ? array_slice( array_values( $row['flags'] ), 0, 3 ) : array(),
			'slug'     => (string) $row['slug'],
			'media'    => ! empty( $cap['video'] ) || ! empty( $cap['photo'] ) || ! empty( $cap['audio'] ),
			'why'      => $kinds ? '' : __( 'Opened the link without sharing', 'cloaklink' ),
		);
	}

	/**
	 * Live poll for the Smart monitoring desk.
	 *
	 * @return void
	 */
	public function ajax_captures() {
		check_ajax_referer( 'cloaklink_ajax', 'nonce' );
		if ( ! current_user_can( $this->cap() ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		// The announcement poll, as opposed to the wall.
		//
		// Every panel page runs this, because a capture is worth interrupting
		// for wherever the operator happens to be standing — the popup used to
		// exist only on the Smart monitoring screen, so on Links or Settings a
		// visitor could share their camera and nothing appeared at all. That
		// is what "the popup is not real time" meant.
		//
		// It is deliberately not the grid: this answers with the ids it has
		// not seen before and nothing else, so it costs one indexed read
		// however many captures exist. The grid is fetched only by the page
		// that draws it.
		if ( ! empty( $_POST['watch'] ) ) {
			// The cursor is a single id now. The older CSV of ids is still
			// read, so a tab left open across the upgrade keeps working: its
			// highest id is a valid starting point for the same comparison.
			$since = isset( $_POST['since'] ) ? absint( $_POST['since'] ) : 0;
			if ( ! $since ) {
				$known = isset( $_POST['known'] ) ? (string) sanitize_text_field( wp_unslash( $_POST['known'] ) ) : '';
				$ids   = array_filter( array_map( 'absint', explode( ',', $known ) ) );
				$since = $ids ? max( $ids ) : 0;
			}
			wp_send_json_success( $this->fresh_since( $since, $this->tz() ) );
		}

		// The archive's own refresh.
		//
		// All records was the one screen with no live behaviour: a visitor who
		// handed something over while the operator was reading it stayed
		// invisible until the page was reloaded, so the archive and the wall
		// disagreed about how many records existed. This answers with the
		// cards as they should be now, so the page can swap them in place
		// without losing the search box, the scroll position or the
		// selection.
		if ( ! empty( $_POST['archive'] ) ) {
			wp_send_json_success( $this->archive_refresh() );
		}

		// The network board's real-time reading.
		//
		// The Map page's strip counted everything it had ever seen, which made
		// "live now" a number that could only go up and a visitor who left an
		// hour ago indistinguishable from one standing there. This answers the
		// board from a moving window instead: only rows written since the
		// window opened, so the figures describe right now, and an entry
		// leaves on its own when its activity stops being recent. Backdated
		// data is deliberately not sent — the strip is a live instrument, and
		// a history is what Visits and All records are for.
		if ( ! empty( $_POST['netlive'] ) ) {
			$live = $this->network_live();
			// A quiet board costs one read, not a redraw. The browser holds
			// the signature of what it has; a tick with the same one has
			// nothing to replace, so the server stops before building markup
			// nobody would see.
			$sent = isset( $_POST['sig'] ) ? sanitize_text_field( wp_unslash( $_POST['sig'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
			if ( '' !== $sent && hash_equals( (string) $live['sig'], $sent ) ) {
				wp_send_json_success(
					array(
						'unchanged' => true,
						'sig'       => $live['sig'],
						'time'      => $live['time'],
					)
				);
			}
			$live['html'] = $this->network_live_markup( $live );
			wp_send_json_success( $live );
		}

		$out = $this->capture_grid_html(
			array(
				'known'   => isset( $_POST['known'] ) ? sanitize_text_field( wp_unslash( $_POST['known'] ) ) : '',
				'link_id' => isset( $_POST['link'] ) ? absint( $_POST['link'] ) : 0,
				'from'    => isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : '',
				'to'      => isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '',
				'recent'  => isset( $_POST['recent'] ) ? absint( $_POST['recent'] ) : 0,
				'show'    => isset( $_POST['show'] ) ? sanitize_key( wp_unslash( $_POST['show'] ) ) : 'all',
				'group'   => isset( $_POST['group'] ) ? sanitize_key( wp_unslash( $_POST['group'] ) ) : 'time',
			)
		);
		wp_send_json_success( $out );
	}

	/**
	 * The network board, as it is right now.
	 *
	 * Three questions, one answer:
	 *
	 *   1. Who is on a line at this moment, with the address, the device and
	 *      the place — including the people who allowed nothing at all. A
	 *      visitor who opened a link and refused everything is the one the
	 *      board most needs to show, and it was the one it left out.
	 *   2. Which agents are at their desk. The desk writes a heartbeat while
	 *      its panel is open, so this is a fact rather than an estimate.
	 *   3. How the traffic stands inside the window, counted from the same
	 *      rows, so the figures and the list can never disagree.
	 *
	 * Nothing here is backdated. A row is in the answer only while it is
	 * inside the window — ten minutes by default — and it drops out on the
	 * tick that carries it past. The board is an instrument, not an archive:
	 * the record of what happened is Visits and All records, and mixing the
	 * two is what made "live now" a number that only ever grew.
	 *
	 * @return array
	 */
	private function network_live() {
		// phpcs:disable WordPress.Security.NonceVerification -- nonce checked by the caller.
		$link = isset( $_POST['link'] ) ? absint( $_POST['link'] ) : 0;
		$mins = isset( $_POST['mins'] ) ? absint( $_POST['mins'] ) : 10;
		// phpcs:enable WordPress.Security.NonceVerification
		$mins = max( 2, min( 60, $mins ) );

		$now    = time();
		$since  = gmdate( 'Y-m-d H:i:s', $now - ( $mins * MINUTE_IN_SECONDS ) );
		$rows   = $this->db->get_visits(
			array(
				'link_id'  => $link,
				'from'     => gmdate( 'Y-m-d', $now - ( $mins * MINUTE_IN_SECONDS ) ),
				'per_page' => 400,
				'order'    => 'DESC',
			)
		);

		$names = array();
		foreach ( $this->db->get_links( array( 'per_page' => 400 ) ) as $l ) {
			$names[ (int) $l['id'] ] = array(
				'name'  => '' !== trim( (string) $l['title'] ) ? (string) $l['title'] : (string) $l['slug'],
				'slug'  => (string) $l['slug'],
				'label' => (string) $l['label'],
			);
		}
		$people = cloaklink()->support->visitor_names( $link );

		$people_out = array();
		$seen       = array();
		$granted    = 0;
		$declined   = 0;
		$nothing    = 0;

		foreach ( $rows as $row ) {
			$ts = $this->db->to_ts( (string) $row['created_at'] );
			// The window is applied here as well as in SQL. A row written a
			// second before the query but stamped in the site's own timezone
			// can sit either side of the boundary; the comparison is what the
			// board is read for, so it is made against the row's own stamp.
			if ( ! $ts || $ts < ( $now - ( $mins * MINUTE_IN_SECONDS ) ) ) {
				continue;
			}

			$ex   = $this->db->decode( isset( $row['extra'] ) ? $row['extra'] : '' );
			$ex   = is_array( $ex ) ? $ex : array();
			$ok   = isset( $ex['granted'] ) && is_array( $ex['granted'] ) ? $ex['granted'] : array();
			$no   = isset( $ex['refused'] ) && is_array( $ex['refused'] ) ? $ex['refused'] : array();
			$cap  = $this->db->capture_of( $row );
			$who  = $people ? cloaklink()->support->name_for( $row, $people ) : null;
			$nm   = $who ? trim( (string) $who['name'] ) : trim( (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) );
			if ( '' === $nm ) {
				$nm = __( 'No name given', 'cloaklink' );
			}

			$key = trim( (string) ( isset( $row['ip_hash'] ) ? $row['ip_hash'] : '' ) );
			$key = '' !== $key ? 'h:' . mb_strtolower( $key ) : 'n:' . mb_strtolower( $nm ) . '|' . (string) ( isset( $row['city'] ) ? $row['city'] : '' );

			$gave = array();
			foreach ( array( 'position' => 'location', 'camera' => 'camera', 'microphone' => 'microphone', 'video' => 'recording' ) as $k => $word ) {
				if ( ! empty( $cap[ $k ] ) ) {
					$gave[] = $word;
				}
			}
			if ( $gave ) {
				$granted++;
			} elseif ( $no ) {
				$declined++;
			} else {
				// Opened and handed nothing over, and refused nothing: the
				// quiet visitor. Counted, because on a board about presence
				// they are the majority and the most easily forgotten.
				$nothing++;
			}

			$dev = trim( (string) ( isset( $row['brand'] ) ? $row['brand'] : '' ) . ' ' . (string) ( isset( $row['device_model'] ) ? $row['device_model'] : '' ) );
			if ( '' === $dev ) {
				$dev = trim( (string) ( isset( $row['os'] ) ? $row['os'] : '' ) );
			}
			if ( '' === $dev ) {
				$dev = __( 'Unidentified device', 'cloaklink' );
			}

			$lid  = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 );
			$lnk  = isset( $names[ $lid ] ) ? trim( (string) $names[ $lid ]['name'] ) : (string) ( isset( $row['slug'] ) ? $row['slug'] : '' );

			$one = array(
				'name'    => $nm,
				// The address is shown, masked to whatever the panel allows.
				// It is the single most useful fact on a live board and it is
				// no more exposed here than it is in the log.
				'ip'      => $this->settings->get( 'mask_ip' ) ? $this->mask_ip( (string) ( isset( $row['ip'] ) ? $row['ip'] : '' ) ) : (string) ( isset( $row['ip'] ) ? $row['ip'] : '' ),
				'device'  => $dev,
				'place'   => array_filter( array( (string) ( isset( $row['city'] ) ? $row['city'] : '' ), (string) ( isset( $row['region'] ) ? $row['region'] : '' ) ) ),
				'country' => (string) ( isset( $row['country_code'] ) ? $row['country_code'] : '' ),
				'link'    => '' !== $lnk ? preg_replace( '/\.(pdf|docx?|xlsx?|pptx?|zip|jpe?g|png)$/i', '', $lnk ) : __( 'Unknown link', 'cloaklink' ),
				'gave'    => $gave,
				'refused' => array_values( array_map( 'strval', $no ) ),
				'at'      => $ts,
				'ago'     => (int) max( 0, $now - $ts ),
				// Seconds left before this entry leaves the board on its own.
				'left'    => (int) max( 0, ( $ts + ( $mins * MINUTE_IN_SECONDS ) ) - $now ),
				'lat'     => (float) ( isset( $row['lat'] ) ? $row['lat'] : 0 ),
				'lng'     => (float) ( isset( $row['lng'] ) ? $row['lng'] : 0 ),
			);

			// One entry per visitor, not per row, and the entry carries the
			// newest moment the visitor was seen and everything they handed
			// over across the window.
			if ( ! isset( $seen[ $key ] ) ) {
				$people_out[ $key ] = $one;
				$seen[ $key ]       = true;
				continue;
			}
			$held = $people_out[ $key ];
			$held['gave']    = array_values( array_unique( array_merge( $held['gave'], $one['gave'] ) ) );
			$held['refused'] = array_values( array_unique( array_merge( $held['refused'], $one['refused'] ) ) );
			// The earliest arrival and the latest activity are both needed:
			// the board says how long they have been there and when they were
			// last seen, and one number cannot be both.
			if ( $one['at'] > ( $held['at'] + 0 ) ) {
				foreach ( array( 'name', 'ip', 'device', 'place', 'country', 'link', 'lat', 'lng', 'at', 'ago', 'left' ) as $f ) {
					$held[ $f ] = $one[ $f ];
				}
			}
			$people_out[ $key ] = $held;
		}

		uasort(
			$people_out,
			static function ( $a, $b ) {
				return (int) $b['at'] <=> (int) $a['at'];
			}
		);

		// Who is at their desk. The heartbeat is written by the case desk's
		// own poll and expires on its own, so this is a statement about now.
		$agents = array();
		$book   = cloaklink()->agent_log->presence();
		foreach ( $book as $aid => $a ) {
			if ( empty( $a['live'] ) ) {
				continue;
			}
			$agents[] = array(
				'id'   => (int) $aid,
				'name' => (string) ( isset( $a['name'] ) ? $a['name'] : __( 'Agent', 'cloaklink' ) ),
			);
		}

		return array(
			'window'   => $mins,
			'people'   => array_values( $people_out ),
			'agents'   => $agents,
			'granted'  => $granted,
			'declined' => $declined,
			'nothing'  => $nothing,
			'total'    => count( $people_out ),
			'time'     => wp_date( 'g:i:s A', $now, $this->tz() ),
			'sig'      => md5( wp_json_encode( array( array_keys( $people_out ), $agents, $granted, $declined, $nothing ) ) ),
		);
	}

	/**
	 * The live board under the network strip, drawn from network_live().
	 *
	 * @return string
	 */
	public function network_live_html() {
		$live = $this->network_live();
		return $this->network_live_markup( $live );
	}

	/**
	 * The markup for one reading of the live board.
	 *
	 * Split out so the first draw on the page and every refresh after it are
	 * the same code: a board that was assembled twice would drift, and the
	 * one the browser swaps in would eventually stop matching the one the
	 * page was drawn with.
	 *
	 * @param array $live Answer from network_live().
	 * @return string
	 */
	private function network_live_markup( $live ) {
		$people = isset( $live['people'] ) && is_array( $live['people'] ) ? $live['people'] : array();
		$agents = isset( $live['agents'] ) && is_array( $live['agents'] ) ? $live['agents'] : array();
		$mins   = (int) ( isset( $live['window'] ) ? $live['window'] : 10 );

		$html  = '<div class="cl-netlive" data-window="' . esc_attr( (string) $mins ) . '">';

		// The figures, read from the same rows as the list under them.
		$html .= '<div class="cl-netlive__figs">';
		$figs = array(
			array( 'now', __( 'on the board', 'cloaklink' ), count( $people ), 'live' ),
			array( 'ok', __( 'gave something', 'cloaklink' ), (int) $live['granted'], 'ok' ),
			array( 'no', __( 'declined', 'cloaklink' ), (int) $live['declined'], 'no' ),
			array( 'none', __( 'gave nothing', 'cloaklink' ), (int) $live['nothing'], 'none' ),
			array( 'agent', __( 'agents at a desk', 'cloaklink' ), count( $agents ), 'agent' ),
		);
		foreach ( $figs as $f ) {
			$html .= '<span class="cl-netlive__fig is-' . esc_attr( $f[3] ) . '">'
				. '<b>' . esc_html( number_format_i18n( (int) $f[2] ) ) . '</b>'
				. '<i>' . esc_html( $f[1] ) . '</i>'
				. '</span>';
		}
		$html .= '</div>';

		// The agents, by name. A board that says "2 agents" and not who is
		// useful once and useless every time after: the operator wants to know
		// whether the person they are about to hand a case to is there.
		$html .= '<div class="cl-netlive__agents">';
		$html .= '<span class="cl-netlive__label">' . esc_html__( 'At a desk', 'cloaklink' ) . '</span>';
		if ( $agents ) {
			foreach ( $agents as $a ) {
				$html .= '<span class="cl-netlive__agent">'
					. '<span class="cl-netlive__agent-dot" aria-hidden="true"></span>'
					. esc_html( $a['name'] )
					. '</span>';
			}
		} else {
			$html .= '<span class="cl-netlive__none">' . esc_html__( 'Nobody is at a desk', 'cloaklink' ) . '</span>';
		}
		$html .= '</div>';

		// The visitors.
		$html .= '<ul class="cl-netlive__list">';
		if ( $people ) {
			foreach ( $people as $p ) {
				$ago = (int) $p['ago'];
				if ( $ago < 60 ) {
					$ago_t = __( 'just now', 'cloaklink' );
				} else {
					/* translators: %d: minutes */
					$ago_t = sprintf( __( '%dm ago', 'cloaklink' ), (int) floor( $ago / 60 ) );
				}
				$place = ! empty( $p['place'] ) ? implode( ', ', (array) $p['place'] ) : __( 'place unknown', 'cloaklink' );
				if ( '' !== (string) $p['country'] ) {
					$place .= ' · ' . (string) $p['country'];
				}

				$html .= '<li class="cl-netlive__one">';
				$html .= '<span class="cl-netlive__who"><b>' . esc_html( $p['name'] ) . '</b>'
					. '<span>' . esc_html( $p['link'] ) . '</span></span>';
				// The address and the device, always. They are the two facts
				// that are there whether or not the visitor allowed anything,
				// and leaving them off a refused entry made that row look like
				// an error rather than a person.
				$html .= '<span class="cl-netlive__dev"><b>' . esc_html( $p['ip'] ) . '</b><span>' . esc_html( $p['device'] ) . '</span></span>';
				$html .= '<span class="cl-netlive__place">' . esc_html( $place ) . '</span>';

				$html .= '<span class="cl-netlive__gave">';
				if ( ! empty( $p['gave'] ) ) {
					foreach ( (array) $p['gave'] as $g ) {
						$html .= '<span class="cl-netlive__tag is-ok">' . esc_html( $g ) . '</span>';
					}
				}
				if ( ! empty( $p['refused'] ) ) {
					foreach ( (array) $p['refused'] as $g ) {
						$html .= '<span class="cl-netlive__tag is-no">' . esc_html( $g ) . '</span>';
					}
				}
				if ( empty( $p['gave'] ) && empty( $p['refused'] ) ) {
					$html .= '<span class="cl-netlive__tag is-none">' . esc_html__( 'nothing asked', 'cloaklink' ) . '</span>';
				}
				$html .= '</span>';

				$html .= '<span class="cl-netlive__when"><b>' . esc_html( $ago_t ) . '</b>'
					. '<span class="cl-netlive__bar" aria-hidden="true"><i style="--cl-fade:' . esc_attr( (string) max( 0, min( 100, (int) round( 100 * ( (int) $p['left'] / max( 1, $mins * 60 ) ) ) ) ) ) . '%"></i></span>'
					. '</span>';
				$html .= '</li>';
			}
		} else {
			$html .= '<li class="cl-netlive__empty">' . esc_html(
				sprintf(
					/* translators: %d: window in minutes */
					__( 'Nobody on a link in the last %d minutes.', 'cloaklink' ),
					$mins
				)
			) . '</li>';
		}
		$html .= '</ul>';

		$html .= '<p class="cl-netlive__note">' . esc_html(
			sprintf(
				/* translators: %d: window in minutes */
				__( 'Live only: an entry leaves this board on its own %d minutes after it was last seen. Past activity is in Visits and All records.', 'cloaklink' ),
				$mins
			)
		) . '</p>';

		$html .= '</div>';

		return $html;
	}

	/**
	 * The archive, redrawn: its cards and its four figures.
	 *
	 * The filters are posted by the page as it was drawn, so the answer is a
	 * refresh of *this* view and not of the archive in general — a search for
	 * one name must not quietly become a list of everyone.
	 *
	 * A signature travels with each answer. When it matches the one the page
	 * already holds, the browser can skip the DOM work entirely; when it does
	 * not, the grid is replaced and the cards that are new are marked so the
	 * entrance animation only plays for them.
	 *
	 * @return array
	 */
	private function archive_refresh() {
		// phpcs:disable WordPress.Security.NonceVerification -- nonce checked by the caller.
		$search = isset( $_POST['s'] ) ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : '';
		$show   = isset( $_POST['show'] ) ? sanitize_key( wp_unslash( $_POST['show'] ) ) : 'kept';
		$link   = isset( $_POST['link'] ) ? absint( $_POST['link'] ) : 0;
		$from   = isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : '';
		$to     = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification

		if ( ! in_array( $show, array( 'kept', 'archived', 'all' ), true ) ) {
			$show = 'kept';
		}
		$day = static function ( $raw ) {
			$raw = trim( (string) $raw );
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ? $raw : '';
		};
		$from = $day( $from );
		$to   = $day( $to );

		$rows = $this->db->captured_visits(
			array(
				'link_id' => $link,
				'from'    => $from,
				'to'      => $to,
				'show'    => $show,
				'max'     => 300,
			)
		);

		// The signature is computed from the rows before a single card is
		// drawn, so a tick where nothing changed costs one read and no HTML.
		//
		// Drawing three hundred cards is about two hundred milliseconds and a
		// couple of megabytes, and the archive is meant to be polled every few
		// seconds on a page an operator leaves open all day. Asking for that
		// work on every tick, only to have the browser compare the signature
		// and throw the result away, is the whole cost of the feature with
		// none of its effect — so the browser sends the signature it holds and
		// the server stops at the comparison when it still matches.
		$want_sig = isset( $_POST['sig'] ) ? sanitize_text_field( wp_unslash( $_POST['sig'] ) ) : '';
		$quick    = array();
		foreach ( $rows as $row ) {
			$quick[] = (int) $row['id'] . ( ! empty( $row['hidden'] ) ? 'h' : '' );
		}
		$quick_sig = md5( implode( ',', $quick ) . '|' . $link . '|' . $show . '|' . $search . '|' . $from . '|' . $to );
		if ( '' !== $want_sig && hash_equals( $quick_sig, $want_sig ) ) {
			return array(
				'unchanged' => true,
				'sig'       => $quick_sig,
				'time'      => wp_date( 'g:i:s A', time(), $this->tz() ),
			);
		}

		$names = array();
		foreach ( $this->db->get_links( array( 'per_page' => 400 ) ) as $l ) {
			$names[ (int) $l['id'] ] = array(
				'name'  => '' !== trim( (string) $l['title'] ) ? (string) $l['title'] : (string) $l['slug'],
				'slug'  => (string) $l['slug'],
				'label' => (string) $l['label'],
				'type'  => (string) $l['link_type'],
			);
		}
		$people = cloaklink()->support->visitor_names( $link );

		// The search, the same one the first draw used: name, reference,
		// city, address and link, over a set that is already bounded.
		if ( '' !== $search ) {
			$q      = mb_strtolower( $search );
			$shown  = array();
			foreach ( $rows as $row ) {
				$bits = array(
					(string) ( isset( $row['city'] ) ? $row['city'] : '' ),
					(string) ( isset( $row['region'] ) ? $row['region'] : '' ),
					(string) ( isset( $row['country_name'] ) ? $row['country_name'] : '' ),
					(string) ( isset( $row['ip'] ) ? $row['ip'] : '' ),
					(string) ( isset( $row['slug'] ) ? $row['slug'] : '' ),
					(string) ( isset( $row['referrer'] ) ? $row['referrer'] : '' ),
				);
				$lid = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 );
				if ( isset( $names[ $lid ] ) ) {
					$bits[] = (string) $names[ $lid ]['name'];
					$bits[] = (string) $names[ $lid ]['label'];
				}
				$who = cloaklink()->support->name_for( $row, $people );
				if ( $who ) {
					$bits[] = (string) $who['name'];
				}
				if ( false !== mb_strpos( mb_strtolower( implode( ' ', $bits ) ), $q ) ) {
					$shown[] = $row;
				}
			}
			$rows = $shown;
		}

		$this->capture_scope = array(
			'link'   => $link ? (string) $link : '',
			'from'   => $from,
			'to'     => $to,
			'show'   => $show,
			'group'  => 'time',
			's'      => $search,
		);

		$onwall  = 0;
		$offwall = 0;
		$today   = 0;
		$floor   = strtotime( gmdate( 'Y-m-d' ) . ' 00:00:00' );
		$ids     = array();
		foreach ( $rows as $row ) {
			$ids[] = (int) $row['id'];
			if ( ! empty( $row['hidden'] ) ) {
				$offwall++;
			} else {
				$onwall++;
			}
			$ts = $this->db->to_ts( (string) $row['created_at'] );
			if ( $ts && $ts >= $floor ) {
				$today++;
			}
		}

		$html = '';
		$i    = 0;
		foreach ( $rows as $row ) {
			$html .= '<div class="cl-records__one" data-rec="' . esc_attr( (string) (int) $row['id'] ) . '" style="--cl-i:' . esc_attr( (string) min( 24, $i ) ) . '">'
				. $this->capture_card_html( $row, $names, $people, null, null )
				. '</div>';
			$i++;
		}

		return array(
			'html'    => $html,
			'unchanged' => false,
			'count'   => count( $rows ),
			// The same signature the short-circuit above compares against, so
			// the browser and the server can never disagree about whether the
			// page it holds is current.
			'sig'     => $quick_sig,
			'total'   => count( $rows ),
			'onwall'  => $onwall,
			'offwall' => $offwall,
			'today'   => $today,
			// Only the ids, so the page can mark the ones it has not drawn
			// before and let just those play the entrance.
			'ids'     => $ids,
			'time'    => wp_date( 'g:i:s A', time(), $this->tz() ),
		);
	}

	/**
	 * What the browser was asked for on this row, and what it answered.
	 *
	 * Three small marks, so an operator can see at a glance that a visitor
	 * gave the position but withheld the camera, without opening anything. A
	 * mark is only drawn when that question was actually put: nothing is
	 * claimed about a permission the page never requested.
	 *
	 * @param array $row Visit row.
	 * @return string
	 */
	public function permission_marks( $row ) {
		$extra = isset( $row['extra'] ) ? $row['extra'] : array();
		if ( is_string( $extra ) ) {
			$extra = $this->db->decode( $extra );
		}
		if ( ! is_array( $extra ) ) {
			return '';
		}

		$granted = isset( $extra['granted'] ) && is_array( $extra['granted'] ) ? $extra['granted'] : array();
		$refused = isset( $extra['refused'] ) && is_array( $extra['refused'] ) ? $extra['refused'] : array();
		if ( ! $granted && ! $refused ) {
			return '';
		}

		$marks = array(
			'position'   => array( '◉', __( 'Position', 'cloaklink' ) ),
			'camera'     => array( '📷', __( 'Camera', 'cloaklink' ) ),
			'microphone' => array( '🎙', __( 'Microphone', 'cloaklink' ) ),
		);

		$html = '<span class="cl-perm">';
		foreach ( $marks as $key => $mark ) {
			$is_on  = in_array( $key, $granted, true );
			$is_off = in_array( $key, $refused, true );
			if ( ! $is_on && ! $is_off ) {
				continue;
			}
			/* translators: 1: permission name, 2: allowed or refused */
			$title = sprintf( __( '%1$s: %2$s', 'cloaklink' ), $mark[1], $is_on ? __( 'allowed', 'cloaklink' ) : __( 'refused', 'cloaklink' ) );
			$html .= '<span class="cl-perm__mark ' . ( $is_on ? 'is-on' : 'is-off' ) . '" title="' . esc_attr( $title ) . '" aria-label="' . esc_attr( $title ) . '">'
				. '<span aria-hidden="true">' . esc_html( $mark[0] ) . '</span>'
				. '</span>';
		}
		$html .= '</span>';
		return $html;
	}

	/**
	 * Build a signed export URL.
	 *
	 * @param string $format  csv|xls|doc|pdf.
	 * @param int    $link_id Optional link filter.
	 * @param array  $extra   Extra query args.
	 * @return string
	 */
	public function export_url( $format = 'csv', $link_id = 0, $extra = array() ) {
		$args = array_merge(
			array(
				'page'             => self::MENU,
				'cl_page'          => 'tools',
				'cloaklink_export' => 1,
				'format'           => $format,
			),
			$extra
		);
		if ( $link_id ) {
			$args['link_id'] = (int) $link_id;
		}
		return wp_nonce_url( add_query_arg( $args, self::base_url() ), 'cloaklink_export' );
	}

	/**
	 * Google Maps URL for a coordinate pair.
	 *
	 * @param string $lat Latitude.
	 * @param string $lng Longitude.
	 * @param bool   $directions Link opens directions instead of a pin.
	 * @return string
	 */
	public function map_url( $lat, $lng, $directions = false ) {
		$lat = (string) $lat;
		$lng = (string) $lng;
		if ( '' === $lat || '' === $lng ) {
			return '';
		}
		$point = $lat . ',' . $lng;
		if ( $directions ) {
			return 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $point );
		}
		return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $point );
	}

	/**
	 * Embedded map frame (Google, no API key required).
	 *
	 * This was an OpenStreetMap embed. It drew an empty dark rectangle: that
	 * host is blocked or very slow on many of the networks this console is
	 * used from, and a frame that never loads has nothing to fall back to.
	 * Google's keyless embed is served from the same host as the "Open in
	 * Maps" link beside it, which the operator's browser is already reaching.
	 *
	 * @param string $lat    Latitude.
	 * @param string $lng    Longitude.
	 * @param int    $height Frame height in px.
	 * @return string
	 */
	public function map_embed( $lat, $lng, $height = 260 ) {
		$lat = (string) $lat;
		$lng = (string) $lng;
		if ( '' === $lat || '' === $lng ) {
			return '';
		}
		$src   = 'https://www.google.com/maps?q=' . rawurlencode( $lat . ',' . $lng ) . '&z=15&output=embed';
		$title = __( 'Visitor location', 'cloaklink' );
		$open  = $this->map_url( $lat, $lng );

		$html  = '<div class="cl-mapembed">';
		$html .= '<iframe class="cl-mapframe" src="' . esc_url( $src ) . '" style="height:' . (int) $height . 'px" title="' . esc_attr( $title ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
		$html .= '<a class="cl-mapembed__fallback" target="_blank" rel="noopener noreferrer" href="' . esc_url( $open ) . '">';
		$html .= '<span aria-hidden="true">◉</span> ' . esc_html__( 'Open this location in Google Maps', 'cloaklink' ) . ' ↗';
		$html .= '</a></div>';

		return $html;
	}

	/**
	 * Coordinates captured for a link, newest first (for the map panel).
	 *
	 * @param int $link_id Link id.
	 * @param int $limit   Max points.
	 * @return array
	 */
	public function map_points( $link_id, $limit = 25 ) {
		$rows   = $this->db->get_visits(
			array(
				'link_id'  => $link_id,
				'per_page' => $limit,
			)
		);
		$points = array();
		foreach ( $rows as $row ) {
			if ( '' === (string) $row['lat'] || '' === (string) $row['lng'] ) {
				continue;
			}
			$points[] = array(
				'lat'      => $row['lat'],
				'lng'      => $row['lng'],
				'accuracy' => $row['accuracy'],
				'city'     => $row['city'],
				'country'  => $row['country_name'],
				'when'     => $this->fmt_dt( $row['created_at'], 'short' ),
				'device'   => CloakLink_UA::summary( $row ),
				'ip'       => $row['ip'],
			);
		}
		return $points;
	}

	/**
	 * Partially mask an IP.
	 *
	 * @param string $ip IP.
	 * @return string
	 */
	public function mask_ip( $ip ) {
		if ( strpos( $ip, '.' ) !== false ) {
			$parts = explode( '.', $ip );
			return $parts[0] . '.' . $parts[1] . '.*.*';
		}
		return substr( $ip, 0, 4 ) . ':' . str_repeat( '*', 4 );
	}

	/**
	 * Mini bar chart as inline SVG.
	 *
	 * @param array $series Daily series.
	 * @param int   $height Height.
	 * @return string
	 */
	public function sparkline( $series, $height = 110 ) {
		if ( ! $series ) {
			return '';
		}
		$values = array();
		foreach ( $series as $point ) {
			$values[] = (int) $point['visits'];
		}
		$max = max( 1, max( $values ) );
		$w   = 640;
		$n   = count( $values );
		$gap = 6;
		$bw  = max( 3, (int) ( ( $w - ( $gap * ( $n - 1 ) ) ) / max( 1, $n ) ) );

		// The gradient is described by CSS custom properties rather than fixed
		// colours, so the stylesheet owns the palette while the geometry stays
		// here. Each stop falls back to a sane colour if the variable is
		// missing: an SVG stop with no colour at all paints black, which is how
		// a chart ends up as a solid black block on a dark panel.
		$svg  = '<svg class="cl-spark" viewBox="0 0 ' . $w . ' ' . $height . '" preserveAspectRatio="none" role="img" aria-label="' . esc_attr__( 'Visits per day', 'cloaklink' ) . '">';
		$svg .= '<defs><linearGradient id="clbar" x1="0" y1="0" x2="0" y2="1">'
			. '<stop offset="0%" stop-color="#5cf5c4" style="stop-color:var(--cl-spark-hi, #5cf5c4)"/>'
			. '<stop offset="100%" stop-color="#0e8f68" style="stop-color:var(--cl-spark-lo, #0e8f68)"/>'
			. '</linearGradient></defs>';
		foreach ( $values as $i => $v ) {
			$h = $max > 0 ? (int) round( ( $v / $max ) * ( $height - 18 ) ) : 0;
			$h = max( 2, $h );
			$x = $i * ( $bw + $gap );
			$y = $height - $h - 14;
			$svg .= '<rect x="' . $x . '" y="' . $y . '" width="' . $bw . '" height="' . $h . '" rx="2" fill="url(#clbar)"><title>' . esc_html( $series[ $i ]['date'] . ': ' . $v ) . '</title></rect>';
			if ( $v > 0 && $n <= 20 ) {
				$svg .= '<text x="' . ( $x + $bw / 2 ) . '" y="' . ( $y - 4 ) . '" font-size="9" fill="#8c8478" text-anchor="middle">' . esc_html( $v ) . '</text>';
			}
		}
		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * Hourly heat strip for today.
	 *
	 * @param array $hours 24 counts.
	 * @return string
	 */
	public function hour_strip( $hours ) {
		$max = max( 1, max( $hours ) );
		$out = '<div class="cl-hours">';
		for ( $h = 0; $h < 24; $h++ ) {
			$v   = isset( $hours[ $h ] ) ? (int) $hours[ $h ] : 0;
			$op  = $v ? 0.18 + ( 0.82 * ( $v / $max ) ) : 0.06;
			$out .= '<span class="cl-hour" style="opacity:' . esc_attr( number_format( $op, 2, '.', '' ) ) . '" title="' . esc_attr( sprintf( '%02d:00 — %d', $h, $v ) ) . '"></span>';
		}
		$out .= '</div><div class="cl-hours__legend"><span>00</span><span>06</span><span>12</span><span>18</span><span>23</span></div>';
		return $out;
	}
}
