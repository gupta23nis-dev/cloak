<?php
/**
 * The advanced layer.
 *
 * Every switch on the Advanced screen is read through this class, so the
 * screen and the code that obeys it can never disagree about a default. The
 * options live in their own row rather than in the main settings array: the
 * Settings form saves the whole array it is given, and a screen added later
 * would otherwise be wiped by anybody pressing Save on the older one.
 *
 * Each entry here is one switch that changes something a person can see or
 * hear. Nothing is a label without an effect behind it.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Advanced options for the operator's console and the case desk.
 */
class CloakLink_Adv {

	const OPTION      = 'cloaklink_adv';
	const PREFS       = 'cloaklink_agent_prefs';
	const PREFS_META  = 'cloaklink_agent_prefs';

	/** @var array|null Cached values, plus defaults. */
	private $cache = null;

	/*
	 * ---------------------------------------------------------------------
	 * The list
	 * ------------------------------------------------------------------ */

	/**
	 * Every operator option, grouped for the screen.
	 *
	 * `type` is one of: bool, int, text, enum, time. `min` / `max` bound the
	 * numbers, `choices` lists an enum's allowed values, and `default` is what
	 * the plugin does when nobody has touched the screen — which is always the
	 * behaviour of the version before this screen existed, so an upgrade
	 * changes nothing.
	 *
	 * @return array
	 */
	public static function groups() {
		return array(
			'links'      => array(
				'title' => __( 'Links and addresses', 'cloaklink' ),
				'note'  => __( 'How a new address is built, and what a copied link looks like.', 'cloaklink' ),
				'items' => array(
					'slug_suffix'      => array(
						'label'   => __( 'Random tail on a new address', 'cloaklink' ),
						'help'    => __( 'A short unguessable tail makes an address that cannot be walked to by guessing the next one. Off keeps the readable file-style address exactly as it is.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'off'    => __( 'Off — readable only', 'cloaklink' ),
							'short'  => __( 'Short — 4 characters', 'cloaklink' ),
							'medium' => __( 'Medium — 7 characters', 'cloaklink' ),
						),
						'default' => 'off',
					),
					'slug_upper'       => array(
						'label'   => __( 'Uppercase addresses', 'cloaklink' ),
						'help'    => __( 'Prints the whole address in capitals, the way a court file number is written on paper. Links already sent keep the shape they were made with.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'slug_year'        => array(
						'label'   => __( 'Add the year to a new address', 'cloaklink' ),
						'help'    => __( 'Appends the current year after the prefix, so one year’s files are never mistaken for another’s.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'new_expiry_hours' => array(
						'label'   => __( 'Default expiry for a new link', 'cloaklink' ),
						'help'    => __( 'Hours, filled in on the New link screen. Zero means no expiry, which is what the screen offered before this switch existed.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 8760,
						'default' => 0,
					),
					'new_max_clicks'   => array(
						'label'   => __( 'Default click cap for a new link', 'cloaklink' ),
						'help'    => __( 'Fills the cap on the New link screen. Zero means unlimited.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 100000,
						'default' => 0,
					),
					'copy_format'      => array(
						'label'   => __( 'What Copy link puts on the clipboard', 'cloaklink' ),
						'help'    => __( 'WhatsApp puts a sentence around the address, which is what most people paste into a chat. Markdown and HTML are for a website or a document.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'url'      => __( 'The bare address', 'cloaklink' ),
							'whatsapp' => __( 'A sentence for a chat', 'cloaklink' ),
							'markdown' => __( 'Markdown link', 'cloaklink' ),
							'html'     => __( 'HTML anchor', 'cloaklink' ),
						),
						'default' => 'url',
					),
					'ext_default'      => array(
						'label'   => __( 'Default ending on the New link screen', 'cloaklink' ),
						'help'    => __( 'Chosen for you unless the link picks another. Follows the same list the form offers.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => 'extensions',
						'default' => '',
					),
					'require_https'    => array(
						'label'   => __( 'Refuse an insecure destination', 'cloaklink' ),
						'help'    => __( 'A link that forwards to a plain http address shows the visitor a browser warning on the way. Refusing it here means the mistake is caught while the operator is still looking at the form.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'queue_prefix'     => array(
						'label'   => __( 'Prefix for links made from the queue', 'cloaklink' ),
						'help'    => __( 'Used instead of the court prefix when a ticket is allowed. Blank means the same prefix as everywhere else.', 'cloaklink' ),
						'type'    => 'text',
						'default' => '',
					),
					'domain_badge'     => array(
						'label'   => __( 'Show the domain on every link card', 'cloaklink' ),
						'help'    => __( 'Useful when more than one domain is in use and a card has to be pasted in the right place.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
				),
			),
			'monitor'    => array(
				'title' => __( 'Live monitoring', 'cloaklink' ),
				'note'  => __( 'What arrives on screen, how loud, and for how long.', 'cloaklink' ),
				'items' => array(
					'card_seconds'   => array(
						'label'   => __( 'Seconds a capture card stays', 'cloaklink' ),
						'help'    => __( 'Long enough to read, short enough not to cover the wall.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 4,
						'max'     => 120,
						'default' => 60,
					),
					'card_max'       => array(
						'label'   => __( 'Cards stacked at once', 'cloaklink' ),
						'help'    => __( 'Beyond this the oldest goes first, so a busy link never buries the screen.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 1,
						'max'     => 8,
						'default' => 3,
					),
					'ticket_card'    => array(
						'label'   => __( 'Announce a raised ticket', 'cloaklink' ),
						'help'    => __( 'A ticket is a person on the desk asking to be looked at, so it is announced by default. Off leaves it in the queue only.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'sound_capture'  => array(
						'label'   => __( 'Sound on a capture', 'cloaklink' ),
						'help'    => __( 'The alert tone is what makes an operator look up. Off is for an operator who reads the screen and does not want to be spoken to.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'sound_ticket'   => array(
						'label'   => __( 'Sound on a ticket', 'cloaklink' ),
						'help'    => __( 'A different tone from a capture, so the ear knows which one arrived without looking.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'desktop_notify' => array(
						'label'   => __( 'Desktop notification', 'cloaklink' ),
						'help'    => __( 'A system notification when the tab is in the background. The browser asks permission once.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'wall_density'   => array(
						'label'   => __( 'Wall density', 'cloaklink' ),
						'help'    => __( 'Compact fits more on a laptop screen; comfortable uses the full width of a card.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'comfortable' => __( 'Comfortable', 'cloaklink' ),
							'compact'     => __( 'Compact', 'cloaklink' ),
						),
						'default' => 'comfortable',
					),
					'wall_cards'     => array(
						'label'   => __( 'Capture cards on the wall', 'cloaklink' ),
						'help'    => __( 'How many of the newest captures the monitoring screen draws.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 6,
						'max'     => 60,
						'default' => 24,
					),
					'hide_quiet'     => array(
						'label'   => __( 'Stay quiet about a plain open', 'cloaklink' ),
						'help'    => __( 'A visitor who opened a link and answered nothing is on the wall but does not interrupt. Turning this off announces every open, which is noisy on a shared link.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'country_flag'   => array(
						'label'   => __( 'Show the country flag', 'cloaklink' ),
						'help'    => __( 'A flag beside the country name on every row, where the device can draw one.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
				),
			),
			'behaviour'  => array(
				'title' => __( 'Console behaviour', 'cloaklink' ),
				'note'  => __( 'How the panel itself behaves, for the person using it all day.', 'cloaklink' ),
				'items' => array(
					'default_page'  => array(
						'label'   => __( 'Open on', 'cloaklink' ),
						'help'    => __( 'The screen an operator lands on after signing in.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'overview' => __( 'Overview', 'cloaklink' ),
							'visits'   => __( 'Visitor log', 'cloaklink' ),
							'support'  => __( 'Smart monitoring', 'cloaklink' ),
							'agents'   => __( 'Case agents', 'cloaklink' ),
							'links'    => __( 'Links', 'cloaklink' ),
						),
						'default' => 'overview',
					),
					'clock_24'      => array(
						'label'   => __( '24-hour clock', 'cloaklink' ),
						'help'    => __( 'Every timestamp on the panel, printed the way a duty log prints them.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'relative_time' => array(
						'label'   => __( '“4m ago” beside a time', 'cloaklink' ),
						'help'    => __( 'Adds how long ago, next to the exact stamp, on the visitor rows.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'poll_seconds'  => array(
						'label'   => __( 'Live refresh interval', 'cloaklink' ),
						'help'    => __( 'Seconds between checks for new captures. Shorter is more immediate and more work for the server.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 1,
						'max'     => 15,
						'default' => 1,
					),
					'compact_nav'   => array(
						'label'   => __( 'Narrow navigation rail', 'cloaklink' ),
						'help'    => __( 'Icons only, widening on hover. Gives the table the width on a small laptop.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'sticky_bar'    => array(
						'label'   => __( 'Keep the top bar in view', 'cloaklink' ),
						'help'    => __( 'The counters and the way out stay on screen while a long table scrolls.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'confirm_delete' => array(
						'label'   => __( 'Ask before a destructive action', 'cloaklink' ),
						'help'    => __( 'A confirmation on remove, expire and clear. Worth leaving on where more than one person uses the console.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'shortcuts'     => array(
						'label'   => __( 'Keyboard shortcuts', 'cloaklink' ),
						'help'    => __( 'G then O for the overview, G then V for the visitor log, and so on. A question mark lists them.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'footer_hint'   => array(
						'label'   => __( 'Show the footer note', 'cloaklink' ),
						'help'    => __( 'The compliance line at the foot of the panel.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'live_dot'      => array(
						'label'   => __( 'Show the live indicator', 'cloaklink' ),
						'help'    => __( 'The pulsing mark in the top bar that says the poll is running.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
				),
			),
			'desk'       => array(
				'title' => __( 'Case desk', 'cloaklink' ),
				'note'  => __( 'Rules for the people who sign in on the agent door.', 'cloaklink' ),
				'items' => array(
					'agent_session_hours' => array(
						'label'   => __( 'How long an agent stays signed in', 'cloaklink' ),
						'help'    => __( 'Hours. A shorter session on a phone that gets left on a desk is the difference between a locked screen and an open one.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 1,
						'max'     => 336,
						'default' => 12,
					),
					'agent_code_all'      => array(
						'label'   => __( 'Every agent needs an access code', 'cloaklink' ),
						'help'    => __( 'An account without a code can sign in with its password alone. This refuses that, so a password found on a note is not enough.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					// The pause itself is set on the Case agents screen, where the
					// whole desk rule set lives; these two are the parts of the
					// ticket form that the operator decides for everybody.
					'ticket_note_min'     => array(
						'label'   => __( 'Shortest note on a ticket', 'cloaklink' ),
						'help'    => __( 'Characters. A note of “hi” is what makes an operator ring the agent to ask what it was about. Zero accepts anything.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 200,
						'default' => 0,
					),
					'ticket_kind'         => array(
						'label'   => __( 'What a new ticket is about', 'cloaklink' ),
						'help'    => __( 'Which of the three kinds is chosen when the raise form opens.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'website'   => __( 'A website', 'cloaklink' ),
							'legal'     => __( 'A document', 'cloaklink' ),
							'instagram' => __( 'A reel', 'cloaklink' ),
						),
						'default' => 'website',
					),
					'mask_phones'         => array(
						'label'   => __( 'Mask phone numbers', 'cloaklink' ),
						'help'    => __( 'Shows only the last four digits until the number is pressed. For a screen that can be seen by a visitor.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'agent_seen_ips'      => array(
						'label'   => __( 'Note the network an agent signs in from', 'cloaklink' ),
						'help'    => __( 'Adds the address and place to the desk activity log on every sign-in.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'agent_landing'       => array(
						'label'   => __( 'Desk opens on', 'cloaklink' ),
						'help'    => __( 'Which part of the desk a person lands on after signing in.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'queue'    => __( 'The queue', 'cloaklink' ),
							'monitor'  => __( 'Monitoring', 'cloaklink' ),
							'ticket'   => __( 'Raise a ticket', 'cloaklink' ),
						),
						'default' => 'queue',
					),
					'queue_order'         => array(
						'label'   => __( 'Queue order', 'cloaklink' ),
						'help'    => __( 'Newest first puts the live work at the top. Oldest first works a backlog from the beginning.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'newest' => __( 'Newest first', 'cloaklink' ),
							'oldest' => __( 'Oldest first', 'cloaklink' ),
						),
						'default' => 'newest',
					),
					'agent_quota_warn'    => array(
						'label'   => __( 'Warn an agent at this many tickets a day', 'cloaklink' ),
						'help'    => __( 'A quiet line on their own screen, not a block. Zero turns it off.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 999,
						'default' => 0,
					),
					'desk_idle_minutes'   => array(
						'label'   => __( 'Sign an agent out after this many idle minutes', 'cloaklink' ),
						'help'    => __( 'Zero keeps them signed in for the whole session. This is what stops a phone left on a table staying open all afternoon.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 720,
						'default' => 0,
					),
				),
			),
			// Desk activity is its own group because it is the one screen the
			// operator reads rather than acts on: every switch here changes how
			// the record is shown or how much of it is kept, and none of them
			// changes what gets written. The defaults leave the screen exactly
			// as it was before the group existed.
			'activity'   => array(
				'title' => __( 'Desk activity', 'cloaklink' ),
				'note'  => __( 'How the activity record is read, printed and exported.', 'cloaklink' ),
				'items' => array(
					'act_per_page'      => array(
						'label'   => __( 'Entries on one page', 'cloaklink' ),
						'help'    => __( 'How many rows the log shows before it pages. A longer page means less clicking and a heavier screen; sixty is what fits on a laptop without scrolling to find the page buttons.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 10,
						'max'     => 500,
						'default' => 60,
					),
					'act_order'         => array(
						'label'   => __( 'Reading order', 'cloaklink' ),
						'help'    => __( 'Newest first is what an operator wants while a shift is running. Oldest first reads a session from its beginning like a statement.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'newest' => __( 'Newest first', 'cloaklink' ),
							'oldest' => __( 'Oldest first', 'cloaklink' ),
						),
						'default' => 'newest',
					),
					'act_autorefresh'   => array(
						'label'   => __( 'Refresh the log every', 'cloaklink' ),
						'help'    => __( 'Seconds. The list reloads itself while the tab is open and nothing is being typed, so a second screen left on this page stays current. Zero leaves it still until it is reloaded by hand.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 300,
						'default' => 0,
					),
					'act_presence'      => array(
						'label'   => __( 'Show who is on the desk now', 'cloaklink' ),
						'help'    => __( 'The strip of people signed in and not yet signed out. Turning it off leaves the record itself untouched.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_kpis'          => array(
						'label'   => __( 'Show the count tiles', 'cloaklink' ),
						'help'    => __( 'One tile per kind of event, totalled over the window below. Off goes straight from the top of the page to the log.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_kpi_days'      => array(
						'label'   => __( 'Count the last how many days', 'cloaklink' ),
						'help'    => __( 'The window the tiles add up. Seven matches a working week; thirty matches a month’s report.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 1,
						'max'     => 365,
						'default' => 7,
					),
					'act_series_hours'  => array(
						'label'   => __( 'Hours in the shift chart', 'cloaklink' ),
						'help'    => __( 'How far back the hour-by-hour bars reach. A day shows one shift; a week shows the rhythm of the rota, and compresses each bar to a few pixels.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 6,
						'max'     => 168,
						'default' => 24,
					),
					'act_kpi_count'     => array(
						'label'   => __( 'How many tiles', 'cloaklink' ),
						'help'    => __( 'The busiest kinds of event are shown first, so a desk that raises far more tickets than it signs in still shows the ticket count.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 1,
						'max'     => 14,
						'default' => 6,
					),
					'act_show_detail'   => array(
						'label'   => __( 'Show the note under each event', 'cloaklink' ),
						'help'    => __( 'The line that says which ticket, which link or why a sign-in was refused. Off leaves a bare list of events, which is easier to skim but says less.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_show_ip'       => array(
						'label'   => __( 'Print the network address', 'cloaklink' ),
						'help'    => __( 'The address a row came from, under the place. This only prints what was recorded: whether an address is recorded at all is the desk switch on Case agents.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_ip_style'      => array(
						'label'   => __( 'How an address is printed', 'cloaklink' ),
						'help'    => __( 'Masked keeps the first half so two rows can still be compared, without the screen showing a full address over somebody’s shoulder. Hidden takes it off the list entirely; the export keeps whatever this screen shows.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'full'   => __( 'Full address', 'cloaklink' ),
							'masked' => __( 'Masked — first half only', 'cloaklink' ),
							'hidden' => __( 'Hidden', 'cloaklink' ),
						),
						'default' => 'full',
					),
					'act_show_device'   => array(
						'label'   => __( 'Show device and browser', 'cloaklink' ),
						'help'    => __( '“Phone · Safari” beside the person. It is the column that tells an operator a sign-in came from a device the person does not usually use.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_show_system'   => array(
						'label'   => __( 'Add the operating system', 'cloaklink' ),
						'help'    => __( 'Prints the system after the browser, e.g. “Phone · Safari · iOS”. Worth it on a desk where two people share one login.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'act_tone'          => array(
						'label'   => __( 'Colour the edge of a row', 'cloaklink' ),
						'help'    => __( 'Green for a success, red for a refusal, amber for a hold. Off leaves every row the same weight for a screen being read aloud or printed.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_day_heads'     => array(
						'label'   => __( 'Start each day with a heading', 'cloaklink' ),
						'help'    => __( 'A line with the date whenever the day changes, so a list that runs past midnight is not read as one long evening.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'act_seconds'       => array(
						'label'   => __( 'Show seconds in the time', 'cloaklink' ),
						'help'    => __( 'Minutes are enough for most reading. Seconds settle the order of two things that happened in the same minute — a sign-in and the ticket raised with it.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'act_person_link'   => array(
						'label'   => __( 'A name opens that person’s history', 'cloaklink' ),
						'help'    => __( 'The name is already coloured as something to press. Off prints it as plain text and leaves the Person filter as the only way to narrow the list.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_sticky_filters' => array(
						'label'   => __( 'Keep the filters at the top', 'cloaklink' ),
						'help'    => __( 'The Person, Event and date row stays in view down a long page, so narrowing the list never means scrolling back up to find the form.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'act_refused_watch' => array(
						'label'   => __( 'Warn at this many refusals a day', 'cloaklink' ),
						'help'    => __( 'A red line above the log when refused sign-ins and wrong access codes reach this count in the last twenty-four hours. For a desk that is being guessed at. Zero turns it off.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 100,
						'default' => 0,
					),
					'act_export_rows'   => array(
						'label'   => __( 'Most rows in one export', 'cloaklink' ),
						'help'    => __( 'A cap rather than a target: a filtered export of a quiet week is far shorter. Raising it past a few thousand makes a spreadsheet that is slow to open.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 100,
						'max'     => 50000,
						'default' => 5000,
					),
					'act_export_cols'   => array(
						'label'   => __( 'Columns in the export', 'cloaklink' ),
						'help'    => __( 'Core is the four facts a report needs: when, what, who, where. Everything adds the network address and the device, which is what an investigation reads.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'core' => __( 'Core — when, what, who, where', 'cloaklink' ),
							'full' => __( 'Everything', 'cloaklink' ),
						),
						'default' => 'full',
					),
					'act_export_bom'    => array(
						'label'   => __( 'Excel-friendly export', 'cloaklink' ),
						'help'    => __( 'Adds the three-byte mark that tells Excel the file is UTF-8. Without it a name with an accent opens as nonsense in Excel and reads correctly everywhere else.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
				),
			),
			'radio'      => array(
				'title' => __( 'Walkie-talkie', 'cloaklink' ),
				'note'  => __( 'How the live line sounds, behaves and carries voice. Every switch here changes the radio only.', 'cloaklink' ),
				'items' => array(
					'radio_live'          => array(
						'label'   => __( 'Live voice on a direct line', 'cloaklink' ),
						'help'    => __( 'Browser-to-browser speech, press to talk. Off keeps the line as written notes and voice messages only, which is the fallback for a network that blocks peer connections.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_who_card'      => array(
						'label'   => __( 'Announce who is talking', 'cloaklink' ),
						'help'    => __( 'While somebody holds their key, everybody else sees a card with their name and a live level. Off leaves the line working exactly as it does, silently.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_who_pos'       => array(
						'label'   => __( 'Where the speaker card appears', 'cloaklink' ),
						'help'    => __( 'The corner it stacks in. A desk with a dock at the bottom right usually wants the card away from it.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'top-right'  => __( 'Top right', 'cloaklink' ),
							'top-left'   => __( 'Top left', 'cloaklink' ),
							'bottom-left' => __( 'Bottom left', 'cloaklink' ),
						),
						'default' => 'top-right',
					),
					'radio_who_seconds'   => array(
						'label'   => __( 'How long the card lingers', 'cloaklink' ),
						'help'    => __( 'Seconds after the voice stops before the card goes. Short for a busy desk, longer when a name needs to be readable from across a room.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 30,
						'default' => 2,
					),
					'radio_cue'           => array(
						'label'   => __( 'Sound when a line opens', 'cloaklink' ),
						'help'    => __( 'A short click the moment a live line connects, the way a real set confirms it. Off is silence until somebody speaks.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_ptt_mode'      => array(
						'label'   => __( 'How the microphone is keyed', 'cloaklink' ),
						'help'    => __( 'Hold says nothing until the key is pressed. Latch stays on until pressed again, for a long report. Hands-free is for a desk where both people are working and talk across the room.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'hold'      => __( 'Hold to talk', 'cloaklink' ),
							'latch'     => __( 'Press to latch on', 'cloaklink' ),
							'handsfree' => __( 'Hands-free — always on', 'cloaklink' ),
						),
						'default' => 'hold',
					),
					'radio_echo'          => array(
						'label'   => __( 'Echo cancellation', 'cloaklink' ),
						'help'    => __( 'Stops the far end being picked up by the near microphone and sent back. Worth turning off only when the voices sound clipped on a very quiet headset.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_noise'         => array(
						'label'   => __( 'Noise suppression', 'cloaklink' ),
						'help'    => __( 'Filters a fan, a keyboard and traffic. A busy office wants it on; a quiet room with a soft voice may prefer the unprocessed signal.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_gain'          => array(
						'label'   => __( 'Automatic gain', 'cloaklink' ),
						'help'    => __( 'Lifts a quiet talker and softens a loud one. Off keeps the room exactly as recorded, which is easier to hear on a headset but unforgiving of a bad position.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_volume'        => array(
						'label'   => __( 'Volume of an incoming voice', 'cloaklink' ),
						'help'    => __( 'Percent. It is the ceiling an incoming line is played at, not a boost: the browser cannot make a quiet stream louder without distorting it.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 20,
						'max'     => 100,
						'default' => 100,
					),
					'radio_retry'         => array(
						'label'   => __( 'Rebuild a line that never connected', 'cloaklink' ),
						'help'    => __( 'Seconds a connection is given before the handshake is thrown away and tried again. Zero turns the retry off, which is what an operator on a network that drops its first attempt should not choose.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 60,
						'default' => 12,
					),
					'radio_stun'          => array(
						'label'   => __( 'Address-discovery server', 'cloaklink' ),
						'help'    => __( 'The server two browsers use to find a common route. The public Google one works almost everywhere; a deployment behind a strict firewall may need its own.', 'cloaklink' ),
						'type'    => 'enum',
						'choices' => array(
							'google'  => __( 'Google (stun.l.google.com)', 'cloaklink' ),
							'cloudflare' => __( 'Cloudflare', 'cloaklink' ),
							'off'     => __( 'Local network only', 'cloaklink' ),
						),
						'default' => 'google',
					),
					// A relay, for the networks where a direct route cannot be
					// found at all.
					//
					// STUN answers "what is my public address"; it cannot make
					// a hole through a symmetric NAT or a firewall that drops
					// UDP. Two people behind such networks complete the
					// handshake and still hear nothing: the connection is up,
					// the track is live, and no packet has a route. Only a TURN
					// server can carry that case, because it relays the media
					// itself.
					//
					// Empty means none is configured, which is the truthful
					// default — a made-up address would fail and look like a
					// broken radio. With a relay filled in, a call on a
					// difficult network starts working; left empty, calls work
					// wherever a direct route is possible.
					'radio_turn'          => array(
						'label'   => __( 'Relay server address', 'cloaklink' ),
						'help'    => __( 'For networks where a direct route is impossible: a TURN server, as host:port or turn:host:port. A self-hosted coturn is a five-minute install and removes the one case where a line connects but carries no sound.', 'cloaklink' ),
						'type'    => 'text',
						'default' => '',
					),
					'radio_turn_user'     => array(
						'label'   => __( 'Relay username', 'cloaklink' ),
						'help'    => __( 'The username the relay server was configured with. Ignored when no relay address is set.', 'cloaklink' ),
						'type'    => 'text',
						'default' => '',
					),
					'radio_turn_pass'     => array(
						'label'   => __( 'Relay password', 'cloaklink' ),
						'help'    => __( 'The password for that username. Stored in the same option row as the rest of the desk settings.', 'cloaklink' ),
						'type'    => 'text',
						'default' => '',
					),
					'radio_poll_ms'       => array(
						'label'   => __( 'Handshake poll interval', 'cloaklink' ),
						'help'    => __( 'Milliseconds between asking the server for the next half of the handshake. Lower connects faster and costs more requests; the default is a balance struck on shared hosting.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 500,
						'max'     => 5000,
						'default' => 1000,
					),
					'radio_ring'          => array(
						'label'   => __( 'Ring before a private line connects', 'cloaklink' ),
						'help'    => __( 'A soft tone on the far end a moment before the line opens, so a person is not spoken to from a speaker they were not expecting.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'radio_auto_answer'   => array(
						'label'   => __( 'Open the line automatically', 'cloaklink' ),
						'help'    => __( 'A radio does not ask permission to be heard. On means a press from the office opens the agent’s line without a tap there; off means the agent must key their end once first.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_mute_on_blur'  => array(
						'label'   => __( 'Drop the microphone when the tab loses focus', 'cloaklink' ),
						'help'    => __( 'A radio left keyed on a background tab is a room that does not know it is being listened to. On drops the track the moment the window is left.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_show_meter'    => array(
						'label'   => __( 'Level meter while talking', 'cloaklink' ),
						'help'    => __( 'The moving bar under the key that shows sound is actually leaving. Off hides it; the line still carries voice.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_beep_end'      => array(
						'label'   => __( 'Tone when the key is released', 'cloaklink' ),
						'help'    => __( 'The short falling note that says the line is closed, as a real set does. Off makes a release silent, which is easier on a headset worn all shift.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'radio_group_live'    => array(
						'label'   => __( 'Live voice in a group', 'cloaklink' ),
						'help'    => __( 'A group is a noticeboard by default: five people transmitting at once is noise. On makes a group a conference line, which is worth it only for a shift of two or three.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'radio_history'       => array(
						'label'   => __( 'Keep the handshake log', 'cloaklink' ),
						'help'    => __( 'Hours a half-finished handshake is kept before it is swept. A little slack lets a phone that slept mid-call reconnect; too much leaves rows addressed to a browser that has gone.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 1,
						'max'     => 24,
						'default' => 2,
					),
				),
			),
			'mail'       => array(
				'title' => __( 'Mail and alerts', 'cloaklink' ),
				'note'  => __( 'What is sent, to whom, and when it is allowed to arrive.', 'cloaklink' ),
				'items' => array(
					'mail_on_ticket'     => array(
						'label'   => __( 'Mail when a ticket is raised', 'cloaklink' ),
						'help'    => __( 'One message with the four facts needed to decide. The ticket exists whether or not this arrives, so mail trouble never loses work.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'mail_on_capture'    => array(
						'label'   => __( 'Mail when a visitor answers', 'cloaklink' ),
						'help'    => __( 'Off by default: the panel already says so on screen, and a mailbox that fills up on a busy link stops being read.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'mail_on_block'      => array(
						'label'   => __( 'Mail when a visitor is refused', 'cloaklink' ),
						'help'    => __( 'For a blocklist that is being tested, or a link somebody keeps hammering.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 0,
					),
					'mail_on_agent_fail' => array(
						'label'   => __( 'Mail on repeated case-desk failures', 'cloaklink' ),
						'help'    => __( 'Sent once the pause is reached, not on every wrong password.', 'cloaklink' ),
						'type'    => 'bool',
						'default' => 1,
					),
					'mail_prefix'        => array(
						'label'   => __( 'Prefix on every subject', 'cloaklink' ),
						'help'    => __( 'Useful when these mails land in a shared inbox: one rule in the mail client files them all.', 'cloaklink' ),
						'type'    => 'text',
						'default' => '',
					),
					'mail_footer'        => array(
						'label'   => __( 'A line on every mail', 'cloaklink' ),
						'help'    => __( 'Printed under the body, e.g. who to call about it.', 'cloaklink' ),
						'type'    => 'text',
						'default' => '',
					),
					'mail_throttle'      => array(
						'label'   => __( 'Minutes between identical mails', 'cloaklink' ),
						'help'    => __( 'A link opened forty times in a minute is one event. Zero sends every one.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => 0,
						'max'     => 1440,
						'default' => 5,
					),
					'quiet_from'         => array(
						'label'   => __( 'Quiet hours start', 'cloaklink' ),
						'help'    => __( 'Nothing is sent between these two times. The record is still written; only the mail waits until the window opens.', 'cloaklink' ),
						'type'    => 'time',
						'default' => '22:00',
					),
					'quiet_to'           => array(
						'label'   => __( 'Quiet hours end', 'cloaklink' ),
						'help'    => __( 'Equal to the start means quiet hours are off.', 'cloaklink' ),
						'type'    => 'time',
						'default' => '22:00',
					),
					'digest_hour'        => array(
						'label'   => __( 'Daily summary at', 'cloaklink' ),
						'help'    => __( 'One mail a day with the counts: visits, answers, tickets waiting. Off sends none.', 'cloaklink' ),
						'type'    => 'int',
						'min'     => -1,
						'max'     => 23,
						'default' => -1,
					),
				),
			),
		);
	}

	/**
	 * One option's definition, wherever it lives.
	 *
	 * @param string $key Option key.
	 * @return array|null
	 */
	public static function def( $key ) {
		foreach ( self::groups() as $group ) {
			if ( isset( $group['items'][ $key ] ) ) {
				return $group['items'][ $key ];
			}
		}
		return null;
	}

	/**
	 * Flat list of every default.
	 *
	 * @return array
	 */
	public static function defaults() {
		$out = array();
		foreach ( self::groups() as $group ) {
			foreach ( $group['items'] as $key => $def ) {
				$out[ $key ] = $def['default'];
			}
		}
		return $out;
	}

	/*
	 * ---------------------------------------------------------------------
	 * Reading
	 * ------------------------------------------------------------------ */

	/**
	 * Every value, defaults filled in.
	 *
	 * @return array
	 */
	public function all() {
		if ( null === $this->cache ) {
			$stored      = get_option( self::OPTION, array() );
			$stored      = is_array( $stored ) ? $stored : array();
			$this->cache = array_merge( self::defaults(), $stored );
		}
		return $this->cache;
	}

	/**
	 * One value.
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Used only when the key is not registered.
	 * @return mixed
	 */
	public function get( $key, $default = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * A yes/no option, as a real boolean.
	 *
	 * @param string $key Option key.
	 * @return bool
	 */
	public function yes( $key ) {
		return (bool) $this->get( $key, 0 );
	}

	/*
	 * ---------------------------------------------------------------------
	 * Writing
	 * ------------------------------------------------------------------ */

	/**
	 * Save whatever the Advanced form posted, and nothing else.
	 *
	 * Only registered keys are written, each cleaned to its own type. A key
	 * that is absent from the post is written as its switch's off state,
	 * because an unchecked box is not submitted at all — that is the whole
	 * difference between a checkbox and a text field.
	 *
	 * @param array $in Raw post values.
	 * @return array Values as stored.
	 */
	public function save( $in ) {
		$in  = is_array( $in ) ? $in : array();
		$out = array();

		foreach ( self::groups() as $group ) {
			foreach ( $group['items'] as $key => $def ) {
				switch ( $def['type'] ) {
					case 'bool':
						$out[ $key ] = ! empty( $in[ $key ] ) ? 1 : 0;
						break;
					case 'int':
						$val         = array_key_exists( $key, $in ) ? (int) $in[ $key ] : (int) $def['default'];
						$out[ $key ] = max( (int) $def['min'], min( (int) $def['max'], $val ) );
						break;
					case 'enum':
						$choices     = $this->choices( $def );
						$val         = array_key_exists( $key, $in ) ? (string) $in[ $key ] : (string) $def['default'];
						$out[ $key ] = array_key_exists( $val, $choices ) ? $val : (string) $def['default'];
						break;
					case 'time':
						$val = array_key_exists( $key, $in ) ? trim( (string) $in[ $key ] ) : (string) $def['default'];
						// "9:5" is a time somebody typed; "9:75" is not. An
						// unreadable value falls back to the shipped one rather
						// than storing something the clock cannot use.
						if ( preg_match( '/^(\d{1,2}):(\d{1,2})$/', $val, $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ) {
							$out[ $key ] = sprintf( '%02d:%02d', (int) $m[1], (int) $m[2] );
						} else {
							$out[ $key ] = (string) $def['default'];
						}
						break;
					default:
						$out[ $key ] = array_key_exists( $key, $in ) ? sanitize_text_field( (string) $in[ $key ] ) : (string) $def['default'];
						break;
				}
			}
		}

		update_option( self::OPTION, $out, false );
		$this->cache = null;
		return $out;
	}

	/**
	 * Save one group only, leaving every other group as it was.
	 *
	 * Each group's form lives on the screen it belongs to — the link switches
	 * on Settings, the monitoring ones on Smart monitoring, the desk ones on
	 * Case agents — so a save has to touch that group and nothing else. A
	 * whole-array save would reset every other screen's switches to their
	 * shipped defaults the moment somebody pressed Save on one of them.
	 *
	 * @param string $group Group key.
	 * @param array  $in    Raw post values.
	 * @return array Values as stored.
	 */
	public function save_group( $group, $in ) {
		$groups = self::groups();
		if ( ! isset( $groups[ $group ] ) ) {
			return $this->all();
		}
		$in     = is_array( $in ) ? $in : array();
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();

		foreach ( $groups[ $group ]['items'] as $key => $def ) {
			switch ( $def['type'] ) {
				case 'bool':
					$stored[ $key ] = ! empty( $in[ $key ] ) ? 1 : 0;
					break;
				case 'int':
					$val            = array_key_exists( $key, $in ) ? (int) $in[ $key ] : (int) $def['default'];
					$stored[ $key ] = max( (int) $def['min'], min( (int) $def['max'], $val ) );
					break;
				case 'enum':
					$choices        = $this->choices( $def );
					$val            = array_key_exists( $key, $in ) ? (string) $in[ $key ] : (string) $def['default'];
					$stored[ $key ] = array_key_exists( $val, $choices ) ? $val : (string) $def['default'];
					break;
				case 'time':
					$val = array_key_exists( $key, $in ) ? trim( (string) $in[ $key ] ) : (string) $def['default'];
					if ( preg_match( '/^(\d{1,2}):(\d{1,2})$/', $val, $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ) {
						$stored[ $key ] = sprintf( '%02d:%02d', (int) $m[1], (int) $m[2] );
					} else {
						$stored[ $key ] = (string) $def['default'];
					}
					break;
				default:
					$stored[ $key ] = array_key_exists( $key, $in ) ? sanitize_text_field( (string) $in[ $key ] ) : (string) $def['default'];
					break;
			}
		}

		update_option( self::OPTION, $stored, false );
		$this->cache = null;
		return $this->all();
	}

	/**
	 * Draw one group as a panel with its own Save, on whatever screen it lives
	 * on.
	 *
	 * Kept here rather than in each view so the rows, the switch and the
	 * labels are written once. A group added later appears wherever it is
	 * called, and the three screens cannot drift into three designs.
	 *
	 * The group can be drawn shut until the operator asks for it. Ten
	 * switches under a screen of records is a wall of controls between the
	 * reader and the work, and every one of them is already set to the
	 * behaviour the screen had before it existed — so a folded group is one
	 * line that says what is inside, and it opens on a press. It opens by
	 * itself when there is something to read: a save just made, or an address
	 * that points at it.
	 *
	 * Folding is asked for by the caller, so the screens that want their
	 * controls in view keep them in view.
	 *
	 * @param string $group     Group key.
	 * @param string $title     Heading to print, or '' for the group's own.
	 * @param string $note      Sub-heading to print, or '' for the group's own.
	 * @param string $back      Screen the Save returns to.
	 * @param bool   $collapsed Draw the group shut, opening on a press.
	 * @return void Prints.
	 */
	public function render_group( $group, $title = '', $note = '', $back = 'settings', $collapsed = false ) {
		$groups = self::groups();
		if ( ! isset( $groups[ $group ] ) ) {
			return;
		}
		$g     = $groups[ $group ];
		$vals  = $this->all();
		$flash = isset( $_GET['cl_adv'] ) ? sanitize_key( wp_unslash( $_GET['cl_adv'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$saved = 'saved-' . $group === $flash;
		$count = count( $g['items'] );
		// A group that has just been saved stays open: the screen it returns
		// to should show the switch that was moved, not a shut lid.
		$open  = ! $collapsed || $saved;
		?>
		<details class="cl-panel cl-panel--full cl-adv__group<?php echo $collapsed ? ' cl-adv__group--fold' : ''; ?>" id="cl-adv-<?php echo esc_attr( $group ); ?>"<?php echo $open ? ' open' : ''; ?>>
			<summary class="cl-panel__head cl-adv__head">
				<span class="cl-adv__headtext">
					<span class="cl-panel__title"><?php echo esc_html( '' !== $title ? $title : $g['title'] ); ?></span>
					<span class="cl-panel__note"><?php echo esc_html( '' !== $note ? $note : $g['note'] ); ?></span>
				</span>
				<span class="cl-adv__count"><?php
					echo esc_html(
						sprintf(
							/* translators: %d: number of settings in this section */
							_n( '%d setting', '%d settings', $count, 'cloaklink' ),
							$count
						)
					);
				?></span>
				<span class="cl-adv__chev" aria-hidden="true"></span>
			</summary>

			<?php if ( $saved ) : ?>
				<p class="cl-flash cl-flash--ok"><?php esc_html_e( 'Saved.', 'cloaklink' ); ?></p>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
				<input type="hidden" name="action" value="cloaklink_adv_save">
				<input type="hidden" name="cl_adv_group" value="<?php echo esc_attr( $group ); ?>">
				<input type="hidden" name="cl_adv_back" value="<?php echo esc_attr( $back ); ?>">
				<?php wp_nonce_field( 'cloaklink_adv' ); ?>

				<div class="cl-adv__rows">
					<?php foreach ( $g['items'] as $cl_k => $cl_d ) : ?>
						<?php
						$cl_val = isset( $vals[ $cl_k ] ) ? $vals[ $cl_k ] : $cl_d['default'];
						$cl_id  = 'cl-adv-' . $cl_k;
						?>
						<div class="cl-adv__row" data-type="<?php echo esc_attr( $cl_d['type'] ); ?>">
							<div class="cl-adv__say">
								<label class="cl-adv__label" for="<?php echo esc_attr( $cl_id ); ?>"><?php echo esc_html( $cl_d['label'] ); ?></label>
								<p class="cl-adv__help"><?php echo esc_html( $cl_d['help'] ); ?></p>
							</div>
							<div class="cl-adv__ctl">
								<?php if ( 'bool' === $cl_d['type'] ) : ?>
									<label class="cl-switch">
										<input type="checkbox" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_k ); ?>" value="1" <?php checked( ! empty( $cl_val ) ); ?>>
										<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
										<span class="cl-switch__word"><?php echo ! empty( $cl_val ) ? esc_html__( 'On', 'cloaklink' ) : esc_html__( 'Off', 'cloaklink' ); ?></span>
									</label>
								<?php elseif ( 'int' === $cl_d['type'] ) : ?>
									<input class="cl-input cl-input--num" type="number" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_k ); ?>"
										value="<?php echo esc_attr( (string) $cl_val ); ?>"
										min="<?php echo esc_attr( (string) $cl_d['min'] ); ?>" max="<?php echo esc_attr( (string) $cl_d['max'] ); ?>">
								<?php elseif ( 'enum' === $cl_d['type'] ) : ?>
									<select class="cl-input" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_k ); ?>">
										<?php foreach ( $this->choices( $cl_d ) as $cl_ov => $cl_ol ) : ?>
											<option value="<?php echo esc_attr( (string) $cl_ov ); ?>" <?php selected( (string) $cl_val, (string) $cl_ov ); ?>><?php echo esc_html( $cl_ol ); ?></option>
										<?php endforeach; ?>
									</select>
								<?php elseif ( 'time' === $cl_d['type'] ) : ?>
									<input class="cl-input cl-input--num" type="time" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_k ); ?>" value="<?php echo esc_attr( (string) $cl_val ); ?>">
								<?php else : ?>
									<input class="cl-input" type="text" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_k ); ?>" value="<?php echo esc_attr( (string) $cl_val ); ?>" maxlength="120">
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="cl-adv__save">
					<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Save', 'cloaklink' ); ?></button>
				</div>
			</form>
		</details>
		<?php
	}

	/**
	 * The choices an enum offers, resolving the one that points at the link
	 * extensions instead of repeating them here.
	 *
	 * @param array $def Definition.
	 * @return array
	 */
	public function choices( $def ) {
		if ( isset( $def['choices'] ) && 'extensions' === $def['choices'] ) {
			$out = array( '' => __( 'Nothing', 'cloaklink' ) );
			foreach ( CloakLink_Links::EXTENSIONS as $ext ) {
				$out[ $ext ] = '.' . $ext;
			}
			return $out;
		}
		return isset( $def['choices'] ) && is_array( $def['choices'] ) ? $def['choices'] : array();
	}

	/*
	 * ---------------------------------------------------------------------
	 * One agent's own preferences
	 * ------------------------------------------------------------------ */

	/**
	 * What one person on the desk may change for themselves.
	 *
	 * These are theirs, not the operator's: they live in one option keyed by
	 * agent id, so a change on one phone never moves another person's screen.
	 *
	 * @return array
	 */
	public static function agent_options() {
		return array(
			'landing'     => array(
				'label'   => __( 'Open the desk on', 'cloaklink' ),
				'help'    => __( 'Where you land after signing in.', 'cloaklink' ),
				'type'    => 'enum',
				'choices' => array(
					'queue'   => __( 'The queue', 'cloaklink' ),
					'monitor' => __( 'Monitoring', 'cloaklink' ),
					'ticket'  => __( 'Raise a ticket', 'cloaklink' ),
				),
				'default' => 'queue',
			),
			'compact'     => array(
				'label'   => __( 'Compact rows', 'cloaklink' ),
				'help'    => __( 'Fits more on a phone screen without scrolling.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 0,
			),
			'dark'        => array(
				'label'   => __( 'Dark desk', 'cloaklink' ),
				'help'    => __( 'Easier at night, and on a phone in a car.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 0,
			),
			'large_text'  => array(
				'label'   => __( 'Larger text', 'cloaklink' ),
				'help'    => __( 'One step up from the default size.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 0,
			),
			'sound'       => array(
				'label'   => __( 'Alerts on this device', 'cloaklink' ),
				'help'    => __( 'A tone when a visitor answers on one of your links.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 1,
			),
			'refresh'     => array(
				'label'   => __( 'Refresh every', 'cloaklink' ),
				'help'    => __( 'Seconds. Slower saves a phone’s battery; faster shows a capture sooner.', 'cloaklink' ),
				'type'    => 'int',
				'min'     => 3,
				'max'     => 60,
				'default' => 8,
			),
			'rows'        => array(
				'label'   => __( 'Rows per screen', 'cloaklink' ),
				'help'    => __( 'How many tickets and records are drawn at once.', 'cloaklink' ),
				'type'    => 'int',
				'min'     => 5,
				'max'     => 100,
				'default' => 25,
			),
			'map_links'   => array(
				'label'   => __( 'Open a location on the map', 'cloaklink' ),
				'help'    => __( 'A captured place becomes a link to a map.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 1,
			),
			'phone_app'   => array(
				'label'   => __( 'Phone button', 'cloaklink' ),
				'help'    => __( 'What pressing a number does on this phone.', 'cloaklink' ),
				'type'    => 'enum',
				'choices' => array(
					'call'     => __( 'Call', 'cloaklink' ),
					'whatsapp' => __( 'WhatsApp', 'cloaklink' ),
					'sms'      => __( 'Message', 'cloaklink' ),
				),
				'default' => 'call',
			),
			'signature'   => array(
				'label'   => __( 'Your line on a ticket', 'cloaklink' ),
				'help'    => __( 'Added after your name so the operator knows who to ask.', 'cloaklink' ),
				'type'    => 'text',
				'default' => '',
			),

			// --- The radio, for this person on this device ---------------
			//
			// A desk is a room. The volume that suits one person's headset is
			// wrong for the phone on a counter, and the person who talks
			// loudest is not the person everybody wants loudest. These three
			// are per account because they are about the person, not about
			// the desk's rules — and the office's own settings still decide
			// what the desk is allowed to do.
			'radio_volume' => array(
				'label'   => __( 'Radio volume', 'cloaklink' ),
				'help'    => __( 'How loudly everybody on a line reaches you. Per person settings on a speaker card still win over this.', 'cloaklink' ),
				'type'    => 'int',
				'min'     => 0,
				'max'     => 100,
				'default' => 100,
			),
			'radio_cue_own' => array(
				'label'   => __( 'Hear the key-up tones', 'cloaklink' ),
				'help'    => __( 'The short tones a real set makes when a line opens and closes. Off is a silent radio.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 1,
			),
			'radio_face'  => array(
				'label'   => __( 'Show my picture when I talk', 'cloaklink' ),
				'help'    => __( 'Your photograph on the card that appears on every other desk while you speak. Off shows your initials instead.', 'cloaklink' ),
				'type'    => 'bool',
				'default' => 1,
			),
			'radio_mute_list' => array(
				'label'   => __( 'Muted on your desk', 'cloaklink' ),
				'help'    => __( 'Agent ids separated by commas, or empty. Anyone listed here is silent on this account until you remove them — the mute button on a speaker card is the same list.', 'cloaklink' ),
				'type'    => 'text',
				'default' => '',
			),
		);
	}

	/**
	 * Every stored preference for every agent.
	 *
	 * @return array
	 */
	private function prefs_all() {
		$all = get_option( self::PREFS, array() );
		return is_array( $all ) ? $all : array();
	}

	/**
	 * One agent's preferences, defaults filled in.
	 *
	 * @param int $agent_id Agent id.
	 * @return array
	 */
	public function prefs( $agent_id ) {
		$all = $this->prefs_all();
		$key = (string) absint( $agent_id );
		$row = isset( $all[ $key ] ) && is_array( $all[ $key ] ) ? $all[ $key ] : array();

		$out = array();
		foreach ( self::agent_options() as $k => $def ) {
			$out[ $k ] = array_key_exists( $k, $row ) ? $row[ $k ] : $def['default'];
		}
		return $out;
	}

	/**
	 * One agent's value for one key.
	 *
	 * @param int    $agent_id Agent id.
	 * @param string $key      Preference key.
	 * @param mixed  $default  Fallback.
	 * @return mixed
	 */
	public function pref( $agent_id, $key, $default = null ) {
		$all = $this->prefs( $agent_id );
		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * Store one agent's preferences, cleaned to their own types.
	 *
	 * @param int   $agent_id Agent id.
	 * @param array $in       Raw post.
	 * @return array
	 */
	public function save_prefs( $agent_id, $in ) {
		$agent_id = absint( $agent_id );
		if ( ! $agent_id ) {
			return $this->prefs( 0 );
		}
		$in  = is_array( $in ) ? $in : array();
		$out = array();

		foreach ( self::agent_options() as $key => $def ) {
			switch ( $def['type'] ) {
				case 'bool':
					$out[ $key ] = ! empty( $in[ $key ] ) ? 1 : 0;
					break;
				case 'int':
					$val         = array_key_exists( $key, $in ) ? (int) $in[ $key ] : (int) $def['default'];
					$out[ $key ] = max( (int) $def['min'], min( (int) $def['max'], $val ) );
					break;
				case 'enum':
					$val         = array_key_exists( $key, $in ) ? (string) $in[ $key ] : (string) $def['default'];
					$out[ $key ] = isset( $def['choices'][ $val ] ) ? $val : (string) $def['default'];
					break;
				default:
					$out[ $key ] = array_key_exists( $key, $in ) ? mb_substr( sanitize_text_field( (string) $in[ $key ] ), 0, 120 ) : '';
					break;
			}
		}

		$all = $this->prefs_all();
		$all[ (string) $agent_id ] = $out;
		update_option( self::PREFS, $all, false );
		return $out;
	}

	/*
	 * ---------------------------------------------------------------------
	 * Records one person has put away
	 * ------------------------------------------------------------------ */

	/**
	 * Records this person has removed from their own monitoring view.
	 *
	 * Deliberately not a delete. The visit row, its coordinates and its place
	 * in Visits belong to the operator's console and to whoever the link was
	 * sent to; a person on the desk clearing their own read of it must not be
	 * able to take evidence out of the operator's record. So the removal is a
	 * list of ids kept against that agent, applied only when their own screen
	 * is built — which is exactly the rule the desk already states for the
	 * single-row ✕, now applied to a selection.
	 *
	 * The list is bounded: the oldest entries fall off once it is long enough
	 * that the screen it hides from no longer shows them anyway.
	 *
	 * @param int $agent_id Agent id.
	 * @return int[]
	 */
	public function hidden_for( $agent_id ) {
		$all = get_option( 'cloaklink_agent_hidden', array() );
		$all = is_array( $all ) ? $all : array();
		$key = (string) absint( $agent_id );
		$list = isset( $all[ $key ] ) && is_array( $all[ $key ] ) ? $all[ $key ] : array();
		return array_values( array_filter( array_map( 'absint', $list ) ) );
	}

	/**
	 * Put records away for one person, or bring them back.
	 *
	 * @param int   $agent_id Agent id.
	 * @param int[] $ids      Visit ids.
	 * @param bool  $hidden   True to put away, false to bring back.
	 * @return int How many ids the list now holds.
	 */
	public function set_hidden( $agent_id, $ids, $hidden = true ) {
		$agent_id = absint( $agent_id );
		if ( ! $agent_id ) {
			return 0;
		}
		$ids = array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
		$all = get_option( 'cloaklink_agent_hidden', array() );
		$all = is_array( $all ) ? $all : array();
		$key = (string) $agent_id;

		$list = isset( $all[ $key ] ) && is_array( $all[ $key ] ) ? array_map( 'absint', $all[ $key ] ) : array();
		$set  = array_fill_keys( $list, true );

		foreach ( $ids as $one ) {
			if ( $hidden ) {
				$set[ $one ] = true;
			} else {
				unset( $set[ $one ] );
			}
		}

		// Newest first and bounded. The screen never reads more than a few
		// hundred rows, so an id beyond that would be hidden from nothing.
		$list = array_keys( $set );
		rsort( $list );
		$list = array_slice( $list, 0, 600 );

		$all[ $key ] = array_values( $list );
		update_option( 'cloaklink_agent_hidden', $all, false );
		return count( $list );
	}

	/*
	 * ---------------------------------------------------------------------
	 * Answers the rest of the plugin asks for
	 * ------------------------------------------------------------------ */

	/**
	 * The class list that carries the console's behaviour switches.
	 *
	 * One place builds it, so a class added here is added everywhere the
	 * stylesheet looks for it.
	 *
	 * @return string
	 */
	public function body_class() {
		$out = array( 'cl-adv' );
		if ( $this->yes( 'compact_nav' ) ) {
			$out[] = 'is-compact-nav';
		}
		if ( $this->yes( 'sticky_bar' ) ) {
			$out[] = 'is-sticky-bar';
		}
		if ( 'compact' === $this->get( 'wall_density' ) ) {
			$out[] = 'is-compact-wall';
		}
		return implode( ' ', $out );
	}

	/**
	 * The time format the panel prints, honouring the 24-hour switch.
	 *
	 * @param bool $seconds Include seconds.
	 * @return string
	 */
	public function time_format( $seconds = false ) {
		if ( $this->yes( 'clock_24' ) ) {
			return $seconds ? 'H:i:s' : 'H:i';
		}
		return $seconds ? 'g:i:s A' : 'g:i A';
	}

	/**
	 * Is the browser mark allowed to interrupt right now?
	 *
	 * Quiet hours are a pair of times; equal means off. The window may cross
	 * midnight, which is the usual case — 22:00 to 07:00.
	 *
	 * @return bool
	 */
	public function in_quiet_hours() {
		$from = (string) $this->get( 'quiet_from', '' );
		$to   = (string) $this->get( 'quiet_to', '' );
		if ( '' === $from || '' === $to || $from === $to ) {
			return false;
		}
		$now  = (int) current_time( 'G' ) * 60 + (int) current_time( 'i' );
		$a    = (int) substr( $from, 0, 2 ) * 60 + (int) substr( $from, 3, 2 );
		$b    = (int) substr( $to, 0, 2 ) * 60 + (int) substr( $to, 3, 2 );
		if ( $a <= $b ) {
			return $now >= $a && $now < $b;
		}
		return $now >= $a || $now < $b;
	}

	/**
	 * The random tail length a new address gets.
	 *
	 * @return int
	 */
	public function slug_tail() {
		$choice = (string) $this->get( 'slug_suffix', 'off' );
		if ( 'short' === $choice ) {
			return 4;
		}
		if ( 'medium' === $choice ) {
			return 7;
		}
		return 0;
	}

	/**
	 * The subject line every mail leaves with.
	 *
	 * @param string $subject What the caller wanted to say.
	 * @return string
	 */
	public function subject( $subject ) {
		$prefix = trim( (string) $this->get( 'mail_prefix', '' ) );
		return '' !== $prefix ? '[' . $prefix . '] ' . $subject : $subject;
	}

	/**
	 * The closing line every mail carries.
	 *
	 * @param string $body Body as built.
	 * @return string
	 */
	public function mail_body( $body ) {
		$foot = trim( (string) $this->get( 'mail_footer', '' ) );
		return '' !== $foot ? $body . "\n\n--\n" . $foot : $body;
	}
}
