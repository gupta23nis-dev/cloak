<?php
/**
 * The desk's activity log.
 *
 * Every action a person on the case desk takes is written here: signing in,
 * signing out, raising a ticket, clearing a record, and the answering of a
 * refused sign-in. The operator's question this answers is not "what did they
 * do" in the abstract — it is "who was on the desk at ten past nine, from
 * where, and what happened next".
 *
 * Two rules shape the table and this class:
 *
 *   1. It records actions, not data. A row says a ticket was raised and which
 *      one; it never copies the visitor's name, the position or the capture
 *      into itself. Deleting a ticket therefore leaves a truthful record that
 *      something was raised, without a second copy of the thing that was
 *      deleted.
 *   2. Nothing here can be edited from the browser. The only writes are the
 *      ones below, all of which are called from a server-side action that has
 *      already passed its own checks.
 *
 * Presence is derived rather than stored: a person is "on the desk" when
 * their last sign-in is recent and their session has not been ended. That
 * keeps the answer correct after a laptop is shut without needing a heartbeat
 * request every few seconds from every agent.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Records and reads what people on the case desk did.
 */
class CloakLink_Agent_Log {

	/** Minutes after which a sign-in with no sign-out is treated as stale. */
	const LIVE_MINUTES = 30;

	/** How long a desk heartbeat counts as "open". */
	const BEAT_MINUTES = 4;

	/**
	 * The table this class writes to.
	 *
	 * @return string
	 */
	public function table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_agent_activity';
	}

	/**
	 * The newest sign-ins and sign-outs, for the operator's alert.
	 *
	 * The desk page has always known who is on it, but only when it was
	 * reloaded. This asks the same table for the last few door events after a
	 * cursor, which is what lets the console say "Deepak signed in" the
	 * moment it happens rather than the next time somebody presses refresh.
	 *
	 * It reads the newest rows only. A shift that begins while the operator
	 * is asleep is one alert, not forty: the caller is handed at most a
	 * handful and the cursor moves past all of them.
	 *
	 * @param int $after Last id already seen, or 0 for none.
	 * @return array
	 */
	/**
	 * The highest id in the log right now.
	 *
	 * Used to place a cursor at the present without reading history: a panel
	 * opened at nine should say nothing about eight, and the number it needs
	 * is this one.
	 *
	 * @return int
	 */
	public function newest_id() {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . $this->table() ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public function door_since( $after = 0 ) {
		global $wpdb;

		$after = absint( $after );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				// Newest first, then reversed below. Ascending with a limit
				// takes the *oldest* twenty after the cursor, which on a busy
				// shift stops short of the event being announced and leaves
				// the cursor behind it — the operator would be told about
				// this morning and never about just now.
				'SELECT id, agent_id, event, ip, city, device, created_at FROM ' . $this->table()
				. " WHERE id > %d AND event IN ( 'signin', 'signout' ) ORDER BY id DESC LIMIT 20", // phpcs:ignore WordPress.DB.PreparedSQL
				$after
			),
			ARRAY_A
		);
		$rows = is_array( $rows ) ? array_reverse( (array) $rows ) : array();
		if ( ! $rows ) {
			return array();
		}

		$names = array();
		$all   = cloaklink()->agents->all();
		foreach ( $all as $one ) {
			$names[ (int) $one['id'] ] = (string) $one['name'];
		}

		$out = array();
		foreach ( $rows as $row ) {
			$id     = (int) $row['agent_id'];
			$out[]  = array(
				'id'    => (int) $row['id'],
				'agent' => $id,
				'name'  => isset( $names[ $id ] ) ? $names[ $id ] : __( 'A removed account', 'cloaklink' ),
				'event' => (string) $row['event'],
				'in'    => 'signin' === (string) $row['event'],
				'city'  => (string) $row['city'],
				'ip'    => (string) $row['ip'],
				'at'    => CloakLink_Admin::stamp( $row['created_at'], 'H:i' ),
			);
		}
		return $out;
	}

	/**
	 * The words an event is printed with.
	 *
	 * One list rather than a switch in four templates: the log, the agent's
	 * own history and any export all name an event the same way, so a row
	 * cannot read as two different things on two screens.
	 *
	 * @return array event => array( label, tone )
	 */
	public static function events() {
		return array(
			'signin'        => array( __( 'Signed in', 'cloaklink' ), 'ok' ),
			'signout'       => array( __( 'Signed out', 'cloaklink' ), 'muted' ),
			'signin_failed' => array( __( 'Sign-in refused', 'cloaklink' ), 'bad' ),
			'code_failed'   => array( __( 'Wrong access code', 'cloaklink' ), 'bad' ),
			'paused_login'  => array( __( 'Tried a switched-off account', 'cloaklink' ), 'bad' ),
			'locked'        => array( __( 'Desk locked itself', 'cloaklink' ), 'warn' ),
			'unlocked'      => array( __( 'Desk unlocked', 'cloaklink' ), 'ok' ),
			'ticket_raised' => array( __( 'Raised a ticket', 'cloaklink' ), 'info' ),
			'ticket_allowed' => array( __( 'Allowed a ticket', 'cloaklink' ), 'ok' ),
			'ticket_held'   => array( __( 'Held a ticket', 'cloaklink' ), 'warn' ),
			'ticket_deleted' => array( __( 'Removed a ticket', 'cloaklink' ), 'bad' ),
			'record_cleared' => array( __( 'Cleared a record', 'cloaklink' ), 'warn' ),
			'ticket_opened' => array( __( 'Opened a ticket', 'cloaklink' ), 'muted' ),
			'link_copied'   => array( __( 'Copied a link', 'cloaklink' ), 'info' ),
			// A person changing their own name, picture, password or code.
			// Recorded because the office still has to be able to answer "who
			// changed this, and when" — the difference is who made the change,
			// not whether it is written down.
			'self_edit'     => array( __( 'Changed their own account', 'cloaklink' ), 'info' ),
		);
	}

	/**
	 * The label for one event.
	 *
	 * @param string $event Event key.
	 * @return array [label, tone]
	 */
	public static function label( $event ) {
		$all = self::events();
		return isset( $all[ $event ] ) ? $all[ $event ] : array( (string) $event, 'muted' );
	}

	/**
	 * Write one row.
	 *
	 * The address, the device and the place are read here rather than passed
	 * in, because every caller is a request from the person's own browser and
	 * none of them has a better answer than the request itself.
	 *
	 * A log write must never stop the action it is recording from happening:
	 * a failed insert is swallowed, and the desk carries on. That is the right
	 * trade — the alternative is a person unable to sign in because the
	 * activity table is missing after a partial upgrade.
	 *
	 * @param int    $agent_id Person. 0 for a refused sign-in with no account.
	 * @param string $event    Event key.
	 * @param array  $args     Optional: detail, subject.
	 * @return int Row id, or 0.
	 */
	public function log( $agent_id, $event, $args = array() ) {
		global $wpdb;

		$ua   = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 500 ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$parsed = CloakLink_UA::parse( $ua );

		// Whether the network a person signed in from is written down. Some
		// desks would rather not keep it; the event, the time and the device
		// still are, so the log still answers "who did what and when" — it
		// simply does not answer "from where".
		$keep_ip = ! function_exists( 'cloaklink' ) || ! cloaklink()->adv || cloaklink()->adv->yes( 'agent_seen_ips' );
		$ip      = $keep_ip ? CloakLink_Geo::ip() : '';
		$geo     = $keep_ip ? CloakLink_Geo::lookup( $ip ) : array();
		$geo     = is_array( $geo ) ? $geo : array();

		// A caller may name the place itself. Nothing in the plugin needs
		// this; a test that has to prove "the console heard a sign-in from
		// Mumbai" needs a sign-in from Mumbai, and a lookup against a
		// localhost address will never produce one.
		if ( isset( $args['ip'] ) ) {
			$ip = (string) $args['ip'];
		}
		if ( isset( $args['city'] ) ) {
			$geo['city'] = (string) $args['city'];
		}

		$ok = $wpdb->insert(
			$this->table(),
			array(
				'agent_id'     => absint( $agent_id ),
				'event'        => substr( sanitize_key( (string) $event ), 0, 32 ),
				'detail'       => isset( $args['detail'] ) ? mb_substr( sanitize_text_field( (string) $args['detail'] ), 0, 255 ) : '',
				'subject'      => isset( $args['subject'] ) ? absint( $args['subject'] ) : 0,
				'ip'           => substr( (string) $ip, 0, 64 ),
				'ip_hash'      => hash( 'sha256', (string) $ip ),
				'country_code' => isset( $geo['country_code'] ) ? substr( (string) $geo['country_code'], 0, 2 ) : '',
				'city'         => isset( $geo['city'] ) ? mb_substr( (string) $geo['city'], 0, 120 ) : '',
				'device'       => substr( (string) $parsed['device'], 0, 24 ),
				'browser'      => substr( (string) $parsed['browser'], 0, 64 ),
				'os'           => substr( (string) $parsed['os'], 0, 64 ),
				'ua'           => $ua,
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * The log, newest first.
	 *
	 * @param array $args agent_id, event, from, to, max, page.
	 * @return array
	 */
	public function rows( $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'agent_id' => 0,
				'event'    => '',
				'from'     => '',
				'to'       => '',
				'max'      => 50,
				'page'     => 1,
				'order'    => 'newest',
			)
		);

		list( $where, $params ) = $this->where( $args );

		$max    = max( 1, min( 500, (int) $args['max'] ) );
		$offset = max( 0, ( (int) $args['page'] - 1 ) * $max );
		// Two orders and no more: the id is the order things happened in, so
		// "oldest" is the same list read from the other end. Anything else in
		// the argument falls back to newest rather than reaching the query.
		$dir    = 'oldest' === (string) $args['order'] ? 'ASC' : 'DESC';
		$sql    = 'SELECT * FROM ' . $this->table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id ' . $dir . ' LIMIT %d OFFSET %d';
		$params = array_merge( $params, array( $max, $offset ) );

		$rows = $wpdb->get_results( call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $params ) ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * How many rows match.
	 *
	 * @param array $args Same filters as rows().
	 * @return int
	 */
	public function count( $args = array() ) {
		global $wpdb;
		list( $where, $params ) = $this->where( wp_parse_args( $args, array() ) );
		$sql = 'SELECT COUNT(*) FROM ' . $this->table() . ' WHERE ' . implode( ' AND ', $where );
		if ( $params ) {
			return (int) $wpdb->get_var( call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $params ) ) );
		}
		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Build the WHERE clause for a set of filters.
	 *
	 * @param array $args Filters.
	 * @return array [where, params]
	 */
	private function where( $args ) {
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['agent_id'] ) ) {
			$where[]  = 'agent_id = %d';
			$params[] = absint( $args['agent_id'] );
		}
		if ( ! empty( $args['event'] ) ) {
			$where[]  = 'event = %s';
			$params[] = sanitize_key( (string) $args['event'] );
		}
		if ( ! empty( $args['from'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = (string) $args['from'] . ' 00:00:00';
		}
		if ( ! empty( $args['to'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = (string) $args['to'] . ' 23:59:59';
		}

		return array( $where, $params );
	}

	/**
	 * Who is on the desk right now, and who was.
	 *
	 * For each person: their last sign-in, their last sign-out, and whether
	 * the last thing they did was arrive. "Online" is derived from that
	 * sequence and the age of the sign-in — not from a heartbeat — so it stays
	 * right when a laptop is closed mid-session, and it does not add a request
	 * per agent per second to the site.
	 *
	 * @return array agent id => array( in, out, live, minutes, ip, city, device )
	 */
	public function presence() {
		global $wpdb;

		$rows = $wpdb->get_results(
			'SELECT agent_id, event, ip, city, device, browser, created_at FROM ' . $this->table()
			. " WHERE event IN ( 'signin', 'signout', 'locked', 'unlocked' ) ORDER BY id DESC LIMIT 800", // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();

		$out = array();
		foreach ( $rows as $row ) {
			$id = (int) $row['agent_id'];
			if ( $id < 1 ) {
				continue;
			}
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array(
					'in'     => '',
					'out'    => '',
					'live'   => false,
					'ip'     => '',
					'city'   => '',
					'device' => '',
					'lock'   => '',
				);
			}

			// Newest first. Only a sign-in or a sign-out decides presence, and
			// only the newest of the two does: a sign-out that happened before
			// the last sign-in belongs to the previous session and must not
			// close the one that is open now. `in` being filled is therefore
			// what gates a sign-out, and once a sign-out has been recorded it
			// gates every older sign-in.
			if ( 'signin' === $row['event'] ) {
				if ( '' === $out[ $id ]['in'] ) {
					$out[ $id ]['in']     = (string) $row['created_at'];
					$out[ $id ]['ip']     = (string) $row['ip'];
					$out[ $id ]['city']   = (string) $row['city'];
					$out[ $id ]['device'] = (string) $row['device'];
				}
			} elseif ( 'signout' === $row['event'] ) {
				// Only a sign-out that came after the sign-in closes it. MySQL
				// datetimes sort as strings, so the comparison is the same
				// question the clock would answer.
				if ( '' === $out[ $id ]['out']
					&& '' !== $out[ $id ]['in']
					&& strcmp( (string) $row['created_at'], $out[ $id ]['in'] ) > 0 ) {
					$out[ $id ]['out'] = (string) $row['created_at'];
				}
			} elseif ( 'locked' === $row['event'] ) {
				if ( '' === $out[ $id ]['lock'] && '' === $out[ $id ]['out'] ) {
					$out[ $id ]['lock'] = (string) $row['created_at'];
				}
			}
		}

		// A sign-in followed by nothing at all is live only while it is recent.
		// This is the one place the two facts are put together, so every screen
		// that asks "who is on the desk" gets the same answer.
		foreach ( $out as $id => $one ) {
			$out[ $id ]['live'] = ( '' !== $one['in'] && '' === $one['out'] && $this->still_live( $one['in'] ) );
		}

		// A heartbeat beats the estimate.
		//
		// The log can only say "signed in and not signed out since", and a
		// laptop closed at 10am looked exactly like a desk still being worked
		// at 3pm until the thirty-minute window ran out. The case desk's own
		// poll checks in every few seconds while the panel is open, so the
		// operator's screen can say Available while somebody is actually there
		// and Offline the moment they close the tab — not half an hour later.
		foreach ( $out as $id => $one ) {
			if ( '' !== $one['out'] ) {
				$out[ $id ]['live'] = false;
				continue;
			}
			$beat = self::beat_of( (int) $id );
			if ( $beat ) {
				$out[ $id ]['live'] = ( time() - $beat ) < ( self::BEAT_MINUTES * MINUTE_IN_SECONDS );
			}
		}

		return $out;
	}

	/**
	 * How recently a browser had the case desk open, in seconds, or 0.
	 *
	 * The desk's poll writes this. It is a transient rather than a column
	 * because it is a fact about right now and nothing else: it is worthless
	 * a quarter of an hour later, and a transient expires on its own.
	 *
	 * @param int $agent_id Agent id.
	 * @return int Unix time, or 0 when it has never checked in.
	 */
	public static function beat_of( $agent_id ) {
		$agent_id = (int) $agent_id;
		if ( $agent_id < 1 ) {
			return 0;
		}
		$beat = get_transient( 'cl_beat_' . $agent_id );
		return $beat ? (int) $beat : 0;
	}

	/**
	 * Say that this person's desk is open right now.
	 *
	 * @param int $agent_id Agent id.
	 * @return void
	 */
	public static function beat( $agent_id ) {
		$agent_id = (int) $agent_id;
		if ( $agent_id < 1 ) {
			return;
		}
		// The desk now polls twice a second, and this runs on every poll. A
		// transient write on a site with no persistent object cache is an
		// options row update, so leaving it unconditional meant thirty writes
		// a minute per open desk to record a fact that only needs to be
		// roughly now.
		//
		// Twenty seconds is well inside the four-minute expiry, so the desk
		// still reads Online for exactly as long as it did, and a stale
		// transient still refreshes itself long before anyone could notice.
		$key  = 'cl_beat_' . $agent_id;
		$last = (int) get_transient( $key );
		$now  = time();
		if ( $last && $now - $last < 20 ) {
			return;
		}
		set_transient( $key, $now, self::BEAT_MINUTES * MINUTE_IN_SECONDS );
	}

	/**
	 * Say that this person's desk has closed.
	 *
	 * @param int $agent_id Agent id.
	 * @return void
	 */
	public static function stop_beat( $agent_id ) {
		$agent_id = (int) $agent_id;
		if ( $agent_id > 0 ) {
			delete_transient( 'cl_beat_' . $agent_id );
		}
	}

	/**
	 * Whether a sign-in with no sign-out still counts as being on the desk.
	 *
	 * @param string $when MySQL time of the sign-in.
	 * @return bool
	 */
	private function still_live( $when ) {
		$ts = $this->to_ts( $when );
		if ( ! $ts ) {
			return false;
		}
		return ( time() - $ts ) < ( self::LIVE_MINUTES * MINUTE_IN_SECONDS );
	}

	/**
	 * Whether a sign-in has a matching sign-out.
	 *
	 * @param string $in  Sign-in time.
	 * @param string $out Sign-out time.
	 * @return bool
	 */
	private function is_open( $in, $out ) {
		return '' !== $in && '' === $out;
	}

	/**
	 * A MySQL time as a timestamp in this site's own zone.
	 *
	 * @param string $when MySQL datetime.
	 * @return int
	 */
	private function to_ts( $when ) {
		$when = trim( (string) $when );
		if ( '' === $when || '0000-00-00 00:00:00' === $when ) {
			return 0;
		}
		$ts = strtotime( $when );
		// current_time('mysql') is site-local, while strtotime reads a naive
		// string as UTC. The offset puts the two on the same clock.
		return $ts ? $ts - ( (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) : 0;
	}

	/**
	 * How many times each event happened in a window, per person.
	 *
	 * @param int $days Days back.
	 * @return array agent id => array( event => count )
	 */
	public function tally( $days = 7 ) {
		global $wpdb;
		$days = max( 1, (int) $days );
		$from = gmdate( 'Y-m-d 00:00:00', time() - ( $days * DAY_IN_SECONDS ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT agent_id, event, COUNT(*) AS n FROM ' . $this->table() . ' WHERE created_at >= %s GROUP BY agent_id, event', // phpcs:ignore WordPress.DB.PreparedSQL
				$from
			),
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row['agent_id'] ][ (string) $row['event'] ] = (int) $row['n'];
		}
		return $out;
	}

	/**
	 * The log as a shape over time, hour by hour.
	 *
	 * A table says what happened and in what order; it cannot say that the
	 * desk is busiest at eleven and dead after four, or that the refusals
	 * come in a burst at two in the morning. Those are the questions a shift
	 * is planned around, and they are answered by counting, not by reading.
	 *
	 * Hours are the bucket because a desk works in hours. Each row carries
	 * the hour, the total and the split by tone — done, warned, refused — so
	 * a bar can be drawn without a second query per column.
	 *
	 * @param int $hours How far back, in hours.
	 * @return array
	 */
	public function series( $hours = 24 ) {
		global $wpdb;
		$hours = max( 6, min( 168, (int) $hours ) );
		$from  = gmdate( 'Y-m-d H:i:00', time() - ( $hours * HOUR_IN_SECONDS ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT SUBSTR(created_at, 1, 13) AS hr, event, COUNT(*) AS n FROM ' . $this->table()
					. ' WHERE created_at >= %s GROUP BY hr, event ORDER BY hr ASC', // phpcs:ignore WordPress.DB.PreparedSQL
				$from
			),
			ARRAY_A
		);

		// Every hour in the window is present, empty or not. A series with
		// the quiet hours missing draws a chart that lies about its own
		// scale — three bars side by side, each eight hours apart.
		$out = array();
		$t0  = time() - ( $hours * HOUR_IN_SECONDS );
		for ( $i = 0; $i <= $hours; $i++ ) {
			$key         = gmdate( 'Y-m-d H', $t0 + ( $i * HOUR_IN_SECONDS ) );
			$out[ $key ] = array(
				'at'    => (int) strtotime( $key . ':00:00 UTC' ),
				'label' => gmdate( 'H:00', $t0 + ( $i * HOUR_IN_SECONDS ) ),
				'total' => 0,
				'ok'    => 0,
				'warn'  => 0,
				'no'    => 0,
			);
		}

		foreach ( (array) $rows as $row ) {
			$hr = (string) $row['hr'];
			if ( ! isset( $out[ $hr ] ) ) {
				continue;
			}
			$n  = (int) $row['n'];
			// The label table's five tones folded into the three a bar can
			// carry: done, waiting, refused. "info" and "ok" are both work
			// that went through; "bad" is the one worth looking at.
			$map  = array( 'ok' => 'ok', 'info' => 'ok', 'warn' => 'warn', 'bad' => 'no', 'muted' => 'warn' );
			$tone = self::tone_of( (string) $row['event'] );
			$tone = isset( $map[ $tone ] ) ? $map[ $tone ] : 'warn';
			$out[ $hr ]['total'] += $n;
			$out[ $hr ][ $tone ] += $n;
		}

		return array_values( $out );
	}

	/**
	 * Who did the most, and who was refused the most.
	 *
	 * The tally elsewhere answers "how many of each event". This answers the
	 * question that follows it: by whom. Read together they are the two
	 * halves of a shift review — the desk's shape, and the people in it.
	 *
	 * @param int $days Days back.
	 * @param int $max  How many people.
	 * @return array
	 */
	public function leaders( $days = 7, $max = 6 ) {
		global $wpdb;
		$days = max( 1, min( 365, (int) $days ) );
		$max  = max( 1, min( 20, (int) $max ) );
		$from = gmdate( 'Y-m-d 00:00:00', time() - ( $days * DAY_IN_SECONDS ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT agent_id, COUNT(*) AS n FROM ' . $this->table()
					. ' WHERE created_at >= %s GROUP BY agent_id ORDER BY n DESC LIMIT %d', // phpcs:ignore WordPress.DB.PreparedSQL
				$from,
				$max
			),
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$id    = (int) $row['agent_id'];
			$out[] = array(
				'id'   => $id,
				'n'    => (int) $row['n'],
				// The refusals that landed on this person's account, which is
				// the number worth looking at twice: a busy account and one
				// that is being guessed at both appear here, and only one of
				// them is good news.
				'no'   => (int) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT COUNT(*) FROM ' . $this->table()
							. " WHERE agent_id = %d AND created_at >= %s AND event IN ( 'signin_failed', 'code_failed', 'paused_login' )", // phpcs:ignore WordPress.DB.PreparedSQL
						$id,
						$from
					)
				),
			);
		}
		return $out;
	}

	/**
	 * What has stopped.
	 *
	 * The most useful figure on a desk and the one a log never volunteers:
	 * the people who signed in and have not come back, and the accounts
	 * that have not been touched for the window at all. A shift that ends
	 * with somebody still marked "on the desk" is the one an operator wants
	 * to be told about before they go home.
	 *
	 * @return array
	 */
	public function dormant() {
		global $wpdb;
		$from = gmdate( 'Y-m-d 00:00:00', time() - ( 7 * DAY_IN_SECONDS ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT agent_id, MAX(created_at) AS last FROM ' . $this->table()
					. ' WHERE created_at >= %s GROUP BY agent_id', // phpcs:ignore WordPress.DB.PreparedSQL
				$from
			),
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row['agent_id'] ] = (string) $row['last'];
		}
		return $out;
	}

	/**
	 * The tone of one event, as the label table already knows it.
	 *
	 * @param string $event Event key.
	 * @return string ok | warn | no | muted
	 */
	public static function tone_of( $event ) {
		$all = self::events();
		if ( isset( $all[ $event ] ) && isset( $all[ $event ][1] ) ) {
			return (string) $all[ $event ][1];
		}
		return 'muted';
	}

	/**
	 * How many refused attempts landed in the last stretch of hours.
	 *
	 * Three events count as a refusal: a wrong password, a wrong access code
	 * and an attempt on a switched-off account. They are added together
	 * because they answer one question — is somebody guessing at this door —
	 * and a desk that is being tried against rarely uses only one of them.
	 *
	 * @param int $hours Hours back.
	 * @return int
	 */
	public function refusals( $hours = 24 ) {
		global $wpdb;
		$hours = max( 1, (int) $hours );
		$from  = gmdate( 'Y-m-d H:i:s', time() - ( $hours * HOUR_IN_SECONDS ) );

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . $this->table() . " WHERE created_at >= %s AND event IN ( 'signin_failed', 'code_failed', 'paused_login' )", // phpcs:ignore WordPress.DB.PreparedSQL
				$from
			)
		);
	}

	/**
	 * An address as the screen should print it.
	 *
	 * Masking keeps the leading half so two rows can still be told apart and
	 * compared — "same network as that one" is the fact being read — while
	 * what is left is not an address that can be walked to. An IPv4 keeps
	 * three of its four parts; an IPv6 keeps its first two groups and says
	 * how many were dropped, because its parts are not all the same size.
	 *
	 * @param string $ip    Address.
	 * @param string $style full, masked or hidden.
	 * @return string
	 */
	public static function ip_for_display( $ip, $style = 'full' ) {
		$ip = trim( (string) $ip );
		if ( '' === $ip || 'hidden' === $style ) {
			return '';
		}
		if ( 'masked' !== $style ) {
			return $ip;
		}

		if ( false !== strpos( $ip, ':' ) ) {
			$parts = explode( ':', $ip );
			$keep  = array_slice( $parts, 0, 2 );
			return implode( ':', $keep ) . ':…';
		}

		$parts = explode( '.', $ip );
		if ( count( $parts ) < 4 ) {
			return $ip;
		}
		return $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.•';
	}

	/**
	 * Remove rows older than a number of days.
	 *
	 * Called from the daily maintenance job. A log that grows for ever is a
	 * log nobody reads, and the operator set the window in Settings.
	 *
	 * @param int $days Days to keep.
	 * @return int Rows removed.
	 */
	public function prune( $days = 90 ) {
		global $wpdb;
		$days = max( 7, (int) $days );
		$cut  = gmdate( 'Y-m-d 00:00:00', time() - ( $days * DAY_IN_SECONDS ) );
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . $this->table() . ' WHERE created_at < %s', $cut ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Every row for one person, for their own history.
	 *
	 * @param int $agent_id Person.
	 * @param int $max      How many.
	 * @return array
	 */
	public function for_agent( $agent_id, $max = 20 ) {
		return $this->rows(
			array(
				'agent_id' => absint( $agent_id ),
				'max'      => max( 1, (int) $max ),
			)
		);
	}
}
