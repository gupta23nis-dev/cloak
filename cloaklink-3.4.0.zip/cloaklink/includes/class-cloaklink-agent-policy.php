<?php
/**
 * The rules a person on the case desk is held to.
 *
 * The desk used to have exactly one rule: an account that is active can sign
 * in. Everything else — where from, at what hour, how often, how long since
 * the password was changed, whether a session should still be alive — was the
 * operator's memory. This class is that memory, written down.
 *
 * Every rule is optional and off by default, because a control nobody asked
 * for is a control that locks somebody out on a Sunday. What each one does
 * when it is on is written beside it, and every refusal names itself, so an
 * operator reading "out of hours" in the log knows which switch to reach for.
 *
 * Nothing here trusts the browser. A refusal is returned as data, and the
 * caller is the one that decides what to do with it — the sign-in handler
 * stops, the ticket form refuses, and neither one takes the page's word.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Evaluates the desk's policies for one person.
 */
class CloakLink_Agent_Policy {

	/** @var CloakLink_Settings */
	private $settings;

	/** @var CloakLink_DB */
	private $db;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_Settings $settings Settings.
	 * @param CloakLink_DB       $db       Database.
	 */
	public function __construct( $settings, $db ) {
		$this->settings = $settings;
		$this->db       = $db;
	}

	/**
	 * The defaults every policy reads from when a person has no override.
	 *
	 * Kept in one place so the admin screen and the enforcement can never
	 * disagree about what "not set" means.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Off: any active account, from anywhere, at any hour.
			'desk_ip_lock'       => 0,
			'desk_hours_on'      => 0,
			'desk_hours_from'    => '08:00',
			'desk_hours_to'      => '21:00',
			'desk_hours_days'    => '1,2,3,4,5,6,7',
			'desk_quota_on'      => 0,
			'desk_quota_day'     => 25,
			'desk_fail_on'       => 1,
			'desk_fail_max'      => 6,
			'desk_fail_minutes'  => 15,
			'desk_pw_days'       => 0,
			'desk_pause'         => 0,
			'desk_log_days'      => 90,
			'desk_notify_login'  => 0,
		);
	}

	/**
	 * One policy value.
	 *
	 * @param string $key     Key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	private function get( $key, $default = null ) {
		$all = self::defaults();
		$def = isset( $all[ $key ] ) ? $all[ $key ] : $default;
		return $this->settings->get( $key, $def );
	}

	/**
	 * One rule's current value, for a screen that has to draw it.
	 *
	 * The admin panel needs the same fallback the enforcement uses, so a
	 * switch that has never been saved draws the shipped value rather than
	 * an empty one.
	 *
	 * @param string $key Rule key.
	 * @return mixed
	 */
	public function value( $key ) {
		return $this->get( $key );
	}

	/**
	 * Whether the whole desk is paused.
	 *
	 * A single switch for the nights and holidays when nobody should be
	 * raising anything. It refuses new tickets and new sign-ins, and it does
	 * not touch a person already working — taking the page away from somebody
	 * mid-sentence is worse than letting them finish.
	 *
	 * @return bool
	 */
	public function desk_paused() {
		return (bool) $this->get( 'desk_pause', 0 );
	}

	/**
	 * Run every rule that applies to arriving.
	 *
	 * @param array  $agent Agent row.
	 * @param string $ip    Address the request came from.
	 * @param string $event Event key to write when refused.
	 * @return true|WP_Error
	 */
	public function check_signin( $agent, $ip, $event = 'signin_failed' ) {
		if ( $this->desk_paused() ) {
			return new WP_Error( 'desk_paused', __( 'The desk is paused. Ask the operator to open it.', 'cloaklink' ) );
		}

		$hours = $this->check_hours();
		if ( is_wp_error( $hours ) ) {
			return $hours;
		}

		$allowed = $this->check_ip( $agent, $ip );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$throttle = $this->check_throttle( $agent );
		if ( is_wp_error( $throttle ) ) {
			return $throttle;
		}

		return true;
	}

	/**
	 * Whether this is inside the desk's working hours.
	 *
	 * The window is site-local, wraps past midnight, and is only consulted
	 * when the operator turned it on. A person already signed in is not
	 * thrown out at closing time; the rule governs arriving, not working.
	 *
	 * @return true|WP_Error
	 */
	public function check_hours() {
		if ( ! $this->get( 'desk_hours_on', 0 ) ) {
			return true;
		}

		$days = array_filter( array_map( 'absint', explode( ',', (string) $this->get( 'desk_hours_days', '1,2,3,4,5,6,7' ) ) ) );
		$now  = (int) current_time( 'N' ); // 1 = Monday.
		if ( $days && ! in_array( $now, $days, true ) ) {
			return new WP_Error( 'out_of_hours', __( 'The desk is closed today.', 'cloaklink' ) );
		}

		$from = $this->minutes( (string) $this->get( 'desk_hours_from', '08:00' ) );
		$to   = $this->minutes( (string) $this->get( 'desk_hours_to', '21:00' ) );
		$at   = ( (int) current_time( 'G' ) * 60 ) + (int) current_time( 'i' );

		// A window that ends before it starts runs past midnight, so the test
		// is an OR rather than a between.
		$open = $from <= $to ? ( $at >= $from && $at <= $to ) : ( $at >= $from || $at <= $to );

		if ( ! $open ) {
			return new WP_Error( 'out_of_hours', __( 'The desk is closed at this hour.', 'cloaklink' ) );
		}
		return true;
	}

	/**
	 * "08:30" as minutes past midnight.
	 *
	 * @param string $hhmm Time.
	 * @return int
	 */
	private function minutes( $hhmm ) {
		if ( ! preg_match( '/^(\d{1,2}):(\d{2})$/', trim( $hhmm ), $m ) ) {
			return 0;
		}
		return min( 1439, ( (int) $m[1] * 60 ) + (int) $m[2] );
	}

	/**
	 * Whether this person may sign in from this address.
	 *
	 * A person's own list wins when it is set; otherwise the desk-wide switch
	 * applies and any address is accepted. The list takes addresses and CIDR
	 * blocks, because an office is a range and not a single machine.
	 *
	 * @param array  $agent Agent row.
	 * @param string $ip    Address.
	 * @return true|WP_Error
	 */
	public function check_ip( $agent, $ip ) {
		$own = isset( $agent['ip_lock'] ) ? trim( (string) $agent['ip_lock'] ) : '';
		if ( '' === $own ) {
			// No personal list: the desk-wide switch decides. Off means any
			// address, which is the shipped default.
			if ( ! $this->get( 'desk_ip_lock', 0 ) ) {
				return true;
			}
			$own = (string) $this->get( 'ip_lock_list', '' );
			if ( '' === trim( $own ) ) {
				return true;
			}
		}

		$entries = preg_split( '/[\s,]+/', $own );
		foreach ( (array) $entries as $entry ) {
			$entry = trim( (string) $entry );
			if ( '' === $entry ) {
				continue;
			}
			if ( $this->ip_matches( $ip, $entry ) ) {
				return true;
			}
		}

		return new WP_Error( 'ip_refused', __( 'This desk does not open from this network.', 'cloaklink' ) );
	}

	/**
	 * Whether an address falls inside an entry, which may be a CIDR block.
	 *
	 * @param string $ip    Address.
	 * @param string $entry Address or block.
	 * @return bool
	 */
	private function ip_matches( $ip, $entry ) {
		$ip    = trim( (string) $ip );
		$entry = trim( (string) $entry );

		if ( false === strpos( $entry, '/' ) ) {
			return $ip === $entry;
		}

		list( $net, $bits ) = explode( '/', $entry, 2 );
		$bits = (int) $bits;
		$ip_bin  = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$net_bin = @inet_pton( $net ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( false === $ip_bin || false === $net_bin || strlen( $ip_bin ) !== strlen( $net_bin ) ) {
			return false;
		}

		$max = strlen( $ip_bin ) * 8;
		if ( $bits < 0 || $bits > $max ) {
			return false;
		}

		$whole = intdiv( $bits, 8 );
		if ( substr( $ip_bin, 0, $whole ) !== substr( $net_bin, 0, $whole ) ) {
			return false;
		}
		$rest = $bits % 8;
		if ( 0 === $rest ) {
			return true;
		}
		$mask = chr( ( 0xff << ( 8 - $rest ) ) & 0xff );
		return ( $ip_bin[ $whole ] & $mask ) === ( $net_bin[ $whole ] & $mask );
	}

	/**
	 * Whether this person has failed too often, too recently.
	 *
	 * Counted from the activity log rather than a transient, so closing the
	 * browser does not reset it and the operator can see the attempts that
	 * caused it. Only failures in the last N minutes count.
	 *
	 * @param array $agent Agent row.
	 * @return true|WP_Error
	 */
	public function check_throttle( $agent ) {
		if ( ! $this->get( 'desk_fail_on', 1 ) ) {
			return true;
		}

		$max     = max( 1, (int) $this->get( 'desk_fail_max', 6 ) );
		$minutes = max( 1, (int) $this->get( 'desk_fail_minutes', 15 ) );
		global $wpdb;

		$fail = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'cloak_agent_activity'
				. " WHERE agent_id = %d AND event IN ( 'signin_failed', 'code_failed' )"
				. ' AND created_at >= %s',
				absint( $agent['id'] ),
				gmdate( 'Y-m-d H:i:s', time() - ( $minutes * MINUTE_IN_SECONDS ) )
			)
		);

		if ( $fail >= $max ) {
			$this->maybe_mail_failure( $agent, $fail, $minutes );
			return new WP_Error(
				'throttled',
				sprintf(
					/* translators: %d: minutes */
					__( 'Too many failed attempts. Try again in %d minutes.', 'cloaklink' ),
					$minutes
				)
			);
		}
		return true;
	}

	/**
	 * Tell the operator once that somebody is guessing at an account.
	 *
	 * Once per pause window, not per attempt: a mailbox that receives one mail
	 * per wrong password is a mailbox that stops being read, which is the same
	 * as not being told at all. The window key is the account and the minute,
	 * so the pause and the mail expire together.
	 *
	 * @param array $agent   Agent row.
	 * @param int   $fails   Failures counted.
	 * @param int   $minutes Window in minutes.
	 * @return void
	 */
	private function maybe_mail_failure( $agent, $fails, $minutes ) {
		if ( ! function_exists( 'cloaklink' ) || ! cloaklink()->adv || ! cloaklink()->adv->yes( 'mail_on_agent_fail' ) ) {
			return;
		}
		$key = 'cl_deskfail_mail_' . (int) $agent['id'] . '_' . (int) floor( time() / max( 1, $minutes * MINUTE_IN_SECONDS ) );
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, max( 1, $minutes * MINUTE_IN_SECONDS ) );

		$to = (string) $this->settings->get( 'security_alert_email', '' );
		if ( ! is_email( $to ) ) {
			$to = (string) $this->settings->get( 'notify_email', '' );
		}
		if ( ! is_email( $to ) ) {
			return;
		}

		$lines = array(
			__( 'Repeated failures on the case desk.', 'cloaklink' ),
			'',
			sprintf( /* translators: %s: person */ __( 'Account: %s', 'cloaklink' ), (string) $agent['name'] ),
			sprintf( /* translators: %d: failures */ __( 'Failures: %d', 'cloaklink' ), (int) $fails ),
			sprintf( /* translators: %d: minutes */ __( 'Paused for: %d minutes', 'cloaklink' ), (int) $minutes ),
			sprintf( /* translators: %s: address */ __( 'Network: %s', 'cloaklink' ), CloakLink_Geo::ip() ),
			'',
			CloakLink_Admin::url( 'activity' ),
		);

		wp_mail(
			$to,
			cloaklink()->adv->subject( __( 'Case desk: repeated failures', 'cloaklink' ) ),
			implode( "\n", $lines )
		);
	}

	/**
	 * How many tickets this person has raised since midnight.
	 *
	 * @param array $agent Agent row.
	 * @return int
	 */
	public function raised_today( $agent ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'cloak_tickets WHERE agent_id = %d AND created_at >= %s', // phpcs:ignore WordPress.DB.PreparedSQL
				absint( $agent['id'] ),
				gmdate( 'Y-m-d 00:00:00', time() )
			)
		);
	}

	/**
	 * Whether this person may raise another ticket now.
	 *
	 * The quota is per person per day, and the person may be given their own
	 * number in the admin screen. Zero means no limit.
	 *
	 * @param array $agent Agent row.
	 * @return true|WP_Error
	 */
	public function check_quota( $agent ) {
		if ( $this->desk_paused() ) {
			return new WP_Error( 'desk_paused', __( 'The desk is paused.', 'cloaklink' ) );
		}
		if ( ! $this->get( 'desk_quota_on', 0 ) ) {
			return true;
		}

		$cap = isset( $agent['quota'] ) ? absint( $agent['quota'] ) : 0;
		if ( ! $cap ) {
			$cap = (int) $this->get( 'desk_quota_day', 25 );
		}
		if ( ! $cap ) {
			return true;
		}

		if ( $this->raised_today( $agent ) >= $cap ) {
			return new WP_Error( 'quota', __( 'This account has reached its limit of tickets for today.', 'cloaklink' ) );
		}
		return true;
	}

	/**
	 * How old this person's password is, in days.
	 *
	 * Measured from the last change the operator or the person made. A row
	 * that has never recorded a change counts from the account's creation,
	 * which is the same thing on a fresh account.
	 *
	 * @param array $agent Agent row.
	 * @return int
	 */
	public function password_age( $agent ) {
		$when = isset( $agent['pass_changed'] ) && '' !== (string) $agent['pass_changed']
			? (string) $agent['pass_changed']
			: ( isset( $agent['created_at'] ) ? (string) $agent['created_at'] : '' );
		$ts = $when ? strtotime( $when ) : 0;
		if ( ! $ts ) {
			return 0;
		}
		return (int) floor( ( time() - $ts ) / DAY_IN_SECONDS );
	}

	/**
	 * Whether this person must change their password before carrying on.
	 *
	 * @param array $agent Agent row.
	 * @return bool
	 */
	public function password_expired( $agent ) {
		$days = (int) $this->get( 'desk_pw_days', 0 );
		if ( $days < 1 ) {
			return false;
		}
		return $this->password_age( $agent ) >= $days;
	}

	/**
	 * Whether a session issued at this time is still valid.
	 *
	 * Forcing somebody out is done by stamping the account with the moment of
	 * the kill: every cookie issued before it stops being accepted, including
	 * one on a machine the operator cannot see. The cookie itself is
	 * unchanged, so nothing in the browser needs to know.
	 *
	 * @param array $agent Agent row.
	 * @param int   $issued When the cookie was issued (unix time).
	 * @return bool
	 */
	public function session_valid( $agent, $issued ) {
		$cut = isset( $agent['session_cut'] ) ? (string) $agent['session_cut'] : '';
		if ( '' === $cut ) {
			return true;
		}
		$cut_ts = strtotime( $cut );
		if ( ! $cut_ts ) {
			return true;
		}
		// A cookie issued in the same second the cut was made is refused too:
		// the operation is "everyone currently signed in", and that is the
		// person sitting there.
		return (int) $issued > $cut_ts;
	}

	/**
	 * A one-line description of why somebody must act, for the panel.
	 *
	 * @param array $agent Agent row.
	 * @return string
	 */
	public function notice( $agent ) {
		if ( $this->password_expired( $agent ) ) {
			return __( 'Password age limit reached', 'cloaklink' );
		}
		if ( $this->desk_paused() ) {
			return __( 'Desk paused', 'cloaklink' );
		}
		$hours = $this->check_hours();
		if ( is_wp_error( $hours ) ) {
			return $hours->get_error_message();
		}
		return '';
	}
}
