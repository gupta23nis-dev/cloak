<?php
/**
 * Case agents: the people who raise tickets and are shown what their links
 * capture.
 *
 * An agent is not a WordPress user. They never enter wp-admin, they cannot see
 * the operator's links, and they cannot change anything about the plugin. They
 * sign in on their own door, raise a ticket, and are shown the visit data for
 * the link that ticket produced — and only that.
 *
 * Their records live in two tables of their own so that removing an agent, or
 * removing a ticket from the operator's side, is one delete rather than a
 * search through WordPress users, capabilities and post meta.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Agent and ticket storage.
 */
class CloakLink_Agents {

	/**
	 * Cookie that carries an agent's session.
	 */
	const COOKIE = 'cl_agent_session';

	/** Sessions last this long. */
	const SESSION_HOURS = 12;

	/**
	 * Database helper.
	 *
	 * @var CloakLink_DB
	 */
	private $db;

	/**
	 * Settings.
	 *
	 * @var CloakLink_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings store.
	 */
	public function __construct( $db, $settings ) {
		$this->db       = $db;
		$this->settings = $settings;
	}

	/**
	 * Agents table.
	 *
	 * @return string
	 */
	public function table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_agents';
	}

	/**
	 * Tickets table.
	 *
	 * @return string
	 */
	public function tickets_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_tickets';
	}

	/*
	 * ---------------------------------------------------------------------
	 * Addressing
	 * ------------------------------------------------------------------ */

	/**
	 * The path the agent desk answers on.
	 *
	 * A word of its own rather than a page of the operator's panel, so an
	 * agent address can be given out without revealing where the operator
	 * works, and so the two can never be confused. It is settable, because an
	 * address that has been printed on paper is not something a plugin should
	 * decide for good.
	 *
	 * @return string
	 */
	public function path() {
		$slug = sanitize_title( (string) $this->settings->get( 'agent_slug', 'case-desk' ) );
		return '' !== $slug ? $slug : 'case-desk';
	}

	/**
	 * The sign-in address.
	 *
	 * @return string
	 */
	public function url() {
		// The sign-in form posts here, so it has to be an address the server
		// will actually answer. On a site that does not route clean paths
		// that is the query form, not the pretty one.
		if ( CloakLink_Admin::routes_broken() ) {
			return add_query_arg( 'cloaklink_agent', 'login', home_url( '/index.php' ) );
		}
		return home_url( '/' . $this->path() . '/' );
	}

	/**
	 * The address this request actually arrived on.
	 *
	 * The desk's configured addresses are clean paths, and on a host that does
	 * not route clean paths those are 404s. A form must post back to an
	 * address the server has already answered once, so this rebuilds the
	 * current request rather than trusting the setting. It is used for the
	 * sign-in form, where a wrong answer means the password is delivered to a
	 * page that does not exist and the desk looks broken.
	 *
	 * @return string
	 */
	public function served_url() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		// The query is kept, the fragment is not: the fragment never reached
		// the server and must not be posted back as if it had.
		$uri = preg_replace( '/#.*$/', '', $uri );
		if ( '' !== $uri && '/' === substr( $uri, 0, 1 ) ) {
			return esc_url_raw( home_url( $uri ) );
		}
		return $this->url();
	}

	/**
	 * One screen of the agent desk.
	 *
	 * @param string $screen login|panel|ticket.
	 * @param array  $args   Extra query args.
	 * @return string
	 */
	public function screen_url( $screen = 'login', $args = array() ) {
		// A clean path only works where the site routes clean paths. Where it
		// has been measured as not doing so — an nginx front end answering
		// every extension-less address itself — the desk speaks the query
		// form instead, which index.php always answers. Without this the
		// sign-in page loaded and every press on it span forever, because the
		// page was printed under one address and its buttons pointed at
		// another that the server had already decided was missing.
		if ( ! CloakLink_Admin::routes_broken() ) {
			$base = trailingslashit( home_url( '/' . $this->path() ) );
			$base .= 'login' === $screen ? '' : $screen . '/';
			return $args ? add_query_arg( $args, $base ) : $base;
		}

		$base = home_url( '/index.php' );
		$args = array_merge( array( 'cloaklink_agent' => 'login' === $screen ? 'login' : $screen ), (array) $args );
		return add_query_arg( $args, $base );
	}

	/**
	 * Register the two rewrites.
	 *
	 * @return void
	 */
	public function register_rewrites() {
		$path = preg_quote( $this->path(), '#' );
		add_rewrite_rule(
			$path . '/ticket/([0-9]+)/?$',
			'index.php?cloaklink_agent=panel&cloaklink_ticket=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			$path . '/(panel|out|prefs)/?$',
			'index.php?cloaklink_agent=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			$path . '/?$',
			'index.php?cloaklink_agent=login',
			'top'
		);
	}

	/**
	 * The query vars the rewrites write.
	 *
	 * @param array $vars Vars.
	 * @return array
	 */
	public static function query_vars( $vars ) {
		$vars[] = 'cloaklink_agent';
		$vars[] = 'cloaklink_ticket';
		return $vars;
	}

	/**
	 * Answer a request for the agent desk.
	 *
	 * Read from the path as well as the query var, because on a site with
	 * plain permalinks the rewrite never runs and the path is all there is.
	 *
	 * @return void
	 */
	public function handle() {
		$screen = (string) get_query_var( 'cloaklink_agent' );
		if ( '' === $screen ) {
			$screen = $this->screen_from_uri();
		}
		if ( '' === $screen ) {
			return;
		}

		// WordPress has already decided this path does not exist and sent a
		// 404. A desk that answers is not a missing page, so the status is put
		// right before anything is printed.
		global $wp_query;
		if ( ! headers_sent() && is_404() ) {
			status_header( 200 );
			if ( $wp_query instanceof WP_Query ) {
				$wp_query->is_404 = false;
			}
		}

		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Referrer-Policy: no-referrer' );

		$post = isset( $_POST['cl_agent_action'] ) ? sanitize_key( wp_unslash( $_POST['cl_agent_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' !== $post ) {
			$this->handle_post( $post );
			return;
		}

		if ( isset( $_GET['cl_agent_out'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$leaving = $this->current();
			if ( $leaving ) {
				cloaklink()->agent_log->log( (int) $leaving['id'], 'signout' );
				// Offline at once, not thirty minutes from now. The operator's
				// screen should be able to name the person who just left.
				CloakLink_Agent_Log::stop_beat( (int) $leaving['id'] );
			}
			$this->end_session();
			wp_safe_redirect( $this->screen_url( 'login', array( 'cl_ok' => 'out' ) ) );
			exit;
		}

		$agent = $this->current();

		if ( 'out' === $screen ) {
			wp_safe_redirect( $this->url() );
			exit;
		}

		if ( 'login' === $screen && $agent ) {
			wp_safe_redirect( $this->screen_url( 'panel' ) );
			exit;
		}

		if ( ( 'panel' === $screen || 'prefs' === $screen ) && ! $agent ) {
			wp_safe_redirect( $this->url() );
			exit;
		}

		// Where a person lands after signing in. The Advanced screen decides,
		// and the three answers are the three things a desk is for: the queue
		// they work, the captures they watch, and the form they raise.
		//
		// This redirect used to fire on every request, and it targets a
		// fragment — '#cl-deskmix', '#clx-raise'. A fragment is never sent to
		// the server, so the second request arrived looking exactly like the
		// first and was redirected again, and again: an endless loop that
		// never paints the page. Any account whose landing was set to
		// "monitor" or "raise" was locked out of its own desk this way.
		//
		// The marker is the fix. One query argument says "the landing has
		// been done", so this fires once; the fragment still scrolls, which
		// is the only thing it was ever really for.
		$cl_landed = isset( $_GET['cl_at'] ) ? sanitize_key( wp_unslash( $_GET['cl_at'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'panel' === $screen && $agent && ! isset( $_GET['cl_ticket'] ) && 'land' !== $cl_landed ) { // phpcs:ignore WordPress.Security.NonceVerification
			$land  = $this->landing( (int) $agent['id'] );
			$jump  = '';
			if ( 'ticket' === $land ) {
				$jump = '#clx-raise';
			} elseif ( 'monitor' === $land ) {
				$jump = '#cl-deskmix';
			}
			if ( '' !== $jump ) {
				wp_safe_redirect( add_query_arg( 'cl_at', 'land', $this->screen_url( 'panel' ) ) . $jump );
				exit;
			}
		}

		$this->render( 'login' === $screen ? 'login' : ( 'prefs' === $screen ? 'prefs' : 'panel' ), $agent );
		exit;
	}

	/**
	 * Answer one of the desk's three forms.
	 *
	 * Every one of them is a plain POST to the desk's own address, answered
	 * with a redirect rather than a rendered page: pressing the back button
	 * then cannot re-submit a sign-in or re-raise a ticket.
	 *
	 * @param string $what signin|raise|delete.
	 * @return void
	 */
	private function handle_post( $what ) {
		// A desk form carries its own nonce, and a request without one is
		// dropped rather than answered — an agent session is 12 hours long and
		// a forged POST from another site would otherwise be able to raise
		// tickets, and links, in the agent's name.
		$nonce = isset( $_POST['_cl'] ) ? sanitize_text_field( wp_unslash( $_POST['_cl'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'cloaklink_agent' ) ) {
			wp_safe_redirect( $this->screen_url( 'login', array( 'cl_err' => 'empty' ) ) );
			exit;
		}

		if ( 'signin' === $what ) {
			$user  = isset( $_POST['cl_user'] ) ? sanitize_user( (string) wp_unslash( $_POST['cl_user'] ), true ) : '';
			$pass  = isset( $_POST['cl_pass'] ) ? (string) wp_unslash( $_POST['cl_pass'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$code  = isset( $_POST['cl_code'] ) ? (string) wp_unslash( $_POST['cl_code'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

			if ( '' === $user || '' === $pass ) {
				wp_safe_redirect( $this->screen_url( 'login', array( 'cl_err' => 'empty' ) ) );
				exit;
			}

			$agent = $this->authenticate( $user, $pass, $code );
			if ( is_wp_error( $agent ) ) {
				// A refused sign-in is worth a row. The account is named only
				// when it exists: a wrong username produces a row with person
				// 0 and the typed name in the detail, which is what lets an
				// operator see somebody trying names that are not real.
				$who = $this->by_username( $user );
				$row = array(
					'bad_code' === $agent->get_error_code() ? 'code_failed' : 'signin_failed',
					'paused' === $agent->get_error_code() ? 'paused_login' : ( 'bad_code' === $agent->get_error_code() ? 'code_failed' : 'signin_failed' ),
				);
				cloaklink()->agent_log->log(
					$who ? (int) $who['id'] : 0,
					$row[1],
					array( 'detail' => $who ? (string) $who['username'] : mb_substr( (string) $user, 0, 60 ) )
				);
				wp_safe_redirect( $this->screen_url( 'login', array( 'cl_err' => $agent->get_error_code() ) ) );
				exit;
			}
			// Every rule that governs arriving, in one place: the desk
			// pause, the working hours, this person's own network list and
			// the failure throttle. A refusal names itself so the operator
			// reading the log knows which switch to reach for.
			$policy = cloaklink()->agent_policy->check_signin( $agent, CloakLink_Geo::ip() );
			if ( is_wp_error( $policy ) ) {
				cloaklink()->agent_log->log( (int) $agent['id'], 'signin_failed', array( 'detail' => $policy->get_error_code() ) );
				wp_safe_redirect( $this->screen_url( 'login', array( 'cl_err' => 'refused', 'cl_why' => $policy->get_error_code() ) ) );
				exit;
			}

			$this->start_session( $agent );
			wp_safe_redirect( $this->screen_url( 'panel' ) );
			exit;
		}

		$agent = $this->current();
		if ( ! $agent ) {
			wp_safe_redirect( $this->url() );
			exit;
		}

		if ( 'profile' === $what ) {
			// A table write needs the database handle; this method does not
			// otherwise touch it, so it has to be brought into scope here.
			// Without it the name was never written and the request still
			// looked like a success.
			global $wpdb;

			// Their own name, picture, password and code.
			//
			// Every one of these used to be the operator's alone, which meant
			// a person could not correct their own name or reset a password
			// they had forgotten without asking somebody else to do it. The
			// username stays fixed: it is the handle the log records, and
			// rewriting it would rewrite the record.
			$id      = (int) $agent['id'];
			$name    = isset( $_POST['cl_name'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_name'] ) ) : '';
			$pass    = isset( $_POST['cl_pass'] ) ? (string) wp_unslash( $_POST['cl_pass'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$pass2   = isset( $_POST['cl_pass2'] ) ? (string) wp_unslash( $_POST['cl_pass2'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$code    = isset( $_POST['cl_code'] ) ? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cl_code'] ) ) : '';
			$clear   = ! empty( $_POST['cl_photo_clear'] );
			$changed = array();

			if ( '' !== $pass && ( strlen( $pass ) < 8 || $pass !== $pass2 ) ) {
				wp_safe_redirect( $this->screen_url( 'prefs', array( 'cl_ok' => 'me_badpass' ) ) . '#clx-me' );
				exit;
			}

			if ( '' !== $name ) {
				$wpdb->update( $this->table(), array( 'name' => $name ), array( 'id' => $id ) );
				$changed[] = 'name';
			}

			if ( '' !== $pass || '' !== $code ) {
				$this->update_credentials(
					$id,
					array(
						'password' => $pass,
						'code'     => '' !== $code ? $code : null,
					)
				);
				if ( '' !== $pass ) {
					$changed[] = 'password';
				}
				if ( '' !== $code ) {
					$changed[] = 'access code';
				}
			}

			// A picture. It is filed in the media library under this person's
			// own name and then pointed at by the agent row, which is how the
			// operator's own upload already works — one kind of image, one
			// place it lives.
			$photo_err = false;
			if ( ! empty( $_FILES['cl_photo'] ) && ! empty( $_FILES['cl_photo']['tmp_name'] ) && UPLOAD_ERR_NO_FILE !== (int) $_FILES['cl_photo']['error'] ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$file = $_FILES['cl_photo']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$type = isset( $file['type'] ) ? (string) $file['type'] : '';
				$size = isset( $file['size'] ) ? (int) $file['size'] : 0;
				$oktypes = array( 'image/jpeg', 'image/png', 'image/webp' );
				if ( ! in_array( $type, $oktypes, true ) || $size > 4 * MB_IN_BYTES ) {
					$photo_err = true;
				} else {
					require_once ABSPATH . 'wp-admin/includes/file.php';
					require_once ABSPATH . 'wp-admin/includes/image.php';
					require_once ABSPATH . 'wp-admin/includes/media.php';
					$up = wp_handle_upload( $file, array( 'test_form' => false ) );
					if ( empty( $up['file'] ) ) {
						$photo_err = true;
					} else {
						$att = wp_insert_attachment(
							array(
								'post_mime_type' => $up['type'],
								'post_title'     => $name !== '' ? $name : (string) $agent['name'],
								'post_status'    => 'inherit',
							),
							$up['file']
						);
						if ( $att ) {
							wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $up['file'] ) );
							$this->set_avatar( $id, (int) $att );
							$changed[] = 'picture';
						} else {
							$photo_err = true;
						}
					}
				}
			} elseif ( $clear ) {
				$this->set_avatar( $id, 0 );
				$changed[] = 'picture removed';
			}

			if ( $photo_err ) {
				wp_safe_redirect( $this->screen_url( 'prefs', array( 'cl_ok' => 'me_badphoto' ) ) . '#clx-me' );
				exit;
			}

			// The log says what this person changed about themselves. An
			// operator reading the activity log still sees the change; the
			// difference is who had to make it.
			if ( $changed ) {
				cloaklink()->agent_log->log(
					$id,
					'self_edit',
					array( 'detail' => implode( ', ', $changed ) )
				);
			}

			wp_safe_redirect( $this->screen_url( 'prefs', array( 'cl_ok' => 'me_saved' ) ) . '#clx-me' );
			exit;
		}

		if ( 'prefs' === $what ) {
			// One person's own desk preferences. They are saved under their own
			// id, so a change on one phone never moves another person's screen.
			$agent = $this->current();
			if ( $agent ) {
				cloaklink()->adv->save_prefs( (int) $agent['id'], $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
			}
			wp_safe_redirect( $this->screen_url( 'prefs', array( 'cl_ok' => 'saved' ) ) );
			exit;
		}

		if ( 'raise' === $what ) {
			$in = array(
				'name'  => isset( $_POST['cl_name'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_name'] ) ) : '',
				'phone' => isset( $_POST['cl_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_phone'] ) ) : '',
				'note'  => isset( $_POST['cl_note'] ) ? sanitize_text_field( wp_unslash( $_POST['cl_note'] ) ) : '',
			);

			// The daily quota and the desk pause are checked before anything
			// is written, so a refused raise leaves no half-made ticket.
			$quota = cloaklink()->agent_policy->check_quota( $agent );
			if ( is_wp_error( $quota ) ) {
				wp_safe_redirect( $this->screen_url( 'panel', array( 'cl_err' => $quota->get_error_code() ) ) );
				exit;
			}
			$ticket = $this->create_ticket( $agent, $in );
			if ( is_wp_error( $ticket ) ) {
				$cl_why = $ticket->get_error_code();
				wp_safe_redirect(
					$this->screen_url(
						'panel',
						array( 'cl_err' => in_array( $cl_why, array( 'phone', 'note_short', 'name' ), true ) ? $cl_why : 'link_failed' )
					)
				);
				exit;
			}
			cloaklink()->agent_log->log( (int) $agent['id'], 'ticket_raised', array( 'subject' => (int) $ticket['id'], 'detail' => (string) $ticket['ref'] . ' · ' . (string) $ticket['person'] ) );
			// The ledger's first row for this ticket, and the only one that
			// carries what the ticket said. Everything after this is a change
			// to it; a removal is the end of the ticket, not of the record.
			if ( cloaklink()->ticket_log ) {
				cloaklink()->ticket_log->raised( $ticket, 'agent', (int) $agent['id'], (string) $agent['name'] );
			}
			wp_safe_redirect( $this->screen_url( 'panel', array( 'cl_ok' => 'raised', 'cl_ticket' => (int) $ticket['id'] ) ) );
			exit;
		}

		// Nobody on this desk may allow a ticket and make its link.
		//
		// That is the operator's decision and nobody else's: the whole point
		// of a ticket is that it waits for the office. A desk "admin" is
		// somebody trusted with the queue's shape — they may hold a case that
		// should not go out — but the button that turns a case into a working
		// link belongs to the console behind wp-admin, not to this door.
		//
		// This used to be `is_admin( $agent )`, which meant an agent granted
		// the admin role could release their own link and start reading what
		// it captured, with nobody at the office ever having said yes.
		//
		// A named constant rather than deleting the variable: the branches
		// below read it, and keeping it visible is what stops the next change
		// quietly reintroducing a role check here.
		$is_admin = false;

		if ( 'clear_many' === $what ) {
			// A selection, removed from this person's own monitoring view.
			//
			// Same rule as the single ✕, applied to a set: the rows stay in the
			// operator's record and in Visits, and nothing on the link is
			// deleted. The desk is a reading of the evidence, not the evidence.
			$ids = isset( $_POST['cl_visit'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['cl_visit'] ) ) : array();
			$ids = array_values( array_filter( array_unique( $ids ) ) );

			$done = 0;
			$kept = array();
			foreach ( $ids as $one ) {
				// Every id is checked against this person's own set, so a formed
				// request cannot hide somebody else's record.
				$row = $this->db->get_visit( $one );
				if ( ! $row ) {
					continue;
				}
				$mine = false;
				// Only this person's own tickets. A desk-admin used to be
				// handed the whole queue here, which let them clear records
				// off a case somebody else raised.
				foreach ( $this->tickets_for( (int) $agent['id'], false ) as $t ) {
					if ( (int) $t['link_id'] === (int) $row['link_id'] && $this->is_allowed( $t ) ) {
						$mine = true;
						break;
					}
				}
				if ( $mine ) {
					$kept[] = $one;
					$done++;
				}
			}

			if ( $kept ) {
				cloaklink()->adv->set_hidden( (int) $agent['id'], $kept, true );
				cloaklink()->agent_log->log(
					(int) $agent['id'],
					'record_cleared',
					array( 'detail' => sprintf( /* translators: %d: how many records */ _n( '%d record', '%d records', $done, 'cloaklink' ), $done ) )
				);
			}

			wp_safe_redirect(
				$this->screen_url(
					'panel',
					array( 'cl_ok' => $done ? 'cleared_many' : 'not_cleared' )
				) . '#cl-deskmix'
			);
			exit;
		}

		if ( 'delete_records' === $what ) {
			// Deleting from the record itself.
			//
			// The ✕ on a monitoring row puts a row away for this desk; this is
			// the other thing, and it is the only one that destroys anything.
			// It exists because "All records" is the file, and a file that
			// cannot be pruned of a run of the agent's own test clicks is not a
			// file, it is a log that only ever grows.
			//
			// Scoped exactly as hard as reading is: a row is deleted only if it
			// sits on a ticket THIS person raised and the office released. A
			// formed request gets the same answer as a button, because the
			// ownership test is here and not in the template.
			$ids = isset( $_POST['cl_visit'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['cl_visit'] ) ) : array();
			$ids = array_values( array_filter( array_unique( $ids ) ) );

			$mine_links = array();
			foreach ( $this->tickets_for( (int) $agent['id'], false ) as $t ) {
				if ( $this->is_allowed( $t ) && ! empty( $t['link_id'] ) ) {
					$mine_links[ (int) $t['link_id'] ] = true;
				}
			}

			$done = 0;
			foreach ( $ids as $one ) {
				$row = $this->db->get_visit( $one );
				if ( ! $row || ! isset( $mine_links[ (int) $row['link_id'] ] ) ) {
					continue;
				}
				// Everywhere, not just here. The photographs, the recording
				// and the voice note a visitor left live in a session beside
				// the visit row; deleting the row alone left the files on the
				// disk with nothing on the site naming them, so the record
				// was gone from the desk and still on the server.
				cloaklink()->support->delete_visitor(
					(int) $row['link_id'],
					isset( $row['ip_hash'] ) ? (string) $row['ip_hash'] : '',
					isset( $row['slug'] ) ? (string) $row['slug'] : ''
				);
				if ( $this->db->delete_visit( $one ) ) {
					$done++;
				}
			}

			if ( $done ) {
				cloaklink()->agent_log->log(
					(int) $agent['id'],
					'record_deleted',
					array( 'detail' => sprintf( /* translators: %d: how many records */ _n( '%d record deleted', '%d records deleted', $done, 'cloaklink' ), $done ) )
				);
			}

			wp_safe_redirect(
				$this->screen_url(
					'panel',
					array( 'cl_ok' => $done ? 'deleted_many' : 'not_deleted' )
				) . '#cl-agent-shared'
			);
			exit;
		}

		if ( 'delete_tickets' === $what ) {
			// The All tickets list, in bulk.
			//
			// A ticket is a case, and its link is what the visitor opened; both
			// go, and with the link its records and its captured files. That is
			// why this list was not offered before: it is the one action on the
			// desk that cannot be undone. It is offered now because a desk with
			// forty test cases in it cannot be read, and every entry is checked
			// against this person's own tickets first.
			$ids = isset( $_POST['cl_ticket_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['cl_ticket_ids'] ) ) : array();
			$ids = array_values( array_filter( array_unique( $ids ) ) );

			$done = 0;
			foreach ( $ids as $one ) {
				$gone   = $this->get_ticket( $one );
				$really = $this->delete_ticket( $one, (int) $agent['id'] );
				if ( ! $really || ! $gone ) {
					continue;
				}
				$done++;
				cloaklink()->agent_log->log(
					(int) $agent['id'],
					'ticket_deleted',
					array( 'subject' => (int) $one, 'detail' => (string) $gone['ref'] )
				);
				if ( cloaklink()->ticket_log ) {
					cloaklink()->ticket_log->write(
						$gone,
						array(
							'event'      => 'removed',
							'actor_kind' => 'agent',
							'actor_id'   => (int) $agent['id'],
							'actor_name' => (string) $agent['name'],
						)
					);
				}
			}

			wp_safe_redirect(
				$this->screen_url(
					'panel',
					array( 'cl_ok' => $done ? 'deleted' : 'not_deleted' )
				) . '#cl-agent-tickets'
			);
			exit;
		}

		if ( 'clear_record' === $what ) {
			// Removing a record from the desk's monitoring view. It is the
			// operator's own "remove" action, offered here because the person
			// who raised the ticket is the one who knows a capture was their
			// own test. The permission rule lives in clear_record(), not in
			// this branch: a formed request gets the same answer as a button.
			$id  = isset( $_POST['cl_visit'] ) ? absint( $_POST['cl_visit'] ) : 0;
			$ok  = $this->clear_record( $agent, $id );
			if ( $ok ) {
				cloaklink()->agent_log->log( (int) $agent['id'], 'record_cleared', array( 'subject' => $id ) );
			}
			$ref = isset( $_POST['cl_back'] ) ? absint( $_POST['cl_back'] ) : 0;
			wp_safe_redirect(
				$this->screen_url(
					'panel',
					array_filter(
						array(
							'cl_ticket' => $ref,
							'cl_ok'     => $ok ? 'cleared' : 'not_cleared',
						)
					)
				) . '#cl-deskmix'
			);
			exit;
		}

		if ( 'delete' === $what ) {
			$id = isset( $_POST['cl_ticket'] ) ? absint( $_POST['cl_ticket'] ) : 0;
			// Always scoped to this person, so a formed request cannot
			// delete somebody else's ticket. This used to pass null for a
			// desk-admin, which let them remove any case on the desk.
			$gone   = $this->get_ticket( $id );
			$really = $this->delete_ticket( $id, (int) $agent['id'] );
			if ( $really ) {
				cloaklink()->agent_log->log(
					(int) $agent['id'],
					'ticket_deleted',
					array( 'subject' => $id, 'detail' => $gone ? (string) $gone['ref'] : '' )
				);
				// Written before the row is gone from the screen and after it
				// is gone from the table: this is the only place the removal is
				// still answerable afterwards, so it names the person who
				// pressed it and the ticket as it read at the time.
				if ( $gone && cloaklink()->ticket_log ) {
					cloaklink()->ticket_log->write(
						$gone,
						array(
							'event'      => 'removed',
							'actor_kind' => 'agent',
							'actor_id'   => (int) $agent['id'],
							'actor_name' => (string) $agent['name'],
						)
					);
				}
			}
			// Told truthfully. A removal that the ownership check refused — or
			// that the database would not carry out — used to answer "deleted",
			// so the person pressed Remove, saw a success message, and found
			// the ticket still there on the next load.
			wp_safe_redirect(
				$this->screen_url(
					'panel',
					$really
						? array( 'cl_ok' => 'deleted' )
						: array( 'cl_err' => 'not_deleted' )
				)
			);
			exit;
		}

		// "Allow" is refused outright, and says so.
		//
		// Silently redirecting made the failed attempt look like a page that
		// simply did not change, which invites trying again. A message that
		// names the rule is honest and ends the attempt.
		if ( 'allow' === $what ) {
			wp_safe_redirect( $this->screen_url( 'panel', array( 'cl_err' => 'not_allowed' ) ) );
			exit;
		}

		if ( 'hold' === $what ) {
			// Holding withholds a ticket; it never releases one. It is offered
			// to nobody on this desk now — the operator's console holds and
			// releases — but the branch stays so a request that arrives here
			// is answered the same way for everybody rather than falling
			// through to silence.
			wp_safe_redirect( $this->screen_url( 'panel', array( 'cl_err' => 'not_allowed' ) ) );
			exit;
		}

		wp_safe_redirect( $this->screen_url( 'panel' ) );
		exit;
	}

	/**
	 * Send a captured file to the agent who is allowed to see it.
	 *
	 * Captured media is stored in a private folder and never has a public
	 * address — the operator's own panel streams it through a handler that
	 * checks a WordPress capability. An agent has no WordPress user, so that
	 * handler can never serve them. This is the same stream, with the same
	 * checks, made to answer a different question first: does the file belong
	 * to a link whose ticket is allowed, and is that ticket this agent's?
	 *
	 * Everything else — the range request, the content type, the file name —
	 * is delegated to the operator's handler, so a video still scrubs and a
	 * photo is still served as an image, and there is one implementation of
	 * "send a captured file" rather than two that can drift apart.
	 *
	 * @return void Never returns.
	 */
	/**
	 * Answer a media request, if this request is one.
	 *
	 * @return void
	 */
	public function maybe_serve_media() {
		if ( empty( $_GET['cl_agent_media'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'cloaklink_agent_media' ) ) {
			wp_die( esc_html__( 'That file is not available.', 'cloaklink' ), 403 );
		}
		$this->serve_media();
	}

	public function serve_media() {
		$agent = $this->current();
		if ( ! $agent ) {
			wp_die( esc_html__( 'Sign in to see this.', 'cloaklink' ), 403 );
		}

		// The flag in the address says "this is a media request"; the two ids
		// that identify the file are `session` and `ticket`.
		$session = isset( $_GET['session'] ) ? absint( $_GET['session'] ) : 0;
		$ticket  = isset( $_GET['ticket'] ) ? absint( $_GET['ticket'] ) : 0;
		if ( ! $session || ! $ticket ) {
			wp_die( esc_html__( 'That file is not available.', 'cloaklink' ), 404 );
		}

		// The ticket must be this person's to read, and allowed. Both facts are
		// read from the database on this request, not from the address, so a
		// changed id there reaches nothing. An admin-role person on the desk
		// may open any ticket's file — that is the whole of their extra reach,
		// and it stops at the files.
		// Owner only. An admin-role person on the desk may work the queue but
		// may not open another person's recording: the file is the one thing
		// on this desk that cannot be taken back once it has been seen.
		$row = $this->get_ticket( $ticket );
		if ( ! $this->may_read( $row, $agent ) || ! $this->is_allowed( $row ) ) {
			wp_die( esc_html__( 'That file is not available.', 'cloaklink' ), 404 );
		}

		$support     = cloaklink()->support;
		$session_row = $support->get( $session );
		// The session must belong to the link this ticket made. Without this a
		// ticket id from one case would fetch a recording from another.
		if ( ! $session_row || (int) $session_row['link_id'] !== (int) $row['link_id'] ) {
			wp_die( esc_html__( 'That file is not available.', 'cloaklink' ), 404 );
		}

		$which = isset( $_GET['file'] ) ? sanitize_key( wp_unslash( $_GET['file'] ) ) : '';

		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );

		$support->stream_media(
			$session_row,
			$which,
			isset( $_GET['n'] ) ? absint( $_GET['n'] ) : 0,
			! empty( $_GET['dl'] )
		);
	}

	/**
	 * The signed address of one captured file.
	 *
	 * @param int    $session Support session id.
	 * @param int    $ticket  Ticket id.
	 * @param string $which   audio|video|photo.
	 * @param int    $index   Photo index.
	 * @return string
	 */
	public function media_url( $session, $ticket, $which, $index = 0 ) {
		$args = array(
			'cl_agent_media' => 1,
			'session'        => (int) $session,
			'ticket'         => (int) $ticket,
			'file'           => (string) $which,
		);
		if ( 'photo' === $which ) {
			$args['n'] = (int) $index;
		}
		return wp_nonce_url( add_query_arg( $args, $this->screen_url( 'panel' ) ), 'cloaklink_agent_media' );
	}

	/**
	 * The agent panel asking what has arrived since it last looked.
	 *
	 * Deliberately nopriv: an agent is not a WordPress user, so there is no
	 * logged-in state to check. The signed cookie is the whole of the
	 * authorisation, and it is verified here; without it the answer is empty
	 * rather than an error, because a signed-out tab polling on a stale page
	 * is not a fault worth a message.
	 *
	 * @return void Never returns.
	 */
	public function ajax_feed() {
		$agent = $this->current();
		if ( ! $agent ) {
			wp_send_json_success( array( 'fresh' => array(), 'top' => 0, 'signed_out' => true ) );
		}

		// The poll is also a heartbeat: it runs only while the panel is open,
		// so it is the one honest answer to "is this desk being worked right
		// now". Four minutes of silence and the desk reads Offline.
		CloakLink_Agent_Log::beat( (int) $agent['id'] );

		$scene = isset( $_POST['since'] ) ? absint( $_POST['since'] ) : 0;
		$out   = $this->arrivals_for( (int) $agent['id'], $scene );

		// A ticket of theirs that the office has just allowed. It is the one
		// message an agent actually waits for: "your case is open, the link
		// exists, records will come". It rides the same poll as the visitor
		// arrivals, so it costs no extra request, and it is announced before
		// any record can be — an allowance is the cause and a record is the
		// consequence.
		$seen_allow = isset( $_POST['allow_since'] ) ? (string) wp_unslash( $_POST['allow_since'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$out['allowed'] = $this->allowed_since( (int) $agent['id'], sanitize_text_field( $seen_allow ) );
		// The baseline is the same kind of value the browser sends back, so
		// the compare and the marker cannot be two different things. A first
		// call hands back the newest ledger id on this person's allowed
		// tickets, which places the marker at the present without announcing
		// the day.
		$out['allowStamp'] = $out['allowed']
			? (string) $out['allowed'][0]['mark']
			: $this->allowed_mark( (int) $agent['id'] );
		$out['sound']       = (string) $this->settings->alert_sound_url();
		// The allowance has a voice of its own: three rising notes, drawn in
		// the browser, so it cannot be mistaken for a visitor capture and
		// needs no file to exist.
		$out['allowSound']  = '';
		wp_send_json_success( $out );
	}

	/**
	 * Tickets of this agent's that were allowed after a moment.
	 *
	 * The agent's panel could tell them a record had arrived, but not that the
	 * office had said yes — and yes is the thing they wait for, because until
	 * it comes there is nothing to watch. The comparison is on the ticket's
	 * own row rather than a per-agent marker, so a second agent, a reloaded
	 * tab or a panel opened an hour later all read the same answer.
	 *
	 * @param int    $agent_id Agent id.
	 * @param string $since    ISO moment the browser last saw, or ''.
	 * @return array
	 */
	public function allowed_since( $agent_id, $since = '' ) {
		global $wpdb;
		$table = $this->tickets_table();

		// Allowed tickets have a link; a ticket that was allowed and then held
		// back has one too, so the filter is the status, not the column.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, ref, person, phone, note, link_id, created_at FROM {$table} WHERE agent_id = %d AND status = 'allowed' ORDER BY id DESC LIMIT 15", // phpcs:ignore WordPress.DB.PreparedSQL
				absint( $agent_id )
			),
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();
		if ( ! $rows ) {
			return array();
		}

		// The moment of the decision, as a monotonic number.
		//
		// This used to compare the link's created_at against the last wall
		// clock the browser had seen, with a `<=` — and that is exactly the
		// case it got wrong. A ticket is allowed by one request: the link is
		// inserted and the ledger row written inside the same second, and the
		// browser's marker came from the previous poll. When the desk sat on a
		// screen opened ten minutes ago the compare worked; when the allow
		// landed in the same second as the marker it was skipped, and the agent
		// was never told their link had gone live. From their side that is
		// "after allow there is no real-time data" — the link works, records
		// arrive, and the desk keeps saying nothing.
		//
		// The ledger row is the answer. Its id only ever goes up, it is
		// written once per decision, and it is written by the same request
		// that sets the status. Two allows in one second are two ids, so
		// neither can hide behind the other.
		$ledger = $wpdb->prefix . 'cloak_ticket_log';
		$marks  = array();
		$stamps = array();
		$ids    = array();
		foreach ( $rows as $row ) {
			$ids[]                          = (int) $row['id'];
			$marks[ (int) $row['id'] ]     = 0;
			$stamps[ (int) $row['id'] ]    = (string) $row['created_at'];
		}

		$in = implode( ',', array_map( 'absint', $ids ) );
		$found = $wpdb->get_results(
			"SELECT id, ticket_id, event, created_at FROM {$ledger} WHERE ticket_id IN ({$in}) AND event = 'allowed' ORDER BY id ASC", // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		foreach ( (array) $found as $l ) {
			$tid = (int) $l['ticket_id'];
			$marks[ $tid ]  = max( (int) $marks[ $tid ], (int) $l['id'] );
			$stamps[ $tid ] = (string) $l['created_at'];
		}

		// No ledger row yet — an older install whose allow predates the
		// ledger — falls back to the link's own creation time, which is the
		// same moment to the minute.
		$link_ids = array();
		foreach ( $rows as $row ) {
			if ( ! empty( $row['link_id'] ) ) {
				$link_ids[] = (int) $row['link_id'];
			}
		}
		$links = array();
		if ( $link_ids ) {
			$in    = implode( ',', $link_ids );
			$found = $wpdb->get_results( 'SELECT id, created_at FROM ' . $this->db->links_table() . " WHERE id IN ({$in})", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
			foreach ( (array) $found as $l ) {
				$links[ (int) $l['id'] ] = (string) $l['created_at'];
			}
		}

		// The marker is the ledger id when there is one, and a timestamp
		// string when there is not. They never mix: a browser that has sent a
		// number keeps sending numbers, because `since` comes back from what
		// this method last returned.
		$since_n = absint( $since );

		$out = array();
		foreach ( $rows as $row ) {
			$tid = (int) $row['id'];
			$at  = isset( $links[ (int) $row['link_id'] ] ) ? $links[ (int) $row['link_id'] ] : (string) $row['created_at'];
			if ( isset( $stamps[ $tid ] ) && '' !== (string) $stamps[ $tid ] ) {
				$at = (string) $stamps[ $tid ];
			}
			$mark = (int) $marks[ $tid ];
			if ( $mark > 0 ) {
				if ( $since_n > 0 && $mark <= $since_n ) {
					continue;
				}
			} elseif ( '' !== $since && $since_n < 1 && strcmp( $at, $since ) <= 0 ) {
				continue;
			}
			$out[] = array(
				'id'     => $tid,
				'ref'    => (string) $row['ref'],
				'who'    => '' !== (string) $row['person'] ? (string) $row['person'] : __( 'A visitor', 'cloaklink' ),
				'note'   => (string) $row['note'],
				'at'     => CloakLink_Admin::stamp( $at, 'g:i A' ),
				'at_raw' => $at,
				'mark'   => $mark > 0 ? (string) $mark : $at,
			);
		}

		// Newest allowance first, so the browser's marker — which is read from
		// the first row — is always the most recent moment, never an older one
		// that would keep re-announcing the same ticket. Ledger ids sort above
		// timestamps numerically as well as lexically, and the two never mix
		// inside one answer: every row with a ledger row carries a number.
		usort(
			$out,
			static function ( $a, $b ) {
				$an = (int) $a['mark'];
				$bn = (int) $b['mark'];
				if ( $an && $bn ) {
					return $bn <=> $an;
				}
				return strcmp( (string) $b['at_raw'], (string) $a['at_raw'] );
			}
		);

		return $out;
	}

	/**
	 * The highest allowance ledger id for one person's tickets.
	 *
	 * A panel that has just opened asks with no marker and must be placed at
	 * the present rather than handed every allowance it ever had. This reads
	 * the newest ledger row on the tickets this agent owns, which is exactly
	 * the number the next poll compares against — and zero when nothing has
	 * ever been allowed here, which the browser reads as "never seen".
	 *
	 * @param int $agent_id Agent id.
	 * @return string
	 */
	public function allowed_mark( $agent_id ) {
		global $wpdb;
		$ledger = $wpdb->prefix . 'cloak_ticket_log';
		$table  = $this->tickets_table();
		$id     = (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL -- table names are built from $wpdb->prefix.
				"SELECT MAX(l.id) FROM {$ledger} l INNER JOIN {$table} t ON t.id = l.ticket_id WHERE t.agent_id = %d AND l.event = 'allowed'",
				absint( $agent_id )
			)
		);
		return $id > 0 ? (string) $id : '';
	}

	/**
	 * Open the desk again after it locked itself.
	 *
	 * Same idea as the operator's own idle lock: an agent session is twelve
	 * hours long, and a panel left open on a desk in an office should not stay
	 * readable by whoever walks past it. The answer is checked here and never
	 * in the browser — the page is told only whether it was right.
	 *
	 * Five wrong answers from one address cost a quarter of an hour, counted
	 * in a transient so a new tab does not reset the count.
	 *
	 * @return void
	 */
	public function ajax_unlock() {
		$agent = $this->current();
		if ( ! $agent ) {
			wp_send_json_error( array( 'message' => 'signed_out' ), 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'cloaklink_agent_unlock' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}

		$key  = 'cl_agent_unlock_' . md5( (string) $agent['id'] . '|' . CloakLink_Geo::ip() );
		$fail = (int) get_transient( $key );
		if ( $fail >= 5 ) {
			wp_send_json_error( array( 'message' => 'wait' ), 429 );
		}

		$given  = isset( $_POST['code'] ) ? trim( (string) wp_unslash( $_POST['code'] ) ) : '';
		$stored = (string) $agent['code_hash'];
		$good   = false;

		if ( '' !== $stored ) {
			// The code, exactly as typed: stripping non-digits here would let
			// "ab12cd34" pass as "1234".
			$digits = preg_replace( '/\D/', '', $given );
			if ( '' !== $digits && $digits === $given ) {
				$good = wp_check_password( $digits, $stored );
			}
		} else {
			// An account with no access code unlocks on its own password.
			//
			// Without this the lock was a trap rather than a lock: an account
			// that had never been given a code could not open its own screen
			// again, and the only way back in was to sign out and in. The
			// password is already the credential this person proved at the
			// door, so asking for it again covers the screen without inventing
			// a second secret they were never issued.
			$good = '' !== $given && wp_check_password( $given, (string) $agent['pass_hash'] );
		}

		if ( ! $good ) {
			set_transient( $key, $fail + 1, 15 * MINUTE_IN_SECONDS );
			wp_send_json_error( array( 'message' => 'refused' ), 403 );
		}

		delete_transient( $key );
		cloaklink()->agent_log->log( (int) $agent['id'], 'unlocked' );
		wp_send_json_success( array( 'unlocked' => 1 ) );
	}

	/**
	 * What the desk's lock screen knows about the person sitting here.
	 *
	 * @param array $agent Agent row.
	 * @return array
	 */
	public function lock_config( $agent ) {
		return array(
			'nonce'   => wp_create_nonce( 'cloaklink_agent_unlock' ),
			'ajax'    => admin_url( 'admin-ajax.php' ),
			// The desk's own idle window, when the operator set one; the
			// console's otherwise. A desk is often a phone on a table, which is
			// a different risk from a tab left open on an office machine.
			'minutes' => max(
				1,
				(int) ( (int) cloaklink()->adv->get( 'desk_idle_minutes', 0 ) > 0
					? (int) cloaklink()->adv->get( 'desk_idle_minutes', 0 )
					: (int) $this->settings->get( 'idle_lock_minutes', 10 ) )
			),
			// Always the access code, whether or not one has been set.
			//
			// Falling back to the password made the lock a second sign-in
			// form on accounts without a code, which is not a lock — it is
			// the door again, with the same secret somebody behind the desk
			// may already have watched being typed. An account with no code
			// gets one when the operator creates it or sets it later, and the
			// panel says so rather than quietly asking for something else.
			'needs'   => 'code',
			'has'     => '' !== (string) $agent['code_hash'],
			'name'    => (string) $agent['name'],
			'init'    => strtoupper( substr( (string) $agent['name'], 0, 1 ) ),
		);
	}

	/**
	 * Which screen the requested path names.
	 *
	 * @return string '' when this is not an agent request.
	 */
	private function screen_from_uri() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path = (string) parse_url( $uri, PHP_URL_PATH );
		$home = (string) parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( '' !== $home && '/' !== $home && 0 === strpos( $path, rtrim( $home, '/' ) ) ) {
			$path = substr( $path, strlen( rtrim( $home, '/' ) ) );
		}
		$bits = array_values( array_filter( explode( '/', trim( $path, '/' ) ), 'strlen' ) );
		if ( ! $bits || strtolower( $bits[0] ) !== strtolower( $this->path() ) ) {
			return '';
		}
		if ( ! isset( $bits[1] ) ) {
			return 'login';
		}
		if ( 'panel' === $bits[1] || 'ticket' === $bits[1] || 'out' === $bits[1] || 'prefs' === $bits[1] ) {
			return $bits[1];
		}
		return 'login';
	}

	/**
	 * Draw one of the desk's screens.
	 *
	 * @param string     $view  View name.
	 * @param array|null $agent Agent row.
	 * @return void
	 */
	private function render( $view, $agent ) {
		$base = realpath( CLOAKLINK_DIR . 'views/agent' );
		$file = CLOAKLINK_DIR . 'views/agent/' . $view . '.php';
		$real = realpath( $file );
		if ( ! $base || ! $real || 0 !== strpos( $real, $base . DIRECTORY_SEPARATOR ) || ! is_file( $real ) ) {
			wp_die( esc_html__( 'That page is not available.', 'cloaklink' ), 404 );
		}
		global $cl_agents, $cl_agent;
		$cl_agents = $this;
		$cl_agent  = $agent;
		require $real;
	}

	/**
	 * Where one person's desk opens.
	 *
	 * Their own choice wins over the operator's, because the person at the
	 * desk is the one who has to use it. The operator's setting is the answer
	 * for everyone who has not chosen.
	 *
	 * @param int $agent_id Agent id.
	 * @return string queue|monitor|ticket
	 */
	public function landing( $agent_id ) {
		$own = (string) cloaklink()->adv->pref( $agent_id, 'landing', '' );
		if ( in_array( $own, array( 'queue', 'monitor', 'ticket' ), true ) ) {
			return $own;
		}
		$site = (string) cloaklink()->adv->get( 'agent_landing', 'queue' );
		return in_array( $site, array( 'queue', 'monitor', 'ticket' ), true ) ? $site : 'queue';
	}

	/**
	 * The message to show on the sign-in screen, from the query.
	 *
	 * @return array [kind, text]
	 */
	public function login_notice() {
		$err = isset( $_GET['cl_err'] ) ? sanitize_key( wp_unslash( $_GET['cl_err'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$ok  = isset( $_GET['cl_ok'] ) ? sanitize_key( wp_unslash( $_GET['cl_ok'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		$errors = array(
			'bad_login'   => __( 'That username and password do not match.', 'cloaklink' ),
			'refused'     => __( 'This desk will not open for you right now.', 'cloaklink' ),
			'quota'       => __( 'This account has reached its limit of tickets for today.', 'cloaklink' ),
			'closed'      => __( 'The desk is paused. Ask the operator to open it.', 'cloaklink' ),
			'desk_paused' => __( 'The desk is paused. Ask the operator to open it.', 'cloaklink' ),
			'out_of_hours' => __( 'The desk is closed at this hour.', 'cloaklink' ),
			'throttled'   => __( 'Too many failed attempts. Wait a few minutes and try again.', 'cloaklink' ),
			'not_deleted' => __( 'That ticket was not removed. It is still in the queue.', 'cloaklink' ),
			// Said when something tries to release a ticket from this door.
			// It is the one refusal on this desk that has to explain itself,
			// because the person may believe they were allowed to do it.
			'not_allowed' => __( 'Only the office can release a ticket and make its link. Yours is in the queue waiting for them.', 'cloaklink' ),
			'note_short'  => __( 'Add a line saying what the ticket is about.', 'cloaklink' ),
			'ip_refused'  => __( 'This desk does not open from this network.', 'cloaklink' ),
			'expired'     => __( 'This account has expired. Ask the operator for a new one.', 'cloaklink' ),
			'bad_code'    => __( 'That access code is not correct.', 'cloaklink' ),
			'paused'      => __( 'This account is switched off. Ask the operator to turn it back on.', 'cloaklink' ),
			'empty'       => __( 'Enter your username and password.', 'cloaklink' ),
			'note'        => __( 'Fill in the name and the mobile number to raise a ticket.', 'cloaklink' ),
			'link_failed' => __( 'The ticket could not be saved. Try again.', 'cloaklink' ),
		);
		if ( '' !== $err && isset( $errors[ $err ] ) ) {
			return array( 'error', $errors[ $err ] );
		}
		if ( 'raised' === $ok ) {
			return array( 'ok', __( 'Ticket raised.', 'cloaklink' ) );
		}
		if ( 'deleted' === $ok ) {
			return array( 'ok', __( 'That ticket and its link are gone.', 'cloaklink' ) );
		}
		if ( 'out' === $ok ) {
			return array( 'ok', __( 'You are signed out.', 'cloaklink' ) );
		}
		if ( 'allowed' === $ok ) {
			return array( 'ok', __( 'Ticket released. Its link is ready to copy.', 'cloaklink' ) );
		}
		if ( 'held' === $ok ) {
			return array( 'ok', __( 'Ticket held back. Its records are hidden again; nothing was deleted.', 'cloaklink' ) );
		}
		if ( 'cleared' === $ok ) {
			return array( 'ok', __( 'That record was cleared from monitoring. The time it happened is kept.', 'cloaklink' ) );
		}
		if ( 'cleared_many' === $ok ) {
			return array( 'ok', __( 'Those records are cleared from your view of monitoring. The operator’s record and the link are untouched.', 'cloaklink' ) );
		}
		if ( 'not_cleared' === $ok ) {
			return array( 'error', __( 'That record could not be cleared. It may belong to a ticket that is not released.', 'cloaklink' ) );
		}
		if ( 'deleted_many' === $ok ) {
			return array( 'ok', __( 'Those records are deleted. They are gone from the operator’s wall as well.', 'cloaklink' ) );
		}
		return array( '', '' );
	}

	/*
	 * ---------------------------------------------------------------------
	 * Agents
	 * ------------------------------------------------------------------ */

	/**
	 * Create an agent.
	 *
	 * @param array $in Raw input: username, password, code, name, email.
	 * @return array|WP_Error
	 */
	/**
	 * Which of the desk's two roles a word means.
	 *
	 * An admin here is not a WordPress administrator and never becomes one —
	 * it is a second kind of person on the case desk, with the operator's side
	 * of it offered to them there. Only the two names are accepted, so a
	 * crafted form cannot invent a third.
	 *
	 * @param string $role Raw value.
	 * @return string agent|admin
	 */
	public static function clean_role( $role ) {
		return 'admin' === strtolower( trim( (string) $role ) ) ? 'admin' : 'agent';
	}

	/**
	 * Is this agent given the operator's side of the desk?
	 *
	 * @param array|null $agent Agent row.
	 * @return bool
	 */
	public function is_admin( $agent ) {
		return is_array( $agent ) && 'admin' === self::clean_role( isset( $agent['role'] ) ? $agent['role'] : '' );
	}

	/**
	 * Set an agent's role.
	 *
	 * @param int    $id   Agent id.
	 * @param string $role agent|admin.
	 * @return bool
	 */
	public function set_role( $id, $role ) {
		global $wpdb;
		$id = absint( $id );
		if ( ! $id || ! $this->get( $id ) ) {
			return false;
		}
		return false !== $wpdb->update( $this->table(), array( 'role' => self::clean_role( $role ) ), array( 'id' => $id ) );
	}

	public function create( $in ) {
		global $wpdb;

		$user  = isset( $in['username'] ) ? sanitize_user( (string) $in['username'], true ) : '';
		$pass  = isset( $in['password'] ) ? (string) $in['password'] : '';
		$code  = isset( $in['code'] ) ? preg_replace( '/\D/', '', (string) $in['code'] ) : '';
		$name  = isset( $in['name'] ) ? sanitize_text_field( (string) $in['name'] ) : '';
		$email = isset( $in['email'] ) ? sanitize_email( (string) $in['email'] ) : '';
		$role  = isset( $in['role'] ) ? self::clean_role( (string) $in['role'] ) : 'agent';

		if ( '' === $user || '' === $pass ) {
			return new WP_Error( 'missing', __( 'A username and a password are both required.', 'cloaklink' ) );
		}
		if ( strlen( $pass ) < 8 ) {
			return new WP_Error( 'short', __( 'The password must be at least eight characters.', 'cloaklink' ) );
		}
		if ( '' !== $code && 6 !== strlen( $code ) ) {
			return new WP_Error( 'code', __( 'The access code must be six digits, or left empty.', 'cloaklink' ) );
		}
		if ( $this->by_username( $user ) ) {
			return new WP_Error( 'exists', __( 'That username is already taken by another agent.', 'cloaklink' ) );
		}

		$ok = $wpdb->insert(
			$this->table(),
			array(
				'username'   => $user,
				'pass_hash'  => wp_hash_password( $pass ),
				'code_hash'  => '' !== $code ? wp_hash_password( $code ) : '',
				'name'       => '' !== $name ? $name : $user,
				'email'      => $email,
				'status'     => 'active',
				'role'       => $role,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( ! $ok ) {
			return new WP_Error( 'db', __( 'The agent could not be stored.', 'cloaklink' ) );
		}

		$id = (int) $wpdb->insert_id;
		cloaklink()->links->log_audit( 'agent_created', 0, array( 'agent' => $id, 'username' => $user ) );

		return $this->get( $id );
	}

	/**
	 * One agent by id.
	 *
	 * @param int $id Agent id.
	 * @return array|null
	 */
	public function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->table() . ' WHERE id = %d', absint( $id ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		return $row ? $row : null;
	}

	/**
	 * One agent by username.
	 *
	 * @param string $username Username.
	 * @return array|null
	 */
	public function by_username( $username ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->table() . ' WHERE username = %s', (string) $username ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		return $row ? $row : null;
	}

	/**
	 * Every agent, newest first.
	 *
	 * @return array
	 */
	public function all() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . $this->table() . ' ORDER BY id DESC', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * How many tickets exist, and how many are still waiting.
	 *
	 * Two numbers for the sign-in screen, read in one query: the desk states
	 * what it is holding without naming a single person or ticket.
	 *
	 * @return array { total, pending, allowed }
	 */
	public function ticket_counts() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS n FROM ' . $this->tickets_table() . ' GROUP BY status', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL

		$out = array(
			'total'   => 0,
			'pending' => 0,
			'allowed' => 0,
		);
		foreach ( (array) $rows as $row ) {
			$n = (int) $row['n'];
			$out['total'] += $n;
			if ( 'allowed' === (string) $row['status'] || 'open' === (string) $row['status'] ) {
				$out['allowed'] += $n;
			} else {
				$out['pending'] += $n;
			}
		}

		return $out;
	}

	/**
	 * Count agents, and how many are active.
	 *
	 * @return array
	 */
	public function counts() {
		$all    = $this->all();
		$active = 0;
		foreach ( $all as $one ) {
			if ( 'active' === (string) $one['status'] ) {
				$active++;
			}
		}
		$admins = 0;
		foreach ( $all as $one ) {
			if ( $this->is_admin( $one ) ) {
				$admins++;
			}
		}

		return array(
			'total'   => count( $all ),
			'active'  => $active,
			'admins'  => $admins,
			'agents'  => count( $all ) - $admins,
			'paused'  => count( $all ) - $active,
		);
	}

	/**
	 * Change an agent's password and/or code.
	 *
	 * @param int   $id   Agent id.
	 * @param array $in   Input: password, code.
	 * @return void
	 */
	public function update_credentials( $id, $in ) {
		global $wpdb;
		$set = array();

		$pass = isset( $in['password'] ) ? (string) $in['password'] : '';
		if ( '' !== $pass && strlen( $pass ) >= 8 ) {
			$set['pass_hash']    = wp_hash_password( $pass );
			// The change is what the password-age rule counts from, so the
			// moment is written with the hash rather than derived later.
			$set['pass_changed'] = current_time( 'mysql' );
			$set['must_change']  = 0;
		}

		if ( isset( $in['code'] ) ) {
			$code = preg_replace( '/\D/', '', (string) $in['code'] );
			if ( '' === $code ) {
				$set['code_hash'] = '';
			} elseif ( 6 === strlen( $code ) ) {
				$set['code_hash'] = wp_hash_password( $code );
			}
		}

		if ( $set ) {
			$wpdb->update( $this->table(), $set, array( 'id' => absint( $id ) ) );
		}
	}

	/**
	 * The desk's radio settings, with this person's own answers laid over.
	 *
	 * The office decides what the radio is and what it may do; the person
	 * sitting at the desk decides how loud it is in the room they are in, and
	 * who they do not want to hear. Those are two different kinds of decision
	 * and they belong in two different places — which is why the office's
	 * rules are read first and only then overridden, and only on the four
	 * keys that are a person's own.
	 *
	 * The mute list is resolved here into the numbers the browser already
	 * uses for peer keys, so the script needs no extra round trip to know
	 * whose voice starts muted.
	 *
	 * @param array|null $agent Agent row, or null for the signed-in person.
	 * @return array
	 */
	public function radio_config_for( $agent = null ) {
		$cfg = CloakLink_Walkie::radio_config();

		if ( null === $agent ) {
			$agent = $this->current();
		}
		if ( ! $agent || empty( $agent['id'] ) ) {
			return $cfg;
		}

		$prefs = cloaklink()->adv->prefs( (int) $agent['id'] );

		$vol = isset( $prefs['radio_volume'] ) ? (int) $prefs['radio_volume'] : 100;
		$cfg['volume'] = max( 0, min( 100, $vol ) ) / 100;

		if ( isset( $prefs['radio_cue_own'] ) ) {
			$on = (bool) $prefs['radio_cue_own'];
			$cfg['cue']    = $on ? $cfg['cue'] : false;
			$cfg['beepEnd'] = $on ? $cfg['beepEnd'] : false;
		}

		$list = isset( $prefs['radio_mute_list'] ) ? (string) $prefs['radio_mute_list'] : '';
		$ids  = array();
		foreach ( preg_split( '/[^0-9]+/', $list ) as $one ) {
			$one = (int) $one;
			if ( $one > 0 ) {
				$ids[] = 'agent:' . $one;
			}
		}
		$cfg['muted'] = array_values( array_unique( $ids ) );

		// Whether this person's own face travels with their voice. The office
		// may also have switched the card off entirely, in which case there is
		// no card to put a picture on and this changes nothing.
		$cfg['myFace'] = isset( $prefs['radio_face'] ) ? (bool) $prefs['radio_face'] : true;

		return $cfg;
	}

	/**
	 * The per-person rules the operator can change on the agents table.
	 *
	 * These are the columns that belong to one person rather than to the
	 * desk: their own network list, their own daily cap, the moment their
	 * account stops, and whether they must choose a new password next time.
	 * Every one accepts an empty value, because "no rule for this person" is
	 * the shipped state and must be reachable again after it is set.
	 *
	 * @param int   $id  Agent id.
	 * @param array $in  ip_lock, quota, expires_at, must_change.
	 * @return void
	 */
	/**
	 * Set the sound this person's messages make on everybody else's screen.
	 *
	 * The tone is a recipe, not a file: a waveform, a run of notes and a
	 * length, drawn in the browser. Empty means "the desk's own tone", which is
	 * what a person gets until the operator decides otherwise.
	 *
	 * @param int    $id   Agent id.
	 * @param string $tone Tone key, or '' for the desk's default.
	 * @return bool
	 */
	public function set_radio_tone( $id, $tone ) {
		global $wpdb;
		$id   = absint( $id );
		$tone = sanitize_key( (string) $tone );
		$all  = CloakLink_Walkie::tones();
		if ( $id < 1 ) {
			return false;
		}
		if ( '' !== $tone && ! isset( $all[ $tone ] ) ) {
			return false;
		}
		return false !== $wpdb->update( $this->table(), array( 'radio_tone' => $tone ), array( 'id' => $id ) );
	}

	/**
	 * The tone stored on an account, or '' when it inherits the desk's.
	 *
	 * @param int $id Agent id.
	 * @return string
	 */
	public function radio_tone( $id ) {
		$one = $this->get( (int) $id );
		return $one && isset( $one['radio_tone'] ) ? (string) $one['radio_tone'] : '';
	}

	/**
	 * The picture on an account, if one was uploaded.
	 *
	 * A face is worth more than two letters on a card that appears for four
	 * seconds: the point of the "who is talking" announcement is to know who
	 * it is before reading anything. It is optional, and an account without
	 * one gets the initials, in the same colour, in the same place — so the
	 * card never has an empty hole where a face would be.
	 *
	 * @param int $id Agent id.
	 * @return string Image URL, or ''.
	 */
	public function avatar_url( $id ) {
		$one = $this->get( (int) $id );
		if ( ! $one || empty( $one['avatar_id'] ) ) {
			return '';
		}
		$url = wp_get_attachment_image_url( (int) $one['avatar_id'], 'thumbnail' );
		return $url ? (string) $url : '';
	}

	/**
	 * Attach or clear the picture on an account.
	 *
	 * @param int $id      Agent id.
	 * @param int $mediaId Attachment id, or 0 to remove.
	 * @return bool
	 */
	public function set_avatar( $id, $mediaId ) {
		global $wpdb;
		$id = absint( $id );
		if ( $id < 1 ) {
			return false;
		}
		$mediaId = absint( $mediaId );
		if ( $mediaId && 'attachment' !== get_post_type( $mediaId ) ) {
			return false;
		}
		return false !== $wpdb->update( $this->table(), array( 'avatar_id' => $mediaId ), array( 'id' => $id ) );
	}

	public function update_rules( $id, $in ) {
		global $wpdb;
		$set = array();

		if ( array_key_exists( 'ip_lock', $in ) ) {
			$list = preg_split( '/[\s,]+/', (string) $in['ip_lock'] );
			$keep = array();
			foreach ( (array) $list as $entry ) {
				$entry = trim( (string) $entry );
				if ( '' === $entry ) {
					continue;
				}
				// An address, a prefix or a CIDR block. Anything else is
				// dropped rather than stored, so a typo can never refuse a
				// person their own desk.
				if ( preg_match( '/^[0-9a-fA-F:.]+(\/\d{1,3})?$/', $entry ) ) {
					$keep[] = $entry;
				}
			}
			$set['ip_lock'] = implode( ' ', $keep );
		}

		if ( array_key_exists( 'quota', $in ) ) {
			// Zero is "use the desk's number", which is the default.
			$set['quota'] = absint( $in['quota'] );
		}

		if ( array_key_exists( 'expires_at', $in ) ) {
			$when = trim( (string) $in['expires_at'] );
			$set['expires_at'] = '';
			if ( '' !== $when ) {
				$ts = strtotime( $when );
				if ( $ts ) {
					$set['expires_at'] = gmdate( 'Y-m-d H:i:s', $ts + ( (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );
				}
			}
		}

		if ( array_key_exists( 'must_change', $in ) ) {
			$set['must_change'] = ! empty( $in['must_change'] ) ? 1 : 0;
		}

		if ( $set ) {
			$wpdb->update( $this->table(), $set, array( 'id' => absint( $id ) ) );
		}
	}

	/**
	 * End every session this person currently has.
	 *
	 * A cookie already issued cannot be reached, so the account is stamped
	 * with the moment of the kill and every cookie older than it stops being
	 * accepted. The person is not told anything they cannot work out: their
	 * next request takes them to the door.
	 *
	 * @param int $id Agent id.
	 * @return void
	 */
	public function cut_sessions( $id ) {
		global $wpdb;
		$wpdb->update(
			$this->table(),
			array( 'session_cut' => current_time( 'mysql' ) ),
			array( 'id' => absint( $id ) )
		);
		cloaklink()->agent_log->log( absint( $id ), 'signout', array( 'detail' => __( 'Signed out from the console', 'cloaklink' ) ) );
		CloakLink_Agent_Log::stop_beat( absint( $id ) );
	}

	/**
	 * Turn an agent on or off.
	 *
	 * @param int    $id     Agent id.
	 * @param string $status active|paused.
	 * @return void
	 */
	public function set_status( $id, $status ) {
		global $wpdb;
		$wpdb->update(
			$this->table(),
			array( 'status' => 'active' === $status ? 'active' : 'paused' ),
			array( 'id' => absint( $id ) )
		);
	}

	/**
	 * Delete an agent, their tickets and the links those tickets made.
	 *
	 * The links go too, because a link whose owner no longer exists is a link
	 * nobody can see or clear from either side — and it still captures
	 * visitors' positions. Their visits go with it through the same path a
	 * link deleted from the Links screen takes.
	 *
	 * @param int $id Agent id.
	 * @return bool
	 */
	public function delete( $id ) {
		global $wpdb;
		$id = absint( $id );
		if ( ! $id ) {
			return false;
		}

		$link_ids = array();
		foreach ( $this->tickets_for( $id ) as $ticket ) {
			if ( ! empty( $ticket['link_id'] ) ) {
				$link_ids[] = (int) $ticket['link_id'];
			}
		}
		if ( $link_ids ) {
			$this->db->delete_links( $link_ids, true );
		}

		$wpdb->delete( $this->tickets_table(), array( 'agent_id' => $id ) );
		$wpdb->delete( $this->table(), array( 'id' => $id ) );

		return true;
	}

	/**
	 * Check a username and password.
	 *
	 * @param string $username Username.
	 * @param string $password Password.
	 * @param string $code     Access code, when the agent has one.
	 * @return array|WP_Error Agent row on success.
	 */
	public function authenticate( $username, $password, $code = '' ) {
		$agent = $this->by_username( trim( (string) $username ) );

		// One answer for a wrong name and a wrong password, so the form cannot
		// be used to find out which usernames exist.
		$wrong = new WP_Error( 'bad_login', __( 'That username and password do not match.', 'cloaklink' ) );

		if ( ! $agent || ! wp_check_password( (string) $password, (string) $agent['pass_hash'] ) ) {
			return $wrong;
		}
		if ( 'active' !== (string) $agent['status'] ) {
			return new WP_Error( 'paused', __( 'This account is switched off. Ask the operator to turn it back on.', 'cloaklink' ) );
		}

		// An account past its expiry is a different answer from a wrong
		// password: the person's details are right, and saying so saves a
		// phone call that would otherwise end in "it must be your password".
		if ( ! $this->account_live( $agent ) ) {
			return new WP_Error( 'expired', __( 'This account has expired.', 'cloaklink' ) );
		}

		// A code, when one is set, is a second factor and is checked after the
		// password so a wrong code is never reported for a name that does not
		// exist.
		$have = (string) $agent['code_hash'];
		// An operator who wants every account to carry a code: an account
		// without one is refused rather than quietly let in on its password
		// alone. The message says what to do, because the person reading it
		// cannot fix it themselves.
		if ( '' === $have && cloaklink()->adv->yes( 'agent_code_all' ) ) {
			return new WP_Error( 'need_code', __( 'This account has no access code yet. Ask the operator to set one before you sign in.', 'cloaklink' ) );
		}
		if ( '' !== $have ) {
			$code = preg_replace( '/\D/', '', (string) $code );
			if ( ! wp_check_password( $code, $have ) ) {
				return new WP_Error( 'bad_code', __( 'That access code is not correct.', 'cloaklink' ) );
			}
		}

		return $agent;
	}

	/*
	 * ---------------------------------------------------------------------
	 * Sessions
	 * ------------------------------------------------------------------ */

	/**
	 * Sign an agent in: a signed cookie carrying the agent id and an expiry.
	 *
	 * The cookie is signed with this site's salt rather than stored in the
	 * options table, so a stolen cookie cannot be forged and a session needs
	 * no row of its own.
	 *
	 * @param array $agent Agent row.
	 * @return void
	 */
	public function start_session( $agent ) {
		cloaklink()->agent_log->log( (int) $agent['id'], 'signin' );
		// How long this session lasts. The Advanced screen sets it, because a
		// phone left on a desk and a desk machine in an office need different
		// answers, and twelve hours is only the middle of the two.
		$hours   = (int) cloaklink()->adv->get( 'agent_session_hours', self::SESSION_HOURS );
		$hours   = max( 1, min( 336, $hours ) );
		$expires = time() + ( $hours * HOUR_IN_SECONDS );
		$value   = $this->sign( (int) $agent['id'], $expires );

		$path   = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$path   = '' !== $path ? rtrim( $path, '/' ) . '/' : '/';
		$secure = is_ssl();

		if ( ! headers_sent() ) {
			setcookie(
				self::COOKIE,
				$value,
				array(
					'expires'  => $expires,
					'path'     => $path,
					'secure'   => $secure,
					'httponly' => true,
					'samesite' => 'Lax',
				)
			);
		}
		$_COOKIE[ self::COOKIE ] = $value;

		global $wpdb;
		$wpdb->update( $this->table(), array( 'last_login' => current_time( 'mysql' ) ), array( 'id' => absint( $agent['id'] ) ) );

		// The operator asked to hear about every arrival. It is sent after the
		// cookie is set and the row updated, so a mail server having a bad
		// morning can never stop somebody getting onto their desk.
		if ( cloaklink()->agent_policy->value( 'desk_notify_login' ) && ! cloaklink()->adv->in_quiet_hours() ) {
			$this->mail_arrival( $agent );
		}
	}

	/**
	 * Tell the operator somebody has opened the desk.
	 *
	 * Four facts, in the order the operator asks them: who, when, from where,
	 * on what. Nothing else — this is a notification, not a report, and a
	 * message that takes a minute to read is one that gets filtered.
	 *
	 * @param array $agent Agent row.
	 * @return void
	 */
	private function mail_arrival( $agent ) {
		$to = (string) $this->settings->get( 'notify_email' );
		if ( '' === $to || ! is_email( $to ) ) {
			$to = (string) $this->settings->get( 'brand_email' );
		}
		if ( '' === $to || ! is_email( $to ) ) {
			return;
		}

		$ua    = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 300 ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$parsed = CloakLink_UA::parse( $ua );
		$ip     = CloakLink_Geo::ip();
		$geo    = CloakLink_Geo::lookup( $ip );
		$geo    = is_array( $geo ) ? $geo : array();
		$place  = trim( implode( ', ', array_filter( array( (string) ( $geo['city'] ?? '' ), (string) ( $geo['country_name'] ?? '' ) ) ) ) );

		$subject = sprintf(
			/* translators: %s: person's name */
			__( 'Case desk: %s signed in', 'cloaklink' ),
			(string) $agent['name']
		);

		$lines = array(
			sprintf( /* translators: %s: person's name */ __( '%s signed in to the case desk.', 'cloaklink' ), (string) $agent['name'] ),
			'',
			sprintf( /* translators: %s: time */ __( 'When: %s', 'cloaklink' ), wp_date( 'j M Y, H:i' ) ),
			sprintf( /* translators: %s: address */ __( 'Network: %s', 'cloaklink' ), $ip ),
			sprintf( /* translators: %s: place */ __( 'Place: %s', 'cloaklink' ), '' !== $place ? $place : __( 'not named', 'cloaklink' ) ),
			sprintf( /* translators: 1: device, 2: browser */ __( 'Device: %1$s, %2$s', 'cloaklink' ), (string) $parsed['device'], (string) $parsed['browser'] ),
			'',
			__( 'If this was not them, sign out their sessions on the Case agents screen.', 'cloaklink' ),
			CloakLink_Admin::url( 'agents' ),
		);

		wp_mail( $to, cloaklink()->adv->subject( $subject ), cloaklink()->adv->mail_body( implode( "\n", $lines ) ) );
	}

	/**
	 * The signed value for an agent and an expiry.
	 *
	 * @param int $id      Agent id.
	 * @param int $expires Unix time.
	 * @return string
	 */
	private function sign( $id, $expires ) {
		$payload = (int) $id . '.' . (int) $expires;
		return $payload . '.' . hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
	}

	/**
	 * The agent signed in on this request, or null.
	 *
	 * @return array|null
	 */
	public function current() {
		$raw = isset( $_COOKIE[ self::COOKIE ] ) ? (string) $_COOKIE[ self::COOKIE ] : '';
		if ( '' === $raw ) {
			return null;
		}

		$bits = explode( '.', $raw );
		if ( count( $bits ) !== 3 ) {
			return null;
		}

		list( $id, $expires, $sig ) = $bits;
		$payload = (int) $id . '.' . (int) $expires;
		$expect  = hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );

		// hash_equals rather than ===: a comparison that stops at the first
		// wrong character leaks how much of a forged signature was right.
		if ( ! hash_equals( $expect, (string) $sig ) ) {
			return null;
		}
		if ( (int) $expires < time() ) {
			return null;
		}

		$agent = $this->get( (int) $id );
		if ( ! $agent || 'active' !== (string) $agent['status'] ) {
			return null;
		}

		// A session cannot outlive an operator's decision to end them all, and
		// it cannot outlive the account's expiry. Both are checked from the
		// row on every request, so ending a session takes effect on the
		// person's very next click rather than when their cookie runs out.
		if ( ! cloaklink()->agent_policy->session_valid( $agent, (int) $expires ) ) {
			return null;
		}
		if ( ! $this->account_live( $agent ) ) {
			return null;
		}
		return $agent;
	}

	/**
	 * Whether the account itself still exists in time.
	 *
	 * An expiry is a date the operator set when the account was made — a
	 * fortnight for a temp, a year for staff. It is compared here rather than
	 * in a nightly sweep so an expired account stops working at the moment it
	 * expires, not on the next cron run.
	 *
	 * @param array $agent Agent row.
	 * @return bool
	 */
	public function account_live( $agent ) {
		$when = isset( $agent['expires_at'] ) ? trim( (string) $agent['expires_at'] ) : '';
		if ( '' === $when || '0000-00-00 00:00:00' === $when ) {
			return true;
		}
		$ts = strtotime( $when );
		return ! $ts || $ts > time();
	}

	/**
	 * Sign the current agent out.
	 *
	 * @return void
	 */
	public function end_session() {
		$path   = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$path   = '' !== $path ? rtrim( $path, '/' ) . '/' : '/';
		if ( ! headers_sent() ) {
			setcookie( self::COOKIE, '', array( 'expires' => time() - 3600, 'path' => $path ) );
		}
		unset( $_COOKIE[ self::COOKIE ] );
	}

	/*
	 * ---------------------------------------------------------------------
	 * Tickets
	 * ------------------------------------------------------------------ */

	/**
	 * Create a ticket and the link it hands out.
	 *
	 * @param array $agent Agent row.
	 * @param array $in    Raw input: name, phone, note, destination.
	 * @return array|WP_Error Ticket row with its link address.
	 */
	public function create_ticket( $agent, $in ) {
		global $wpdb;

		$name  = isset( $in['name'] ) ? sanitize_text_field( (string) $in['name'] ) : '';
		$phone = isset( $in['phone'] ) ? preg_replace( '/[^0-9+]/', '', (string) $in['phone'] ) : '';
		$note  = isset( $in['note'] ) ? sanitize_text_field( (string) $in['note'] ) : '';

		// What kind of link this request is asking for. It is the agent's
		// guess, not a decision: the operator can change it when they allow
		// the ticket, because the person who makes the link is the person who
		// knows what should be on it.
		$kind = isset( $in['kind'] ) ? sanitize_key( (string) $in['kind'] ) : '';
		if ( ! in_array( $kind, array( 'website', 'legal', 'instagram' ), true ) ) {
			$kind = '';
		}

		if ( '' === $name ) {
			return new WP_Error( 'name', __( 'A name is required.', 'cloaklink' ) );
		}
		if ( strlen( $phone ) < 6 ) {
			return new WP_Error( 'phone', __( 'A mobile number is required.', 'cloaklink' ) );
		}

		// The shortest note the operator accepts, from the Advanced screen.
		// A one-word note is what makes an operator ring the agent back to ask
		// what the request actually was, which is a call the ticket existed to
		// prevent. Zero, the default, accepts anything.
		$min_note = max( 0, (int) cloaklink()->adv->get( 'ticket_note_min', 0 ) );
		if ( $min_note > 0 && mb_strlen( $note ) < $min_note ) {
			return new WP_Error(
				'note_short',
				sprintf(
					/* translators: %d: minimum characters */
					__( 'Add a line of at least %d characters saying what this is about.', 'cloaklink' ),
					$min_note
				)
			);
		}

		// A kind the desk has no opinion on takes the operator's default, so
		// a raise form that never asked is not an empty column in the queue.
		if ( '' === $kind ) {
			$fallback = (string) cloaklink()->adv->get( 'ticket_kind', '' );
			if ( in_array( $fallback, array( 'website', 'legal', 'instagram' ), true ) ) {
				$kind = $fallback;
			}
		}

		// A ticket is a request. No link exists yet.
		//
		// It used to make the link at the moment the agent pressed the button,
		// so an address was circulating before anybody at the office had looked
		// at the request. Now the link is made when the operator allows the
		// ticket (see make_link()), and the name the agent typed is the name
		// printed on that address — so the file says who it is about from the
		// moment it exists.
		$ref = strtoupper( wp_generate_password( 6, false, false ) );

		$ok = $wpdb->insert(
			$this->tickets_table(),
			array(
				'agent_id'   => (int) $agent['id'],
				'ref'        => $ref,
				'person'     => $name,
				'phone'      => $phone,
				'note'       => $note,
				'link_id'    => 0,
				'status'     => 'pending',
				'kind'       => $kind,
				'doc_id'     => isset( $in['doc_id'] ) ? absint( $in['doc_id'] ) : 0,
				'doc_name'   => isset( $in['doc_name'] ) ? mb_substr( sanitize_file_name( (string) $in['doc_name'] ), 0, 190 ) : '',
				'doc_path'   => isset( $in['doc_path'] ) ? mb_substr( sanitize_file_name( (string) $in['doc_path'] ), 0, 190 ) : '',
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s', '%s' )
		);

		if ( ! $ok ) {
			return new WP_Error( 'link', __( 'The ticket could not be saved.', 'cloaklink' ) );
		}

		$ticket_id = (int) $wpdb->insert_id;

		/**
		 * Fires when an agent raises a ticket.
		 *
		 * @param int   $ticket_id Ticket id.
		 * @param array $agent     Agent row.
		 * @param array $row       Unused; kept so existing listeners still work.
		 */
		do_action( 'cloaklink_ticket_raised', $ticket_id, $agent, null );

		return $this->get_ticket( $ticket_id );
	}

	/**
	 * Make the link for a ticket that has been allowed.
	 *
	 * The address is built from the name the agent typed, so a shared link
	 * reads as the file it is about ("…Notice.RaviKumar.E23TPV"), and the
	 * link carries the ticket and the agent in its meta so the office side can
	 * tell where it came from.
	 *
	 * Doing this at the moment of allowing — rather than at the moment of
	 * raising — means an unallowed request has no address at all. Nothing can
	 * leak because there is nothing to leak.
	 *
	 * @param int   $ticket_id Ticket id.
	 * @param array $over      Optional overrides: destination, domain, extension.
	 * @return array|WP_Error Ticket row, with `url`.
	 */
	public function make_link( $ticket_id, $over = array() ) {
		global $wpdb;

		$ticket = $this->get_ticket( $ticket_id );
		if ( ! $ticket ) {
			return new WP_Error( 'noticket', __( 'That ticket no longer exists.', 'cloaklink' ) );
		}
		if ( ! empty( $ticket['link_id'] ) && $this->db->get_link( (int) $ticket['link_id'] ) ) {
			return $ticket;
		}

		$agent = $this->get( (int) $ticket['agent_id'] );
		$name  = (string) $ticket['person'];
		$note  = (string) $ticket['note'];

		$dest = isset( $over['destination'] ) ? esc_url_raw( (string) $over['destination'] ) : '';
		$dom  = isset( $over['domain'] ) ? CloakLink_Settings::clean_host( (string) $over['domain'] ) : '';
		$ext  = isset( $over['extension'] ) ? (string) $over['extension'] : '';

		// What kind of link to make. The agent may have said at raise time;
		// the operator can override it here, and their word wins. A ticket
		// with a document attached is a document link unless the operator
		// says otherwise, because that is what the attachment is for.
		$kind = isset( $over['kind'] ) ? sanitize_key( (string) $over['kind'] ) : '';
		if ( ! in_array( $kind, array( 'website', 'legal', 'instagram' ), true ) ) {
			$kind = isset( $ticket['kind'] ) ? (string) $ticket['kind'] : '';
		}
		if ( ! in_array( $kind, array( 'website', 'legal', 'instagram' ), true ) ) {
			$kind = '' !== (string) ( $ticket['doc_path'] ?? '' ) ? 'legal' : 'website';
		}
		// A document link is 'legal' to the link model; a plain one is
		// 'redirect'. Instagram has its own type.
		$link_type = 'legal' === $kind ? 'legal' : ( 'instagram' === $kind ? 'instagram' : 'redirect' );

		// Validated exactly as the operator's own form would be, so every field
		// the link row needs — the domain, the extension, the pin hash, the
		// countdown — gets the same default it gets there.
		// A ticket that carries a document already holds the file, so the
		// validation must not ask for an upload it will never receive.
		$has_doc = 'legal' === $link_type && '' !== (string) ( $ticket['doc_path'] ?? '' );

		// What the operator decided to call this link. An empty field keeps the
		// name the ticket already carries, so nothing changes for whoever
		// leaves it alone.
		$title = isset( $over['title'] ) ? trim( (string) $over['title'] ) : '';

		$build = function ( $destination ) use ( $name, $note, $dom, $ext, $link_type, $has_doc, $title ) {
			return cloaklink()->links->validate(
				array(
					'id'          => 0,
					'title'       => '' !== $title ? $title : ( $name . ( '' !== $note ? ' — ' . $note : '' ) ),
					'label'       => $name,
					'link_type'   => $link_type,
					'destination' => $destination,
					'file_ready'  => $has_doc,
					'mode'        => 'optional',
					'status'      => 'active',
					// The name on the file is the name the agent typed. This is
					// what generate_slug() prints in the address.
					'party_name'  => $name,
					// Marks this address as one released from the queue, so
					// it takes the queue's own prefix when one is set on the
					// Advanced screen.
					'from_queue'  => 1,
					'extension'   => $ext,
					'domain'      => $dom,
				)
			);
		};

		list( $clean, $bad ) = $build( $dest );

		// No address given: the visitor is asked for the position, the answer
		// is recorded, and they are sent to the site itself.
		if ( '' === $dest || $bad ) {
			list( $clean, $bad ) = $build( home_url( '/' ) );
			if ( $bad ) {
				$domains = $this->settings->domains();
				if ( $domains ) {
					list( $clean, $bad ) = $build( 'https://' . (string) $domains[0] . '/' );
				}
			}
		}

		if ( $bad ) {
			return new WP_Error( 'link', __( 'The link could not be created.', 'cloaklink' ) );
		}

		$link = cloaklink()->links->create( $clean );
		if ( is_wp_error( $link ) || ! $link ) {
			return new WP_Error( 'link', __( 'The link could not be created.', 'cloaklink' ) );
		}

		$link_id = is_array( $link ) ? (int) $link['id'] : (int) $link;

		// Marked as this ticket's link, so the office side can tell it from the
		// operator's own links, and so removing the ticket takes it away.
		$row = $this->db->get_link( $link_id );
		if ( $row ) {
			$meta = isset( $row['meta'] ) && is_array( $row['meta'] ) ? $row['meta'] : array();
			$meta['agent_id']   = (int) $ticket['agent_id'];
			$meta['agent_name'] = $agent ? (string) $agent['name'] : '';
			$meta['ticket_id']  = (int) $ticket['id'];
			$meta['ticket_ref'] = (string) $ticket['ref'];

			// The document the agent attached. It was stored at raise time in
			// the private folder, so allowing the ticket is what points the
			// link at it — nothing is re-uploaded, and a ticket that is held
			// back leaves the file in place for the next decision.
			$doc_path = isset( $ticket['doc_path'] ) ? (string) $ticket['doc_path'] : '';
			if ( '' !== $doc_path && 'legal' === $link_type ) {
				$meta['file_path'] = $doc_path;
				$meta['file_name'] = isset( $ticket['doc_name'] ) ? (string) $ticket['doc_name'] : '';
				$meta['file_type'] = 'pdf';
				$meta['file_at']   = current_time( 'mysql' );
				$meta['share_title'] = '' !== $meta['file_name'] ? $meta['file_name'] : (string) $ticket['person'];
			}

			$this->db->update_link( $link_id, array( 'meta' => $this->db->encode( $meta ) ) );
		}

		$wpdb->update( $this->tickets_table(), array( 'link_id' => $link_id ), array( 'id' => (int) $ticket['id'] ) );

		// This address is about to be copied and sent to a visitor, so it is
		// worth one request to find out whether the site actually answers on
		// it. The answer is stored and shown on the queue: an operator who
		// knows the host is not routing /go/ sends the link knowing what to
		// expect, instead of hearing about the 404 from the recipient.
		$made = $this->db->get_link( $link_id );
		if ( $made && ! empty( $made['slug'] ) ) {
			CloakLink_Install::check_routing_health( (string) $made['slug'], true );
		}

		return $this->get_ticket( $ticket['id'] );
	}

	/**
	 * One ticket.
	 *
	 * @param int $id Ticket id.
	 * @return array|null
	 */
	public function get_ticket( $id ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->tickets_table() . ' WHERE id = %d', absint( $id ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		if ( ! $row ) {
			return null;
		}
		$row['url'] = $this->url_for( $row );
		return $row;
	}

	/**
	 * Every ticket an agent raised, newest first.
	 *
	 * @param int $agent_id Agent id.
	 * @return array
	 */
	public function tickets_for( $agent_id, $all = false ) {
		global $wpdb;
		$table = $this->tickets_table();

		// An admin-role person on the desk works the whole queue, the same
		// list the operator's own Case agents screen shows; an agent sees the
		// ones they raised. The role is passed in rather than read from the
		// database a second time, because every caller already holds the row.
		// Which end of the queue comes first. Newest first is the live work;
		// oldest first is how a backlog is worked from the beginning, which is
		// what an operator does after a week away.
		$order = 'oldest' === (string) cloaklink()->adv->get( 'queue_order', 'newest' ) ? 'ASC' : 'DESC';

		if ( $all ) {
			// The queue is a work list: an admin-role person sees every ticket
			// so they can allow, hold or remove one. Seeing that a ticket
			// exists is not the same as seeing what it captured — that stays
			// with the person who raised it. `readable` is the flag the
			// template uses to decide whether it may open one, so the list
			// and the evidence are separated in one place rather than at
			// every call site.
			$rows = $wpdb->get_results( 'SELECT * FROM ' . $table . ' ORDER BY id ' . $order, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
			$me   = absint( $agent_id );
			foreach ( $rows as $i => $one ) {
				$rows[ $i ]['readable'] = (int) $one['agent_id'] === $me;
			}
		} else {
			$rows = $wpdb->get_results(
				$wpdb->prepare( 'SELECT * FROM ' . $table . ' WHERE agent_id = %d ORDER BY id ' . $order, absint( $agent_id ) ), // phpcs:ignore WordPress.DB.PreparedSQL
				ARRAY_A
			);
		}
		$rows = is_array( $rows ) ? $rows : array();

		$names = array();
		if ( $all ) {
			foreach ( $this->all() as $who ) {
				$names[ (int) $who['id'] ] = (string) $who['name'];
			}
		}
		foreach ( $rows as $i => $row ) {
			$rows[ $i ]['url'] = $this->url_for( $row );
			// Always present, even when nobody asked for it.
			//
			// The name used to be filled only in the all-tickets branch. When
			// the desk stopped asking for that branch the key vanished, and
			// every template that read it raised "Undefined array key" — a
			// warning printed above a real person's name on a real screen.
			// A key a view may read is always a key this method sets.
			$rows[ $i ]['agent_name'] = isset( $names[ (int) $row['agent_id'] ] )
				? (string) $names[ (int) $row['agent_id'] ]
				: '';
		}
		return $rows;
	}

	/**
	 * The newest visit id on any of an agent's tickets' links.
	 *
	 * The agent panel polls for arrivals the same way the operator's panel
	 * does, and a MAX(id) over a joined set is one indexed read — which is
	 * what keeps the card and its sound landing the moment a visitor answers
	 * rather than a second or two later.
	 *
	 * @param int $agent_id Agent id.
	 * @return int
	 */
	public function top_visit_for( $agent_id ) {
		global $wpdb;
		$tickets = $this->tickets_table();
		$visits  = $this->db->visits_table();
		$top     = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MAX(v.id) FROM {$visits} v INNER JOIN {$tickets} t ON t.link_id = v.link_id WHERE t.agent_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL
				absint( $agent_id )
			)
		);
		return (int) $top;
	}

	/**
	 * What has arrived on an agent's own tickets since an id.
	 *
	 * @param int $agent_id Agent id.
	 * @param int $after    Newest id the browser has seen.
	 * @return array
	 */
	public function arrivals_for( $agent_id, $after = 0 ) {
		global $wpdb;

		$top = $this->top_visit_for( $agent_id );
		if ( $top <= (int) $after ) {
			return array( 'fresh' => array(), 'top' => $top );
		}

		$tickets = $this->tickets_table();
		$visits  = $this->db->visits_table();
		$rows    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT v.* FROM {$visits} v INNER JOIN {$tickets} t ON t.link_id = v.link_id WHERE t.agent_id = %d AND v.id > %d ORDER BY v.id DESC LIMIT 20", // phpcs:ignore WordPress.DB.PreparedSQL
				absint( $agent_id ),
				max( 0, (int) $after )
			),
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();

		// Newest last, so the cards appear in the order they happened.
		$rows = array_reverse( $rows );

		// Which ticket each link belongs to, so the card can say which of the
		// agent's own cases just moved.
		// Only allowed tickets can produce a card. A ticket still waiting is
		// not news the agent may be told about, and a card would carry the
		// place the visitor answered from — which is the data itself.
		$by_link = array();
		foreach ( $this->tickets_for( $agent_id ) as $ticket ) {
			if ( ! $this->is_allowed( $ticket ) ) {
				continue;
			}
			$by_link[ (int) $ticket['link_id'] ] = $ticket;
		}

		$fresh = array();
		foreach ( $rows as $row ) {
			$cap   = $this->db->capture_of( $row );
			$kinds = array();
			foreach ( array( 'position' => 'Location', 'camera' => 'Camera', 'microphone' => 'Microphone', 'video' => 'Recording' ) as $key => $word ) {
				if ( ! empty( $cap[ $key ] ) ) {
					$kinds[] = $word;
				}
			}
			// A plain open is not worth interrupting for. Only an answer — a
			// granted permission or a recording — earns a card and a sound.
			if ( ! $kinds ) {
				continue;
			}
			// No ticket in the allowed set means this row belongs to a ticket
			// that has not been released, and it is dropped here rather than
			// described without a reference. The fall-through used to be an
			// empty array, which still produced a card — so a waiting ticket
			// announced its visitor's position before the operator allowed it.
			if ( ! isset( $by_link[ (int) $row['link_id'] ] ) ) {
				continue;
			}
			$ticket = $by_link[ (int) $row['link_id'] ];
			$bits   = array_filter( array( (string) $row['city'], (string) $row['region'], (string) $row['country_name'] ) );
			$fresh[] = array(
				'id'    => (int) $row['id'],
				'ref'   => isset( $ticket['ref'] ) ? (string) $ticket['ref'] : '',
				'who'   => isset( $ticket['person'] ) ? (string) $ticket['person'] : __( 'A visitor', 'cloaklink' ),
				'kinds' => $kinds,
				'place' => $bits ? implode( ', ', $bits ) : '',
				'at'    => CloakLink_Admin::stamp( $row['created_at'], 'g:i A' ),
			);
		}

		return array( 'fresh' => $fresh, 'top' => $top );
	}

	/**
	 * Every ticket, with the agent's name beside it.
	 *
	 * @return array
	 */
	public function all_tickets() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . $this->tickets_table() . ' ORDER BY id DESC', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$rows = is_array( $rows ) ? $rows : array();

		$names = array();
		foreach ( $this->all() as $agent ) {
			$names[ (int) $agent['id'] ] = (string) $agent['name'];
		}
		foreach ( $rows as $i => $row ) {
			$rows[ $i ]['agent_name'] = isset( $names[ (int) $row['agent_id'] ] ) ? $names[ (int) $row['agent_id'] ] : '';
			$rows[ $i ]['url']        = $this->url_for( $row );
		}
		return $rows;
	}

	/**
	 * The address a ticket's link is printed on.
	 *
	 * @param array $ticket Ticket row.
	 * @return string
	 */
	private function url_for( $ticket ) {
		if ( empty( $ticket['link_id'] ) ) {
			return '';
		}
		$link = $this->db->get_link( (int) $ticket['link_id'] );
		return $link ? (string) cloaklink()->links->link_url( $link ) : '';
	}

	/**
	 * Tell the operator a ticket has been raised.
	 *
	 * Wired to cloaklink_ticket_raised. It is a plain message with the four
	 * facts an operator needs to decide whether to allow it, and a link
	 * straight to the Case agents screen. The mail is a convenience, never a
	 * condition: the ticket exists in the panel whether or not this arrives,
	 * which matters because mail delivery on shared hosting is exactly the
	 * thing that cannot be assumed.
	 *
	 * @param int   $ticket_id Ticket id.
	 * @param array $agent     Agent row.
	 * @param array $row       Link row, or null.
	 * @return void
	 */
	public function notify_raised( $ticket_id, $agent = null, $row = null ) {
		if ( ! $this->settings->get( 'email_on_click' ) ) {
			return;
		}
		// The Advanced screen's own switch, and the quiet window. A message
		// that arrives at two in the morning wakes somebody for news they can
		// do nothing about until the desk opens; the ticket is on the queue
		// either way, so nothing is lost by holding the mail.
		if ( ! cloaklink()->adv->yes( 'mail_on_ticket' ) ) {
			return;
		}
		if ( cloaklink()->adv->in_quiet_hours() ) {
			return;
		}

		$to = (string) $this->settings->get( 'notify_email', '' );
		if ( ! is_email( $to ) ) {
			return;
		}

		$ticket = $this->get_ticket( (int) $ticket_id );
		if ( ! $ticket ) {
			return;
		}

		$brand = trim( (string) $this->settings->get( 'brand_name', '' ) );
		$brand = '' !== $brand ? $brand : 'Credit Control';
		$panel = CloakLink_Admin::url( 'agents' );

		$lines = array(
			__( 'Ticket raised', 'cloaklink' ),
			'',
			/* translators: %s: ticket reference */
			sprintf( __( 'Reference: %s', 'cloaklink' ), (string) $ticket['ref'] ),
			/* translators: %s: person's name */
			sprintf( __( 'Name: %s', 'cloaklink' ), (string) $ticket['person'] ),
			/* translators: %s: mobile number */
			sprintf( __( 'Mobile: %s', 'cloaklink' ), (string) $ticket['phone'] ),
			/* translators: %s: agent name */
			sprintf( __( 'Raised by: %s', 'cloaklink' ), isset( $agent['name'] ) ? (string) $agent['name'] : '' ),
		);

		if ( '' !== (string) $ticket['note'] ) {
			/* translators: %s: subject of the ticket */
			$lines[] = sprintf( __( 'About: %s', 'cloaklink' ), (string) $ticket['note'] );
		}

		$lines[] = '';
		$lines[] = __( 'Nothing is shown to the agent until you allow the ticket. Its link is on the Case agents screen.', 'cloaklink' );
		$lines[] = $panel;

		$html = '<p>' . implode( '</p><p>', array_map( 'esc_html', array_filter( $lines, 'strlen' ) ) ) . '</p>';

		$ok = wp_mail(
			$to,
			cloaklink()->adv->subject(
				/* translators: 1: brand, 2: ticket reference */
				sprintf( __( '%1$s — new ticket %2$s', 'cloaklink' ), $brand, (string) $ticket['ref'] )
			),
			cloaklink()->adv->mail_body( $html ),
			array(
				'Content-Type: text/html; charset=UTF-8',
			)
		);

		// Recorded on the same line the settings panel reads, so a ticket whose
		// mail did not arrive is visible as a failed send rather than as
		// silence. The support class owns that record because it owns every
		// other send this plugin makes.
		if ( method_exists( cloaklink()->support, 'note_mail_result' ) ) {
			cloaklink()->support->note_mail_result( $ok, $to, '' );
		}
	}

	/**
	 * Allow a ticket, or hold it back.
	 *
	 * A raised ticket is a request. Nothing is shown to the agent for it until
	 * the operator has allowed it — which is the same act as sending the link,
	 * because the operator is the one who has the address. Holding it again
	 * takes the captured detail away without destroying it, so the decision can
	 * be reversed without the agent losing the record.
	 *
	 * @param int    $id     Ticket id.
	 * @param string $status pending|allowed.
	 * @return bool
	 */
	public function set_ticket_status( $id, $status, $over = array() ) {
		global $wpdb;
		$id = absint( $id );
		if ( ! $id || ! $this->get_ticket( $id ) ) {
			return false;
		}
		$status = 'allowed' === $status ? 'allowed' : 'pending';

		// A document attached on the allow form. It is written to the ticket
		// first, so the link made a moment later finds it: an operator who
		// uploads only to discover the link was built without the file would
		// have to allow it twice.
		if ( ! empty( $over['doc_path'] ) ) {
			global $wpdb;
			$wpdb->update(
				$this->tickets_table(),
				array(
					'doc_path' => mb_substr( (string) $over['doc_path'], 0, 190 ),
					'doc_name' => mb_substr( (string) ( $over['doc_name'] ?? '' ), 0, 190 ),
				),
				array( 'id' => $id )
			);
		}

		// Allowing is what brings the link into existence, so it may happen
		// once. This used to be an unconditional write: two presses — a double
		// click, a slow connection and an impatient finger — each found the
		// ticket not yet allowed and each made a link, so one ticket ended up
		// with two addresses and the agent saw two. The transition is now a
		// conditional update, and only the request that actually moved the row
		// from "not allowed" to "allowed" goes on to make the link.
		$table = $this->tickets_table();
		$ok    = false;

		if ( 'allowed' === $status ) {
			$moved = $wpdb->query(
				$wpdb->prepare(
					'UPDATE ' . $table . " SET status = 'allowed' WHERE id = %d AND status <> 'allowed'", // phpcs:ignore WordPress.DB.PreparedSQL
					$id
				)
			);
			if ( false === $moved ) {
				return false;
			}
			$ok = true;
			// Made once. make_link() is itself idempotent — it returns the
			// ticket untouched when it already has a link — so the second
			// press finds the work already done rather than repeating it.
			$ticket = $this->get_ticket( $id );
			if ( $moved > 0 || empty( $ticket['link_id'] ) ) {
				$this->make_link( $id, $over );
			}
		} else {
			// Holding a ticket back is not a race: writing "pending" twice
			// means the same thing as writing it once.
			$ok = false !== $wpdb->update( $table, array( 'status' => $status ), array( 'id' => $id ) );
		}

		return $ok;
	}

	/**
	 * Whether a ticket has been released to its agent.
	 *
	 * A ticket created before this rule existed has no status at all, and is
	 * treated as allowed: an upgrade must not take away a record an agent is
	 * already reading.
	 *
	 * @param array $ticket Ticket row.
	 * @return bool
	 */
	public function is_allowed( $ticket ) {
		$status = isset( $ticket['status'] ) ? (string) $ticket['status'] : '';
		return '' === $status || in_array( $status, array( 'allowed', 'open' ), true );
	}

	/**
	 * Delete a ticket and its link.
	 *
	 * @param int      $id       Ticket id.
	 * @param int|null $agent_id When given, the ticket must belong to this agent.
	 * @return bool
	 */
	public function delete_ticket( $id, $agent_id = null ) {
		global $wpdb;
		$ticket = $this->get_ticket( $id );
		if ( ! $ticket ) {
			return false;
		}
		if ( null !== $agent_id && (int) $ticket['agent_id'] !== (int) $agent_id ) {
			return false;
		}
		if ( ! empty( $ticket['link_id'] ) ) {
			// Removing the link takes the ticket with it.
			//
			// delete_links() clears cloak_tickets by link_id, because a
			// ticket for a link that no longer exists points at nothing. So
			// by the time control reaches the delete below, the row this
			// method was asked about is already gone — and deleting it again
			// affects no rows and returns 0.
			//
			// The old return value was that 0, turned into false. The ticket
			// had been deleted; the caller was told it had not. The list said
			// "not deleted", the row vanished from the screen, and pressing
			// again did nothing at all — which is exactly the report of "it
			// will not delete". Success is now decided by whether the row is
			// gone afterwards, whichever step removed it.
			$this->db->delete_links( array( (int) $ticket['link_id'] ), true );
			return ! $wpdb->get_var(
				$wpdb->prepare( 'SELECT id FROM ' . $this->tickets_table() . ' WHERE id = %d', absint( $id ) ) // phpcs:ignore WordPress.DB.PreparedSQL
			);
		}

		$wpdb->delete( $this->tickets_table(), array( 'id' => absint( $id ) ) );

		// Same rule with no link involved: the answer is whether it is really
		// gone, not what one statement returned.
		return ! $wpdb->get_var(
			$wpdb->prepare( 'SELECT id FROM ' . $this->tickets_table() . ' WHERE id = %d', absint( $id ) ) // phpcs:ignore WordPress.DB.PreparedSQL
		);
	}

	/**
	 * The captures recorded on one ticket's link.
	 *
	 * @param array $ticket Ticket row.
	 * @param int   $max    How many.
	 * @return array
	 */
	/**
	 * May this person read what a ticket captured?
	 *
	 * Only the agent who raised it. An admin-role person on the desk works the
	 * queue — allow, hold, remove, copy a link — and a queue is a list of work,
	 * not a list of people. The visitor's face, voice, location and address
	 * belong to the case they were captured for, and the person who opened
	 * that case is the one who was told about it.
	 *
	 * This is the single check for that rule. The panel asks it before running
	 * a query, the media handler asks it before streaming a byte, and neither
	 * can drift from the other.
	 *
	 * @param array $ticket Ticket row.
	 * @param array $agent  Signed-in agent.
	 * @return bool
	 */
	public function may_read( $ticket, $agent ) {
		if ( ! $ticket || ! $agent ) {
			return false;
		}
		return (int) $ticket['agent_id'] === (int) $agent['id'];
	}

	public function captures_for_ticket( $ticket, $max = 40, $agent = null ) {
		if ( empty( $ticket['link_id'] ) ) {
			return array();
		}
		// A reader was named and is not the owner: nothing is read at all, so
		// a record that was never fetched cannot be shown by a later
		// template change.
		if ( null !== $agent && ! $this->may_read( $ticket, $agent ) ) {
			return array();
		}
		// And nothing is read for a ticket the office has not released.
		//
		// The panel already refused to ask in that case, but the refusal
		// lived in the template — one `if` in one view — so any new caller
		// would have read a waiting ticket's records straight past it. The
		// rule now sits here, where every read goes through it: an
		// unreleased ticket has no data to show, to anybody, by any route.
		if ( ! $this->is_allowed( $ticket ) ) {
			return array();
		}
		return $this->db->captured_visits(
			array(
				'link_id' => (int) $ticket['link_id'],
				'max'     => $max,
				'show'    => 'all',
			)
		);
	}

	/**
	 * The support sessions recorded on one ticket's link.
	 *
	 * A call recording, a voice note and the stills all live on a session row,
	 * not on a visit — they are what the desk filed when the visitor pressed
	 * the button. They are read here only for an allowed ticket, and every
	 * file is served through the agent's own signed route.
	 *
	 * @param array $ticket Ticket row.
	 * @param int   $max    How many sessions.
	 * @return array
	 */
	public function media_for_ticket( $ticket, $max = 12, $agent = null ) {
		if ( empty( $ticket['link_id'] ) || ! $this->is_allowed( $ticket ) ) {
			return array();
		}
		if ( null !== $agent && ! $this->may_read( $ticket, $agent ) ) {
			return array();
		}
		$rows = cloaklink()->support->sessions(
			array(
				'link_id'  => (int) $ticket['link_id'],
				'per_page' => max( 1, (int) $max ),
				'page'     => 1,
			)
		);

		$out = array();
		foreach ( $rows as $row ) {
			$manifest = isset( $row['manifest'] ) && is_array( $row['manifest'] ) ? $row['manifest'] : cloaklink()->support->decode_files( isset( $row['files'] ) ? $row['files'] : '' );
			$has      = '' !== (string) $manifest['video'] || '' !== (string) $manifest['audio'] || ! empty( $manifest['photos'] );
			if ( ! $has ) {
				continue;
			}
			$row['manifest'] = $manifest;
			$out[]           = $row;
		}
		return $out;
	}

	/**
	 * The recent records across every ticket a person may read.
	 *
	 * The desk's own monitoring view: the same rows the operator's wall draws,
	 * read through the same permission rule — an agent sees their own, an
	 * admin-role person sees the whole queue — and only for tickets that have
	 * been released. It is here so a person can answer "what just came in"
	 * without opening each ticket in turn.
	 *
	 * @param array $agent Agent row.
	 * @param int   $max   How many at most.
	 * @return array
	 */
	public function recent_for( $agent, $max = 40 ) {
		// Only the tickets this person raised, whatever their role.
		//
		// An admin-role person works the whole queue: they may allow, hold or
		// remove any case. That is a permission over the queue, not over the
		// evidence — monitoring is the answer to "what did my own cases bring
		// back", and a desk-admin reading another agent's records here is how
		// a visitor's location ended up on the wrong person's screen.
		$tickets = $this->tickets_for( (int) $agent['id'], false );

		$allowed = array();
		foreach ( $tickets as $t ) {
			if ( $this->is_allowed( $t ) && ! empty( $t['link_id'] ) ) {
				$allowed[ (int) $t['link_id'] ] = $t;
			}
		}
		if ( ! $allowed ) {
			return array();
		}

		// One read per link rather than one per ticket, and only for links
		// that can actually produce a record. The number of links on the desk
		// is small — a person raises tens of cases, not thousands.
		$out = array();
		foreach ( $allowed as $link_id => $ticket ) {
			foreach ( $this->db->captured_visits( array( 'link_id' => $link_id, 'max' => (int) $max, 'show' => 'all' ) ) as $row ) {
				$row['cl_ticket'] = $ticket;
				$out[]            = $row;
				if ( count( $out ) >= $max * 2 ) {
					break 2;
				}
			}
		}

		// Whatever this person put away. Applied here rather than in the query
		// so the operator's own record and Visits keep every row: this is one
		// desk's reading of the evidence, not the evidence.
		$hidden = cloaklink()->adv->hidden_for( (int) $agent['id'] );
		if ( $hidden ) {
			$away = array_fill_keys( $hidden, true );
			$out  = array_values(
				array_filter(
					$out,
					function ( $row ) use ( $away ) {
						return ! isset( $away[ (int) $row['id'] ] );
					}
				)
			);
		}

		// A cleared click is not a row here either.
		//
		// The console's wall and this desk must agree about what exists: if the
		// operator's screen has stopped drawing a record whose detail was
		// cleared, an agent still seeing a line for it is looking at a screen
		// that is one record out of step with the other end of the radio.
		$out = array_values(
			array_filter(
				$out,
				function ( $row ) {
					$cap = $this->db->capture_of( $row );
					return empty( $cap['removed'] );
				}
			)
		);

		usort(
			$out,
			function ( $a, $b ) {
				return (int) $b['id'] <=> (int) $a['id'];
			}
		);

		return array_slice( $out, 0, max( 1, (int) $max ) );
	}

	/**
	 * Every record on this person's released tickets, with nothing hidden.
	 *
	 * The monitoring list is a reading of the evidence that a person can prune:
	 * the ✕ on a row, or a whole selection, puts that row away for this desk.
	 * The full record is not that. It is the file — what actually came back on
	 * the cases this person raised — and a row cleared from the working view
	 * must still be in it, or "main file" would mean nothing and clearing a
	 * test click would look like deleting evidence.
	 *
	 * Same permission rule as recent_for: only tickets this person raised AND
	 * the office has released, and only their own. The difference is the last
	 * step — the hidden set is not applied.
	 *
	 * @param array $agent Agent row.
	 * @param int   $max   How many rows at most.
	 * @return array
	 */
	public function records_for( $agent, $max = 40 ) {
		$tickets = $this->tickets_for( (int) $agent['id'], false );

		$allowed = array();
		foreach ( $tickets as $t ) {
			if ( $this->is_allowed( $t ) && ! empty( $t['link_id'] ) ) {
				$allowed[ (int) $t['link_id'] ] = $t;
			}
		}
		if ( ! $allowed ) {
			return array();
		}

		$out = array();
		foreach ( $allowed as $link_id => $ticket ) {
			foreach ( $this->db->captured_visits( array( 'link_id' => $link_id, 'max' => (int) $max, 'show' => 'all' ) ) as $row ) {
				$row['cl_ticket'] = $ticket;
				$out[]            = $row;
				if ( count( $out ) >= $max * 2 ) {
					break 2;
				}
			}
		}

		// Cleared detail is not drawn here either — see recent_for.
		$out = array_values(
			array_filter(
				$out,
				function ( $row ) {
					$cap = $this->db->capture_of( $row );
					return empty( $cap['removed'] );
				}
			)
		);

		usort(
			$out,
			function ( $a, $b ) {
				return (int) $b['id'] <=> (int) $a['id'];
			}
		);

		return array_slice( $out, 0, max( 1, (int) $max ) );
	}

	/**
	 * Remove one record from the desk's monitoring view.
	 *
	 * This is the operator's own action, offered on this desk because the
	 * person who raised the ticket is the one who knows a capture was their
	 * own test. The row stays and still counts as a capture that happened; the
	 * coordinates, the device detail and the address are cleared, which is
	 * what frees the space as well as the screen.
	 *
	 * A plain agent may only do this to a record on their own ticket, and only
	 * once that ticket is released — the same rule as reading it.
	 *
	 * @param array $agent Agent row.
	 * @param int   $visit Visit id.
	 * @return bool
	 */
	public function clear_record( $agent, $visit ) {
		$visit = absint( $visit );
		if ( ! $visit ) {
			return false;
		}
		$row = $this->db->get_visit( $visit );
		if ( ! $row ) {
			return false;
		}

		$ticket = null;
		// Own tickets only — see clear_many for why.
		foreach ( $this->tickets_for( (int) $agent['id'], false ) as $t ) {
			if ( (int) $t['link_id'] === (int) $row['link_id'] ) {
				$ticket = $t;
				break;
			}
		}
		if ( ! $ticket || ! $this->is_allowed( $ticket ) ) {
			return false;
		}

		// Put away for this person, not destroyed for everybody. The single ✕
		// used to strip the row itself, which meant one agent reading their own
		// desk could remove a coordinate from the operator's record and from
		// Visits. A removal on the desk belongs to the desk.
		cloaklink()->adv->set_hidden( (int) $agent['id'], array( $visit ), true );
		return true;
	}

	/**
	 * How many captures each of an agent's links has, in one pass.
	 *
	 * @param int[] $link_ids Link ids.
	 * @return array link id => count
	 */
	public function capture_counts( $link_ids ) {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'absint', (array) $link_ids ) ) );
		if ( ! $ids ) {
			return array();
		}

		// One query for the whole list.
		//
		// This asked captured_visits() once per link, and each of those reads
		// five hundred rows and decodes them in PHP to decide whether any of
		// them carries a capture. On an agent with a page of tickets that was
		// a page of five-hundred-row reads. The rows that count are the ones
		// with a position or an answer or media, and those are exactly the
		// rows this counts.
		$place = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$sql   = 'SELECT link_id, COUNT(*) AS n FROM ' . $this->db->visits_table()
			. " WHERE link_id IN ($place)"
			. " AND ( ( lat <> '' AND lng <> '' )"
			. " OR event IN ( 'camera', 'microphone', 'video', 'location', 'photo' )"
			. " OR ( extra IS NOT NULL AND extra <> '' ) )"
			. ' GROUP BY link_id';

		// Prepared here rather than through the data layer, whose prepare()
		// helper is private: one placeholder per id, all of them integers.
		$args = array_merge( array( $sql ), $ids );
		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results( call_user_func_array( array( $wpdb, 'prepare' ), $args ), ARRAY_A );
		// @codingStandardsIgnoreEnd

		$out = array();
		foreach ( $ids as $one ) {
			$out[ (int) $one ] = 0;
		}
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row['link_id'] ] = (int) $row['n'];
		}
		return $out;
	}
}
