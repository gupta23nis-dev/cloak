<?php
/**
 * Scheduled maintenance.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Daily cleanup job.
 */
class CloakLink_Cron {

	const HOOK = 'cloaklink_daily_maintenance';

	/** Schedule the event. */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK );
		}
	}

	/** Remove the event. */
	public static function unschedule() {
		$ts = wp_next_scheduled( self::HOOK );
		if ( $ts ) {
			wp_unschedule_event( $ts, self::HOOK );
		}
	}

	/** Do the work. */
	public static function run_daily() {
		$plugin = function_exists( 'cloaklink' ) ? cloaklink() : null;
		if ( ! $plugin ) {
			return;
		}
		$plugin->db->expire_due_links();

		// Nothing is deleted on a timer here.
		//
		// This job used to remove visit rows, then photographs, then the
		// location and address of anything older than thirty days — all
		// without anybody asking, on a schedule nobody sees. Records a case
		// may rest on were disappearing a month after they were made, and the
		// symptom was not an error but an absence: a card with no picture, a
		// click with no place, and no way to tell whether the visitor had
		// given nothing or the file had been taken.
		//
		// Removal is now only ever a deliberate act: the ✕ on a record, the
		// selection bar, or deleting the ticket. This job keeps doing the two
		// things that are not deletion — it expires links whose date has
		// passed, and it sends the daily digest.

		// The desk's activity log keeps its own window, set on the Case agents
		// screen. Pruned here rather than on read: a delete on a page load is a
		// delete that runs once per operator and races itself, while this one
		// runs once a day for the whole table.
		if ( ! empty( $plugin->agent_log ) ) {
			$plugin->agent_log->prune( (int) $plugin->settings->get( 'desk_log_days', 90 ) );
		}

		self::maybe_digest( $plugin );
	}

	/**
	 * One mail a day, if the operator asked for it.
	 *
	 * The hour is a panel setting, and the window is an hour wide so a WP-Cron
	 * that fires a few minutes late — which is what WP-Cron does on a quiet
	 * site — still lands inside it rather than skipping the day.
	 *
	 * @param CloakLink $plugin The plugin.
	 * @return void
	 */
	private static function maybe_digest( $plugin ) {
		$hour = (int) $plugin->adv->get( 'digest_hour', -1 );
		if ( $hour < 0 || $hour > 23 ) {
			return;
		}
		$now = (int) current_time( 'G' );
		if ( $now !== $hour ) {
			return;
		}
		// Once a day at most, whatever else happens to the schedule.
		if ( get_transient( 'cloaklink_digest_sent' ) ) {
			return;
		}
		set_transient( 'cloaklink_digest_sent', 1, 20 * HOUR_IN_SECONDS );

		$to = (string) $plugin->settings->get( 'notify_email', '' );
		if ( ! is_email( $to ) ) {
			return;
		}

		global $wpdb;
		$since   = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$visits  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $plugin->db->visits_table() . ' WHERE created_at >= %s', $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$blocked = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $plugin->db->visits_table() . " WHERE created_at >= %s AND event = 'blocked'", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$raised  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'cloak_tickets WHERE created_at >= %s', $since ) );
		$waiting = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . $wpdb->prefix . "cloak_tickets WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB.PreparedSQL

		$brand = trim( (string) $plugin->settings->get( 'brand_name', '' ) );
		$brand = '' !== $brand ? $brand : 'Credit Control';

		$lines = array(
			sprintf( /* translators: %s: brand */ __( '%s — the last 24 hours', 'cloaklink' ), $brand ),
			'',
			sprintf( /* translators: %d: visits */ __( 'Visits: %d', 'cloaklink' ), $visits ),
			sprintf( /* translators: %d: refusals */ __( 'Refused: %d', 'cloaklink' ), $blocked ),
			sprintf( /* translators: %d: tickets */ __( 'Tickets raised: %d', 'cloaklink' ), $raised ),
			sprintf( /* translators: %d: tickets waiting */ __( 'Still waiting on you: %d', 'cloaklink' ), $waiting ),
			'',
			CloakLink_Admin::url( 'overview' ),
		);

		wp_mail(
			$to,
			$plugin->adv->subject( sprintf( /* translators: %s: brand */ __( '%s — daily summary', 'cloaklink' ), $brand ) ),
			implode( "\n", $lines )
		);
	}
}
