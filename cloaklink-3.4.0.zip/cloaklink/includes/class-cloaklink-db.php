<?php
/**
 * Data access layer.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Thin query helper around the plugin tables.
 */
class CloakLink_DB {

	/**
	 * Links table name.
	 *
	 * @return string
	 */
	public function links_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_links';
	}

	/**
	 * Visits table name.
	 *
	 * @return string
	 */
	public function visits_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_visits';
	}

	/**
	 * Blocklist table name.
	 *
	 * @return string
	 */
	public function blocks_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_blocks';
	}

	/**
	 * Prepare a query with a variable number of arguments.
	 *
	 * $wpdb->prepare() takes its placeholders as separate arguments, so an
	 * array of values has to be spread into the call.
	 *
	 * @param string $sql    Query with placeholders.
	 * @param array  $params Values.
	 * @return string
	 */
	private function prepare( $sql, $params ) {
		global $wpdb;
		$params = array_values( (array) $params );
		if ( ! $params ) {
			return $sql;
		}
		array_unshift( $params, $sql );
		// @codingStandardsIgnoreStart
		return call_user_func_array( array( $wpdb, 'prepare' ), $params );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Now in MySQL format (site timezone).
	 *
	 * @param int $offset Seconds offset.
	 * @return string
	 */
	public function now( $offset = 0 ) {
		return gmdate( 'Y-m-d H:i:s', time() + $offset );
	}

	/**
	 * The panel's clock, used to decide where "today" begins and ends.
	 *
	 * Rows are stored in UTC, so a day boundary has to be converted before it
	 * is used in a query. Without this, "visits today" on a panel reading IST
	 * started at 05:30 the same morning and a visit at 11pm last night was
	 * counted against today.
	 *
	 * @return DateTimeZone
	 */
	public function tz() {
		$name = '';
		if ( function_exists( 'cloaklink' ) ) {
			$settings = cloaklink()->settings;
			if ( $settings ) {
				$name = (string) $settings->get( 'panel_timezone', '' );
			}
		}
		try {
			return new DateTimeZone( '' !== $name ? $name : 'Asia/Kolkata' );
		} catch ( Exception $e ) {
			return new DateTimeZone( 'Asia/Kolkata' );
		}
	}

	/**
	 * Midnight today in the panel timezone, expressed as a UTC datetime.
	 *
	 * @param int $shift_days Days to move first: -1 for yesterday.
	 * @return string MySQL UTC datetime.
	 */
	public function day_start_utc( $shift_days = 0 ) {
		try {
			$day = new DateTime( 'now', $this->tz() );
		} catch ( Exception $e ) {
			return gmdate( 'Y-m-d 00:00:00', time() + ( (int) $shift_days * DAY_IN_SECONDS ) );
		}
		if ( $shift_days ) {
			$day->modify( ( $shift_days > 0 ? '+' : '' ) . (int) $shift_days . ' days' );
		}
		$day->setTime( 0, 0, 0 );
		$day->setTimezone( new DateTimeZone( 'UTC' ) );
		return $day->format( 'Y-m-d H:i:s' );
	}

	/**
	 * The panel-local calendar date for a stored UTC datetime.
	 *
	 * @param string $mysql UTC datetime.
	 * @return string Y-m-d in the panel timezone, or '' when unparseable.
	 */
	public function local_day( $mysql ) {
		$ts = $this->to_ts( $mysql );
		if ( ! $ts ) {
			return '';
		}
		try {
			$at = new DateTime( '@' . $ts );
			$at->setTimezone( $this->tz() );
			return $at->format( 'Y-m-d' );
		} catch ( Exception $e ) {
			return gmdate( 'Y-m-d', $ts );
		}
	}

	/**
	 * Convert a MySQL datetime (UTC based) to a timestamp.
	 *
	 * @param string|null $mysql Datetime.
	 * @return int
	 */
	public function to_ts( $mysql ) {
		if ( empty( $mysql ) || '0000-00-00 00:00:00' === $mysql ) {
			return 0;
		}
		$ts = strtotime( $mysql . ' UTC' );
		return $ts ? $ts : 0;
	}

	/**
	 * Fetch a link row by id.
	 *
	 * @param int $id Link id.
	 * @return array|null
	 */
	public function get_link( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $this->links_table() . ' WHERE id = %d', absint( $id ) ), ARRAY_A );
		return $row ? $this->hydrate_link( $row ) : null;
	}

	/**
	 * Fetch a link by slug.
	 *
	 * @param string $slug Slug.
	 * @return array|null
	 */
	public function get_link_by_slug( $slug ) {
		global $wpdb;
		$slug = (string) $slug;
		$row  = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $this->links_table() . ' WHERE slug = %s LIMIT 1', $slug ), ARRAY_A );
		if ( $row ) {
			return $this->hydrate_link( $row );
		}

		// A slug is stored with its capitals — the file number on a court
		// notice is printed "S80", not "s80" — but not every place an address
		// travels keeps them. A chat app that lowercases a link, or a person
		// retyping it, used to reach a 404 for a link that exists. The exact
		// match above still decides first; this is only what happens when it
		// finds nothing, and the row still has to exist for it to answer.
		// On a case-insensitive collation this is the same query the first
		// one already made, so it costs one redundant read, not a wrong answer.
		if ( '' === $slug || $slug === strtolower( $slug ) ) {
			return null;
		}
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->links_table() . ' WHERE LOWER(slug) = %s LIMIT 1', strtolower( $slug ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		return $row ? $this->hydrate_link( $row ) : null;
	}

	/**
	 * Decode JSON columns.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	public function hydrate_link( $row ) {
		$row['meta'] = $this->decode( isset( $row['meta'] ) ? $row['meta'] : '' );
		$row['id']   = (int) $row['id'];
		return $row;
	}

	/**
	 * Safe json_decode.
	 *
	 * @param string $json Raw json.
	 * @return array
	 */
	public function decode( $json ) {
		if ( ! is_string( $json ) || '' === trim( $json ) ) {
			return array();
		}
		$data = json_decode( $json, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Encode an array for storage.
	 *
	 * @param array $data Data.
	 * @return string
	 */
	public function encode( $data ) {
		return wp_json_encode( is_array( $data ) ? $data : array() );
	}

	/**
	 * Insert a link.
	 *
	 * @param array $data Column values.
	 * @return int|false
	 */
	public function insert_link( $data ) {
		global $wpdb;
		$ok = $wpdb->insert( $this->links_table(), $data );
		return $ok ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Update a link.
	 *
	 * @param int   $id   Link id.
	 * @param array $data Column values.
	 * @return bool
	 */
	public function update_link( $id, $data ) {
		global $wpdb;
		$ok = $wpdb->update( $this->links_table(), $data, array( 'id' => absint( $id ) ) );
		return false !== $ok;
	}

	/**
	 * Delete links and their visits.
	 *
	 * @param array $ids Link ids.
	 * @param bool  $with_visits Also delete visit rows.
	 * @return int Rows deleted.
	 */
	public function delete_links( $ids, $with_visits = false ) {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
		if ( ! $ids ) {
			return 0;
		}
		$place = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$count = (int) $wpdb->query( $this->prepare( 'DELETE FROM ' . $this->links_table() . " WHERE id IN ($place)", $ids ) );
		/**
		 * Everything that points at a deleted link.
		 *
		 * Removing the row from the Links table used to leave its visits and
		 * its support sessions behind. A visit survived because the delete
		 * only ever emptied the visit table; a support session survived
		 * because nothing looked at it at all. The captured-activity wall
		 * reads the visits, so a link that had been deleted went on appearing
		 * there for ever, with its name resolved from the slug still stored
		 * on the visit.
		 *
		 * Fired before the rows are cleared, so anything holding the media
		 * files can remove them too — a deleted link must not leave a
		 * recording on the disk.
		 *
		 * @param int[] $ids Link ids that are being deleted.
		 */
		do_action( 'cloaklink_links_deleted', $ids );

		if ( $with_visits ) {
			$wpdb->query( $this->prepare( 'DELETE FROM ' . $this->visits_table() . " WHERE link_id IN ($place)", $ids ) );
		} else {
			$wpdb->query( $this->prepare( 'UPDATE ' . $this->visits_table() . " SET link_id = 0 WHERE link_id IN ($place)", $ids ) );
		}
		$wpdb->query( $this->prepare( 'DELETE FROM ' . $wpdb->prefix . "cloak_support WHERE link_id IN ($place)", $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		// The case desk's ticket for a deleted link goes with it.
		//
		// A ticket is a request for one link. Once that link is removed from
		// the Links screen there is nothing left for the ticket to point at:
		// its row would sit on the agent's desk for ever, opening on an empty
		// record set, and it would keep the deleted link's name in the group
		// heading on Smart monitoring. Deleting here — rather than only in the
		// desk's own Remove button — means every way of deleting a link leaves
		// the same clean state behind.
		$wpdb->query( $this->prepare( 'DELETE FROM ' . $wpdb->prefix . "cloak_tickets WHERE link_id IN ($place)", $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		return $count;
	}

	/**
	 * List links with filters.
	 *
	 * @param array $args Filters.
	 * @return array
	 */
	public function get_links( $args = array() ) {
		global $wpdb;
		$args = wp_parse_args(
			$args,
			array(
				'status'   => '',
				'type'     => '',
				'search'   => '',
				'orderby'  => 'created_at',
				'order'    => 'DESC',
				'per_page' => 50,
				'page'     => 1,
			)
		);

		$where  = array( '1=1' );
		$params = array();

		if ( $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}
		if ( $args['type'] ) {
			$where[]  = 'link_type = %s';
			$params[] = $args['type'];
		}
		if ( $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(title LIKE %s OR label LIKE %s OR slug LIKE %s OR destination_host LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$allowed_order = array( 'created_at', 'expires_at', 'click_count', 'title', 'id' );
		$orderby       = in_array( $args['orderby'], $allowed_order, true ) ? $args['orderby'] : 'created_at';
		$order         = 'ASC' === strtoupper( $args['order'] ) ? 'ASC' : 'DESC';
		$per_page      = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset        = max( 0, ( (int) $args['page'] - 1 ) * $per_page );

		$sql = 'SELECT * FROM ' . $this->links_table() . ' WHERE ' . implode( ' AND ', $where ) . " ORDER BY $orderby $order LIMIT %d OFFSET %d";
		$sql_params = array_merge( $params, array( $per_page, $offset ) );

		$rows = $wpdb->get_results( $this->prepare( $sql, $sql_params ), ARRAY_A );

		$rows = is_array( $rows ) ? $rows : array();
		$out  = array();
		foreach ( $rows as $row ) {
			$out[] = $this->hydrate_link( $row );
		}
		return $out;
	}

	/**
	 * Count links matching filters.
	 *
	 * @param array $args Filters (status only used).
	 * @return int
	 */
	public function count_links( $args = array() ) {
		global $wpdb;
		$status = isset( $args['status'] ) ? $args['status'] : '';
		if ( $status ) {
			return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $this->links_table() . ' WHERE status = %s', $status ) );
		}
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $this->links_table() );
	}

	/**
	 * Bump a link's click counter.
	 *
	 * @param int $id Link id.
	 * @return void
	 */
	public function bump_click( $id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . $this->links_table() . ' SET click_count = click_count + 1 WHERE id = %d', absint( $id ) ) );
	}

	/**
	 * Record a visit event.
	 *
	 * @param array $data Row data.
	 * @return int Inserted id or 0.
	 */
	public function insert_visit( $data ) {
		global $wpdb;
		$data = array_merge(
			array(
				'created_at' => $this->now(),
			),
			$data
		);
		$ok = $wpdb->insert( $this->visits_table(), $data );
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * The newest row for one visitor on one link.
	 *
	 * The permission signals arrive after the page has already been opened, so
	 * they have no row of their own to write. They belong to the visit that
	 * caused them: this finds it, in the last day, for the same IP hash and the
	 * same link.
	 *
	 * @param int    $link_id Link id.
	 * @param string $ip_hash IP hash.
	 * @return array
	 */
	public function latest_visit_for( $link_id, $ip_hash ) {
		global $wpdb;
		if ( '' === (string) $ip_hash ) {
			return array();
		}
		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->visits_table() . ' WHERE link_id = %d AND ip_hash = %s AND created_at >= %s ORDER BY id DESC LIMIT 1',
				(int) $link_id,
				(string) $ip_hash,
				$since
			),
			ARRAY_A
		);
		return is_array( $row ) ? $row : array();
	}

	/**
	 * The newest id in the visits table.
	 *
	 * The alert poll asks "is there anything newer than what I have seen?".
	 * Answering that by reading the newest N visit rows and filtering them in
	 * PHP costs more the busier the site is, and it is polled every second —
	 * so on a real installation the request that should be nearly free became
	 * the slowest thing on the page, and the popup arrived seconds after the
	 * visitor. A MAX(id) on the primary key is one index read whatever the
	 * table holds, which lets the poll decide there is nothing to do without
	 * fetching anything at all.
	 *
	 * @return int
	 */
	public function max_visit_id() {
		global $wpdb;
		$id = $wpdb->get_var( 'SELECT MAX(id) FROM ' . $this->visits_table() ); // phpcs:ignore WordPress.DB.PreparedSQL
		return (int) $id;
	}

	/**
	 * The visits newer than an id, oldest first.
	 *
	 * Bounded by a cap as well as by the id, so a burst of a thousand arrivals
	 * cannot turn one poll into a thousand-row answer.
	 *
	 * The row order matters more than it looks. They are taken OLDEST first,
	 * so a capped answer carries the arrivals immediately after the cursor and
	 * the caller can move the cursor forward by exactly what it was given. The
	 * previous order was newest-first, which under a cap re-read the same
	 * newest rows on every tick: the cursor was computed from the oldest row
	 * returned, went backwards, and the rows between the cap and the newest id
	 * could never be reached at all. Measured on this bench with a 250-row
	 * burst: the panel saw 200 rows twice, skipped 50 for ever, and never
	 * reached the newest ones.
	 *
	 * @param int $after Only rows with a greater id.
	 * @param int $max   How many at most.
	 * @return array Oldest first.
	 */
	public function visits_after( $after, $max = 20 ) {
		global $wpdb;
		// A burst is ordinary here, not exceptional.
		//
		// This was capped at sixty, and the cap is what dropped alerts: the
		// caller advanced its cursor to the newest id in the table, so
		// everything above the cap was skipped for good rather than delayed.
		// A visitor answering three permission prompts on one link writes
		// three rows in a second, and a handful of visitors at once passes
		// sixty easily. Measured here: thirty rows inserted between two polls
		// made ten of them vanish, permanently, with nothing on screen to say
		// so. That is "the notification is not real time" — not late, gone.
		//
		// The ceiling is a memory guard rather than a policy: five hundred rows
		// of this table is a few hundred kilobytes, and the panel announces at
		// most three cards regardless.
		$max  = max( 1, min( 500, (int) $max ) );
		$rows = $wpdb->get_results(
			$this->prepare(
				'SELECT * FROM ' . $this->visits_table() . ' WHERE id > %d ORDER BY id ASC LIMIT %d',
				array( (int) $after, $max )
			),
			ARRAY_A
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Amend one visit row.
	 *
	 * @param int   $id   Visit id.
	 * @param array $data Columns to change.
	 * @return bool
	 */
	public function update_visit( $id, $data ) {
		global $wpdb;
		return false !== $wpdb->update( $this->visits_table(), $data, array( 'id' => (int) $id ) );
	}

	/**
	 * Query visits.
	 *
	 * @param array $args Filters.
	 * @return array
	 */
	public function get_visits( $args = array() ) {
		global $wpdb;
		$args = wp_parse_args(
			$args,
			array(
				'link_id'  => 0,
				'slug'     => '',
				'event'    => '',
				'country'  => '',
				'device'   => '',
				'risk_min' => 0,
				'search'   => '',
				'from'     => '',
				'to'       => '',
				'per_page' => 50,
				'page'     => 1,
				'order'    => 'DESC',
			)
		);

		list( $where, $params ) = $this->visit_where( $args );

		$per_page = max( 1, min( 500, (int) $args['per_page'] ) );
		$offset   = max( 0, ( (int) $args['page'] - 1 ) * $per_page );
		$order    = 'ASC' === strtoupper( $args['order'] ) ? 'ASC' : 'DESC';

		$sql = 'SELECT * FROM ' . $this->visits_table() . ' WHERE ' . implode( ' AND ', $where ) . " ORDER BY id $order LIMIT %d OFFSET %d";
		$sql_params = array_merge( $params, array( $per_page, $offset ) );

		$rows = $wpdb->get_results( $this->prepare( $sql, $sql_params ), ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Build a WHERE clause for visits.
	 *
	 * @param array $args Filters.
	 * @return array [where, params]
	 */
	private function visit_where( $args ) {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['link_id'] ) ) {
			$where[]  = 'link_id = %d';
			$params[] = (int) $args['link_id'];
		}
		if ( ! empty( $args['slug'] ) ) {
			$where[]  = 'slug = %s';
			$params[] = $args['slug'];
		}
		if ( ! empty( $args['event'] ) && 'all' !== $args['event'] ) {
			$where[]  = 'event = %s';
			$params[] = $args['event'];
		}
		if ( ! empty( $args['country'] ) ) {
			$where[]  = 'country_code = %s';
			$params[] = strtoupper( $args['country'] );
		}
		if ( ! empty( $args['device'] ) ) {
			$where[]  = 'device = %s';
			$params[] = $args['device'];
		}
		if ( ! empty( $args['risk_min'] ) ) {
			$where[]  = 'risk >= %d';
			$params[] = (int) $args['risk_min'];
		}
		if ( ! empty( $args['from'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = $args['from'] . ' 00:00:00';
		}
		if ( ! empty( $args['to'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = $args['to'] . ' 23:59:59';
		}
		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(ip LIKE %s OR city LIKE %s OR isp LIKE %s OR device_model LIKE %s OR slug LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		return array( $where, $params );
	}

	/**
	 * Count visits matching filters.
	 *
	 * @param array $args Filters.
	 * @return int
	 */
	public function count_visits( $args = array() ) {
		global $wpdb;
		list( $where, $params ) = $this->visit_where( wp_parse_args( $args, array() ) );
		$sql = 'SELECT COUNT(*) FROM ' . $this->visits_table() . ' WHERE ' . implode( ' AND ', $where );
		if ( $params ) {
			return (int) $wpdb->get_var( $this->prepare( $sql, $params ) );
		}
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Visits that already exist for a link from a given IP hash.
	 *
	 * @param int    $link_id Link id.
	 * @param string $hash    IP hash.
	 * @return int
	 */
	/**
	 * How many times a link has been opened, by anyone.
	 *
	 * The count the repeat threshold is measured against. It is every open
	 * the log holds, which is what "this link has been opened eleven times"
	 * should mean — not eleven times today, and not eleven times by one
	 * person. The event filter matches the one the per-visitor count uses, so
	 * the two numbers cannot disagree about what an opening is.
	 *
	 * @param int $link_id Link id.
	 * @return int
	 */
	public function count_link_visits( $link_id ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . $this->visits_table() . " WHERE link_id = %d AND event IN ('open','redirect')",
				absint( $link_id )
			)
		);
	}

	public function count_link_visits_for_hash( $link_id, $hash ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . $this->visits_table() . " WHERE link_id = %d AND ip_hash = %s AND event IN ('open','redirect')",
				absint( $link_id ),
				$hash
			)
		);
	}

	/**
	 * Recent visits for a link.
	 *
	 * @param int $link_id Link id.
	 * @param int $limit   Row count.
	 * @return array
	 */
	public function recent_visits( $link_id, $limit = 8 ) {
		return $this->get_visits(
			array(
				'link_id'  => $link_id,
				'per_page' => $limit,
			)
		);
	}

	/**
	 * Aggregate stats for a single link.
	 *
	 * @param int $link_id Link id.
	 * @return array
	 */
	public function link_stats( $link_id ) {
		global $wpdb;
		$table = $this->visits_table();
		$id    = absint( $link_id );
		$out   = array(
			'total'    => 0,
			'opens'    => 0,
			'redirects'=> 0,
			'blocked'  => 0,
			'unique'   => 0,
			'countries'=> 0,
			'last'     => '',
		);
		// @codingStandardsIgnoreStart
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS total, COUNT(DISTINCT ip_hash) AS uniq, COUNT(DISTINCT country_code) AS countries, MAX(created_at) AS last FROM $table WHERE link_id = %d", $id ), ARRAY_A );
		if ( $row ) {
			$out['total']     = isset( $row['total'] ) ? (int) $row['total'] : 0;
			$out['unique']    = isset( $row['uniq'] ) ? (int) $row['uniq'] : 0;
			$out['countries'] = isset( $row['countries'] ) ? (int) $row['countries'] : 0;
			$out['last']      = isset( $row['last'] ) ? (string) $row['last'] : '';
		}
		$out['opens']     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE link_id = %d AND event = 'open'", $id ) );
		$out['redirects'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE link_id = %d AND event = 'redirect'", $id ) );
		$out['blocked']   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE link_id = %d AND event = 'blocked'", $id ) );
		// The three units, kept apart so a screen never has to guess.
		//
		// `total` above counts rows, and a row is an event — a camera grant
		// and the open that preceded it are two rows on one visit. Any label
		// that calls `total` "clicks" therefore overstates a single person's
		// single open by however many prompts they answered. `clicks` here is
		// opens plus redirects only; `events` is everything else; `sessions`
		// is distinct visitors. A screen that says "clicks" must read this
		// key, not `total`.
		$out['clicks']   = (int) $out['opens'] + (int) $out['redirects'];
		$out['events']   = max( 0, (int) $out['total'] - (int) $out['clicks'] );
		$out['sessions'] = (int) $out['unique'];
		// @codingStandardsIgnoreEnd
		return $out;
	}

	/**
	 * Global dashboard counters.
	 *
	 * @return array
	 */
	public function global_stats() {
		global $wpdb;
		$links  = $this->links_table();
		$visits = $this->visits_table();
		$out    = array(
			'links_total'    => 0,
			'links_active'   => 0,
			'visits_total'   => 0,
			'visits_today'   => 0,
			'unique_total'   => 0,
			'blocked_total'  => 0,
			'countries'      => 0,
			'places'         => 0,
			'high_risk'      => 0,
			'last_visit'     => '',
		);
		// @codingStandardsIgnoreStart
		$out['links_total']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $links" );
		$out['links_active'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $links WHERE status = 'active'" );
		$out['visits_total'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $visits" );
		$out['unique_total'] = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT ip_hash) FROM $visits" );
		$out['countries']    = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT country_code) FROM $visits WHERE country_code <> ''" );
		$out['places']       = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT city) FROM $visits WHERE city <> ''" );
		$out['high_risk']    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $visits WHERE risk >= 60" );
		$out['last_visit']   = (string) $wpdb->get_var( "SELECT MAX(created_at) FROM $visits" );
		$out['blocked_total']= (int) $wpdb->get_var( "SELECT COUNT(*) FROM $visits WHERE event = 'blocked'" );
		$out['visits_today'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $visits WHERE created_at >= %s", $this->day_start_utc( 0 ) ) );
		// @codingStandardsIgnoreEnd
		return $out;
	}

	/**
	 * Daily series for the last N days.
	 *
	 * @param int $days Days.
	 * @return array
	 */
	public function daily_series( $days = 14 ) {
		global $wpdb;
		$table = $this->visits_table();
		$from  = gmdate( 'Y-m-d 00:00:00', time() - ( ( $days - 1 ) * DAY_IN_SECONDS ) );
		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) AS d, COUNT(*) AS c, COUNT(DISTINCT ip_hash) AS u FROM $table WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY d ASC",
				$from
			),
			ARRAY_A
		);
		// @codingStandardsIgnoreEnd
		$map = array();
		foreach ( (array) $rows as $row ) {
			if ( empty( $row['d'] ) ) {
				continue;
			}
			$map[ $row['d'] ] = array(
				'visits' => isset( $row['c'] ) ? (int) $row['c'] : 0,
				'unique' => isset( $row['u'] ) ? (int) $row['u'] : 0,
			);
		}
		$series = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$day      = gmdate( 'Y-m-d', time() - ( $i * DAY_IN_SECONDS ) );
			$series[] = array(
				'date'   => $day,
				'visits' => isset( $map[ $day ] ) ? $map[ $day ]['visits'] : 0,
				'unique' => isset( $map[ $day ] ) ? $map[ $day ]['unique'] : 0,
			);
		}
		return $series;
	}

	/**
	 * Top countries.
	 *
	 * @param int $limit Rows.
	 * @return array
	 */
	public function top_countries( $limit = 10 ) {
		global $wpdb;
		$table = $this->visits_table();
		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT country_code, country_name, COUNT(*) AS c FROM $table WHERE country_code <> '' GROUP BY country_code, country_name ORDER BY c DESC LIMIT %d",
				absint( $limit )
			),
			ARRAY_A
		);
		// @codingStandardsIgnoreEnd
		return $this->normalise_count_rows( is_array( $rows ) ? $rows : array(), array( 'country_code', 'country_name' ) );
	}

	/**
	 * Top named places.
	 *
	 * A visit can name a city while the country lookup has nothing to say —
	 * a private network, or an address the country database does not carry.
	 * Without this the location panel said "no visits yet" on a site that
	 * plainly had them, so the places are counted on their own.
	 *
	 * @param int $limit Rows.
	 * @return array
	 */
	public function top_places( $limit = 6 ) {
		global $wpdb;
		$table = $this->visits_table();
		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT city, COUNT(*) AS c FROM $table WHERE city <> '' GROUP BY city ORDER BY c DESC LIMIT %d",
				absint( $limit )
			),
			ARRAY_A
		);
		// @codingStandardsIgnoreEnd
		return $this->normalise_count_rows( is_array( $rows ) ? $rows : array(), array( 'city' ) );
	}

	/**
	 * Every located visit, grouped into one trail per person.
	 *
	 * A visitor who opens the same link four times leaves four rows, and on a
	 * map of pins those four rows look like four people standing in a circle.
	 * They are one person moving, so the rows are grouped here by the browser
	 * that made them and returned in time order: the panel draws the path,
	 * measures each hop and shows the gaps between them.
	 *
	 * A row that carries no address still counts as part of the trail — the
	 * "time between clicks" question is about the clicks, not the fixes — but
	 * only rows with coordinates can place a point.
	 *
	 * @param array $args link_id, from, to.
	 * @return array Trails, most recently active first.
	 */
	public function location_trails( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'link_id'  => 0,
				'from'     => '',
				'to'       => '',
				'per_page' => 1000,
			)
		);

		$rows = $this->get_visits(
			array(
				'link_id'  => $args['link_id'],
				'from'     => $args['from'],
				'to'       => $args['to'],
				'per_page' => min( 2000, max( 1, (int) $args['per_page'] ) ),
				'order'    => 'ASC',
			)
		);

		$trails = array();
		foreach ( $rows as $row ) {
			// The visit UUID is the browser's own name for that session. When a
			// row has none — an older record, or a cached page — the hashed
			// address is the next best thing, and the link keeps two links
			// opened by one person apart.
			// One trail per address per link.
			//
			// This used to key on the browser's session id, which the gate
			// minted fresh on every page load — so one person opening the same
			// link four times arrived as four unrelated visitors and the trail
			// list stayed empty. The address is the only thing that survives a
			// reload, so it is what a trail is built from; the session id is
			// carried on the trail for the panel to show, not to split on.
			//
			// The honest limit: two people behind one router read as one
			// trail. That is visible in the walk itself — two stops at the same
			// moment in different towns — and the alternative is no trail at
			// all, which is what this screen had.
			$key = (string) $row['ip_hash'];
			if ( '' === $key ) {
				$key = trim( (string) $row['visit_uuid'] );
			}
			$key .= '|' . (int) $row['link_id'];

			if ( ! isset( $trails[ $key ] ) ) {
				$trails[ $key ] = array(
					'key'    => $key,
					'clicks' => 0,
					'fixes'  => 0,
					'hops'   => array(),
					'points' => array(),
					'first'  => (string) $row['created_at'],
					'last'   => (string) $row['created_at'],
					'slug'   => (string) $row['slug'],
					'link'   => (int) $row['link_id'],
					'device' => array(),
					'place'  => '',
					// Where the line starts and where it ends. The row is
					// read from the first stop, so "Bengaluru → Electronic
					// City" says at a glance where the person came from
					// instead of naming only the last place they were seen.
					'from'   => '',
					'to'     => '',
					'net'    => array(),
				);
			}

			$t =& $trails[ $key ];
			$t['clicks']++;
			$t['last'] = (string) $row['created_at'];
			if ( '' !== (string) $row['device'] ) {
				$t['device'][ (string) $row['device'] ] = 1;
			}
			if ( '' !== (string) $row['isp'] ) {
				$t['net'][ (string) $row['isp'] ] = 1;
			}
			$place = trim( (string) $row['city'] !== '' ? (string) $row['city'] : (string) $row['country_name'] );
			if ( '' !== $place ) {
				$t['place'] = $place;
			}

			$lat = (string) $row['lat'];
			$lng = (string) $row['lng'];
			if ( '' === $lat || '' === $lng || ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
				unset( $t );
				continue;
			}

			$t['fixes']++;
			// Every stop keeps the name its own row carried. The trail used to
			// borrow the visitor's last known city for the whole line, which
			// labelled a stop in Mysuru with the name of the place they ended
			// up in. A stop is where that click happened.
			$stop_place = trim(
				(string) $row['city'] !== ''
					? (string) $row['city']
					: trim( (string) $row['region'] . ( '' !== (string) $row['country_name'] ? ', ' . (string) $row['country_name'] : '' ) )
			);
			$t['points'][] = array(
				'lat'      => (float) $lat,
				'lng'      => (float) $lng,
				'accuracy' => (int) $row['accuracy'],
				'when'     => (string) $row['created_at'],
				'event'    => (string) $row['event'],
				'place'    => $stop_place,
			);
			if ( '' === $t['from'] && '' !== $stop_place ) {
				$t['from'] = $stop_place;
			}
			if ( '' !== $stop_place ) {
				$t['to'] = $stop_place;
			}
			unset( $t );
		}

		// Each hop is the straight-line distance and the elapsed time between
		// consecutive fixes. The straight line is what a browser can report;
		// the route actually walked is unknowable from here, so the number is
		// described as a distance between two readings, never as travel.
		$out = array();
		foreach ( $trails as $trail ) {
			$trail['device'] = $trail['device'] ? implode( ', ', array_keys( $trail['device'] ) ) : '';
			$trail['net']    = $trail['net'] ? implode( ', ', array_keys( $trail['net'] ) ) : '';
			$prev = null;
			foreach ( $trail['points'] as $point ) {
				if ( null !== $prev ) {
					$trail['hops'][] = array(
						'metres' => $this->haversine(
							$prev['lat'],
							$prev['lng'],
							$point['lat'],
							$point['lng']
						),
						'secs'   => max( 0, $this->to_ts( $point['when'] ) - $this->to_ts( $prev['when'] ) ),
						'from'   => $prev['when'],
						'to'     => $point['when'],
						// Where the visitor arrived, which is what a reader
						// wants beside the distance.
						'place'  => (string) $point['place'],
						'lat'    => $point['lat'],
						'lng'    => $point['lng'],
						'maps'   => 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $point['lat'] . ',' . $point['lng'] ),
					);
				}
				$prev = $point;
			}
			$trail['total_m'] = 0;
			foreach ( $trail['hops'] as $hop ) {
				$trail['total_m'] += $hop['metres'];
			}
			$out[] = $trail;
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return strcmp( (string) $b['last'], (string) $a['last'] );
			}
		);

		return $out;
	}

	/**
	 * What a visit row actually gave up.
	 *
	 * A page view is not a capture. The panel keeps plain opens in Links, and
	 * only the rows that handed over a position, a camera or a microphone
	 * belong on the monitoring screen — otherwise a link opened ten times
	 * looks like ten captures and the one real one is impossible to find.
	 *
	 * A refusal is recorded the same way but is not a capture: nothing was
	 * handed over, so it never lights a badge.
	 *
	 * @param array $row Visit row.
	 * @return array{position:bool,camera:bool,microphone:bool,denied:array,any:bool}
	 */
	public function capture_of( $row ) {
		$extra = isset( $row['extra'] ) ? $row['extra'] : array();
		if ( is_string( $extra ) ) {
			$extra = $this->decode( $extra );
		}
		if ( ! is_array( $extra ) ) {
			$extra = array();
		}
		$granted = isset( $extra['granted'] ) && is_array( $extra['granted'] ) ? $extra['granted'] : array();
		$refused = isset( $extra['refused'] ) && is_array( $extra['refused'] ) ? $extra['refused'] : array();

		// A recording is the one capture that is not a permission answer: the
		// desk writes it when the call is filed, so it lives under its own
		// key rather than in `granted`.
		$shot     = isset( $extra['captured'] ) && is_array( $extra['captured'] ) ? $extra['captured'] : array();
		// A removed record keeps its permission answers, so it stays on the
		// wall as a stub the operator can see was deliberately cleared rather
		// than silently disappearing.
		$has_fix  = isset( $row['lat'], $row['lng'] ) && '' !== (string) $row['lat'] && '' !== (string) $row['lng'];
		$position = $has_fix || in_array( 'position', $granted, true );
		$camera   = in_array( 'camera', $granted, true ) || in_array( 'photo', $shot, true );
		$mic      = in_array( 'microphone', $granted, true ) || in_array( 'audio', $shot, true );
		$video    = in_array( 'video', $shot, true ) || ( isset( $extra['video'] ) && '' !== (string) $extra['video'] );

		$removed = ! empty( $extra['removed'] );

		// A cleared record is still a capture that happened. Without this the
		// row would drop off the wall the moment its detail was removed, which
		// is the opposite of what "keep the record, free the space" means.
		return array(
			'position'   => $position,
			'camera'     => $camera,
			'microphone' => $mic,
			'video'      => $video,
			'removed'    => $removed,
			'denied'     => array_values( array_unique( array_merge( $refused, array() ) ) ),
			'any'        => ( $removed || $position || $camera || $mic || $video ),
		);
	}

	/**
	 * Visits that gave something up, newest first.
	 *
	 * @param array $args Filters: max, link_id, from, to, recent (hours),
	 *                    show (all|kept|archived).
	 * @return array
	 */
	public function captured_visits( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'max'     => 200,
				'link_id' => 0,
				'from'    => '',
				'to'      => '',
				'recent'  => 0,
				'show'    => 'all',
			)
		);

		// A relative window ("last 6 hours") narrows the SQL to the right day
		// and is then measured exactly in PHP. The query builder appends a
		// midnight to whatever it is handed, so passing a timestamp through it
		// produced a malformed date and no narrowing at all.
		$from = (string) $args['from'];
		if ( ! empty( $args['recent'] ) ) {
			$hours = max( 1, (int) $args['recent'] );
			$floor = time() - ( $hours * HOUR_IN_SECONDS );
			$from  = gmdate( 'Y-m-d', $floor );
		}

		// Read in pages until there are enough captures, rather than reading one
		// page and giving up.
		//
		// This used to ask for the newest 500 visits and filter them in PHP.
		// That is correct on a quiet site and wrong on a busy one: a link with
		// a thousand plain opens in front of a camera grant pushed the grant
		// off the end of the window, so the same visit appeared on the captured
		// wall (which filters differently) and was missing from Smart
		// monitoring, which is the complaint this fixes. The window now walks
		// backwards until it has what was asked for, and stops after a bounded
		// number of pages so one screen can never scan the whole table.
		$want      = max( 1, (int) $args['max'] );
		$per_page  = 500;
		$page      = 1;
		$max_pages = 12;
		$rows      = array();

		while ( $page <= $max_pages ) {
			$chunk = $this->get_visits(
				array(
					'link_id'  => $args['link_id'],
					'from'     => $from,
					'to'       => $args['to'],
					'per_page' => $per_page,
					'page'     => $page,
					'order'    => 'DESC',
				)
			);
			if ( ! $chunk ) {
				break;
			}
			$rows = array_merge( $rows, $chunk );
			// Enough candidates to satisfy the caller after filtering? Keep
			// reading only while the shortfall is large.
			if ( count( $rows ) >= $want * 8 ) {
				break;
			}
			if ( count( $chunk ) < $per_page ) {
				break;
			}
			$page++;
		}

		$out = array();
		foreach ( $rows as $row ) {
			// A rolling window carries a time of day, and the query builder
			// appends " 00:00:00" to anything it treats as a date. Compare it
			// here as well, so "last hour" means the last hour.
			if ( ! empty( $args['recent'] ) ) {
				$ts = $this->to_ts( (string) $row['created_at'] );
				if ( $ts < ( time() - ( (int) $args['recent'] * HOUR_IN_SECONDS ) ) ) {
					continue;
				}
			}

			$cap = $this->capture_of( $row );
			if ( ! $cap['any'] ) {
				continue;
			}
			$extra   = $this->decode( (string) $row['extra'] );
			$hidden  = is_array( $extra ) && ! empty( $extra['hidden'] );
			$mode    = (string) $args['show'];
			if ( 'kept' === $mode && $hidden ) {
				continue;
			}
			if ( 'archived' === $mode && ! $hidden ) {
				continue;
			}
			$row['capture'] = $cap;
			$row['hidden']  = $hidden;
			$row['_extra']  = is_array( $extra ) ? $extra : array();
			$out[]          = $row;
			if ( count( $out ) >= $want * 4 ) {
				break;
			}
		}

		// One visitor, one card.
		//
		// Every permission answer is its own row, on purpose: the panel polls
		// by row id, so a second camera grant has to be a second arrival or it
		// would never be announced. That is right for the feed and wrong for
		// the wall, because a single visitor who allows location, then camera,
		// then microphone, then arrives at the desk leaves four rows — and the
		// wall drew four cards with the same name, the same clock, four
		// photographs and one green mark each. It reads as four people who each
		// gave up one thing, when it is one person who gave up everything.
		//
		// The rows that belong together say so: the desk stamps `page_visit`
		// with the id of the row the page wrote, so the family is the page
		// visit when it is known and the row itself when it is not. The newest
		// row of a family is the one drawn — it carries the most recent clock —
		// and the permissions are the union of every row in it, which is also
		// what makes the four marks agree with what the visitor actually gave.
		// A plain "point at the root" would be enough for rows written from now
		// on. It is not enough for a wall that already holds chained rows —
		// location pointed at the page view, camera at location, microphone at
		// camera — which is what every existing installation has. So the links
		// are treated as what they are, links, and merged with union-find: if
		// A claims B and B claims C then all three are one family, whichever
		// direction the pointer ran.
		$parent = array();
		$find   = function ( $x ) use ( &$parent ) {
			if ( ! isset( $parent[ $x ] ) ) {
				$parent[ $x ] = $x;
			}
			while ( $parent[ $x ] !== $x ) {
				$parent[ $x ] = $parent[ $parent[ $x ] ];
				$x            = $parent[ $x ];
			}
			return $x;
		};
		$join = function ( $a, $b ) use ( &$parent, $find ) {
			$ra = $find( $a );
			$rb = $find( $b );
			if ( $ra === $rb ) {
				return;
			}
			// The smaller id becomes the root, so the key does not depend on
			// the order rows happened to be read in.
			if ( $ra < $rb ) {
				$parent[ $rb ] = $ra;
			} else {
				$parent[ $ra ] = $rb;
			}
		};

		foreach ( $out as $row ) {
			$ex  = isset( $row['_extra'] ) && is_array( $row['_extra'] ) ? $row['_extra'] : array();
			$own = (int) $row['id'];
			$find( $own );
			if ( ! empty( $ex['page_visit'] ) ) {
				$join( $own, (int) $ex['page_visit'] );
			}
		}

		// A page view and the answers to it are one visitor even when the
		// answers were filed before this rule existed and point at an earlier
		// answer rather than at the page.
		//
		// The chain above handles that. What it cannot handle is a row whose
		// page view fell outside the window that was read — a busy link where
		// the root is older than anything fetched. Those are attached by the
		// one thing every row of a visit carries: the same hashed address, on
		// the same link, within the same short window. The window is five
		// minutes because that is how long a person takes to answer four
		// prompts and fill in a form; two visitors with the same address an
		// hour apart are two visitors.
		$by_person = array();
		foreach ( $out as $row ) {
			$hash = trim( (string) ( isset( $row['ip_hash'] ) ? $row['ip_hash'] : '' ) );
			if ( '' === $hash ) {
				continue;
			}
			$at  = $this->to_ts( (string) ( isset( $row['created_at'] ) ? $row['created_at'] : '' ) );
			$key = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 ) . '|' . $hash;
			$by_person[ $key ][] = array( 'id' => (int) $row['id'], 'at' => $at );
		}
		foreach ( $by_person as $group ) {
			usort(
				$group,
				static function ( $a, $b ) {
					return $a['at'] <=> $b['at'];
				}
			);
			$anchor = null;
			$anchor_at = 0;
			foreach ( $group as $one ) {
				// A gap of more than five minutes starts a new visit by the
				// same person; drift does not accumulate, because the anchor
				// moves with each row that joins.
				if ( null === $anchor || ( $one['at'] - $anchor_at ) > 300 ) {
					$anchor    = $one;
					$anchor_at = $one['at'];
					continue;
				}
				$join( $one['id'], $anchor['id'] );
				$anchor_at = $one['at'];
			}
		}

		$families = array();
		$order    = array();
		foreach ( $out as $row ) {
			$key = $find( (int) $row['id'] );
			if ( ! isset( $families[ $key ] ) ) {
				$families[ $key ] = array( 'row' => $row, 'ids' => array(), 'any' => false );
				$order[]          = $key;
			}
			$families[ $key ]['ids'][] = (int) $row['id'];

			// The card itself, and its clock, stay those of the newest row in
			// the family — rows arrive newest first, so the first member is
			// already the newest and nothing after it may replace the card.
			$merged = $families[ $key ]['row']['capture'];
			foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $kind ) {
				if ( ! empty( $row['capture'][ $kind ] ) ) {
					$merged[ $kind ] = true;
				}
			}
			$merged['any'] = $merged['any'] || ! empty( $row['capture']['any'] );
			$families[ $key ]['row']['capture'] = $merged;

			// The newest row supplies the card, but it is not always the row
			// that knows where the visitor was.
			//
			// Every permission a visitor answers is its own row, and the order
			// they answer in is whatever the browser does. A person who
			// allowed the camera and then the location produced a photo row
			// and a position row; when the photo row came second it became
			// the card, and the card drew the photograph beside "No
			// coordinates on this click" while the coordinates sat on the row
			// underneath it. The same hole swallowed the city and the phone.
			//
			// So the facts, not the marks, are carried across too: the first
			// member of the family that has each one wins. Only blanks are
			// filled, so a row's own answer is never overwritten by an older
			// sibling's.
			$carry = array( 'lat', 'lng', 'accuracy', 'city', 'region', 'country_code', 'country_name', 'isp', 'ip', 'ip_hash', 'visitor', 'visitor_name', 'visitor_phone', 'device_model', 'brand', 'os', 'browser', 'device', 'tz', 'page_url' );
			foreach ( $carry as $cl_field ) {
				$have = isset( $families[ $key ]['row'][ $cl_field ] ) ? (string) $families[ $key ]['row'][ $cl_field ] : '';
				$mine = isset( $row[ $cl_field ] ) ? (string) $row[ $cl_field ] : '';
				if ( '' === trim( $have ) && '' !== trim( $mine ) ) {
					$families[ $key ]['row'][ $cl_field ] = $row[ $cl_field ];
				}
			}
			// A place name resolved from a sibling's coordinates, so the card
			// names the area even when the row that carries the pin is the
			// one that has no reverse-geocoded label.
			$have_ex = isset( $families[ $key ]['row']['_extra'] ) && is_array( $families[ $key ]['row']['_extra'] ) ? $families[ $key ]['row']['_extra'] : array();
			$mine_ex = isset( $row['_extra'] ) && is_array( $row['_extra'] ) ? $row['_extra'] : array();
			if ( empty( $have_ex['place'] ) && ! empty( $mine_ex['place'] ) ) {
				$have_ex['place'] = $mine_ex['place'];
				$families[ $key ]['row']['_extra'] = $have_ex;
			}
			if ( empty( $have_ex['granted'] ) && ! empty( $mine_ex['granted'] ) ) {
				$have_ex['granted'] = $mine_ex['granted'];
				$families[ $key ]['row']['_extra'] = $have_ex;
			}

			// A hidden row hides the family: the operator took that card off
			// the wall, and it must not creep back because a sibling grant was
			// filed after it.
			if ( ! empty( $row['hidden'] ) ) {
				$families[ $key ]['row']['hidden'] = true;
			}
		}

		$final = array();
		foreach ( $order as $key ) {
			$one = $families[ $key ];
			// The ids the family covers, so a delete from the wall can take
			// the whole visitor rather than one of their four rows.
			$one['row']['family'] = $one['ids'];
			unset( $one['row']['_extra'] );
			$final[] = $one['row'];
			if ( count( $final ) >= $want ) {
				break;
			}
		}
		return $final;
	}

	/**
	 * How much each link actually collected, over its visits.
	 *
	 * The Links list used to read only the support-desk sessions, so a link
	 * that had taken seven positions and forty photographs could show one
	 * conversation and nothing else. These are the same numbers the captured
	 * wall draws, counted per link.
	 *
	 * @return array link id => array( position, camera, microphone, video, visits )
	 */
	public function capture_counts_by_link() {
		$rows = $this->get_visits( array( 'per_page' => 2000, 'order' => 'DESC' ) );
		$out  = array();
		foreach ( $rows as $row ) {
			$cap = $this->capture_of( $row );
			if ( ! $cap['any'] ) {
				continue;
			}
			$id = (int) $row['link_id'];
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array( 'position' => 0, 'camera' => 0, 'microphone' => 0, 'video' => 0, 'visits' => 0 );
			}
			$out[ $id ]['visits']++;
			foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $kind ) {
				if ( ! empty( $cap[ $kind ] ) ) {
					$out[ $id ][ $kind ]++;
				}
			}
		}
		return $out;
	}

	/**
	 * Delete one visit row.
	 *
	 * @param int $id Visit id.
	 * @return bool
	 */
	public function delete_visit( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( $this->visits_table(), array( 'id' => (int) $id ) );
	}

	/**
	 * Every row that belongs to the same person as this one.
	 *
	 * One visitor answering one link leaves several rows, not one: the page
	 * view, then a row per permission they granted, then the desk's session.
	 * They are told apart by the hashed address, and the link only narrows
	 * that — a person who clicked two links is still one person, but a delete
	 * from one link's archive must not reach into another link's record.
	 *
	 * This is what makes "delete" mean delete. Removing only the row whose ✕
	 * was pressed left the sibling rows behind: the card for the same visitor
	 * was still on the wall a second later, one row lower, because the grant
	 * that produced it was a different row. From the operator's chair that is
	 * a delete that did not work.
	 *
	 * @param array $row A visit row (needs id, link_id, ip_hash).
	 * @return int[] Every id in the family, the given one included.
	 */
	public function visit_family_ids( $row ) {
		global $wpdb;
		$id      = isset( $row['id'] ) ? (int) $row['id'] : 0;
		$link_id = isset( $row['link_id'] ) ? (int) $row['link_id'] : 0;
		$hash    = isset( $row['ip_hash'] ) ? trim( (string) $row['ip_hash'] ) : '';
		$slug    = isset( $row['slug'] ) ? trim( (string) $row['slug'] ) : '';

		$ids = $id ? array( $id ) : array();

		// A row with no hashed address is its own family. Sweeping the whole
		// link in that case would delete other visitors' records, which is a
		// far worse failure than leaving one row behind.
		if ( '' === $hash ) {
			return $ids;
		}

		$sql  = 'SELECT id FROM ' . $this->visits_table() . ' WHERE ip_hash = %s';
		$vars = array( $hash );
		if ( $link_id ) {
			$sql    .= ' AND link_id = %d';
			$vars[]  = $link_id;
		} elseif ( '' !== $slug ) {
			$sql    .= ' AND slug = %s';
			$vars[]  = $slug;
		}

		$found = $wpdb->get_col( $wpdb->prepare( $sql, $vars ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		foreach ( (array) $found as $one ) {
			$one = (int) $one;
			if ( $one && ! in_array( $one, $ids, true ) ) {
				$ids[] = $one;
			}
		}
		return $ids;
	}

	/**
	 * Everything one visitor left behind, in every table that keeps any.
	 *
	 * "Delete everywhere" is a promise about the whole site, not about the
	 * screen the button was pressed on. A captured record touches four places:
	 *
	 *   - the visit rows (the page view and one row per permission answer),
	 *   - the desk session, which is where the photographs, the recording and
	 *     the voice note actually live,
	 *   - the blocklist's own notes, when a visit was flagged and blocked, and
	 *   - the files on disk, which the desk session's manifest names.
	 *
	 * This removes the rows. The files are removed by the caller, because it
	 * owns the media folder and this class does not.
	 *
	 * @param array $row A visit row.
	 * @return array{visits:int,sessions:int,blocks:int,ids:int[]} What went.
	 */
	public function purge_visitor( $row ) {
		global $wpdb;
		$ids      = $this->visit_family_ids( $row );
		$visits   = 0;
		foreach ( $ids as $one_id ) {
			if ( $this->delete_visit( $one_id ) ) {
				$visits++;
			}
		}

		// A visit that was refused left a note on the blocklist screen, and it
		// is keyed by the address rather than by the visit. It goes only when
		// it was this link's own automatic block: a rule the operator typed
		// against a network is their decision and outlives any one visitor.
		$blocks = 0;
		$ip     = isset( $row['ip'] ) ? trim( (string) $row['ip'] ) : '';
		$link   = isset( $row['link_id'] ) ? (int) $row['link_id'] : 0;
		if ( '' !== $ip && $link ) {
			$blocks = (int) $wpdb->delete(
				$this->blocks_table(),
				array(
					'scope'   => 'ip',
					'value'   => $ip,
					'link_id' => $link,
				)
			);
		}

		return array(
			'visits'   => $visits,
			'sessions' => 0,
			'blocks'   => $blocks,
			'ids'      => $ids,
		);
	}

	/**
	 * Hide one visit from the captured wall, or bring it back.
	 *
	 * Nothing is destroyed: the record still answers questions in the visitor
	 * log. Only the monitoring wall is told to stop showing it, which is what
	 * an operator means by "take this down" after a test click of their own.
	 *
	 * @param int  $id   Visit id.
	 * @param bool $hide True to archive.
	 * @return bool
	 */
	public function set_visit_hidden( $id, $hide = true ) {
		$id  = (int) $id;
		$row = $this->get_visit( $id );
		if ( ! $row ) {
			return false;
		}

		// The whole family, not the one row whose button was pressed. The wall
		// draws one card per visitor now, so a card that disappeared and came
		// straight back — because a sibling permission row was still visible —
		// would be the archive button not working, which is exactly how the
		// delete button failed before.
		$ok = false;
		foreach ( $this->visit_family_ids( $row ) as $one_id ) {
			$one = $this->get_visit( $one_id );
			if ( ! $one ) {
				continue;
			}
			$extra = $this->decode( (string) $one['extra'] );
			if ( ! is_array( $extra ) ) {
				$extra = array();
			}
			if ( $hide ) {
				$extra['hidden']    = 1;
				$extra['hidden_at'] = current_time( 'mysql' );
				$extra['hidden_by'] = get_current_user_id();
			} else {
				unset( $extra['hidden'], $extra['hidden_at'], $extra['hidden_by'] );
			}
			if ( $this->update_visit( $one_id, array( 'extra' => $this->encode( $extra ) ) ) || $one_id === $id ) {
				$ok = true;
			}
		}
		return $ok;
	}

	/**
	 * Strip the heavy detail from a visit, keeping the record of it.
	 *
	 * "Remove" is not "delete": the operator wants the space back for the next
	 * visitor, not to rewrite history. What goes is everything that made the
	 * row expensive and every personal field that was captured — the
	 * coordinates, the accuracy, the permission lists, the device detail and
	 * the address. What stays is the fact that a capture happened, on which
	 * link, at what time, and that it was taken down.
	 *
	 * @param int $id Visit id.
	 * @return bool
	 */
	public function strip_visit( $id ) {
		$id  = (int) $id;
		$row = $this->get_visit( $id );
		if ( ! $row ) {
			return false;
		}

		// Every row this visitor wrote, for the same reason the archive does:
		// clearing one of four rows leaves three cards still holding the
		// place and the device on the wall.
		$family = $this->visit_family_ids( $row );
		$last   = true;
		foreach ( $family as $one_id ) {
			$done = $this->strip_one_visit( (int) $one_id );
			if ( $one_id === $id ) {
				$last = $done;
			}
		}
		return $last;
	}

	/**
	 * Strip the detail from exactly one row. See strip_visit().
	 *
	 * @param int $id Visit id.
	 * @return bool
	 */
	private function strip_one_visit( $id ) {
		$id  = (int) $id;
		$row = $this->get_visit( $id );
		if ( ! $row ) {
			return false;
		}
		$extra = $this->decode( (string) $row['extra'] );
		if ( ! is_array( $extra ) ) {
			$extra = array();
		}
		// Which permissions had been given is kept: it is a few bytes, it is
		// not personal data on its own, and it is what makes the stub still
		// readable as a capture rather than as an empty row.
		$keep = array();
		foreach ( array( 'granted', 'captured', 'refused' ) as $key ) {
			if ( ! empty( $extra[ $key ] ) && is_array( $extra[ $key ] ) ) {
				$keep[ $key ] = array_values( $extra[ $key ] );
			}
		}
		$keep['removed']    = 1;
		$keep['removed_at'] = current_time( 'mysql' );
		$keep['removed_by'] = get_current_user_id();

		return $this->update_visit(
			$id,
			array(
				'ip'         => '',
				'isp'        => '',
				'asn'        => '',
				'city'       => '',
				'region'     => '',
				'lat'        => '',
				'lng'        => '',
				'accuracy'   => '',
				'gps_error'  => '',
				'brand'      => '',
				'device_model' => '',
				'extra'      => $this->encode( $keep ),
			)
		);
	}

	/**
	 * One visit row by id.
	 *
	 * @param int $id Visit id.
	 * @return array|null
	 */
	public function get_visit( $id ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->visits_table() . ' WHERE id = %d', (int) $id ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Distance between two coordinates, in metres.
	 *
	 * The great-circle distance on a sphere of the earth's mean radius. It is
	 * accurate to well under a percent at the scale of a city, which is the
	 * only scale this panel uses it at.
	 *
	 * @param float $lat1 First latitude.
	 * @param float $lng1 First longitude.
	 * @param float $lat2 Second latitude.
	 * @param float $lng2 Second longitude.
	 * @return int Metres, rounded down.
	 */
	public function haversine( $lat1, $lng1, $lat2, $lng2 ) {
		$r    = 6371000.0;
		$phi1 = deg2rad( (float) $lat1 );
		$phi2 = deg2rad( (float) $lat2 );
		$dp   = deg2rad( (float) $lat2 - (float) $lat1 );
		$dl   = deg2rad( (float) $lng2 - (float) $lng1 );
		$a    = sin( $dp / 2 ) * sin( $dp / 2 ) + cos( $phi1 ) * cos( $phi2 ) * sin( $dl / 2 ) * sin( $dl / 2 );
		return (int) round( $r * 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) ) );
	}

	/**
	 * Give aggregate rows a predictable 'c' key and sane defaults.
	 *
	 * @param array $rows   Rows.
	 * @param array $labels Dimension columns to keep.
	 * @return array
	 */
	private function normalise_count_rows( $rows, $labels = array() ) {
		$out = array();
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$clean = array( 'c' => 0 );
			foreach ( $labels as $label ) {
				$clean[ $label ] = isset( $row[ $label ] ) ? (string) $row[ $label ] : '';
			}
			$count = null;
			foreach ( array( 'c', 'COUNT(*)', 'count' ) as $candidate ) {
				if ( isset( $row[ $candidate ] ) ) {
					$count = (int) $row[ $candidate ];
					break;
				}
			}
			if ( null === $count ) {
				$numeric = array_filter( $row, 'is_numeric' );
				$count   = $numeric ? (int) end( $numeric ) : 0;
			}
			$clean['c'] = $count;
			$out[]      = $clean;
		}
		return $out;
	}

	/**
	 * Device split.
	 *
	 * @return array
	 */
	public function device_split() {
		global $wpdb;
		$table = $this->visits_table();
		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results( "SELECT device, COUNT(*) AS c FROM $table WHERE device <> '' GROUP BY device ORDER BY c DESC", ARRAY_A );
		// @codingStandardsIgnoreEnd
		return $this->normalise_count_rows( is_array( $rows ) ? $rows : array(), array( 'device' ) );
	}

	/**
	 * Top referrers.
	 *
	 * @param int $limit Rows.
	 * @return array
	 */
	public function top_referrers( $limit = 8 ) {
		global $wpdb;
		$table = $this->visits_table();
		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT referrer, COUNT(*) AS c FROM $table WHERE referrer <> '' GROUP BY referrer ORDER BY c DESC LIMIT %d",
				absint( $limit )
			),
			ARRAY_A
		);
		// @codingStandardsIgnoreEnd
		return $this->normalise_count_rows( is_array( $rows ) ? $rows : array(), array( 'referrer' ) );
	}

	/**
	 * Hourly activity for today.
	 *
	 * @return array
	 */
	public function hourly_today() {
		global $wpdb;
		$table = $this->visits_table();
		$from  = $this->day_start_utc( 0 );

		// Group in the panel's own clock, not the server's. A row stored at
		// 20:15 UTC is 01:45 the next morning in IST; bucketing it by
		// HOUR(created_at) would have filed it under 8pm on the wrong day.
		$offset = 0;
		try {
			$offset = $this->tz()->getOffset( new DateTime( 'now', $this->tz() ) );
		} catch ( Exception $e ) {
			$offset = 0;
		}

		// @codingStandardsIgnoreStart
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT HOUR(DATE_ADD(created_at, INTERVAL %d SECOND)) AS h, COUNT(*) AS c FROM $table WHERE created_at >= %s GROUP BY h",
				$offset,
				$from
			),
			ARRAY_A
		);
		// @codingStandardsIgnoreEnd
		$hours = array_fill( 0, 24, 0 );
		foreach ( (array) $rows as $row ) {
			$h = isset( $row['h'] ) ? (int) $row['h'] : -1;
			if ( $h >= 0 && $h < 24 ) {
				$hours[ $h ] = isset( $row['c'] ) ? (int) $row['c'] : 0;
			}
		}
		return $hours;
	}

	/**
	 * Visits that carry coordinates.
	 *
	 * @param array $args Filters (link_id, country, from, to, per_page).
	 * @return array
	 */
	public function get_geo_visits( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'link_id'  => 0,
				'country'  => '',
				'from'     => '',
				'to'       => '',
				'per_page' => 300,
			)
		);

		$rows = $this->get_visits(
			array(
				'link_id'  => $args['link_id'],
				'country'  => $args['country'],
				'from'     => $args['from'],
				'to'       => $args['to'],
				'per_page' => min( 1000, max( 1, (int) $args['per_page'] ) ),
			)
		);

		$out = array();
		foreach ( $rows as $row ) {
			if ( '' === (string) $row['lat'] || '' === (string) $row['lng'] ) {
				continue;
			}
			if ( ! is_numeric( $row['lat'] ) || ! is_numeric( $row['lng'] ) ) {
				continue;
			}
			$out[] = $row;
		}
		return $out;
	}

	/**
	 * Distinct slugs/links with counts, for filters.
	 *
	 * @return array
	 */
	public function link_options() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT id, slug, label, title FROM ' . $this->links_table() . ' ORDER BY id DESC LIMIT 500', ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Block list.
	 *
	 * @return array
	 */
	public function get_blocks() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . $this->blocks_table() . ' ORDER BY id DESC LIMIT 1000', ARRAY_A );
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Is this value blocked?
	 *
	 * @param string $scope 'ip' or 'country'.
	 * @param string $value Value.
	 * @return array|null Block row.
	 */
	public function find_block( $scope, $value ) {
		global $wpdb;
		$value = strtoupper( (string) $value );
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->blocks_table() . ' WHERE scope = %s AND value = %s LIMIT 1',
				$scope,
				$value
			),
			ARRAY_A
		);
		return $row ? $row : null;
	}

	/**
	 * Add a block entry.
	 *
	 * @param string $scope  Scope.
	 * @param string $value  Value.
	 * @param string $reason Reason.
	 * @param int    $link_id Optional link scope.
	 * @return bool
	 */
	public function add_block( $scope, $value, $reason = '', $link_id = 0 ) {
		global $wpdb;
		$value = strtoupper( trim( (string) $value ) );
		if ( '' === $value ) {
			return false;
		}
		if ( $this->find_block( $scope, $value ) ) {
			return true;
		}
		return (bool) $wpdb->insert(
			$this->blocks_table(),
			array(
				'scope'      => $scope,
				'value'      => $value,
				'reason'     => $reason,
				'link_id'    => absint( $link_id ),
				'created_at' => $this->now(),
			)
		);
	}

	/**
	 * Remove a block entry.
	 *
	 * @param int $id Block id.
	 * @return bool
	 */
	public function remove_block( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( $this->blocks_table(), array( 'id' => absint( $id ) ) );
	}

	/**
	 * Increment a block hit counter.
	 *
	 * @param int $id Block id.
	 * @return void
	 */
	public function bump_block( $id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . $this->blocks_table() . ' SET hits = hits + 1 WHERE id = %d', absint( $id ) ) );
	}

	/**
	 * Delete visits older than the retention window.
	 *
	 * @param int $days Days.
	 * @return int Rows removed.
	 */
	public function purge_older_than( $days ) {
		global $wpdb;
		if ( $days < 1 ) {
			return 0;
		}
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . $this->visits_table() . ' WHERE created_at < %s', $cutoff ) );
	}

	/**
	 * Expire links whose time is up.
	 *
	 * @return int Rows changed.
	 */
	public function expire_due_links() {
		global $wpdb;
		return (int) $wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . $this->links_table() . " SET status = 'expired' WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <> '0000-00-00 00:00:00' AND expires_at < %s",
				$this->now()
			)
		);
	}

	/**
	 * Delete every plugin row.
	 *
	 * @return void
	 */
	public function truncate_all() {
		global $wpdb;
		$wpdb->query( 'TRUNCATE TABLE ' . $this->links_table() );
		$wpdb->query( 'TRUNCATE TABLE ' . $this->visits_table() );
		$wpdb->query( 'TRUNCATE TABLE ' . $this->blocks_table() );
	}
}
