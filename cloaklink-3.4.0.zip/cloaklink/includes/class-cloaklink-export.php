<?php
/**
 * CSV / Excel / Word / PDF exports.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Streams downloads from the panel.
 */
class CloakLink_Export {

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings.
	 */
	public function __construct( $db, $settings ) {
		$this->db       = $db;
		$this->settings = $settings;
	}

	/** Handle both admin-post and early-init export requests. */
	public function handle_request() {
		if ( ! current_user_can( apply_filters( 'cloaklink_capability', 'manage_options' ) ) ) {
			wp_die( esc_html__( 'You do not have access to these records.', 'cloaklink' ), 403 );
		}
		check_admin_referer( 'cloaklink_export' );

		if ( isset( $_GET['scope'] ) ) {
			$scope = sanitize_key( wp_unslash( $_GET['scope'] ) );
			if ( 'links' === $scope ) {
				$this->export_links( isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : 'csv' );
				exit;
			}
			if ( 'blocks' === $scope ) {
				$this->export_blocks( isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : 'csv' );
				exit;
			}
			if ( 'support' === $scope ) {
				$this->export_support( isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : 'csv' );
				exit;
			}
		}

		$format = isset( $_GET['format'] ) ? sanitize_key( wp_unslash( $_GET['format'] ) ) : 'csv';
		$this->export_visits( $format );
		exit;
	}

	/**
	 * Column set for the visitor export.
	 *
	 * @return array key => label.
	 */
	private function visit_columns() {
		return array(
			'created_at'   => __( 'Timestamp (site time)', 'cloaklink' ),
			'event'        => __( 'Event', 'cloaklink' ),
			'slug'         => __( 'Link slug', 'cloaklink' ),
			'device'       => __( 'Device', 'cloaklink' ),
			'brand'        => __( 'Brand', 'cloaklink' ),
			'device_model' => __( 'Model', 'cloaklink' ),
			'os'           => __( 'OS', 'cloaklink' ),
			'browser'      => __( 'Browser', 'cloaklink' ),
			'country_code' => __( 'Country', 'cloaklink' ),
			'country_name' => __( 'Country name', 'cloaklink' ),
			'region'       => __( 'Region', 'cloaklink' ),
			'city'         => __( 'City', 'cloaklink' ),
			'lat'          => __( 'Latitude', 'cloaklink' ),
			'lng'          => __( 'Longitude', 'cloaklink' ),
			'accuracy'     => __( 'GPS accuracy (m)', 'cloaklink' ),
			'gps_error'    => __( 'GPS status', 'cloaklink' ),
			'ip'           => __( 'IP address', 'cloaklink' ),
			'isp'          => __( 'ISP / organisation', 'cloaklink' ),
			'asn'          => __( 'ASN', 'cloaklink' ),
			'vpn'          => __( 'VPN / proxy', 'cloaklink' ),
			'screen'       => __( 'Screen', 'cloaklink' ),
			'viewport'     => __( 'Viewport', 'cloaklink' ),
			'tz'           => __( 'Timezone', 'cloaklink' ),
			'lang'         => __( 'Language', 'cloaklink' ),
			'referrer'     => __( 'Referrer', 'cloaklink' ),
			'campaign'     => __( 'Campaign', 'cloaklink' ),
			'insta_id'     => __( 'Instagram ID', 'cloaklink' ),
			'risk'         => __( 'Risk score', 'cloaklink' ),
			'flags'        => __( 'Flags', 'cloaklink' ),
			'ua'           => __( 'User agent', 'cloaklink' ),
		);
	}

	/**
	 * Flatten a visit row to the export columns.
	 *
	 * @param array $row Visit row.
	 * @return array
	 */
	private function visit_values( $row ) {
		$out = array();
		foreach ( $this->visit_columns() as $key => $label ) {
			if ( 'vpn' === $key ) {
				$bits        = array_filter( array( $row['is_vpn'] ? 'VPN' : '', $row['is_proxy'] ? 'Proxy' : '' ) );
				$out[ $key ] = implode( ' + ', $bits );
				continue;
			}
			if ( 'created_at' === $key ) {
				$out[ $key ] = $this->local( $row['created_at'] );
				continue;
			}
			$out[ $key ] = isset( $row[ $key ] ) ? (string) $row[ $key ] : '';
		}
		if ( $this->settings->get( 'mask_ip' ) ) {
			$out['ip'] = $this->mask( $out['ip'] );
		}
		return $out;
	}

	/**
	 * Convert a stored UTC datetime to site time.
	 *
	 * @param string $mysql Datetime.
	 * @return string
	 */
	private function local( $mysql ) {
		$ts = $this->db->to_ts( $mysql );
		return $ts ? wp_date( 'd M Y, g:i A', $ts, $this->db->tz() ) : '';
	}

	/**
	 * Partially mask an IP.
	 *
	 * @param string $ip IP.
	 * @return string
	 */
	private function mask( $ip ) {
		if ( false !== strpos( $ip, '.' ) ) {
			$p = explode( '.', $ip );
			return $p[0] . '.' . $p[1] . '.*.*';
		}
		return substr( $ip, 0, 4 ) . ':' . str_repeat( '*', 4 );
	}

	/**
	 * Export visitor rows.
	 *
	 * @param string $format csv|xls|doc|pdf.
	 * @return void
	 */
	private function export_visits( $format ) {
		$args = array(
			'link_id'  => isset( $_GET['link_id'] ) ? absint( $_GET['link_id'] ) : 0,
			'event'    => isset( $_GET['event'] ) ? sanitize_key( wp_unslash( $_GET['event'] ) ) : '',
			'device'   => isset( $_GET['device'] ) ? sanitize_key( wp_unslash( $_GET['device'] ) ) : '',
			'country'  => isset( $_GET['country'] ) ? sanitize_key( wp_unslash( $_GET['country'] ) ) : '',
			'from'     => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
			'to'       => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
			'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'risk_min' => isset( $_GET['risk_min'] ) ? absint( $_GET['risk_min'] ) : 0,
			'per_page' => 5000,
			'page'     => 1,
		);

		$rows  = $this->db->get_visits( $args );
		$links = $this->db->link_options();
		$title = __( 'CloakLink visitor report', 'cloaklink' );
		if ( $args['link_id'] ) {
			$link = $this->db->get_link( $args['link_id'] );
			if ( $link ) {
				$title = sprintf( /* translators: %s: link title */ __( 'CloakLink report — %s', 'cloaklink' ), $link['title'] );
			}
		}

		$columns = $this->visit_columns();
		$matrix  = array();
		foreach ( $rows as $row ) {
			$matrix[] = $this->visit_values( $row );
		}

		$stats = $this->db->global_stats();
		$summary = array(
			__( 'Records', 'cloaklink' )      => number_format_i18n( count( $matrix ) ),
			__( 'Links', 'cloaklink' )        => number_format_i18n( count( $links ) ),
			__( 'Countries', 'cloaklink' )    => number_format_i18n( $stats['countries'] ),
			__( 'High risk', 'cloaklink' )    => number_format_i18n( $stats['high_risk'] ),
			__( 'Blocked', 'cloaklink' )      => number_format_i18n( $stats['blocked_total'] ),
		);

		switch ( $format ) {
			case 'xls':
				$this->send_html_table( $matrix, $columns, $title, $summary, 'xls' );
				break;
			case 'doc':
				$this->send_html_table( $matrix, $columns, $title, $summary, 'doc' );
				break;
			case 'pdf':
				$this->send_pdf( $matrix, $columns, $title, $summary, $args );
				break;
			default:
				$this->send_csv( $matrix, $columns, $title );
		}
	}

	/**
	 * Export the link list.
	 *
	 * @param string $format Format.
	 * @return void
	 */
	private function export_links( $format ) {
		$rows = $this->db->get_links( array( 'per_page' => 2000 ) );

		$columns = array(
			'slug'         => __( 'Slug', 'cloaklink' ),
			'title'        => __( 'Internal name', 'cloaklink' ),
			'label'        => __( 'Label', 'cloaklink' ),
			'link_type'    => __( 'Type', 'cloaklink' ),
			'destination'  => __( 'Destination', 'cloaklink' ),
			'host'         => __( 'Host', 'cloaklink' ),
			'click_count'  => __( 'Opens', 'cloaklink' ),
			'max_clicks'   => __( 'Max opens', 'cloaklink' ),
			'status'       => __( 'Status', 'cloaklink' ),
			'expires_at'   => __( 'Expires', 'cloaklink' ),
			'created_at'   => __( 'Created', 'cloaklink' ),
			'pin'          => __( 'PIN', 'cloaklink' ),
			'lock'         => __( 'Single use', 'cloaklink' ),
			'public_url'   => __( 'Public URL', 'cloaklink' ),
		);

		$matrix = array();
		foreach ( $rows as $row ) {
			$matrix[] = array(
				// Printed as it is shared, ending included, so the inventory
				// matches the address an operator would paste into a message.
				'slug'        => $row['slug'] . ( '' !== cloaklink()->links->extension( $row ) ? '.' . cloaklink()->links->extension( $row ) : '' ),
				'title'       => $row['title'],
				'label'       => $row['label'],
				'link_type'   => $row['link_type'],
				'destination' => $row['destination'],
				'host'        => $row['destination_host'],
				'click_count' => (string) $row['click_count'],
				'max_clicks'  => (string) $row['max_clicks'],
				'status'      => $row['status'],
				'expires_at'  => $this->local( $row['expires_at'] ),
				'created_at'  => $this->local( $row['created_at'] ),
				'pin'         => ! empty( $row['meta']['pin_hash'] ) ? __( 'Required', 'cloaklink' ) : __( 'No', 'cloaklink' ),
				'lock'        => ! empty( $row['meta']['locked_hash'] ) ? __( 'Locked', 'cloaklink' ) : ( ! empty( $row['meta']['single_use'] ) ? __( 'Waiting', 'cloaklink' ) : __( 'No', 'cloaklink' ) ),
				'public_url'  => cloaklink()->links->link_url( $row ),
			);
		}

		$title   = __( 'CloakLink link inventory', 'cloaklink' );
		$summary = array( __( 'Links', 'cloaklink' ) => number_format_i18n( count( $matrix ) ) );

		if ( 'xls' === $format ) {
			$this->send_html_table( $matrix, $columns, $title, $summary, 'xls' );
		} elseif ( 'doc' === $format ) {
			$this->send_html_table( $matrix, $columns, $title, $summary, 'doc' );
		} elseif ( 'pdf' === $format ) {
			$this->send_pdf( $matrix, $columns, $title, $summary, array() );
		} else {
			$this->send_csv( $matrix, $columns, $title );
		}
	}

	/**
	 * Export the Smart monitoring sessions.
	 *
	 * One row per conversation, newest first, carrying the link it came in
	 * on and what that visitor sent. The photographs and the voice note are
	 * files in their own right, not table cells, so the row names them and
	 * the time window they belong to rather than pretending to embed them.
	 *
	 * @param string $format csv|xls|doc|pdf.
	 * @return void
	 */
	private function export_support( $format ) {
		$support = cloaklink()->support;
		$from    = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$to      = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		$link_id = isset( $_GET['link_id'] ) ? absint( $_GET['link_id'] ) : 0;

		// A list of ticked rows wins over every other filter: the operator has
		// pointed at exactly these sessions, so those are the ones to write.
		$ids = isset( $_GET['ids'] ) ? array_filter( array_map( 'absint', explode( ',', (string) wp_unslash( $_GET['ids'] ) ) ) ) : array();

		$rows = $support->sessions(
			array(
				'per_page' => 5000,
				'link_id'  => $link_id,
				'from'     => $from,
				'to'       => $to,
				// The export carries the same search the screen was filtered
				// by, so a report of "the rows I am looking at" is the truth.
				'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
				'ids'      => $ids,
			)
		);

		$names = array();
		foreach ( $this->db->get_links( array( 'per_page' => 2000 ) ) as $l ) {
			$names[ (int) $l['id'] ] = array( trim( (string) $l['title'] ), trim( (string) $l['label'] ), (string) $l['slug'] );
		}

		$columns = array(
			'created_at' => __( 'Received (site time)', 'cloaklink' ),
			'day'        => __( 'Day', 'cloaklink' ),
			'link'       => __( 'Link (internal name)', 'cloaklink' ),
			'label'      => __( 'Link label', 'cloaklink' ),
			'slug'       => __( 'Link slug', 'cloaklink' ),
			'status'     => __( 'Session', 'cloaklink' ),
			// What the visitor typed on the desk form. These come before the
			// device detail because they are what identifies the person.
			'visitor'    => __( 'Visitor name', 'cloaklink' ),
			'phone'      => __( 'Mobile', 'cloaklink' ),
			'email'      => __( 'Email', 'cloaklink' ),
			'reference'  => __( 'Case reference', 'cloaklink' ),
			'subject'    => __( 'Subject', 'cloaklink' ),
			'request_no' => __( 'Request no.', 'cloaklink' ),
			'device'     => __( 'Device', 'cloaklink' ),
			'os'         => __( 'OS', 'cloaklink' ),
			'browser'    => __( 'Browser', 'cloaklink' ),
			'ip'         => __( 'IP address', 'cloaklink' ),
			'city'       => __( 'City', 'cloaklink' ),
			'region'     => __( 'Region', 'cloaklink' ),
			'country'    => __( 'Country', 'cloaklink' ),
			'isp'        => __( 'ISP', 'cloaklink' ),
			'lat'        => __( 'Latitude', 'cloaklink' ),
			'lng'        => __( 'Longitude', 'cloaklink' ),
			'accuracy'   => __( 'Accuracy (m)', 'cloaklink' ),
			'network'    => __( 'Network', 'cloaklink' ),
			'battery'    => __( 'Battery', 'cloaklink' ),
			'photos'     => __( 'Photographs', 'cloaklink' ),
			'audio'      => __( 'Voice note', 'cloaklink' ),
			'video'      => __( 'Call recording', 'cloaklink' ),
			'purge_at'   => __( 'Media deletes', 'cloaklink' ),
		);

		$matrix = array();
		foreach ( $rows as $row ) {
			$files = isset( $row['manifest'] ) ? $row['manifest'] : array( 'audio' => '', 'video' => '', 'photos' => array() );
			$lk    = isset( $names[ (int) $row['link_id'] ] ) ? $names[ (int) $row['link_id'] ] : array( __( 'Deleted link', 'cloaklink' ), '', (string) $row['slug'] );
			$dev   = trim( (string) $row['brand'] . ' ' . (string) $row['device_model'] );
			if ( '' === $dev ) {
				$dev = (string) $row['os'];
			}
			$matrix[] = array(
				'created_at' => $this->local( $row['created_at'] ),
				'day'        => substr( (string) $row['created_at'], 0, 10 ),
				'link'       => $lk[0],
				'label'      => $lk[1],
				'slug'       => $lk[2],
				'status'     => 'open' === $row['status'] ? __( 'Connected', 'cloaklink' ) : ( 'message' === $row['status'] ? __( 'Written message', 'cloaklink' ) : __( 'Finished', 'cloaklink' ) ),
				'visitor'    => (string) $row['visitor_name'],
				'phone'      => (string) $row['visitor_phone'],
				'email'      => (string) $row['visitor_email'],
				'reference'  => isset( $row['visitor_reference'] ) ? (string) $row['visitor_reference'] : '',
				'subject'    => isset( $row['visitor_topic'] ) ? (string) $row['visitor_topic'] : '',
				'request_no' => isset( $row['request_ref'] ) ? (string) $row['request_ref'] : '',
				'device'     => $dev,
				'os'         => (string) $row['os'],
				'browser'    => (string) $row['browser'],
				// Same rule as the panel: the operator's masking switch, not a
				// second opinion invented for the export.
				'ip'         => $this->settings->get( 'mask_ip' ) ? $this->mask( (string) $row['ip'] ) : (string) $row['ip'],
				'city'       => (string) $row['city'],
				'region'     => (string) $row['region'],
				'country'    => (string) $row['country_name'],
				'isp'        => (string) $row['isp'],
				'lat'        => (string) $row['lat'],
				'lng'        => (string) $row['lng'],
				'accuracy'   => (string) $row['accuracy'],
				'network'    => (string) $row['network'],
				'battery'    => (string) $row['battery'],
				'photos'     => (string) count( $files['photos'] ),
				'audio'      => '' !== (string) $files['audio'] ? __( 'Yes', 'cloaklink' ) : __( 'No', 'cloaklink' ),
				'video'      => isset( $files['video'] ) && '' !== (string) $files['video'] ? __( 'Yes', 'cloaklink' ) : __( 'No', 'cloaklink' ),
				'purge_at'   => $this->local( (string) $row['purge_at'] ),
			);
		}

		$title = __( 'CloakLink Smart monitoring report', 'cloaklink' );
		if ( $link_id && isset( $names[ $link_id ] ) ) {
			$title = sprintf( /* translators: %s: link title */ __( 'Smart monitoring — %s', 'cloaklink' ), $names[ $link_id ][0] );
		}

		$media = 0;
		foreach ( $rows as $row ) {
			$f = isset( $row['manifest'] ) ? $row['manifest'] : array( 'audio' => '', 'video' => '', 'photos' => array() );
			if ( '' !== (string) $f['audio'] || ( isset( $f['video'] ) && '' !== (string) $f['video'] ) || $f['photos'] ) {
				$media++;
			}
		}

		$summary = array(
			__( 'Conversations', 'cloaklink' ) => number_format_i18n( count( $matrix ) ),
			__( 'With media', 'cloaklink' )    => number_format_i18n( $media ),
			__( 'Dates', 'cloaklink' )         => ( $from || $to ) ? trim( $from . ' – ' . $to ) : __( 'every date', 'cloaklink' ),
		);

		if ( 'xls' === $format ) {
			$this->send_html_table( $matrix, $columns, $title, $summary, 'xls' );
		} elseif ( 'doc' === $format ) {
			$this->send_html_table( $matrix, $columns, $title, $summary, 'doc' );
		} elseif ( 'pdf' === $format ) {
			$this->send_pdf( $matrix, $columns, $title, $summary, array() );
		} else {
			$this->send_csv( $matrix, $columns, $title );
		}
	}

	/**
	 * Export the blocklist.
	 *
	 * @param string $format Format.
	 * @return void
	 */
	private function export_blocks( $format ) {
		$rows = $this->db->get_blocks();

		$columns = array(
			'scope'      => __( 'Scope', 'cloaklink' ),
			'value'      => __( 'Value', 'cloaklink' ),
			'reason'     => __( 'Reason', 'cloaklink' ),
			'hits'       => __( 'Blocked attempts', 'cloaklink' ),
			'created_at' => __( 'Added', 'cloaklink' ),
		);

		$matrix = array();
		foreach ( $rows as $row ) {
			$matrix[] = array(
				'scope'      => $row['scope'],
				'value'      => $row['value'],
				'reason'     => $row['reason'],
				'hits'       => (string) $row['hits'],
				'created_at' => $this->local( $row['created_at'] ),
			);
		}

		$title   = __( 'CloakLink blocklist', 'cloaklink' );
		$summary = array( __( 'Entries', 'cloaklink' ) => number_format_i18n( count( $matrix ) ) );

		if ( 'xls' === $format ) {
			$this->send_html_table( $matrix, $columns, $title, $summary, 'xls' );
		} elseif ( 'doc' === $format ) {
			$this->send_html_table( $matrix, $columns, $title, $summary, 'doc' );
		} elseif ( 'pdf' === $format ) {
			$this->send_pdf( $matrix, $columns, $title, $summary, array() );
		} else {
			$this->send_csv( $matrix, $columns, $title );
		}
	}

	/**
	 * Emit a CSV with a BOM so Excel reads UTF-8 correctly.
	 *
	 * @param array  $matrix  Rows.
	 * @param array  $columns Columns.
	 * @param string $title   File name base.
	 * @return void
	 */
	private function send_csv( $matrix, $columns, $title ) {
		$this->headers( 'text/csv; charset=utf-8', $title, 'csv' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv( $out, array_values( $columns ), ',', '"', '\\' );
		foreach ( $matrix as $row ) {
			$line = array();
			foreach ( array_keys( $columns ) as $key ) {
				$line[] = isset( $row[ $key ] ) ? self::csv_cell( (string) $row[ $key ] ) : '';
			}
			fputcsv( $out, $line, ',', '"', '\\' );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}

	/**
	 * Defuse a cell that a spreadsheet would treat as a formula.
	 *
	 * Excel, LibreOffice and Google Sheets all evaluate a cell beginning with
	 * = + - @ or a tab/return, so a visitor who sets their city to
	 * "=HYPERLINK("http://evil","Click")" writes a live formula into the
	 * operator's export. The export exists to be opened in a spreadsheet,
	 * which makes that the one place it would run. A leading apostrophe makes
	 * the value text; it is not part of what the operator reads.
	 *
	 * @param string $value Raw cell.
	 * @return string
	 */
	private static function csv_cell( $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return '';
		}
		if ( preg_match( '/^[=+\-@\t\r]/', $value ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Emit an HTML-table based Excel or Word document.
	 *
	 * @param array  $matrix  Rows.
	 * @param array  $columns Columns.
	 * @param string $title   Title.
	 * @param array  $summary Summary pairs.
	 * @param string $kind    'xls' or 'doc'.
	 * @return void
	 */
	private function send_html_table( $matrix, $columns, $title, $summary, $kind ) {
		$is_xls = 'xls' === $kind;

		if ( $is_xls ) {
			$this->headers( 'application/vnd.ms-excel; charset=utf-8', $title, 'xls' );
		} else {
			$this->headers( 'application/msword; charset=utf-8', $title, 'doc' );
		}

		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$now  = wp_date( 'd F Y, g:i A', time(), $this->db->tz() );

		if ( $is_xls ) {
			echo '<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8">';
			echo '<meta name="ProgId" content="Excel.Sheet">';
		} else {
			// Word reads a saved HTML page as a document; declaring the Excel
			// namespace here would make it open the table as a spreadsheet.
			echo '<html xmlns:o="urn:schemas-microsoft-com:office:office"';
			echo ' xmlns:w="urn:schemas-microsoft-com:office:word"';
			echo ' xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8">';
			echo '<meta name="ProgId" content="Word.Document">';
			echo '<meta name="Generator" content="CloakLink">';
			echo '<!--[if gte mso 9]><xml><w:WordDocument>';
			echo '<w:View>Print</w:View><w:Zoom>100</w:Zoom>';
			echo '</w:WordDocument></xml><![endif]-->';
		}
		echo '<title>' . esc_html( $title ) . '</title>';
		echo '<style>';
		echo 'body{font-family:Calibri,Arial,sans-serif;font-size:10pt;color:#1a2236;}';
		echo 'h1{font-size:17pt;color:#0d1b3e;margin:0 0 2pt;}';
		echo '.sub{font-size:9pt;color:#6b7280;margin:0 0 12pt;}';
		echo 'table{border-collapse:collapse;width:100%;}';
		echo 'th{background:#0d1b3e;color:#fff;font-size:8pt;text-transform:uppercase;letter-spacing:.4pt;';
		echo 'padding:6pt 5pt;text-align:left;border:0.5pt solid #0d1b3e;}';
		echo 'td{font-size:8.5pt;padding:4pt 5pt;border:0.5pt solid #ddd8cc;vertical-align:top;}';
		echo 'tr:nth-child(even) td{background:#faf8f3;}';
		echo '.kpis td{border:0.5pt solid #ddd8cc;background:#f4f1e9;}';
		echo '.kpis .k{font-size:7.5pt;color:#6b7280;text-transform:uppercase;}';
		echo '.kpis .v{font-size:13pt;color:#0d1b3e;font-weight:bold;}';
		echo '.note{font-size:8pt;color:#6b7280;margin-top:14pt;border-top:0.5pt solid #ddd8cc;padding-top:8pt;}';
		if ( ! $is_xls ) {
			// Word sizes pages in points; without this the table runs off the sheet.
			echo '@page{size:A4 landscape;margin:1.4cm;}';
			echo 'body{font-family:Calibri,Arial,sans-serif;}';
			echo 'table{page-break-inside:auto;}';
			echo 'tr{page-break-inside:avoid;}';
		}
		echo '</style></head><body>';

		echo '<h1>' . esc_html( $title ) . '</h1>';
		echo '<p class="sub">' . esc_html( $site ) . ' · ' . esc_html( $now ) . ' · ' . esc_html( $this->compliance() ) . '</p>';

		if ( $summary ) {
			echo '<table class="kpis"><tr>';
			foreach ( $summary as $label => $value ) {
				echo '<td><div class="k">' . esc_html( $label ) . '</div><div class="v">' . esc_html( $value ) . '</div></td>';
			}
			echo '</tr></table><br>';
		}

		echo '<table><thead><tr>';
		foreach ( $columns as $label ) {
			echo '<th>' . esc_html( $label ) . '</th>';
		}
		echo '</tr></thead><tbody>';

		foreach ( $matrix as $row ) {
			echo '<tr>';
			foreach ( array_keys( $columns ) as $key ) {
				$value = isset( $row[ $key ] ) ? (string) $row[ $key ] : '';
				// Numeric-looking values are emitted as text to protect long IPs and coordinates.
				echo '<td>' . esc_html( $value ) . '</td>';
			}
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '<p class="note">' . esc_html__( 'Generated by CloakLink. Records are collected for access-control and audit purposes; handle them in line with applicable data-protection obligations.', 'cloaklink' ) . '</p>';
		echo '</body></html>';
	}

	/**
	 * Emit the PDF report.
	 *
	 * @param array  $matrix  Rows.
	 * @param array  $columns Columns.
	 * @param string $title   Title.
	 * @param array  $summary Summary pairs.
	 * @param array  $args    Applied filters.
	 * @return void
	 */
	private function send_pdf( $matrix, $columns, $title, $summary, $args ) {
		$this->headers( 'application/pdf', $title, 'pdf' );

		$columns = $this->pdf_columns( $columns );

		// Landscape A4: usable width is W - 2M.
		$usable = CloakLink_PDF::W - ( 2 * CloakLink_PDF::M );

		$pdf = new CloakLink_PDF( array_values( $columns ), $this->pdf_widths( $columns, $usable ) );

		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$pdf->banner( $title, $site . ' · ' . wp_date( 'd F Y, g:i A', time(), $this->db->tz() ) . ' · ' . $this->compliance(), 'CloakLink' );

		if ( $summary ) {
			$pdf->kpis( $summary );
		}

		$pdf->field( __( 'Report basis', 'cloaklink' ), $this->basis_text( $args ) );

		$n = 0;
		foreach ( $matrix as $row ) {
			$cells = array();
			foreach ( array_keys( $columns ) as $key ) {
				$cells[] = isset( $row[ $key ] ) ? (string) $row[ $key ] : '';
			}
			$pdf->row( $cells, ( $n % 2 ) === 1 );
			$n++;
		}

		if ( ! $matrix ) {
			$pdf->field( __( 'Records', 'cloaklink' ), __( 'No records matched the selected filters.', 'cloaklink' ) );
		}

		echo $pdf->output( $title, $title . ' · ' . $site ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Trim the column list to what stays legible on a printed A4 page.
	 * CSV, Excel and Word keep every field; the PDF is a readable report.
	 *
	 * @param array $columns All columns.
	 * @return array
	 */
	private function pdf_columns( $columns ) {
		if ( count( $columns ) <= 16 ) {
			return $columns;
		}

		// A printed A4 landscape page reads well up to about 12 data columns.
		$print = array(
			'created_at'   => __( 'When', 'cloaklink' ),
			'event'        => __( 'Event', 'cloaklink' ),
			'slug'         => __( 'Link', 'cloaklink' ),
			'device'       => __( 'Device', 'cloaklink' ),
			'country_code' => __( 'Country', 'cloaklink' ),
			'city'         => __( 'City', 'cloaklink' ),
			'lat'          => __( 'Latitude', 'cloaklink' ),
			'lng'          => __( 'Longitude', 'cloaklink' ),
			'accuracy'     => __( 'GPS (m)', 'cloaklink' ),
			'ip'           => __( 'IP address', 'cloaklink' ),
			'isp'          => __( 'Network', 'cloaklink' ),
			'risk'         => __( 'Risk', 'cloaklink' ),
			'flags'        => __( 'Flags', 'cloaklink' ),
		);

		$link_fields = array(
			'slug'        => __( 'Slug', 'cloaklink' ),
			'title'       => __( 'Name', 'cloaklink' ),
			'link_type'   => __( 'Type', 'cloaklink' ),
			'destination' => __( 'Destination', 'cloaklink' ),
			'click_count' => __( 'Opens', 'cloaklink' ),
			'max_clicks'  => __( 'Cap', 'cloaklink' ),
			'status'      => __( 'Status', 'cloaklink' ),
			'expires_at'  => __( 'Expires', 'cloaklink' ),
			'created_at'  => __( 'Created', 'cloaklink' ),
		);

		$block_fields = array(
			'scope'      => __( 'Scope', 'cloaklink' ),
			'value'      => __( 'Value', 'cloaklink' ),
			'reason'     => __( 'Reason', 'cloaklink' ),
			'hits'       => __( 'Attempts', 'cloaklink' ),
			'created_at' => __( 'Added', 'cloaklink' ),
		);

		$set = $print;
		if ( isset( $columns['destination'] ) ) {
			$set = $link_fields;
		} elseif ( isset( $columns['scope'] ) ) {
			$set = $block_fields;
		}

		$out = array();
		foreach ( $set as $key => $label ) {
			if ( isset( $columns[ $key ] ) ) {
				$out[ $key ] = $label;
			}
		}

		return $out ? $out : $columns;
	}

	/**
	 * Widths for the PDF table, weighted by column.
	 *
	 * @param array $columns Columns.
	 * @param float $usable  Usable width.
	 * @return array
	 */
	private function pdf_widths( $columns, $usable ) {
		$weights = array(
			'created_at'   => 1.15,
			'event'        => 0.8,
			'slug'         => 0.9,
			'device'       => 0.75,
			'brand'        => 0.7,
			'device_model' => 1.1,
			'os'           => 0.9,
			'browser'      => 1.0,
			'country_code' => 0.65,
			'country_name' => 1.0,
			'region'       => 1.0,
			'city'         => 1.0,
			'lat'          => 0.85,
			'lng'          => 0.85,
			'accuracy'     => 0.65,
			'gps_error'    => 0.75,
			'ip'           => 1.1,
			'isp'          => 1.4,
			'asn'          => 0.6,
			'vpn'          => 0.7,
			'screen'       => 0.7,
			'viewport'     => 0.7,
			'tz'           => 0.9,
			'lang'         => 0.6,
			'referrer'     => 1.4,
			'campaign'     => 0.8,
			'insta_id'     => 0.9,
			'risk'         => 0.55,
			'flags'        => 1.6,
			'ua'           => 0,
			'title'        => 1.6,
			'label'        => 1.0,
			'link_type'    => 0.8,
			'destination'  => 2.2,
			'host'         => 1.2,
			'click_count'  => 0.7,
			'max_clicks'   => 0.7,
			'status'       => 0.8,
			'expires_at'   => 1.1,
			'public_url'   => 2.0,
			'scope'        => 0.8,
			'value'        => 1.4,
			'reason'       => 1.6,
			'hits'         => 0.8,
		);

		$keys  = array_keys( $columns );
		$count = max( 1, count( $keys ) );

		// Reserve a legible minimum for every column, then share the rest by weight.
		$floor = ( $count > 20 ) ? 26.0 : 34.0;
		$floor = min( $floor, ( $usable / $count ) * 0.9 );

		$total = 0;
		$w     = array();
		foreach ( $keys as $key ) {
			$w[ $key ] = isset( $weights[ $key ] ) ? max( 0.5, (float) $weights[ $key ] ) : 1.0;
			$total    += $w[ $key ];
		}

		$out = array();
		foreach ( $keys as $key ) {
			$out[] = max( $floor, ( $w[ $key ] / $total ) * $usable );
		}

		// Renormalise so the table exactly fills the usable width.
		$sum = array_sum( $out );
		if ( $sum > 0 ) {
			$out = array_map(
				static function ( $v ) use ( $sum, $usable ) {
					return ( $v / $sum ) * $usable;
				},
				$out
			);
		}
		return $out;
	}

	/**
	 * Human description of the filters used.
	 *
	 * @param array $args Filters.
	 * @return string
	 */
	private function basis_text( $args ) {
		$bits = array();
		if ( ! empty( $args['link_id'] ) ) {
			$link = $this->db->get_link( $args['link_id'] );
			if ( $link ) {
				$bits[] = sprintf( /* translators: %s: link title */ __( 'single link: %s', 'cloaklink' ), $link['title'] );
			}
		} else {
			$bits[] = __( 'all links', 'cloaklink' );
		}
		if ( ! empty( $args['event'] ) ) {
			$bits[] = sprintf( /* translators: %s: event */ __( 'event: %s', 'cloaklink' ), $args['event'] );
		}
		if ( ! empty( $args['device'] ) ) {
			$bits[] = sprintf( /* translators: %s: device */ __( 'device: %s', 'cloaklink' ), $args['device'] );
		}
		if ( ! empty( $args['country'] ) ) {
			$bits[] = sprintf( /* translators: %s: code */ __( 'country: %s', 'cloaklink' ), strtoupper( $args['country'] ) );
		}
		if ( ! empty( $args['from'] ) || ! empty( $args['to'] ) ) {
			$bits[] = sprintf(
				/* translators: 1: from date, 2: to date */
				__( 'period: %1$s to %2$s', 'cloaklink' ),
				$args['from'] ? $args['from'] : '…',
				$args['to'] ? $args['to'] : '…'
			);
		}
		if ( ! empty( $args['risk_min'] ) ) {
			$bits[] = sprintf( /* translators: %d: score */ __( 'risk >= %d', 'cloaklink' ), (int) $args['risk_min'] );
		}
		if ( ! empty( $args['search'] ) ) {
			$bits[] = sprintf( /* translators: %s: term */ __( 'search: %s', 'cloaklink' ), $args['search'] );
		}
		return implode( ' · ', $bits );
	}

	/**
	 * The compliance note used in exports.
	 *
	 * @return string
	 */
	private function compliance() {
		$note = (string) $this->settings->get( 'brand_note' );
		if ( '' === $note ) {
			$note = __( 'Independent platform. Not a government, court or tribunal service.', 'cloaklink' );
		}
		return $note;
	}

	/**
	 * Send download headers and clean any buffer.
	 *
	 * @param string $type Content type.
	 * @param string $name File name base.
	 * @param string $ext  Extension.
	 * @return void
	 */
	private function headers( $type, $name, $ext ) {
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		$slug = sanitize_title( $name );
		$slug = $slug ? $slug : 'cloaklink-export';
		$file = $slug . '-' . wp_date( 'Ymd-Hi' ) . '.' . $ext;

		nocache_headers();
		header( 'Content-Type: ' . $type );
		header( 'Content-Disposition: attachment; filename="' . $file . '"' );
		header( 'X-Content-Type-Options: nosniff' );
	}
}
