<?php
/**
 * IP resolution and geo intelligence.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolves the visitor IP and enriches it with country / city / ISP data.
 */
class CloakLink_Geo {

	/** @var array Request-scoped cache keyed by ip. */
	private static $cache = array();

	/**
	 * Best-effort real client IP.
	 *
	 * Only trusts proxy headers when the site is actually behind a proxy
	 * (Cloudflare, or an explicit filter allowing it), so the value cannot
	 * be spoofed by a plain request.
	 *
	 * @return string
	 */
	public static function ip() {
		$candidates = array();

		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$candidates[] = $_SERVER['HTTP_CF_CONNECTING_IP']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}
		if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$candidates[] = $_SERVER['REMOTE_ADDR']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}

		if ( apply_filters( 'cloaklink_trust_proxy_headers', false ) ) {
			foreach ( array( 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_TRUE_CLIENT_IP' ) as $key ) {
				if ( ! empty( $_SERVER[ $key ] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
					$parts = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
					$candidates[] = trim( $parts[0] );
				}
			}
		}

		foreach ( $candidates as $candidate ) {
			$candidate = trim( (string) $candidate );
			if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
				return $candidate;
			}
		}
		return '0.0.0.0';
	}

	/**
	 * Hash an IP for unique-visitor counting without storing it twice.
	 *
	 * @param string $ip IP.
	 * @return string
	 */
	public static function hash_ip( $ip ) {
		return hash( 'sha256', strtolower( (string) $ip ) . '|' . wp_salt( 'nonce' ) );
	}

	/**
	 * Whether an IP is private / loopback.
	 *
	 * @param string $ip IP.
	 * @return bool
	 */
	public static function is_local( $ip ) {
		if ( '0.0.0.0' === $ip ) {
			return true;
		}
		return ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	}

	/**
	 * Look up geo data for an IP.
	 *
	 * @param string $ip         IP.
	 * @param string $provider   'ipwho' | 'ipapi' | 'none'.
	 * @param string $key        API key (optional).
	 * @return array
	 */
	public static function lookup( $ip, $provider = 'ipwho', $key = '' ) {
		$cache_key = $provider . '|' . $ip;
		if ( isset( self::$cache[ $cache_key ] ) ) {
			return self::$cache[ $cache_key ];
		}

		$empty = array(
			'country_code' => '',
			'country_name' => '',
			'region'       => '',
			'city'         => '',
			'isp'          => '',
			'asn'          => '',
			'proxy'        => 0,
			'vpn'          => 0,
		);

		if ( self::is_local( $ip ) || 'none' === $provider ) {
			self::$cache[ $cache_key ] = $empty;
			return $empty;
		}

		$cached       = get_transient( 'cloaklink_geo_' . md5( $ip ) );
		if ( is_array( $cached ) ) {
			self::$cache[ $cache_key ] = $cached;
			return $cached;
		}

		$data = $empty;

		if ( 'ipapi' === $provider ) {
			$url = 'https://ipapi.co/' . rawurlencode( $ip ) . '/json/';
		} else {
			$url = 'https://ipwho.is/' . rawurlencode( $ip ) . '?fields=success,country,country_code,region,city,connection,security';
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 4,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $body ) ) {
				if ( 'ipapi' === $provider ) {
					$data['country_code'] = isset( $body['country_code'] ) ? strtoupper( (string) $body['country_code'] ) : '';
					$data['country_name'] = isset( $body['country_name'] ) ? (string) $body['country_name'] : '';
					$data['region']       = isset( $body['region'] ) ? (string) $body['region'] : '';
					$data['city']         = isset( $body['city'] ) ? (string) $body['city'] : '';
					$data['isp']          = isset( $body['org'] ) ? (string) $body['org'] : '';
					$data['asn']          = isset( $body['asn'] ) ? (string) $body['asn'] : '';
				} elseif ( ! isset( $body['success'] ) || true === $body['success'] ) {
					$conn                 = isset( $body['connection'] ) && is_array( $body['connection'] ) ? $body['connection'] : array();
					$sec                  = isset( $body['security'] ) && is_array( $body['security'] ) ? $body['security'] : array();
					$data['country_code'] = isset( $body['country_code'] ) ? strtoupper( (string) $body['country_code'] ) : '';
					$data['country_name'] = isset( $body['country'] ) ? (string) $body['country'] : '';
					$data['region']       = isset( $body['region'] ) ? (string) $body['region'] : '';
					$data['city']         = isset( $body['city'] ) ? (string) $body['city'] : '';
					$data['isp']          = isset( $conn['isp'] ) ? (string) $conn['isp'] : ( isset( $conn['org'] ) ? (string) $conn['org'] : '' );
					$data['asn']          = isset( $conn['asn'] ) ? (string) $conn['asn'] : '';
					$data['proxy']        = ! empty( $sec['proxy'] ) ? 1 : 0;
					$data['vpn']          = ! empty( $sec['vpn'] ) ? 1 : 0;
				}
			}
		}

		$data['country_name'] = $data['country_name'] ? $data['country_name'] : self::country_name( $data['country_code'] );

		set_transient( 'cloaklink_geo_' . md5( $ip ), $data, HOUR_IN_SECONDS );
		self::$cache[ $cache_key ] = $data;
		return $data;
	}

	/**
	 * Rough country label for a code (fallback list; full list in assets).
	 *
	 * @param string $code ISO code.
	 * @return string
	 */
	public static function country_name( $code ) {
		$code = strtoupper( (string) $code );
		$map  = array(
			'IN' => 'India', 'US' => 'United States', 'GB' => 'United Kingdom', 'AE' => 'United Arab Emirates',
			'CA' => 'Canada', 'AU' => 'Australia', 'SG' => 'Singapore', 'DE' => 'Germany', 'FR' => 'France',
			'NL' => 'Netherlands', 'RU' => 'Russia', 'CN' => 'China', 'PK' => 'Pakistan', 'BD' => 'Bangladesh',
			'NP' => 'Nepal', 'LK' => 'Sri Lanka', 'MY' => 'Malaysia', 'SA' => 'Saudi Arabia', 'QA' => 'Qatar',
			'JP' => 'Japan', 'KR' => 'South Korea', 'BR' => 'Brazil', 'ZA' => 'South Africa', 'NG' => 'Nigeria',
			'KE' => 'Kenya', 'HK' => 'Hong Kong', 'TH' => 'Thailand', 'ID' => 'Indonesia', 'PH' => 'Philippines',
			'TR' => 'Turkey', 'IR' => 'Iran', 'IL' => 'Israel', 'EG' => 'Egypt', 'MX' => 'Mexico',
		);
		return isset( $map[ $code ] ) ? $map[ $code ] : $code;
	}

	/**
	 * Reverse-geocode GPS coordinates to a readable place (best effort).
	 *
	 * @param float $lat Latitude.
	 * @param float $lng Longitude.
	 * @return string
	 */
	public static function reverse( $lat, $lng ) {
		$key = 'cloaklink_rev_' . md5( $lat . ',' . $lng );
		$hit = get_transient( $key );
		if ( is_string( $hit ) ) {
			return $hit;
		}
		$label = '';
		$url   = add_query_arg(
			array(
				'format'         => 'jsonv2',
				'lat'            => $lat,
				'lon'            => $lng,
				'zoom'           => 12,
				'addressdetails' => 1,
			),
			'https://nominatim.openstreetmap.org/reverse'
		);
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 4,
				'headers' => array( 'User-Agent' => 'CloakLink/1.0 (cc-co.in)' ),
			)
		);
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $body ) && ! empty( $body['display_name'] ) ) {
				$label = (string) $body['display_name'];
			}
		}
		set_transient( $key, $label, DAY_IN_SECONDS );
		return $label;
	}
}
