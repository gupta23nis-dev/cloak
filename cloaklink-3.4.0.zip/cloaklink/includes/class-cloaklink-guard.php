<?php
/**
 * The network gate for the restricted console.
 *
 * A second panel address exists so the full console can be reached from
 * anywhere an operator is signed in, while the visitor data — the logs, the
 * positions, the captured media — answers only to networks the operator has
 * named. This class holds the rule and nothing else: who is allowed in, and
 * how the list is read.
 *
 * The list is deliberately simple, because a wrong rule here either locks an
 * operator out or lets a stranger in:
 *
 *   - 203.0.113.7        one address
 *   - 203.0.113.0/24     a block, in the usual CIDR form
 *   - 203.0.113.         everything the prefix covers
 *   - 2001:db8::/32      an IPv6 block
 *
 * Anything else is dropped when the list is saved, so the matcher never has
 * to guess what a line meant. An empty list matches nothing: an allowlist
 * that quietly allows everybody is worse than no allowlist at all.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Network gate.
 */
final class CloakLink_Guard {

	/**
	 * Normalise a pasted list into one entry per line.
	 *
	 * @param string $raw Textarea contents.
	 * @return string
	 */
	public static function clean_list( $raw ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) {
				continue;
			}
			// A comment is for the person reading the list, not for the gate.
			$hash = strpos( $line, '#' );
			if ( false !== $hash ) {
				$line = trim( substr( $line, 0, $hash ) );
			}
			// Trailing spaces or a stray comma from a spreadsheet paste.
			$line = trim( $line, " \t,;" );
			if ( '' === $line ) {
				continue;
			}
			$one = self::normalise_entry( $line );
			if ( '' !== $one && ! in_array( $one, $out, true ) ) {
				$out[] = $one;
			}
		}
		return implode( "\n", $out );
	}

	/**
	 * Reduce one line to a form the matcher understands, or ''.
	 *
	 * @param string $line One entry.
	 * @return string
	 */
	private static function normalise_entry( $line ) {
		// A full IPv6 address written out and nothing else.
		if ( false !== strpos( $line, ':' ) ) {
			// CIDR block first, because the address part is not a full address.
			if ( preg_match( '#^([0-9a-fA-F:.]+)/(\d{1,3})$#', $line, $m ) ) {
				$net = @inet_pton( $m[1] );
				if ( false === $net ) {
					return '';
				}
				$bits = (int) $m[2];
				if ( $bits < 0 || $bits > strlen( $net ) * 8 ) {
					return '';
				}
				return inet_ntop( $net ) . '/' . $bits;
			}
			return filter_var( $line, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ? $line : '';
		}

		// A block: the network is validated, the prefix length is only a count.
		if ( preg_match( '#^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$#', $line, $m ) ) {
			$bits = (int) $m[2];
			return filter_var( $m[1], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) && $bits <= 32
				? $m[1] . '/' . $bits
				: '';
		}

		// A whole address.
		if ( filter_var( $line, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return $line;
		}

		// A prefix: "203.0.113." or "203.0." — at least two octets, so a
		// single "10" cannot quietly mean "everything starting with 10".
		if ( preg_match( '#^(\d{1,3}(?:\.\d{1,3}){1,3})\.$#', $line, $m ) ) {
			$parts = explode( '.', $m[1] );
			foreach ( $parts as $part ) {
				if ( (int) $part > 255 ) {
					return '';
				}
			}
			if ( count( $parts ) < 2 ) {
				return '';
			}
			return $m[1] . '.';
		}

		return '';
	}

	/**
	 * Does an address fall inside the stored list?
	 *
	 * @param string $ip    Address to test.
	 * @param string $rules Stored list, one entry per line.
	 * @return bool
	 */
	public static function allowed( $ip, $rules ) {
		$ip = trim( (string) $ip );
		if ( '' === $ip || '0.0.0.0' === $ip ) {
			return false;
		}
		$packed = @inet_pton( $ip );
		if ( false === $packed ) {
			return false;
		}

		foreach ( preg_split( '/\s+/', (string) $rules ) as $rule ) {
			$rule = trim( $rule );
			if ( '' === $rule ) {
				continue;
			}
			if ( false !== strpos( $rule, '/' ) ) {
				if ( self::in_block( $ip, $packed, $rule ) ) {
					return true;
				}
				continue;
			}
			if ( '.' === substr( $rule, -1 ) ) {
				if ( 0 === strpos( strtolower( $ip ), strtolower( $rule ) ) ) {
					return true;
				}
				continue;
			}
			// A bare address: compared as bytes so an IPv6 address written in
			// two valid but different ways still matches.
			$one = @inet_pton( $rule );
			if ( false !== $one && $one === $packed ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Is this address inside one CIDR block?
	 *
	 * @param string $ip     Address as text (for the family check).
	 * @param string $packed Address as bytes.
	 * @param string $block  "network/bits".
	 * @return bool
	 */
	private static function in_block( $ip, $packed, $block ) {
		list( $net, $bits ) = array_pad( explode( '/', $block, 2 ), 2, '' );
		$net    = @inet_pton( $net );
		$bits   = (int) $bits;
		if ( false === $net || strlen( $net ) !== strlen( $packed ) ) {
			return false;
		}
		$max = strlen( $packed ) * 8;
		if ( $bits < 0 || $bits > $max ) {
			return false;
		}
		$bytes = intdiv( $bits, 8 );
		$rest  = $bits % 8;

		if ( $bytes > 0 && strncmp( $net, $packed, $bytes ) !== 0 ) {
			return false;
		}
		if ( 0 === $rest ) {
			return true;
		}
		// The partial byte: both are masked to their leading bits.
		$mask = chr( 0xff << ( 8 - $rest ) & 0xff );
		return ( $net[ $bytes ] & $mask ) === ( $packed[ $bytes ] & $mask );
	}

	/**
	 * The address the gate tests.
	 *
	 * Kept identical to the address the rest of the plugin records, so the
	 * gate and the log can never disagree about who asked.
	 *
	 * @return string
	 */
	public static function ip() {
		return CloakLink_Geo::ip();
	}

	/**
	 * Is the restricted console switched on and does this request pass?
	 *
	 * @return bool
	 */
	public static function passes() {
		// An operator who has locked themselves out — a new office, a changed
		// home connection, a phone on a different carrier — has no way back in
		// through the panel, because the panel is what they cannot reach. This
		// one line in wp-config.php is the way back: it skips the address test
		// for the restricted console and nothing else, so a sign-in is still
		// required and the data is still behind a password.
		$settings = cloaklink()->settings;
		if ( defined( 'CLOAKLINK_UNLOCK' ) && CLOAKLINK_UNLOCK ) {
			return (bool) $settings->get( 'ip_lock_enabled' );
		}

		if ( ! $settings->get( 'ip_lock_enabled' ) ) {
			// Switched off, the address exists for nobody. A gate that is off
			// must not leave a second way in open.
			return false;
		}
		return self::allowed( self::ip(), (string) $settings->get( 'ip_lock_list' ) );
	}

	/**
	 * Is this address listed, for the settings screen to show at rest?
	 *
	 * @param string $ip Address to test.
	 * @return bool
	 */
	public static function listed( $ip ) {
		return self::allowed( $ip, (string) cloaklink()->settings->get( 'ip_lock_list' ) );
	}
}
