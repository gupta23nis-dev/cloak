<?php
/** Simple voluntary email support requests. No GPS, recordings, or simulated live calls. */
defined( 'ABSPATH' ) || exit;
class CloakLink_Help {
    public static function ajax_request() {
        if ( ! check_ajax_referer( 'cloaklink_help', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Session expired. Refresh and try again.' ), 403 );
        }
        $id = isset( $_POST['link_id'] ) ? absint( wp_unslash( $_POST['link_id'] ) ) : 0;
        $reason = isset( $_POST['reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) : '';
        $name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
        $contact = isset( $_POST['contact'] ) ? sanitize_text_field( wp_unslash( $_POST['contact'] ) ) : '';
        if ( ! empty( $_POST['website'] ) || strlen( $reason ) < 8 || strlen( $reason ) > 2000 || strlen( $name ) > 120 || strlen( $contact ) < 5 || strlen( $contact ) > 150 ) {
            wp_send_json_error( array( 'message' => 'Enter a reason (at least 8 characters) and contact email or phone.' ), 400 );
        }
        $link = $id ? cloaklink()->db->get_link( $id ) : null;
        if ( ! $link || 'legal' !== $link['link_type'] || '' !== cloaklink()->links->state( $link ) ) {
            wp_send_json_error( array( 'message' => 'Document link is not available.' ), 404 );
        }
        $email = sanitize_email( cloaklink()->settings->get( 'brand_email' ) );
        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => 'The administrator has not set up a support email.' ), 503 );
        }
        $key = 'cl_help_' . substr( wp_hash( 'help|' . CloakLink_Geo::ip() ), 0, 24 );
        if ( (int) get_transient( $key ) >= 4 ) {
            wp_send_json_error( array( 'message' => 'Too many recent requests. Try later.' ), 429 );
        }
        set_transient( $key, (int) get_transient( $key ) + 1, HOUR_IN_SECONDS );
        $message = "New Credit Control support request\n\nName: {$name}\nContact: {$contact}\nReference: " . sanitize_text_field( $link['slug'] ) . "\n\nReason:\n{$reason}\n\nNo camera, microphone or GPS data was collected.";
        $sent = wp_mail( $email, 'Credit Control: support request', $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );
        if ( ! $sent ) {
            wp_send_json_error( array( 'message' => 'Mail delivery failed. Please contact support directly.' ), 503 );
        }
        wp_send_json_success( array( 'message' => 'Your request has been sent. The team can contact you using the details you provided.' ) );
    }
}
