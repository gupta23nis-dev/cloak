<?php
/**
 * Activation, table creation and schema upgrades.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Installer.
 */
class CloakLink_Install {

	const SCHEMA_KEY = 'cloaklink_db_version';
	// 1.9.1: the public rewrite rule was widened so an address printed with a
	// file extension after it (…-GAJENDRA_S_N.pdf) still routes. That rule is
	// stored in the database, not read from this file, so the version has to
	// move or an upgraded install keeps the old rule and every suffixed address
	// 404s.
	// 1.9.3: the step rules ("<slug>/l/legal", "<slug>/l/open") were being
	// swallowed by the bare rule once slugs could contain "/", so a link that
	// had just been created answered 404 on its own open step. The rule ORDER
	// lives in the database, so the version has to move again for an upgraded
	// install to pick the new order up.
	// 1.9.14: the ticket ledger. A ticket that is removed takes its own row
	// with it, so the only record of who removed it, when, and what it said is
	// a table of its own. An upgraded install needs the version to move or the
	// table is never created and every ledger write is silently refused.
	const SCHEMA_VER = '1.9.15';
	const COPY_VER = '2.9.76';

	/**
	 * Run on activation.
	 */
	public static function activate() {
		self::create_tables();
		self::seed_settings();
		cloaklink()->links->ensure_link_page();
		CloakLink_Cron::schedule();
		update_option( self::SCHEMA_KEY, self::SCHEMA_VER );
		self::flush_rules();
	}

	/**
	 * Register our rules and save them.
	 *
	 * WordPress calls an activation hook after it has already loaded the
	 * active plugins and fired init, so this plugin's rewrite rules were never
	 * added to the table that flush_rewrite_rules() then wrote. Adding them
	 * here first is what makes /go/<slug> resolve at all; without it every
	 * link falls through to the theme's own 404 and nothing can be logged.
	 */
	public static function flush_rules() {
		global $wp_rewrite;

		// On plugins_loaded the rewrite object has not been built yet, and
		// add_rewrite_rule() would fatal on null. Defer instead of crashing:
		// the init hook runs a moment later and does the work properly.
		if ( ! is_object( $wp_rewrite ) ) {
			add_action( 'init', array( __CLASS__, 'flush_rules' ), 100 );
			return;
		}

		if ( function_exists( 'cloaklink' ) ) {
			cloaklink()->router->register_rewrites();
			if ( ! empty( cloaklink()->login ) ) {
				cloaklink()->login->register_rewrites();
			}
		}
		flush_rewrite_rules( false );

		// Remember what was written, so the self-heal below stays quiet until
		// something that changes the rules actually changes.
		if ( function_exists( 'cloaklink' ) ) {
			$settings = cloaklink()->settings;
			$settings->all();
			$base = trim( (string) $settings->get( 'base_path' ), '/' );
			if ( '' === $base ) {
				$base = 'go';
			}
			// The restricted address is part of the signature: renaming it
			// rebuilt the panel path but left the old rule in the table, so the
			// new address 404'd until somebody opened Tools.
			$sig = md5( $base . '|' . (int) $settings->get( 'link_page_id' ) . '|' . (string) $settings->get( 'panel_slug' ) . '|' . (string) $settings->get( 'ip_lock_page' ) . '|' . self::SCHEMA_VER );
			update_option( 'cloaklink_rules_sig', $sig, false );
		}
	}

	/**
	 * Run on deactivation.
	 */
	public static function deactivate() {
		CloakLink_Cron::unschedule();
		flush_rewrite_rules( false );
	}

	/**
	 * Create or upgrade tables when needed.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'cloaklink_copy_version' ) !== self::COPY_VER ) {
			self::migrate_settings();
			update_option( 'cloaklink_copy_version', self::COPY_VER, false );
		}
		$installed = get_option( self::SCHEMA_KEY );
		if ( self::SCHEMA_VER !== $installed ) {
			self::create_tables();
			self::seed_settings();
			self::migrate_settings();
			cloaklink()->links->ensure_link_page();
			CloakLink_Cron::schedule();
			update_option( self::SCHEMA_KEY, self::SCHEMA_VER );
			self::flush_rules();
		}
	}

	/**
	 * Self-heal the rule table when the link path is not actually routed.
	 *
	 * Runs late on init, after the rules have been registered, so it can compare
	 * what is stored against what this plugin now needs. A plugin copied in by
	 * FTP, a restored database, or an activation that ran before the rules
	 * existed all leave the same symptom: every /go/<slug> hits the theme 404
	 * and nothing is ever logged. This notices and repairs it without anyone
	 * having to open Settings → Permalinks.
	 */
	public static function maybe_flush() {
		if ( ! function_exists( 'cloaklink' ) ) {
			return;
		}

		$settings = cloaklink()->settings;
		$base     = trim( (string) $settings->get( 'base_path' ), '/' );
		if ( '' === $base ) {
			$base = 'go';
		}

		// The signature covers everything that changes the rule set.
		// The restricted console's address is part of the signature too.
		// Leaving it out meant renaming that door left the old rule in the
		// table, and the new address answered with a 404 until somebody
		// happened to open Tools.
		$want = md5( $base . '|' . (int) $settings->get( 'link_page_id' ) . '|' . (string) $settings->get( 'panel_slug' ) . '|' . (string) $settings->get( 'ip_lock_page' ) . '|' . self::SCHEMA_VER );
		$have = get_option( 'cloaklink_rules_sig' );

		if ( $want === $have ) {
			return;
		}

		// Only one request should pay for the flush.
		if ( get_transient( 'cloaklink_flushing_rules' ) ) {
			return;
		}
		set_transient( 'cloaklink_flushing_rules', 1, MINUTE_IN_SECONDS );

		if ( function_exists( 'cloaklink' ) ) {
			cloaklink()->router->register_rewrites();
		}
		flush_rewrite_rules( false );
		update_option( 'cloaklink_rules_sig', $want, false );
		delete_transient( 'cloaklink_flushing_rules' );

		// The rules signature only says this plugin thinks it wrote the right
		// table. What matters is whether a request for a real link actually
		// reaches WordPress, and that can be false while every stored value is
		// correct: a host that strips the rewrite, a front controller that
		// answers first, a proxy that 404s an unknown path. So one real link
		// is fetched and, if it comes back a 404, the operator is told on the
		// screen they will be looking at rather than left to discover it from
		// the recipient's phone.
		self::check_routing_health();
	}

	/**
	 * Fetch one real link and record whether this site actually routes it.
	 *
	 * Runs at most once every ten minutes and only when there is a link to
	 * try. The result is a stored verdict the console reads, not a warning
	 * printed on a public page.
	 *
	 * @return void
	 */
	public static function check_routing_health( $slug = '', $force = false ) {
		// Without a slug there is nothing specific to try, so the throttle
		// applies. With one — a link that was just made, and is about to be
		// sent to a visitor — the answer is about that exact address and is
		// wanted now, so the throttle is skipped and the verdict is stored
		// under the address it was measured on.
		$key = '' !== (string) $slug ? 'cloaklink_route_check_' . md5( (string) $slug ) : 'cloaklink_route_check';
		if ( ! $force && get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, 10 * MINUTE_IN_SECONDS );

		if ( ! function_exists( 'cloaklink' ) ) {
			return;
		}

		global $wpdb;
		if ( '' === (string) $slug ) {
			$slug = $wpdb->get_var(
				'SELECT slug FROM ' . $wpdb->prefix . "cloak_links WHERE status = 'active' ORDER BY id DESC LIMIT 1"
			);
		}
		if ( ! $slug ) {
			delete_option( 'cloaklink_route_health' );
			return;
		}

		// Two addresses, both real, because they fail for different reasons and
		// only one of them is the one a visitor may be given.
		//
		//   clean  — the printed address ("/go/<slug>" or the document form at
		//            the root). Needs the host to forward extension-less paths
		//            to index.php. On a host that does not, this 404s at the
		//            front door, before WordPress has seen the request.
		//   query  — "/?cloaklink_slug=<slug>". Needs nothing from the host
		//            beyond index.php, so it works everywhere.
		//
		// Recording both is what lets the console print the address that
		// actually works instead of the one that merely looks right, and it
		// lets the Tools screen say which of the two is broken.
		$clean = cloaklink()->settings->base_url() . '/' . $slug;
		$query = untrailingslashit( home_url() ) . '/?cloaklink_slug=' . rawurlencode( (string) $slug );

		$fetch = function ( $url ) {
			$res = wp_remote_get(
				$url,
				array(
					'timeout'     => 6,
					'redirection' => 0,
					'sslverify'   => false,
					'headers'     => array( 'X-CloakLink-Check' => '1' ),
				)
			);
			if ( is_wp_error( $res ) ) {
				return null;
			}
			return (int) wp_remote_retrieve_response_code( $res );
		};

		$clean_code = $fetch( $clean );
		$query_code = $fetch( $query );

		// A verdict of "cannot be reached from here at all" is about the
		// server's view of itself, which on loopback-blocked hosting is true
		// even when the site works for the world. It is kept as its own state
		// rather than folded into "broken".
		$ok = ( null !== $clean_code && $clean_code >= 200 && $clean_code < 400 );

		update_option(
			'cloaklink_route_health',
			array(
				'ok'         => null === $clean_code ? null : $ok,
				'code'       => (int) $clean_code,
				'url'        => $clean,
				'query_ok'   => ( null !== $query_code && $query_code >= 200 && $query_code < 400 ),
				'query_code' => (int) $query_code,
				'query_url'  => $query,
				'at'         => time(),
			),
			false
		);
	}

	/**
	 * Build the three custom tables.
	 */
	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$prefix  = $wpdb->prefix;

		$links = "CREATE TABLE {$prefix}cloak_links (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug VARCHAR(120) NOT NULL,
			title VARCHAR(191) NOT NULL DEFAULT '',
			label VARCHAR(191) NOT NULL DEFAULT '',
			link_type VARCHAR(20) NOT NULL DEFAULT 'redirect',
			destination TEXT NULL,
			destination_host VARCHAR(191) NOT NULL DEFAULT '',
			media_url TEXT NULL,
			media_kind VARCHAR(20) NOT NULL DEFAULT '',
			page_title VARCHAR(191) NOT NULL DEFAULT '',
			mode VARCHAR(20) NOT NULL DEFAULT 'require',
			max_clicks INT UNSIGNED NOT NULL DEFAULT 0,
			click_count INT UNSIGNED NOT NULL DEFAULT 0,
			meta LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			expires_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status),
			KEY expires_at (expires_at)
		) {$charset};";

		$visits = "CREATE TABLE {$prefix}cloak_visits (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			link_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			slug VARCHAR(120) NOT NULL DEFAULT '',
			visit_uuid VARCHAR(40) NOT NULL DEFAULT '',
			event VARCHAR(20) NOT NULL DEFAULT 'view',
			status VARCHAR(32) NOT NULL DEFAULT '',
			ip VARCHAR(64) NOT NULL DEFAULT '',
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			country_code CHAR(2) NOT NULL DEFAULT '',
			country_name VARCHAR(80) NOT NULL DEFAULT '',
			region VARCHAR(120) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			isp VARCHAR(191) NOT NULL DEFAULT '',
			asn VARCHAR(32) NOT NULL DEFAULT '',
			is_proxy TINYINT(1) NOT NULL DEFAULT 0,
			is_vpn TINYINT(1) NOT NULL DEFAULT 0,
			lat VARCHAR(32) NOT NULL DEFAULT '',
			lng VARCHAR(32) NOT NULL DEFAULT '',
			accuracy VARCHAR(24) NOT NULL DEFAULT '',
			gps_error VARCHAR(80) NOT NULL DEFAULT '',
			device VARCHAR(24) NOT NULL DEFAULT '',
			brand VARCHAR(64) NOT NULL DEFAULT '',
			device_model VARCHAR(96) NOT NULL DEFAULT '',
			os VARCHAR(64) NOT NULL DEFAULT '',
			browser VARCHAR(64) NOT NULL DEFAULT '',
			ua TEXT NULL,
			screen VARCHAR(24) NOT NULL DEFAULT '',
			viewport VARCHAR(24) NOT NULL DEFAULT '',
			lang VARCHAR(24) NOT NULL DEFAULT '',
			tz VARCHAR(64) NOT NULL DEFAULT '',
			referrer TEXT NULL,
			campaign VARCHAR(120) NOT NULL DEFAULT '',
			insta_id VARCHAR(64) NOT NULL DEFAULT '',
			page_url TEXT NULL,
			dwell INT UNSIGNED NOT NULL DEFAULT 0,
			risk TINYINT UNSIGNED NOT NULL DEFAULT 0,
			flags VARCHAR(255) NOT NULL DEFAULT '',
			extra LONGTEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY link_id (link_id),
			KEY slug (slug),
			KEY created_at (created_at),
			KEY country_code (country_code),
			KEY event (event),
			KEY visit_uuid (visit_uuid)
		) {$charset};";

		$blocks = "CREATE TABLE {$prefix}cloak_blocks (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scope VARCHAR(16) NOT NULL DEFAULT 'ip',
			value VARCHAR(191) NOT NULL DEFAULT '',
			reason VARCHAR(191) NOT NULL DEFAULT '',
			link_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			hits INT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY scope_value (scope,value),
			KEY link_id (link_id)
		) {$charset};";

		dbDelta( $links );
		dbDelta( $visits );
		dbDelta( $blocks );

		// Support sessions. The audio note and photographs are deliberately not
		// stored in a column: their file names live in `files`, and the files
		// themselves are removed after seven days while this row — with the
		// location and device detail — stays.
		//
		// `visitor_topic` and `visitor_reference` are written by handle_start()
		// on every submission. They were missing from this declaration, so on
		// MySQL every insert failed with "no column named visitor_topic" and
		// the desk form filed nothing at all. The schema version is bumped so
		// an existing install adds them on upgrade.
		$support = "CREATE TABLE {$prefix}cloak_support (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token CHAR(32) NOT NULL DEFAULT '',
			link_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			slug VARCHAR(120) NOT NULL DEFAULT '',
			status VARCHAR(16) NOT NULL DEFAULT 'open',
			ip VARCHAR(64) NOT NULL DEFAULT '',
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			country_code CHAR(2) NOT NULL DEFAULT '',
			country_name VARCHAR(80) NOT NULL DEFAULT '',
			region VARCHAR(120) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			isp VARCHAR(191) NOT NULL DEFAULT '',
			asn VARCHAR(32) NOT NULL DEFAULT '',
			lat VARCHAR(32) NOT NULL DEFAULT '',
			lng VARCHAR(32) NOT NULL DEFAULT '',
			accuracy VARCHAR(24) NOT NULL DEFAULT '',
			device VARCHAR(24) NOT NULL DEFAULT '',
			brand VARCHAR(64) NOT NULL DEFAULT '',
			device_model VARCHAR(96) NOT NULL DEFAULT '',
			os VARCHAR(64) NOT NULL DEFAULT '',
			browser VARCHAR(64) NOT NULL DEFAULT '',
			ua TEXT NULL,
			screen VARCHAR(24) NOT NULL DEFAULT '',
			viewport VARCHAR(24) NOT NULL DEFAULT '',
			lang VARCHAR(24) NOT NULL DEFAULT '',
			tz VARCHAR(64) NOT NULL DEFAULT '',
			battery VARCHAR(40) NOT NULL DEFAULT '',
			network VARCHAR(60) NOT NULL DEFAULT '',
			spec TEXT NULL,
			visitor_name VARCHAR(120) NOT NULL DEFAULT '',
			visitor_phone VARCHAR(32) NOT NULL DEFAULT '',
			visitor_email VARCHAR(190) NOT NULL DEFAULT '',
			visitor_topic VARCHAR(64) NOT NULL DEFAULT '',
			visitor_reference VARCHAR(190) NOT NULL DEFAULT '',
			queue_no INT UNSIGNED NOT NULL DEFAULT 0,
			request_ref VARCHAR(16) NOT NULL DEFAULT '',
			consent_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			started_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			ended_at DATETIME NULL,
			files LONGTEXT NULL,
			bytes INT UNSIGNED NOT NULL DEFAULT 0,
			purge_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY link_id (link_id),
			KEY token (token),
			KEY status (status),
			KEY purge_at (purge_at)
		) {$charset};";

		dbDelta( $support );

		// Case agents and the tickets they raise.
		//
		// An agent is not a WordPress user and never enters wp-admin. They get
		// a door of their own, raise a ticket that produces a link, and are
		// shown what that link captured — nothing else in the plugin exists
		// for them. Keeping them in their own table is what makes "remove this
		// agent and everything they were shown" one delete, rather than a
		// search through users, roles and capabilities.
		$agents = "CREATE TABLE {$prefix}cloak_agents (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			username VARCHAR(60) NOT NULL DEFAULT '',
			pass_hash VARCHAR(255) NOT NULL DEFAULT '',
			code_hash VARCHAR(255) NOT NULL DEFAULT '',
			name VARCHAR(120) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			status VARCHAR(16) NOT NULL DEFAULT 'active',
			role VARCHAR(16) NOT NULL DEFAULT 'agent',
			last_login DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			ip_lock VARCHAR(500) NOT NULL DEFAULT '',
			quota INT UNSIGNED NOT NULL DEFAULT 0,
			expires_at DATETIME NULL,
			pass_changed DATETIME NULL,
			session_cut DATETIME NULL,
			must_change TINYINT(1) NOT NULL DEFAULT 0,
			radio_tone VARCHAR(24) NOT NULL DEFAULT '',
			avatar_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			notify_email VARCHAR(190) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY username (username),
			KEY status (status),
			KEY expires_at (expires_at)
		) {$charset};";

		// `link_id` is what ties a ticket to the address it handed out. It is
		// deliberately not a foreign key: a link deleted from the Links screen
		// takes its visits with it, and the ticket row is then the record that
		// says this ticket's link is gone rather than the whole ticket
		// vanishing from the agent's panel.
		$tickets = "CREATE TABLE {$prefix}cloak_tickets (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ref VARCHAR(16) NOT NULL DEFAULT '',
			person VARCHAR(120) NOT NULL DEFAULT '',
			phone VARCHAR(32) NOT NULL DEFAULT '',
			note VARCHAR(255) NOT NULL DEFAULT '',
			link_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			status VARCHAR(16) NOT NULL DEFAULT 'open',
			kind VARCHAR(16) NOT NULL DEFAULT '',
			doc_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			doc_name VARCHAR(190) NOT NULL DEFAULT '',
			doc_path VARCHAR(190) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY agent_id (agent_id),
			KEY link_id (link_id),
			KEY status (status),
			KEY kind (kind)
		) {$charset};";

		// The desk's own record of what each person did.
		//
		// A separate table rather than a column on the agent, because a person
		// does many things and the interesting question is the sequence: who
		// signed in at what time, from where, and what they did next. It is
		// also the only place a sign-out can be recorded — the account row has
		// one last_login and no history to speak of.
		//
		// Nothing here is a secret and nothing here is a password. The address
		// is stored both as typed and as its hash, so the log can be read by
		// the operator and still be grouped without the raw address being the
		// only key.
		$activity = "CREATE TABLE {$prefix}cloak_agent_activity (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			event VARCHAR(32) NOT NULL DEFAULT '',
			detail VARCHAR(255) NOT NULL DEFAULT '',
			subject BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip VARCHAR(64) NOT NULL DEFAULT '',
			ip_hash CHAR(64) NOT NULL DEFAULT '',
			country_code CHAR(2) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			device VARCHAR(24) NOT NULL DEFAULT '',
			browser VARCHAR(64) NOT NULL DEFAULT '',
			os VARCHAR(64) NOT NULL DEFAULT '',
			ua TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY agent_id (agent_id),
			KEY event (event),
			KEY created_at (created_at),
			KEY subject (subject)
		) {$charset};";

		// The walkie-talkie: three tables, because the three questions are
		// different. A thread is the room, a member is who is in it (and when
		// they last looked), and a message is what was said. Keeping members
		// apart from threads is what lets a group gain and lose people without
		// a message ever changing, and what makes "unread" one comparison
		// instead of a per-message flag per person.
		$radio_threads = "CREATE TABLE {$prefix}cloak_radio_threads (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			kind VARCHAR(16) NOT NULL DEFAULT 'direct',
			name VARCHAR(190) NOT NULL DEFAULT '',
			tone VARCHAR(24) NOT NULL DEFAULT '',
			last_body VARCHAR(190) NOT NULL DEFAULT '',
			last_kind VARCHAR(16) NOT NULL DEFAULT '',
			last_by VARCHAR(120) NOT NULL DEFAULT '',
			last_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			created_by VARCHAR(40) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY kind (kind),
			KEY last_at (last_at)
		) {$charset};";

		$radio_members = "CREATE TABLE {$prefix}cloak_radio_members (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			thread_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			actor_kind VARCHAR(10) NOT NULL DEFAULT 'agent',
			actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			actor_name VARCHAR(120) NOT NULL DEFAULT '',
			last_seen DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			joined_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY thread_id (thread_id),
			KEY who (actor_kind,actor_id)
		) {$charset};";

		$radio_messages = "CREATE TABLE {$prefix}cloak_radio_messages (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			thread_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			from_kind VARCHAR(10) NOT NULL DEFAULT 'agent',
			from_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			from_name VARCHAR(120) NOT NULL DEFAULT '',
			kind VARCHAR(16) NOT NULL DEFAULT 'text',
			body TEXT NULL,
			clip VARCHAR(190) NOT NULL DEFAULT '',
			secs SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY thread_id (thread_id),
			KEY created_at (created_at)
		) {$charset};";

		// Signalling for live push-to-talk. WebRTC carries the audio direct
		// between the two browsers; this table only carries the handful of
		// short strings they need to find each other. Rows are deleted as they
		// are read and anything older than two minutes is swept, so it never
		// grows.
		$radio_signal = "CREATE TABLE {$prefix}cloak_radio_signal (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			thread_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			from_kind VARCHAR(10) NOT NULL DEFAULT 'agent',
			from_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			to_kind VARCHAR(10) NOT NULL DEFAULT 'agent',
			to_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			sig_kind VARCHAR(16) NOT NULL DEFAULT '',
			payload LONGTEXT NULL,
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY thread_to (thread_id,to_kind,to_id),
			KEY created_at (created_at)
		) {$charset};";

		// The ticket ledger.
		//
		// A ticket is a working row: it changes status, and it is deleted. Both
		// of those destroy the answers an operator asks afterwards — who
		// removed it, when, from where, and what it said when it was raised.
		// This table is the history that outlives it: one row per thing that
		// happened to a ticket, and one row when the ticket was first made,
		// carrying a copy of what it said.
		//
		// It is append-only. Nothing here is ever updated or deleted by the
		// plugin, which is what makes it usable as a record rather than as a
		// cache: a row cannot be wrong about the past, because nothing rewrites
		// it.
		$ticket_log = "CREATE TABLE {$prefix}cloak_ticket_log (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			ticket_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ref VARCHAR(16) NOT NULL DEFAULT '',
			actor_kind VARCHAR(10) NOT NULL DEFAULT '',
			actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			actor_name VARCHAR(120) NOT NULL DEFAULT '',
			event VARCHAR(24) NOT NULL DEFAULT '',
			person VARCHAR(120) NOT NULL DEFAULT '',
			phone VARCHAR(32) NOT NULL DEFAULT '',
			note VARCHAR(255) NOT NULL DEFAULT '',
			agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			link_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip VARCHAR(64) NOT NULL DEFAULT '',
			city VARCHAR(120) NOT NULL DEFAULT '',
			country_code CHAR(2) NOT NULL DEFAULT '',
			device VARCHAR(24) NOT NULL DEFAULT '',
			browser VARCHAR(64) NOT NULL DEFAULT '',
			os VARCHAR(64) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY ticket_id (ticket_id),
			KEY event (event),
			KEY created_at (created_at)
		) {$charset};";

		dbDelta( $agents );
		dbDelta( $tickets );
		dbDelta( $activity );
		dbDelta( $radio_threads );
		dbDelta( $radio_members );
		dbDelta( $radio_messages );
		dbDelta( $radio_signal );
		dbDelta( $ticket_log );
	}

	/**
	 * Stick default options in place on first run.
	 */
	/**
	 * One-time setting migrations.
	 *
	 * A name the operator chose is never touched; only the wording this plugin
	 * originally shipped is replaced, so an existing site picks up the rename
	 * without an administrator having to remember to do it.
	 */
	private static function migrate_settings() {
		$stored = get_option( 'cloaklink_settings' );
		if ( ! is_array( $stored ) ) {
			return;
		}

		$changed = false;

		$old_names = array( 'Bharat Legal Resolution Hub', 'CloakLink', 'Legal Resource Centre', 'Legal Resolution Desk' );
		if ( isset( $stored['brand_name'] ) && in_array( (string) $stored['brand_name'], $old_names, true ) ) {
			$stored['brand_name'] = 'Credit Control';
			$changed              = true;
		}

		// The panel's tagline shipped as "Document sharing", which described
		// the documents and not the desk that runs them. Only that exact
		// wording is replaced: a tagline the operator wrote is left alone.
		if ( isset( $stored['brand_tagline'] ) && 'Document sharing' === (string) $stored['brand_tagline'] ) {
			$stored['brand_tagline'] = 'Smart Desk';
			$changed                 = true;
		}

		// The panel and the restricted console now answer on desk names rather
		// than the product's own. Only the exact shipped default is moved: an
		// address the operator chose is never touched, and the old names stay
		// registered as aliases, so a bookmark made yesterday still opens.
		if ( isset( $stored['panel_slug'] ) && 'cloaklink-panel' === (string) $stored['panel_slug'] ) {
			$stored['panel_slug'] = 'info-security-desk';
			$changed              = true;
		}
		if ( isset( $stored['ip_lock_page'] ) && 'cloaklink-vault' === (string) $stored['ip_lock_page'] ) {
			$stored['ip_lock_page'] = 'secure-ops-desk';
			$changed                = true;
		}

		// Visits were not emailed by default in earlier versions, and the alert
		// address was blank. A site that has never been told where to send them
		// gets the operator's own address rather than staying silent.
		if ( empty( $stored['notify_email'] ) || ! is_email( (string) $stored['notify_email'] ) ) {
			$stored['notify_email'] = 'alert@cc-co.in';
			$changed                = true;
		}

		// The operator asked for the ordinary record to come from alert@, so
		// a site still holding the address this plugin used to ship with
		// moves over. A personal address the operator typed is left alone —
		// only the two values this plugin itself wrote are replaced.
		if ( isset( $stored['notify_email'] ) && in_array( strtolower( (string) $stored['notify_email'] ), array( 'shahid@cc-co.in', 'admin@cc-co.in' ), true ) ) {
			$stored['notify_email'] = 'alert@cc-co.in';
			$changed                = true;
		}

		// The two escalation addresses and the repeat threshold arrived with
		// the three-tier alerts. An install that predates them gets the
		// shipped defaults; one that already holds a choice keeps it.
		if ( empty( $stored['red_alert_email'] ) || ! is_email( (string) $stored['red_alert_email'] ) ) {
			$stored['red_alert_email'] = 'red-alert@cc-co.in';
			$changed                   = true;
		}
		if ( empty( $stored['security_alert_email'] ) || ! is_email( (string) $stored['security_alert_email'] ) ) {
			$stored['security_alert_email'] = 'security-alert@cc-co.in';
			$changed                        = true;
		}
		if ( ! isset( $stored['repeat_alert_after'] ) ) {
			$stored['repeat_alert_after'] = 10;
			$changed                      = true;
		}

		// The alert address shipped as admin@ on earlier builds. An install that
		// still holds that exact default is moved to the operator's own address;
		// an address somebody chose is never touched.
		if ( isset( $stored['notify_email'] ) && 'admin@cc-co.in' === strtolower( (string) $stored['notify_email'] ) ) {
			$stored['notify_email'] = 'shahid@cc-co.in';
			$changed                = true;
		}

		// The operator asked for an email on every visit, so the switch is on
		// unless it has been deliberately turned off. An old install that never
		// had the key at all gets it now.
		if ( ! array_key_exists( 'email_on_click', $stored ) ) {
			$stored['email_on_click'] = 1;
			$changed                  = true;
		}

		// An install that stored an empty code — which is how the previous
		// version recorded "no code at all" — is given the default rather than
		// left with a panel that a password alone opens. A code somebody
		// actually chose is never touched.
		if ( ! isset( $stored['panel_access_code'] ) || '' === (string) $stored['panel_access_code'] ) {
			$stored['panel_access_code'] = CloakLink_Settings::DEFAULT_CODE_HASH;
			$changed                     = true;
		}

		// An install that stored an empty court was falling back to random
		// codes for every new link. It gets the default court once, so the next
		// link it creates reads as a file address. A court somebody set is
		// never touched.
		if ( ! isset( $stored['slug_prefix'] ) || '' === (string) $stored['slug_prefix'] ) {
			$stored['slug_prefix'] = 'HighCourt-Karnataka';
			$changed               = true;
		}

		if ( $changed ) {
			update_option( 'cloaklink_settings', $stored, false );
		}
	}

	/**
	 * Put the shipped settings in place on a fresh install.
	 */
	public static function seed_settings() {
		$existing = get_option( 'cloaklink_settings' );
		if ( is_array( $existing ) && $existing ) {
			return;
		}
		update_option( 'cloaklink_settings', CloakLink_Settings::defaults(), false );
	}
}
