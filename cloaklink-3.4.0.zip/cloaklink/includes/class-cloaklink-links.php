<?php
/**
 * Link model: validation, creation, state resolution.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Business logic for links.
 */
class CloakLink_Links {

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/**
	 * Whether the link being built came from a queue ticket.
	 *
	 * Set by the caller for the length of one generate_slug() call, so the
	 * queue's own prefix applies to that address and to nothing else. A flag
	 * rather than an argument because validate() and create() sit between the
	 * caller and the generator, and threading a fifth parameter through both
	 * would put a queue concern into the shape of the operator's own form.
	 *
	 * @var bool
	 */
	public $queue_made = false;

	/** Allowed link types. */
	const TYPES = array( 'redirect', 'instagram', 'legal' );

	/**
	 * Extensions an operator may print on the end of a link.
	 *
	 * A shared address is often read before it is tapped, and
	 * HighCourt-Karnataka.Notice.F56-DR-AXO973-GAJENDRA_S_N reads as a bare
	 * reference while the same address ending in .pdf reads as a document.
	 * The list is fixed rather than free text so a typo cannot produce an
	 * address nothing recognises.
	 */
	const EXTENSIONS = array(
		'pdf',
		'doc',
		'docx',
		'xls',
		'xlsx',
		'ppt',
		'pptx',
		'jpg',
		'jpeg',
		'png',
		'webp',
		'gif',
		'zip',
		'txt',
		'csv',
		'html',
		'htm',
		'xml',
		'json',
		'mp4',
		'mp3',
		'apk',
		'link',
	);

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings.
	 */
	public function __construct( $db, $settings ) {
		$this->db       = $db;
		$this->settings = $settings;
	}

	/**
	 * The slug a new link is given.
	 *
	 * When a prefix is set in Settings, the address is built in three parts:
	 *
	 *   HighCourt-Karnataka.Notice.F56-DR-AXO973-GAJENDRA_S_N
	 *   └────── fixed ──────┘└ fixed┘└─ per link ─┘└── the name ──┘
	 *
	 * The court and the word "Notice" are the same on every link of theirs,
	 * because that is how the paper is headed. The file number after them is
	 * drawn fresh for each link, in the shape a court file number takes:
	 * two letters, a hyphen, two letters, a hyphen, three letters and three
	 * digits. It is not a count and not derived from the case, so two notices
	 * to the same person never share an address and no address reveals how
	 * many were issued before it.
	 *
	 * The name closing it is the name on the case in capitals, with the spaces
	 * between its words replaced by underscores: GAJENDRA_S_N. A hyphen is
	 * kept for the file number itself, so the two parts of the address never
	 * read as one long string of words.
	 *
	 * Dots and capitals are kept because a court file number carries them, and
	 * stripping either would print an address that does not match the paper.
	 * A short number is appended only when that address is already taken.
	 *
	 * With no prefix set, the old random code is used, so an install that has
	 * not asked for named links keeps the addresses it already shares.
	 *
	 * @param int    $len   Length of the random fallback.
	 * @param string $party Name on this file, overriding the Settings one.
	 * @return string
	 */
	public function generate_slug( $len = 9, $party = '' ) {
		$prefix = trim( (string) $this->settings->get( 'slug_prefix' ) );
		// A link made from the queue may carry its own prefix, set on the
		// Advanced screen: the operator's own links and the ones released from
		// a ticket are different streams, and an address that says which is
		// useful when they are read side by side.
		$queue = function_exists( 'cloaklink' ) && cloaklink()->adv ? trim( (string) cloaklink()->adv->get( 'queue_prefix', '' ) ) : '';
		if ( '' !== $queue && ! empty( $this->queue_made ) ) {
			$prefix = $queue;
		}
		// The link's own name first; the one in Settings only stands in when
		// the operator left the field empty.
		$name   = '' !== trim( (string) $party ) ? trim( (string) $party ) : trim( (string) $this->settings->get( 'case_name' ) );

		// A random code is the last resort, not the response to a blank field.
		// The prefix is the court, and every install has one by default; only
		// an operator who deliberately cleared it gets the short codes back.
		if ( '' !== $prefix ) {
			return $this->unique_slug( self::file_slug( $prefix, $name ) );
		}

		// No court set at all. The address still says what it is, rather than
		// becoming nine meaningless characters.
		return $this->unique_slug( self::file_slug( '', $name ) );
	}

	/**
	 * Turn a base address into the first one that is not taken, with whatever
	 * the Advanced screen asked for added to it.
	 *
	 * The three additions are independent and all optional: a random tail makes
	 * the address unguessable, a year marks which year's files it belongs to,
	 * and capitals are how a court writes its own reference. Each is off in a
	 * fresh install, so an upgrade keeps the addresses it already shares.
	 *
	 * @param string $base Address without any of them.
	 * @return string
	 */
	private function unique_slug( $base ) {
		$adv   = function_exists( 'cloaklink' ) ? cloaklink()->adv : null;
		$base  = (string) $base;
		$tail  = $adv ? (int) $adv->slug_tail() : 0;

		if ( $adv && $adv->yes( 'slug_year' ) ) {
			$year = wp_date( 'Y' );
			// The year goes before the party name, so the file reference still
			// reads in the order a clerk reads it: cause, year, number, party.
			$dot = strrpos( $base, '-' );
			$base = false !== $dot
				? substr( $base, 0, $dot ) . '.' . $year . substr( $base, $dot )
				: $base . '.' . $year;
		}

		if ( $tail > 0 ) {
			$base = $base . '-' . strtolower( self::tail_code( $tail ) );
		}

		$slug = $base;
		$n    = 1;
		while ( $this->db->get_link_by_slug( $slug ) ) {
			$n++;
			$slug = substr( $base, 0, 96 ) . '-' . $n;
		}

		if ( $adv && $adv->yes( 'slug_upper' ) ) {
			// Upper case only for the display shape: the matcher is already
			// case-insensitive and stores the address as typed, so an old
			// lowercase link still resolves.
			$upper = strtoupper( $slug );
			if ( ! $this->db->get_link_by_slug( $upper ) ) {
				$slug = $upper;
			}
		}

		return $slug;
	}

	/**
	 * A short random tail drawn from letters and digits that cannot be
	 * mistaken for each other in print (no O/0, no I/1, no S/5).
	 *
	 * @param int $len How many characters.
	 * @return string
	 */
	public static function tail_code( $len = 4 ) {
		$set  = 'ABCDEFGHJKLMNPQRTUVWXY2346789';
		$out  = '';
		$len  = max( 1, min( 16, (int) $len ) );
		for ( $i = 0; $i < $len; $i++ ) {
			$out .= $set[ random_int( 0, strlen( $set ) - 1 ) ];
		}
		return $out;
	}

	/**
	 * Build the file-style address from its three parts.
	 *
	 * Split out so the same address can be shown in Settings exactly as it will
	 * be issued, without creating a link to look at.
	 *
	 * @param string $prefix Court and cause, e.g. HighCourt-Karnataka.
	 * @param string $name   Name on the case, e.g. "Gajendra S N".
	 * @return string
	 */
	public static function file_slug( $prefix, $name ) {
		// The court keeps its hyphen and loses its spaces: a court's own name is
		// written that way on the paper, and HighCourt-Karnataka reads as the
		// court rather than as one long word. Underscores are dropped here
		// because the underscore is what joins "Notice" to it.
		$court = preg_replace( '/\s+/', '-', trim( (string) $prefix ) );
		$court = preg_replace( '/[^A-Za-z0-9.\-]/', '', $court );
		$court = trim( preg_replace( '/-{2,}/', '-', $court ), '-.' );

		// The party's name keeps underscores between its words: three words
		// become three parts that read as one name, not as three fields. The
		// underscore is also what keeps the name distinct from the dotted
		// parts before it, so GAJENDRA_S_N reads as one person.
		$who = preg_replace( '/[^A-Za-z0-9_]/', '', preg_replace( '/[\s\-_.]+/', '_', strtoupper( trim( (string) $name ) ) ) );
		$who = trim( (string) $who, '_' );

		// HighCourt-Karnataka.Notice.F56-DR-AXO973-GAJENDRA_S_N
		//
		// The court, the word Notice and the file number are one file
		// reference and are separated by dots, the way a court cites its own
		// paperwork. The name is the party, set apart by a hyphen, with
		// underscores between its words. "Notice" is fixed: every link of
		// this kind is a notice. With no court set the address still carries
		// the word, so the shape never collapses into a bare random code.
		$slug = ( '' !== $court ? $court . '.' : '' ) . 'Notice.' . self::file_number();
		if ( '' !== $who ) {
			$slug .= '-' . $who;
		}
		return substr( $slug, 0, 110 );
	}

	/**
	 * A fresh file number in the shape a court issues: one letter and two
	 * digits, a hyphen, two letters, a hyphen, three letters and three digits
	 * — F56-DR-AXO973.
	 *
	 * The letters exclude I and O, which are misread as 1 and 0 when a file
	 * number is read back over the telephone.
	 *
	 * @return string
	 */
	public static function file_number() {
		$set = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
		$pick = static function ( $n ) use ( $set ) {
			$out = '';
			for ( $i = 0; $i < $n; $i++ ) {
				$out .= $set[ random_int( 0, strlen( $set ) - 1 ) ];
			}
			return $out;
		};
		return $pick( 1 ) . wp_rand( 10, 99 ) . '-' . $pick( 2 ) . '-' . $pick( 3 ) . wp_rand( 100, 999 );
	}

	/**
	 * Turn text into the shape a slug may take.
	 *
	 * Letters, digits, dots, hyphens and underscores survive; spaces become
	 * hyphens; every other character is dropped. Case is kept, because the
	 * file number on the paper is printed that way.
	 *
	 * Underscores are kept because the name on a file address uses them to
	 * join its words: GAJENDRA_S_N. Dropping them would merge three names into
	 * one word.
	 *
	 * @param string $value Raw text.
	 * @return string
	 */
	public static function clean_slug( $value ) {
		$value = trim( (string) $value );
		$value = preg_replace( '/\s+/', '-', $value );
		$value = preg_replace( '/[^A-Za-z0-9.\-_]/', '', $value );
		$value = preg_replace( '/-{2,}/', '-', $value );
		$value = preg_replace( '/\.{2,}/', '.', $value );
		return trim( $value, '.-_' );
	}

	/**
	 * Public URL for a slug.
	 *
	 * @param string $slug     Slug.
	 * @param string $domain   Domain to print it on.
	 * @param string $ext      Extension printed after the slug, or ''.
	 * @return string
	 */
	public function url( $slug, $domain = '', $ext = '', $type = '' ) {
		$slug = (string) $slug;

		// When the host does not pass clean paths to WordPress, a printed
		// clean path is a 404 at the door — the row exists, the route exists,
		// and the visitor still sees "Not Found" because nginx answered the
		// request itself without ever reaching the plugin.
		//
		// That is measurable, and it is measured elsewhere on this install:
		// `CloakLink_Admin::routes_broken()` reports it from the permalink
		// setting and from a real probe of a real link. When it is true, the
		// address is printed in the form every server passes through — the
		// query form, which lands on index.php and is answered by this
		// plugin's own handler. An address that works beats an address that
		// only looks tidy.
		if ( class_exists( 'CloakLink_Admin' ) && CloakLink_Admin::routes_broken() ) {
			$ext = self::clean_extension( $ext );
			return $this->query_url( $slug, $domain, $ext, $type );
		}

		// A document is printed at the root of the domain, with the kind of
		// paper spelled out in the address itself:
		//
		//   cc-co.in/HighCourt-Karnataka.legal-Notice.T81-UQ-FGN142-PAVAN_KUMAR
		//
		// No "/go/" in front of it. A notice is read by somebody who was not
		// expecting a link at all, and an address that starts with the court
		// looks like the court's own paperwork; the delivery path in front of
		// it looked like a redirect service, which is what made recipients
		// stop and ask what it was. Every other kind of link keeps the parent
		// path exactly as it was — a reel in particular is printed the way
		// Instagram prints it.
		if ( self::is_document( $type, $slug ) ) {
			$url = $this->settings->root_url( $domain ) . '/' . self::legal_slug( $slug );
			$ext = self::clean_extension( $ext );
			return '' !== $ext ? $url . '.' . $ext : $url;
		}

		// A link can be printed on any configured domain. The path never
		// changes, because the request has to land on this install anyway.
		$url  = $this->settings->base_url( $domain ) . '/' . $slug;

		// A reel's slug is "instagram.com/reel/<code>". Printed as-is, the
		// recipient sees this install's host immediately followed by the
		// post's own host, which is what the address is meant to say. The
		// share tail is added here so the address reads as a real share link.
		if ( false !== stripos( $slug, 'instagram.com/' ) ) {
			$parts = array_values( array_filter( explode( '/', $slug ), 'strlen' ) );
			// www.instagram.com / reel / <code>
			$code = isset( $parts[2] ) ? (string) $parts[2] : '';
			$tail = $this->insta_tail( $code );
			// The trailing slash before the query is part of the address
			// shape WhatsApp and Instagram themselves print.
			if ( '' !== $tail ) {
				$url .= '/?utm_source=ig_web_copy_link&rpxt=' . $tail;
			}
			return $url;
		}

		$ext = self::clean_extension( $ext );
		if ( '' !== $ext ) {
			$url .= '.' . $ext;
		}
		return $url;
	}

	/**
	 * The address of a link on a host that will not route clean paths.
	 *
	 * Everything the clean form carries is kept: the document form still
	 * names the kind of paper, and the extension is still printed. What
	 * changes is only where the anchor sits — on the site root, with the
	 * slug as an argument, which is the one shape a server that never
	 * forwards paths to WordPress can still answer.
	 *
	 * The step ("/l/open") is not part of a printed address: it is a
	 * fragment of the page a visitor is already on. The query form reads
	 * the same slug and serves the same page.
	 *
	 * @param string $slug   Stored slug.
	 * @param string $domain Host to print on.
	 * @param string $ext    Extension, already cleaned.
	 * @param string $type   Link type.
	 * @return string
	 */
	private function query_url( $slug, $domain, $ext, $type ) {
		$printed = self::is_document( $type, $slug ) ? self::legal_slug( $slug ) : $slug;

		$root = $this->settings->root_url( $domain );
		$url  = $root . '/?cloaklink_slug=' . rawurlencode( $printed );

		if ( '' !== $ext ) {
			$url .= '&cloaklink_ext=' . rawurlencode( $ext );
		}
		if ( self::is_document( $type, $slug ) ) {
			$url .= '&cloaklink_doc=1';
		}

		return $url;
	}

	/**
	 * Is this a document, whatever its row happens to say?
	 *
	 * The two stored answers are "legal" (what the form writes now) and
	 * "document" (what older rows carry). A notice printed before either of
	 * those was recorded can still be recognised from its own address: the
	 * court and the kind of paper are in the slug, and no other kind of link
	 * is built in that shape. An Instagram link is never one of these — its
	 * slug begins with the post's own host — so it keeps its delivery path
	 * exactly as it was.
	 *
	 * @param string $type Stored link type.
	 * @param string $slug Stored slug.
	 * @return bool
	 */
	public static function is_document( $type, $slug = '' ) {
		$type = (string) $type;
		if ( 'legal' === $type || 'document' === $type ) {
			return true;
		}
		if ( false !== stripos( (string) $slug, 'instagram.com/' ) ) {
			return false;
		}
		return (bool) preg_match( '/\.(notice|summons|order|petition|judgment|affidavit)\./i', (string) $slug );
	}

	/**
	 * A stored slug, written the way a document's address prints it.
	 *
	 * The stored slug is the file reference as the court writes it —
	 * "HighCourt-Karnataka.Notice.T81-UQ-FGN142-PAVAN_KUMAR". The printed
	 * address carries the kind of paper in the address too, so a recipient
	 * reading it sees a legal notice rather than a bare file number:
	 * "HighCourt-Karnataka.legal-Notice.T81-UQ-FGN142-PAVAN_KUMAR".
	 *
	 * The first segment is the court and stays untouched. The word that
	 * follows it is the kind, and "legal-" is put in front of that one word
	 * only, so a name later in the address is never altered.
	 *
	 * @param string $slug Stored slug.
	 * @return string
	 */
	public static function legal_slug( $slug ) {
		$slug = (string) $slug;
		if ( '' === $slug || false !== strpos( $slug, '.legal-' ) ) {
			return $slug;
		}
		$parts = explode( '.', $slug, 2 );
		if ( count( $parts ) < 2 || '' === $parts[1] ) {
			return $slug;
		}
		return $parts[0] . '.legal-' . $parts[1];
	}

	/**
	 * Undo legal_slug(): the stored slug a printed document address stands for.
	 *
	 * @param string $slug Printed slug.
	 * @return string
	 */
	public static function stored_slug( $slug ) {
		return preg_replace( '/\.legal-/', '.', (string) $slug, 1 );
	}

	/**
	 * The printed URL for a whole link row.
	 *
	 * A convenience wrapper so every screen prints the same address, extension
	 * and all, instead of each one having to remember to read the meta.
	 *
	 * @param array $link Link row.
	 * @return string
	 */
	public function link_url( $link ) {
		// A deleted link leaves a null behind. Every screen that prints an
		// address from a row would otherwise raise "array offset on null" and,
		// on a strict host, show the warning above the panel. An empty string
		// is the honest answer for a link that is not there.
		if ( ! is_array( $link ) || empty( $link['slug'] ) ) {
			return '';
		}
		$domain = isset( $link['meta']['domain'] ) ? (string) $link['meta']['domain'] : '';
		$type   = isset( $link['link_type'] ) ? (string) $link['link_type'] : '';
		return $this->url( (string) $link['slug'], $domain, $this->extension( $link ), $type );
	}

	/**
	 * The extension stored on a link, or '' when it has none.
	 *
	 * @param array $link Link row.
	 * @return string
	 */
	public function extension( $link ) {
		if ( ! is_array( $link ) || empty( $link['meta']['extension'] ) ) {
			return '';
		}
		return self::clean_extension( (string) $link['meta']['extension'] );
	}

	/**
	 * Reduce input to one of the offered extensions, or ''.
	 *
	 * @param string $ext Raw extension, with or without its leading dot.
	 * @return string
	 */
	public static function clean_extension( $ext ) {
		$ext = strtolower( ltrim( trim( (string) $ext ), '.' ) );
		$ext = preg_replace( '/[^a-z0-9]/', '', $ext );
		return in_array( $ext, self::EXTENSIONS, true ) ? $ext : '';
	}

	/**
	 * Build a ready-to-share message.
	 *
	 * @param array $link Link row.
	 * @return string
	 */
	public function share_text( $link ) {
		$link = is_array( $link ) ? $link : array();
		$url    = $this->link_url( $link );
		$msg_title = ! empty( $link['meta']['share_title'] ) ? (string) $link['meta']['share_title'] : (string) ( isset( $link['title'] ) ? $link['title'] : '' );
		$msg = (string) $this->settings->get( 'share_message' );
		$msg = str_replace(
			array( '{url}', '{title}', '{label}' ),
			array( $url, $msg_title, isset( $link['label'] ) ? (string) $link['label'] : '' ),
			$msg
		);
		// A blank URL would be appended as a stray trailing space and the
		// message would end in nothing at all, which reads as a broken share.
		if ( '' !== $url && false === strpos( $msg, $url ) ) {
			$msg = trim( $msg . ' ' . $url );
		}
		return $msg;
	}

	/**
	 * Validate and normalise incoming link input.
	 *
	 * @param array $in Raw POST.
	 * @return array [clean, errors]
	 */
	public function validate( $in ) {
		$errors = array();
		$d      = array(
			'id'          => 0,
			'title'       => '',
			'label'       => '',
			'link_type'   => 'redirect',
			'destination' => '',
			'media_url'   => '',
			'page_title'  => '',
			'whatsapp_preview_url' => '',
			'mode'        => 'off',
			'max_clicks'  => 0,
			'expiry'      => '',
			'status'      => 'active',
			'accept_deny' => 0,
			'otp'         => 0,
			'notice'      => '',
			'pin'         => '',
			'pin_remove'  => 0,
			'single_use'  => 0,
			'used'        => '',
			'domain'      => '',
			'party_name'  => '',
			'extension'   => '',
		);
		$clean = array();

		$clean['id']        = isset( $in['id'] ) ? absint( $in['id'] ) : 0;
		$clean['title']     = isset( $in['title'] ) ? sanitize_text_field( wp_unslash( $in['title'] ) ) : '';
		$clean['label']     = isset( $in['label'] ) ? sanitize_text_field( wp_unslash( $in['label'] ) ) : '';
		$clean['link_type'] = isset( $in['link_type'] ) ? sanitize_key( $in['link_type'] ) : 'redirect';
		if ( ! in_array( $clean['link_type'], self::TYPES, true ) ) {
			$clean['link_type'] = 'redirect';
		}

		$clean['destination'] = isset( $in['destination'] ) ? trim( (string) wp_unslash( $in['destination'] ) ) : '';
		$clean['media_url']   = isset( $in['media_url'] ) ? trim( (string) wp_unslash( $in['media_url'] ) ) : '';
		$clean['page_title']  = isset( $in['page_title'] ) ? sanitize_text_field( wp_unslash( $in['page_title'] ) ) : '';

		// The party named on this file. Per link, not per site: one operator
		// issues notices to many people, and a single global name would print
		// the wrong one on every address but the last. Blank means the name in
		// Settings stands in, and blank there too means the address ends at the
		// file number.
		$clean['party_name'] = isset( $in['party_name'] ) ? mb_substr( sanitize_text_field( wp_unslash( (string) $in['party_name'] ) ), 0, 80 ) : '';

		// The extension printed after the address. Only the offered list is kept,
		// so a value that did not come from the picker is dropped rather than
		// printed. The field is always submitted by the form, so an empty string
		// is a deliberate "None" and is respected; the standing choice in
		// Settings fills in only when the field is not sent at all — the form
		// already pre-selects it, so this is for anything posting without it.
		if ( array_key_exists( 'extension', $in ) ) {
			$clean['extension'] = self::clean_extension( wp_unslash( (string) $in['extension'] ) );
		} else {
			$clean['extension'] = empty( $in['id'] ) ? self::clean_extension( (string) $this->settings->get( 'default_extension', '' ) ) : '';
		}

		// Location policy for this link. "require" is the default the operator
		// asked for: a link opens after the browser has answered the location
		// prompt. A link may still be set to ask optionally, or not at all.
		$clean['mode'] = isset( $in['mode'] ) ? sanitize_key( (string) wp_unslash( $in['mode'] ) ) : 'require';
		if ( ! in_array( $clean['mode'], array( 'require', 'optional', 'off' ), true ) ) {
			$clean['mode'] = 'require';
		}

		$clean['max_clicks'] = 0; // Per-visitor open counters are disabled in the public preview flow.
		$clean['status']     = isset( $in['status'] ) && in_array( $in['status'], array( 'active', 'paused', 'expired', 'deleted' ), true ) ? $in['status'] : 'active';
		$clean['accept_deny'] = ! empty( $in['accept_deny'] ) ? 1 : 0;
		$clean['otp']         = ! empty( $in['otp'] ) ? 1 : 0;
		$clean['notice']      = isset( $in['notice'] ) ? sanitize_textarea_field( wp_unslash( $in['notice'] ) ) : '';
		$clean['single_use']  = 0; // No network-based visitor binding.

		// Optional host to print on the shared link, chosen from the domains in
		// Settings. Anything not on that list falls back to the site's own host.
		$clean['domain'] = isset( $in['domain'] ) ? CloakLink_Settings::clean_host( (string) wp_unslash( $in['domain'] ) ) : '';
		if ( '' === $clean['domain'] ) {
			// No choice made: use the primary domain from Settings. It is stored
			// on the link so changing the setting later does not silently move an
			// address that has already been shared.
			$clean['domain'] = CloakLink_Settings::clean_host( (string) $this->settings->get( 'link_domain', '' ) );
		}
		if ( '' !== $clean['domain'] && ! in_array( $clean['domain'], $this->settings->domains(), true ) ) {
			$clean['domain'] = '';
		}

		// Optional per-link PIN. Stored hashed; the sender reads it back from the
		// link page, so it is never kept in plain text in the database.
		$clean['pin_hash'] = '';
		if ( ! empty( $in['pin'] ) ) {
			$pin = preg_replace( '/\D/', '', (string) wp_unslash( $in['pin'] ) );
			if ( strlen( $pin ) < 4 || strlen( $pin ) > 10 ) {
				$errors['pin'] = __( 'The PIN must be 4 to 10 digits.', 'cloaklink' );
			} else {
				$clean['pin_hash'] = wp_hash_password( $pin );
			}
		}
		if ( ! empty( $in['pin_remove'] ) ) {
			$clean['pin_hash'] = 'REMOVE';
		}

		/*
		 * Documents use a private uploaded file and do not need a destination.
		 * Website/social links accept any HTTP(S) URL. Instagram links are
		 * detected from the pasted URL and stored using the canonical reel/post
		 * address so existing direct-open behaviour remains intact.
		 */
		if ( 'legal' === $clean['link_type'] ) {
			$raw_destination = $clean['destination'];
			// A document link has no destination of its own: the page asks the
			// browser for a position and then shows the file. An empty value is
			// therefore the normal case, not a missing field.
			$clean['destination'] = '' !== $raw_destination ? $this->normalise_url( $raw_destination ) : '';
			if ( '' !== $raw_destination && ! $clean['destination'] ) {
				$errors['destination'] = __( 'Enter a valid HTTP or HTTPS URL.', 'cloaklink' );
			}
			$clean['media_url'] = '';
		} elseif ( 'instagram' === $clean['link_type'] ) {
			$clean['media_url'] = $this->normalise_instagram( $clean['media_url'] ? $clean['media_url'] : $clean['destination'] );
			if ( ! $clean['media_url'] ) {
				$errors['media_url'] = __( 'Enter a valid Instagram reel or post URL.', 'cloaklink' );
			}
			$clean['destination'] = $clean['media_url'];
		} else {
			$clean['media_url'] = '';
			$clean['destination'] = $this->normalise_url( $clean['destination'] );
			if ( ! $clean['destination'] ) {
				$errors['destination'] = __( 'Paste a valid website, Instagram, or social post URL.', 'cloaklink' );
			} elseif (
				function_exists( 'cloaklink' )
				&& cloaklink()->adv
				&& cloaklink()->adv->yes( 'require_https' )
				&& 0 === strpos( strtolower( $clean['destination'] ), 'http://' )
			) {
				// The Advanced switch. A link that forwards to a plain http
				// address shows the visitor a browser warning on the way, which
				// reads as the operator's fault. Caught here, while the form is
				// still in front of them.
				$errors['destination'] = __( 'That address is plain http. Change it to https, or turn off the https rule on the Advanced screen.', 'cloaklink' );
			} else {
				$host = strtolower( (string) wp_parse_url( $clean['destination'], PHP_URL_HOST ) );
				if ( in_array( $host, array( 'instagram.com', 'www.instagram.com', 'm.instagram.com' ), true ) ) {
					$instagram = $this->normalise_instagram( $clean['destination'] );
					if ( $instagram ) {
						$clean['link_type'] = 'instagram';
						$clean['media_url'] = $instagram;
						$clean['destination'] = $instagram;
					}
				}
			}
		}

		// A separate public URL can supply the WhatsApp/Open Graph card while
		// the visitor action remains the uploaded document or Instagram Reel.
		$raw_preview_url = '';
		if ( 'legal' === $clean['link_type'] && isset( $in['document_preview_url'] ) ) {
			$raw_preview_url = trim( (string) wp_unslash( $in['document_preview_url'] ) );
		} elseif ( 'instagram' === $clean['link_type'] && isset( $in['instagram_preview_url'] ) ) {
			$raw_preview_url = trim( (string) wp_unslash( $in['instagram_preview_url'] ) );
		}
		$clean['whatsapp_preview_url'] = '' !== $raw_preview_url ? $this->normalise_url( $raw_preview_url ) : '';
		if ( '' !== $raw_preview_url && ! $clean['whatsapp_preview_url'] ) {
			$errors['whatsapp_preview_url'] = __( 'Enter a valid public HTTP or HTTPS WhatsApp preview URL.', 'cloaklink' );
		}

		if ( 'legal' === $clean['link_type'] ) {
			$existing_file = false;
			if ( $clean['id'] ) {
				$existing_link = $this->db->get_link( $clean['id'] );
				$existing_file = $existing_link && ! empty( $existing_link['meta']['file_path'] );
			}
			// A caller that already holds the file may say so. That is how a
			// ticket's document becomes a link: it was uploaded to the private
			// folder when the agent raised the request, so there is nothing to
			// upload at this point — only an instruction that the file is
			// there. Without this the allow step would demand an upload the
			// operator does not have, and a document ticket could never be
			// released.
			$file_ready      = ! empty( $in['file_ready'] );
			$upload_present  = ! empty( $_FILES['cl_file']['name'] ) || $file_ready;
			$remove_existing = ! empty( $_POST['cl_file_remove'] );
			if ( ! $upload_present && ( ! $existing_file || $remove_existing ) ) {
				$errors['file'] = __( 'Choose a document to upload.', 'cloaklink' );
			}
		}

		// A link has a name, and the operator gives it.
		//
		// A title used to be optional and defaulted to "Document download" or
		// "Website link". Every link then read the same on the wall, in the
		// desk's ticket list and in an export, and the only way to tell two of
		// them apart was the slug — which is the one thing an operator should
		// never have to read. Nothing names itself here: an empty name is a
		// refusal with a sentence saying so.
		//
		// Editing an existing link whose name was never filled in keeps the
		// old default rather than forcing a rename, so opening a two-year-old
		// link to change its expiry does not demand a new name first.
		if ( '' === $clean['title'] ) {
			$keep = '';
			if ( ! empty( $clean['id'] ) ) {
				$was = $this->db->get_link( (int) $clean['id'] );
				if ( $was && '' !== trim( (string) $was['title'] ) ) {
					$keep = (string) $was['title'];
				}
			}
			if ( '' !== $keep ) {
				$clean['title'] = $keep;
			} else {
				$errors['title'] = __( 'Give this link a name. It is how you will find it later.', 'cloaklink' );
			}
		}

		/* Expiry: absolute datetime-local or relative hours. */
		$clean['expires_at'] = null;
		if ( ! empty( $in['expiry'] ) ) {
			$raw = sanitize_text_field( wp_unslash( $in['expiry'] ) );
			$ts  = strtotime( $raw );
			if ( $ts && $ts > time() ) {
				$clean['expires_at'] = gmdate( 'Y-m-d H:i:s', $ts );
			} elseif ( $ts ) {
				$errors['expiry'] = __( 'Expiry must be in the future.', 'cloaklink' );
			}
		} elseif ( ! empty( $in['expiry_hours'] ) ) {
			$hours = absint( $in['expiry_hours'] );
			if ( $hours > 0 ) {
				$clean['expires_at'] = gmdate( 'Y-m-d H:i:s', time() + ( $hours * HOUR_IN_SECONDS ) );
			}
		} elseif ( empty( $clean['id'] ) ) {
			$default_hours = (int) $this->settings->get( 'link_expiry_hours', 0 );
			if ( $default_hours > 0 ) {
				$clean['expires_at'] = gmdate( 'Y-m-d H:i:s', time() + ( $default_hours * HOUR_IN_SECONDS ) );
			}
		}

		return array( $clean, $errors );
	}

	/**
	 * Normalise a destination URL, adding https:// to bare domains.
	 *
	 * @param string $url Raw input.
	 * @return string Empty string when invalid.
	 */
	public function normalise_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		if ( ! preg_match( '#^[a-z][a-z0-9+.\-]*://#i', $url ) ) {
			$url = 'https://' . ltrim( $url, '/' );
		}
		$scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
		if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
			return '';
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! $host || false === strpos( (string) $host, '.' ) ) {
			return '';
		}
		if ( ! preg_match( '#\.[a-z]{2,}$#i', (string) $host ) ) {
			return '';
		}
		return esc_url_raw( $url );
	}

	/**
	 * Validate an Instagram URL and strip tracking noise.
	 *
	 * @param string $url Raw input.
	 * @return string
	 */
	public function normalise_instagram( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}

		// A reel link is pasted from the Instagram app, from a browser address
		// bar, or from a chat where the app prefixed it with a redirect host.
		// All three carry the same shortcode, and the shortcode is the only
		// part that identifies the post. Rather than parsing the host and
		// hoping it is one of three spellings, read the post out of the path
		// wherever it sits — the canonical address is then rebuilt from that
		// one value and can never be stitched together wrongly.
		//
		// This is what produced "cc_co.in.www.instagram.com/reel/…": a link
		// whose scheme was missing was prefixed wholesale onto an address that
		// already had a host, and the two hosts ran together.
		if (
			preg_match( '#(?:^|[/.])(?:p|reel|reels|tv)/([A-Za-z0-9_-]{5,32})#i', $url, $m )
			// A post path only counts on an Instagram address, or on a bare
			// "reel/…" the app copied out without a host. Otherwise an
			// unrelated site with a "/p/" in its path would be accepted here
			// and turned into an Instagram link.
			&& ( false !== stripos( $url, 'instagram.com' ) || preg_match( '#^(?:https?://)?(?:www\.)?(?:p|reel|reels|tv)/#i', $url ) )
		) {
			$kind = 'reel';
			if ( preg_match( '#(?:^|[/.])(p|reel|reels|tv)/#i', $url, $k ) ) {
				$kind = strtolower( $k[1] );
			}
			if ( 'reels' === $kind ) {
				$kind = 'reel';
			}
			return 'https://www.instagram.com/' . $kind . '/' . $m[1] . '/';
		}

		if ( false === stripos( $url, 'instagram.com' ) ) {
			// Allow bare shortcodes like "C9xYzAbCdE".
			if ( preg_match( '/^[A-Za-z0-9_-]{5,32}$/', $url ) ) {
				return 'https://www.instagram.com/p/' . $url . '/';
			}
			return '';
		}

		return '';
	}

	/**
	 * Fetch safe Open Graph metadata for a destination URL.
	 *
	 * Uses WordPress' safe HTTP API (including redirect validation), limits the
	 * response size, and caches results. Metadata is descriptive only; the
	 * visitor is always sent to the exact URL selected by the administrator.
	 *
	 * @param string $url Destination URL.
	 * @return array
	 */
	public function preview_metadata( $url ) {
		$url = $this->normalise_url( $url );
		if ( ! $url ) {
			return array();
		}

		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$instagram_hosts = array( 'instagram.com', 'www.instagram.com', 'm.instagram.com' );
		$is_instagram = in_array( $host, $instagram_hosts, true );
		$icon = $is_instagram
			? CLOAKLINK_URL . 'assets/img/instagram.svg'
			: 'https://www.google.com/s2/favicons?sz=64&domain=' . rawurlencode( $host );

		$cache_key = 'cloaklink_og_26_' . md5( $url );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$preview = array(
			'url'         => $url,
			'host'        => $host,
			'title'       => $is_instagram ? __( 'Instagram Reel or Post', 'cloaklink' ) : $host,
			'description' => $is_instagram ? __( 'View this content on Instagram.', 'cloaklink' ) : __( 'Open this link.', 'cloaklink' ),
			'site_name'   => $is_instagram ? 'Instagram' : $host,
			'image'       => '',
			'icon'        => $icon,
		);

		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 5,
				'redirection'         => 3,
				'limit_response_size' => 524288,
				'headers'             => array(
					'Accept'     => 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.5',
					'User-Agent' => 'CreditControlLinkPreview/2.3 (+WordPress)',
				),
			)
		);

		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
			$html         = (string) wp_remote_retrieve_body( $response );
			if ( false !== stripos( $content_type, 'text/html' ) && '' !== $html ) {
				$found = array();
				if ( class_exists( 'DOMDocument' ) ) {
					$previous = libxml_use_internal_errors( true );
					$document = new DOMDocument();
					$loaded   = $document->loadHTML( '<?xml encoding="utf-8" ?>' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING );
					libxml_clear_errors();
					libxml_use_internal_errors( $previous );

					if ( $loaded ) {
						foreach ( $document->getElementsByTagName( 'meta' ) as $node ) {
							$key = strtolower( trim( $node->getAttribute( 'property' ) ) );
							if ( '' === $key ) {
								$key = strtolower( trim( $node->getAttribute( 'name' ) ) );
							}
							$value = trim( $node->getAttribute( 'content' ) );
							if ( '' !== $key && '' !== $value && ! isset( $found[ $key ] ) ) {
								$found[ $key ] = $value;
							}
						}
						$titles = $document->getElementsByTagName( 'title' );
						if ( $titles->length ) {
							$found['html_title'] = $titles->item( 0 )->textContent;
						}
					}
				} else {
					if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $match ) ) {
						$found['html_title'] = $match[1];
					}
					if ( preg_match_all( '/<meta\s+[^>]*>/i', $html, $tags ) ) {
						foreach ( $tags[0] as $tag ) {
							if ( preg_match( '/(?:property|name)=["\']([^"\']+)["\']/i', $tag, $key_match ) && preg_match( '/content=["\']([^"\']*)["\']/i', $tag, $value_match ) ) {
								$found[ strtolower( $key_match[1] ) ] = $value_match[1];
							}
						}
					}
				}

				$clean_text = static function ( $value, $limit ) {
					$value = html_entity_decode( (string) $value, ENT_QUOTES, 'UTF-8' );
					$value = sanitize_text_field( wp_strip_all_tags( $value ) );
					if ( function_exists( 'mb_substr' ) ) {
						return mb_substr( $value, 0, $limit, 'UTF-8' );
					}
					return substr( $value, 0, $limit );
				};

				$title = isset( $found['og:title'] ) ? $found['og:title'] : ( isset( $found['twitter:title'] ) ? $found['twitter:title'] : ( isset( $found['html_title'] ) ? $found['html_title'] : '' ) );
				$desc  = isset( $found['og:description'] ) ? $found['og:description'] : ( isset( $found['twitter:description'] ) ? $found['twitter:description'] : ( isset( $found['description'] ) ? $found['description'] : '' ) );
				$site  = isset( $found['og:site_name'] ) ? $found['og:site_name'] : ( $is_instagram ? 'Instagram' : $host );
				$image = isset( $found['og:image'] ) ? $found['og:image'] : ( isset( $found['og:image:secure_url'] ) ? $found['og:image:secure_url'] : ( isset( $found['twitter:image'] ) ? $found['twitter:image'] : '' ) );

				if ( '' !== trim( (string) $title ) ) {
					$preview['title'] = $clean_text( $title, 180 );
				}
				if ( '' !== trim( (string) $desc ) ) {
					$preview['description'] = $clean_text( $desc, 240 );
				}
				$preview['site_name'] = $clean_text( $site, 100 );

				if ( '' !== $image ) {
					$image = html_entity_decode( trim( (string) $image ), ENT_QUOTES, 'UTF-8' );
					$parts = wp_parse_url( $url );
					if ( 0 === strpos( $image, '//' ) ) {
						$image = ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'https' ) . ':' . $image;
					} elseif ( 0 === strpos( $image, '/' ) ) {
						$image = ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'https' ) . '://' . $host . $image;
					} elseif ( ! preg_match( '#^https?://#i', $image ) ) {
						$base_path = isset( $parts['path'] ) ? dirname( $parts['path'] ) : '/';
						$image     = ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'https' ) . '://' . $host . trailingslashit( $base_path ) . ltrim( $image, '/' );
					}
					$image_scheme = strtolower( (string) wp_parse_url( $image, PHP_URL_SCHEME ) );
					if ( in_array( $image_scheme, array( 'http', 'https' ), true ) ) {
						$preview['image'] = esc_url_raw( $image );
					}
				}
			}
		}

		set_transient( $cache_key, $preview, 12 * HOUR_IN_SECONDS );
		return $preview;
	}

	/**
	 * Extract the Instagram shortcode from a URL.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	public function insta_code( $url ) {
		if ( preg_match( '#instagram\.com/(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)#i', (string) $url, $m ) ) {
			return $m[1];
		}
		return '';
	}

	/**
	 * The address a new link is issued.
	 *
	 * A reel and a notice are not filed the same way, and their addresses say
	 * so. A document gets the court's own file reference
	 * (HighCourt-Karnataka.Notice.M29-UJ-LVJ942-BORE_GOWDA); a reel gets the
	 * reel's own code (Reel.Dddbr4Gp6UU), which is what the post is called
	 * everywhere else. The two shapes never collapse into each other, so one
	 * look at an address tells the operator which kind of link it is.
	 *
	 * @param array $clean Validated fields.
	 * @return string
	 */
	private function slug_for( $clean ) {
		$type = isset( $clean['link_type'] ) ? (string) $clean['link_type'] : 'redirect';

		if ( 'instagram' === $type ) {
			$slug = $this->instagram_slug( $clean );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		$was_queue = $this->queue_made;
		$this->queue_made = ! empty( $clean['from_queue'] );
		$slug = $this->generate_slug( 9, isset( $clean['party_name'] ) ? (string) $clean['party_name'] : '' );
		$this->queue_made = $was_queue;
		return $slug;
	}

	/**
	 * The trailing share code a reel address carries.
	 *
	 * Six characters from the alphabet Instagram uses for a shortcode, taken
	 * from the post's own code so the same post always yields the same tail.
	 * It exists so the printed address looks like a real share link rather
	 * than like an address with this install's marker glued on the end.
	 *
	 * @param string $code Post shortcode.
	 * @return string
	 */
	public function insta_tail( $code ) {
		$code = (string) $code;
		if ( '' === $code ) {
			return '';
		}
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		$seed     = md5( 'ig|' . $code );
		$tail     = '';
		for ( $i = 0; $i < 6; $i++ ) {
			$tail .= $alphabet[ hexdec( $seed[ $i * 2 ] . $seed[ ( $i * 2 ) + 1 ] ) % strlen( $alphabet ) ];
		}
		return $tail;
	}

	/**
	 * The address a reel is issued.
	 *
	 * Shape: instagram.com/reel/<code>/?utm_source=ig_web_copy_link&rpxt=<tail>
	 *
	 * The printed address has to read as the post's own Instagram address, so
	 * a recipient who looks before tapping sees where it goes. Every part is
	 * either the post's identity or a value the platform itself puts on a
	 * share link — nothing is a random word — so this is a real Instagram
	 * address with this install's base path in front of it.
	 *
	 * The tail is six characters from the same alphabet Instagram uses for a
	 * shortcode, derived from the post rather than from a counter: the same
	 * post always produces the same address, so re-saving a link never mints
	 * a second one.
	 *
	 * @param array $clean Validated fields.
	 * @return string Slug, or '' when no reel code could be read.
	 */
	private function instagram_slug( $clean ) {
		$url = isset( $clean['media_url'] ) ? (string) $clean['media_url'] : '';
		if ( '' === $url ) {
			$url = isset( $clean['destination'] ) ? (string) $clean['destination'] : '';
		}
		$code = $this->insta_code( $url );
		if ( '' === $code ) {
			return '';
		}

		$kind = 'reel';
		if ( preg_match( '#/(p|reel|reels|tv)/#i', $url, $m ) ) {
			$piece = strtolower( $m[1] );
			$kind  = ( 'reel' === $piece || 'reels' === $piece ) ? 'reel' : $piece;
		}

		// The slug is the PATH only. The query tail is added when the address
		// is printed, because a "?" stored in a slug would be read as the
		// start of a query string by every router that has to match it.
		$base = 'www.instagram.com/' . $kind . '/' . $code;
		$slug = $base;
		$n    = 1;
		while ( $this->db->get_link_by_slug( $slug ) ) {
			$n++;
			$slug = $base . '-' . $n;
		}
		return $slug;
	}

	/**
	 * Create a link from clean input.
	 *
	 * @param array $clean Validated fields.
	 * @return int|WP_Error
	 */
	public function create( $clean ) {
		$slug   = $this->slug_for( $clean );
		$host   = (string) wp_parse_url( $clean['destination'], PHP_URL_HOST );
		$now    = $this->db->now();
		$preview_source = ! empty( $clean['whatsapp_preview_url'] ) ? $clean['whatsapp_preview_url'] : $clean['destination'];
		$preview = 'legal' === $clean['link_type'] && empty( $clean['whatsapp_preview_url'] )
			? array(
				'title'       => $clean['page_title'] ? $clean['page_title'] : __( 'Document link', 'cloaklink' ),
				'description' => __( 'Download the shared document.', 'cloaklink' ),
				'site_name'   => 'Credit Control',
				'image'       => '',
			)
			: $this->preview_metadata( $preview_source );
		$meta   = array(
			'accept_deny'       => (int) $clean['accept_deny'],
			// Printed on the desk form and used as the last part of the address.
			'party_name'        => isset( $clean['party_name'] ) ? (string) $clean['party_name'] : '',
			// Printed after the address, so the link reads as the kind of
			// document it points at. Empty means the bare address.
			'extension'         => isset( $clean['extension'] ) ? (string) $clean['extension'] : '',
			'otp'               => (int) $clean['otp'],
			'notice'            => $clean['notice'],
			'insta_code'        => $this->insta_code( $clean['media_url'] ),
			'destination_host'  => $host,
			// Defaulted rather than assumed.
			//
			// These four are read straight off the array the form handler
			// builds, so a caller that is not that handler — a duplicate, an
			// import, anything added later — leaves them out and PHP 8 raises
			// "Undefined array key" for each one. That warning prints before
			// the redirect that follows, so the redirect is dropped and the
			// action appears to do nothing, which is exactly how duplicate
			// behaved: the copy was made and the operator never saw it.
			'pin_hash'          => isset( $clean['pin_hash'] ) ? (string) $clean['pin_hash'] : '',
			'single_use'        => isset( $clean['single_use'] ) ? (int) $clean['single_use'] : 0,
			'locked_hash'       => '',
			'domain'            => isset( $clean['domain'] ) ? (string) $clean['domain'] : '',
			'whatsapp_preview_url' => isset( $clean['whatsapp_preview_url'] ) ? (string) $clean['whatsapp_preview_url'] : '',
			'share_title'       => isset( $preview['title'] ) ? $preview['title'] : $clean['title'],
			'share_description' => isset( $preview['description'] ) ? $preview['description'] : '',
			'share_site_name'   => isset( $preview['site_name'] ) ? $preview['site_name'] : $host,
			'share_image'       => isset( $preview['image'] ) ? $preview['image'] : '',
			'share_icon'        => isset( $preview['icon'] ) ? $preview['icon'] : '',
		);

		$id = $this->db->insert_link(
			array(
				'slug'             => $slug,
				'title'            => $clean['title'],
				'label'            => $clean['label'],
				'link_type'        => $clean['link_type'],
				'destination'      => $clean['destination'],
				'destination_host' => $host,
				'media_url'        => $clean['media_url'],
				'media_kind'       => 'instagram' === $clean['link_type'] ? 'instagram' : '',
				'page_title'       => $clean['page_title'],
				'mode'             => $clean['mode'],
				'max_clicks'       => (int) $clean['max_clicks'],
				'click_count'      => 0,
				'meta'             => $this->db->encode( $meta ),
				'status'           => $clean['status'],
				'created_by'       => get_current_user_id(),
				'created_at'       => $now,
				'updated_at'       => $now,
				'expires_at'       => $clean['expires_at'],
			)
		);

		if ( ! $id ) {
			return new WP_Error( 'cloaklink_db', __( 'The link could not be saved. Please try again.', 'cloaklink' ) );
		}

		$this->log_audit( 'link_created', $id, array( 'slug' => $slug, 'type' => $clean['link_type'] ) );
		return $id;
	}

	/**
	 * Update an existing link.
	 *
	 * @param int   $id    Link id.
	 * @param array $clean Validated fields.
	 * @return bool|WP_Error
	 */
	public function update( $id, $clean ) {
		$existing = $this->db->get_link( $id );
		if ( ! $existing ) {
			return new WP_Error( 'cloaklink_missing', __( 'Link not found.', 'cloaklink' ) );
		}

		$host     = (string) wp_parse_url( $clean['destination'], PHP_URL_HOST );
		$old_meta = (array) $existing['meta'];

		// A blank PIN box means "leave it alone", not "remove it"; removal is
		// its own explicit checkbox so a typo cannot silently unlock a link.
		$pin_hash = isset( $old_meta['pin_hash'] ) ? (string) $old_meta['pin_hash'] : '';
		if ( 'REMOVE' === $clean['pin_hash'] ) {
			$pin_hash = '';
		} elseif ( '' !== $clean['pin_hash'] ) {
			$pin_hash = $clean['pin_hash'];
		}

		$preview_source = ! empty( $clean['whatsapp_preview_url'] ) ? $clean['whatsapp_preview_url'] : $clean['destination'];
		$preview = 'legal' === $clean['link_type'] && empty( $clean['whatsapp_preview_url'] )
			? array(
				'title'       => $clean['page_title'] ? $clean['page_title'] : ( ! empty( $old_meta['file_name'] ) ? $old_meta['file_name'] : __( 'Document link', 'cloaklink' ) ),
				'description' => __( 'Download the shared document.', 'cloaklink' ),
				'site_name'   => 'Credit Control',
				'image'       => '',
			)
			: $this->preview_metadata( $preview_source );
		$meta = array_merge(
			$old_meta,
			array(
				'accept_deny'        => (int) $clean['accept_deny'],
				'party_name'         => isset( $clean['party_name'] ) ? (string) $clean['party_name'] : ( isset( $old_meta['party_name'] ) ? (string) $old_meta['party_name'] : '' ),
				'extension'          => isset( $clean['extension'] ) ? (string) $clean['extension'] : '',
				'otp'                => (int) $clean['otp'],
				'notice'             => $clean['notice'],
				'insta_code'         => $this->insta_code( $clean['media_url'] ),
				'destination_host'   => $host,
				'pin_hash'           => $pin_hash,
				'single_use'         => (int) $clean['single_use'],
				'domain'             => (string) $clean['domain'],
				'whatsapp_preview_url' => (string) $clean['whatsapp_preview_url'],
				'share_title'        => isset( $preview['title'] ) ? $preview['title'] : $clean['title'],
				'share_description' => isset( $preview['description'] ) ? $preview['description'] : '',
				'share_site_name'   => isset( $preview['site_name'] ) ? $preview['site_name'] : $host,
				'share_image'        => isset( $preview['image'] ) ? $preview['image'] : '',
				'share_icon'         => isset( $preview['icon'] ) ? $preview['icon'] : '',
			)
		);

		$ok = $this->db->update_link(
			$id,
			array(
				'title'            => $clean['title'],
				'label'            => $clean['label'],
				'link_type'        => $clean['link_type'],
				'destination'      => $clean['destination'],
				'destination_host' => $host,
				'media_url'        => $clean['media_url'],
				'media_kind'       => 'instagram' === $clean['link_type'] ? 'instagram' : '',
				'page_title'       => $clean['page_title'],
				'mode'             => $clean['mode'],
				'max_clicks'       => (int) $clean['max_clicks'],
				'meta'             => $this->db->encode( $meta ),
				'status'           => $clean['status'],
				'updated_at'       => $this->db->now(),
				'expires_at'       => $clean['expires_at'],
			)
		);

		$this->log_audit( 'link_updated', $id, array( 'slug' => $existing['slug'] ) );
		return $ok;
	}

	/**
	 * Why a link cannot be opened, or '' when it can.
	 *
	 * @param array $link Link row.
	 * @param bool  $raw  Skip the expiry write-back.
	 * @return string Reason code.
	 */
	public function state( $link, $raw = false ) {
		// A row read from the database always carries every column, so the
		// reads below were safe in practice. Every one of them is defaulted
		// anyway: this method is also called from previews and from a badge
		// on a row that may have been deleted between the query and the
		// render, and a missing key there raised six warnings to say what a
		// single "not found" already said.
		$link = is_array( $link ) ? $link : array();
		$status = isset( $link['status'] ) ? (string) $link['status'] : '';
		if ( '' === $status && isset( $link['id'] ) ) {
			$status = 'active';
		}
		if ( '' === $status ) {
			return 'not_found';
		}
		if ( 'deleted' === $status ) {
			return 'deleted';
		}
		if ( 'paused' === $status ) {
			return 'paused';
		}
		if ( 'expired' === $status ) {
			return 'expired';
		}

		$exp_ts = $this->db->to_ts( isset( $link['expires_at'] ) ? $link['expires_at'] : '' );
		if ( $exp_ts && $exp_ts <= time() ) {
			if ( ! $raw && ! empty( $link['id'] ) ) {
				$this->db->update_link( (int) $link['id'], array( 'status' => 'expired' ) );
			}
			return 'expired';
		}

		$max_clicks = isset( $link['max_clicks'] ) ? (int) $link['max_clicks'] : 0;
		$clicked    = isset( $link['click_count'] ) ? (int) $link['click_count'] : 0;
		if ( $max_clicks > 0 && $clicked >= $max_clicks ) {
			return 'limit';
		}

		return '';
	}

	/**
	 * Resolve the location requirement for a link, merging global and per-link.
	 *
	 * @param array $link Link row.
	 * @return string 'require' | 'optional' | 'off'
	 */
	public function location_mode( $link ) {
		$mode = isset( $link['mode'] ) ? (string) $link['mode'] : 'require';

		// The link's own setting decides. A global switch that silently
		// overrode it made "this link asks for location" impossible to turn on:
		// the panel offered the choice and the plugin ignored it.
		// A reel is always asked, and never held back for the answer.
		//
		// The position is wanted on every opening of a reel — that is the
		// whole reason the link was built — but a person who declines must
		// still reach the post, because the post is what they were sent. So
		// an Instagram link is never 'off' (nothing would be asked) and never
		// 'require' (a refusal would end the visit). Both answers are still
		// written to the visit, 'granted' with coordinates and 'refused' with
		// the reason, so the desk sees who allowed and who did not.
		if ( 'instagram' === ( isset( $link['link_type'] ) ? (string) $link['link_type'] : '' ) ) {
			return 'optional';
		}

		if ( 'off' === $mode ) {
			return 'off';
		}
		if ( 'optional' === $mode ) {
			return 'optional';
		}
		return 'require';
	}

	/**
	 * Human label for a state code.
	 *
	 * @param string $state State.
	 * @return string
	 */
	public static function state_label( $state ) {
		$map = array(
			'active'    => __( 'Active', 'cloaklink' ),
			'paused'    => __( 'Paused', 'cloaklink' ),
			'expired'   => __( 'Expired', 'cloaklink' ),
			'limit'     => __( 'Click limit reached', 'cloaklink' ),
			'deleted'   => __( 'Deleted', 'cloaklink' ),
			'not_found' => __( 'Not found', 'cloaklink' ),
		);
		return isset( $map[ $state ] ) ? $map[ $state ] : $state;
	}

	/**
	 * Badge class for a link status.
	 *
	 * @param array $link Link row.
	 * @return string
	 */
	public function badge( $link ) {
		$state = $this->state( $link, true );
		// state() says "nothing wrong" with an empty string, which used to
		// reach the label lookup and print an empty badge. A blank state is
		// an active link, so name it here once.
		if ( '' === $state ) {
			$state = 'active';
		}
		// One class per state, so the colour of the word is decided in CSS
		// rather than by a chain of conditions here. A row that is paused or
		// used up is then findable by colour before the word is read.
		$class = 'cl-status';
		if ( in_array( $state, array( 'active', 'paused', 'expired', 'limit' ), true ) ) {
			$class .= ' cl-status--' . $state;
		} elseif ( 'deleted' === $state || 'not_found' === $state ) {
			$class .= ' cl-status--dead';
		} else {
			$class .= ' cl-status--active';
		}
		return '<span class="' . esc_attr( $class ) . '">' . esc_html( 'active' === $state ? __( 'Active', 'cloaklink' ) : self::state_label( $state ) ) . '</span>';
	}

	/**
	 * Create the hidden holder page for pretty links.
	 *
	 * @return int
	 */
	public function ensure_link_page() {
		$id = (int) $this->settings->get( 'link_page_id' );
		if ( $id && get_post( $id ) ) {
			return $id;
		}

		// A stale id (page deleted behind our back) must not stop link creation.
		if ( $id && ! get_post( $id ) ) {
			$id = 0;
		}

		$existing = get_page_by_path( 'cloaklink', OBJECT, 'page' );
		if ( $existing ) {
			$id = (int) $existing->ID;
		} else {
			$id = wp_insert_post(
				array(
					'post_title'   => 'CloakLink',
					'post_name'    => 'cloaklink',
					'post_content' => '',
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_author'  => get_current_user_id(),
					'comment_status' => 'closed',
					'ping_status'  => 'closed',
				)
			);
		}

		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_cloaklink_holder', 1 );
			$all = $this->settings->all();
			$all['link_page_id'] = (int) $id;
			update_option( CloakLink_Settings::OPTION, $all, false );
			return (int) $id;
		}
		return 0;
	}

	/**
	 * Append an entry to the audit trail option.
	 *
	 * @param string $action Action key.
	 * @param int    $link_id Link id.
	 * @param array  $context Extra.
	 * @return void
	 */
	public function log_audit( $action, $link_id = 0, $context = array() ) {
		if ( ! $this->settings->get( 'audit_log' ) ) {
			return;
		}
		$log   = get_option( 'cloaklink_audit', array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array(
			'time'    => current_time( 'mysql' ),
			'user'    => get_current_user_id(),
			'action'  => $action,
			'link_id' => (int) $link_id,
			'context' => $context,
			'ip'      => CloakLink_Geo::ip(),
		);
		if ( count( $log ) > 400 ) {
			$log = array_slice( $log, -400 );
		}
		update_option( 'cloaklink_audit', $log, false );
	}

	/**
	 * The audit trail, newest first.
	 *
	 * @param int $limit Rows.
	 * @return array
	 */
	public function audit( $limit = 60 ) {
		$log = get_option( 'cloaklink_audit', array() );
		$log = is_array( $log ) ? array_reverse( $log ) : array();
		return array_slice( $log, 0, $limit );
	}

	/**
	 * Site origin used for share links.
	 *
	 * @return string
	 */
	public function site_host() {
		$parts = wp_parse_url( home_url() );
		return isset( $parts['host'] ) ? $parts['host'] : '';
	}
}
