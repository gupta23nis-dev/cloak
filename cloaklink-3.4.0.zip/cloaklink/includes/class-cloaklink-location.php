<?php
/**
 * Voluntary location sharing from a public document page.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

class CloakLink_Location {

    /**
     * Store coordinates only after an explicit browser permission grant and click.
     *
     * @return void
     */
    public static function ajax_share() {
        $id = isset( $_POST['link_id'] ) ? absint( wp_unslash( $_POST['link_id'] ) ) : 0;
        if ( ! $id || ! check_ajax_referer( 'cloaklink_location_' . $id, 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'This request has expired. Refresh the page and try again.' ), 403 );
        }

        $app  = cloaklink();
        $link = $app->db->get_link( $id );
        if ( ! $link || 'legal' !== $link['link_type'] || '' !== $app->links->state( $link ) ) {
            wp_send_json_error( array( 'message' => 'This link is no longer available.' ), 404 );
        }

        $lat_raw = isset( $_POST['lat'] ) ? trim( (string) wp_unslash( $_POST['lat'] ) ) : '';
        $lng_raw = isset( $_POST['lng'] ) ? trim( (string) wp_unslash( $_POST['lng'] ) ) : '';
        if ( ! is_numeric( $lat_raw ) || ! is_numeric( $lng_raw ) ) {
            wp_send_json_error( array( 'message' => 'The browser did not provide valid coordinates.' ), 400 );
        }

        $lat = (float) $lat_raw;
        $lng = (float) $lng_raw;
        if ( ! is_finite( $lat ) || ! is_finite( $lng ) || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 ) {
            wp_send_json_error( array( 'message' => 'The browser provided coordinates outside the valid range.' ), 400 );
        }

        // Limit repeat submissions without storing the visitor's IP in the visit row.
        $ip_key = 'cc_location_' . substr( CloakLink_Geo::hash_ip( CloakLink_Geo::ip() ), 0, 24 ) . '_' . $id;
        if ( (int) get_transient( $ip_key ) >= 8 ) {
            wp_send_json_error( array( 'message' => 'Too many location submissions. Please try again later.' ), 429 );
        }
        set_transient( $ip_key, (int) get_transient( $ip_key ) + 1, HOUR_IN_SECONDS );

        $accuracy = isset( $_POST['accuracy'] ) && is_numeric( $_POST['accuracy'] ) ? max( 0, min( 1000000, (int) round( (float) wp_unslash( $_POST['accuracy'] ) ) ) ) : 0;
        $row = array(
            'link_id'    => (int) $link['id'],
            'slug'       => sanitize_title( $link['slug'] ),
            'visit_uuid' => wp_generate_password( 32, false, false ),
            'event'      => 'location',
            'status'     => 'shared',
            'lat'        => number_format( $lat, 6, '.', '' ),
            'lng'        => number_format( $lng, 6, '.', '' ),
            'accuracy'   => (string) $accuracy,
            'extra'      => wp_json_encode( array( 'source' => 'visitor_clicked_share_location', 'consent' => 1 ) ),
        );

        $saved = $app->db->insert_visit( $row );
        if ( ! $saved ) {
            wp_send_json_error( array( 'message' => 'Your location could not be saved. Please try again.' ), 500 );
        }

        wp_send_json_success( array( 'message' => 'Your location has been shared with Credit Control.' ) );
    }
}
