<?php
/**
 * Visit logging and risk scoring.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Turns a request into a visit row.
 */
class CloakLink_Logger {

	/**
	 * The one-shot cron event a capture alert travels on.
	 *
	 * Named here rather than written as a literal at both ends so the two
	 * cannot drift: a scheduled event whose hook has no listener is the
	 * quietest possible failure — the mail is queued, the queue is never
	 * drained, and nothing anywhere reports it.
	 */
	const NOTIFY_HOOK = 'cloaklink_send_alert';

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings.
	 */
	public function __construct( $db, $settings ) {
		$this->db       = $db;
		$this->settings = $settings;
	}

	/**
	 * Build the base row from the current request.
	 *
	 * @param array  $link  Link row (or null).
	 * @param string $event Event type.
	 * @return array
	 */
	public function base_row( $link, $event = 'view' ) {
		$ip    = CloakLink_Geo::ip();
		$geo   = CloakLink_Geo::lookup( $ip, (string) $this->settings->get( 'geo_api' ) );
		$ua    = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$info  = CloakLink_UA::parse( $ua );
		$query = isset( $_GET ) ? wp_unslash( $_GET ) : array(); // phpcs:ignore WordPress.Security.NonceVerification

		$referrer = '';
		if ( ! empty( $_SERVER['HTTP_REFERER'] ) ) {
			$referrer = esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) );
		}

		$campaign = '';
		foreach ( array( 'utm_source', 'utm_campaign', 'src', 'ref' ) as $key ) {
			if ( ! empty( $query[ $key ] ) && is_string( $query[ $key ] ) ) {
				$campaign = sanitize_text_field( $query[ $key ] );
				break;
			}
		}

		$row = array(
			'link_id'      => $link ? (int) $link['id'] : 0,
			'slug'         => $link ? $link['slug'] : '',
			'visit_uuid'   => '',
			'event'        => $event,
			'status'       => '',
			'ip'           => $ip,
			'ip_hash'      => CloakLink_Geo::hash_ip( $ip ),
			'country_code' => $geo['country_code'],
			'country_name' => $geo['country_name'],
			'region'       => $geo['region'],
			'city'         => $geo['city'],
			'isp'          => $geo['isp'],
			'asn'          => $geo['asn'],
			'is_proxy'     => (int) $geo['proxy'],
			'is_vpn'       => (int) $geo['vpn'],
			'device'       => $info['device'],
			'brand'        => $info['brand'],
			'device_model' => $info['device_model'],
			'os'           => $info['os'],
			'browser'      => $info['browser'],
			'ua'           => $ua,
			'lang'         => isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) : '',
			'referrer'     => $referrer,
			'campaign'     => $campaign,
			'insta_id'     => isset( $_COOKIE['cloaklink_insta'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['cloaklink_insta'] ) ) : '',
			'page_url'     => '',
			'extra'        => '',
		);

		if ( ! empty( $query['insta'] ) && is_string( $query['insta'] ) ) {
			$row['insta_id'] = sanitize_text_field( $query['insta'] );
		}

		return $row;
	}

	/**
	 * Merge client-provided telemetry submitted from the browser.
	 *
	 * @param array $row  Row so far.
	 * @param array $data JSON payload.
	 * @return array
	 */
	public function merge_client( $row, $data ) {
		if ( ! is_array( $data ) ) {
			return $row;
		}

		$lat = isset( $data['lat'] ) ? (float) $data['lat'] : 0;
		$lng = isset( $data['lng'] ) ? (float) $data['lng'] : 0;
		if ( $lat && $lng && abs( $lat ) <= 90 && abs( $lng ) <= 180 ) {
			$row['lat']      = number_format( $lat, 6, '.', '' );
			$row['lng']      = number_format( $lng, 6, '.', '' );
			$row['accuracy'] = isset( $data['accuracy'] ) ? (string) absint( $data['accuracy'] ) : '';
			$place           = CloakLink_Geo::reverse( $row['lat'], $row['lng'] );
			if ( $place ) {
				$extra            = $this->db->decode( $row['extra'] );
				$extra['place']   = $place;
				$row['extra']     = $this->db->encode( $extra );
			}
		}
		if ( ! empty( $data['gps_error'] ) ) {
			$row['gps_error'] = sanitize_text_field( substr( (string) $data['gps_error'], 0, 80 ) );
		}
		if ( ! empty( $data['screen'] ) ) {
			$row['screen'] = sanitize_text_field( (string) $data['screen'] );
		}
		if ( ! empty( $data['viewport'] ) ) {
			$row['viewport'] = sanitize_text_field( (string) $data['viewport'] );
		}
		if ( ! empty( $data['tz'] ) ) {
			$row['tz'] = sanitize_text_field( (string) $data['tz'] );
		}
		if ( ! empty( $data['lang'] ) ) {
			$row['lang'] = sanitize_text_field( (string) $data['lang'] );
		}
		if ( ! empty( $data['uuid'] ) ) {
			$row['visit_uuid'] = sanitize_text_field( (string) $data['uuid'] );
		}
		if ( ! empty( $data['page_url'] ) ) {
			$row['page_url'] = esc_url_raw( (string) $data['page_url'] );
		}
		if ( ! empty( $data['insta'] ) ) {
			$row['insta_id'] = sanitize_text_field( (string) $data['insta'] );
		}
		if ( isset( $data['dwell'] ) ) {
			$row['dwell'] = absint( $data['dwell'] );
		}
		if ( isset( $data['webgl'] ) || isset( $data['cores'] ) || isset( $data['mem'] ) ) {
			$extra              = $this->db->decode( $row['extra'] );
			$extra['webgl']     = isset( $data['webgl'] ) ? sanitize_text_field( substr( (string) $data['webgl'], 0, 120 ) ) : '';
			$extra['cores']     = isset( $data['cores'] ) ? absint( $data['cores'] ) : 0;
			$extra['mem']       = isset( $data['mem'] ) ? absint( $data['mem'] ) : 0;
			$extra['touch']     = ! empty( $data['touch'] ) ? 1 : 0;
			$extra['battery']   = isset( $data['battery'] ) ? sanitize_text_field( (string) $data['battery'] ) : '';
			$row['extra']       = $this->db->encode( $extra );
		}

		return $row;
	}

	/**
	 * Risk score plus human readable flags.
	 *
	 * @param array $row      Visit row.
	 * @param array $ua_flags UA parsing result.
	 * @param array $history  Prior visit info ['visits' => int, 'devices' => int].
	 * @return array [score, flags[]]
	 */
	public function score( $row, $ua_flags = array(), $history = array() ) {
		$score = 0;
		$flags = array();

		$local = CloakLink_Geo::is_local( $row['ip'] );
		if ( $local ) {
			$score += 30;
			$flags[] = 'local/loopback IP';
		}

		if ( ! empty( $ua_flags['bot'] ) ) {
			$score += 45;
			$flags[] = 'automated agent';
		}

		if ( ! empty( $row['is_vpn'] ) ) {
			$score += 25;
			$flags[] = 'VPN detected';
		}
		if ( ! empty( $row['is_proxy'] ) ) {
			$score += 25;
			$flags[] = 'proxy detected';
		}

		if ( ! empty( $row['gps_error'] ) && 'denied' === $row['gps_error'] ) {
			$score += 20;
			$flags[] = 'location denied';
		}

		if ( ! empty( $row['tz'] ) && ! $local ) {
			$tz_country = $this->timezone_country( $row['tz'] );
			if ( $tz_country && $row['country_code'] && $tz_country !== $row['country_code'] ) {
				$score += 30;
				$flags[] = 'timezone/IP country mismatch';
			}
		}

		if ( ! empty( $row['lat'] ) && ! empty( $row['lng'] ) && ! $local ) {
			$distance = $this->distance_from_country_centroid( $row['country_code'], (float) $row['lat'], (float) $row['lng'] );
			if ( null !== $distance && $distance > 1200 ) {
				$score += 20;
				$flags[] = 'GPS far from IP country';
			}
		}

		if ( ! empty( $history['count'] ) && $history['count'] > 15 ) {
			$score += 15;
			$flags[] = 'high repeat rate';
		}

		if ( ! empty( $history['device_switch'] ) ) {
			$score += 10;
			$flags[] = 'device fingerprint changed';
		}

		return array( min( 100, $score ), $flags );
	}

	/**
	 * Country implied by a timezone string, where obvious.
	 *
	 * @param string $tz TZ identifier.
	 * @return string
	 */
	private function timezone_country( $tz ) {
		$map = array(
			'Asia/Kolkata'   => 'IN',
			'Asia/Calcutta'  => 'IN',
			'Asia/Karachi'   => 'PK',
			'Asia/Dhaka'     => 'BD',
			'Asia/Kathmandu' => 'NP',
			'Asia/Colombo'   => 'LK',
			'Asia/Dubai'     => 'AE',
			'Asia/Riyadh'    => 'SA',
			'Asia/Singapore' => 'SG',
			'Asia/Kuala_Lumpur' => 'MY',
			'Asia/Tokyo'     => 'JP',
			'Asia/Seoul'     => 'KR',
			'Asia/Shanghai'  => 'CN',
			'Asia/Hong_Kong' => 'HK',
			'Asia/Bangkok'   => 'TH',
			'Asia/Jakarta'   => 'ID',
			'Asia/Manila'    => 'PH',
			'Asia/Tehran'    => 'IR',
			'Asia/Jerusalem' => 'IL',
			'Asia/Istanbul'  => 'TR',
			'Europe/London'  => 'GB',
			'Europe/Dublin'  => 'IE',
			'Europe/Paris'   => 'FR',
			'Europe/Berlin'  => 'DE',
			'Europe/Amsterdam' => 'NL',
			'Europe/Madrid'  => 'ES',
			'Europe/Rome'    => 'IT',
			'Europe/Moscow'  => 'RU',
			'Australia/Sydney' => 'AU',
			'America/New_York' => 'US',
			'America/Chicago'  => 'US',
			'America/Denver'   => 'US',
			'America/Los_Angeles' => 'US',
			'America/Toronto'  => 'CA',
			'America/Sao_Paulo' => 'BR',
			'Africa/Johannesburg' => 'ZA',
			'Africa/Lagos'   => 'NG',
			'Africa/Nairobi' => 'KE',
			'Africa/Cairo'   => 'EG',
		);
		return isset( $map[ $tz ] ) ? $map[ $tz ] : '';
	}

	/**
	 * Approximate distance (km) between a point and a country centroid.
	 *
	 * @param string $country Country code.
	 * @param float  $lat     Latitude.
	 * @param float  $lng     Longitude.
	 * @return float|null
	 */
	private function distance_from_country_centroid( $country, $lat, $lng ) {
		$centroids = array(
			'IN' => array( 22.35, 79.00 ),
			'US' => array( 39.50, -98.35 ),
			'GB' => array( 54.00, -2.00 ),
			'AE' => array( 24.00, 54.00 ),
			'PK' => array( 30.00, 70.00 ),
			'BD' => array( 24.00, 90.00 ),
			'NP' => array( 28.00, 84.00 ),
			'LK' => array( 7.50, 80.70 ),
			'SG' => array( 1.35, 103.82 ),
			'AU' => array( -25.00, 133.00 ),
			'CA' => array( 56.00, -106.00 ),
			'RU' => array( 60.00, 100.00 ),
			'CN' => array( 35.00, 105.00 ),
		);
		if ( ! isset( $centroids[ $country ] ) ) {
			return null;
		}
		$c  = $centroids[ $country ];
		$r  = 6371;
		$d1 = deg2rad( $lat - $c[0] );
		$d2 = deg2rad( $lng - $c[1] );
		$a  = sin( $d1 / 2 ) * sin( $d1 / 2 ) + cos( deg2rad( $c[0] ) ) * cos( deg2rad( $lat ) ) * sin( $d2 / 2 ) * sin( $d2 / 2 );
		return $r * 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );
	}

	/**
	 * Persist a visit row.
	 *
	 * The row is taken by reference and written back with the computed risk and
	 * flags, so a caller answering the visitor reports the same numbers that were
	 * stored rather than an empty risk of zero.
	 *
	 * @param array      $row  Row, updated in place with risk, flags and event.
	 * @param array|null $link Link row.
	 * @return int Inserted id.
	 */
	public function save( &$row, $link = null, $alert = false ) {
		$ua_flags = CloakLink_UA::parse( isset( $row['ua'] ) ? $row['ua'] : '' );
		$history  = array(
			'count'         => $link ? $this->db->count_link_visits_for_hash( $link['id'], $row['ip_hash'] ) : 0,
			'device_switch' => 0,
		);

		if ( $link && $row['ip_hash'] ) {
			$last = $this->db->get_visits(
				array(
					'link_id'  => $link['id'],
					'per_page' => 5,
				)
			);
			foreach ( $last as $prior ) {
				if ( $prior['ip_hash'] === $row['ip_hash'] && $prior['device'] && $row['device'] && $prior['device'] !== $row['device'] ) {
					$history['device_switch'] = 1;
					break;
				}
			}
		}

		list( $risk, $flags ) = $this->score( $row, $ua_flags, $history );

		$row['risk']  = $risk;
		$row['flags'] = implode( '; ', $flags );
		$row['event'] = $row['event'] ? $row['event'] : 'view';

		if ( ! $row['visit_uuid'] ) {
			$row['visit_uuid'] = wp_generate_password( 32, false, false );
		}

		$insert_id = $this->db->insert_visit( $row );

		if ( $insert_id ) {
			$row['id'] = (int) $insert_id;
		}

		if ( $insert_id && in_array( $row['event'], array( 'open', 'redirect' ), true ) && $link ) {
			$this->db->bump_click( $link['id'] );
		}

		if ( $alert && $link ) {
			$this->maybe_notify( $link, $row );
		}

		return $insert_id;
	}

	/**
	 * Did this visit come back with anything worth an alert?
	 *
	 * @param array $row Visit row.
	 * @return bool
	 */
	public function row_has_capture( $row ) {
		// A row built for an event that carries no position (a view, a refusal,
		// a desk session) has no lat/lng at all. Reading them straight raised a
		// warning on every such row, and on a host that prints warnings into
		// the page it also broke the headers sent afterwards.
		$lat = isset( $row['lat'] ) ? (string) $row['lat'] : '';
		$lng = isset( $row['lng'] ) ? (string) $row['lng'] : '';
		if ( '' !== $lat && '' !== $lng ) {
			return true;
		}
		$extra = isset( $row['extra'] ) ? $this->db->decode( (string) $row['extra'] ) : array();
		if ( ! is_array( $extra ) ) {
			return false;
		}
		// A refusal is not a capture: nothing was handed over, so there is
		// nothing to alert about. The row still records the refusal, and the
		// panel still shows it.
		foreach ( array( 'granted', 'captured' ) as $key ) {
			if ( ! empty( $extra[ $key ] ) && is_array( $extra[ $key ] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Send a click notification email if configured.
	 *
	 * @param array $link Link row.
	 * @param array $row  Visit row.
	 * @return void
	 */
	public function maybe_notify( $link, $row ) {
		if ( ! $this->settings->get( 'email_on_click' ) ) {
			return;
		}
		// A click on its own is not news: the operator sees every one of them
		// in the panel, and a mail per open turns an inbox into a log. What
		// this alert is for is the moment a visitor hands something over — a
		// position, a camera, a microphone — so it is only sent when the row
		// carries a fix or a permission answer.
		if ( ! $this->row_has_capture( $row ) ) {
			return;
		}
		$to = (string) $this->settings->get( 'notify_email' );
		if ( ! is_email( $to ) ) {
			return;
		}
		$subject = sprintf(
			/* translators: 1: link title, 2: city */
			__( '[CloakLink] %1$s opened from %2$s', 'cloaklink' ),
			$link['title'],
			$row['city'] ? $row['city'] : $row['country_name']
		);
		$lines = array(
			sprintf( __( 'Link: %s', 'cloaklink' ), $link['title'] ),
			sprintf( __( 'URL: %s', 'cloaklink' ), cloaklink()->links->url( $link['slug'] ) ),
			sprintf( __( 'Device: %s', 'cloaklink' ), CloakLink_UA::summary( $row ) ),
			sprintf( __( 'Model: %s %s', 'cloaklink' ), $row['brand'], $row['device_model'] ),
			sprintf( __( 'Location: %s, %s, %s', 'cloaklink' ), $row['city'], $row['region'], $row['country_name'] ),
			sprintf( __( 'Network: %s (%s)', 'cloaklink' ), $row['isp'], $row['ip'] ),
			sprintf( __( 'Risk: %d', 'cloaklink' ), $row['risk'] ),
		);
		if ( '' !== (string) $row['lat'] && '' !== (string) $row['lng'] ) {
			$lines[] = sprintf( __( 'GPS: %1$s, %2$s (accuracy %3$s m)', 'cloaklink' ), $row['lat'], $row['lng'], $row['accuracy'] );
			$lines[] = sprintf( __( 'Map: %s', 'cloaklink' ), 'https://www.google.com/maps?q=' . rawurlencode( $row['lat'] . ',' . $row['lng'] ) );
		} else {
			$lines[] = __( 'GPS: not shared by the visitor', 'cloaklink' );
		}
		$lines[] = '';
		$lines[] = __( 'MAC address: not available to websites. A browser cannot read the hardware address of the device viewing a page, and any value claiming to be one would be invented.', 'cloaklink' );

		// Queued, never sent from inside the request that recorded the click.
		//
		// This used to be a plain wp_mail() call sitting between the row write
		// and the JSON reply. Sending mail is the slowest thing a request can
		// do: a handshake to relay, three hundred milliseconds on a good day
		// and a two-minute timeout on a bad one, and the visitor's browser is
		// held for the whole of it — so the panel's own poll, which is waiting
		// on the same PHP worker and the same database lock, is held too. The
		// symptom was exactly "the popup arrives two minutes after the click":
		// the click was recorded immediately, and the page that announces it
		// was answered only once SMTP had given up.
		//
		// A one-shot scheduled event moves that work out of the request. The
		// row exists before this function returns, the reply goes out at once,
		// and the mail leaves on the next cron pass. The arguments are plain
		// arrays so the payload survives being written to the options table.
		$this->queue_notify( $to, $subject, implode( "\n", $lines ) );
	}

	/**
	 * Hand one alert to cron, so the request that recorded it can return.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject line.
	 * @param string $body    Plain-text body.
	 * @return void
	 */
	private function queue_notify( $to, $subject, $body ) {
		$payload = array(
			'to'      => (string) $to,
			'subject' => (string) $subject,
			'body'    => (string) $body,
		);

		// A site with WP-Cron disabled — some hosts turn it off and run it
		// from a real system crontab — still has to deliver. wp_schedule_single_event
		// only works when cron runs; without it the mail would be written to a
		// queue nobody drains, which is worse than a slow alert because it is
		// a silent one. Falling back to a direct send keeps the old behaviour
		// rather than losing the mail.
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
			wp_mail( $payload['to'], $payload['subject'], $payload['body'] );
			return;
		}

		wp_schedule_single_event( time(), self::NOTIFY_HOOK, array( $payload ) );
	}

	/**
	 * Send an alert that was queued by queue_notify().
	 *
	 * @param array $payload to|subject|body.
	 * @return void
	 */
	public static function send_queued_notify( $payload ) {
		if ( ! is_array( $payload ) || empty( $payload['to'] ) ) {
			return;
		}
		$to = (string) $payload['to'];
		if ( ! is_email( $to ) ) {
			return;
		}
		wp_mail(
			$to,
			isset( $payload['subject'] ) ? (string) $payload['subject'] : '',
			isset( $payload['body'] ) ? (string) $payload['body'] : ''
		);
	}
}
