<?php
/**
 * Private sign-in screen for the control panel.
 *
 * The panel lives in wp-admin, but the address people are given is not
 * /wp-admin: it is a private path that shows a branded sign-in and then sends
 * the administrator straight to CloakLink. Anyone who is not signed in and
 * reaches wp-admin is sent here, so the ordinary WordPress login never appears.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Routes and renders the private sign-in.
 */
class CloakLink_Login {

	/** @var CloakLink_Settings */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_Settings $settings Settings.
	 */
	public function __construct( $settings ) {
		$this->settings = $settings;
	}

	/**
	 * The path this login is served on.
	 *
	 * @return string
	 */
	public function path() {
		$slug = sanitize_title( (string) $this->settings->get( 'panel_slug', 'info-security-desk' ) );
		return '' !== $slug ? $slug : 'info-security-desk';
	}

	/**
	 * Register the rewrite.
	 *
	 * @return void
	 */
	public function register_rewrites() {
		// The panel has readable addresses: /<panel>/links, /<panel>/links/37,
		// /<panel>/settings and so on. Each one is a real path segment rather
		// than a query string, so a screen can be linked, bookmarked and
		// opened from a phone without a string of punctuation after it. The
		// old ?cl_page= form keeps working — every address this plugin has
		// ever printed still resolves — because some browsers and mail
		// clients trim or reorder a query string but never a path.
		$panel = preg_quote( $this->path(), '#' );
		add_rewrite_rule(
			$panel . '/([a-z]+)(?:/([0-9]+))?/?$',
			'index.php?cloaklink_panel=1&cloaklink_page=$matches[1]&cloaklink_id=$matches[2]',
			'top'
		);
		add_rewrite_rule(
			$panel . '/?$',
			'index.php?cloaklink_panel=1',
			'top'
		);
		// The names this desk has answered to before. Registering them keeps
		// an old bookmark working rather than landing the operator on a 404
		// with no way to tell what changed.
		foreach ( self::aliases() as $alias ) {
			$alias = preg_quote( $alias, '#' );
			add_rewrite_rule(
				$alias . '/([a-z]+)(?:/([0-9]+))?/?$',
				'index.php?cloaklink_panel=1&cloaklink_page=$matches[1]&cloaklink_id=$matches[2]',
				'top'
			);
			add_rewrite_rule(
				$alias . '/?$',
				'index.php?cloaklink_panel=1',
				'top'
			);
		}

		// The restricted console has its own address, so the two doors are
		// actually two doors: one open to any signed-in operator, one that
		// answers only to the networks the operator listed. It takes the same
		// readable shape.
		$vault = preg_quote( $this->vault_path(), '#' );
		add_rewrite_rule(
			$vault . '/([a-z]+)(?:/([0-9]+))?/?$',
			'index.php?cloaklink_vault=1&cloaklink_page=$matches[1]&cloaklink_id=$matches[2]',
			'top'
		);
		add_rewrite_rule(
			$vault . '/?$',
			'index.php?cloaklink_vault=1',
			'top'
		);
	}

	/**
	 * The path segments beyond this install's home, or array() when the
	 * address does not begin with one of this panel's own names.
	 *
	 * @return array
	 */
	private function own_segments() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path = (string) parse_url( $uri, PHP_URL_PATH );
		$home = (string) parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( '' !== $home && '/' !== $home && 0 === strpos( $path, rtrim( $home, '/' ) ) ) {
			$path = substr( $path, strlen( rtrim( $home, '/' ) ) );
		}
		$bits = array_values( array_filter( explode( '/', trim( $path, '/' ) ), 'strlen' ) );
		if ( ! $bits ) {
			return array();
		}
		$own = array_merge( array( $this->path(), $this->vault_path() ), self::aliases() );
		return in_array( strtolower( $bits[0] ), $own, true ) ? $bits : array();
	}

	/**
	 * The page named in the path, when the address carries one.
	 *
	 * The rewrite puts it in its own query var; a site with plain permalinks
	 * never sees that, so the path is read here too. Only the shape is
	 * trusted — the value is sanitised, and the caller checks it against the
	 * panel's own page list, so an address cannot reach a page that does not
	 * exist.
	 *
	 * @return string Page key, or '' when the address names none.
	 */
	public function path_page_from_uri() {
		$bits = $this->own_segments();
		return isset( $bits[1] ) ? sanitize_key( $bits[1] ) : '';
	}

	/**
	 * The page the address asks for, from either shape.
	 *
	 * @return string
	 */
	public function requested_page() {
		$page = get_query_var( 'cloaklink_page' );
		if ( $page ) {
			return sanitize_key( (string) $page );
		}
		if ( isset( $_GET['cloaklink_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return sanitize_key( wp_unslash( $_GET['cloaklink_page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		// The older query form. It is read after the readable one so a path
		// always wins, and it is read at all because the panel's own form
		// handlers still answer with it: a link just created redirects to
		// ?cl_page=link&id=… so the operator lands on the page holding the
		// address they have to copy. Without this the address was ignored and
		// the create landed on Overview — which is exactly the complaint that
		// the copy button had gone missing.
		if ( isset( $_GET['cl_page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$legacy = sanitize_key( wp_unslash( $_GET['cl_page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			if ( '' !== $legacy ) {
				return $legacy;
			}
		}
		$from_path = $this->path_page_from_uri();
		if ( '' !== $from_path ) {
			return $from_path;
		}

		// Nothing was asked for, so this is the operator arriving at the door
		// with no screen in mind. The Advanced screen decides where they land;
		// overview remains the shipped answer, because it is the one screen
		// that says whether anything needs doing at all.
		if ( 'GET' === strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? (string) $_SERVER['REQUEST_METHOD'] : 'GET' )
			&& function_exists( 'cloaklink' ) && cloaklink()->adv
		) {
			$landing = (string) cloaklink()->adv->get( 'default_page', 'overview' );
			// Only a screen this panel actually has, so a value left behind by
			// an older version cannot produce a blank page.
			$known = array( 'overview', 'visits', 'support', 'agents', 'links', 'map', 'settings', 'activity', 'blocks', 'tools' );
			if ( in_array( $landing, $known, true ) ) {
				return $landing;
			}
		}
		return '';
	}

	/**
	 * The id named in the path, when the address carries one.
	 *
	 * @return int
	 */
	public function requested_id() {
		$id = get_query_var( 'cloaklink_id' );
		if ( '' !== $id && null !== $id ) {
			return absint( $id );
		}
		if ( isset( $_GET['cloaklink_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return absint( $_GET['cloaklink_id'] ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		$bits = $this->own_segments();
		return isset( $bits[2] ) && ctype_digit( $bits[2] ) ? absint( $bits[2] ) : 0;
	}

	/**
	 * Every path that lands on the main panel.
	 *
	 * The address the operator set, plus the two words this desk has used
	 * before, so a bookmark made under an older name still opens the panel
	 * instead of a 404.
	 *
	 * @return array
	 */
	public static function aliases() {
		return array( 'info-security-desk', 'cloaklink-panel', 'control-room' );
	}

	/**
	 * The path the network-restricted console answers on.
	 *
	 * @return string
	 */
	public function vault_path() {
		$slug = sanitize_title( (string) $this->settings->get( 'ip_lock_page', 'secure-ops-desk' ) );
		return '' !== $slug ? $slug : 'secure-ops-desk';
	}

	/**
	 * Is the current request the restricted console?
	 *
	 * @return bool
	 */
	public function is_vault_request() {
		if ( get_query_var( 'cloaklink_vault' ) ) {
			return true;
		}
		return isset( $_GET['cloaklink_vault'] ); // phpcs:ignore WordPress.Security.NonceVerification
	}

	/**
	 * Declare the query var.
	 *
	 * @param array $vars Vars.
	 * @return array
	 */
	public static function query_vars( $vars ) {
		$vars[] = 'cloaklink_panel';
		$vars[] = 'cloaklink_vault';
		$vars[] = 'cloaklink_page';
		$vars[] = 'cloaklink_id';
		return $vars;
	}

	/**
	 * Serve the sign-in or hand a signed-in visitor to the panel.
	 *
	 * Runs on template_redirect before the router, so a signed-in administrator
	 * arriving here lands on the Overview page instead of a second login form.
	 *
	 * @return void
	 */
	public function handle() {
		// The restricted console is a different address with a different
		// answer: signed in is not enough, and the test runs before anything
		// is printed so a refusal cannot leak a fragment of the page.
		if ( $this->is_vault_request() ) {
			$this->serve_vault();
			return;
		}

		if ( ! $this->is_panel_request() ) {
			return;
		}

		// A captured file, asked for from this address.
		//
		// The console moved to its own address, and every media tile moved with
		// it — but the door that serves a file stayed behind in wp-admin, where
		// this address never arrives. So the browser asked /info-security-desk
		// for a JPEG and got the console page back instead: an <img> with an
		// HTML body draws nothing, and the card looked as though the visitor
		// had handed over no photograph at all. This hands the request to the
		// media handler, which checks the capability and the signed nonce and
		// then streams the bytes, before a single byte of the page is printed.
		if ( ! empty( $_GET['cloaklink_media'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			cloaklink()->admin->serve_media_request();
			exit;
		}

		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Referrer-Policy: no-referrer' );

		// WordPress has already decided this address does not exist and set a
		// 404 before handing over, and a 404 that then prints a whole sign-in
		// form is the worst of both: the browser, the host's cache and any
		// error page in front of it all think the page failed, so the operator
		// gets a spinner or a blank screen over a page that was fine. The desk
		// has always put this right; the console had not, which is why the
		// console was the one that looked broken.
		$this->clear_404();

		// A signed-in operator gets the panel itself, on this address, rather
		// than being pushed into wp-admin. The two addresses render the same
		// views: this one simply has no WordPress frame around them.
		if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			$this->panel_assets();
			cloaklink()->admin->render_standalone();
			exit;
		}

		$this->render();
		exit;
	}

	/**
	 * Take back the 404 WordPress set for this address.
	 *
	 * A route answered by this plugin is by definition not a missing page, so
	 * the status WordPress guessed before the plugin saw the request is put
	 * right before anything is printed. Doing it here rather than in each
	 * screen means no future screen can forget it.
	 *
	 * @return void
	 */
	private function clear_404() {
		if ( headers_sent() || ! is_404() ) {
			return;
		}
		global $wp_query;
		status_header( 200 );
		if ( $wp_query instanceof WP_Query ) {
			$wp_query->is_404 = false;
		}
	}

	/**
	 * Answer the restricted console.
	 *
	 * Three outcomes, each of which says only what the asker may know:
	 *
	 *   - the network is not on the list: a plain page saying so, with the
	 *     address it saw, so an operator who mistyped their own network can
	 *     fix it from a machine that still works;
	 *   - the network is on the list but nobody is signed in: the ordinary
	 *     sign-in, which returns here afterwards;
	 *   - both pass: the panel, with the visitor data.
	 *
	 * @return void
	 */
	private function serve_vault() {
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Referrer-Policy: no-referrer' );
		// Same reason as the console: a 403 below is a decision this plugin
		// makes, but a 200 page must not carry WordPress's leftover 404.
		$this->clear_404();

		$enabled = (bool) $this->settings->get( 'ip_lock_enabled' );
		$ip      = CloakLink_Guard::ip();
		// passes() rather than the raw matcher, so the wp-config rescue line
		// and the settings screen agree about who may come in. Signing in is
		// still required below either way.
		$listed  = CloakLink_Guard::passes();

		if ( ! $listed ) {
			// The refusal is recorded so the operator can register a
			// colleague's office from a machine that already works, rather
			// than asking them to read an address down the phone. Only the
			// address and the time are kept.
			if ( $enabled ) {
				$this->settings->note_refusal( $ip );
			}
			status_header( 403 );
			$this->render_vault_denied( $ip, $enabled );
			exit;
		}

		if ( ! ( is_user_logged_in() && current_user_can( 'manage_options' ) ) ) {
			// Not signed in yet: the sign-in screen, told to come back here.
			$this->render_vault_signin();
			exit;
		}

		$this->panel_assets();
		cloaklink()->admin->render_standalone( true );
		exit;
	}

	/**
	 * The refusal page for a network that is not on the list.
	 *
	 * It says "Unauthorized Device" and nothing else about the inside. A page
	 * that explained what it was protecting would tell a stranger walking the
	 * site that there is something worth coming back for, and a page that
	 * apologised would read as a fault they could retry rather than as a
	 * decision somebody made. The address it saw is printed because the one
	 * person who needs it is the operator standing at the wrong desk.
	 *
	 * @param string $ip      Address seen.
	 * @param bool   $enabled Whether the restricted console is switched on.
	 * @return void
	 */
	private function render_vault_denied( $ip, $enabled ) {
		$brand = cloaklink()->router->brand();
		$name  = isset( $brand['name'] ) ? (string) $brand['name'] : 'Credit Control';
		?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#f3f6f9">
<title><?php echo esc_html( sprintf( /* translators: %s: site name */ __( 'Unauthorized device — %s', 'cloaklink' ), $name ) ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/login.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body class="cl-login cl-login--denied">

<main class="cl-card cl-card--denied">
	<div class="cl-brand">
		<span class="cl-squares" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
		<span class="cl-word"><?php echo esc_html( $name ); ?></span>
	</div>

	<div class="cl-denied-mark" aria-hidden="true">
		<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" focusable="false">
			<path d="M24 4 9.5 10v12.5C9.5 31.6 15.5 39.6 24 44c8.5-4.4 14.5-12.4 14.5-21.5V10L24 4Z"/>
			<path d="m17.5 20.5 13 13"/>
			<path d="m30.5 20.5-13 13"/>
		</svg>
	</div>

	<p class="cl-denied-kicker"><?php esc_html_e( 'Access denied · 403', 'cloaklink' ); ?></p>
	<h1 class="cl-title cl-title--denied"><?php esc_html_e( 'Unauthorized Device', 'cloaklink' ); ?></h1>
	<p class="cl-sub">
		<?php
		echo $enabled
			? esc_html__( 'This device is not registered for this console. Access is granted per network address, and this one is not on the list.', 'cloaklink' )
			: esc_html__( 'This console is switched off. No device can open it while it is off.', 'cloaklink' );
		?>
	</p>

	<div class="cl-denyip">
		<span><?php esc_html_e( 'Device address', 'cloaklink' ); ?></span>
		<code><?php echo esc_html( $ip ); ?></code>
	</div>

	<p class="cl-denied-next">
		<?php esc_html_e( 'To use this console from here, sign in to the main panel from a device that is already registered and add this address under Network access. Nothing on this page can do it for you.', 'cloaklink' ); ?>
	</p>

	<div class="cl-legend cl-legend--denied">
		<span class="cl-legend__l">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
			<?php esc_html_e( 'Only this address and the time were noted, so it can be registered', 'cloaklink' ); ?>
		</span>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to the site', 'cloaklink' ); ?></a>
	</div>
</main>

</body>
</html>
		<?php
	}

	/**
	 * The sign-in screen for the restricted console.
	 *
	 * @return void
	 */
	private function render_vault_signin() {
		$this->render();
	}

	/**
	 * Queue what the panel's scripts expect before the page is printed.
	 *
	 * The wp-admin screen enqueues these from a hook; here there is no such
	 * hook, so the same handles are registered and printed directly. Same
	 * files, same version, so the two addresses can never drift apart.
	 *
	 * @return void
	 */
	private function panel_assets() {
		wp_register_script( 'cloaklink-admin', CLOAKLINK_URL . 'assets/js/admin.js', array(), CLOAKLINK_VERSION, true );
		wp_enqueue_script( 'cloaklink-admin' );
		wp_localize_script( 'cloaklink-admin', 'CLOAKLINK', cloaklink()->admin->script_config_public() );

		// The readable address is /info-security-desk/<page>, where there is no
		// cl_page in the query at all. Reading only the legacy parameter meant
		// every per-page script was silently skipped on the address the panel
		// actually hands out — which is why the tracing map had no script
		// behind it. current_page() answers both shapes.
		$page = CloakLink_Admin::current_page();
		if ( 'map' === $page ) {
			wp_enqueue_script( 'cloaklink-map', CLOAKLINK_URL . 'assets/js/admin-map.js', array(), CLOAKLINK_VERSION, true );
		}
		// The tracing map is drawn only on Smart monitoring, and only when
		// the wall has nothing to show. It carries its own tiles and is
		// dependency-free, so a failure elsewhere on the page cannot take it
		// down with it.
		if ( 'support' === $page ) {
			wp_enqueue_script( 'cloaklink-trace', CLOAKLINK_URL . 'assets/js/admin-trace.js', array(), CLOAKLINK_VERSION, true );
		}
		wp_enqueue_style( 'cloaklink-tower', CLOAKLINK_URL . 'assets/css/tower.css', array(), CLOAKLINK_VERSION );
		wp_enqueue_script( 'cloaklink-tower', CLOAKLINK_URL . 'assets/js/admin-tower.js', array(), CLOAKLINK_VERSION, true );

		// The walkie-talkie used to load with the console here. It is no
		// longer printed anywhere, so nothing of it is loaded either.
	}

	/**
	 * Is the current request the panel sign-in path?
	 *
	 * @return bool
	 */
	public function is_panel_request() {
		if ( get_query_var( 'cloaklink_panel' ) ) {
			return true;
		}
		// Pretty permalinks off: /?cloaklink_panel=1.
		if ( isset( $_GET['cloaklink_panel'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return true;
		}
		// A stale rewrite table still leaves the path in the request, so the
		// address is recognised even before the rules are rebuilt.
		return isset( $this->own_segments()[1] );
	}

	/**
	 * Send a signed-in-user-less request for wp-admin here.
	 *
	 * Without this, /wp-admin shows the ordinary WordPress login and the private
	 * path is pointless. Requests that carry their own intention (a password
	 * reset, a sign-out, an AJAX call) are left alone so nothing breaks.
	 *
	 * @return void
	 */
	public function redirect_admin_to_panel() {
		if ( is_user_logged_in() ) {
			return;
		}
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}
		if ( isset( $_GET['action'] ) || isset( $_GET['loggedout'] ) || isset( $_GET['checkemail'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? (string) $_SERVER['SCRIPT_NAME'] : '';
		if ( false !== strpos( $script, 'admin-ajax.php' ) || false !== strpos( $script, 'admin-post.php' ) ) {
			return;
		}

		// Only the sign-in page is redirected. Everything else under wp-admin
		// reaches auth_redirect() on its own and is handled below.
		if ( false === strpos( $script, 'wp-login.php' ) ) {
			return;
		}

		// Only a real page request is redirected. A POST carries credentials and
		// has to reach wp-login.php itself.
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET';
		if ( 'GET' !== $method ) {
			return;
		}

		wp_safe_redirect( $this->url() );
		exit;
	}

	/**
	 * Take over a failed sign-in.
	 *
	 * On a wrong password WordPress does not redirect: it reprints its own form
	 * in place. That form is exactly what this plugin hides, so the failure is
	 * caught here and the visitor goes back to the private screen with the
	 * reason. Nothing has been output yet at this point, so a redirect is safe.
	 *
	 * @param string         $username Attempted login name.
	 * @param WP_Error|mixed $error    What went wrong, as core reports it.
	 * @return void
	 */
	public function catch_failed_login( $username = '', $error = null ) {
		if ( is_user_logged_in() ) {
			return;
		}

		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? (string) $_SERVER['SCRIPT_NAME'] : '';
		if ( false === strpos( $script, 'wp-login.php' ) ) {
			return;
		}

		// A rejected access code is not a rejected password.
		//
		// `wp_login_failed` fires for both, and this handler used to assume
		// every failure was a bad password and say so. So an operator who had
		// typed the right password and one digit of their code wrong was told
		// "That password is not correct" — the one message guaranteed to send
		// them off resetting a password that was never the problem. The error
		// the filter returned names the gate that actually refused, so it is
		// read here rather than guessed.
		$reason = '';
		if ( is_wp_error( $error ) ) {
			$reason = (string) $error->get_error_code();
		}
		if ( '' === $reason && isset( $_POST['cl_access_code'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			// The error did not arrive, so the gate has to be worked out.
			//
			// This panel's form always posts six code cells, empty or not,
			// so the presence of the field proves nothing. What does prove
			// something is whether the code has actually been filled in: a
			// typed code means the password was accepted and this is the
			// second gate failing, which is worth saying. Empty cells mean the
			// attempt stopped at the password, and calling that a bad code
			// would be a new way of being wrong — the exact mistake this
			// method was changed to stop making.
			$raw = wp_unslash( $_POST['cl_access_code'] ); // phpcs:ignore WordPress.Security.NonceVerification
			$digits = preg_replace( '/[^0-9A-Za-z]/', '', is_array( $raw ) ? implode( '', array_map( 'strval', $raw ) ) : (string) $raw );
			if ( '' !== $digits ) {
				$reason = 'cloaklink_bad_code';
			}
		}

		if ( 'cloaklink_bad_code' === $reason ) {
			wp_safe_redirect( add_query_arg( 'cl_signin', 'bad_code', $this->url() ) );
			exit;
		}
		if ( 'cloaklink_code_locked' === $reason ) {
			wp_safe_redirect( add_query_arg( 'cl_signin', 'code_locked', $this->url() ) );
			exit;
		}

		// Say which of the two usual mistakes it was, when that is knowable.
		$user = get_user_by( 'login', (string) $username );
		if ( ! $user ) {
			$user = get_user_by( 'email', (string) $username );
		}

		$code = $user ? 'incorrect_password' : 'invalid_username';
		// "error" is a reserved public query var: WordPress strips it before the
		// plugin ever sees the request, which silently lost the message. A
		// plugin-specific name cannot collide with anything in core.
		wp_safe_redirect( add_query_arg( 'cl_signin', $code, $this->url() ) );
		exit;
	}

	/**
	 * Point wp-admin's own sign-in redirect at the private screen.
	 *
	 * WordPress core sends a signed-out visitor to wp-login.php and then on to
	 * this private page, so the ordinary form is never shown. Filtering the URL
	 * is more reliable than inspecting the request, because it runs with the
	 * same information core itself used.
	 *
	 * @param string $location Redirect target.
	 * @return string
	 */
	public function filter_login_url( $location ) {
		$location = (string) $location;
		if ( false === strpos( $location, 'wp-login.php' ) ) {
			return $location;
		}
		// Leave anything with its own purpose alone: a password reset, a sign-out
		// notice, or a confirmation screen.
		if ( preg_match( '/[?&](action|loggedout|checkemail)=/', $location ) ) {
			return $location;
		}

		// A failed sign-in comes back here with reauth=1. It has to fall through
		// so the private screen can show the error, rather than dropping the
		// visitor onto the stock WordPress form.
		return $this->url();
	}

	/**
	 * Absolute URL of the sign-in screen.
	 *
	 * @return string
	 */
	public function url() {
		return home_url( '/' . $this->path() );
	}

	/**
	 * Print the sign-in page.
	 *
	 * @return void
	 */
	private function render() {
		$vars = array(
			'brand'     => cloaklink()->router->brand(),
			'action'    => esc_url( site_url( 'wp-login.php', 'login_post' ) ),
			'redirect'  => CloakLink_Admin::url( 'overview' ),
			'error'     => $this->current_error(),
			'notice'    => $this->current_notice(),
			'need_code' => $this->needs_code(),
			'home'      => home_url( '/' ),
			'panel'     => $this->url(),
		);

		$file = CLOAKLINK_DIR . 'views/public/login.php';
		if ( ! file_exists( $file ) ) {
			wp_safe_redirect( wp_login_url( CloakLink_Admin::url( 'overview' ) ) );
			exit;
		}

		$GLOBALS['cloaklink_view'] = $vars;
		include $file;
	}

	/**
	 * A neutral message: something that happened, not something that went wrong.
	 *
	 * @return string
	 */
	private function current_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['loggedout'] ) ) {
			return __( 'You have been signed out.', 'cloaklink' );
		}
		return '';
	}

	/**
	 * Does this panel ask for an access code as well as a password?
	 *
	 * The answer has to be "could any account here need one", not "is the
	 * site-wide fallback set". An operator given a code of their own was
	 * refused at the last gate — check_code() reads the account's code and
	 * only falls back to the site-wide one — while this screen decided from
	 * the fallback alone that no code was wanted, printed only a password
	 * field, and left that operator with a form that could never be filled
	 * in correctly. The field is shown when either source exists; the second
	 * step is still skipped by the screen's own script for an account that
	 * has no code, so nobody is asked for one that does not exist.
	 *
	 * @return bool
	 */
	public function needs_code() {
		if ( '' !== $this->code_for( null ) ) {
			return true;
		}

		// Any account holding a code of its own. This is one indexed meta
		// read, made once per sign-in screen, which is cheap enough to be
		// worth the certainty.
		$own = get_users(
			array(
				'meta_key'     => 'cloaklink_access_code', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_compare' => 'EXISTS',
				'number'       => 1,
				'fields'       => 'ID',
			)
		);

		return ! empty( $own );
	}

	/**
	 * The access code that belongs to one account.
	 *
	 * Each operator has their own: a code shared by everybody is one leaked
	 * code away from opening every session. The account's own record wins; a
	 * site-wide code is only the fallback for accounts that have never been
	 * given one, so an install that was set up before this change keeps
	 * working on the day it is updated.
	 *
	 * @param int|WP_User|null $user Account, or null for "is any code set".
	 * @return string A hash, or '' when there is none.
	 */
	public function code_for( $user = null ) {
		$own = '';
		if ( $user instanceof WP_User ) {
			$own = (string) get_user_meta( $user->ID, 'cloaklink_access_code', true );
		} elseif ( is_numeric( $user ) && (int) $user > 0 ) {
			$own = (string) get_user_meta( (int) $user, 'cloaklink_access_code', true );
		}

		if ( '' !== $own ) {
			return $own;
		}

		return (string) $this->settings->get( 'panel_access_code', '' );
	}

	/**
	 * Store an account's own code.
	 *
	 * @param int    $user_id Account.
	 * @param string $code    Six digits, already validated by the caller.
	 * @return void
	 */
	public static function set_user_code( $user_id, $code ) {
		$digits = preg_replace( '/\D/', '', (string) $code );
		if ( '' === $digits ) {
			delete_user_meta( (int) $user_id, 'cloaklink_access_code' );
			return;
		}
		update_user_meta( (int) $user_id, 'cloaklink_access_code', wp_hash_password( $digits ) );
	}

	/**
	 * Does this account's own code match what was typed?
	 *
	 * Deliberately checks the account's OWN code and not the fallback: this is
	 * used before replacing a code, where the fallback has no meaning — an
	 * account with no code of its own is allowed to set one without knowing
	 * anything.
	 *
	 * @param int    $user_id Account.
	 * @param string $code    What was typed.
	 * @return bool
	 */
	public static function verify_user_code( $user_id, $code ) {
		$stored = (string) get_user_meta( (int) $user_id, 'cloaklink_access_code', true );
		$digits = preg_replace( '/\D/', '', (string) $code );
		if ( '' === $stored || '' === $digits ) {
			return false;
		}
		return (bool) wp_check_password( $digits, $stored );
	}

	/**
	 * Does one account have a code of its own (as opposed to the fallback)?
	 *
	 * @param int $user_id Account.
	 * @return bool
	 */
	public static function user_has_code( $user_id ) {
		return '' !== (string) get_user_meta( (int) $user_id, 'cloaklink_access_code', true );
	}

	/**
	 * Refuse a sign-in that has the right password but the wrong code.
	 *
	 * Runs after WordPress has authenticated, which is the only point where the
	 * password is known to be correct: a wrong code is then never reported for
	 * a username that does not exist, so the screen leaks nothing.
	 *
	 * @param WP_User|WP_Error $user     Authenticated user or error.
	 * @param string           $password Password supplied (unused: the code is
	 *                                   read from the request, and this filter
	 *                                   runs after the password was accepted).
	 * @return WP_User|WP_Error
	 */
	public function check_code( $user, $password = '' ) {
		if ( ! ( $user instanceof WP_User ) ) {
			return $user;
		}
		$stored = $this->code_for( $user );
		if ( '' === $stored ) {
			return $user;
		}

		// A recorded refusal has to be able to stop the next attempt, or the
		// code is only as strong as the number of guesses someone is willing to
		// make. Six wrong codes from one address in ten minutes locks that
		// address out of this account until the window passes, whether the next
		// code is right or not.
		if ( $this->code_is_locked( $user ) ) {
			return new WP_Error( 'cloaklink_code_locked', __( 'Too many attempts. Try again in a few minutes.', 'cloaklink' ) );
		}

		// Six separate cells post six values under one name, so the field
		// arrives as an array. Joined here before the digits are stripped, the
		// screen can be laid out however it likes without the handler caring.
		$raw = isset( $_POST['cl_access_code'] ) ? wp_unslash( $_POST['cl_access_code'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( is_array( $raw ) ) {
			$raw = implode( '', array_map( 'strval', $raw ) );
		}
		$given = preg_replace( '/[^0-9A-Za-z]/', '', (string) $raw );

		// The account's own code is the one that counts. A site-wide fallback
		// is accepted only for an account that has never been given its own,
		// so setting a code for one operator cannot quietly leave another
		// with none.
		if ( wp_check_password( $given, $stored, strlen( $given ) ) ) {
			return $user;
		}

		// The code is the last gate, so a failure here ends the attempt rather
		// than returning the user to a half-signed-in state.
		$this->log_refusal( $user );
		return new WP_Error( 'cloaklink_bad_code', __( 'That access code was not accepted.', 'cloaklink' ) );
	}

	/**
	 * Has this address used up its attempts at this account's code?
	 *
	 * @param WP_User $user The user whose password was correct.
	 * @return bool
	 */
	private function code_is_locked( $user ) {
		$key = 'cl_codefail_' . md5( (string) $user->ID . '|' . (string) CloakLink_Geo::ip() );
		return (int) get_transient( $key ) >= 6;
	}

	/**
	 * Record a refused code, so a repeated attempt is visible in the panel.
	 *
	 * @param WP_User $user The user whose password was correct.
	 * @return void
	 */
	private function log_refusal( $user ) {
		if ( ! class_exists( 'CloakLink_Logger' ) || ! function_exists( 'cloaklink' ) ) {
			return;
		}
		$key = 'cl_codefail_' . md5( (string) $user->ID . '|' . (string) CloakLink_Geo::ip() );
		set_transient( $key, (int) get_transient( $key ) + 1, 10 * MINUTE_IN_SECONDS );
	}

	/**
	 * Translate WordPress's login error codes into plain language.
	 *
	 * The codes arrive in the query string from wp-login.php after a failed
	 * attempt, so the same screen can explain what happened.
	 *
	 * @return string
	 */
	private function current_error() {
		// phpcs:disable WordPress.Security.NonceVerification
		$code = isset( $_GET['cl_signin'] ) ? sanitize_key( wp_unslash( $_GET['cl_signin'] ) ) : '';
		if ( '' === $code && isset( $_GET['reauth'] ) ) {
			// WordPress collapses several failures into reauth=1 with no detail.
			return __( 'Those details were not accepted. Check your username and password, then try again.', 'cloaklink' );
		}
		if ( '' === $code ) {
			return '';
		}

		$map = array(
			'empty_username' => __( 'Enter your username or email address.', 'cloaklink' ),
			'empty_password' => __( 'Enter your password.', 'cloaklink' ),
			'invalid_username' => __( 'That username is not registered on this site.', 'cloaklink' ),
			'invalid_email'  => __( 'No account uses that email address.', 'cloaklink' ),
			'incorrect_password' => __( 'That password is not correct.', 'cloaklink' ),
			'expired_session' => __( 'Your session expired. Please sign in again.', 'cloaklink' ),
			// The password was right; the code was not. Saying "that password
			// is not correct" here sent people to reset a password that had
			// worked perfectly, and left them no closer to the real problem.
			'bad_code'       => __( 'Your password was accepted, but that access code was not. Check the six digits and try again.', 'cloaklink' ),
			'code_locked'    => __( 'Too many wrong access codes. Wait a few minutes, then try again.', 'cloaklink' ),
		);
		// phpcs:enable WordPress.Security.NonceVerification

		return isset( $map[ $code ] ) ? $map[ $code ] : __( 'Those details were not accepted. Please try again.', 'cloaklink' );
	}
}
