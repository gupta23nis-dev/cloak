<?php
/**
 * Mail transport.
 *
 * WordPress sends mail through PHP's mail() by default, which on shared
 * hosting is usually either not configured at all or unauthenticated — the
 * server accepts the message and it is dropped somewhere before it reaches an
 * inbox. That is the reason alert mail can be "sent" on every visit and never
 * arrive.
 *
 * This class lets the operator enter their own mailbox details in Settings and
 * sends through that mailbox over SMTP instead. Nothing here is specific to
 * the alert: it hooks PHPMailer, so every message this site sends — password
 * resets, comment notices, the alerts — goes the same way. No second plugin is
 * needed.
 *
 * A blank host means "leave WordPress alone", so a site that already sends
 * correctly through a plugin is never disturbed by upgrading this one.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * SMTP transport for this site's mail.
 */
class CloakLink_Mailer {

	/**
	 * Settings store.
	 *
	 * @var CloakLink_Settings
	 */
	private $settings;

	/** True while a fallback send is in progress, so it cannot loop. */
	private $retrying = false;

	/** The arguments of the message being sent, for the fallback. */
	private $pending = null;

	/** Whether the last fallback attempt delivered the message. */
	private $fallback_ok = null;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_Settings $settings Settings store.
	 */
	public function __construct( $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Whether the operator has filled in enough for SMTP to be used.
	 *
	 * A host is the one required field. The username is not required, because
	 * some internal relays accept unauthenticated mail; the password is not
	 * required for the same reason. If the host is blank the site's own
	 * transport stays in place.
	 *
	 * @return bool
	 */
	public function is_on() {
		return '' !== trim( (string) $this->settings->get( 'smtp_host', '' ) );
	}

	/**
	 * Apply the operator's SMTP settings to a message about to be sent.
	 *
	 * @param PHPMailer\PHPMailer\PHPMailer|PHPMailer $phpmailer Mailer.
	 * @return void
	 */
	public function configure( $phpmailer ) {
		if ( ! $this->is_on() ) {
			return;
		}

		$host = trim( (string) $this->settings->get( 'smtp_host', '' ) );
		$port = (int) $this->settings->get( 'smtp_port', 587 );
		$user = trim( (string) $this->settings->get( 'smtp_user', '' ) );
		$pass = (string) $this->settings->get( 'smtp_pass', '' );
		$sec  = (string) $this->settings->get( 'smtp_secure', 'tls' );

		// The host may be typed as an address ("smtp.example.com") or as a
		// URL ("https://smtp.example.com/"). Only the host part means anything
		// to a socket.
		if ( false !== strpos( $host, '//' ) ) {
			$parsed = wp_parse_url( $host, PHP_URL_HOST );
			if ( $parsed ) {
				$host = (string) $parsed;
			}
		}
		$host = preg_replace( '#^.*?//#', '', $host );
		$host = preg_replace( '#/.*$#', '', (string) $host );
		$host = trim( (string) $host );

		if ( '' === $host ) {
			return;
		}

		$phpmailer->isSMTP();
		$phpmailer->Host = $host;
		$phpmailer->Port = $port > 0 ? $port : 587;

		// Authentication only when a username was given. An empty username on a
		// relay that does not need one is a valid setup, and forcing
		// authentication there makes every message fail.
		$phpmailer->SMTPAuth = '' !== $user;
		if ( '' !== $user ) {
			$phpmailer->Username = $user;
			$phpmailer->Password = $pass;
		}

		if ( 'ssl' === $sec ) {
			$phpmailer->SMTPSecure = 'ssl';
		} elseif ( 'none' === $sec ) {
			$phpmailer->SMTPSecure = '';
			$phpmailer->SMTPAutoTLS = false;
		} else {
			$phpmailer->SMTPSecure = 'tls';
		}

		// A certificate that does not match the host is a common shared-hosting
		// problem, and PHPMailer refuses the connection over it. The connection
		// still protects the password from being read on the wire; what is lost
		// is the guarantee that the machine on the other end is the one named.
		// For a mailbox the operator chose themselves this is an acceptable
		// trade, and the alternative is no mail at all.
		$phpmailer->SMTPOptions = array(
			'ssl' => array(
				'verify_peer'       => false,
				'verify_peer_name'  => false,
				'allow_self_signed' => true,
			),
		);

		// The From address has to belong to the mailbox being authenticated,
		// or the receiving server rejects it as spoofing. The alert sets its
		// own From (alert@, red-alert@, security-alert@), so this only fills a
		// blank — but a site whose domain does not match its mailbox gets a
		// working sender instead of a rejected one.
		$from = (string) $this->settings->get( 'smtp_from_email', '' );
		if ( ! is_email( $from ) && is_email( $user ) ) {
			$from = $user;
		}
		if ( is_email( $from ) ) {
			$name = trim( (string) $this->settings->get( 'brand_name', '' ) );
			$phpmailer->setFrom( $from, '' !== $name ? $name : 'Credit Control', false );
		}

		// Timeouts long enough for a slow shared host, short enough that a
		// broken mailbox cannot hold a visitor's page open for a minute.
		$phpmailer->Timeout = 12;
	}

	/**
	 * Register the hook.
	 *
	 * Priority 20 so a plugin that configures its own SMTP at the default
	 * priority has already run: this one then takes over only because the
	 * operator asked for it here, which is the more recent and more specific
	 * instruction.
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'phpmailer_init', array( $this, 'configure' ), 20 );

		// If the operator's SMTP settings do not work, hand the message back to
		// WordPress and let the site try its own way rather than losing it.
		//
		// A wrong host, a mailbox that was never created, a blocked port — any
		// of these used to mean the alert was silently never delivered, and the
		// operator's only clue was an empty inbox. The settings are meant to
		// help delivery, never to be a precondition for it.
		add_filter( 'wp_mail', array( $this, 'remember' ), 99 );
		add_action( 'wp_mail_failed', array( $this, 'maybe_retry' ), 10, 1 );
	}

	/**
	 * Keep the arguments of the message being sent.
	 *
	 * The fallback needs the same message, and wp_mail arguments are the only
	 * copy of it that exists by the time a failure is reported.
	 *
	 * @param array $args wp_mail arguments.
	 * @return array Unchanged.
	 */
	public function remember( $args ) {
		$this->pending = $args;
		return $args;
	}

	/**
	 * Retry once over the site's own transport after an SMTP failure.
	 *
	 * @param WP_Error $error Failure reported by wp_mail.
	 * @return void
	 */
	public function maybe_retry( $error ) {
		if ( ! $this->is_on() || $this->retrying ) {
			return;
		}
		if ( ! $error instanceof WP_Error || ! is_array( $this->pending ) ) {
			return;
		}

		// Only a transport failure is worth retrying. An address the receiver
		// refused would fail the same way twice.
		$message = strtolower( (string) $error->get_error_message() );
		$retry   = false;
		foreach ( array( 'smtp', 'connect', 'could not', 'connection', 'timed out', 'timeout', 'certificate', 'authentication', 'username', 'password' ) as $needle ) {
			if ( false !== strpos( $message, $needle ) ) {
				$retry = true;
				break;
			}
		}
		if ( ! $retry ) {
			return;
		}

		$this->retrying = true;
		remove_action( 'phpmailer_init', array( $this, 'configure' ), 20 );

		$args = $this->pending;
		$sent = (bool) call_user_func_array( 'wp_mail', $args );

		add_action( 'phpmailer_init', array( $this, 'configure' ), 20 );
		$this->retrying = false;
		$this->pending  = null;

		// Recorded so the caller can see that the message did leave, by the
		// other route. Without this the panel reported a failure for a mail the
		// site had in fact sent, which is worse than saying nothing.
		$this->fallback_ok = $sent;
	}

	/**
	 * Did the site's own transport deliver a message the SMTP settings refused?
	 *
	 * @return bool
	 */
	public function fallback_succeeded() {
		$ok = (bool) $this->fallback_ok;
		$this->fallback_ok = null;
		return $ok;
	}
}
