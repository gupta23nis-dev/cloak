<?php
/**
 * Minimal, dependency-free PDF writer.
 *
 * Produces a valid PDF 1.4 document with the standard Helvetica faces,
 * automatic word wrapping, multi-page tables and a repeating header row.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tiny PDF builder.
 */
class CloakLink_PDF {

	/** Page width in points (A4 landscape). */
	const W = 842;

	/** Page height in points. */
	const H = 595;

	/** Left/right margin. */
	const M = 36;

	/** @var string[] Finished page content streams. */
	private $pages = array();

	/** @var string Current page stream. */
	private $buf = '';

	/** @var float Current y cursor. */
	private $y = 0;

	/** @var array Header definition. */
	private $head = array();

	/** @var array Column widths. */
	private $widths = array();

	/** @var int Header font size. */
	private $font_size = 9;

	/** @var bool Whether the column head has been drawn on this page. */
	private $head_drawn = false;

	/** @var int Maximum wrapped lines per cell before truncation. */
	private $max_lines = 3;

	/**
	 * Constructor: start the first page.
	 *
	 * @param array $head   Column labels.
	 * @param array $widths Column widths in points.
	 * @param float $y      Start y.
	 */
	public function __construct( $head, $widths, $y = 0 ) {
		$this->head   = array_values( $head );
		$this->widths = array_values( $widths );
		$this->y      = $y > 0 ? $y : ( self::H - 110 );
	}

	/**
	 * Start a fresh page, optionally with the column header.
	 *
	 * @param bool $with_head Print the table head.
	 * @return void
	 */
	public function new_page( $with_head = true ) {
		if ( '' !== $this->buf ) {
			$this->pages[] = $this->buf;
		}
		$this->buf        = '';
		$this->y          = self::H - 56;
		$this->head_drawn = false;
		unset( $with_head );
	}

	/**
	 * Write a text line.
	 *
	 * @param float  $x    X position.
	 * @param float  $y    Y position.
	 * @param float  $size Font size.
	 * @param string $text Text.
	 * @param string $hex  Hex colour.
	 * @param bool   $bold Bold face.
	 * @return void
	 */
	public function text( $x, $y, $size, $text, $hex = '1A2236', $bold = false ) {
		$text = $this->clean( $text );
		if ( '' === $text ) {
			return;
		}
		$font = $bold ? '/F2' : '/F1';
		$this->buf .= sprintf(
			"BT %s %.2F Tf %s rg %.2F %.2F Td (%s) Tj ET\n",
			$font,
			$size,
			$this->rgb( $hex ),
			$x,
			$y,
			$this->escape( $text )
		);
	}

	/**
	 * Draw a filled rectangle.
	 *
	 * @param float $x X.
	 * @param float $y Y.
	 * @param float $w Width.
	 * @param float $h Height.
	 * @param string $hex Colour.
	 * @return void
	 */
	public function rect( $x, $y, $w, $h, $hex = 'F1EEE7' ) {
		$this->buf .= sprintf(
			"%s rg %.2F %.2F %.2F %.2F re f\n",
			$this->rgb( $hex ),
			$x,
			$y,
			$w,
			$h
		);
	}

	/**
	 * Draw a horizontal rule.
	 *
	 * @param float  $x X.
	 * @param float  $y Y.
	 * @param float  $w Width.
	 * @param string $hex Colour.
	 * @return void
	 */
	public function line( $x, $y, $w, $hex = 'D8D2C4' ) {
		$this->buf .= sprintf(
			"%s RG 0.6 w %.2F %.2F m %.2F %.2F l S\n",
			$this->rgb( $hex ),
			$x,
			$y,
			$x + $w,
			$y
		);
	}

	/**
	 * Compute approximate text width for Helvetica.
	 *
	 * @param string $text Text.
	 * @param float  $size Font size.
	 * @return float
	 */
	public function width( $text, $size ) {
		$len = strlen( $this->clean( $text ) );
		return $len * $size * 0.5;
	}

	/**
	 * Shorten text to fit a width, adding an ellipsis.
	 *
	 * @param string $text  Text.
	 * @param float  $width Available width in points.
	 * @param float  $size  Font size.
	 * @return string
	 */
	public function clip( $text, $width, $size ) {
		$text = $this->clean( $text );
		$max  = max( 3, (int) floor( $width / max( 1, $size * 0.5 ) ) );
		if ( strlen( $text ) <= $max ) {
			return $text;
		}
		return rtrim( substr( $text, 0, $max - 3 ) ) . '...';
	}

	/**
	 * Wrap text to a width.
	 *
	 * @param string $text  Text.
	 * @param float  $width Points.
	 * @param float  $size  Font size.
	 * @return string[]
	 */
	public function wrap( $text, $width, $size ) {
		$text = $this->clean( $text );
		if ( '' === $text ) {
			return array();
		}
		$max   = max( 4, (int) floor( $width / max( 1, $size * 0.5 ) ) );
		$words = preg_split( '/\s+/', $text );
		$lines = array();
		$line  = '';
		foreach ( (array) $words as $word ) {
			while ( strlen( $word ) > $max ) {
				if ( '' !== $line ) {
					$lines[] = $line;
					$line    = '';
				}
				$lines[] = substr( $word, 0, $max );
				$word    = substr( $word, $max );
			}
			$candidate = '' === $line ? $word : $line . ' ' . $word;
			if ( strlen( $candidate ) > $max ) {
				$lines[] = $line;
				$line    = $word;
			} else {
				$line = $candidate;
			}
		}
		if ( '' !== $line ) {
			$lines[] = $line;
		}
		return $lines;
	}

	/**
	 * Banner at the top of the first page.
	 *
	 * @param string $title    Title.
	 * @param string $subtitle Subtitle.
	 * @param string $meta     Right-aligned meta.
	 * @return void
	 */
	public function banner( $title, $subtitle = '', $meta = '' ) {
		$this->rect( 0, self::H - 74, self::W, 74, '0D1B3E' );
		$this->rect( 0, self::H - 77, self::W, 3, 'C8A34A' );
		$this->text( self::M, self::H - 34, 17, $title, 'FFFFFF', true );
		if ( $subtitle ) {
			$this->text( self::M, self::H - 52, 9, $subtitle, 'C9D2E4' );
		}
		if ( $meta ) {
			$w = $this->width( $meta, 9 );
			$this->text( self::W - self::M - $w, self::H - 34, 9, $meta, 'C8A34A' );
		}
	}

	/**
	 * Draw the table header row at the current cursor.
	 *
	 * @return void
	 */
	public function table_head() {
		$x = self::M;
		$h = 17;
		$this->rect( self::M, $this->y + 6 - $h, self::W - ( 2 * self::M ), $h, 'EEEAE0' );
		foreach ( $this->head as $i => $label ) {
			$w = isset( $this->widths[ $i ] ) ? $this->widths[ $i ] : 80;
			$text = $this->clip( strtoupper( (string) $label ), $w - 8, $this->font_size - 1 );
			$this->text( $x + 4, $this->y - 6, $this->font_size - 1, $text, '4A5065', true );
			$x += $w;
		}
		$this->line( self::M, $this->y + 6 - $h, self::W - ( 2 * self::M ), 'CFC7B4' );
		$this->y         -= $h + 2;
		$this->head_drawn = true;
	}

	/**
	 * Draw the column head if this page has none yet.
	 *
	 * @return void
	 */
	private function ensure_head() {
		if ( ! $this->head ) {
			return;
		}
		if ( ! $this->head_drawn ) {
			$this->table_head();
		}
	}

	/**
	 * Append one table row.
	 *
	 * @param array $cells Cell strings.
	 * @param bool  $zebra Shade the row.
	 * @return void
	 */
	public function row( $cells, $zebra = false ) {
		$size     = $this->font_size;
		$line_h   = $size + 3;
		$wrapped  = array();
		$maxlines = 1;

		foreach ( $this->widths as $i => $w ) {
			$cell          = isset( $cells[ $i ] ) ? (string) $cells[ $i ] : '';
			$lines         = $this->wrap( $cell, $w - 8, $size );

			// Cap the height so one long ISP name cannot blow up the whole row.
			if ( count( $lines ) > $this->max_lines ) {
				$lines                          = array_slice( $lines, 0, $this->max_lines );
				$last                           = count( $lines ) - 1;
				$lines[ $last ]                 = rtrim( $lines[ $last ], '.' ) . '...';
			}

			$wrapped[ $i ] = $lines;
			$maxlines      = max( $maxlines, count( $lines ) );
		}

		$row_h = ( $maxlines * $line_h ) + 8;

		if ( $this->y - $row_h < 46 ) {
			$this->new_page( true );
		}
		$this->ensure_head();

		$top = $this->y + 6;

		if ( $zebra ) {
			$this->rect( self::M, $top - $row_h, self::W - ( 2 * self::M ), $row_h, 'F7F4EC' );
		}

		$x = self::M;
		foreach ( $this->widths as $i => $w ) {
			$ty = $top - 5 - $size;
			foreach ( $wrapped[ $i ] as $line ) {
				$this->text( $x + 4, $ty, $size, $line, '2A3148' );
				$ty -= $line_h;
			}
			$x += $w;
		}

		$this->line( self::M, $top - $row_h, self::W - ( 2 * self::M ) );
		$this->y = $top - $row_h;
	}

	/**
	 * Paragraph block outside the table grid.
	 *
	 * @param string $label Label.
	 * @param string $value Value.
	 * @return void
	 */
	public function field( $label, $value ) {
		$size = 9;
		$lines = $this->wrap( $value, self::W - ( 2 * self::M ), $size );
		if ( $this->y - ( count( $lines ) * 12 ) < 50 ) {
			$this->new_page( true );
		}
		$this->text( self::M, $this->y, $size - 1, strtoupper( $label ), '8A8F9E', true );
		$this->y -= 13;
		foreach ( $lines as $line ) {
			$this->text( self::M, $this->y, $size, $line, '2A3148' );
			$this->y -= 12;
		}
		$this->y -= 6;
	}

	/**
	 * KPI band.
	 *
	 * @param array $items label => value.
	 * @return void
	 */
	public function kpis( $items ) {
		$count = max( 1, count( $items ) );
		$gap   = 8;
		$bw    = ( self::W - ( 2 * self::M ) - ( $gap * ( $count - 1 ) ) ) / $count;
		$h     = 46;

		if ( $this->y - $h < 60 ) {
			$this->new_page( false );
		}

		$x = self::M;
		foreach ( $items as $label => $value ) {
			$this->rect( $x, $this->y - $h + 12, $bw, $h, 'F4F1E9' );
			$this->text( $x + 8, $this->y - 4, 7.5, strtoupper( (string) $label ), '8A8F9E', true );
			$this->text( $x + 8, $this->y - 24, 15, (string) $value, '0D1B3E', true );
			$x += $bw + $gap;
		}
		$this->y -= $h + 12;
	}

	/**
	 * Render and return the PDF bytes.
	 *
	 * @param string $title   Document title.
	 * @param string $footer  Footer line.
	 * @return string
	 */
	public function output( $title, $footer = '' ) {
		if ( '' !== $this->buf ) {
			$this->pages[] = $this->buf;
			$this->buf     = '';
		}
		if ( ! $this->pages ) {
			$this->pages[] = '';
		}

		$n    = count( $this->pages );
		$objs = array();

		// 1: catalog, 2: pages, 3: F1, 4: F2.
		$kids = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$kids[] = ( 5 + ( $i * 2 ) ) . ' 0 R';
		}
		$objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
		$objs[2] = "<< /Type /Pages /Count $n /Kids [" . implode( ' ', $kids ) . '] >>';
		$objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
		$objs[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";

		foreach ( $this->pages as $i => $content ) {
			$page_obj = 5 + ( $i * 2 );
			$cont_obj = $page_obj + 1;

			$stream  = '';
			$stream .= 'q ' . self::W . ' 0 0 ' . self::H . ' 0 0 cm Q' . "\n";
			$stream .= $content;
			$stream .= $this->footer_stream( $i + 1, $n, $footer );

			$objs[ $page_obj ] = sprintf(
				'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d %d] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>',
				self::W,
				self::H,
				$cont_obj
			);
			$objs[ $cont_obj ] = '<< /Length ' . strlen( $stream ) . " >>\nstream\n" . $stream . 'endstream';
		}

		$pdf     = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
		$offsets = array();
		$max     = max( array_keys( $objs ) );

		for ( $i = 1; $i <= $max; $i++ ) {
			if ( ! isset( $objs[ $i ] ) ) {
				$objs[ $i ] = '<< >>';
			}
			$offsets[ $i ] = strlen( $pdf );
			$pdf          .= $i . " 0 obj\n" . $objs[ $i ] . "\nendobj\n";
		}

		$xref      = strlen( $pdf );
		$count     = $max + 1;
		$pdf      .= "xref\n0 $count\n0000000000 65535 f \n";
		for ( $i = 1; $i <= $max; $i++ ) {
			$pdf .= sprintf( "%010d 00000 n \n", $offsets[ $i ] );
		}

		$pdf .= "trailer\n<< /Size $count /Root 1 0 R /Info << /Title (" . $this->escape( $title ) . ') /Producer (CloakLink) /Creator (CloakLink) >> >>';
		$pdf .= "\nstartxref\n$xref\n%%EOF";

		return $pdf;
	}

	/**
	 * Footer drawing commands for a page.
	 *
	 * @param int    $num    Page number.
	 * @param int    $total  Total pages.
	 * @param string $footer Footer text.
	 * @return string
	 */
	private function footer_stream( $num, $total, $footer ) {
		$left = $this->escape( $this->clean( $footer ) );
		$out  = '';
		$out .= "0.55 0.55 0.6 RG 0.5 w\n" . self::M . " 30 m " . ( self::W - self::M ) . " 30 l S\n";
		if ( $left ) {
			$out .= "BT /F1 7.5 Tf 0.45 0.45 0.5 rg " . self::M . " 19 Td (" . $left . ") Tj ET\n";
		}
		$label = 'Page ' . $num . ' of ' . $total;
		$w     = strlen( $label ) * 7.5 * 0.5;
		$out  .= "BT /F1 7.5 Tf 0.45 0.45 0.5 rg " . ( self::W - self::M - $w ) . " 19 Td (" . $this->escape( $label ) . ") Tj ET\n";
		return $out;
	}

	/**
	 * Convert a hex colour to PDF rgb operator operands.
	 *
	 * @param string $hex Hex colour.
	 * @return string
	 */
	private function rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			$hex = '000000';
		}
		return sprintf(
			'%.3F %.3F %.3F',
			hexdec( substr( $hex, 0, 2 ) ) / 255,
			hexdec( substr( $hex, 2, 2 ) ) / 255,
			hexdec( substr( $hex, 4, 2 ) ) / 255
		);
	}

	/**
	 * Reduce text to WinAnsi-safe ASCII.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private function clean( $text ) {
		$text = (string) $text;

		$text = strtr(
			$text,
			array(
				'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A',
				'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
				'Ç' => 'C', 'ç' => 'c', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
				'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'Ì' => 'I', 'Í' => 'I',
				'Î' => 'I', 'Ï' => 'I', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
				'Ñ' => 'N', 'ñ' => 'n', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O',
				'Ö' => 'O', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
				'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'ù' => 'u', 'ú' => 'u',
				'û' => 'u', 'ü' => 'u', 'Ý' => 'Y', 'ý' => 'y', 'ÿ' => 'y',
				'–' => '-', '—' => '-', '‘' => "'", '’' => "'", '“' => '"', '”' => '"',
				'…' => '...', '·' => '-', '±' => '+/-', '°' => ' deg', '₹' => 'Rs.',
				"\xC2\xA0" => ' ',
			)
		);

		// Drop anything else the standard faces cannot draw.
		$text = preg_replace( '/[^\x20-\x7E]/', ' ', $text );
		$text = preg_replace( '/\s+/', ' ', $text );
		return trim( (string) $text );
	}

	/**
	 * Escape PDF string characters.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private function escape( $text ) {
		return str_replace( array( '\\', '(', ')', "\r", "\n" ), array( '\\\\', '\(', '\)', ' ', ' ' ), (string) $text );
	}
}
