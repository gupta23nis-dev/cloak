<?php
/**
 * Public routing for /{base}/{slug}.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles the public short links.
 */
class CloakLink_Router {

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/** @var CloakLink_Links */
	private $links;

	/** @var CloakLink_Logger */
	private $logger;

	/** @var string Slug currently being served. */
	private $slug = '';

	/** @var string Step read from the path when the rewrite table is stale. */
	private $path_step = '';

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings.
	 * @param CloakLink_Links    $links    Link model.
	 */
	public function __construct( $db, $settings, $links ) {
		$this->db       = $db;
		$this->settings = $settings;
		$this->links    = $links;
		$this->logger   = new CloakLink_Logger( $db, $settings );
	}

	/**
	 * Rewrite rules for both the holder page query var and the bare base path.
	 *
	 * @return void
	 */
	public function register_rewrites() {
		$base = trim( (string) $this->settings->get( 'base_path' ), '/' );
		if ( '' === $base ) {
			$base = 'go';
		}

		// A slug may contain slashes: a reel's address carries the post's own
		// path ("www.instagram.com/reel/<code>"), and a document's printed
		// address may carry its extension. Every rule therefore accepts "/" in
		// the slug — which means the bare rule would swallow "<slug>/l/legal"
		// whole and 404 a link that exists. WordPress keeps rules added "top"
		// in the order they were added and matches them in that order, so the
		// step rules are added BEFORE the bare rule and win over it.
		$slug_rx = '([A-Za-z0-9][A-Za-z0-9._\\-/?=&]{1,180}[A-Za-z0-9])';

		add_rewrite_rule(
			preg_quote( $base, '#' ) . '/' . $slug_rx . '/l/([a-z]+)/?$',
			'index.php?cloaklink_slug=$matches[1]&cloaklink_step=$matches[2]',
			'top'
		);
		add_rewrite_rule(
			preg_quote( $base, '#' ) . '/' . $slug_rx . '/?$',
			'index.php?cloaklink_slug=$matches[1]',
			'top'
		);
	}

	/**
	 * Register the query vars.
	 *
	 * @param array $vars Public query vars.
	 * @return array
	 */
	public static function query_vars( $vars ) {
		$vars[] = 'cloaklink_slug';
		$vars[] = 'cloaklink_step';
		$vars[] = 'cloaklink_u';
		// The two arguments the query-form address carries, so a link printed
		// on a host without clean paths is served exactly as the clean one is.
		$vars[] = 'cloaklink_ext';
		$vars[] = 'cloaklink_doc';
		return $vars;
	}

	/**
	 * Is the current request one of ours?
	 *
	 * @return string Slug or empty string.
	 */
	private function current_slug() {
		$slug = get_query_var( 'cloaklink_slug' );
		if ( $slug ) {
			return self::clean_slug( $slug );
		}
		// Pretty permalinks off, or a host that does not forward clean paths:
		// /?cloaklink_slug=abc. That form is the one address every server can
		// answer, so it is the one printed when the pretty form cannot be
		// reached — and it carries the printed slug, whose document form
		// ("….legal-Notice…") is folded back to the stored one at lookup.
		if ( isset( $_GET['cloaklink_slug'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return self::clean_slug( wp_unslash( $_GET['cloaklink_slug'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		return '';
	}

	/**
	 * Normalise a slug from the address bar.
	 *
	 * The same rule the link builder uses, so an address that was printed can
	 * be looked up again. Title-casing is not applied: the slug is compared
	 * byte for byte against what is stored.
	 *
	 * @param string $slug Raw slug.
	 * @return string
	 */
	private static function clean_slug( $slug ) {
		$slug = rawurldecode( (string) $slug );
		// Underscores are part of a name on a file address: GAJENDRA_S_N.
		// A slash is part of a reel's address ("instagram.com/reel/<code>"),
		// and stripping it would leave a value no stored slug could equal.
		$slug = preg_replace( '#[^A-Za-z0-9.\-_/]#', '', $slug );
		return trim( $slug, '.-_/' );
	}

	/**
	 * Dispatch the request.
	 *
	 * @return void
	 */
	public function handle_request() {
		$this->slug = $this->current_slug();

		if ( '' === $this->slug ) {
			// The rewrite table is a cache of routes written into the database.
			// After an update copied in by FTP, a restored database, or with
			// permalinks set to Plain, it can be out of date — and then a link
			// that was just created, and whose row is right there, still falls
			// through to the theme's 404 because WordPress never learned the
			// route. The stored link is the authority, so read the path here
			// and serve it. Nothing is served unless a real row matches.
			$path_slug = $this->slug_from_path();
			if ( '' !== $path_slug ) {
				$this->slug = $path_slug;
				$this->serve( $path_slug );
				exit;
			}

			// The site is hidden for everyone now, so every address that is not
			// a shared link is also kept out of any index that saw it earlier.
			if ( ! $this->request_wants_asset() ) {
				header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
			}
			$this->maybe_lockdown();
			return;
		}

		$this->serve( $this->slug );
		exit;
	}

	/**
	 * The site wears no public face.
	 *
	 * Everything on the public side answers 404 except a shared link the
	 * plugin itself issues. This is not a setting and not a role: the domain
	 * is a delivery surface, and a blog, a search result, an author archive,
	 * a feed or a theme footer is a page this install has no business
	 * publishing. A visitor who types the domain, or anything they guess at,
	 * gets the same blank 404 whether or not they are signed in — so nothing
	 * on the domain ever confirms what it is running.
	 *
	 * Three things stay reachable, because without them the install could not
	 * be run or signed in to: wp-admin, the sign-in scripts, and static files
	 * the pages themselves load.
	 *
	 * @return void
	 */
	private function maybe_lockdown() {
		// The address people try first, and the one a search engine indexes.
		if ( $this->is_site_root() && ! $this->request_wants_asset() ) {
			$this->render_404();
		}

		// The holder page and the bare link base path are not links either.
		if ( $this->is_holder_page() || $this->is_bare_base_path() ) {
			$this->render_404();
		}

		// A permalink, an archive, a search result, a feed and the sitemap all
		// reach the same content, and a sitemap also publishes the author slug,
		// which is the login name. Checked before the asset rule: the sitemap
		// ends in .xml and would otherwise be waved through as a static file.
		if ( $this->request_wants_feed() ) {
			$this->render_404();
		}

		// wp-admin, the sign-in scripts and static files have to work, or
		// nobody could administer this install or load one of its pages.
		if ( is_admin() || $this->is_login_request() || $this->request_wants_asset() ) {
			return;
		}

		// Everything else. Naming the conditions to hide is less safe than
		// saying what may be shown: a theme, a plugin or a new WordPress
		// feature can invent a page type nobody listed, and a list of names
		// would let it through. The only things that survive are the link
		// routes, which have already returned by the time this runs.
		$this->render_404();
	}

	/**
	 * Refuse the entry points that answer before template_redirect.
	 *
	 * xmlrpc.php and wp-trackback.php bootstrap WordPress and reply inside the
	 * bootstrap, so the router never sees them. Left alone, both let anyone ask
	 * a site what it is running and, with xmlrpc, try passwords. They are
	 * refused here with the same 404 every other hidden address gets.
	 *
	 * @return void
	 */
	public function block_script_requests() {
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( (string) $_SERVER['SCRIPT_NAME'] ) : '';
		if ( ! in_array( $script, array( 'xmlrpc.php', 'wp-trackback.php' ), true ) ) {
			return;
		}

		nocache_headers();
		status_header( 404 );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo 'Not Found';
		exit;
	}

	/**
	 * Is this request part of signing in?
	 *
	 * wp-login.php, its POST, the password reset, and the private panel path
	 * all have to work while the public site is blanked out.
	 *
	 * @return bool
	 */
	private function is_login_request() {
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( (string) $_SERVER['SCRIPT_NAME'] ) : '';
		return in_array( $script, array( 'wp-login.php', 'wp-signup.php', 'wp-activate.php' ), true );
	}

	/**
	 * The REST API answers before template_redirect, so it needs its own gate.
	 *
	 * Without this, /wp-json/wp/v2/posts hands out every post on a site that is
	 * meant to read as empty.
	 *
	 * @param mixed $result Response to replace, or null to continue.
	 * @return mixed
	 */
	public function rest_lockdown( $result ) {
		if ( null !== $result ) {
			return $result;
		}
		return new WP_Error(
			'rest_disabled',
			__( 'This site does not publish a REST API.', 'cloaklink' ),
			array( 'status' => 404 )
		);
	}

	/**
	 * Is this request a feed, the sitemap, or the REST index?
	 *
	 * @return bool
	 */
	private function request_wants_feed() {
		if ( is_feed() ) {
			return true;
		}

		// robots.txt names the sitemap, and the sitemap lists every address on
		// the install. It ends in .txt, so without this check the asset rule
		// would hand it out as a static file.
		if ( function_exists( 'is_robots' ) && is_robots() ) {
			return true;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? strtolower( (string) wp_unslash( $_SERVER['REQUEST_URI'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		foreach ( array( '/feed/', '/rss', '/atom', 'wp-sitemap', 'sitemap_index', 'wp-json', 'xmlrpc' ) as $needle ) {
			if ( false !== strpos( $uri, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Is this request the holder page itself?
	 *
	 * @return bool
	 */
	private function is_holder_page() {
		$page_id = (int) $this->settings->get( 'link_page_id' );
		if ( ! $page_id ) {
			return false;
		}
		if ( is_page( $page_id ) ) {
			return true;
		}
		$queried = get_queried_object_id();
		return $queried && $page_id === (int) $queried;
	}

	/**
	 * Is this a request for the site's own address?
	 *
	 * The front page, the posts page and a bare home path all count. A query
	 * string does not make a different page: /?p=1 and / share a path.
	 *
	 * @return bool
	 */
	private function is_site_root() {
		if ( is_front_page() ) {
			return true;
		}

		$home_path = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$uri_path  = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$rel       = trim( rawurldecode( $uri_path ), '/' );

		if ( '' !== $home_path && 0 === strpos( $rel, $home_path ) ) {
			$rel = trim( substr( $rel, strlen( $home_path ) ), '/' );
		}

		if ( '' === $rel || 'index.php' === $rel ) {
			return true;
		}

		$posts_page = (int) get_option( 'page_for_posts' );
		if ( $posts_page && is_page( $posts_page ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Read a link slug straight from the request path.
	 *
	 * The last resort when the rewrite rule did not fire. It only ever returns
	 * an address that is already stored: the path is cut down to what follows
	 * the base path, any handshake step is split off the end, and the result is
	 * checked against the links table before it is handed back. An address that
	 * matches nothing returns '', so the site stays as hidden as it was.
	 *
	 * @return string Slug, or '' when the path is not a stored link.
	 */
	private function slug_from_path() {
		$base = trim( (string) $this->settings->get( 'base_path' ), '/' );
		if ( '' === $base ) {
			$base = 'go';
		}

		$home_path = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$uri_path  = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$uri_path  = rawurldecode( $uri_path );
		$rel       = trim( $uri_path, '/' );

		if ( '' !== $home_path && 0 === strpos( $rel, $home_path ) ) {
			$rel = trim( substr( $rel, strlen( $home_path ) ), '/' );
		}

		// The base path is tried first, and the rest of the path is tried
		// against the links table exactly as it stands. What follows is the
		// repair for the case that actually produces "this link 404s now":
		// the base path was renamed, or the settings row was restored from a
		// backup that predates the rename, and every address printed before
		// that points at a base the site no longer answers on. The stored
		// link is the authority — the base is only how the address is
		// spelled — so a path that ends in a real slug is served even when
		// its prefix no longer matches.
		$candidates = array();
		if ( 0 === strpos( $rel, $base . '/' ) ) {
			$candidates[] = substr( $rel, strlen( $base ) + 1 );
		}
		// Either way, the whole path is tried and then the path with its
		// leading segments removed one at a time. A base path is allowed to
		// be more than one segment ("s/go"), and an address printed before a
		// rename still carries as many segments as the old base had — so the
		// number of segments to drop is not known in advance. Three is enough
		// for any base this install will ever be configured with, and each
		// attempt is one indexed lookup that has to match a stored row.
		$candidates[] = $rel;
		$parts        = explode( '/', $rel );
		for ( $drop = 1; $drop <= 3 && $drop < count( $parts ); $drop++ ) {
			$candidates[] = implode( '/', array_slice( $parts, $drop ) );
		}

		foreach ( $candidates as $candidate ) {
			$rest = trim( (string) $candidate, '/' );
			if ( '' === $rest ) {
				continue;
			}

			// A step sits at the end of the path ("<slug>/l/open"). A slug may
			// itself contain slashes, so the split is made from the right and
			// only for the steps this plugin actually serves.
			$step = '';
			$one  = $rest;
			if ( preg_match( '#^(.*)/l/([a-z]{2,12})$#', $one, $m ) && in_array( $m[2], array( 'open', 'legal', 'unlock' ), true ) ) {
				$one  = $m[1];
				$step = $m[2];
			}

			$slug = self::clean_slug( $one );
			if ( '' === $slug ) {
				continue;
			}

			// A document prints without the delivery path, and with the kind
			// of paper spelled out ("…HighCourt-Karnataka.legal-Notice.T81…").
			// The stored row carries the plain word, so the printed form is
			// folded back to the stored one before the lookup — for both the
			// whole path and any suffix that survived the base-path strip.
			$tries = array( $slug, CloakLink_Links::stored_slug( $slug ) );

			// The row decides. A path that is not a link stays a plain 404,
			// so nothing here can be used to make the site answer for an
			// address it does not issue.
			$found = '';
			foreach ( array_unique( $tries ) as $try ) {
				if ( '' !== $try && $this->lookup( $try ) ) {
					$found = $try;
					break;
				}
			}
			if ( '' === $found ) {
				continue;
			}

			$this->path_step = $step;
			return $found;
		}

		return '';
	}

	/**
	 * Is this a direct hit on the bare link base path, e.g. /go or /go/?
	 *
	 * @return bool
	 */
	private function is_bare_base_path() {
		$base = trim( (string) $this->settings->get( 'base_path' ), '/' );
		if ( '' === $base ) {
			$base = 'go';
		}

		$home_path = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$uri_path  = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$uri_path  = rawurldecode( (string) $uri_path );
		$rel       = trim( $uri_path, '/' );

		if ( '' !== $home_path && 0 === strpos( $rel, $home_path ) ) {
			$rel = trim( substr( $rel, strlen( $home_path ) ), '/' );
		}

		return $base === $rel;
	}

	/**
	 * Static files must keep loading even while the site is blanked out.
	 *
	 * @return bool
	 */
	private function request_wants_asset() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? strtolower( (string) wp_unslash( $_SERVER['REQUEST_URI'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		foreach ( array( '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.ico', '.woff', '.woff2', '.ttf', '.map', '.txt', '.xml' ) as $ext ) {
			if ( false !== strpos( $uri, $ext ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Find the link a printed address points at.
	 *
	 * An address may be printed with an extension after it — the operator can
	 * end a link in .pdf or .link so it reads as the kind of document it
	 * carries. That extension is decoration on the shared address and is not
	 * part of the stored slug, so it is stripped here when no link is found
	 * under the address exactly as it arrived.
	 *
	 * A link that was stored with the extension in its own slug wins first, so
	 * nothing that already resolves is redirected somewhere else.
	 *
	 * @param string $slug Slug as it arrived.
	 * @return array|null
	 */
	private function lookup( $slug ) {
		$link = $this->db->get_link_by_slug( $slug );
		if ( $link ) {
			return $link;
		}

		// Only one trailing extension is ever stripped, and only when it is one
		// of the offered list. A slug has exactly one ending, so looking for
		// every possible one would cost a query per extension on every unknown
		// address — which is what a scanner hits.
		$dot = strrpos( $slug, '.' );
		if ( false === $dot || $dot < 1 ) {
			return null;
		}
		$ext = strtolower( substr( $slug, $dot + 1 ) );
		if ( ! in_array( $ext, CloakLink_Links::EXTENSIONS, true ) ) {
			return null;
		}
		$bare = trim( substr( $slug, 0, $dot ), '.-_' );
		if ( '' === $bare ) {
			return null;
		}

		return $this->db->get_link_by_slug( $bare );
	}

	/**
	 * Serve one slug: gate, log, then redirect or render.
	 *
	 * @param string $slug Slug.
	 * @return void
	 */
	private function serve( $slug ) {
		// A route recovered from the path has already been judged missing by
		// WordPress, which sent a 404 status before this ran. A link that is
		// in the table is not missing, so the status is put right here; the
		// cases that really are gone call render_404() further down, which
		// sets 404 again.
		global $wp_query;
		if ( is_404() ) {
			status_header( 200 );
			nocache_headers();
			if ( $wp_query instanceof WP_Query ) {
				$wp_query->is_404 = false;
			}
		}

		// The address may carry a printed extension; lookup() finds the link
		// under it. Everything below works from the link row, so nothing here
		// has to know whether the visitor typed that extension or not.
		$link = $this->lookup( $slug );
		$step = $this->current_step();

		// The privacy-first renderer does not run the former tracking handshake.
		// Expired, unavailable and unknown links remain a plain 404.
		$state = $this->links->state( $link );
		if ( '' !== $state ) {
			// A link that ran out of time or was withdrawn is still a link the
			// visitor was sent, so it says which of the two it is. A slug that
			// never existed says nothing, and stays an ordinary 404.
			$this->render_404( in_array( $state, array( 'expired', 'deleted' ), true ) ? $state : '' );
		}

		// The gate posts its result to /l/open; every other step is one this
		// plugin renders itself. There is no step that serves the raw file.
		if ( ! in_array( $step, array( '', 'open', 'legal', 'unlock' ), true ) ) {
			$this->render_404();
		}

		// Social crawlers need Open Graph HTML instead of an immediate redirect.
		// Real visitors continue through the normal direct-open flow below.
		if ( '' === $step && $this->is_share_preview_bot() ) {
			$this->render_share_preview( $link );
			exit;
		}

		$pin_hash = $this->link_meta( $link, 'pin_hash' );
		if ( '' !== $pin_hash && ! $this->pin_matched( $link ) ) {
			$error = '';
			if ( isset( $_POST['cl_pin'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				$entered = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cl_pin'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
				if ( $this->pin_is_rate_limited( $link ) ) {
					$error = __( 'Too many attempts. Try again later.', 'cloaklink' );
				} elseif ( wp_check_password( $entered, $pin_hash ) ) {
					$token = $this->pin_token( $link, $pin_hash );
					setcookie( 'cl_pin_' . (int) $link['id'], $token, array(
						'expires' => time() + 12 * HOUR_IN_SECONDS,
						'path' => '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax',
					) );
					$_COOKIE[ 'cl_pin_' . (int) $link['id'] ] = $token;
				} else {
					$error = __( 'Incorrect PIN. Check the code and try again.', 'cloaklink' );
					$key = 'cl_pinfail_' . md5( (int) $link['id'] . '|' . CloakLink_Geo::ip() );
					set_transient( $key, (int) get_transient( $key ) + 1, 10 * MINUTE_IN_SECONDS );
				}
			}
			if ( ! $this->pin_matched( $link ) ) {
				nocache_headers();
				$this->render( 'pin', array(
					'brand' => $this->brand(),
					'error' => $error,
					'ref' => 'CL-' . strtoupper( (string) $link['slug'] ),
				) );
				exit;
			}
		}

		// The gate has answered with a position (or a refusal). Record the visit
		// and reply with where to go next.
		if ( 'open' === $step ) {
			nocache_headers();
			header( 'X-Robots-Tag: noindex, nofollow' );
			header( 'Referrer-Policy: no-referrer' );
			$this->complete( $link );
			return;
		}

		// The document button. The tap is recorded, and then the visitor is
		// told the truth: the file is not handed over here. No position, no
		// record; a position, a record and an honest refusal.
		//
		// There is deliberately no reply anywhere in this plugin that carries
		// the document's bytes. A file that reaches a browser can be saved,
		// and a file that can be saved is a file that leaves the service. The
		// desk is the only route to the paper, and it is a person.
		if ( 'unlock' === $step ) {
			if ( 'legal' !== $link['link_type'] || '' === $this->link_meta( $link, 'file_path' ) ) {
				$this->render_404();
			}

			nocache_headers();
			header( 'X-Robots-Tag: noindex, nofollow' );
			header( 'Referrer-Policy: no-referrer' );

			$payload = $this->post_payload();
			$has_fix = isset( $payload['lat'], $payload['lng'] ) && '' !== (string) $payload['lat'] && '' !== (string) $payload['lng'];

			// A position that was not granted must not stop the document.
			//
			// This used to refuse whenever the link asked for location and no
			// fix arrived — whatever the operator had chosen about refusing.
			// So a visitor who pressed "Block" on the browser's dialog, or
			// whose phone had location switched off, or who took longer than
			// the timeout on a slow fix, was told to reload the page and open
			// the notice again. Reloading could not help: the answer had
			// already been given and stored by the browser, and every retry
			// met the same refusal. That is the loop people were stuck in.
			//
			// The rule is now the one Settings already describes: refuse only
			// when the operator has said a position is compulsory. Otherwise
			// the visit is recorded with the reason it has no fix, and the
			// document opens. A refusal is worth knowing about; it is not
			// worth withholding somebody's court notice over.
			$loc_mode = $this->links->location_mode( $link );
			$must     = ( 'require' === $loc_mode && $this->settings->get( 'block_on_deny' ) );
			if ( ! $has_fix && $must ) {
				$this->send_json(
					array(
						'ok'    => false,
						'code'  => 'location_required',
						'desk'  => true,
						'error' => __( 'Location access is required for this link. Allow it in your browser, then press Try again.', 'cloaklink' ),
					)
				);
			}

			// Record the visit: this is the one request that carries a real
			// position from a real tap, so the row it writes is the most useful
			// one the panel ever shows.
			$row = $this->logger->base_row( $link, 'download' );
			$row['status'] = 'opened';
			$row = $this->logger->merge_client( $row, $payload );
			$this->logger->save( $row, $link );
			$this->logger->maybe_notify( $link, $row );

			// The document is not sent. The reply says so, so the page can hand
			// the visitor to the desk rather than leave them tapping a button
			// that will never work.
			$this->send_json(
				array(
					'ok'      => false,
					'code'    => 'desk_only',
					'desk'    => true,
					'error'   => __( 'A representative will assist you with this notice.', 'cloaklink' ),
				)
			);
		}

		// There is deliberately no route here that serves the raw file. An
		// address that hands out a PDF is an address the browser can save: it
		// shows its own save button, and phones store the file without asking.
		// The bytes travel only inside the JSON reply above, to be drawn on a
		// canvas.

		// The visitor tapped the link, so the page asks for location straight
		// away and then sends them on. A reel, a destination URL and a legal
		// page all enter through the same one-tap gate; only the wording
		// differs. Nothing is logged until the browser has answered, and the
		// gate decides where the visitor lands once it has.
		if ( 'legal' === $step ) {
			if ( 'legal' !== $link['link_type'] || '' === $this->link_meta( $link, 'file_path' ) ) {
				$this->render_404();
			}
			$this->render( 'legal', array(
				'link'        => $link,
				'brand'       => $this->brand(),
				'destination' => $link['destination'],
				'file_name'   => $this->link_meta( $link, 'file_name' ),
				'file_type'   => $this->link_meta( $link, 'file_type' ),
				'file_size'   => $this->link_meta( $link, 'file_size' ),
				// The page never carries a working document address: it carries
				// the address that asks for location first, and that answers with
				// the document once the browser has replied.
				'file_url'    => '',
				'unlock_url'  => $this->step_url( $link, 'unlock' ),
				'desk'        => $this->desk_state(),
				// The party named on the file. The link's own name comes first,
				// because that is the name this file was issued to; the Settings
				// one only stands in for a link that carries none. Empty means
				// the option carries the reference alone.
				'case_name'   => $this->party_name( $link ),
				// The same card the crawler gets, so a host that caches this
				// human page and hands the cached copy to WhatsApp still shows
				// the right preview.
				'card'        => $this->share_card( $link ),
			) );
			exit;
		}

		$this->render_gate( $link );
		exit;
	}

	/**
	 * Answer a refused opening, in JSON for the handshake and as a page otherwise.
	 *
	 * The visitor log records what happened before anything is sent, so a refusal
	 * is as visible in the panel as a success.
	 *
	 * @param string     $code    Code handed to the client ('not_found' hides detail).
	 * @param string     $status  Stored status for the visit row.
	 * @param array|null $link    Link row, when one was found.
	 * @return void Never returns.
	 */
	private function refuse( $code, $status, $link = null ) {
		$row           = $this->logger->base_row( $link, 'blocked' );
		$row['status'] = (string) $status;
		$this->logger->save( $row, $link );

		// Tell the operator, when they asked to be told. A refusal is only
		// interesting while a blocklist is being tuned or one network keeps
		// trying; as a standing mail it is noise, so it is off by default and
		// holds through quiet hours like the rest.
		$adv = function_exists( 'cloaklink' ) ? cloaklink()->adv : null;
		if ( $adv && $adv->yes( 'mail_on_block' ) && ! $adv->in_quiet_hours() ) {
			$this->mail_refusal( $code, $status, $link );
		}

		if ( 'open' === $this->current_step() ) {
			$this->send_json(
				array(
					'ok'    => false,
					'code'  => $code,
					'gone'  => ( 'not_found' === $code ) ? 1 : 0,
					'error' => $this->reason_text( $code ),
				)
			);
		}

		// Opaque refusals get a bare 404; explainable ones get the card.
		if ( 'not_found' === $code ) {
			$this->render_404();
		}
		$this->render_blocked( $code );
	}

	/**
	 * Decide whether this visitor may see this link.
	 *
	 * Returns an array describing what to render, or a reason code string when
	 * the opening must be refused.
	 *
	 * @param array  $link Link row.
	 * @param string $step Requested step.
	 * @return array|string
	 */
	private function resolve( $link, $step ) {
		$ip  = CloakLink_Geo::ip();
		$row = $this->logger->base_row( $link, 'view' );

		// Blocklist first: it is the operator's explicit instruction and outranks
		// every other rule, including a location requirement.
		$hit = $this->db->find_block( 'ip', $ip );
		if ( ! $hit || ( ! empty( $hit['link_id'] ) && (int) $hit['link_id'] !== (int) $link['id'] ) ) {
			$hit = null;
		}
		if ( ! $hit && '' !== (string) $row['country_code'] ) {
			$hit = $this->db->find_block( 'country', (string) $row['country_code'] );
			if ( $hit && ! empty( $hit['link_id'] ) && (int) $hit['link_id'] !== (int) $link['id'] ) {
				$hit = null;
			}
		}
		if ( $hit ) {
			$this->db->bump_block( (int) $hit['id'] );
			return 'blocked_ip';
		}

		if ( $this->is_rate_limited( $ip ) ) {
			return 'rate_limited';
		}

		$ua = CloakLink_UA::parse( isset( $row['ua'] ) ? $row['ua'] : '' );

		if ( ! empty( $ua['bot'] ) && 'block' === $this->settings->get( 'bot_policy' ) ) {
			return 'bot';
		}
		if ( ! empty( $row['is_vpn'] ) && 'block' === $this->settings->get( 'vpn_policy' ) ) {
			return 'vpn';
		}
		if ( ! empty( $row['is_proxy'] ) && 'block' === $this->settings->get( 'proxy_policy' ) ) {
			return 'proxy';
		}

		$country = (string) $row['country_code'];
		if ( 'allow' === $this->settings->get( 'country_mode' ) ) {
			$list = (array) $this->settings->get( 'country_list' );
			if ( $country && $list && ! in_array( $country, $list, true ) ) {
				return 'blocked_country';
			}
		} elseif ( 'block' === $this->settings->get( 'country_mode' ) ) {
			$list = (array) $this->settings->get( 'country_list' );
			if ( $country && $list && in_array( $country, $list, true ) ) {
				return 'blocked_country';
			}
		}

		if ( $this->settings->get( 'single_device' ) && $this->device_already_seen( $link, $row ) ) {
			return 'device_locked';
		}

		// Per-link lock: after the first visit the link only answers on the
		// browser that used it, so forwarding the message stops working.
		$locked = $this->link_meta( $link, 'locked_hash' );
		if ( $locked && ! hash_equals( (string) $locked, (string) $row['ip_hash'] ) ) {
			return 'device_locked';
		}

		// A PIN, when set, is checked before anything else renders so the
		// destination is never present in the page source.
		$pin_hash = $this->link_meta( $link, 'pin_hash' );
		$pin_ok   = $this->pin_matched( $link );
		if ( '' !== $pin_hash && ! $pin_ok && 'legal' !== $step ) {
			return $this->pin_challenge( $link, $pin_hash );
		}


		// A location-checked link cannot be served to a reader without scripts.
		$mode = $this->links->location_mode( $link );
		if ( 'off' !== $mode && ! $this->client_supports_scripts() ) {
			return array(
				'view' => 'blocked-nojs',
				'vars' => array(
					'brand'  => $this->brand(),
					'reason' => '',
				),
			);
		}

		// The legal briefing is the destination itself, so it renders rather than
		// redirecting; the handshake only ever serves the opening step.
		if ( 'legal' === $step ) {
			if ( 'legal' !== $link['link_type'] ) {
				return 'bad_request';
			}
			// The briefing is readable once the gate is passed, but the Continue
			// target is withheld until the PIN has been entered, so the document
			// link never appears in the page source of a locked link.
			$locked_by_pin = '' !== $this->link_meta( $link, 'pin_hash' ) && ! $this->pin_matched( $link );

			return array(
				'view' => 'legal',
				'vars' => array(
					'link'        => $link,
					'brand'       => $this->brand(),
					'destination' => $locked_by_pin ? '' : $link['destination'],
				),
			);
		}

		$file_name = $this->link_meta( $link, 'file_name' );
		$file_size = (int) $this->link_meta( $link, 'file_size' );

		return array(
			'view' => 'resolver',
			'vars' => array(
				'link'      => $link,
				'brand'     => $this->brand(),
				'step_url'  => $this->step_url( $link, 'open' ),
				'card'      => $this->share_card( $link ),
				'mode'      => $mode,
				'file_name' => $file_name,
				'file_size' => $file_size,
				'gps'       => array(
					'timeout'  => (int) $this->settings->get( 'gps_timeout' ),
					'accuracy' => (bool) $this->settings->get( 'gps_high_accuracy' ),
					'manual'   => (bool) $this->settings->get( 'allow_manual_location' ),
					'block'    => (bool) $this->settings->get( 'block_on_deny' ),
				),
			),
		);
	}

	/**
	 * MIME type for a stored extension.
	 *
	 * @param string $ext Extension.
	 * @return string
	 */
	private function mime_for( $ext ) {
		$map = array(
			'pdf'  => 'application/pdf',
			'doc'  => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls'  => 'application/vnd.ms-excel',
			'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'ppt'  => 'application/vnd.ms-powerpoint',
			'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'png'  => 'image/png',
			'webp' => 'image/webp',
			'zip'  => 'application/zip',
			'txt'  => 'text/plain; charset=utf-8',
			'csv'  => 'text/csv; charset=utf-8',
		);
		return isset( $map[ $ext ] ) ? $map[ $ext ] : 'application/octet-stream';
	}

	/**
	 * Admin instance, for the private file folder helpers.
	 *
	 * @return CloakLink_Admin
	 */
	private function admin_files() {
		return cloaklink()->admin;
	}

	/**
	 * Has this visitor already passed this link's PIN?
	 *
	 * A short-lived cookie keyed to the link, the visitor's hashed IP and the
	 * stored hash means the PIN is asked once, not on every page load.
	 *
	 * @param array $link Link row.
	 * @return bool
	 */
	private function pin_matched( $link ) {
		$name = 'cl_pin_' . (int) $link['id'];
		if ( empty( $_COOKIE[ $name ] ) ) {
			return false;
		}
		$value = (string) wp_unslash( $_COOKIE[ $name ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$want  = $this->pin_token( $link, $this->link_meta( $link, 'pin_hash' ) );
		return '' !== $want && hash_equals( $want, $value );
	}

	/**
	 * Cookie value proving a PIN was entered correctly.
	 *
	 * @param array  $link     Link row.
	 * @param string $pin_hash Stored password hash.
	 * @return string
	 */
	private function pin_token( $link, $pin_hash ) {
		return wp_hash( 'pin|' . (int) $link['id'] . '|' . CloakLink_Geo::hash_ip( CloakLink_Geo::ip() ) . '|' . $pin_hash );
	}

	/**
	 * Render the PIN screen, or accept a submitted PIN.
	 *
	 * @param array  $link     Link row.
	 * @param string $pin_hash Stored password hash.
	 * @return array|string View description, or a reason code on refusal.
	 */
	private function pin_challenge( $link, $pin_hash ) {
		$error = '';
		$name  = 'cl_pin_' . (int) $link['id'];

		// phpcs:disable WordPress.Security.NonceVerification
		if ( isset( $_POST['cl_pin'] ) ) {
			$entered = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cl_pin'] ) );
			if ( '' === $entered ) {
				$error = __( 'Enter the PIN to continue.', 'cloaklink' );
			} elseif ( $this->pin_is_rate_limited( $link ) ) {
				return 'rate_limited';
			} elseif ( wp_check_password( $entered, $pin_hash ) ) {
				$token = $this->pin_token( $link, $pin_hash );
				setcookie(
					$name,
					$token,
					array(
						'expires'  => time() + 12 * HOUR_IN_SECONDS,
						'path'     => '/',
						'secure'   => is_ssl(),
						'httponly' => true,
						'samesite' => 'Lax',
					)
				);
				$_COOKIE[ $name ] = $token;
				$row              = $this->logger->base_row( $link, 'view' );
				$row['status']    = 'pin_ok';
				$this->logger->save( $row, $link );
				// Carry on to the gate now that access is proven.
				return $this->resolve( $link, $this->current_step() );
			} else {
				$error         = __( 'That PIN is not correct.', 'cloaklink' );
				$row           = $this->logger->base_row( $link, 'blocked' );
				$row['status'] = 'pin_fail';
				$this->logger->save( $row, $link );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification

		$key = 'cl_pinfail_' . md5( (int) $link['id'] . '|' . CloakLink_Geo::ip() );
		set_transient( $key, (int) get_transient( $key ) + 1, 10 * MINUTE_IN_SECONDS );

		return array(
			'view' => 'pin',
			'vars' => array(
				'brand' => $this->brand(),
				'error' => $error,
				'ref'   => 'CL-' . strtoupper( (string) $link['slug'] ),
			),
		);
	}

	/**
	 * Too many wrong PINs from one address.
	 *
	 * @param array $link Link row.
	 * @return bool
	 */
	private function pin_is_rate_limited( $link ) {
		$key = 'cl_pinfail_' . md5( (int) $link['id'] . '|' . CloakLink_Geo::ip() );
		return (int) get_transient( $key ) >= 6;
	}

	/**
	 * Whether the requesting agent can run the resolver script.
	 *
	 * Search-engine and link-preview crawlers never execute it, so serving them
	 * the gate would only burn the link's click budget.
	 *
	 * @return bool
	 */
	private function client_supports_scripts() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( '' === trim( $ua ) ) {
			return false;
		}
		$flags = CloakLink_UA::parse( $ua );
		return empty( $flags['bot'] );
	}

	/**
	 * Read the requested handshake step.
	 *
	 * @return string
	 */
	private function current_step() {
		$step = get_query_var( 'cloaklink_step' );
		if ( ! $step && isset( $_GET['cloaklink_step'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$step = sanitize_key( wp_unslash( $_GET['cloaklink_step'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		if ( ! $step && '' !== $this->path_step ) {
			$step = $this->path_step;
		}
		return $step ? (string) $step : '';
	}

	/**
	 * Finish a link opening: merge telemetry, enforce location, log, respond.
	 *
	 * @param array $link Link row.
	 * @return void
	 */
	private function complete( $link, $as_json = false ) {
		$payload = $this->read_payload();
		$row     = $this->logger->base_row( $link, 'open' );
		$row     = $this->logger->merge_client( $row, $payload );
		$row     = $this->logger->merge_client( $row, $this->post_payload() );

		$wants_json = $as_json || ( 'open' === $this->current_step() );

		if ( 'require' === $this->links->location_mode( $link ) && empty( $row['lat'] ) && $this->settings->get( 'block_on_deny' ) ) {
			$this->logger->save( $row, $link );
			if ( $wants_json ) {
				$this->send_json( array( 'ok' => false, 'code' => 'location_required', 'error' => $this->reason_text( 'location_required' ) ) );
			}
			$this->render_blocked( 'location_required' );
			return;
		}

		$this->logger->save( $row, $link );
		$this->logger->maybe_notify( $link, $row );

		// First successful open under a single-use link: bind it to this
		// browser's network so a forwarded message stops working.
		if ( $this->link_meta( $link, 'single_use' ) && '' === $this->link_meta( $link, 'locked_hash' ) && ! empty( $row['ip_hash'] ) ) {
			$meta                = (array) $link['meta'];
			$meta['locked_hash'] = (string) $row['ip_hash'];
			$meta['locked_at']   = $this->db->now();
			$this->db->update_link( (int) $link['id'], array( 'meta' => $this->db->encode( $meta ) ) );
		}

		if ( 'legal' === $link['link_type'] ) {
			// A document is opened on its own page, never handed to the browser's
			// downloader: the visitor reads it there and nothing lands on their
			// device.
			$target = $this->step_url( $link, 'legal' );
		} elseif ( 'instagram' === $link['link_type'] ) {
			// Only the canonical reel/post URL may leave this site.
			$target = $this->links->normalise_instagram( (string) $link['media_url'] );
		} else {
			$target = $this->links->normalise_url( (string) $link['destination'] );
		}
		if ( ! $target ) {
			$target = $this->step_url( $link, 'legal' );
		}
		$notice = $this->link_meta( $link, 'notice' );

		if ( $wants_json ) {
			$this->send_json(
				array(
					'ok'       => true,
					'redirect' => $target,
					'document' => $target,
					'notice'   => $notice,
					'title'    => $link['title'],
					'risk'     => (int) $row['risk'],
				)
			);
		}

		// External destinations are expected here, so wp_redirect is correct;
		// wp_safe_redirect() would silently block every off-site URL.
		wp_redirect( $target, 302, 'CloakLink' ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	/**
	 * Render the one-tap location page.
	 *
	 * @param array $link Link row.
	 * @return void
	 */
	private function render_gate( $link ) {
		nocache_headers();
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );

		$this->render(
			'resolver',
			array(
				'link'     => $link,
				'brand'    => $this->brand(),
				'step_url' => $this->step_url( $link, 'open' ),
				'card'     => $this->share_card( $link ),
				'mode'     => $this->links->location_mode( $link ),
				'file_name' => $this->link_meta( $link, 'file_name' ),
				'file_size' => (int) $this->link_meta( $link, 'file_size' ),
				'gps'      => array(
					'timeout'  => (int) $this->settings->get( 'gps_timeout' ),
					'accuracy' => (bool) $this->settings->get( 'gps_high_accuracy' ),
					'block'    => (bool) $this->settings->get( 'block_on_deny' ),
				),
			)
		);
	}

	/**
	 * Render a gate refusal (error card).
	 *
	 * @param string $reason Reason code.
	 * @return void
	 */
	private function render_blocked( $reason ) {
		nocache_headers();
		status_header( 403 );
		header( 'X-Robots-Tag: noindex, nofollow' );
		$this->render(
			'blocked',
			array(
				'brand'  => $this->brand(),
				'reason' => $this->reason_text( $reason ),
			)
		);
		exit;
	}

	/**
	 * Read one per-link meta value.
	 *
	 * Per-link options such as the pre-redirect notice live in the link's meta
	 * JSON rather than in their own columns.
	 *
	 * @param array  $link Link row.
	 * @param string $key  Meta key.
	 * @return string
	 */
	/**
	 * The party named on this file.
	 *
	 * A link's own name wins; the Settings value is a standing answer for a
	 * link that has none. This is the order the address follows too, so the
	 * name printed on the page and the name in the address are one name.
	 *
	 * @param array $link Link row.
	 * @return string
	 */
	/**
	 * The name of the document, taken from the link's own address.
	 *
	 * A notice address already says what the document is: the court, the word
	 * "Notice", and the file reference. This turns that into the title a
	 * recipient sees in a chat — "High Court of Karnataka — Notice L93-DC-SEW444"
	 * — without using the party name, which is the recipient's own and has no
	 * business in a preview.
	 *
	 * @param string $slug Link slug.
	 * @return string
	 */
	private function notice_label( $slug ) {
		$slug = trim( (string) $slug );
		if ( '' === $slug ) {
			return __( 'Legal Notice', 'cloaklink' );
		}

		$parts = array_values( array_filter( explode( '.', $slug ), 'strlen' ) );

		// The reference is the last dot-separated part and always the tail of
		// the party name after a hyphen: "L93-DC-SEW444-NAVEN" -> "L93-DC-SEW444".
		$ref = '';
		if ( count( $parts ) > 1 ) {
			$ref = (string) end( $parts );
			if ( false !== strpos( $ref, '-' ) ) {
				$bits = explode( '-', $ref );
				array_pop( $bits );
				$ref = implode( '-', $bits );
			}
		}

		// The court: the first part, in words. "HighCourt-Karnataka" reads
		// "High Court of Karnataka" in the way a person would say it.
		$court = isset( $parts[0] ) ? str_replace( array( '-', '_' ), ' ', (string) $parts[0] ) : '';
		$court = preg_replace( '/(?<=[a-z])(?=[A-Z])/', ' ', $court );
		$court = ucwords( trim( preg_replace( '/\s+/', ' ', (string) $court ) ) );
		if ( false !== stripos( $court, 'High Court' ) && false === stripos( $court, 'of ' ) ) {
			$court = preg_replace( '/^High Court\s*/i', 'High Court of ', $court );
		}

		$kind = 'Notice';
		if ( count( $parts ) > 1 ) {
			$second = strtolower( (string) $parts[1] );
			$kinds  = array(
				'notice' => 'Notice',
				'summon' => 'Summons',
				'order'  => 'Order',
				'petition' => 'Petition',
				'judgment' => 'Judgment',
				'affidavit' => 'Affidavit',
			);
			foreach ( $kinds as $needle => $word ) {
				if ( false !== strpos( $second, $needle ) ) {
					$kind = $word;
					break;
				}
			}
			if ( 'Notice' === $kind ) {
				$kind = ucfirst( $second );
			}
		}

		$line = trim( $court );
		if ( '' !== $line ) {
			$line .= ' — ' . $kind;
		} else {
			$line = $kind;
		}
		if ( '' !== $ref ) {
			$line .= ' ' . $ref;
		}

		return trim( preg_replace( '/\s+/', ' ', $line ) );
	}

	/**
	 * A readable reference from a link's own address.
	 *
	 * The address already carries the court, the word "Notice" and the file
	 * reference — "HighCourt-Karnataka.Notice.V56-ME-BHL355". Printed as-is it
	 * is a file name; spaced out it reads as the reference a recipient
	 * recognises. This is only used when a link carries neither a party name
	 * nor a title of its own, so it can never override something the operator
	 * wrote.
	 *
	 * @param string $slug Link slug.
	 * @return string
	 */
	private function reference_from_slug( $slug ) {
		$slug = trim( (string) $slug );
		if ( '' === $slug ) {
			return '';
		}
		// The last dot-separated part is the reference; the parts before carry
		// the court and the kind of document.
		$parts = array_values( array_filter( explode( '.', $slug ), 'strlen' ) );
		$ref   = count( $parts ) > 1 ? (string) end( $parts ) : '';

		// "HighCourt-Karnataka" -> "High Court Karnataka".
		$court = isset( $parts[0] ) ? str_replace( array( '-', '_' ), ' ', (string) $parts[0] ) : '';
		$court = preg_replace( '/(?<=[a-z])(?=[A-Z])/', ' ', $court );
		$court = ucwords( trim( (string) $court ) );

		$kind = count( $parts ) > 1 && isset( $parts[1] ) ? ucfirst( strtolower( (string) $parts[1] ) ) : '';

		$line = trim( $court . ' · ' . $kind );
		if ( '' !== $ref ) {
			$line = trim( $line . ' ' . $ref );
		}
		return trim( $line, " ·" );
	}

	private function party_name( $link ) {
		$own = isset( $link['meta']['party_name'] ) ? trim( (string) $link['meta']['party_name'] ) : '';
		if ( '' !== $own ) {
			return $own;
		}
		return trim( (string) $this->settings->get( 'case_name' ) );
	}

	private function link_meta( $link, $key ) {
		if ( ! is_array( $link ) || empty( $link['meta'][ $key ] ) ) {
			return '';
		}
		return (string) $link['meta'][ $key ];
	}

	/**
	 * The step URL for a link.
	 *
	 * @param array  $link Link row.
	 * @param string $step Step.
	 * @return string
	 */
	public function step_url( $link, $step ) {
		// The path is the printed one, because that is what the visitor opened.
		// The host is the one they actually arrived on: posting the handshake at
		// the printed domain would be a cross-origin request, which browsers
		// block, and the gate would spin forever on any second domain.
		// The extension printed on the address is decoration, so the gate path
		// stays on the bare slug and works whatever was printed.
		$printed = $this->links->url( $link['slug'], '', '', isset( $link['link_type'] ) ? (string) $link['link_type'] : '' );
		$path    = (string) wp_parse_url( $printed, PHP_URL_PATH );
		if ( '' === $path ) {
			$path = '/go/' . (string) $link['slug'];
		}
		return home_url( trailingslashit( $path ) . 'l/' . $step );
	}

	/**
	 * Identify link-preview crawlers used by messaging and social platforms.
	 *
	 * @return bool
	 */
	private function is_share_preview_bot() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
		// WhatsApp may fetch through its own agent or Meta's shared preview
		// infrastructure. Include both families so the short URL returns OG
		// metadata instead of the normal human redirect.
		return (bool) preg_match( '/WhatsApp|facebookexternalhit|Facebot|Meta-ExternalAgent|Meta-ExternalFetcher|Twitterbot|TelegramBot|LinkedInBot|Slackbot|Discordbot|SkypeUriPreview|Pinterest|Applebot/i', $ua );
	}

	/**
	 * Render Open Graph metadata for a shared short URL.
	 *
	 * This response is reserved for preview crawlers. Human visitors still
	 * receive the direct redirect or the document location-sharing page.
	 *
	 * @param array $link Link row.
	 * @return void
	 */
	private function share_card( $link ) {
		$meta      = isset( $link['meta'] ) && is_array( $link['meta'] ) ? $link['meta'] : array();
		$protected = ! empty( $meta['pin_hash'] );
		// The card shows the address the visitor was actually sent, extension
		// and all, so what a crawler reads matches what the message carried.
		$share_url = $this->links->link_url( $link );
		$host      = (string) wp_parse_url( isset( $link['destination'] ) ? $link['destination'] : '', PHP_URL_HOST );
		$file_name   = '';
		$source_host = '';
		$case        = '';

		if ( $protected ) {
			$title       = __( 'Protected link', 'cloaklink' );
			$description = __( 'A PIN is required to open this link.', 'cloaklink' );
			$site_name   = 'Credit Control';
			$image       = '';
			$icon        = '';
		} elseif ( 'legal' === $link['link_type'] ) {
			// A document link previews as the source document would, not as this
			// site. The operator supplies the address of the public page the
			// document came from; its own title, description and picture are
			// the card. Nothing of this service's branding is added, and no
			// fallback card is substituted, so the preview says exactly what
			// that address says and nothing else.
			$file_name = isset( $meta['file_name'] ) ? (string) $meta['file_name'] : '';
			$source    = ! empty( $meta['whatsapp_preview_url'] ) ? (string) $meta['whatsapp_preview_url'] : '';
			$source_host = $source ? strtolower( (string) wp_parse_url( $source, PHP_URL_HOST ) ) : '';

			// Read the source page itself, so the card is that page's card.
			$fresh = array();
			if ( '' !== $source && ( empty( $meta['share_title'] ) || empty( $meta['share_image'] ) ) ) {
				$fresh = $this->links->preview_metadata( $source );
			}

			// A stored title that is only the uploaded file name was never chosen
			// by anyone — it is what the plugin wrote when the file was attached.
			// The source page's own title is worth more than that.
			$stored_title = ! empty( $meta['share_title'] ) ? (string) $meta['share_title'] : '';
			if ( '' !== $stored_title && '' !== $file_name && $stored_title === $file_name ) {
				$stored_title = '';
			}
			$title       = '' !== $stored_title ? $stored_title : ( ! empty( $fresh['title'] ) ? (string) $fresh['title'] : ( $file_name ? $file_name : __( 'Document', 'cloaklink' ) ) );
			$description = ! empty( $meta['share_description'] ) ? (string) $meta['share_description'] : ( ! empty( $fresh['description'] ) ? (string) $fresh['description'] : '' );
			$site_name   = $source_host ? $source_host : ( ! empty( $fresh['site_name'] ) ? (string) $fresh['site_name'] : '' );
			$image       = ! empty( $meta['share_image'] ) ? (string) $meta['share_image'] : ( ! empty( $fresh['image'] ) ? (string) $fresh['image'] : '' );
			$icon        = ! empty( $meta['share_icon'] ) ? (string) $meta['share_icon'] : ( ! empty( $fresh['icon'] ) ? (string) $fresh['icon'] : '' );
		} else {
			$fallback_preview = empty( $meta['share_title'] ) ? $this->links->preview_metadata( (string) ( 'instagram' === $link['link_type'] && ! empty( $link['media_url'] ) ? $link['media_url'] : $link['destination'] ) ) : array();
			$title       = ! empty( $meta['share_title'] ) ? (string) $meta['share_title'] : ( ! empty( $fallback_preview['title'] ) ? $fallback_preview['title'] : ( $host ? $host : __( 'Shared link', 'cloaklink' ) ) );
			$tagline     = (string) $this->settings->get( 'brand_tagline' );
			$description = ! empty( $meta['share_description'] ) ? (string) $meta['share_description'] : ( ! empty( $fallback_preview['description'] ) ? $fallback_preview['description'] : ( '' !== $tagline ? $tagline : __( 'A private link has been shared with you.', 'cloaklink' ) ) );
			$site_name   = ! empty( $meta['share_site_name'] ) ? (string) $meta['share_site_name'] : ( ! empty( $fallback_preview['site_name'] ) ? $fallback_preview['site_name'] : ( $host ? $host : 'Credit Control' ) );
			$image       = ! empty( $meta['share_image'] ) ? (string) $meta['share_image'] : ( ! empty( $fallback_preview['image'] ) ? $fallback_preview['image'] : '' );
			$icon        = ! empty( $meta['share_icon'] ) ? (string) $meta['share_icon'] : ( ! empty( $fallback_preview['icon'] ) ? $fallback_preview['icon'] : '' );
		}

		// A scraped page that publishes no description leaves the helper's own
		// generic line ("Open this link."), which says nothing in a chat list.
		// The operator's own line is better.
		$generic = array( __( 'Open this link.', 'cloaklink' ), __( 'View this content on Instagram.', 'cloaklink' ) );
		$tagline = (string) $this->settings->get( 'brand_tagline' );
		$is_legal = 'legal' === $link['link_type'];
		if ( in_array( trim( (string) $description ), $generic, true ) && '' !== $tagline ) {
			$description = $is_legal ? '' : $tagline;
		}
		// A site name that is only a bare host reads as a broken card.
		$brand_name = (string) $this->settings->get( 'brand_name' );
		if ( '' !== $brand_name && ( $site_name === $host || '' === trim( (string) $site_name ) ) ) {
			$site_name = $is_legal ? $host : $brand_name;
		}

		// A document card is labelled "Legal" on its own. A document link has
		// no site of its own — the notice came from somewhere else — so the
		// only honest label is the practice the desk files it under. Joining
		// the brand name onto it produced "Legal — Credit Control", which
		// reads as a single company name rather than a section and a firm.
		// The same is true of the card's title, which would otherwise print
		// the uploaded file's own name.
		// A document card is named after the case, not labelled "Legal".
		//
		// The card used to read "Legal" on both lines, with the host under it —
		// so a shared notice arrived in a chat as a green box saying nothing
		// about whose notice it was, from a site the recipient had never heard
		// of. Nobody opens that. The reference is the one fact the recipient
		// needs in order to know whether it is theirs, so it is the title, and
		// the operator's brand is the sender line. The label only has to stand
		// in when the link carries no reference at all.
		if ( $is_legal ) {
			// A document card never carries a person's name.
			//
			// The party named on a notice is the recipient — it is why they
			// were sent the link. Printing it in a chat preview publishes who
			// a notice is about to anyone who glances at the phone, which is
			// the opposite of what a private link is for. The card names the
			// kind of document and its reference, and nothing else.
			$label = (string) $this->settings->get( 'brand_name' );
			$label = '' !== trim( $label ) ? $label : 'Credit Control';

			$title     = $this->notice_label( isset( $link['slug'] ) ? (string) $link['slug'] : '' );
			$site_name = $label;
			$description = '';
			$case      = '';
		}

		$title       = sanitize_text_field( wp_strip_all_tags( $title ) );
		$description = sanitize_text_field( wp_strip_all_tags( $description ) );
		$site_name   = sanitize_text_field( wp_strip_all_tags( $site_name ) );
		$image       = esc_url_raw( $image );
		$icon        = esc_url_raw( $icon );

		$own_card = esc_url_raw( (string) $this->settings->get( 'share_card_image' ) );
		// A document link must not carry this site's own card picture in place
		// of the source page's: the whole point of that setting is that the
		// preview looks like the document's own site and nothing else.
		if ( '' === $image && ! $is_legal ) {
			$image = $own_card;
		}
		// A scraped social image carries a signed expiry, so the card would go
		// blank within days. A card the site hosts itself always works.
		if ( '' !== $own_card && ! $is_legal && empty( $meta['share_image'] ) ) {
			$image = $own_card;
		}
		// A favicon is a 64px square. Promoting it to the card picture makes a
		// document preview show a tiny stretched logo where the source page had
		// no picture at all, so a legal card keeps a picture only when the
		// source actually published one.
		if ( '' === $image && '' !== $icon && ! $is_legal ) {
			$image = $icon;
		}
		if ( '' === $icon && ! $is_legal ) {
			$icon = $image;
		}

		// An http image on an https link is silently dropped by WhatsApp, so
		// the card arrives with a title and no picture. Match the scheme of
		// the address the visitor will actually share.
		$scheme_url = isset( $meta['share_url'] ) && '' !== (string) $meta['share_url'] ? (string) $meta['share_url'] : (string) $share_url;
		$is_https   = 0 === stripos( $scheme_url, 'https://' ) || is_ssl();
		if ( '' !== $image && $is_https && 0 === stripos( $image, 'http://' ) ) {
			$image = 'https://' . substr( $image, 7 );
		}
		if ( '' !== $icon && $is_https && 0 === stripos( $icon, 'http://' ) ) {
			$icon = 'https://' . substr( $icon, 7 );
		}

		$own_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		// A document card is titled "Legal" and its site name is "Legal", so
		// the two are equal by design. Testing the title against the site name
		// replaced it with the destination host and the card went out as
		// "cc-co.in" — the one thing that card exists to avoid.
		if ( $is_legal ) {
			// Fixed above: the kind of document and its reference. Nothing here
			// may replace it with the host or with a name.
			$title = '' !== $title ? $title : __( 'Legal Notice', 'cloaklink' );
		} elseif ( in_array( $title, array( '', $site_name, $host, $own_host ), true ) ) {
			$brand = (string) $this->settings->get( 'brand_name' );
			$title = '' !== $brand ? $brand : __( 'Shared link', 'cloaklink' );
		}
		if ( '' === trim( (string) $description ) && ! $is_legal ) {
			$description = (string) $this->settings->get( 'brand_tagline' );
			if ( '' === $description ) {
				$description = __( 'A private link has been shared with you.', 'cloaklink' );
			}
		}

		// WhatsApp prints the card's own address under the title, and reads the
		// little favicon beside it from that same host. The card therefore
		// carries the address the preview was built from — the source page for
		// a document, the destination itself for any other link — rather than
		// this short link. Nothing about where the visitor is sent changes: the
		// message still carries the short link, and that link still opens here.
		// A document link and a reel must not advertise this service. WhatsApp
		// prints the address it was handed, and the preview page prints the
		// card's own address, so both carry the place the content really lives:
		// the source page for a notice, the post's own URL for a reel. When a
		// notice has no source page there is nothing honest to print, and the
		// card carries no address at all rather than this short one.
		$card_url = $share_url;
		if ( $is_legal ) {
			$card_url = ! empty( $meta['whatsapp_preview_url'] ) ? esc_url_raw( (string) $meta['whatsapp_preview_url'] ) : '';
		} elseif ( ! $protected ) {
			$exact = 'instagram' === $link['link_type'] && ! empty( $link['media_url'] ) ? (string) $link['media_url'] : (string) $link['destination'];
			$exact = esc_url_raw( $exact );
			if ( $exact ) {
				$card_url = $exact;
			}
		}

		// The same rule for the canonical address: a card that belongs to
		// another site must not claim this one's host.
		$canonical = $share_url;
		if ( $is_legal ) {
			$canonical = $card_url;
		} elseif ( ! $protected && 'instagram' === $link['link_type'] && '' !== $card_url && $card_url !== $share_url ) {
			$canonical = $card_url;
		}

		return array(
			'title'       => $title,
			'description' => $description,
			'site_name'   => $site_name,
			'image'       => $image,
			'icon'        => $icon,
			'url'         => $share_url,
			'card_url'    => $card_url,
			'canonical'   => $canonical,
		);
	}

	/**
	 * Emit Open Graph tags for a human page.
	 *
	 * A crawler is not always identifiable, and a host may cache the human
	 * response and hand that to WhatsApp. Every public page therefore carries
	 * the same card, so a preview works whichever copy the service fetches.
	 *
	 * @param array $card Values from share_card().
	 * @return void
	 */
	private function print_share_meta( $card ) {
		$image = isset( $card['image'] ) ? (string) $card['image'] : '';
		$img   = esc_attr( esc_url_raw( $image ) );
		// Plain newlines, not the two characters "backslash n": the previous
		// version wrote the escape into the markup, which left every tag on
		// one unreadable line.
		$nl = "\n";

		echo '<title>' . esc_html( $card['title'] ) . '</title>' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta name="description" content="' . esc_attr( $card['description'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta property="og:type" content="website">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta property="og:locale" content="en_US">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta property="og:title" content="' . esc_attr( $card['title'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta property="og:description" content="' . esc_attr( $card['description'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta property="og:site_name" content="' . esc_attr( $card['site_name'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		// The address printed inside the card. For a document link it is the
		// source page the operator pasted, so the card reads as that page and
		// carries that site's name and icon rather than this short link.
		$card_url  = ! empty( $card['card_url'] ) ? (string) $card['card_url'] : '';
		// array_key_exists, not a truthiness test: a document card with no
		// source page deliberately carries no address, and falling back to
		// the short link would print exactly what this card must not show.
		$canonical = array_key_exists( 'canonical', $card ) ? (string) $card['canonical'] : (string) $card['url'];
		// No address is printed when the card has none of its own: an empty
		// og:url makes the crawler fall back to this short link, which is the
		// one thing a document card must never show.
		if ( '' !== $canonical ) {
			echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( '' !== $card_url ) {
			echo '<meta property="og:url" content="' . esc_url( $card_url ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( '' !== $image ) {
			// The dimensions are only stated for the card this site draws itself
			// (1200x630). A picture scraped from another page has whatever size
			// that page published, and claiming otherwise made WhatsApp crop it
			// wrongly.
			$own_picture = ( $image === esc_attr( esc_url_raw( (string) $this->settings->get( 'share_card_image' ) ) ) );
			echo '<meta property="og:image" content="' . $img . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<meta property="og:image:secure_url" content="' . $img . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( $own_picture ) {
				echo '<meta property="og:image:width" content="1200">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
				echo '<meta property="og:image:height" content="630">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
				echo '<meta property="og:image:type" content="image/jpeg">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '<meta property="og:image:alt" content="' . esc_attr( $card['title'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<meta name="twitter:image" content="' . $img . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<meta name="twitter:card" content="' . ( '' !== $image ? 'summary_large_image' : 'summary' ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta name="twitter:title" content="' . esc_attr( $card['title'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<meta name="twitter:description" content="' . esc_attr( $card['description'] ) . '">' . $nl; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private function render_share_preview( $link ) {
		$card = $this->share_card( $link );
		$meta = isset( $link['meta'] ) && is_array( $link['meta'] ) ? $link['meta'] : array();
		$protected = ! empty( $meta['pin_hash'] );
		if ( $protected ) {
			$target = $card['url'];
		} elseif ( 'legal' === $link['link_type'] ) {
			$target = $this->step_url( $link, 'legal' );
		} else {
			$target = 'instagram' === $link['link_type'] && ! empty( $link['media_url'] ) ? $link['media_url'] : $link['destination'];
		}
		$target = esc_url_raw( (string) $target );

		// Do not let a page cache reuse a human redirect for a crawler (or
		// crawler HTML for a human). Preview responses are generated per request.
		header( 'Content-Type: text/html; charset=UTF-8' );
		header( 'Vary: User-Agent', false );
		header( 'Cache-Control: private, no-store, no-cache, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Credit-Control-Preview: 1' );

		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
		// A document card takes its icon from the source page. Falling back to
		// this install's mark would put a WordPress-style favicon on a card that
		// is meant to read as the source site, so nothing is printed when the
		// source has no icon of its own.
		if ( $card['icon'] && 'legal' !== $link['link_type'] ) {
			echo '<link rel="icon" href="' . esc_url( $card['icon'] ) . '">';
		}
		$this->print_share_meta( $card );
		echo '</head><body><p><a href="' . esc_url( $target ? $target : $card['url'] ) . '">' . esc_html__( 'Open shared link', 'cloaklink' ) . '</a></p></body></html>';
	}

	/**
	 * Read the JSON payload sent by the resolver page.
	 *
	 * @return array|string Decoded data or error code.
	 */
	private function read_payload() {
		$raw = '';
		if ( ! empty( $_POST['payload'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$raw = wp_unslash( $_POST['payload'] ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		}
		if ( '' === $raw ) {
			$body = file_get_contents( 'php://input' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$raw  = (string) $body;
		}
		if ( '' === trim( (string) $raw ) ) {
			return array();
		}
		$data = json_decode( (string) $raw, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Optional POST fields (non-JSON form submission).
	 *
	 * @return array
	 */
	private function post_payload() {
		$out = array();
		// phpcs:disable WordPress.Security.NonceVerification
		foreach ( array( 'lat', 'lng', 'accuracy', 'gps_error', 'screen', 'viewport', 'tz', 'lang', 'uuid', 'dwell' ) as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$out[ $key ] = is_string( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : $_POST[ $key ];
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification
		return $out;
	}

	/**
	 * Has this device already opened the link (single-device mode)?
	 *
	 * @param array $link Link row.
	 * @param array $row  Visit row.
	 * @return bool
	 */
	private function device_already_seen( $link, $row ) {
		$seen = $this->db->count_link_visits_for_hash( $link['id'], $row['ip_hash'] );
		return $seen > 0;
	}

	/**
	 * Very light per-IP rate limit using transients.
	 *
	 * @param string $ip IP.
	 * @return bool
	 */
	private function is_rate_limited( $ip ) {
		$limit = (int) $this->settings->get( 'rate_limit', 40 );
		if ( $limit < 1 ) {
			return false;
		}
		$key   = 'cloaklink_rl_' . md5( $ip . '|' . gmdate( 'YmdHi' ) );
		$count = (int) get_transient( $key );
		set_transient( $key, $count + 1, 2 * MINUTE_IN_SECONDS );
		return $count > $limit;
	}

	/**
	 * One short mail saying a visitor was turned away.
	 *
	 * Deliberately not a copy of the capture alert: this is the answer to "is
	 * my blocklist working", so it carries the reason, the address and the
	 * link, and nothing else. Sent only when the Advanced screen asks for it.
	 *
	 * @param string     $code   Refusal code.
	 * @param string     $status Stored status.
	 * @param array|null $link   Link row.
	 * @return void
	 */
	private function mail_refusal( $code, $status, $link ) {
		$to = (string) $this->settings->get( 'security_alert_email', '' );
		if ( ! is_email( $to ) ) {
			$to = (string) $this->settings->get( 'notify_email', '' );
		}
		if ( ! is_email( $to ) ) {
			return;
		}

		$title = $link && ! empty( $link['title'] ) ? (string) $link['title'] : __( 'A shared link', 'cloaklink' );
		$lines = array(
			__( 'A visitor was turned away.', 'cloaklink' ),
			'',
			sprintf( /* translators: %s: link title */ __( 'Link: %s', 'cloaklink' ), $title ),
			sprintf( /* translators: %s: reason */ __( 'Reason: %s', 'cloaklink' ), $this->reason_text( $code ) ),
			sprintf( /* translators: %s: network address */ __( 'Network: %s', 'cloaklink' ), CloakLink_Geo::ip() ),
			sprintf( /* translators: %s: recorded status */ __( 'Recorded as: %s', 'cloaklink' ), (string) $status ),
			'',
			CloakLink_Admin::url( 'visits' ),
		);

		wp_mail(
			$to,
			$this->adv_subject( __( 'Visitor refused', 'cloaklink' ) ),
			implode( "\n", $lines )
		);
	}

	/**
	 * One short mail saying a visitor was turned away.
	 *
	 * @param string $subject Subject as built.
	 * @return string
	 */
	private function adv_subject( $subject ) {
		return function_exists( 'cloaklink' ) ? cloaklink()->adv->subject( $subject ) : $subject;
	}

	/**
	 * Human text for a gate failure.
	 *
	 * @param string $code Error code.
	 * @return string
	 */
	public function reason_text( $code ) {
		$map = array(
			'location_required' => __( 'Location access is required before this link can open. Please allow location and try again.', 'cloaklink' ),
			'rate_limited'      => __( 'Too many requests. Please wait a minute and try again.', 'cloaklink' ),
			'blocked_ip'        => __( 'Access from this network has been restricted.', 'cloaklink' ),
			'blocked_country'   => __( 'This link is not available in your region.', 'cloaklink' ),
			'country_gate'      => __( 'This link is not available in your region.', 'cloaklink' ),
			'vpn'               => __( 'Please turn off your VPN or proxy and try again.', 'cloaklink' ),
			'proxy'             => __( 'Please turn off your VPN or proxy and try again.', 'cloaklink' ),
			'bot'               => __( 'Automated access is not permitted.', 'cloaklink' ),
			'device_locked'     => __( 'This link is already linked to another device.', 'cloaklink' ),
			'bad_request'       => __( 'The request could not be verified. Please reopen the link.', 'cloaklink' ),
			'not_found'         => __( 'This link is no longer available.', 'cloaklink' ),
		);
		return isset( $map[ $code ] ) ? $map[ $code ] : __( 'The link could not be opened.', 'cloaklink' );
	}

	/**
	 * What the support desk is doing right now, as the public page must see it.
	 *
	 * The panel switch and the Settings panel both write the one option this
	 * reads, so the public page can never be told something different from
	 * what the operator set. A busy or closed desk is reported here and the
	 * page says so before it touches a camera or a microphone.
	 *
	 * @return array status, message, hours, name.
	 */
	public function desk_state() {
		// One reader for this, so the page and the endpoint cannot disagree.
		return cloaklink()->support->desk_state();
	}

	/**
	 * Brand strings for public pages.
	 *
	 * @return array
	 */
	public function brand() {
		return array(
			'name'    => (string) $this->settings->get( 'brand_name' ),
			'tagline' => (string) $this->settings->get( 'brand_tagline' ),
			'note'    => (string) $this->settings->get( 'brand_note' ),
			'phone'   => (string) $this->settings->get( 'brand_phone' ),
			'email'   => (string) $this->settings->get( 'brand_email' ),
		);
	}

	/**
	 * Output JSON and stop.
	 *
	 * @param array $data Payload.
	 * @return void
	 */
	private function send_json( $data ) {
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		echo wp_json_encode( $data );
		exit;
	}

	/**
	 * Render a template with variables.
	 *
	 * @param string $view View name.
	 * @param array  $vars Variables.
	 * @return void
	 */
	public function render( $view, $vars ) {
		// A template name, optionally in a subfolder ("partials/scene"), and
		// nothing else: no leading separator, no dots in any segment. The
		// resolved path is then confirmed to still be inside the views folder,
		// which is what actually stops traversal. Refusing the slash as well
		// would break every partial-template call.
		$view = trim( (string) $view, '/' );
		if ( '' === $view || ! preg_match( '#^[a-z0-9_-]+(/[a-z0-9_-]+)*$#i', $view ) ) {
			$this->render_404();
			return;
		}

		$base = realpath( CLOAKLINK_DIR . 'views/public' );
		$file = CLOAKLINK_DIR . 'views/public/' . $view . '.php';
		$real = realpath( $file );

		if ( ! $base || ! $real || 0 !== strpos( $real, $base . DIRECTORY_SEPARATOR ) || ! is_file( $real ) ) {
			$this->render_404();
			return;
		}
		$file = $real;
		$GLOBALS['cloaklink_view'] = $vars;
		include $file;
	}

	/**
	 * Emit a bare 404 with no site chrome.
	 *
	 * @param string $message Empty, or one of the view's own keys: 'expired'
	 *                        and 'deleted' add a sentence, everything else
	 *                        stays a plain 404.
	 * @return void
	 */
	public function render_404( $message = '' ) {
		nocache_headers();
		status_header( 404 );
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Referrer-Policy: no-referrer' );
		$GLOBALS['cloaklink_view'] = array( 'message' => (string) $message );
		include CLOAKLINK_DIR . 'views/public/404.php';
		exit;
	}
}
