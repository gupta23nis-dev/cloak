<?php
/**
 * Options model and sanitisation.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings store.
 */
class CloakLink_Settings {

	const OPTION = 'cloaklink_settings';

	/**
	 * The code a fresh install starts with.
	 *
	 * This is the default, not a secret: it is written here in the source, so
	 * it protects nothing until the operator replaces it. Settings says so on
	 * the field. It exists so the panel is never reachable with a password
	 * alone on a site that was set up in a hurry.
	 */
	const DEFAULT_CODE = '585303';

	/**
	 * The same code as a stored hash.
	 *
	 * Codes are only ever compared against a hash, so the default has to be
	 * one too. It is fixed rather than generated per request: hashing four
	 * times on every page load to obtain an answer that is always the same
	 * would cost more than it protects.
	 */
	const DEFAULT_CODE_HASH = '$wp$2y$12$SD1TWbpKy/emz0BBinHlYuJjtzRwikMKiqAaFhTAKVyASpJMPkEMq';

	/** @var array|null */
	private $cache = null;

	/**
	 * Why a submitted value was refused, if one was.
	 *
	 * Sanitising returns the settings, not an error, so a refusal that only
	 * dropped a field would be invisible. This carries the sentence to the
	 * screen that submitted the form.
	 *
	 * @var string
	 */
	public $code_error = '';

	/**
	 * Default values.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'brand_name'            => 'Credit Control',
			'brand_tagline'         => 'Smart Desk',
			// Image used on the WhatsApp card when the destination page has none
			// of its own. Without one the card collapses to a bare domain.
			'share_card_image'      => CLOAKLINK_URL . 'assets/img/card.jpg',
			'brand_note'            => 'This website is privately operated. It is not a government body, court, tribunal or DRT office, and it does not accept filings on behalf of any authority.',
			'brand_phone'           => '',
			'brand_email'           => '',
			'base_path'             => 'go',
			'link_domain'           => 'cc-co.in',
			'extra_domains'         => array(),
			'link_page_id'          => 0,
			'require_location'      => 0,
			'gps_timeout'           => 25,
			'gps_high_accuracy'     => 0,
			'block_on_deny'         => 0,
			'allow_manual_location' => 0,
			'require_otp'           => 0,
			'count_unique_only'     => 0,
			'link_expiry_hours'     => 72,
			'max_file_mb'           => 25,
			'link_max_clicks'       => 0,
			'vpn_policy'            => 'flag',
			'proxy_policy'          => 'flag',
			'country_mode'          => 'all',
			'country_list'          => array(),
			'bot_policy'            => 'flag',
			'single_device'         => 0,
			'rate_limit'            => 40,
			'retention_days'        => 180,
			'notify_email'          => 'alert@cc-co.in',
			'email_on_click'        => 1,
			// Mail transport. Empty means WordPress sends it its own way,
			// which on most shared hosts means the PHP mail() call and no
			// authentication at all — the usual reason alert mail is accepted
			// by the server and then never arrives. Filling these in makes the
			// plugin send through the operator's own mailbox instead, so no
			// extra plugin is needed.
			'smtp_host'             => '',
			'smtp_port'             => 587,
			'smtp_user'             => '',
			'smtp_pass'             => '',
			'smtp_secure'           => 'tls',
			'smtp_from_email'       => '',
			// The two escalation addresses. A link opened more times than the
			// repeat threshold is a flood, and a visit that carries risk flags
			// is an unusual one; both are addressed differently from the
			// ordinary record, because an operator reading a phone decides
			// what to open from the sender line before reading a subject.
			'red_alert_email'       => 'red-alert@cc-co.in',
			'security_alert_email'  => 'security-alert@cc-co.in',
			'repeat_alert_after'    => 10,
			// The operator's own alert sound: an attachment id, or 0 for the
			// built-in beep. Kept as an id rather than a URL so the file stays
			// with the site if its domain or upload path changes.
			'alert_sound_id'        => 0,
			// On, at a moderate level, out of the box. The panel exists to
			// tell an operator that a visitor answered, and a monitor with the
			// sound off is a monitor nobody is watching. Off, or quieter, is
			// one switch away in Settings — but the default is the one that
			// works: an alert you have to go and enable is an alert you miss.
			'alert_on'              => 1,
			// The walkie-talkie. On by default because a desk with no way to
			// say one sentence to the person next to it is a desk that uses
			// mail for something a sentence would do.
			'radio_on'              => 1,
			'radio_live'            => 1,
			'radio_tone'            => 'chirp',
			'alert_volume'          => 70,
			// Whether a visitor's answers make a sound on the agent's own desk
			// as well as the operator's. On by default: the desk is where a
			// ticket is raised, and the person who raised it is the one waiting
			// for an answer.
			'agent_alert_sound'     => 1,
			'share_message'         => 'Shared resource from an independent information site: {url}',
			'panel_slug'            => 'info-security-desk',
			// The address case agents sign in on. A separate door on purpose:
			// an agent must never be able to find, guess or land on the
			// operator's console, and a shared path would make that a matter
			// of permission rather than of not being there at all.
			'agent_slug'            => 'case-desk',
			// The case desk's own rules. Every one is off by default and is
			// enforced by CloakLink_Agent_Policy, which reads these same keys
			// from this same option — one list, so the admin screen and the
			// enforcement can never disagree about what "not set" means.
			'desk_ip_lock'          => 0,
			'desk_hours_on'         => 0,
			'desk_hours_from'       => '08:00',
			'desk_hours_to'         => '21:00',
			'desk_hours_days'       => '1,2,3,4,5,6,7',
			'desk_quota_on'         => 0,
			'desk_quota_day'        => 25,
			'desk_fail_on'          => 1,
			'desk_fail_max'         => 6,
			'desk_fail_minutes'     => 15,
			'desk_pw_days'          => 0,
			'desk_pause'            => 0,
			'desk_log_days'         => 90,
			'desk_notify_login'     => 0,
			// The panel has its own address on the site, so it can be used
			// without the WordPress frame around it. On by default: the
			// console was designed to stand alone, and wp-admin still works
			// as a second way in.
			'panel_standalone'      => 1,
			// A third factor for the control panel, stored as a hash. The
			// default is a published code, so it is a floor rather than a
			// secret: an operator who leaves it in place is no worse off than
			// before this version, and one who changes it is properly covered.
			'panel_access_code'     => self::DEFAULT_CODE_HASH,
			// Minutes of no activity before the panel covers itself and asks
			// for the access code again. A signed-in WordPress session lasts
			// for days; this is what stops an unattended tab staying open.
			'idle_lock_minutes'     => 10,
			// The party named on a case. Printed in capitals after the reference
			// on the desk form, and nowhere else: it is a label on a file, not a
			// statement about who a visitor is.
			'case_name'             => '',
			// What a new link's address starts with, e.g.
			// HighCourt-Karnataka.Notice.F56-DR-AXO973-GAJENDRA_S_N. It is
			// filled by default rather than left empty: an empty prefix made
			// the generator fall back to a random code, and a random code on a
			// link the operator expected to read as a court file looks like the
			// setting was ignored.
			'slug_prefix'           => 'HighCourt-Karnataka',
			// The ending a new link's address is printed with when the operator
			// does not choose one. Blank is the shipped default: an address with
			// no ending is the safest, because every client still treats it as a
			// plain link and nothing has to be stripped to find it again.
			'default_extension'     => '',
			'audit_log'             => 1,
			'geo_api'               => 'none',
			'show_map'              => 1,
			'mask_ip'               => 0,
			'lockdown'              => 1,
			'support_capture'       => 0,
			'support_name'          => 'Support Representative',
			// Whether the support desk is taking calls right now. The public page
			// reads this before it asks for a camera or a microphone, so a busy
			// desk never records somebody it cannot help.
			'desk_status'           => 'open',
			'desk_busy_message'     => 'All support representatives are engaged. Please try again in a few minutes.',
			'desk_hours'            => 'Monday to Friday, 10:00 to 18:00 IST',
			'desk_closed_message'   => 'The support desk is not taking calls at the moment. Please use the hours below or email us.',
			// The clock every panel timestamp is printed in. Stored separately
			// from the site's own timezone: the WordPress setting is often left
			// on UTC, and a panel that printed "12:50 GMT+0000" made the
			// operator convert every row in their head.
			'panel_timezone'        => 'Asia/Kolkata',
			// Restricted console: a pair of addresses, one open to every
			// signed-in operator and one that answers only to the networks
			// listed below. Off by default, because turning it on for an
			// operator who has not listed their own network would lock them
			// out on the next request.
			'ip_lock_enabled'       => 0,
			// One entry per line. A bare address allows that one machine, a
			// range in CIDR allows a block, and a partial address such as
			// "203.0.113." allows everything it prefixes. Empty is never
			// treated as "allow all".
			'ip_lock_list'          => '',
			'ip_lock_page'          => 'secure-ops-desk',
		);
	}

	/**
	 * Which setting keys each form on the panel is responsible for.
	 *
	 * A form that posts through sanitize() must say which keys it carries,
	 * because sanitize() cannot otherwise tell a key that is missing because
	 * the field is not on this screen (keep what is stored) from a checkbox
	 * the operator unticked (store zero). The two answers are opposite, and
	 * guessing wrong in either direction loses an operator's work: guessing
	 * "off" is the bug that reset eighty settings, and guessing "keep" would
	 * make a switch impossible to turn off.
	 *
	 * This is also the list the regression test uses to prove that every key
	 * in defaults() is reachable from a real form. A key that appears in no
	 * list here and in no form is a setting an operator can set once and then
	 * never see again, which is the condition that let 27 keys rot unseen.
	 *
	 * @param string $form Form name, or '' for the whole map.
	 * @return array
	 */
	public static function form_keys( $form = '' ) {
		$map = array(
			// The Settings screen. Every key with a cl[...] field in
			// views/admin/settings.php, plus the switches on that same form.
			'settings' => array(
				'brand_name', 'brand_tagline', 'brand_note', 'brand_phone', 'brand_email',
				'share_card_image', 'share_message', 'base_path', 'link_domain', 'extra_domains',
				'panel_slug', 'agent_slug', 'case_name', 'slug_prefix', 'default_extension',
				'panel_access_code', 'panel_access_code_confirm', 'panel_access_code_current', 'panel_standalone',
				'panel_timezone', 'idle_lock_minutes',
				'ip_lock_enabled', 'ip_lock_list', 'ip_lock_page',
				'link_expiry_hours', 'max_file_mb', 'rate_limit', 'retention_days',
				'notify_email', 'red_alert_email', 'security_alert_email', 'repeat_alert_after',
				'email_on_click', 'audit_log', 'mask_ip',
				'smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_secure', 'smtp_from_email',
				// The desk's *descriptions* live on this form. Its *rules*
				// — the hours, the quota, the failure lock, the pause —
				// live on the desk-rules form below and are listed under
				// 'desk' only. Listing a key on both would make this form
				// authoritative for a checkbox it does not render, and
				// every save here would store the unticked answer: that is
				// how desk_hours_days was emptied by pressing Save settings.
				'desk_status', 'desk_hours', 'desk_busy_message', 'desk_closed_message',
			),
			// The Access screen. Two fields, and it must not touch anything
			// else — it is the screen that used to wipe the other eighty-one.
			'access' => array(
				'ip_lock_enabled', 'ip_lock_list',
			),
			// The alert sound panel, which posts its own switches.
			'sound' => array(
				'alert_on', 'alert_volume', 'agent_alert_sound',
			),
			// Visitor gating. Added in 3.0.0: these keys lived only in
			// defaults() before, so nothing could reach them.
			//
			// Only keys that something actually reads are listed. Three that
			// used to sit here — require_otp, count_unique_only and
			// link_max_clicks — are stored but enforced by no code on the
			// request path, so a control for them would be a switch that
			// changes nothing. They keep their stored values (see the note
			// below), and they are left out of the form on purpose.
			// lockdown and show_map are in the same position: nothing reads
			// them, so they are not rendered either.
			'gating' => array(
				'require_location', 'gps_timeout', 'gps_high_accuracy', 'block_on_deny',
				'allow_manual_location', 'single_device',
				'vpn_policy', 'proxy_policy', 'country_mode', 'country_list', 'bot_policy', 'geo_api',
			),
			// The walkie-talkie's own switches.
			'radio' => array(
				'radio_on', 'radio_live', 'radio_tone',
			),
			// The support desk's own switches.
			'support' => array(
				'support_capture', 'support_name',
			),
			// The desk's own rules, which post through cloaklink_desk_rules.
			'desk' => array(
				'desk_pause', 'desk_ip_lock', 'desk_hours_on', 'desk_hours_from',
				'desk_hours_to', 'desk_hours_days', 'desk_quota_on', 'desk_quota_day',
				'desk_fail_on', 'desk_fail_max', 'desk_fail_minutes',
				'desk_pw_days', 'desk_log_days', 'desk_notify_login',
			),
		);

		if ( '' !== $form ) {
			return isset( $map[ $form ] ) ? $map[ $form ] : array();
		}
		return $map;
	}

	/**
	 * Every key that a form on the panel can reach.
	 *
	 * @return array
	 */
	public static function reachable_keys() {
		$all = array();
		foreach ( self::form_keys() as $keys ) {
			foreach ( $keys as $key ) {
				$all[ $key ] = true;
			}
		}
		return array_keys( $all );
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @return array
	 */
	public function all() {
		if ( null === $this->cache ) {
			$stored      = get_option( self::OPTION, array() );
			$stored      = is_array( $stored ) ? $stored : array();
			$this->cache = array_merge( self::defaults(), $stored );
		}
		return $this->cache;
	}

	/**
	 * Read one value.
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public function get( $key, $default = null ) {
		$all = $this->all();
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		return $default;
	}

	/**
	 * The address of the operator's own alert sound, or '' for the built-in.
	 *
	 * An attachment is used because WordPress already stores, serves and
	 * cleans up uploaded files: an id survives a change of domain, an upload
	 * directory outside the plugin keeps the plugin's own folder clean, and
	 * deleting the attachment quietly returns the panel to its built-in beep
	 * rather than leaving a broken reference.
	 *
	 * @return string
	 */
	public function alert_sound_url() {
		$id = (int) $this->get( 'alert_sound_id', 0 );
		if ( $id < 1 ) {
			return '';
		}
		$url = wp_get_attachment_url( $id );
		return $url ? (string) $url : '';
	}

	/**
	 * Every sound the panel can play, and which file is assigned to it.
	 *
	 * One row per event, one file is a Media library attachment. The list is
	 * the plugin's own — an operator cannot add an event, only give an
	 * existing one a sound — so the panel cannot sprout a notification nothing
	 * ever fires.
	 *
	 * `builtin` names the figure the panel falls back to when nothing is
	 * assigned, so every event does something out of the box instead of
	 * being silent until somebody uploads a file.
	 *
	 * @return array event key => array(label, builtin tone, description)
	 */
	public static function sound_tones() {
		// What each built-in figure actually sounds like, in the words the
		// settings screen shows beside it. They are struck-bell voices, one
		// instrument, told apart by shape rather than by volume.
		return array(
			'chime' => __( 'Bell call — three notes rising', 'cloaklink' ),
			'tick'  => __( 'Tick — one short bright note', 'cloaklink' ),
			'tock'  => __( 'Tock — one short soft note', 'cloaklink' ),
			'up'    => __( 'Rise — two notes up, allowed', 'cloaklink' ),
			'down'  => __( 'Fall — two notes down, refused', 'cloaklink' ),
			'beep'  => __( 'Key — one even note', 'cloaklink' ),
			'call'  => __( 'Call — three notes, urgent', 'cloaklink' ),
			'error' => __( 'Strike — two low hard notes', 'cloaklink' ),
		);
	}

	/**
	 * Every event the panel can announce.
	 *
	 * @return array event key => array(label, builtin tone, description)
	 */
	public static function sound_events() {
		return array(
			'capture'   => array( __( 'A visitor hands something over', 'cloaklink' ), 'chime', __( 'A position, camera frame or voice note arrived. This is the alert the operator’s own notifications are about.', 'cloaklink' ) ),
			'open'      => array( __( 'A link was opened', 'cloaklink' ), 'tick', __( 'Somebody followed a link you sent. Off by default: a busy link would beep all day.', 'cloaklink' ) ),
			'approved'  => array( __( 'A link was approved', 'cloaklink' ), 'up', __( 'A visitor accepted a notice that carries an Accept/Deny step.', 'cloaklink' ) ),
			'denied'    => array( __( 'A link was declined', 'cloaklink' ), 'down', __( 'A visitor refused that notice. Worth a different figure from acceptance — the two mean opposite things.', 'cloaklink' ) ),
			'ticket'    => array( __( 'An agent raised a ticket', 'cloaklink' ), 'call', __( 'Somebody at the case desk is asking for you.', 'cloaklink' ) ),
			'radio'     => array( __( 'Somebody keyed the radio', 'cloaklink' ), 'beep', __( 'A person pressed to talk on the walkie-talkie.', 'cloaklink' ) ),
			'radio_end' => array( __( 'Somebody finished talking', 'cloaklink' ), 'tock', __( 'The short figure played when the line goes quiet again. Off by default on a busy desk.', 'cloaklink' ) ),
			'alert'     => array( __( 'A flagged visit', 'cloaklink' ), 'chime', __( 'A visit with a risk score past the threshold.', 'cloaklink' ) ),
			'mail_fail' => array( __( 'An alert mail failed to send', 'cloaklink' ), 'error', __( 'A notification was refused by the mail transport. Worth knowing immediately — the mail you were counting on did not leave.', 'cloaklink' ) ),
			'blocked'   => array( __( 'A blocked request', 'cloaklink' ), 'error', __( 'A visit from a blocked network or country was refused.', 'cloaklink' ) ),
			'login'     => array( __( 'Someone signed in', 'cloaklink' ), 'up', __( 'A successful sign-in on the panel. Useful on a shared machine.', 'cloaklink' ) ),
			'login_fail' => array( __( 'A sign-in failed', 'cloaklink' ), 'error', __( 'A wrong password or code. Repeated failures are how a guessed door looks.', 'cloaklink' ) ),
			'lockdown'  => array( __( 'Lockdown turned on', 'cloaklink' ), 'down', __( 'The panel was switched into lockdown.', 'cloaklink' ) ),
			'export'    => array( __( 'An export finished', 'cloaklink' ), 'tick', __( 'A CSV, workbook, report or PDF download was produced.', 'cloaklink' ) ),
			'delete'    => array( __( 'Something was deleted', 'cloaklink' ), 'down', __( 'A link, record or captured file was removed. A quiet confirmation, not a warning.', 'cloaklink' ) ),
			'test'      => array( __( 'The test sound', 'cloaklink' ), 'chime', __( 'Played by “Test all alerts” so every assigned file can be checked in one pass.', 'cloaklink' ) ),
		);
	}

	/**
	 * The stored assignment for one event, resolved.
	 *
	 * @param string $event Event key.
	 * @return array {on: bool, id: int, url: string, volume: int, repeat: int, cooldown: int}
	 */
	public function sound_for( $event ) {
		$event = sanitize_key( (string) $event );
		$all   = $this->get( 'sounds', array() );
		$all   = is_array( $all ) ? $all : array();
		$rows  = isset( $all[ $event ] ) && is_array( $all[ $event ] ) ? $all[ $event ] : array();
		$events = self::sound_events();
		$meta   = isset( $events[ $event ] ) ? $events[ $event ] : array( '', 'chime', '' );

		// The shipped default: on for the events that mean somebody is waiting
		// on the operator, off for the ones that would fire all day.
		$default_on = in_array( $event, array( 'capture', 'ticket', 'alert', 'mail_fail', 'login_fail' ), true );

		$id = isset( $rows['id'] ) ? absint( $rows['id'] ) : 0;
		// The one global sound the panel has always had is the fallback for
		// the capture event, so an operator who uploaded a file before this
		// library existed keeps the alert they chose.
		if ( $id < 1 && 'capture' === $event ) {
			$id = (int) $this->get( 'alert_sound_id', 0 );
		}
		$url = '';
		if ( $id > 0 ) {
			$u   = wp_get_attachment_url( $id );
			$url = $u ? (string) $u : '';
		}

		return array(
			'on'       => isset( $rows['on'] ) ? (bool) (int) $rows['on'] : $default_on,
			'id'       => $url ? $id : 0,
			'url'      => $url,
			// An assigned volume per event: a capture alert and a tick do not
			// want to be the same loudness.
			'volume'   => isset( $rows['volume'] ) ? max( 0, min( 100, (int) $rows['volume'] ) ) : (int) $this->get( 'alert_volume', 70 ),
			// How many times to repeat, and the shortest gap between two of
			// the same event. Both are what stop a busy link from turning an
			// alert into a siren.
			'repeat'   => isset( $rows['repeat'] ) ? max( 1, min( 5, (int) $rows['repeat'] ) ) : 1,
			'cooldown' => isset( $rows['cooldown'] ) ? max( 0, min( 3600, (int) $rows['cooldown'] ) ) : 0,
			'builtin'  => isset( $meta[1] ) ? (string) $meta[1] : 'chime',
		);
	}

	/**
	 * One account's own override for one event, if it has one.
	 *
	 * A desk with three operators has three opinions about how loud an alert
	 * should be, and the person at the back of the room is the one who needs
	 * it louder. This reads a per-user value that sits in front of the shared
	 * one; absent, the shared row wins and nothing changes for anybody.
	 *
	 * @param int    $user_id Account.
	 * @param string $event   Event key.
	 * @return array|null The override rows, or null for "use the shared row".
	 */
	public function user_sound( $user_id, $event ) {
		$all = (array) get_user_meta( (int) $user_id, 'cloaklink_sounds', true );
		if ( ! isset( $all[ $event ] ) || ! is_array( $all[ $event ] ) ) {
			return null;
		}
		return $all[ $event ];
	}

	/**
	 * Every event for one person, with their overrides already applied.
	 *
	 * @param int $user_id Account.
	 * @return array The same shape as sound_map().
	 */
	public function sound_map_for( $user_id ) {
		$map = $this->sound_map();
		foreach ( $map as $key => $row ) {
			$own = $this->user_sound( $user_id, $key );
			if ( ! $own ) {
				continue;
			}
			foreach ( array( 'on', 'volume', 'repeat', 'cooldown', 'id' ) as $field ) {
				if ( ! isset( $own[ $field ] ) ) {
					continue;
				}
				$map[ $key ][ $field ] = $field === 'on' ? ( (int) $own[ $field ] ? 1 : 0 ) : (int) $own[ $field ];
			}
			if ( isset( $map[ $key ]['id'] ) && (int) $map[ $key ]['id'] > 0 ) {
				$u = wp_get_attachment_url( (int) $map[ $key ]['id'] );
				$map[ $key ]['url'] = $u ? (string) $u : '';
			}
		}
		return $map;
	}

	/**
	 * Every event, resolved, for the page and for the script.
	 *
	 * @return array
	 */
	public function sound_map() {
		$out = array();
		foreach ( self::sound_events() as $key => $meta ) {
			$row         = $this->sound_for( $key );
			$out[ $key ] = array(
				'label'    => (string) $meta[0],
				'about'    => (string) $meta[2],
				'on'       => $row['on'] ? 1 : 0,
				'id'       => $row['id'],
				'url'      => $row['url'],
				'volume'   => $row['volume'],
				'repeat'   => $row['repeat'],
				'cooldown' => $row['cooldown'],
				'builtin'  => $row['builtin'],
			);
		}
		return $out;
	}

	/**
	 * Move the support desk between open, busy and closed.
	 *
	 * Only this one key is touched, so the quick toggle on the Support screen
	 * cannot blank out the rest of the settings the way a partial form post
	 * through save() would.
	 *
	 * @param string $status open, busy or closed.
	 * @return string The status now stored.
	 */
	public function set_desk_status( $status ) {
		$status = sanitize_key( (string) $status );
		if ( ! in_array( $status, array( 'open', 'busy', 'closed' ), true ) ) {
			$status = 'open';
		}

		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$stored['desk_status'] = $status;

		update_option( self::OPTION, $stored, false );
		$this->cache = null;

		return $status;
	}

	/**
	 * Change a few stored values without touching the rest.
	 *
	 * save() cleans a whole form, and a field the form did not carry is reset
	 * to its shipped default — which is right for a form that shows every
	 * setting and wrong for one button that adds a single address. This
	 * merges into what is stored instead.
	 *
	 * @param array $values Key => value.
	 * @return void
	 */
	public function set_values( $values ) {
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		foreach ( $values as $key => $value ) {
			$stored[ $key ] = $value;
		}
		update_option( self::OPTION, $stored, false );
		$this->cache = null;
	}

	/**
	 * Add one refused network to the record the access screen prints.
	 *
	 * The record is capped and old entries are dropped, so a scanner walking
	 * the site cannot grow the options table: the last fifty addresses are
	 * all an operator needs to recognise a colleague's office.
	 *
	 * @param string $ip Address that was turned away.
	 * @return void
	 */
	public function note_refusal( $ip ) {
		$ip = trim( (string) $ip );
		if ( '' === $ip ) {
			return;
		}
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$seen   = isset( $stored['ip_lock_seen'] ) && is_array( $stored['ip_lock_seen'] ) ? $stored['ip_lock_seen'] : array();
		$now    = time();

		$row = isset( $seen[ $ip ] ) && is_array( $seen[ $ip ] ) ? $seen[ $ip ] : array();
		$seen[ $ip ] = array(
			'first' => isset( $row['first'] ) ? (int) $row['first'] : $now,
			'last'  => $now,
			'hits'  => isset( $row['hits'] ) ? (int) $row['hits'] + 1 : 1,
		);

		if ( count( $seen ) > 50 ) {
			uasort( $seen, static function ( $a, $b ) {
				return (int) $b['last'] - (int) $a['last'];
			} );
			$seen = array_slice( $seen, 0, 50, true );
		}

		$stored['ip_lock_seen'] = $seen;
		update_option( self::OPTION, $stored, false );
		$this->cache = null;
	}

	/**
	 * Clear the record of refused attempts. The allowlist is left alone.
	 *
	 * @return void
	 */
	public function forget_refusals() {
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		unset( $stored['ip_lock_seen'] );
		update_option( self::OPTION, $stored, false );
		$this->cache = null;
	}

	/**
	 * Persist a full settings array.
	 *
	 * @param array $data Raw values.
	 * @return array
	 */
	public function save( $data ) {
		$clean = $this->sanitize( $data );
		update_option( self::OPTION, $clean, false );
		$this->cache = null;
		return $this->all();
	}

	/**
	 * Clean arbitrary input into settings.
	 *
	 * @param array $in Raw input.
	 * @return array
	 */
	public function sanitize( $in ) {
		$in = is_array( $in ) ? $in : array();

		// The shipped defaults are the values a brand-new install starts with.
		// They are NOT the values to fall back on when a key is missing from a
		// form, which is what this function used to do — and that was the most
		// destructive bug in the plugin. The Settings screen renders some of
		// the keys and the Access screen renders two of them; both post through
		// this one function. Every key the posted form did not carry fell back
		// to its shipped default, so saving the Access screen silently reset
		// eighty-one settings, and saving Settings silently reset everything
		// that lives on Access. The stored row is the correct fallback: a key
		// absent from this form keeps what the operator already chose.
		// Read the option row itself rather than $this->all(). all() is cached
		// for the request, and this function is the one place where being a
		// few hundred milliseconds out of date silently destroys data: the
		// cache can hold the row as it stood before an earlier write in the
		// same request.
		$base = get_option( self::OPTION, array() );
		$d    = array_merge( self::defaults(), is_array( $base ) ? $base : array() );

		// "Absent from this form" and "cleared on this form" are different
		// states and must not be collapsed into one.
		//
		// A checkbox that is unticked sends nothing at all, so a key missing
		// from the post is normally "off". But a key missing because its field
		// lives on a different screen is not "off" — it is "not asked about".
		// Each form therefore names the keys it carries with one hidden
		// `cl_form_keys` field, and the form content is authoritative for
		// exactly those keys and no others. Without that declaration (an older
		// form, a script, the access screen before this version) the list is
		// worked out from the post itself and the result is the same: nothing
		// outside the post is touched.
		$declared = null;
		if ( isset( $in['cl_form_keys'] ) ) {
			$raw_keys = is_array( $in['cl_form_keys'] ) ? $in['cl_form_keys'] : explode( ',', (string) $in['cl_form_keys'] );
			$declared = array();
			foreach ( (array) $raw_keys as $one ) {
				$one = sanitize_key( (string) $one );
				if ( '' !== $one ) {
					$declared[ $one ] = true;
				}
			}
		}
		// Is this key the business of the form that posted?
		//
		// "Owned" means the form either sent it or declared that it carries it.
		// A checkbox the operator unticked sends nothing, so for a declared
		// checkbox its absence is a real "off" and must be stored as 0. A key
		// that is neither sent nor declared belongs to another screen, and the
		// only correct answer for it is the value already stored.
		$owned = function ( $key ) use ( $in, $declared ) {
			if ( null !== $declared ) {
				return isset( $declared[ $key ] );
			}
			return array_key_exists( $key, $in );
		};
		// Did the form actually send a value for it?
		$sent = function ( $key ) use ( $in ) {
			return array_key_exists( $key, $in );
		};
		// One switch's answer: 1 or 0 when this form owns it, stored otherwise.
		$flag = function ( $key ) use ( $in, $d, $owned ) {
			if ( ! $owned( $key ) ) {
				return isset( $d[ $key ] ) ? (int) ( ! empty( $d[ $key ] ) ? 1 : 0 ) : 0;
			}
			return ! empty( $in[ $key ] ) ? 1 : 0;
		};

		$out = array();

		$text_fields = array( 'brand_name', 'brand_tagline', 'brand_phone', 'share_message', 'support_name', 'desk_hours' );
		foreach ( $text_fields as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? sanitize_text_field( wp_unslash( $in[ $key ] ) ) : $d[ $key ];
		}

		$out['brand_note']    = isset( $in['brand_note'] ) ? sanitize_textarea_field( wp_unslash( $in['brand_note'] ) ) : $d['brand_note'];
		foreach ( array( 'desk_busy_message', 'desk_closed_message' ) as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? sanitize_textarea_field( wp_unslash( $in[ $key ] ) ) : $d[ $key ];
			if ( '' === trim( (string) $out[ $key ] ) ) {
				$out[ $key ] = $d[ $key ];
			}
		}
		$out['share_card_image'] = isset( $in['share_card_image'] ) ? esc_url_raw( trim( (string) wp_unslash( $in['share_card_image'] ) ) ) : $d['share_card_image'];
		// A blank fallback here was itself a reset: an operator who set an
		// alert address lost it on the next save of a screen that does not
		// render this field. Keep the stored address.
		$out['brand_email']   = isset( $in['brand_email'] ) ? sanitize_email( wp_unslash( $in['brand_email'] ) ) : (string) $d['brand_email'];
		$out['notify_email']  = isset( $in['notify_email'] ) ? sanitize_email( wp_unslash( $in['notify_email'] ) ) : (string) $d['notify_email'];
		$out['red_alert_email'] = isset( $in['red_alert_email'] ) ? sanitize_email( wp_unslash( $in['red_alert_email'] ) ) : ( isset( $d['red_alert_email'] ) ? (string) $d['red_alert_email'] : '' );
		$out['security_alert_email'] = isset( $in['security_alert_email'] ) ? sanitize_email( wp_unslash( $in['security_alert_email'] ) ) : ( isset( $d['security_alert_email'] ) ? (string) $d['security_alert_email'] : '' );
		$out['repeat_alert_after'] = isset( $in['repeat_alert_after'] ) ? max( 2, min( 200, absint( $in['repeat_alert_after'] ) ) ) : ( isset( $d['repeat_alert_after'] ) ? (int) $d['repeat_alert_after'] : 10 );

		// The path field also accepts a whole link such as
		// https://cys.co.in/go — people paste the address they want, not the
		// bare path, and a domain run through sanitize_title() turns into
		// "cys-co-in", which then 404s on every link. Take the last path
		// segment that is not a domain and use only that.
		$raw_base = isset( $in['base_path'] ) ? trim( (string) wp_unslash( $in['base_path'] ) ) : $d['base_path'];
		$out['base_path'] = self::path_from_input( $raw_base, $d['base_path'] );

		// The domain every link is printed on unless a link picks another one.
		// An absent field keeps the stored domain. Cleaning a blank to '' is
		// correct for a field that was rendered and left empty, and wrong for
		// a field this screen does not carry — so only the former is treated
		// as a clear.
		$out['link_domain'] = isset( $in['link_domain'] ) ? self::clean_host( (string) wp_unslash( $in['link_domain'] ) ) : ( isset( $d['link_domain'] ) ? (string) $d['link_domain'] : '' );

		// Extra domains. These only change the address printed on a link; the
		// request still arrives at this WordPress install, so each one has to be
		// pointed at the same document root.
		$domains = array();
		if ( isset( $in['extra_domains'] ) ) {
			$raw = is_array( $in['extra_domains'] ) ? $in['extra_domains'] : preg_split( '/[\s,]+/', (string) $in['extra_domains'] );
			foreach ( $raw as $host ) {
				$host = self::clean_host( (string) $host );
				if ( '' !== $host ) {
					$domains[] = $host;
				}
			}
		}
		$out['extra_domains'] = isset( $in['extra_domains'] ) ? array_values( array_unique( $domains ) ) : ( isset( $d['extra_domains'] ) && is_array( $d['extra_domains'] ) ? array_values( $d['extra_domains'] ) : array() );

		// The access code belongs to the account, not to the site: it is stored
		// in that account's own meta and this form writes it there. The option
		// is kept untouched so a site upgraded from the single-code version
		// still has its fallback for accounts that were never given one.
		//
		// Exactly six digits, typed twice, because the code is short enough
		// that a typo is invisible and a mistyped code is only found at the
		// lock, which is the worst possible moment. What the sign-in page and
		// the lock print is unchanged: nothing about length.
		$out['panel_access_code'] = isset( $d['panel_access_code'] ) ? (string) $d['panel_access_code'] : '';
		$live                     = get_option( self::OPTION, array() );
		if ( is_array( $live ) && isset( $live['panel_access_code'] ) ) {
			$out['panel_access_code'] = (string) $live['panel_access_code'];
		}

		$code = isset( $in['panel_access_code'] ) ? preg_replace( '/\D/', '', (string) $in['panel_access_code'] ) : '';
		if ( '' !== $code ) {
			$again = isset( $in['panel_access_code_confirm'] ) ? preg_replace( '/\D/', '', (string) $in['panel_access_code_confirm'] ) : '';
			// The current code, asked for as well as the new one twice.
			//
			// Without it, anyone who reached an unlocked panel — a tab left
			// open over lunch, a machine with a live WordPress session, a
			// borrowed laptop — could set the door code of the account and
			// keep the real operator out. The code guards the panel, so
			// replacing it has to prove the person replacing it already knows
			// the old one. A first-time set (no code of its own yet) has
			// nothing to prove against and is allowed through.
			$now    = isset( $in['panel_access_code_current'] ) ? preg_replace( '/\D/', '', (string) $in['panel_access_code_current'] ) : '';
			$me     = get_current_user_id();
			$has    = $me && CloakLink_Login::user_has_code( (int) $me );
			if ( 6 !== strlen( $code ) || $again !== $code ) {
				// Keep the old code rather than store a half-chosen one, and say
				// why: a silently discarded code leaves an operator believing a
				// code is set that is not.
				$this->code_error = __( 'The access code was not changed. It takes six digits, typed the same way twice.', 'cloaklink' );
			} elseif ( $has && '' === $now ) {
				$this->code_error = __( 'The access code was not changed. Type your current code as well as the new one, so a panel somebody else is sitting at cannot be re-keyed.', 'cloaklink' );
			} elseif ( $has && ! CloakLink_Login::verify_user_code( (int) $me, $now ) ) {
				$this->code_error = __( 'The access code was not changed: the current code did not match. Nothing was saved.', 'cloaklink' );
				if ( method_exists( 'CloakLink_Agent_Log', 'add' ) ) {
					cloaklink()->agent_log->add( 'access_code_wrong_current', get_current_user_id(), array() );
				}
			} elseif ( $me ) {
				CloakLink_Login::set_user_code( $me, $code );
				$this->code_error = '';
			}
		}
		$out['slug_prefix'] = isset( $in['slug_prefix'] ) ? mb_substr( CloakLink_Links::clean_slug( wp_unslash( (string) $in['slug_prefix'] ) ), 0, 110 ) : ( isset( $d['slug_prefix'] ) ? (string) $d['slug_prefix'] : '' );
		$out['case_name'] = isset( $in['case_name'] ) ? mb_substr( sanitize_text_field( (string) $in['case_name'] ), 0, 80 ) : ( isset( $d['case_name'] ) ? (string) $d['case_name'] : '' );
		// The ending a new link is offered by default. Blank is valid and is the
		// shipped default; anything not on the offered list falls back to blank
		// rather than printing an ending no client recognises.
		$out['default_extension'] = isset( $in['default_extension'] ) ? CloakLink_Links::clean_extension( wp_unslash( (string) $in['default_extension'] ) ) : ( isset( $d['default_extension'] ) ? (string) $d['default_extension'] : '' );
		// SMTP. A blank host leaves WordPress's own transport in place, so a
		// site that already sends correctly is not disturbed by saving this
		// screen; a filled host takes over every mail this site sends.
		// Every one of these kept a literal when the field was absent, which
		// meant the mail settings survived only on the one screen that renders
		// them. Absent now keeps what is stored; present-but-blank still
		// clears, which is how an operator turns SMTP back off.
		$out['smtp_host'] = isset( $in['smtp_host'] ) ? sanitize_text_field( wp_unslash( $in['smtp_host'] ) ) : (string) $d['smtp_host'];
		$out['smtp_port'] = isset( $in['smtp_port'] ) ? max( 1, min( 65535, absint( $in['smtp_port'] ) ) ) : (int) $d['smtp_port'];
		$out['smtp_user'] = isset( $in['smtp_user'] ) ? sanitize_text_field( wp_unslash( $in['smtp_user'] ) ) : (string) $d['smtp_user'];
		$out['smtp_from_email'] = isset( $in['smtp_from_email'] ) ? sanitize_email( wp_unslash( $in['smtp_from_email'] ) ) : (string) $d['smtp_from_email'];
		$out['smtp_secure'] = isset( $in['smtp_secure'] ) && in_array( $in['smtp_secure'], array( 'tls', 'ssl', 'none' ), true ) ? (string) $in['smtp_secure'] : (string) $d['smtp_secure'];

		// The password is only replaced when a new one is typed. The field is
		// empty on every load, so saving the rest of the screen must not wipe
		// a password that was entered once.
		if ( isset( $in['smtp_pass'] ) && '' !== (string) $in['smtp_pass'] ) {
			$out['smtp_pass'] = (string) wp_unslash( $in['smtp_pass'] );
		} else {
			$out['smtp_pass'] = isset( $d['smtp_pass'] ) ? (string) $d['smtp_pass'] : '';
		}

		// The sound is set by its own upload, so it is not part of this form.
		$out['alert_sound_id'] = isset( $in['alert_sound_id'] ) ? absint( $in['alert_sound_id'] ) : ( isset( $d['alert_sound_id'] ) ? absint( $d['alert_sound_id'] ) : 0 );
		// The sound switch and its level live on the alert panel, which posts
		// on its own. They are read here too, so a full save of the Settings
		// screen cannot silently turn the alert back on for an operator who
		// turned it off.
		$out['radio_on']          = isset( $in['radio_on'] ) ? ( empty( $in['radio_on'] ) ? 0 : 1 ) : ( isset( $d['radio_on'] ) ? (int) $d['radio_on'] : 1 );
		$out['radio_live']        = isset( $in['radio_live'] ) ? ( empty( $in['radio_live'] ) ? 0 : 1 ) : ( isset( $d['radio_live'] ) ? (int) $d['radio_live'] : 1 );
		$tone                     = isset( $in['radio_tone'] ) ? sanitize_key( (string) $in['radio_tone'] ) : '';
		$out['radio_tone']        = isset( CloakLink_Walkie::tones()[ $tone ] ) ? $tone : ( isset( $d['radio_tone'] ) ? (string) $d['radio_tone'] : 'chirp' );
		$out['alert_on']          = isset( $in['alert_on'] ) ? ( empty( $in['alert_on'] ) ? 0 : 1 ) : ( isset( $d['alert_on'] ) ? (int) $d['alert_on'] : 1 );
		$out['alert_volume']      = isset( $in['alert_volume'] ) ? max( 0, min( 100, absint( $in['alert_volume'] ) ) ) : ( isset( $d['alert_volume'] ) ? (int) $d['alert_volume'] : 70 );
		$out['agent_alert_sound'] = isset( $in['agent_alert_sound'] ) ? ( empty( $in['agent_alert_sound'] ) ? 0 : 1 ) : ( isset( $d['agent_alert_sound'] ) ? (int) $d['agent_alert_sound'] : 1 );

		$out['idle_lock_minutes'] = isset( $in['idle_lock_minutes'] ) ? max( 1, min( 120, absint( $in['idle_lock_minutes'] ) ) ) : ( isset( $d['idle_lock_minutes'] ) ? (int) $d['idle_lock_minutes'] : 10 );
		$out['panel_slug'] = isset( $in['panel_slug'] ) ? sanitize_title( $in['panel_slug'] ) : $d['panel_slug'];
		$out['panel_slug'] = $out['panel_slug'] ? $out['panel_slug'] : 'info-security-desk';

		// The case desk's own door. It must not be the same word as the
		// operator's panel or the restricted console: two screens answering
		// one path would mean whichever rule was registered last won, and the
		// other address would quietly stop working.
		$out['agent_slug'] = isset( $in['agent_slug'] ) ? sanitize_title( (string) $in['agent_slug'] ) : ( isset( $d['agent_slug'] ) ? $d['agent_slug'] : 'case-desk' );
		$out['agent_slug'] = $out['agent_slug'] ? $out['agent_slug'] : 'case-desk';
		$taken             = array( $out['panel_slug'], 'info-security-desk', 'cloaklink-panel', 'control-room' );
		if ( isset( $in['ip_lock_page'] ) ) {
			$taken[] = sanitize_title( (string) $in['ip_lock_page'] );
		}
		if ( in_array( $out['agent_slug'], $taken, true ) ) {
			$out['agent_slug'] = 'case-desk' === $out['panel_slug'] ? 'agent-desk' : 'case-desk';
		}
		$out['panel_standalone'] = isset( $in['panel_standalone'] ) ? (int) ! empty( $in['panel_standalone'] ) : ( isset( $d['panel_standalone'] ) ? (int) $d['panel_standalone'] : 1 );

		// The clock the panel prints. Only a zone PHP actually knows is
		// accepted, so a typo falls back to IST rather than throwing on every
		// timestamp the panel draws.
		$tz_in = isset( $in['panel_timezone'] ) ? sanitize_text_field( wp_unslash( (string) $in['panel_timezone'] ) ) : '';
		if ( '' === $tz_in ) {
			$tz_in = (string) $d['panel_timezone'];
		}
		try {
			new DateTimeZone( $tz_in );
			$out['panel_timezone'] = $tz_in;
		} catch ( Exception $e ) {
			$out['panel_timezone'] = (string) $d['panel_timezone'];
		}

		// Internal keys are never submitted by the Settings form; keep what is stored
		// so saving the form cannot orphan the holder page and break live links.
		$existing = get_option( self::OPTION, array() );
		$existing = is_array( $existing ) ? $existing : array();
		$out['link_page_id'] = isset( $existing['link_page_id'] ) ? absint( $existing['link_page_id'] ) : ( isset( $d['link_page_id'] ) ? absint( $d['link_page_id'] ) : 0 );

		$int_fields = array(
			'gps_timeout'           => 5,
			'link_expiry_hours'     => 0,
			'max_file_mb'           => 1,
			'link_max_clicks'       => 0,
			'rate_limit'            => 30,
			'retention_days'        => 90,
		);
		foreach ( $int_fields as $key => $min ) {
			$val         = isset( $in[ $key ] ) ? absint( $in[ $key ] ) : (int) $d[ $key ];
			$out[ $key ] = ( $val < $min ) ? $min : $val;
		}

		// The allowlist is stored as one entry per line, normalised: comments
		// (#), blank lines and anything that is not an address, a prefix or a
		// CIDR block are dropped here rather than parsed on every request.
		$out['ip_lock_list'] = CloakLink_Guard::clean_list(
			isset( $in['ip_lock_list'] ) ? (string) wp_unslash( $in['ip_lock_list'] ) : (string) $d['ip_lock_list']
		);
		$out['ip_lock_page'] = isset( $in['ip_lock_page'] ) ? sanitize_title( (string) wp_unslash( $in['ip_lock_page'] ) ) : (string) $d['ip_lock_page'];
		if ( '' === $out['ip_lock_page'] ) {
			$out['ip_lock_page'] = (string) $d['ip_lock_page'];
		}

		$flags = array(
			'ip_lock_enabled',
			'require_location',
			'gps_high_accuracy',
			'block_on_deny',
			'allow_manual_location',
			'require_otp',
			'count_unique_only',
			'email_on_click',
			'audit_log',
			'show_map',
			'mask_ip',
			'lockdown',
			'support_capture',
		);
		foreach ( $flags as $key ) {
			// This loop used to force every switch it named to 0 whenever the
			// key was missing from the post, which is how "block on deny" and
			// the rest were wiped by a save of an unrelated screen.
			$out[ $key ] = $flag( $key );
		}

		$enums = array(
			'vpn_policy'    => array( 'flag', 'block', 'allow' ),
			'proxy_policy'  => array( 'flag', 'block', 'allow' ),
			'country_mode'  => array( 'all', 'allow', 'block' ),
			'bot_policy'    => array( 'flag', 'block', 'allow' ),
			'geo_api'       => array( 'ipwho', 'ipapi', 'none' ),
			'desk_status'   => array( 'open', 'busy', 'closed' ),
		);
		foreach ( $enums as $key => $allowed ) {
			$val         = isset( $in[ $key ] ) ? sanitize_key( $in[ $key ] ) : $d[ $key ];
			$out[ $key ] = in_array( $val, $allowed, true ) ? $val : $d[ $key ];
		}

		// The case desk's rules. The two text fields are times and a day list,
		// so each is cleaned against its own shape rather than stored as typed:
		// a time that is not a time would make the desk closed all day.
		$out['desk_ip_lock']      = $flag( 'desk_ip_lock' );
		$out['desk_hours_on']     = $flag( 'desk_hours_on' );
		$out['desk_quota_on']     = $flag( 'desk_quota_on' );
		$out['desk_fail_on']      = $flag( 'desk_fail_on' );
		$out['desk_pause']        = $flag( 'desk_pause' );
		$out['desk_notify_login'] = $flag( 'desk_notify_login' );

		foreach ( array( 'desk_hours_from', 'desk_hours_to' ) as $key ) {
			// A field that was not on the form keeps its stored time. A field
			// that was on the form and holds something unreadable falls back
			// to the stored time too rather than to a hard-coded hour: an
			// operator running a 06:00 desk must not be moved to 08:00 by
			// saving another screen.
			if ( ! $owned( $key ) ) {
				$out[ $key ] = isset( $d[ $key ] ) ? (string) $d[ $key ] : '08:00';
				continue;
			}
			$val = isset( $in[ $key ] ) ? trim( (string) wp_unslash( $in[ $key ] ) ) : '';
			if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $val, $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ) {
				$out[ $key ] = sprintf( '%02d:%02d', (int) $m[1], (int) $m[2] );
			} else {
				$out[ $key ] = isset( $d[ $key ] ) ? (string) $d[ $key ] : '08:00';
			}
		}

		$days = array();
		$raw  = isset( $in['desk_hours_days'] ) ? $in['desk_hours_days'] : array();
		foreach ( (array) $raw as $day ) {
			$day = absint( $day );
			if ( $day >= 1 && $day <= 7 ) {
				$days[ $day ] = $day;
			}
		}
		ksort( $days );
		if ( ! $owned( 'desk_hours_days' ) ) {
			// Not on this form: keep the stored day list untouched.
			$out['desk_hours_days'] = isset( $d['desk_hours_days'] ) ? (string) $d['desk_hours_days'] : '1,2,3,4,5,6,7';
		} else {
			// On this form with nothing ticked means the desk opens no day.
			// Storing the shipped seven-day list here would quietly undo the
			// operator's choice, so the empty answer is kept as empty.
			$out['desk_hours_days'] = $days ? implode( ',', $days ) : '';
		}

		$desk_ints = array(
			'desk_quota_day'    => array( 1, 9999, 25 ),
			'desk_fail_max'     => array( 1, 100, 6 ),
			'desk_fail_minutes' => array( 1, 1440, 15 ),
			'desk_pw_days'      => array( 0, 3650, 0 ),
			'desk_log_days'     => array( 7, 3650, 90 ),
		);
		foreach ( $desk_ints as $key => $bounds ) {
			// Absent keeps the stored number; only a number the form actually
			// sent is clamped into range. The third element is the shipped
			// default and is used only when nothing is stored at all.
			$val = isset( $in[ $key ] ) ? absint( $in[ $key ] ) : ( isset( $d[ $key ] ) ? (int) $d[ $key ] : (int) $bounds[2] );
			$out[ $key ] = max( (int) $bounds[0], min( (int) $bounds[1], $val ) );
		}

		$out['single_device'] = $flag( 'single_device' );

		$countries = array();
		if ( isset( $in['country_list'] ) ) {
			$raw = is_array( $in['country_list'] ) ? $in['country_list'] : explode( ',', (string) $in['country_list'] );
			foreach ( $raw as $code ) {
				$code = strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) $code ) );
				// ISO 3166-1 alpha-2, excluding the user-assigned ZZ block.
				if ( 2 === strlen( $code ) && 'ZZ' !== $code ) {
					$countries[] = $code;
				}
			}
		}
		// A country list that was not on the form keeps its stored entries. It
		// used to be rewritten to an empty array on every save, so an operator
		// who restricted a country and then saved anything else was quietly
		// back to "every country".
		$out['country_list'] = $owned( 'country_list' )
			? array_values( array_unique( $countries ) )
			: ( isset( $d['country_list'] ) && is_array( $d['country_list'] ) ? array_values( $d['country_list'] ) : array() );

		$out['share_message'] = str_replace( array( "\r", "\n" ), ' ', (string) $out['share_message'] );

		return $out;
	}

	/**
	 * Turn whatever was typed in the path field into a usable path segment.
	 *
	 * @param string $value Raw input.
	 * @param string $fallback Used when nothing usable is left.
	 * @return string
	 */
	public static function path_from_input( $value, $fallback = 'go' ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return $fallback ? $fallback : 'go';
		}

		// Strip a scheme and anything that looks like a host, so both
		// "https://cys.co.in/go/" and "cys.co.in/go" and "go" work.
		$value = preg_replace( '#^[a-z][a-z0-9+.\-]*://#i', '', $value );
		$value = preg_replace( '#^//#', '', $value );

		$segments = array_values( array_filter( explode( '/', $value ), 'strlen' ) );
		$kept     = array();
		foreach ( $segments as $i => $segment ) {
			// The first segment is dropped when it is a host name or address.
			if ( 0 === $i && ( false !== strpos( $segment, '.' ) || false !== strpos( $segment, ':' ) ) ) {
				continue;
			}
			$clean = sanitize_title( $segment );
			if ( '' !== $clean ) {
				$kept[] = $clean;
			}
		}

		$path = implode( '/', $kept );
		return '' !== $path ? $path : ( $fallback ? $fallback : 'go' );
	}

	/**
	 * Reduce a pasted address to a bare host name.
	 *
	 * @param string $value Raw input.
	 * @return string Empty when it is not a usable host.
	 */
	public static function clean_host( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		$value = preg_replace( '#^[a-z][a-z0-9+.\-]*://#i', '', $value );
		$value = preg_replace( '#^//#', '', $value );
		// Note the delimiter: a "#" here would close a "#"-delimited pattern
		// at the character class and silently return null.
		$host  = strtolower( (string) preg_replace( '~[/?#].*$~', '', $value ) );
		$host  = preg_replace( '/:\d+$/', '', $host );
		$host  = ltrim( (string) $host, '.' );
		if ( ! preg_match( '/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/', $host ) ) {
			return '';
		}
		return $host;
	}

	/**
	 * Base URL of public links without trailing slash.
	 *
	 * @param string $domain Optional host to print instead of this site's.
	 * @return string
	 */
	public function base_url( $domain = '' ) {
		$base = trim( (string) $this->get( 'base_path' ), '/' );
		if ( '' === $base ) {
			$base = 'go';
		}

		// A link can be presented on the primary domain or on one of the extra
		// domains. Only the host changes: the path and the request both stay on
		// this install.
		//
		// A host that was never configured is ignored rather than printed, so a
		// stored value cannot send a visitor to somewhere the operator did not
		// choose.
		$host = self::clean_host( $domain );
		if ( '' === $host ) {
			$host = self::clean_host( (string) $this->get( 'link_domain', '' ) );
		}
		if ( '' !== $host && ! in_array( $host, $this->domains(), true ) ) {
			$host = '';
		}
		if ( '' !== $host ) {
			$scheme = (string) wp_parse_url( home_url(), PHP_URL_SCHEME );
			$scheme = 'http' === $scheme ? 'http' : 'https';
			$port   = (string) wp_parse_url( home_url(), PHP_URL_PORT );
			$port   = $port ? ':' . $port : '';

			// A development install on another port is still reached by port.
			$home_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
			if ( $host !== $home_host ) {
				$port = '';
			}
			return $scheme . '://' . $host . $port . '/' . $base;
		}

		// The holder page is only a rewrite anchor; public links always live under
		// the configured path, never under the holder page's own permalink.
		return untrailingslashit( home_url( '/' . $base ) );
	}

	/**
	 * The same host as base_url(), with no delivery path in front of it.
	 *
	 * A document is printed at the root of the domain, so it needs the host
	 * and the port and nothing else. The host rules are deliberately the same
	 * ones base_url() applies — a domain that was never configured is ignored
	 * rather than printed — so the two can never disagree about which hosts a
	 * link may appear on.
	 *
	 * @param string $domain Domain to print it on.
	 * @return string
	 */
	public function root_url( $domain = '' ) {
		$host = self::clean_host( $domain );
		if ( '' === $host ) {
			$host = self::clean_host( (string) $this->get( 'link_domain', '' ) );
		}
		if ( '' !== $host && ! in_array( $host, $this->domains(), true ) ) {
			$host = '';
		}

		if ( '' === $host ) {
			return untrailingslashit( home_url() );
		}

		$scheme    = (string) wp_parse_url( home_url(), PHP_URL_SCHEME );
		$scheme    = 'http' === $scheme ? 'http' : 'https';
		$port      = (string) wp_parse_url( home_url(), PHP_URL_PORT );
		$port      = $port ? ':' . $port : '';
		$home_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		if ( $host !== $home_host ) {
			$port = '';
		}

		return $scheme . '://' . $host . $port;
	}

	/**
	 * Every host a link may be printed on.
	 *
	 * @return array
	 */
	public function domains() {
		$home = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$list = array();

		// The primary domain comes first so a link created without a choice is
		// printed on it.
		$primary = self::clean_host( (string) $this->get( 'link_domain', '' ) );
		if ( '' !== $primary ) {
			$list[] = $primary;
		}
		if ( '' !== $home ) {
			$list[] = $home;
		}
		foreach ( (array) $this->get( 'extra_domains', array() ) as $host ) {
			$host = self::clean_host( (string) $host );
			if ( '' !== $host && ! in_array( $host, $list, true ) ) {
				$list[] = $host;
			}
		}
		return array_values( array_filter( $list ) );
	}
}
