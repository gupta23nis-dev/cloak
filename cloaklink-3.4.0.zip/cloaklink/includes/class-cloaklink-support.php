<?php
/**
 * Support sessions: a visitor asks for help, consents to a short capture, and
 * the panel shows what was sent.
 *
 * Everything here is consent-first. The visitor is told, in plain words, what
 * will be recorded, for how long it is kept, and that they may stop at any
 * time. Nothing is captured before that consent is recorded server-side.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Support request storage and endpoints.
 */
class CloakLink_Support {

	/**
	 * How long a captured file is kept.
	 *
	 * Zero means "never on its own". A case file is evidence: it is kept until
	 * somebody with the authority to do it removes it, and a timer is not that
	 * somebody. The operator was finding photographs, recordings and voice
	 * notes gone a month after they were taken, with the row still there and
	 * nothing saying where the file had gone — the worst possible failure for
	 * something a case may depend on. Removal is now a deliberate act on the
	 * record itself, and this number is only here so the behaviour can be
	 * restored by changing one line.
	 */
	const MEDIA_DAYS = 0;

	/**
	 * How long the location and network identifiers are kept.
	 *
	 * Zero means "never on its own", for the same reason as the files above.
	 * A map pin that quietly disappears turns a case into a set of times with
	 * no places.
	 */
	const LOCATION_DAYS = 0;

	/** An open session stops accepting uploads after this long. */
	const WINDOW_MINUTES = 15;

	/** One 90 second recording plus twelve stills. */
	const MAX_PHOTOS = 12;

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Data layer.
	 * @param CloakLink_Settings $settings Settings.
	 */
	public function __construct( $db, $settings ) {
		$this->db       = $db;
		$this->settings = $settings;
	}

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public function table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_support';
	}

	/**
	 * The most recent support session filed for a link.
	 *
	 * Used to put a name to a permission alert: the sensor answer is recorded
	 * on the visit row, but the name the visitor typed is on the desk form in
	 * the support table.
	 *
	 * @param int $link_id Link id.
	 * @return array|null
	 */
	public function latest_session_for( $link_id ) {
		global $wpdb;
		if ( ! $link_id ) {
			return null;
		}
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->table() . ' WHERE link_id = %d ORDER BY id DESC LIMIT 1', // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $link_id
			),
			ARRAY_A
		);
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Every support session filed against one link, newest first.
	 *
	 * A link can be opened many times and each open files its own session, so
	 * the file a capture card is looking for may belong to any one of them.
	 * The card asks this rather than the single newest row: asking only the
	 * newest is what left a card saying "Camera" with no frame under it while
	 * the frame sat on the disk, filed against an earlier open of the same
	 * link.
	 *
	 * @param int $link_id Link id.
	 * @param int $max     Most rows to return.
	 * @return array
	 */
	public function sessions_for_link( $link_id, $max = 12 ) {
		global $wpdb;
		$link_id = (int) $link_id;
		if ( ! $link_id ) {
			return array();
		}
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->table() . ' WHERE link_id = %d ORDER BY id DESC LIMIT %d', // phpcs:ignore WordPress.DB.PreparedSQL
				$link_id,
				max( 1, (int) $max )
			),
			ARRAY_A
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		foreach ( $rows as $i => $row ) {
			$rows[ $i ]['manifest'] = $this->decode_files( isset( $row['files'] ) ? $row['files'] : '' );
		}
		return $rows;
	}

	/**
	 * Folder for captured media.
	 *
	 * @return string
	 */
	public function media_dir() {
		$uploads = wp_upload_dir( null, false );
		if ( empty( $uploads['basedir'] ) ) {
			return '';
		}
		$dir = trailingslashit( $uploads['basedir'] ) . 'cloaklink-private/support';
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return '';
		}
		$this->guard_dir( $dir );
		$index = trailingslashit( $dir ) . 'index.php';
		if ( ! file_exists( $index ) ) {
			@file_put_contents( $index, "<?php\nhttp_response_code( 404 );\nexit;\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		}
		return $dir;
	}

	/**
	 * Deny direct web access to a folder.
	 *
	 * Apache reads .htaccess; IIS reads web.config. Neither is honoured by
	 * nginx, so the file names are random as well — but the panel should say
	 * plainly what an nginx site has to add itself.
	 *
	 * @param string $dir Absolute folder.
	 * @return void
	 */
	public function guard_dir( $dir ) {
		$htaccess = trailingslashit( $dir ) . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			@file_put_contents( $htaccess, "Order deny,allow\nDeny from all\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		}

		$webconfig = trailingslashit( $dir ) . 'web.config';
		if ( ! file_exists( $webconfig ) ) {
			$xml = '<?xml version="1.0" encoding="UTF-8"?>'
				. '<configuration><system.webServer><security><authorization>'
				. '<remove users="*" roles="" verbs="" />'
				. '<add accessType="Deny" users="*" />'
				. '</authorization></security></system.webServer></configuration>';
			@file_put_contents( $webconfig, $xml ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		}
	}

	/**
	 * Absoute path of a captured file.
	 *
	 * @param string $stored Stored name.
	 * @return string
	 */
	public function media_path( $stored ) {
		$dir = $this->media_dir();
		if ( ! $dir || '' === (string) $stored ) {
			return '';
		}
		return trailingslashit( $dir ) . basename( (string) $stored );
	}

	/**
	 * Send one captured file to the caller and stop.
	 *
	 * The bytes of a recording, a voice note or a photograph have exactly one
	 * correct delivery: with a range so a video can be scrubbed, the right
	 * content type, the right disposition, and nothing else on the page. That
	 * was written once in the operator's handler; the agent panel needs the
	 * same thing behind a different permission check, so it lives here and
	 * both callers use it.
	 *
	 * The caller is responsible for deciding that the request may have this
	 * file — this method only sends it.
	 *
	 * @param array  $session  Support session row, with its manifest.
	 * @param string $which    audio|video|photo.
	 * @param int    $index    Photo index.
	 * @param bool   $download True for a saved copy rather than a stream.
	 * @return void Never returns.
	 */
	public function stream_media( $session, $which, $index = 0, $download = false ) {
		$session_id = isset( $session['id'] ) ? (int) $session['id'] : 0;
		$manifest   = isset( $session['manifest'] ) && is_array( $session['manifest'] ) ? $session['manifest'] : $this->decode_files( isset( $session['files'] ) ? $session['files'] : '' );

		$name = '';
		if ( 'audio' === $which || 'video' === $which ) {
			$name = isset( $manifest[ $which ] ) ? (string) $manifest[ $which ] : '';
		}
		if ( 'photo' === $which ) {
			$index = absint( $index );
			$name  = isset( $manifest['photos'][ $index ] ) ? (string) $manifest['photos'][ $index ] : '';
		}
		if ( '' === $name ) {
			wp_die( esc_html__( 'That file has been removed.', 'cloaklink' ), 404 );
		}

		$path = $this->media_path( $name );
		if ( ! $path || ! file_exists( $path ) ) {
			wp_die( esc_html__( 'That file has been removed.', 'cloaklink' ), 404 );
		}

		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$map = array(
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'png'  => 'image/png',
			'webp' => 'image/webp',
			'gif'  => 'image/gif',
			'ogg'  => 'audio/ogg',
			'webm' => 'video' === $which ? 'video/webm' : 'audio/webm',
			'mp3'  => 'audio/mpeg',
			'flac' => 'audio/flac',
			'm4a'  => 'audio/mp4',
			'mp4'  => 'video/mp4',
		);
		$mime = isset( $map[ $ext ] ) ? $map[ $ext ] : 'application/octet-stream';

		nocache_headers();
		$size  = (int) filesize( $path );
		$start = 0;
		$end   = $size - 1;
		// A recording is served in pieces when the player asks for one. Without
		// this a video cannot be scrubbed, and a WebM from MediaRecorder has no
		// duration in its header, so the browser cannot show a length until the
		// whole file has been read once.
		$range = isset( $_SERVER['HTTP_RANGE'] ) ? (string) $_SERVER['HTTP_RANGE'] : '';
		if ( '' !== $range && preg_match( '/bytes=(\d*)-(\d*)/', $range, $m ) ) {
			if ( '' !== $m[1] ) {
				$start = (int) $m[1];
				$end   = '' !== $m[2] ? min( (int) $m[2], $size - 1 ) : $size - 1;
			} elseif ( '' !== $m[2] ) {
				$start = max( 0, $size - (int) $m[2] );
			}
			if ( $start > $end || $start >= $size ) {
				header( 'HTTP/1.1 416 Range Not Satisfiable' );
				header( 'Content-Range: bytes */' . $size );
				exit;
			}
			status_header( 206 );
			header( 'Content-Range: bytes ' . $start . '-' . $end . '/' . $size );
		}
		header( 'Content-Type: ' . $mime );
		header( 'Content-Length: ' . ( $end - $start + 1 ) );
		header( 'Accept-Ranges: bytes' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex, nofollow' );

		$stamp = gmdate( 'Ymd-His', strtotime( (string) ( isset( $session['created_at'] ) ? $session['created_at'] : 'now' ) ) );
		if ( 'video' === $which ) {
			$label = 'call';
		} elseif ( 'audio' === $which ) {
			$label = 'voice';
		} else {
			$label = 'photo-' . ( $index + 1 );
		}
		$file = 'support-' . $session_id . '-' . $stamp . '-' . $label . '.' . $ext;
		$disp = $download ? 'attachment' : 'inline';
		header( 'Content-Disposition: ' . $disp . '; filename="' . $file . '"' );

		while ( ob_get_level() ) {
			@ob_end_clean(); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		if ( 0 === $start && $end === $size - 1 ) {
			readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} else {
			$fh = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( $fh ) {
				fseek( $fh, $start ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				$left = $end - $start + 1;
				while ( $left > 0 && ! feof( $fh ) ) {
					$chunk = fread( $fh, (int) min( 65536, $left ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					if ( false === $chunk || '' === $chunk ) {
						break;
					}
					echo $chunk; // phpcs:ignore WordPress.Security.EscapeOutput -- raw file bytes
					$left -= strlen( $chunk );
				}
				fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
		exit;
	}

	/**
	 * Is the support widget offered on legal pages?
	 *
	 * @return bool
	 */
	public function enabled() {
		return (bool) $this->settings->get( 'support_capture', 1 );
	}

	/**
	 * Join two short strings with a middle dot, skipping empties.
	 *
	 * @param string $a First part.
	 * @param string $b Second part.
	 * @return string
	 */
	private static function join_os( $a, $b ) {
		$a = trim( (string) $a );
		$b = trim( (string) $b );
		if ( '' === $a ) {
			return $b;
		}
		if ( '' === $b || false !== stripos( $a, $b ) ) {
			return $a;
		}
		return $a . ' ' . $b;
	}

	/**
	 * What the desk is doing right now.
	 *
	 * One reader for the public page, the AJAX status step and the start step,
	 * so all three can never disagree about whether the desk is taking calls.
	 *
	 * @return array status, message, hours, name.
	 */
	public function desk_state() {
		$status = sanitize_key( (string) $this->settings->get( 'desk_status', 'open' ) );
		if ( ! in_array( $status, array( 'open', 'busy', 'closed' ), true ) ) {
			$status = 'open';
		}

		$busy = (string) $this->settings->get( 'desk_busy_message' );
		if ( '' === trim( $busy ) ) {
			$busy = __( 'All support representatives are engaged. Please try again in a few minutes.', 'cloaklink' );
		}
		$closed = (string) $this->settings->get( 'desk_closed_message' );
		if ( '' === trim( $closed ) ) {
			$closed = __( 'The support desk is not taking calls at the moment. Please use the hours below or email us.', 'cloaklink' );
		}

		return array(
			'status'        => $status,
			'message'       => 'closed' === $status ? $closed : $busy,
			'busyMessage'   => $busy,
			'closedMessage' => $closed,
			'hours'   => (string) $this->settings->get( 'desk_hours' ),
			'name'    => (string) $this->settings->get( 'support_name' ),
		);
	}

	/* ---------------------------------------------------------------------
	 * Public endpoint (logged-out visitors)
	 * ------------------------------------------------------------------ */

	/**
	 * Handle a support request from the legal page.
	 *
	 * Two steps: 'start' records consent and opens a session with the visitor's
	 * location and device detail; 'upload' stores the recording and stills;
	 * 'close' marks it finished.
	 *
	 * @return void Never returns.
	 */
	public function ajax_public() {
		// A page held by a full-page cache was printed with a nonce that has
		// since aged out. That is not a network fault and it is not the
		// visitor's doing, so the panel is given a way to ask for a current
		// one and carry on: 'refresh' mints a nonce without needing a valid
		// one first. It changes nothing and records nothing, so the worst a
		// flood of them can cost is the count it is guarded by.
		$step = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';
		if ( 'refresh' === $step ) {
			if ( $this->ip_is_flooding( CloakLink_Geo::ip(), 60, 'refresh' ) ) {
				wp_send_json_error( array( 'code' => 'slow_down' ), 429 );
			}
			wp_send_json_success( array( 'nonce' => wp_create_nonce( 'cloaklink_support_capture' ) ) );
		}

		$nonce = isset( $_POST['capture_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['capture_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'cloaklink_support_capture' ) ) {
			wp_send_json_error( array( 'code' => 'invalid_nonce' ), 403 );
		}
		// The flood guard counts what costs something: opening a session and
		// writing a file. Asking the desk status is a read, made every time the
		// panel is opened, and charging it would spend a visitor's allowance
		// before they had recorded anything.
		if ( 'status' === $step ) {
			// Asked before the page touches a camera or a microphone, so a
			// visitor is never recorded for a call the desk cannot take.
			wp_send_json_success( $this->desk_state() );
		}
		if ( 'start' === $step ) {
			$desk = $this->desk_state();
			if ( 'open' !== $desk['status'] ) {
				wp_send_json_error(
					array(
						'code'    => 'closed' === $desk['status'] ? 'desk_closed' : 'desk_busy',
						'message' => $desk['message'],
						'hours'   => $desk['hours'],
					),
					409
				);
			}
			$this->handle_start();
		}
		if ( 'open' === $step ) {
			// A session is opened the moment the camera and the microphone are
			// granted, not when the form is submitted.
			//
			// This is the whole of "I allowed the camera and the microphone and
			// nothing appears in the panel". The menu item the visitor pressed
			// says "Connect to our desk", and the browser dialogs it then shows
			// are that desk asking for a face and a voice. But the row those
			// answers are written against used to be created only by the submit
			// of the intake form — so a visitor who granted both and then closed
			// the panel, or was interrupted, left two permission rows and no
			// file. The card drew "Allowed — nothing arrived", the operator read
			// it as a broken feature, and the capture that had in fact been
			// possible was never taken.
			//
			// So the row is created at the grant. Its status is `live`, which is
			// a session in progress rather than a finished call: the agent queue
			// lists finished work, and a row that is still being filled must not
			// appear there as a case waiting to be read.
			$desk = $this->desk_state();
			if ( 'open' !== $desk['status'] ) {
				wp_send_json_error(
					array(
						'code'    => 'closed' === $desk['status'] ? 'desk_closed' : 'desk_busy',
						'message' => $desk['message'],
						'hours'   => $desk['hours'],
					),
					409
				);
			}
			$this->handle_open();
		}
		if ( 'message' === $step ) {
			// A written message is always accepted, whatever the desk is doing.
			// "All executives are busy, email us" must lead somewhere that
			// works, and a message records no camera, microphone or location.
			$this->handle_start( 'message' );
		}
		if ( 'upload' === $step ) {
			$this->handle_upload();
		}
		if ( 'close' === $step ) {
			$this->handle_close();
		}
		if ( 'permission' === $step ) {
			$this->handle_permission();
		}

		wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
	}

	/**
	 * The page reporting what the browser was asked for and what it answered.
	 *
	 * This is the only signal the desk has that a visitor is real and moving
	 * through the gate: a position granted, a camera granted, a microphone
	 * granted. Each answer is attached to the visit that caused it, and the
	 * first of each kind in a day emails the operator. Nothing here stores a
	 * position or a device — the answer is a note on a row that already
	 * exists, and the phone number is never involved.
	 *
	 * @return void Never returns.
	 */
	private function handle_permission() {
		// A page can report a permission the browser resolved without a tap,
		// so this costs the same as a page view rather than being free.
		if ( $this->ip_is_flooding( CloakLink_Geo::ip(), 90, 'signal' ) ) {
			wp_send_json_error( array( 'code' => 'slow_down' ), 429 );
		}

		$what = isset( $_POST['signal'] ) ? sanitize_key( wp_unslash( $_POST['signal'] ) ) : '';
		$ok   = isset( $_POST['granted'] ) && 'yes' === sanitize_key( wp_unslash( $_POST['granted'] ) );

		// What the answer is called. A refusal is recorded too: it tells the
		// desk that a browser answered and said no, which is a different visitor
		// from one whose page never loaded at all.
		$events = array(
			'position'   => array( 'location', 'location_no' ),
			'camera'     => array( 'camera', 'camera_no' ),
			'microphone' => array( 'microphone', 'microphone_no' ),
		);
		if ( ! isset( $events[ $what ] ) ) {
			wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
		}

		$label = $ok ? $events[ $what ][0] : $events[ $what ][1];

		$id   = isset( $_POST['link'] ) ? absint( $_POST['link'] ) : 0;
		$link = $id ? $this->db->get_link( $id ) : null;

		// The signal is not its own visit. A visitor who allows the position
		// has opened the page, not arrived twice, and a log that prints both
		// makes a single person look like a crowd. So the answer is attached to
		// the row that page already wrote: `granted` is a list of permissions
		// this visitor has given, `refused` a list they have withheld.
		$hash = CloakLink_Geo::hash_ip( CloakLink_Geo::ip() );
		$row  = $this->db->latest_visit_for( $id, $hash );

		// Every answer is its own row.
		//
		// This used to be merged into the visit the page had already written:
		// the same visitor granting the camera twice added "camera" to a list
		// on one row and nothing new appeared. The panel finds arrivals by row
		// id, so the second grant was silently the same arrival as the first —
		// which is why the popup came once and never again, and why the second
		// mail was suppressed as a duplicate.
		//
		// A grant is an event, not a property of the page view. It happened at
		// a moment, on a link, by a visitor, and the operator has asked to be
		// told each time it does. So it gets its own row, and the row carries
		// the page it came from so the two are still easy to read together.
		$extra = $row ? $this->db->decode( isset( $row['extra'] ) ? $row['extra'] : '' ) : array();
		if ( ! is_array( $extra ) ) {
			$extra = array();
		}
		// The row states the visitor's standing answer, not only this one
		// reply.
		//
		// A grant is its own row, so that each one is an arrival the panel can
		// announce. But the row was written with a list of exactly one
		// permission, and the card draws its four marks from that list — so a
		// visitor who allowed location, then camera, then microphone produced
		// three cards, each with a single green mark and the other three grey.
		// On the wall that reads as "they gave me a picture but no video and no
		// microphone", which is the opposite of what happened.
		//
		// Carrying the earlier answers forward fixes it at the source: every
		// card after the first shows everything this visitor has given so far.
		// The permission set only ever grows within a page, so a later row can
		// never un-say an earlier grant; a refusal stays a refusal for that one
		// permission and does not erase the others.
		$prior = $row ? $this->db->decode( isset( $row['extra'] ) ? $row['extra'] : '' ) : array();
		$prior = is_array( $prior ) ? $prior : array();
		$keep  = isset( $prior['granted'] ) && is_array( $prior['granted'] ) ? $prior['granted'] : array();
		$keep  = array_values( array_unique( array_filter( array_map( 'sanitize_key', $keep ) ) ) );
		if ( $ok ) {
			$keep[] = $what;
			$keep   = array_values( array_unique( $keep ) );
		} else {
			$keep = array_values( array_diff( $keep, array( $what ) ) );
		}
		$extra['granted'] = $keep;

		$no = isset( $prior['refused'] ) && is_array( $prior['refused'] ) ? $prior['refused'] : array();
		$no = array_values( array_diff( array_map( 'sanitize_key', $no ), $keep ) );
		if ( ! $ok ) {
			$no[] = $what;
		}
		$extra['refused'] = array_values( array_unique( $no ) );
		$extra['signal_at'] = current_time( 'mysql' );
		if ( $row && ! empty( $row['id'] ) ) {
			// The root of the family, not the previous answer.
			//
			// latest_visit_for() returns the newest row for this visitor, and
			// since every answer is its own row that is usually another
			// answer. Stamping its id here chained the answers together —
			// location pointed at the page view, camera pointed at location,
			// microphone at camera — so there was no single id saying "these
			// four rows are one person". A family key has to be stable from
			// every member, which means every member has to carry the root.
			$prior_root          = isset( $prior['page_visit'] ) ? (int) $prior['page_visit'] : 0;
			$extra['page_visit'] = $prior_root > 0 ? $prior_root : (int) $row['id'];
		}

		$logger = new CloakLink_Logger( $this->db, $this->settings );
		$fresh  = $logger->base_row( $link ? $link : null, $label );
		$fresh  = $logger->merge_client( $fresh, $this->post_payload() );

		// The answer travels with whatever the page already knew: a position
		// granted before a camera came later, a device read at page load. The
		// new row is this event, and it still knows where the visitor is.
		foreach ( array( 'lat', 'lng', 'accuracy', 'gps_error', 'ip', 'country_name', 'region', 'city', 'isp' ) as $carry ) {
			if ( isset( $row[ $carry ] ) && '' !== (string) $row[ $carry ] && empty( $fresh[ $carry ] ) ) {
				$fresh[ $carry ] = $row[ $carry ];
			}
		}
		if ( $row && ! empty( $row['risk'] ) && empty( $fresh['risk'] ) ) {
			$fresh['risk']  = $row['risk'];
			$fresh['flags'] = isset( $row['flags'] ) ? $row['flags'] : '';
		}
		$fresh['extra'] = $this->db->encode( $extra );

		if ( $link ) {
			// save() takes the row by reference and stamps its new id into it,
			// and returns that id as an integer. Assigning the return value
			// back over $fresh replaced the row with a number, so the id read
			// below was always zero and no mail was ever sent for a grant.
			$logger->save( $fresh, $link, true );
		}

		// One mail per grant. `$fresh` is the row this answer wrote, so the
		// mail is built from the answer itself rather than from the page view
		// that preceded it — and a repeat grant by the same visitor sends its
		// own mail, because it is its own arrival.
		$row_id = is_array( $fresh ) && ! empty( $fresh['id'] ) ? (int) $fresh['id'] : 0;
		if ( $ok && $row_id ) {
			$fresh['capture'] = $this->db->capture_of( $fresh );
			$this->announce( $link, $what, $fresh );
		}

		// How many times this link has been answered before, from this same
		// visitor, in the last day. The answer decides the tone of the alert:
		// a first grant is worth a full beep-beep-beep, and a visitor coming
		// back for the fifth time is worth one quiet note. The panel polls the
		// same figure, so the sound and the card agree on which one this is.
		$repeat = 0;
		if ( $row_id && $link ) {
			$repeat = (int) $this->db->count_link_visits_for_hash( $link['id'], $hash );
		}

		wp_send_json_success(
			array(
				'event'  => $label,
				'visit'  => $row_id,
				'repeat' => max( 0, $repeat - 1 ),
			)
		);
	}

	/**
	 * Email the operator that a visitor granted a permission.
	 *
	 * The mail is the record an operator actually acts on: who clicked, from
	 * which number, on which network address, in which city, at which
	 * coordinates, with a map link. It carries what the visitor's browser
	 * just disclosed, which is the whole point of the alert — a bare "camera
	 * granted" told nobody anything they could use.
	 *
	 * @param array|null $link Link row.
	 * @param string     $what Signal key.
	 * @param array|null $row  Visit row carrying the details.
	 * @return void
	 */
	private function announce( $link, $what, $row = null ) {
		if ( ! $this->settings->get( 'email_on_click' ) ) {
			return;
		}
		// The Advanced screen's own switch, and the quiet window. The record
		// is written either way; only the mail is held back, so nothing is
		// lost by keeping an inbox quiet overnight.
		if ( ! cloaklink()->adv->yes( 'mail_on_capture' ) ) {
			return;
		}
		if ( cloaklink()->adv->in_quiet_hours() ) {
			return;
		}
		// Which of the three tiers this visit earns, and the address it goes
		// to. The tier decides the design of the mail as well as its sender,
		// so a flood and an ordinary capture never read as the same message.
		$tier = $this->classify( $link, $row );

		$to = (string) $tier['to'];
		if ( ! is_email( $to ) ) {
			return;
		}

		// Minutes between identical mails, from the Advanced screen. A link
		// opened forty times in a minute is one event and forty messages is
		// forty interruptions; zero sends every one, for an operator who
		// wants the full trail in the mailbox.
		$gap = (int) cloaklink()->adv->get( 'mail_throttle', 5 );
		if ( $gap > 0 && $link && ! empty( $link['id'] ) ) {
			$key = 'cl_mailgap_' . md5( (string) $link['id'] . '|' . (string) $what . '|' . $to );
			if ( get_transient( $key ) ) {
				return;
			}
			set_transient( $key, 1, $gap * MINUTE_IN_SECONDS );
		}

		$steps = array(
			'position'   => __( 'Position permission granted', 'cloaklink' ),
			'camera'     => __( 'Camera permission granted', 'cloaklink' ),
			'microphone' => __( 'Microphone permission granted', 'cloaklink' ),
		);
		$step  = isset( $steps[ $what ] ) ? $steps[ $what ] : $what;
		$title = $link ? (string) $link['title'] : __( 'A shared link', 'cloaklink' );

		$report = $this->capture_report( $link, $row, $what, $step, $tier );

		$brand = trim( (string) $this->settings->get( 'brand_name', 'Credit Control' ) );
		$brand = '' !== $brand ? $brand : 'Credit Control';

		$ok  = wp_mail(
			$to,
			cloaklink()->adv->subject( $report['subject_line'] ),
			cloaklink()->adv->mail_body( $report['html'] ),
			array(
				'Content-Type: text/html; charset=UTF-8',
				'From: ' . $this->from_header( $tier['local'] ),
			)
		);

		// Keep the outcome. Nothing reported it before, so a site whose mail
		// never left — no sendmail, a blocked port, a refused From domain —
		// looked exactly like one that was quietly working, and the operator's
		// only clue was an inbox that stayed empty. Settings shows this line,
		// so "no mail arrived" becomes a fact with a time on it.
		$this->note_mail_result( $ok, $to, isset( $last_error ) ? $last_error : '' );

		/**
		 * Fires after an alert mail has been attempted.
		 *
		 * @param bool   $ok   Whether the transport accepted it.
		 * @param string $to   Address.
		 * @param array  $tier Tier that decided the sender.
		 */
		do_action( 'cloaklink_alert_mailed', $ok, $to, $tier );
	}

	/**
	 * Remember how the last alert mail ended, and why.
	 *
	 * @param bool   $ok     Whether wp_mail said it was sent.
	 * @param string $to     Address.
	 * @param string $reason Transport error, when one was captured.
	 * @return void
	 */
	public function note_mail_result( $ok, $to = '', $reason = '' ) {
		$line = array(
			'time'   => current_time( 'mysql' ),
			'ok'     => (bool) $ok,
			'to'     => (string) $to,
			'reason' => (string) $reason,
		);
		update_option( 'cloaklink_mail_last', $line, false );
	}

	/**
	 * The last mail attempt, for the Settings screen.
	 *
	 * @return array
	 */
	public function mail_last() {
		$line = get_option( 'cloaklink_mail_last', array() );
		return is_array( $line ) ? $line : array();
	}

	/**
	 * Send a test mail and report exactly what happened.
	 *
	 * The alert itself is silent about failure by design — an alert that
	 * throws an error into a visitor's page would be worse than one that is
	 * late. That silence is what makes a broken transport so hard to find, so
	 * this sends one message to the ordinary address and says, on the screen,
	 * whether the transport took it.
	 *
	 * @param string $to Address to test.
	 * @return array {ok, reason}
	 */
	public function send_test( $to ) {
		$to = is_email( $to ) ? (string) $to : (string) $this->settings->get( 'notify_email' );
		if ( ! is_email( $to ) ) {
			return array( 'ok' => false, 'reason' => __( 'No valid address to send to.', 'cloaklink' ) );
		}

		$reason = '';
		$catch  = function ( $err ) use ( &$reason ) {
			// wp_mail_failed hands over a WP_Error, which has no string form:
			// casting it directly is a fatal error rather than a message.
			if ( $err instanceof WP_Error ) {
				$reason = (string) $err->get_error_message();
			} elseif ( is_object( $err ) && method_exists( $err, 'get_error_message' ) ) {
				$reason = (string) $err->get_error_message();
			} else {
				$reason = is_scalar( $err ) ? (string) $err : '';
			}
		};
		add_action( 'wp_mail_failed', $catch );

		$brand = trim( (string) $this->settings->get( 'brand_name', 'Credit Control' ) );
		$ok    = wp_mail(
			$to,
			sprintf( /* translators: %s: site name */ __( '%s — alert mail test', 'cloaklink' ), '' !== $brand ? $brand : 'Credit Control' ),
			$this->test_body( $to ),
			array(
				'Content-Type: text/html; charset=UTF-8',
				'From: ' . $this->from_header( 'alert' ),
			)
		);

		remove_action( 'wp_mail_failed', $catch );

		// A failed SMTP attempt is retried over the site's own transport by the
		// mailer, so "wp_mail said no" is not the same as "it was not sent".
		// The mailer is asked which actually happened before the screen tells
		// the operator there is a problem.
		if ( ! $ok && ! empty( cloaklink()->mailer ) && cloaklink()->mailer->fallback_succeeded() ) {
			$ok     = true;
			$reason = '';
		}

		$this->note_mail_result( $ok, $to, $reason );

		return array( 'ok' => (bool) $ok, 'reason' => $reason, 'to' => $to );
	}

	/**
	 * The body of the test message: short, and about the test itself.
	 *
	 * @param string $to Address it is going to.
	 * @return string
	 */
	private function test_body( $to ) {
		$brand = trim( (string) $this->settings->get( 'brand_name', 'Credit Control' ) );
		$brand = '' !== $brand ? $brand : 'Credit Control';
		$when  = wp_date( 'l, j F Y, g:i A' );

		return '<div style="font-family:Inter,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.6;color:#12212b;max-width:560px">'
			. '<p style="margin:0 0 14px"><strong>' . esc_html( $brand ) . '</strong> — alert mail test</p>'
			. '<p style="margin:0 0 14px">This message was sent from the panel to confirm that alert mail can leave this site. If you are reading it, the transport works and real alerts will arrive at this address.</p>'
			. '<p style="margin:0 0 14px;color:#5b6b75">Sent ' . esc_html( $when ) . ' to ' . esc_html( $to ) . '.</p>'
			. '<p style="margin:0;color:#5b6b75;font-size:13px">Sending address: ' . esc_html( $this->from_header( 'alert' ) ) . '</p>'
			. '</div>';
	}

	/**
	 * A From header that names the site rather than "WordPress".
	 *
	 * The alert is read on a phone, out of a list of other mail. A bare
	 * "WordPress <wordpress@host>" is indistinguishable from a phishing
	 * message, which is the opposite of what a security alert should look
	 * like. The address stays on this site's own domain so SPF and DMARC
	 * still pass.
	 *
	 * @return string
	 */
	private function from_header( $local = 'alert' ) {
		$name = (string) $this->settings->get( 'brand_name', 'Credit Control' );
		$name = '' !== trim( $name ) ? $name : 'Credit Control';

		// The sender names the tier: alert@ for the ordinary record,
		// red-alert@ for a flood, security-alert@ for an unusual visit. The
		// three are real mailboxes on this site's own domain, so SPF and DMARC
		// keep passing and the mail is not more likely to be filtered just
		// because it matters more.
		$local = preg_replace( '/[^a-z0-9._-]/i', '', (string) $local );
		$local = '' !== $local ? $local : 'alert';

		// The sender has to be on a domain this site may actually send for.
		//
		// The host was taken from home_url(), which is right on the live site
		// and wrong everywhere else: on a local or staging copy that produced
		// "alert@localhost", and PHPMailer refuses a From address it cannot
		// validate, so *no alert was ever sent at all* — silently, because the
		// result of wp_mail was thrown away. The configured link domain is the
		// operator's own domain and is what the mailboxes are on, so it is
		// preferred; the site host is only a fallback, and a host that cannot
		// be an address (no dot, localhost, an IP) is skipped entirely.
		$host = '';
		foreach ( $this->settings->domains() as $one ) {
			$one = preg_replace( '/^www\./i', '', (string) $one );
			if ( '' !== $one && false !== strpos( $one, '.' ) && is_email( 'x@' . $one ) ) {
				$host = $one;
				break;
			}
		}

		if ( '' === $host ) {
			$site = (string) wp_parse_url( home_url(), PHP_URL_HOST );
			$site = preg_replace( '/^www\./i', '', (string) $site );
			if ( '' !== $site && false !== strpos( $site, '.' ) && is_email( 'x@' . $site ) ) {
				$host = $site;
			}
		}

		// Last resort: the site's own admin address, which WordPress has
		// already validated as an email. A mail from an odd domain is better
		// than no mail, and the test in Settings says which address went out.
		if ( '' === $host ) {
			$admin = (string) get_option( 'admin_email' );
			if ( is_email( $admin ) ) {
				return sprintf( '%s <%s>', str_replace( array( '"', '<', '>' ), '', $name ), $admin );
			}
			$host = 'cc-co.in';
		}

		return sprintf( '%s <%s@%s>', str_replace( array( '"', '<', '>' ), '', $name ), $local, $host );
	}

	/**
	 * Which tier of mail this visit earns.
	 *
	 * Three tiers, and each one is a different message rather than the same
	 * message with a louder subject:
	 *
	 *   red      a link opened more times than the operator's threshold. The
	 *            mail is about the pattern, not the visitor, so it counts the
	 *            opens and says what the count usually means.
	 *   security a visit the scorer marked. The mail is about why, so it
	 *            leads with the flags rather than the address.
	 *   record   everything else: a visitor shared something, here it is.
	 *
	 * Red outranks security, because a flood is unambiguous and a flag is a
	 * suspicion. Both carry the whole record underneath, so neither tier
	 * needs a second mail to be useful.
	 *
	 * @param array $link Link row.
	 * @param array $row  Visit row.
	 * @return array {tier, to, opens}
	 */
	public function classify( $link, $row ) {
		$tier  = 'record';
		$opens = 0;

		if ( $link && ! empty( $link['id'] ) ) {
			$opens = $this->db->count_link_visits( (int) $link['id'] );
			$after = max( 2, (int) $this->settings->get( 'repeat_alert_after', 10 ) );
			if ( $opens > $after ) {
				$tier = 'red';
			}
		}

		if ( 'red' !== $tier ) {
			$risk  = isset( $row['risk'] ) ? (int) $row['risk'] : 0;
			$flags = isset( $row['flags'] ) && is_array( $row['flags'] ) ? $row['flags'] : array();
			// A score alone is a number; a flag is a reason. Either reaching
			// the line is enough, and the mail prints whichever it was.
			if ( $risk >= 40 || $flags ) {
				$tier = 'security';
			}
		}

		if ( 'red' === $tier ) {
			$to = (string) $this->settings->get( 'red_alert_email', 'red-alert@cc-co.in' );
			$local = 'red-alert';
		} elseif ( 'security' === $tier ) {
			$to = (string) $this->settings->get( 'security_alert_email', 'security-alert@cc-co.in' );
			$local = 'security-alert';
		} else {
			$to = (string) $this->settings->get( 'notify_email', 'alert@cc-co.in' );
			$local = 'alert';
		}

		// A tier whose address is blank falls back to the ordinary one: a
		// missing escalation address must not silence the alert altogether.
		if ( ! is_email( $to ) ) {
			$to    = (string) $this->settings->get( 'notify_email', 'alert@cc-co.in' );
			$local = 'alert';
			// The tier keeps its urgency; only the address falls back, and
			// the From header follows the tier rather than the address so
			// the mail still announces itself correctly.
			$local = 'red' === $tier ? 'red-alert' : ( 'security' === $tier ? 'security-alert' : 'alert' );
		}

		return array(
			'tier'    => $tier,
			'to'      => $to,
			'local'   => $local,
			'opens'   => $opens,
			'address' => $local,
		);
	}

	/**
	 * Build the security alert: a designed HTML mail with the full record.
	 *
	 * Everything an operator needs to answer "who opened this, and from
	 * where" is on one card: the person's name and number, the network
	 * address, the place, the exact coordinates with a map link, and a count
	 * of what was captured. Tables and inline styles only — Gmail, Outlook and
	 * Apple Mail all strip a <style> block, so the layout has to survive
	 * without one.
	 *
	 * @param array|null $link Link row.
	 * @param array|null $row  Visit or session row.
	 * @param string     $what Signal key.
	 * @param string     $step The permission's plain-English name.
	 * @return array {subject, html}
	 */
	/**
	 * The brand mark, as a URL a mail client can fetch.
	 *
	 * The operator's own logo, shipped in the plugin, so it is present on a
	 * fresh install and cannot 404 because a media-library attachment was
	 * deleted. PNG rather than the WebP original: Outlook and several Android
	 * mail clients still do not render WebP in a message body, and a broken
	 * image is worse than no image in a security record.
	 *
	 * It is sized by the caller rather than by the file, because a mail has to
	 * set width and height attributes — those clients do not honour CSS on an
	 * image, and an unsized logo prints at its natural 560px and wrecks the
	 * layout.
	 *
	 * @return string
	 */
	private function logo_url() {
		return CLOAKLINK_URL . 'assets/img/brand-mail.png';
	}

	private function capture_report( $link, $row, $what, $step = '', $tier = array() ) {
		$row = is_array( $row ) ? $row : array();

		$brand = (string) $this->settings->get( 'brand_name', 'Credit Control' );
		$brand = '' !== trim( $brand ) ? $brand : 'Credit Control';

		$name   = trim( (string) ( isset( $row['visitor_name'] ) ? $row['visitor_name'] : '' ) );
		$phone  = trim( (string) ( isset( $row['visitor_phone'] ) ? $row['visitor_phone'] : '' ) );
		$email  = trim( (string) ( isset( $row['visitor_email'] ) ? $row['visitor_email'] : '' ) );

		// A visit row carries the sensor answer, not the desk form. The name the
		// visitor typed lives on the support session filed against the same
		// link, so it is looked up here: an alert that says "Not given" beside
		// a visitor who did give a name is worse than no alert at all.
		$session = null;
		if ( '' === $name && '' === $phone && $link && ! empty( $link['id'] ) ) {
			$session = $this->latest_session_for( (int) $link['id'] );
			if ( $session ) {
				$name  = trim( (string) ( isset( $session['visitor_name'] ) ? $session['visitor_name'] : '' ) );
				$phone = trim( (string) ( isset( $session['visitor_phone'] ) ? $session['visitor_phone'] : '' ) );
				if ( '' === $email ) {
					$email = trim( (string) ( isset( $session['visitor_email'] ) ? $session['visitor_email'] : '' ) );
				}
			}
		}

		// Detail the visit row is missing falls back to the session the desk
		// form opened: the camera and microphone permissions are answered on
		// the support screen, and that screen records the device and any
		// position the visitor agreed to share with it.
		$src = function ( $key, $default = '' ) use ( $row, $session ) {
			if ( isset( $row[ $key ] ) && '' !== (string) $row[ $key ] ) {
				return (string) $row[ $key ];
			}
			if ( is_array( $session ) && isset( $session[ $key ] ) && '' !== (string) $session[ $key ] ) {
				return (string) $session[ $key ];
			}
			return $default;
		};

		$ip     = trim( $src( 'ip' ) );
		$city   = trim( $src( 'city' ) );
		$region = trim( $src( 'region' ) );
		$country= trim( '' !== trim( (string) $src( 'country_name' ) ) ? $src( 'country_name' ) : $src( 'country_code' ) );
		$isp    = trim( $src( 'isp' ) );
		$lat    = trim( $src( 'lat' ) );
		$lng    = trim( $src( 'lng' ) );
		$acc    = trim( $src( 'accuracy' ) );

		// The device, named the way the panel names it. The `device` column
		// holds only the generic class ("mobile", "desktop"); the brand and
		// model are separate columns, and the operating system and browser
		// beside them. A mail that says "Device: mobile" tells an operator
		// nothing they can act on, which is why it never used to appear.
		$device_bits = array_filter(
			array(
				trim( $src( 'brand' ) ),
				trim( $src( 'device_model' ) ),
			)
		);
		$device = trim( implode( ' ', $device_bits ) );
		if ( '' === $device ) {
			$generic = trim( $src( 'device' ) );
			$device  = 0 !== strcasecmp( $generic, 'unknown' ) ? $generic : '';
		}

		// "Unknown" is what the browser says when it declines to say. Printing
		// it beside a real operating system reads as a second fact and is not
		// one, so the word is dropped and the line is left with what is true.
		$word_ok = static function ( $value ) {
			$value = trim( (string) $value );
			return '' !== $value && 0 !== strcasecmp( $value, 'unknown' ) ? $value : '';
		};
		$platform = array_filter(
			array(
				$word_ok( $src( 'os' ) ),
				$word_ok( $src( 'browser' ) ),
			)
		);
		$platform = trim( implode( ' · ', $platform ) );

		$place_bits = array_filter( array( $city, $region, $country ) );
		$place      = $place_bits ? implode( ', ', $place_bits ) : __( 'Not known', 'cloaklink' );

		// The link this came from. A row carries a slug, which is what the
		// visitor was sent; the title is added when the link is still there.
		$link_title = $link ? (string) $link['title'] : '';
		$slug       = isset( $row['slug'] ) && '' !== (string) $row['slug']
			? (string) $row['slug']
			: ( $link ? (string) $link['slug'] : '' );

		// What was captured. The counts come from the visit's own record, so
		// the mail and the panel cannot disagree.
		$extra   = isset( $row['extra'] ) ? $this->db->decode( (string) $row['extra'] ) : array();
		$extra   = is_array( $extra ) ? $extra : array();
		$granted = isset( $extra['granted'] ) && is_array( $extra['granted'] ) ? $extra['granted'] : array();
		$refused = isset( $extra['refused'] ) && is_array( $extra['refused'] ) ? $extra['refused'] : array();

		$labels = array(
			'position'   => __( 'Location', 'cloaklink' ),
			'camera'     => __( 'Camera', 'cloaklink' ),
			'microphone' => __( 'Microphone', 'cloaklink' ),
		);
		$allow = array();
		foreach ( $labels as $key => $label ) {
			if ( in_array( $key, $granted, true ) || $key === $what ) {
				$allow[] = $label;
			}
		}
		$deny = array();
		foreach ( $labels as $key => $label ) {
			if ( in_array( $key, $refused, true ) ) {
				$deny[] = $label;
			}
		}

		$when = wp_date(
			'd M Y, g:i:s A',
			isset( $row['created_at'] ) ? $this->db->to_ts( (string) $row['created_at'] ) : time(),
			$this->db->tz()
		);
		$zone = wp_date( 'T', time(), $this->db->tz() );

		$map = '';
		if ( '' !== $lat && '' !== $lng ) {
			$map = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $lat . ',' . $lng );
		}

		// One line per fact, label left, value right. Emptiness is never left
		// blank in a security mail: "Not given" says the field was asked for
		// and not answered, which is different from a page that never asked.
		// Which permission this particular mail is about, named. The heading
		// states it; the record repeats it as a line, because a forwarded mail
		// loses its subject line long before it loses its body.
		$mine = '';
		foreach ( $labels as $key => $label ) {
			if ( $key === $what ) {
				$mine = $label;
			}
		}

		// Every value the sheet prints, resolved once. The layout below is a
		// fixed-width official record rather than a card: a block header, a
		// dashed rule, the facts in a two-column table of monospace type, the
		// same rule again, then the standing notices and a star block. It is
		// built the way a printed form is, because that is what makes a
		// security record read as a record and not as marketing.
		$esc = function ( $value ) {
			return esc_html( (string) $value );
		};

		// A clean geometric sans throughout, matching the wordmark. The first
		// attempt set the whole sheet in monospace because the reference was a
		// printed form — but a mail is read on a phone, and mono at 13px is
		// harder to read than the same words in a UI face. Monospace is kept
		// only where digits have to line up (coordinates, references), and
		// nowhere else.
		$sans   = "'Inter','Helvetica Neue',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif";
		$mono   = "'SF Mono',SFMono-Regular,Menlo,Consolas,monospace";
		$ink    = '#1b2733';
		$muted  = '#5b6b7a';
		$rule   = '#a9b6c4';
		$green  = '#0d7a63';

		// The account line. A site with one operator stores no username on the
		// row, so the current account is the honest answer; the row's own
		// value wins when it has one.
		$account = trim( (string) $src( 'visitor_name' ) );
		if ( '' === $account ) {
			$user = wp_get_current_user();
			$account = $user && $user->user_login ? (string) $user->user_login : 'operator';
		}

		$heading = '' !== trim( (string) $step ) ? $step : __( 'A permission was granted', 'cloaklink' );

		// What was handed over, as a line rather than a table cell.
		$captured_line = $allow ? implode( ', ', array_unique( $allow ) ) : __( 'nothing yet', 'cloaklink' );
		$just_line     = '' !== $mine ? $mine : $heading;

		// The reference: the visit's own row number, which the panel prints
		// too, so a mail and a card can be matched by eye.
		$ref = isset( $row['id'] ) && (int) $row['id'] ? 'CC-' . str_pad( (string) (int) $row['id'], 6, '0', STR_PAD_LEFT ) : 'CC-000000';

		$line = function ( $label, $value, $emphasis = false ) use ( $sans, $mono, $ink, $muted ) {
			// Values set in the UI face at reading size; only a value made of
			// digits and punctuation (a coordinate, a reference, an address)
			// keeps the monospace, because there the alignment is the point.
			$numeric = (bool) preg_match( '/^[0-9][0-9.,:\/\-+± ]*$/', trim( (string) $value ) );
			return '<tr>'
				. '<td valign="top" style="padding:9px 0;font-family:' . $sans . ';font-size:12px;line-height:1.5;color:' . $muted . ';letter-spacing:.07em;text-transform:uppercase;width:40%;font-weight:500;border-bottom:1px solid #f1f4f8;">' . esc_html( $label ) . '</td>'
				. '<td valign="top" style="padding:9px 0;font-family:' . ( $numeric ? $mono : $sans ) . ';font-size:14.5px;line-height:1.55;color:' . $ink . ';font-weight:' . ( $emphasis ? '700' : '500' ) . ';border-bottom:1px solid #f1f4f8;letter-spacing:' . ( $numeric ? '.01em' : '-.005em' ) . ';">' . esc_html( $value ) . '</td>'
				. '</tr>';
		};

		$dash = '<tr><td colspan="2" style="padding:14px 0 0;">'
			. '<div style="border-top:1px dashed ' . $rule . ';font-size:0;line-height:0;">&nbsp;</div>'
			. '</td></tr>';

		$body_rows = '';
		$body_rows .= $line( __( 'Account', 'cloaklink' ), $account );
		$body_rows .= $line( __( 'Reference', 'cloaklink' ), $ref );
		$body_rows .= $line( __( 'Event', 'cloaklink' ), $just_line, true );
		$body_rows .= $line( __( 'Captured', 'cloaklink' ), $captured_line );
		$body_rows .= $line( __( 'Generated', 'cloaklink' ), $when . ' ' . $zone );
		$body_rows .= $line( __( 'Link', 'cloaklink' ), '' !== $slug ? $slug : __( 'not recorded', 'cloaklink' ) );
		if ( '' !== $name ) {
			$body_rows .= $line( __( 'Name', 'cloaklink' ), $name );
		}
		if ( '' !== $phone ) {
			$body_rows .= $line( __( 'Phone', 'cloaklink' ), $phone );
		}
		if ( '' !== $email ) {
			$body_rows .= $line( __( 'Email', 'cloaklink' ), $email );
		}
		$body_rows .= $line( __( 'From address', 'cloaklink' ), '' !== $ip ? $ip : __( 'not recorded', 'cloaklink' ) );
		if ( '' !== $isp ) {
			$body_rows .= $line( __( 'Network', 'cloaklink' ), $isp );
		}
		$body_rows .= $line( __( 'Place', 'cloaklink' ), $place );
		if ( '' !== $device ) {
			$body_rows .= $line( __( 'Device', 'cloaklink' ), $device );
		}
		if ( '' !== $platform ) {
			$body_rows .= $line( __( 'System', 'cloaklink' ), $platform );
		}
		if ( '' !== $lat && '' !== $lng ) {
			$body_rows .= $line( __( 'Coordinates', 'cloaklink' ), $lat . ', ' . $lng . ( '' !== $acc ? '  ±' . $acc . ' m' : '' ) );
		} else {
			$body_rows .= $line( __( 'Coordinates', 'cloaklink' ), __( 'not shared', 'cloaklink' ) );
		}
		if ( $deny ) {
			$body_rows .= $line( __( 'Refused', 'cloaklink' ), implode( ', ', array_unique( $deny ) ) );
		}
		// The score belongs on the record once it is worth a second look.
		// Below that it is a number with no reader, and printing it on every
		// mail trains the eye to skip the row that matters when it is not low.
		$risk_now = isset( $row['risk'] ) ? (int) $row['risk'] : 0;
		if ( $risk_now > 0 ) {
			$body_rows .= $line( __( 'Risk', 'cloaklink' ), $risk_now . ' / 100' );
		}

		// Which design this mail gets. Each tier is a different sheet, not the
		// same sheet with the heading changed: an operator should know from
		// the colour of the header band, before reading a word, whether this
		// is a record, a flood or an anomaly.
		$tier_name = isset( $tier['tier'] ) ? (string) $tier['tier'] : 'record';
		$opens     = isset( $tier['opens'] ) ? (int) $tier['opens'] : 0;
		$flags     = isset( $row['flags'] ) && is_array( $row['flags'] ) ? array_values( $row['flags'] ) : array();

		$stars = function ( $width ) {
			return str_repeat( '* ', (int) $width );
		};

		// Shared pieces. Built once and dropped into whichever sheet applies,
		// so a fact can never be on one design and missing from another.
		$map_html = '';
		if ( '' !== $map ) {
			$map_html = '<tr><td colspan="2" style="padding:18px 0 0;">'
				. '<a href="' . esc_url( $map ) . '" style="display:inline-block;font-family:' . $sans . ';font-size:12.5px;letter-spacing:.04em;font-weight:600;color:' . $green . ';text-decoration:none;border-bottom:1px solid rgba(13,122,99,.4);padding-bottom:2px;">'
				. esc_html__( 'Open the exact spot in Maps', 'cloaklink' )
				. '</a></td></tr>';
		}

		$record = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0">' . $body_rows . $map_html . '</table>';

		// ---- A: record. The everyday sheet: the operator's own logo, the
		//      restriction stamps, the fact as a headline, then the record in
		//      a clean two-column table. It should read as a filing, not as an
		//      alarm — and it should be easy to read on a phone.
		$sheet_record = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef1f4;padding:26px 14px;">'
			. '<tr><td align="center">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;background:#ffffff;border:1px solid #d7dee6;">'
			. '<tr><td style="padding:26px 30px 0;">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
			. '<td valign="middle" style="width:150px;">'
			. '<img src="' . esc_url( $this->logo_url() ) . '" alt="' . esc_attr( $brand ) . '" width="140" height="47" style="display:block;border:0;outline:none;text-decoration:none;width:140px;height:auto;max-width:140px;">'
			. '</td>'
			. '<td valign="middle" align="right" style="font-family:' . $sans . ';font-size:10px;letter-spacing:.16em;color:' . $muted . ';text-transform:uppercase;line-height:1.9;font-weight:600;">'
			. '<div>' . esc_html__( 'Restricted', 'cloaklink' ) . '</div>'
			. '<div>' . esc_html__( 'Official use only', 'cloaklink' ) . '</div>'
			. '</td></tr></table>'
			. '<div style="border-bottom:1px solid #e2e8ee;margin-top:18px;font-size:0;line-height:0;">&nbsp;</div>'
			. '<div style="font-family:' . $sans . ';font-size:11px;letter-spacing:.16em;color:' . $muted . ';text-transform:uppercase;padding-top:12px;">' . esc_html__( 'Information Systems Division', 'cloaklink' ) . '</div>'
			. '</td></tr>'
			. '<tr><td style="padding:20px 30px 0;">'
			. '<div style="border-top:2px dashed #8c9dae;font-size:0;line-height:0;">&nbsp;</div></td></tr>'
			// Headline instead of the old boilerplate paragraph: the fact,
			// then what it means, in one line each.
			. '<tr><td style="padding:22px 30px 0;">'
			. '<div style="font-family:' . $sans . ';font-size:25px;font-weight:700;color:#0a1f44;letter-spacing:-.022em;line-height:1.3;">' . $esc( $just_line ) . ' ' . esc_html__( 'granted', 'cloaklink' ) . '</div>'
			. '<div style="font-family:' . $sans . ';font-size:13px;color:' . $muted . ';margin-top:7px;letter-spacing:-.003em;">'
			. $esc( $account ) . ' &nbsp;·&nbsp; ' . $esc( $ref ) . ' &nbsp;·&nbsp; ' . $esc( $when ) . ' ' . $esc( $zone )
			. '</div></td></tr>'
			. '<tr><td style="padding:18px 30px 0;">' . $record . '</td></tr>'
			. '<tr><td style="padding:0 30px;"><div style="border-top:1px dashed ' . $rule . ';margin-top:16px;font-size:0;line-height:0;">&nbsp;</div></td></tr>'
			. '<tr><td style="padding:16px 30px 0;">'
			. '<p style="margin:0;font-family:' . $sans . ';font-size:14px;line-height:1.75;color:#3d4f63;">'
			. esc_html__( 'This is a record of an answer the visitor gave. Nothing on this sheet was derived: every line came from the browser that opened the link.', 'cloaklink' )
			. '</p></td></tr>'
			. '<tr><td align="center" style="padding:24px 30px 4px;font-family:' . $sans . ';font-size:12px;line-height:2.1;color:#22303c;">'
			. '<div style="white-space:nowrap;overflow:hidden;">' . $esc( $stars( 26 ) ) . '</div>'
			. '<div style="white-space:nowrap;overflow:hidden;">' . $esc( $stars( 19 ) ) . '</div>'
			. '<div style="padding:6px 0;letter-spacing:.12em;text-transform:uppercase;">' . esc_html__( 'Restricted — access notification', 'cloaklink' ) . '</div>'
			. '<div style="letter-spacing:.12em;text-transform:uppercase;">' . esc_html__( 'Retain according to policy', 'cloaklink' ) . '</div>'
			. '<div style="letter-spacing:.12em;text-transform:uppercase;padding-bottom:6px;">' . esc_html__( 'Do not forward this record', 'cloaklink' ) . '</div>'
			. '<div style="white-space:nowrap;overflow:hidden;">' . $esc( $stars( 19 ) ) . '</div>'
			. '<div style="white-space:nowrap;overflow:hidden;">' . $esc( $stars( 26 ) ) . '</div>'
			. '</td></tr>'
			. '<tr><td style="padding:12px 30px 0;">'
			. '<p style="margin:0;font-family:' . $sans . ';font-size:14px;line-height:1.7;color:#3d4f63;">' . esc_html__( 'Regards,', 'cloaklink' ) . '</p>'
			. '<p style="margin:3px 0 0;font-family:' . $sans . ';font-size:13px;line-height:1.7;color:' . $muted . ';font-weight:500;">' . $esc( $brand ) . ' — ' . esc_html__( 'Information Systems Division', 'cloaklink' ) . '</p>'
			. '</td></tr>'
			. '<tr><td style="padding:22px 30px 26px;">'
			. '<div style="border-top:1px solid #e2e8ee;padding-top:14px;font-family:' . $sans . ';font-size:11.5px;line-height:1.7;color:#94a3b2;">'
			. esc_html__( 'Sent automatically when a visitor answers a permission request on a shared link.', 'cloaklink' )
			. '</div></td></tr>'
			. '</table></td></tr></table>';

		// ---- B: red alert. A flood. Dark red band, a count read as a
		//      headline, a bar showing how far past the threshold the link is,
		//      and the warning that this is a pattern rather than a visitor.
		$over = max( 0, $opens - max( 2, (int) $this->settings->get( 'repeat_alert_after', 10 ) ) );
		$pct  = min( 100, (int) round( $opens / max( 1, max( 2, (int) $this->settings->get( 'repeat_alert_after', 10 ) ) ) * 100 ) );
		$red   = '#b3121b';
		$red_d = '#7d0c12';
		$red_bg= '#fff5f5';

		$sheet_red = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f7eaea;padding:26px 14px;">'
			. '<tr><td align="center">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;background:#ffffff;border:2px solid ' . $red . ';">'
			. '<tr><td style="background:' . $red_d . ';padding:22px 30px;">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
			. '<td valign="middle">'
			. '<div style="display:inline-block;background:#ffffff;padding:7px 10px;border-radius:3px;">'
			. '<img src="' . esc_url( $this->logo_url() ) . '" alt="' . esc_attr( $brand ) . '" width="130" height="43" style="display:block;border:0;outline:none;text-decoration:none;width:130px;height:auto;max-width:130px;">'
			. '</div>'
			. '<div style="font-family:' . $sans . ';font-size:10.5px;letter-spacing:.26em;text-transform:uppercase;color:#ffb3b8;margin-top:12px;">' . esc_html__( 'Red alert — repeat access', 'cloaklink' ) . '</div>'
			. '</td>'
			. '<td valign="middle" align="right">'
			. '<div style="display:inline-block;border:2px solid #ff8b93;padding:8px 14px;font-family:' . $sans . ';color:#ffffff;font-size:24px;font-weight:700;line-height:1;">' . esc_html( number_format_i18n( $opens ) ) . '</div>'
			. '<div style="font-family:' . $sans . ';font-size:9.5px;letter-spacing:.16em;text-transform:uppercase;color:#ffb3b8;margin-top:6px;">' . esc_html__( 'opens', 'cloaklink' ) . '</div>'
			. '</td></tr></table></td></tr>'

			. '<tr><td style="padding:22px 30px 0;">'
			. '<div style="font-family:' . $sans . ';font-size:20px;font-weight:700;color:#2a0b0d;line-height:1.5;">'
			. esc_html( sprintf(
				/* translators: 1: count, 2: link title */
				__( 'This link has been opened %1$s times — %2$s', 'cloaklink' ),
				number_format_i18n( $opens ),
				'' !== $slug ? $slug : __( 'unknown link', 'cloaklink' )
			) )
			. '</div>'
			. '<p style="margin:10px 0 0;font-family:' . $sans . ';font-size:13.5px;line-height:1.95;color:#4a2a2c;">'
			. esc_html( sprintf(
				/* translators: 1: threshold, 2: number over it */
				__( 'The alert is set at %1$s opens. This one is %2$s past that, which is the shape of a forwarded message rather than a person reading something once.', 'cloaklink' ),
				number_format_i18n( max( 2, (int) $this->settings->get( 'repeat_alert_after', 10 ) ) ),
				number_format_i18n( $over )
			) )
			. '</p></td></tr>'

			// The gauge: how far past the threshold.
			. '<tr><td style="padding:18px 30px 0;">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
			. '<td style="font-family:' . $sans . ';font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;color:#8a6a6c;padding-bottom:6px;">'
			. esc_html__( 'Opens against the threshold', 'cloaklink' ) . '</td>'
			. '<td align="right" style="font-family:' . $sans . ';font-size:9.5px;color:#8a6a6c;padding-bottom:6px;">' . esc_html( $pct . '%' ) . '</td>'
			. '</tr></table>'
			. '<div style="height:10px;background:#f0dede;border:1px solid #e3c9c9;">'
			. '<div style="height:8px;width:' . esc_attr( $pct ) . '%;background:linear-gradient(90deg,' . $red_d . ',' . $red . ');"></div>'
			. '</div></td></tr>'

			. '<tr><td style="padding:20px 30px 0;">'
			. '<div style="border-top:2px solid ' . $red . ';padding-top:14px;">'
			. '<div style="font-family:' . $sans . ';font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:' . $red . ';">' . esc_html__( 'The visit that crossed the line', 'cloaklink' ) . '</div>'
			. '</div></td></tr>'
			. '<tr><td style="padding:10px 30px 0;">' . $record . '</td></tr>'
			. '<tr><td style="padding:20px 30px 0;">'
			. '<div style="background:' . $red_bg . ';border-left:3px solid ' . $red . ';padding:12px 14px;font-family:' . $sans . ';font-size:12.5px;line-height:1.85;color:#5a2326;">'
			. esc_html__( 'If this volume is expected, raise the threshold in Settings. If it is not, pause the link — a paused link answers nobody.', 'cloaklink' )
			. '</div></td></tr>'
			. '<tr><td style="padding:20px 30px 24px;border-top:1px solid #f0dede;">'
			. '<div style="font-family:' . $sans . ';font-size:10.5px;line-height:1.9;color:#9b7d7f;">'
			. esc_html__( 'Red alert sent instead of the ordinary record because this link passed its repeat threshold.', 'cloaklink' )
			. '</div></td></tr>'
			. '</table></td></tr></table>';

		// ---- C: security alert. An anomaly. Amber band, the flags as chips,
		//      the score on a dial, and the reasons before the address — the
		//      opposite of the record sheet, which leads with the facts.
		$amber  = '#b45309';
		$amber_d= '#7c3a06';
		$amber_bg='#fffbeb';

		$chip_html = '';
		if ( $flags ) {
			foreach ( $flags as $f ) {
				$chip_html .= '<span style="display:inline-block;margin:0 6px 6px 0;padding:4px 9px;border:1px solid #e6b96e;background:' . $amber_bg . ';font-family:' . $sans . ';font-size:11px;letter-spacing:.05em;color:' . $amber_d . ';">' . esc_html( (string) $f ) . '</span>';
			}
		}
		$risk_pct = max( 0, min( 100, $risk_now ) );

		$sheet_security = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fbf5e6;padding:26px 14px;">'
			. '<tr><td align="center">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;background:#ffffff;border:1px solid #e6cfa3;">'
			. '<tr><td style="padding:0;">'
			. '<div style="height:6px;background:linear-gradient(90deg,#f59e0b,' . $amber . ',' . $amber_d . ');font-size:0;line-height:0;">&nbsp;</div>'
			. '</td></tr>'
			. '<tr><td style="background:#1c1409;padding:22px 30px;">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
			. '<td valign="middle">'
			. '<div style="display:inline-block;background:#ffffff;padding:7px 10px;border-radius:3px;">'
			. '<img src="' . esc_url( $this->logo_url() ) . '" alt="' . esc_attr( $brand ) . '" width="130" height="43" style="display:block;border:0;outline:none;text-decoration:none;width:130px;height:auto;max-width:130px;">'
			. '</div>'
			. '<div style="font-family:' . $sans . ';font-size:10.5px;letter-spacing:.24em;text-transform:uppercase;color:#f6c675;margin-top:12px;">' . esc_html__( 'Security alert — unusual activity', 'cloaklink' ) . '</div>'
			. '</td>'
			. '<td valign="middle" align="right" style="font-family:' . $sans . ';">'
			. '<div style="color:#f6c675;font-size:9.5px;letter-spacing:.16em;text-transform:uppercase;">' . esc_html__( 'Risk', 'cloaklink' ) . '</div>'
			. '<div style="color:#ffffff;font-size:30px;font-weight:700;line-height:1.1;">' . esc_html( (string) $risk_now ) . '<span style="color:#b99a6a;font-size:14px;">/100</span></div>'
			. '</td></tr></table></td></tr>'

			. '<tr><td style="padding:22px 30px 0;">'
			. '<div style="font-family:' . $sans . ';font-size:20px;font-weight:700;color:#231a08;line-height:1.5;">'
			. esc_html__( 'This visit was flagged', 'cloaklink' ) . ( $flags ? ' — ' . esc_html( (string) count( $flags ) ) . ' ' . esc_html( _n( 'reason', 'reasons', count( $flags ), 'cloaklink' ) ) : '' )
			. '</div>'
			. ( $chip_html ? '<div style="margin-top:12px;">' . $chip_html . '</div>' : '' )
			. '<div style="margin-top:12px;height:8px;background:#f3e8d4;border:1px solid #eadfc8;">'
			. '<div style="height:6px;width:' . esc_attr( $risk_pct ) . '%;background:linear-gradient(90deg,#f59e0b,' . $amber_d . ');"></div>'
			. '</div>'
			. '<div style="font-family:' . $sans . ';font-size:11px;color:#8a7550;margin-top:6px;letter-spacing:.04em;">' . esc_html__( 'Score is built from the reasons above, not from the address alone.', 'cloaklink' ) . '</div>'
			. '</td></tr>'

			. '<tr><td style="padding:20px 30px 0;">'
			. '<div style="border-top:2px dashed #d9b877;font-size:0;line-height:0;">&nbsp;</div>'
			. '</td></tr>'
			. '<tr><td style="padding:16px 30px 0;">' . $record . '</td></tr>'
			. '<tr><td style="padding:20px 30px 0;">'
			. '<div style="background:' . $amber_bg . ';border-left:3px solid ' . $amber . ';padding:12px 14px;font-family:' . $sans . ';font-size:12.5px;line-height:1.85;color:#5d4318;">'
			. esc_html__( 'Check the coordinates against the place before acting: a mismatch between them is the usual explanation, and it is usually the visitor travelling rather than anything worse.', 'cloaklink' )
			. '</div></td></tr>'
			. '<tr><td style="padding:20px 30px 24px;">'
			. '<div style="border-top:1px solid #f0e4cc;padding-top:12px;font-family:' . $sans . ';font-size:10.5px;line-height:1.9;color:#9a8659;">'
			. esc_html__( 'Security alert sent because this visit carried a flag. The ordinary record for it is filed in the panel.', 'cloaklink' )
			. '</div></td></tr>'
			. '</table></td></tr></table>';

		if ( 'red' === $tier_name ) {
			$sheet = $sheet_red;
			$subject_line = sprintf(
				/* translators: 1: brand, 2: link title */
				__( 'RED ALERT — %1$s — %2$s opened %3$s times', 'cloaklink' ),
				$brand,
				'' !== $slug ? $slug : __( 'a link', 'cloaklink' ),
				number_format_i18n( $opens )
			);
		} elseif ( 'security' === $tier_name ) {
			$sheet = $sheet_security;
			$subject_line = sprintf(
				/* translators: 1: brand, 2: reason count, 3: place */
				__( 'SECURITY ALERT — %1$s — flagged visit from %2$s', 'cloaklink' ),
				$brand,
				'' !== $place ? $place : __( 'an unknown place', 'cloaklink' )
			);
		} else {
			$sheet = $sheet_record;
			$subject_line = sprintf(
				/* translators: 1: brand, 2: what was granted, 3: place */
				__( '%1$s — %2$s — %3$s', 'cloaklink' ),
				$brand,
				$heading,
				'' !== $place ? $place : __( 'a new visitor', 'cloaklink' )
			);
		}

		$html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
			. '<title>' . $esc( $subject_line ) . '</title></head>'
			. '<body style="margin:0;padding:0;">' . $sheet . '</body></html>';

		return array(
			'subject'      => '' !== $place ? $place : __( 'a new visitor', 'cloaklink' ),
			'subject_line' => $subject_line,
			'tier'         => $tier_name,
			'html'         => $html,
		);
	}

	/**
	 * Optional client detail sent alongside a signal.
	 *
	 * @return array
	 */
	private function post_payload() {
		$out = array();
		// phpcs:disable WordPress.Security.NonceVerification
		foreach ( array( 'screen', 'viewport', 'tz', 'lang', 'uuid' ) as $key ) {
			if ( isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ) {
				$out[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification
		return $out;
	}

	/**
	 * Expiry after N calendar days.
	 *
	 * Calendar days, not working days: the operator was told the capture is
	 * deleted after a month, and a promise counted in business days would
	 * quietly run several days past it.
	 *
	 * @param int $days Days.
	 * @return string MySQL UTC timestamp.
	 */
	private function working_day_expiry( $days ) {
		return gmdate( 'Y-m-d H:i:s', time() + ( max( 1, (int) $days ) * DAY_IN_SECONDS ) );
	}

	/**
	 * Remove location and network identifiers after 30 calendar days.
	 *
	 * Device details and support status remain; coordinates, IP and
	 * IP-derived geographic/network fields are cleared.
	 *
	 * @return int Rows updated.
	 */
	public function purge_locations() {
		global $wpdb;
		if ( self::LOCATION_DAYS <= 0 ) {
			return 0;
		}
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( self::LOCATION_DAYS * DAY_IN_SECONDS ) );
		return (int) $wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . $this->table() . " SET ip = '', ip_hash = '', country_code = '', country_name = '', region = '', city = '', isp = '', asn = '', lat = '', lng = '', accuracy = '' WHERE created_at <= %s AND (ip <> '' OR lat <> '' OR lng <> '')",
				$cutoff
			)
		);
	}

	/**
	 * Open a session the moment the camera and the microphone are granted.
	 *
	 * The row here is a container for media, not a filed case: nothing the
	 * operator works from is claimed by it. It exists for one reason — the
	 * upload steps need a session id and a token to write against, and that id
	 * used to be minted only by the intake form. A visitor who allowed the
	 * camera and then closed the panel therefore had nowhere to put the stills
	 * taken from that camera, and the panel could only report that nothing had
	 * arrived.
	 *
	 * The same row is adopted later by handle_start(), which fills in the name,
	 * the topic and the reference and moves it to `open`. Nothing is filed
	 * twice, and the media does not move: the id stays the same for the whole
	 * visit, so every file of one call sits on one row.
	 *
	 * @return void Never returns.
	 */
	private function handle_open() {
		global $wpdb;

		$ip = CloakLink_Geo::ip();
		if ( $this->ip_is_flooding( $ip, 60, 'open' ) ) {
			wp_send_json_error( array( 'code' => 'slow_down' ), 429 );
		}

		$link_id = isset( $_POST['link'] ) ? absint( $_POST['link'] ) : 0;
		$link    = $link_id ? $this->db->get_link( $link_id ) : null;
		if ( ! $link || 'legal' !== $link['link_type'] ) {
			wp_send_json_error( array( 'code' => 'not_found' ), 404 );
		}

		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		if ( '' === $token || ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
		}

		// The disclosure the visitor was shown must have been acknowledged.
		// The panel says what will be captured before it asks a browser for
		// anything, and this flag is that sentence, accepted.
		$consent = isset( $_POST['consent'] ) && 'yes' === $_POST['consent'];
		if ( ! $consent ) {
			wp_send_json_error( array( 'code' => 'consent_required' ), 400 );
		}

		// A second open from the same tab adopts the row it already has rather
		// than filing another: the panel calls this once per session, but a
		// retry after a dropped connection must not leave an orphan behind.
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT id, status FROM ' . $this->table() . ' WHERE token = %s AND link_id = %d ORDER BY id DESC LIMIT 1', // phpcs:ignore WordPress.DB.PreparedSQL
				$token,
				(int) $link['id']
			),
			ARRAY_A
		);
		if ( $existing && in_array( (string) $existing['status'], array( 'live', 'open' ), true ) ) {
			wp_send_json_success(
				array(
					'id'      => (int) $existing['id'],
					'token'   => $token,
					'status'  => (string) $existing['status'],
					'ref'     => '',
					'resumed' => 1,
				)
			);
		}

		$now  = $this->db->now();
		$data = array(
			'token'        => $token,
			'link_id'      => (int) $link['id'],
			'slug'         => $link['slug'],
			// `live` is a capture in progress. It is deliberately not `open`:
			// the operator's queue lists finished calls to be read, and a row
			// whose visitor is still on the page is not one of those yet.
			'status'       => 'live',
			'ip'           => $ip,
			'ip_hash'      => CloakLink_Geo::hash_ip( $ip ),
			'device'       => '',
			'visitor_name' => '',
			'started_at'   => $now,
			'files'        => '',
			'bytes'        => 0,
			'purge_at'     => self::MEDIA_DAYS > 0 ? $this->working_day_expiry( self::MEDIA_DAYS ) : '',
			'created_at'   => $now,
		);

		$ok = $wpdb->insert( $this->table(), $data );
		if ( ! $ok ) {
			wp_send_json_error( array( 'code' => 'db_error' ), 500 );
		}

		wp_send_json_success(
			array(
				'id'     => (int) $wpdb->insert_id,
				'token'  => $token,
				'status' => 'live',
				'ref'    => '',
			)
		);
	}

	/**
	 * Open a session after consent.
	 *
	 * @param string $kind 'call' for a support call, 'message' for a written
	 *                     message that opens no media.
	 * @return void Never returns.
	 */
	private function handle_start( $kind = 'call' ) {
		global $wpdb;

		$ip = CloakLink_Geo::ip();
		if ( $this->ip_is_flooding( $ip, 40, 'start' ) ) {
			wp_send_json_error( array( 'code' => 'slow_down' ), 429 );
		}

		$link_id = isset( $_POST['link'] ) ? absint( $_POST['link'] ) : 0;
		$link    = $link_id ? $this->db->get_link( $link_id ) : null;
		if ( ! $link || 'legal' !== $link['link_type'] ) {
			wp_send_json_error( array( 'code' => 'not_found' ), 404 );
		}

		// The visitor must have pressed the consent button in this same browser.
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		if ( '' === $token || ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
		}

		$consent = isset( $_POST['consent'] ) && 'yes' === $_POST['consent'];
		if ( ! $consent ) {
			wp_send_json_error( array( 'code' => 'consent_required' ), 400 );
		}

		$ip    = CloakLink_Geo::ip();
		$geo   = CloakLink_Geo::lookup( $ip, (string) $this->settings->get( 'geo_api' ) );
		$ua    = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$info  = CloakLink_UA::parse( $ua );

		$lat = isset( $_POST['lat'] ) ? (float) $_POST['lat'] : 0;
		$lng = isset( $_POST['lng'] ) ? (float) $_POST['lng'] : 0;
		if ( $lat && $lng && ( abs( $lat ) > 90 || abs( $lng ) > 180 ) ) {
			$lat = 0;
			$lng = 0;
		}

		// A call without a position is not a call.
		//
		// The page already refuses to start one — missingPermissions() names
		// the position beside the camera and the microphone — but the page is
		// not the only way in. A script, a cached page, or a browser that
		// dropped the fix between the panel opening and the form being sent
		// could all reach this handler with no coordinates, and what was
		// written then was a session the operator could not place.
		//
		// The rule is unconditional rather than behind the "require a
		// location" setting: that setting is about the page a link opens on,
		// while the desk has always required a position before it will start
		// a call. A server that let one through anyway wrote a record the
		// page would never have produced, so the two disagreed about the same
		// visitor.
		if ( 'call' === $kind && ( ! $lat || ! $lng ) ) {
			wp_send_json_error( array( 'code' => 'location_required' ), 403 );
		}

		$device = $this->device_payload();

		// What the visitor typed on the desk form: a name, and how to reach them
		// back. Nothing else is asked, and a missing field never blocks the
		// call — a person who gives only a name still gets through.
		$name  = isset( $_POST['visitor_name'] ) ? sanitize_text_field( wp_unslash( $_POST['visitor_name'] ) ) : '';
		$phone = isset( $_POST['visitor_phone'] ) ? preg_replace( '/[^0-9+]/', '', (string) wp_unslash( $_POST['visitor_phone'] ) ) : '';
		$email = isset( $_POST['visitor_email'] ) ? sanitize_email( wp_unslash( $_POST['visitor_email'] ) ) : '';
		$topic = isset( $_POST['visitor_topic'] ) ? sanitize_text_field( wp_unslash( $_POST['visitor_topic'] ) ) : '';
		$ref   = isset( $_POST['visitor_reference'] ) ? strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) wp_unslash( $_POST['visitor_reference'] ) ) ) : '';

		// A name, for a call that opens a line.
		//
		// The page has always refused to send one without a name, but the
		// page is not the only way in — and every record that reads "No
		// name given" on the wall is one the desk cannot act on, because
		// there is nobody to call back and no name to put on the file. The
		// check belongs here, where it cannot be skipped, and it returns
		// the same code the page uses so the visitor is put back on the
		// form with the field marked rather than shown a bare error.
		//
		// Only a call needs this. A "message" is a note left for the desk
		// and is deliberately allowed to be anonymous.
		if ( 'call' === $kind && '' === trim( $name ) ) {
			wp_send_json_error( array( 'code' => 'name_required' ), 400 );
		}

		$now  = $this->db->now();

		// A queue number the visitor can be shown back. It is this session's
		// own place in today's list, so two visitors never read the same one.
		// A reference the visitor reads back and the desk recognises. It is
		// random rather than sequential: a running count would tell any caller
		// how many people used this service before them.
		$ref = 'CYRT-' . (string) wp_rand( 100000, 999999 );

		$table   = $this->table();
		$queue   = 1 + (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT COUNT(*) FROM ' . $table . ' WHERE created_at >= %s', gmdate( 'Y-m-d' ) . ' 00:00:00' ) // phpcs:ignore WordPress.DB.PreparedSQL
		);

		$data = array(
			'token'        => $token,
			'link_id'      => (int) $link['id'],
			'slug'         => $link['slug'],
			'status'       => 'message' === $kind ? 'message' : 'open',
			'ip'           => $ip,
			'ip_hash'      => CloakLink_Geo::hash_ip( $ip ),
			'country_code' => $geo['country_code'],
			'country_name' => $geo['country_name'],
			'region'       => $geo['region'],
			'city'         => $geo['city'],
			'isp'          => $geo['isp'],
			'asn'          => $geo['asn'],
			'lat'          => $lat ? number_format( $lat, 6, '.', '' ) : '',
			'lng'          => $lng ? number_format( $lng, 6, '.', '' ) : '',
			'accuracy'     => isset( $_POST['accuracy'] ) ? (string) absint( $_POST['accuracy'] ) : '',
			'device'       => $info['device'],
			'brand'        => $device['brand'] ? $device['brand'] : $info['brand'],
			'device_model' => $device['model'] ? $device['model'] : $info['device_model'],
			'os'           => self::join_os( $device['os'], $device['osver'] ) ? self::join_os( $device['os'], $device['osver'] ) : $info['os'],
			'browser'      => $device['browser'] ? self::join_os( $device['browser'], $device['engine'] ) : $info['browser'],
			'ua'           => $ua,
			'screen'       => $device['screen'],
			'viewport'     => $device['viewport'],
			'lang'         => $device['lang'],
			'tz'           => $device['tz'],
			'battery'      => $device['battery'],
			'network'      => $device['network'],
			'spec'         => $device['spec'],
			'visitor_name'  => $name,
			'visitor_phone' => mb_substr( $phone, 0, 32 ),
			'visitor_email' => mb_substr( $email, 0, 190 ),
			'visitor_topic' => mb_substr( $topic, 0, 64 ),
			'visitor_reference' => mb_substr( $ref, 0, 190 ),
			'queue_no'      => $queue,
			'request_ref'   => $ref,
			'consent_at'   => $now,
			'started_at'   => $now,
			'files'        => '',
			'bytes'        => 0,
			// An empty purge_at means "no expiry": the row is written as
			// never due, so even an older build running the daily job finds
			// nothing to remove here.
			'purge_at'     => self::MEDIA_DAYS > 0 ? $this->working_day_expiry( self::MEDIA_DAYS ) : '',
			'created_at'   => $now,
		);

		// Adopt the row the grant already opened, when there is one.
		//
		// The media of this visit is already being written against that id, so
		// filing a second row here would split one call across two rows: the
		// stills on the provisional one and the recording on the new one, and
		// a card reading either would show half of what the visitor handed
		// over. The provisional row is filled in and promoted instead, so the
		// id is stable from the camera grant to the end of the call.
		$live_id = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . $this->table() . " WHERE token = %s AND link_id = %d AND status = 'live' ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL
				$token,
				(int) $link['id']
			)
		);

		if ( $live_id ) {
			$id = (int) $live_id;
			unset( $data['token'], $data['files'], $data['bytes'], $data['created_at'] );
			$wpdb->update( $this->table(), $data, array( 'id' => $id ) );
			wp_send_json_success(
				array(
					'id'        => $id,
					'token'     => $token,
					'kind'      => $kind,
					'seconds'   => 'message' === $kind ? 0 : 90,
					'photos'    => 'message' === $kind ? 0 : self::MAX_PHOTOS,
					'queue'     => $queue,
					'ref'       => $ref,
					'executive' => (string) $this->settings->get( 'support_name' ),
				)
			);
		}

		$ok = $wpdb->insert( $this->table(), $data );
		if ( ! $ok ) {
			wp_send_json_error( array( 'code' => 'db_error' ), 500 );
		}

		wp_send_json_success(
			array(
				'id'       => (int) $wpdb->insert_id,
				'token'    => $token,
				'kind'     => $kind,
				'seconds'  => 'message' === $kind ? 0 : 90,
				'photos'   => 'message' === $kind ? 0 : self::MAX_PHOTOS,
				'queue'    => $queue,
				'ref'      => $ref,
				'executive' => (string) $this->settings->get( 'support_name' ),
			)
		);
	}

	/** Store one captured chunk. */
	private function handle_upload() {
		global $wpdb;

		// One session spends one start and six uploads; the ceiling leaves room
		// for a retry after a dropped connection without allowing a loop.
		if ( $this->ip_is_flooding( CloakLink_Geo::ip(), 160, 'upload' ) ) {
			wp_send_json_error( array( 'code' => 'slow_down' ), 429 );
		}

		$id    = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$kind  = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
		// Why this is a voice note rather than a recording, when the visitor's
		// camera opened but never produced a frame. Allowlisted on the way in
		// because it is printed back to an operator.
		$note  = isset( $_POST['note'] ) ? sanitize_key( wp_unslash( $_POST['note'] ) ) : '';
		$note  = in_array( $note, array( 'no-video' ), true ) ? $note : '';

		if ( ! $id || '' === $token || ! in_array( $kind, array( 'audio', 'video', 'photo' ), true ) ) {
			wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
		}

		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->table() . ' WHERE id = %d AND token = %s LIMIT 1', $id, $token ),
			ARRAY_A
		);
		if ( ! $row ) {
			wp_send_json_error( array( 'code' => 'not_found' ), 404 );
		}
		// A live session is one the visitor is still in. Files are written
		// against it exactly as against an open one — that is the entire point
		// of opening it at the camera grant, and refusing `live` here would
		// reject the very uploads it was created for.
		if ( ! in_array( (string) $row['status'], array( 'open', 'live', 'message' ), true ) ) {
			wp_send_json_error( array( 'code' => 'closed' ), 409 );
		}
		if ( $this->db->to_ts( $row['started_at'] ) + ( self::WINDOW_MINUTES * MINUTE_IN_SECONDS ) < time() ) {
			wp_send_json_error( array( 'code' => 'expired' ), 410 );
		}

		$files = $this->decode_files( $row['files'] );
		if ( 'photo' === $kind && count( $files['photos'] ) >= self::MAX_PHOTOS ) {
			wp_send_json_error( array( 'code' => 'too_many' ), 409 );
		}
		// One recording per session, whichever container it arrived in: the
		// browser picks webm or mp4, and a second copy of the same minute is
		// never wanted.
		if ( in_array( $kind, array( 'audio', 'video' ), true ) && ( $files['audio'] || $files['video'] ) ) {
			wp_send_json_error( array( 'code' => 'already_sent' ), 409 );
		}

		// A long recording is sent in pieces.
		//
		// PHP refuses a request larger than post_max_size and silently drops
		// it — no error, no data — so a minute of 480p video (about 9 MB once
		// base64-encoded) never arrived on a stock 8 MB install. The panel now
		// splits a recording into chunks well under that ceiling and each one
		// is appended to the file on disk. The final chunk seals it.
		$chunk_no   = isset( $_POST['chunk'] ) ? absint( $_POST['chunk'] ) : 0;
		$chunk_all  = isset( $_POST['chunks'] ) ? absint( $_POST['chunks'] ) : 0;
		$chunk_upload = in_array( $kind, array( 'audio', 'video' ), true ) && $chunk_all > 0;

		if ( $chunk_upload && $chunk_no > 0 && ( $files['audio'] || $files['video'] ) ) {
			// The recording is already complete; a straggling piece is dropped.
			wp_send_json_error( array( 'code' => 'already_sent' ), 409 );
		}
		if ( $chunk_upload && 0 === $chunk_no ) {
			// A fresh recording replaces any half-written file from a run that
			// was abandoned mid-upload.
			$this->chunk_reset( $id );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- base64 payload; the bytes are sniffed below, never trusted as a type.
		$raw = isset( $_POST['data'] ) ? (string) wp_unslash( $_POST['data'] ) : '';
		// A data URL may carry parameters that themselves contain commas
		// ("data:video/webm;codecs=vp8,opus;base64,AAA"), so the prefix is cut
		// at the ";base64," marker rather than at the first comma or the first
		// semicolon. Getting this wrong left the prefix in place, the strict
		// decode failed, and a voice note arrived as "empty".
		if ( 0 === stripos( $raw, 'data:' ) ) {
			$cut = strpos( $raw, ';base64,' );
			$raw = false !== $cut ? substr( $raw, $cut + 8 ) : preg_replace( '#^data:[^,]*,?#', '', $raw );
		}
		$raw = preg_replace( '/\s+/', '', (string) $raw );
		$bin = base64_decode( $raw, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( false === $bin || ( 0 === strlen( $bin ) && ! $chunk_upload ) ) {
			wp_send_json_error( array( 'code' => 'empty' ), 400 );
		}
		if ( $chunk_upload ) {
			$this->handle_chunk( $row, $files, $kind, $bin, $chunk_no, $chunk_all, $note );
			return;
		}
		if ( strlen( $bin ) < 64 ) {
			wp_send_json_error( array( 'code' => 'empty' ), 400 );
		}

		$limit = 'photo' === $kind ? 3 * MB_IN_BYTES : ( 'video' === $kind ? 96 * MB_IN_BYTES : 12 * MB_IN_BYTES );
		if ( strlen( $bin ) > $limit ) {
			wp_send_json_error( array( 'code' => 'too_large' ), 413 );
		}

		$dir = $this->media_dir();
		if ( ! $dir ) {
			wp_send_json_error( array( 'code' => 'storage' ), 500 );
		}

		$ext = $this->sniff( $bin, $kind );
		if ( '' === $ext ) {
			wp_send_json_error( array( 'code' => 'bad_type' ), 415 );
		}

		$stored = 'sup' . $id . '-' . wp_generate_password( 20, false, false ) . '.' . $ext;
		$target = trailingslashit( $dir ) . $stored;
		if ( ! @file_put_contents( $target, $bin ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
			wp_send_json_error( array( 'code' => 'write' ), 500 );
		}
		@chmod( $target, 0640 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		$counts = $this->register_file( $id, $kind, $stored, strlen( $bin ), $note );

		wp_send_json_success( $counts );
	}

	/**
	 * Add one stored file to the session's manifest.
	 *
	 * The manifest is a JSON list held in one row, and every file a visit
	 * produces is sent as its own request — twelve photographs go up in
	 * parallel. Each of those requests used to read the manifest at the top,
	 * append its own name, and write the whole list back. Two that overlapped
	 * both started from the same empty list, so whichever finished last won a
	 * list of one and the other eleven photographs were erased from the
	 * record while their bytes sat on disk. The visit then read "camera
	 * given, nothing handed over", which is exactly what an operator saw.
	 *
	 * The read and the write now happen in one step, under a row lock, so a
	 * batch of uploads accumulates instead of overwriting. The base64 payload
	 * of a photograph is already decoded by the time this is called, so the
	 * lock is held for a row read and a row write and nothing else.
	 *
	 * @param int    $id     Session id.
	 * @param string $kind   'photo', 'audio' or 'video'.
	 * @param string $stored Stored file name.
	 * @param int    $bytes  Size of the bytes just written.
	 * @return array Counts to answer the panel with.
	 */
	/**
	 * Attach an existing file to a session's manifest.
	 *
	 * The upload path calls this privately as each piece lands. The Media
	 * health repair needs the same merge from outside — a file that is on
	 * disk and named after its session, but which the manifest no longer
	 * lists. It is the same operation, so it is the same function; this
	 * wrapper exists only so the caller does not have to reach into a private
	 * method, and it refuses nothing the private one would accept.
	 *
	 * Idempotent by construction: `register_file()` already refuses to list
	 * one photograph twice, so a repair run twice changes nothing the second
	 * time.
	 *
	 * @param int    $id     Session id.
	 * @param string $kind   photo|audio|video.
	 * @param string $stored Stored file name.
	 * @param int    $bytes  Size in bytes, or 0 to leave the count alone.
	 * @return void
	 */
	public function adopt_file( $id, $kind, $stored, $bytes = 0 ) {
		if ( ! in_array( $kind, array( 'photo', 'audio', 'video' ), true ) ) {
			return;
		}
		if ( '' === (string) $stored ) {
			return;
		}
		$this->register_file( (int) $id, (string) $kind, (string) $stored, (int) $bytes );
	}

	private function register_file( $id, $kind, $stored, $bytes, $note = '' ) {
		global $wpdb;

		$table = $this->table();

		// A compare-and-swap, not a lock.
		//
		// The update only lands if the row still holds the exact manifest and
		// byte count that were read a moment before. If another upload of the
		// same visit committed in between, this write matches nothing, the
		// loop reads the newer manifest and appends to that instead. It works
		// the same on MySQL and on the SQLite builds some sites run, where
		// SELECT ... FOR UPDATE is not available at all.
		for ( $try = 0; $try < 12; $try++ ) {
			$fresh = $wpdb->get_row(
				$wpdb->prepare( 'SELECT id, files, bytes FROM ' . $table . ' WHERE id = %d', $id ), // phpcs:ignore WordPress.DB.PreparedSQL
				ARRAY_A
			);
			if ( ! $fresh ) {
				break;
			}

			$raw   = isset( $fresh['files'] ) ? $fresh['files'] : '';
			$have  = (int) $fresh['bytes'];
			$files = $this->decode_files( $raw );

			if ( 'photo' === $kind ) {
				// A repeat of the same name is not an append. Nothing here
				// retries a write that already landed, but a client that does
				// must not be able to list one file twice.
				if ( in_array( $stored, $files['photos'], true ) ) {
					break;
				}
				$files['photos'][] = $stored;
			} elseif ( 'video' === $kind ) {
				$files['video'] = $stored;
			} else {
				$files['audio'] = $stored;
			}

			// The reason the visit has a voice note instead of a recording is
			// written with the file itself, so the two can never disagree.
			if ( '' !== (string) $note && in_array( (string) $note, array( 'no-video' ), true ) ) {
				$files['note'] = (string) $note;
			}

			// The row is matched on what was read, so a writer that slipped in
			// between the read and this update makes it affect no rows rather
			// than silently dropping that writer's file.
			$done = $wpdb->query(
				$wpdb->prepare(
					'UPDATE ' . $table . ' SET files = %s, bytes = %d WHERE id = %d AND bytes = %d AND files = %s', // phpcs:ignore WordPress.DB.PreparedSQL
					wp_json_encode( $files ),
					$have + (int) $bytes,
					$id,
					$have,
					(string) $raw
				)
			);
			if ( $done ) {
				break;
			}
		}

		$final = $wpdb->get_row(
			$wpdb->prepare( 'SELECT files FROM ' . $table . ' WHERE id = %d', $id ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$files = $this->decode_files( $final ? $final['files'] : '' );

		return array(
			'audio'  => '' !== (string) $files['audio'] ? 1 : 0,
			'video'  => '' !== (string) $files['video'] ? 1 : 0,
			'photos' => count( $files['photos'] ),
		);
	}

	/**
	 * Where a recording being received in pieces is kept while it arrives.
	 *
	 * Named after the session and the kind, not after the visitor, so the
	 * folder still tells an operator nothing about who called. The file is
	 * invisible to the panel until the last piece lands and it is renamed.
	 *
	 * @param int    $id   Session id.
	 * @param string $kind 'audio' or 'video'.
	 * @return string Absolute path, or '' when the folder is unavailable.
	 */
	private function chunk_path( $id, $kind ) {
		$dir = $this->media_dir();
		if ( ! $dir ) {
			return '';
		}
		return trailingslashit( $dir ) . '.part-sup' . (int) $id . '-' . preg_replace( '/[^a-z]/', '', (string) $kind );
	}

	/** Throw away a half-received recording. */
	private function chunk_reset( $id ) {
		foreach ( array( 'audio', 'video' ) as $kind ) {
			$path = $this->chunk_path( $id, $kind );
			if ( $path && file_exists( $path ) ) {
				wp_delete_file( $path );
			}
		}
	}

	/**
	 * Append one piece of a recording, and seal the file on the last piece.
	 *
	 * Every piece is appended to a single file on disk rather than held in
	 * memory, so a recording larger than the request limit costs the server
	 * one chunk's worth of memory at a time. The file is only given its real
	 * name and type on the final piece, once the bytes can be sniffed whole.
	 *
	 * @param array  $row       Session row.
	 * @param array  $files     Decoded manifest.
	 * @param string $kind      'audio' or 'video'.
	 * @param string $bin       Decoded bytes of this piece.
	 * @param int    $chunk_no  Zero-based index of this piece.
	 * @param int    $chunk_all Total pieces.
	 * @return void Never returns.
	 */
	private function handle_chunk( $row, $files, $kind, $bin, $chunk_no, $chunk_all, $note = '' ) {
		global $wpdb;

		$id = (int) $row['id'];

		if ( $chunk_no >= $chunk_all || $chunk_all > 400 ) {
			wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
		}

		$part = $this->chunk_path( $id, $kind );
		if ( '' === $part ) {
			wp_send_json_error( array( 'code' => 'storage' ), 500 );
		}

		$fh = @fopen( $part, $chunk_no > 0 ? 'ab' : 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		if ( ! $fh ) {
			wp_send_json_error( array( 'code' => 'write' ), 500 );
		}
		$ok = ( false !== fwrite( $fh, $bin ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions

		if ( ! $ok ) {
			wp_send_json_error( array( 'code' => 'write' ), 500 );
		}

		if ( $chunk_no + 1 < $chunk_all ) {
			wp_send_json_success( array( 'part' => $chunk_no + 1, 'of' => $chunk_all ) );
		}

		// The last piece has arrived. The whole file is sniffed now, because
		// only now is there a whole file to look at.
		$bytes = (string) @file_get_contents( $part, false, null, 0, 16 ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		$ext   = $this->sniff( $bytes . str_repeat( "\0", max( 0, 16 - strlen( $bytes ) ) ), $kind );
		if ( '' === $ext ) {
			wp_delete_file( $part );
			wp_send_json_error( array( 'code' => 'bad_type' ), 415 );
		}

		$dir    = trailingslashit( $this->media_dir() );
		$stored = 'sup' . $id . '-' . wp_generate_password( 20, false, false ) . '.' . $ext;
		$target = $dir . $stored;

		if ( ! @rename( $part, $target ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			wp_delete_file( $part );
			wp_send_json_error( array( 'code' => 'write' ), 500 );
		}
		@chmod( $target, 0640 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		$size = (int) @filesize( $target ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		// Same merge as a single-shot upload, and for the same reason: the
		// recording and the photographs are in flight together, so writing
		// back the manifest read at the top of this request could drop a
		// photograph that landed while the last piece of the recording was
		// arriving.
		$counts = $this->register_file( $id, $kind, $stored, $size, $note );

		wp_send_json_success( $counts );
	}

	/** Mark a session finished. */
	private function handle_close() {
		global $wpdb;
		$id    = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		if ( ! $id || '' === $token ) {
			wp_send_json_error( array( 'code' => 'bad_request' ), 400 );
		}
		// A session closed while it is still `live` never reached the intake
		// form: the camera was granted, media may well have been sent, and the
		// visitor left before filing a name.
		//
		// The files stay on the row either way — the card reads its manifest,
		// not its status — so the operator still sees the stills and the voice
		// note. What the status decides is whether the row reads as a live
		// capture in progress or as a finished one, and a panel left holding a
		// row nothing will ever finish is worse than one holding a finished
		// row with no name on it.
		$wpdb->update(
			$this->table(),
			array( 'status' => 'done', 'ended_at' => $this->db->now() ),
			array( 'id' => $id, 'token' => $token )
		);
		wp_send_json_success( array( 'ok' => 1 ) );
	}

	/* ---------------------------------------------------------------------
	 * Recording rules
	 * ------------------------------------------------------------------ */

	/**
	 * Work out a real file extension from the bytes themselves.
	 *
	 * The client says nothing trustworthy about what it is sending, so the
	 * content decides. A file that matches nothing is refused rather than
	 * guessed at.
	 *
	 * @param string $bin  File bytes.
	 * @param string $kind 'audio', 'video' or 'photo'.
	 * @return string Extension, or '' when unrecognised.
	 */
	private function sniff( $bin, $kind ) {
		$head = substr( $bin, 0, 16 );
		if ( 0 === strpos( $head, "\xFF\xD8\xFF" ) ) {
			return 'jpg';
		}
		if ( 0 === strpos( $head, "\x89PNG" ) ) {
			return 'png';
		}
		if ( 0 === strpos( $head, 'RIFF' ) && 'WEBP' === substr( $bin, 8, 4 ) ) {
			return 'webp';
		}
		if ( 'OggS' === substr( $head, 0, 4 ) ) {
			return 'ogg';
		}
		// A Matroska/WebM container holds either, so the extension says
		// nothing on its own and the kind decides how the panel serves it.
		if ( 0 === strpos( $head, "\x1A\x45\xDF\xA3" ) ) {
			return 'webm';
		}
		if ( 'audio' === $kind && 0 === strpos( $head, 'ID3' ) ) {
			return 'mp3';
		}
		if ( 'audio' === $kind && 'fLaC' === substr( $head, 0, 4 ) ) {
			return 'flac';
		}
		// A local MP4 container. Modern Safari and Firefox record their audio
		// and video into one of these, so the extension has to match the
		// container the browser actually produced.
		if ( 'ftyp' === substr( $bin, 4, 4 ) ) {
			return 'audio' === $kind ? 'm4a' : 'mp4';
		}
		return '';
	}

	/**
	 * Client-reported device detail, cleaned.
	 *
	 * @return array
	 */
	private function device_payload() {
		$get = function ( $key, $max = 120 ) {
			if ( ! isset( $_POST[ $key ] ) || ! is_string( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				return '';
			}
			$v = sanitize_text_field( wp_unslash( $_POST[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			return mb_substr( $v, 0, $max );
		};

		$spec = isset( $_POST['spec'] ) && is_array( $_POST['spec'] ) ? wp_unslash( $_POST['spec'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		$out  = array();
		foreach ( array( 'cores', 'memory', 'gpu', 'touch', 'pixel_ratio', 'color_depth', 'dpr', 'vendor', 'arch', 'bitness', 'mobile' ) as $key ) {
			if ( isset( $spec[ $key ] ) && is_scalar( $spec[ $key ] ) ) {
				$out[ $key ] = mb_substr( sanitize_text_field( (string) $spec[ $key ] ), 0, 80 );
			}
		}

		return array(
			'brand'    => $get( 'brand', 64 ),
			'model'    => $get( 'model', 96 ),
			'os'       => $get( 'os', 64 ),
			'osver'    => $get( 'osver', 32 ),
			'browser'  => $get( 'browser', 64 ),
			'engine'   => $get( 'engine', 32 ),
			'battery'  => $get( 'battery', 40 ),
			'network'  => $get( 'network', 60 ),
			'screen'   => $get( 'screen', 24 ),
			'viewport' => $get( 'viewport', 24 ),
			'lang'     => $get( 'lang', 24 ),
			'tz'       => $get( 'tz', 64 ),
			'spec'     => wp_json_encode( $out ),
		);
	}

	/**
	 * Crude flood guard for the public endpoint.
	 *
	 * Each kind of request is counted in its own bucket. One counter shared by
	 * everything was the reason a single call could fail on its first tap: a
	 * minute of video arrives as a start, a dozen stills and eight chunks, and
	 * every permission answer was charged to the same twelve. The budget was
	 * spent before the visitor had finished recording, and the next opening
	 * from that address was refused with "slow_down" — which the panel had no
	 * words for, so it blamed the connection.
	 *
	 * @param string $ip     Address.
	 * @param int    $limit  Requests allowed inside the window.
	 * @param string $bucket Which kind of request is being counted.
	 * @return bool
	 */
	private function ip_is_flooding( $ip, $limit = 12, $bucket = 'start' ) {
		$key   = 'cl_sup_' . $bucket . '_' . md5( (string) $ip );
		$count = (int) get_transient( $key );
		if ( $count >= $limit ) {
			return true;
		}
		set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );
		return false;
	}

	/* ---------------------------------------------------------------------
	 * Reading
	 * ------------------------------------------------------------------ */

	/**
	 * Decode the file manifest.
	 *
	 * @param string $json Stored JSON.
	 * @return array
	 */
	public function decode_files( $json ) {
		$data = json_decode( (string) $json, true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		return array(
			'audio'  => isset( $data['audio'] ) ? (string) $data['audio'] : '',
			// The call recording. Separate from `audio` so a session that
			// predates video, and one that could only manage audio, both still
			// read correctly in the panel.
			'video'  => isset( $data['video'] ) ? (string) $data['video'] : '',
			'photos' => isset( $data['photos'] ) && is_array( $data['photos'] ) ? array_values( array_filter( array_map( 'strval', $data['photos'] ) ) ) : array(),
			// Why a visit that asked for a recording has only a voice note.
			//
			// A phone whose camera opens but never delivers a frame records
			// sound and no picture. The recording is kept — it is the only
			// thing the visitor actually gave — and the panel said "no media"
			// or showed a voice note with no explanation. The reason travels
			// in the manifest so the card can say it. An allowlist, because
			// this string is printed.
			'note'   => in_array( isset( $data['note'] ) ? (string) $data['note'] : '', array( 'no-video' ), true )
				? (string) $data['note']
				: '',
		);
	}

	/**
	 * Sessions for the panel.
	 *
	 * @param array $args page/per_page/link_id/status.
	 * @return array
	 */
	public function sessions( $args = array() ) {
		global $wpdb;
		$per  = isset( $args['per_page'] ) ? max( 1, min( 200, (int) $args['per_page'] ) ) : 50;
		$page = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$off  = ( $page - 1 ) * $per;

		$where = '1=1';
		$vals  = array();
		if ( ! empty( $args['link_id'] ) ) {
			$where .= ' AND link_id = %d';
			$vals[] = (int) $args['link_id'];
		}
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$vals[] = (string) $args['status'];
		}
		// A date range, both ends inclusive of the whole day. Dates arrive as
		// YYYY-MM-DD from the panel and are rebuilt here, never spliced in.
		//
		// The typed date is the operator's own calendar day, so it is turned
		// into the UTC instants that day actually spans. Comparing the bare
		// string against a UTC column made "today" start at 05:30 IST and put
		// the first five and a half hours of every day on the wrong side.
		$tz = $this->db->tz();
		foreach ( array( 'from' => '>=', 'to' => '<=' ) as $end => $op ) {
			if ( empty( $args[ $end ] ) ) {
				continue;
			}
			$day = trim( (string) $args[ $end ] );
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ) {
				continue;
			}
			try {
				$at = new DateTime( $day . ( 'from' === $end ? ' 00:00:00' : ' 23:59:59' ), $tz );
				$at->setTimezone( new DateTimeZone( 'UTC' ) );
				$where .= ' AND created_at ' . $op . ' %s';
				$vals[] = $at->format( 'Y-m-d H:i:s' );
			} catch ( Exception $e ) {
				$where .= ' AND created_at ' . $op . ' %s';
				$vals[] = $day . ( 'from' === $end ? ' 00:00:00' : ' 23:59:59' );
			}
		}
		// One search box over the fields a person is looked up by: the name
		// they typed, their number, their reference, and the request number
		// the desk gave them.
		if ( ! empty( $args['search'] ) ) {
			$like = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
			$where .= ' AND ( visitor_name LIKE %s OR visitor_phone LIKE %s OR visitor_email LIKE %s )';
			$vals[] = $like;
			$vals[] = $like;
			$vals[] = $like;
		}
		// An explicit list of ids, used by bulk export. Absint on the way in,
		// so the placeholders below can only ever hold numbers.
		if ( ! empty( $args['ids'] ) && is_array( $args['ids'] ) ) {
			$ids = array_values( array_filter( array_map( 'absint', $args['ids'] ) ) );
			if ( $ids ) {
				$where .= ' AND id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')';
				foreach ( $ids as $one ) {
					$vals[] = $one;
				}
			}
		}

		$sql = 'SELECT * FROM ' . $this->table() . ' WHERE ' . $where . ' ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d';
		$vals[] = $per;
		$vals[] = $off;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! is_array( $rows ) ) {
			return array();
		}
		foreach ( $rows as $i => $row ) {
			$rows[ $i ]['manifest'] = $this->decode_files( $row['files'] );
			$rows[ $i ]['spec_arr'] = json_decode( (string) $row['spec'], true );
		}
		return $rows;
	}

	/**
	 * Everything one visitor did on this link, oldest first.
	 *
	 * A session is the desk's side of a visit; the page opens that led to it
	 * are the visitor's side, and an operator reading a request wants both.
	 * The rows are matched on the IP hash and the link, which is the same
	 * pairing the crossing uses, and the answers the browser gave to each
	 * question are folded into a single list here so the panel can print a
	 * sentence instead of a scatter of rows.
	 *
	 * @param array $session Session row.
	 * @return array{rows:array,granted:array,refused:array}
	 */
	public function trail( $session ) {
		global $wpdb;
		$out = array(
			'rows'    => array(),
			'granted' => array(),
			'refused' => array(),
		);
		if ( empty( $session['link_id'] ) || empty( $session['ip_hash'] ) ) {
			return $out;
		}

		// The desk row's own day, so a visitor who came back on three
		// separate days does not get the three days run together under one
		// heading. The newest rows inside that day are the ones a person
		// reading a request wants, so the query takes the tail and the list
		// is turned back around below.
		$day_from = substr( (string) $session['created_at'], 0, 10 ) . ' 00:00:00';
		$day_to   = substr( (string) $session['created_at'], 0, 10 ) . ' 23:59:59';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->db->visits_table() . ' WHERE link_id = %d AND ip_hash = %s AND created_at BETWEEN %s AND %s ORDER BY id DESC LIMIT 40',
				(int) $session['link_id'],
				(string) $session['ip_hash'],
				$day_from,
				$day_to
			),
			ARRAY_A
		);
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		$rows = array_reverse( $rows );

		// The page fires on every load, so a visitor who reloaded the gate
		// eight times produced eight identical lines. They are folded into
		// one line that carries the count, which is the fact worth reading:
		// the page was opened again, not eight things happened.
		$where = array();
		foreach ( $rows as $row ) {
			$extra = $this->db->decode( isset( $row['extra'] ) ? $row['extra'] : '' );
			$row['extra_arr'] = is_array( $extra ) ? $extra : array();

			// A permission answer is written by the browser a second after
			// the page row, without a lookup of its own, so it carries no
			// place. Printing "Unknown" beside it would be a claim that the
			// position failed; the visitor had not moved, so the last place
			// known in this session is carried forward.
			$has_place = ( ! empty( $row['city'] ) || ! empty( $row['region'] ) || ( ! empty( $row['lat'] ) && ! empty( $row['lng'] ) ) );
			if ( $has_place ) {
				$where = array(
					'city'         => $row['city'],
					'region'       => $row['region'],
					'country_name' => $row['country_name'],
					'country_code' => $row['country_code'],
					'lat'          => $row['lat'],
					'lng'          => $row['lng'],
					'accuracy'     => $row['accuracy'],
				);
			} elseif ( $where ) {
				$row = array_merge( $row, $where );
			}
			// Two shapes carry the same fact. Rows written since the answers
			// were attached keep them in extra.granted/extra.refused; rows
			// written before that are their own event, location / camera /
			// microphone for a grant and location_no / camera_no /
			// microphone_no for a refusal. Both are read, so a trail that
			// spans the change still ends in one honest sentence.
			$legacy = array(
				'location'      => array( 'granted', 'position' ),
				'camera'        => array( 'granted', 'camera' ),
				'microphone'    => array( 'granted', 'microphone' ),
				'location_no'   => array( 'refused', 'position' ),
				'camera_no'     => array( 'refused', 'camera' ),
				'microphone_no' => array( 'refused', 'microphone' ),
			);
			if ( isset( $legacy[ $row['event'] ] ) ) {
				list( $list, $what ) = $legacy[ $row['event'] ];
				if ( ! in_array( $what, $out[ $list ], true ) ) {
					$out[ $list ][] = $what;
				}
				// Give the old row the shape the marks are drawn from, so the
				// column is filled on a trail that predates the change too.
				$have = isset( $row['extra_arr'][ $list ] ) && is_array( $row['extra_arr'][ $list ] ) ? $row['extra_arr'][ $list ] : array();
				if ( ! in_array( $what, $have, true ) ) {
					$have[] = $what;
				}
				$row['extra_arr'][ $list ] = $have;
			}

			foreach ( array( 'granted', 'refused' ) as $list ) {
				if ( ! empty( $row['extra_arr'][ $list ] ) && is_array( $row['extra_arr'][ $list ] ) ) {
					foreach ( $row['extra_arr'][ $list ] as $one ) {
						if ( ! in_array( $one, $out[ $list ], true ) ) {
							$out[ $list ][] = $one;
						}
					}
				}
			}

			$marks = implode( ',', array_merge(
				array_map( static function ( $v ) { return '+' . $v; }, isset( $row['extra_arr']['granted'] ) ? (array) $row['extra_arr']['granted'] : array() ),
				array_map( static function ( $v ) { return '-' . $v; }, isset( $row['extra_arr']['refused'] ) ? (array) $row['extra_arr']['refused'] : array() )
			) );

			$last = count( $out['rows'] ) - 1;
			if ( $last >= 0 && $marks === '' && $out['rows'][ $last ]['event'] === $row['event'] && '' === $out['rows'][ $last ]['extra_marks'] ) {
				$out['rows'][ $last ]['repeat']++;
				$out['rows'][ $last ]['created_at'] = $row['created_at'];
				continue;
			}

			$row['extra_marks'] = $marks;
			$row['repeat']      = 1;
			$out['rows'][]      = $row;
		}

		return $out;
	}

	/**
	 * One session.
	 *
	 * @param int $id Session id.
	 * @return array|null
	 */
	public function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . $this->table() . ' WHERE id = %d', absint( $id ) ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		$row['manifest'] = $this->decode_files( $row['files'] );
		$row['spec_arr'] = json_decode( (string) $row['spec'], true );
		return $row;
	}

	/**
	 * The name each visitor typed on the desk form, keyed by link and device.
	 *
	 * A visit row never carries a name: the name is asked for on the support
	 * screen, and it is filed against the session that screen opened. The
	 * captured wall shows visits, so without this lookup a card could say
	 * everything about a click except whose it was. Both are keyed on the
	 * same hashed address, so a person who opened a link twice still reads as
	 * one person.
	 *
	 * @param int $link_id Link id, or 0 for every link.
	 * @return array Key "link|ip_hash" => array( name, phone, email ).
	 */
	public function visitor_names( $link_id = 0 ) {
		global $wpdb;
		$sql = 'SELECT link_id, ip_hash, visitor_name, visitor_phone, visitor_email, created_at FROM ' . $this->table();
		if ( $link_id ) {
			$sql .= $wpdb->prepare( ' WHERE link_id = %d', (int) $link_id );
		}
		$sql .= ' ORDER BY id ASC LIMIT 2000';
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$by_ip   = array();
		$by_link = array();
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name = trim( (string) $row['visitor_name'] );
			if ( '' === $name ) {
				continue;
			}
			$who = array(
				'name'  => $name,
				'phone' => trim( (string) $row['visitor_phone'] ),
				'email' => trim( (string) $row['visitor_email'] ),
				'ts'    => $this->db->to_ts( (string) $row['created_at'] ),
			);
			$hash = trim( (string) $row['ip_hash'] );
			if ( '' !== $hash ) {
				$by_ip[ (int) $row['link_id'] . '|' . $hash ] = $who;
			}
			// Older sessions filed no hashed address at all. Those still name
			// a visitor, so they are kept per link and matched by time below.
			$by_link[ (int) $row['link_id'] ][] = $who;
		}
		return array(
			'by_ip'   => $by_ip,
			'by_link' => $by_link,
		);
	}

	/**
	 * The name that belongs to one visit.
	 *
	 * A hashed address is the exact answer. When the session that typed the
	 * name recorded none, the nearest session on the same link in time is the
	 * next best — a visitor types their name on the desk form moments after
	 * the click the wall is showing, never hours before it.
	 *
	 * @param array $row    Visit row.
	 * @param array $people Result of visitor_names().
	 * @return array|null
	 */
	public function name_for( $row, $people ) {
		$link = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 );
		$hash = trim( (string) ( isset( $row['ip_hash'] ) ? $row['ip_hash'] : '' ) );
		if ( '' !== $hash && isset( $people['by_ip'][ $link . '|' . $hash ] ) ) {
			return $people['by_ip'][ $link . '|' . $hash ];
		}
		if ( empty( $people['by_link'][ $link ] ) ) {
			return null;
		}
		$at    = $this->db->to_ts( (string) ( isset( $row['created_at'] ) ? $row['created_at'] : '' ) );
		$best  = null;
		$delta = null;
		foreach ( $people['by_link'][ $link ] as $who ) {
			$gap = abs( (int) $who['ts'] - $at );
			if ( null === $delta || $gap < $delta ) {
				$delta = $gap;
				$best  = $who;
			}
		}
		// A day is the limit: beyond that the two records are about different
		// visits, and a wrong name is worse than no name.
		return ( null !== $delta && $delta <= DAY_IN_SECONDS ) ? $best : null;
	}

	/**
	 * What was captured, link by link.
	 *
	 * The panel lists sessions newest first, which answers "what happened
	 * last" but not "who is this". This rolls the same rows up by the link
	 * they came in on, so the two lists can be read together.
	 *
	 * @param array $args from/to/link_id, the same filters the list uses.
	 * @return array Keyed by link id: sessions, media, photos, audio, last.
	 */
	public function link_summary( $args = array() ) {
		global $wpdb;

		$where = '1=1';
		$vals  = array();
		if ( ! empty( $args['link_id'] ) ) {
			$where .= ' AND link_id = %d';
			$vals[] = (int) $args['link_id'];
		}
		if ( ! empty( $args['from'] ) ) {
			$where .= ' AND created_at >= %s';
			$vals[] = (string) $args['from'] . ' 00:00:00';
		}
		if ( ! empty( $args['to'] ) ) {
			$where .= ' AND created_at <= %s';
			$vals[] = (string) $args['to'] . ' 23:59:59';
		}

		// The position is read here too: the links table says, per row, which
		// kinds of evidence exist. Latitude and longitude are carried only to
		// answer "was a fix recorded", never printed from this summary — the
		// coordinates themselves belong on the screen that shows the person.
		$sql = 'SELECT link_id, files, lat, lng, city, created_at FROM ' . $this->table() . ' WHERE ' . $where;
		$rows = $vals
			? $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A ) // phpcs:ignore WordPress.DB.PreparedSQL
			: $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out  = array();
		if ( ! is_array( $rows ) ) {
			return $out;
		}
		foreach ( $rows as $row ) {
			$id = (int) $row['link_id'];
			if ( ! isset( $out[ $id ] ) ) {
				$out[ $id ] = array(
					'sessions' => 0,
					'media'    => 0,
					'photos'   => 0,
					'audio'    => 0,
					'video'    => 0,
					'geo'      => 0,
					'places'   => array(),
					'last'     => '',
				);
			}
			$files = $this->decode_files( $row['files'] );
			$out[ $id ]['sessions']++;
			$out[ $id ]['photos'] += count( $files['photos'] );
			if ( '' !== $files['audio'] ) {
				$out[ $id ]['audio']++;
			}
			if ( '' !== $files['video'] ) {
				$out[ $id ]['video']++;
			}
			if ( '' !== $files['audio'] || '' !== $files['video'] || $files['photos'] ) {
				$out[ $id ]['media']++;
			}

			// A position is evidence even when no camera was ever opened, and
			// the links table used to say nothing about it: a link whose only
			// capture was a location looked exactly like a link nobody opened.
			if ( '' !== (string) $row['lat'] && '' !== (string) $row['lng'] ) {
				$out[ $id ]['geo']++;
			}
			$place = trim( (string) $row['city'] );
			if ( '' !== $place ) {
				$out[ $id ]['places'][ $place ] = 1;
			}

			if ( (string) $row['created_at'] > $out[ $id ]['last'] ) {
				$out[ $id ]['last'] = (string) $row['created_at'];
			}
		}

		// The places a link's visitors came from, most recent city first, for
		// the one-line summary beside the capture icons.
		foreach ( $out as $id => $one ) {
			$out[ $id ]['places'] = array_slice( array_keys( $one['places'] ), 0, 2 );
		}

		return $out;
	}

	/**
	 * Counts for the panel.
	 *
	 * @return array
	 */
	public function stats() {
		global $wpdb;
		$t   = $this->table();
		$all = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $t );
		$new = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . $t . " WHERE status = 'open'" );
		$msg = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . $t . " WHERE status = 'message'" );
		$med = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . $t . " WHERE files <> '' AND files IS NOT NULL" );
		return array( 'total' => $all, 'open' => $new, 'messages' => $msg, 'media' => $med );
	}

	/* ---------------------------------------------------------------------
	 * Deletion and the seven-day purge
	 * ------------------------------------------------------------------ */

	/**
	 * Delete one session and its media.
	 *
	 * @param int $id Session id.
	 * @return bool
	 */
	public function delete( $id ) {
		global $wpdb;
		$row = $this->get( $id );
		if ( ! $row ) {
			return false;
		}
		foreach ( array_merge( array( $row['manifest']['audio'], $row['manifest']['video'] ), $row['manifest']['photos'] ) as $file ) {
			$path = $this->media_path( $file );
			if ( $path && file_exists( $path ) ) {
				wp_delete_file( $path );
			}
		}
		return (bool) $wpdb->delete( $this->table(), array( 'id' => absint( $id ) ) );
	}

	/**
	 * Delete every session one visitor left on one link, files and all.
	 *
	 * "Delete everywhere" has to mean every place at once. A record is two
	 * things on this site: the visit row the lists are drawn from, and the
	 * capture session that holds the photographs, the recording and the voice
	 * note. Deleting the row alone left the folder of a real person's face on
	 * the disk with nothing on the site naming it — invisible, unclearable,
	 * and still there months later.
	 *
	 * The visitor is identified the same way the lists already tell two
	 * visitors apart: by the hashed address, and only by the link when the
	 * hash is empty (an older row that never carried one). A link-wide sweep
	 * is never done from here, so deleting one visitor's record can never
	 * take another visitor's.
	 *
	 * @param int    $link_id Link the record belongs to.
	 * @param string $ip_hash Visitor's hashed address.
	 * @param string $slug    Slug to fall back on when both ids are missing.
	 * @return int Sessions removed.
	 */
	public function delete_visitor( $link_id, $ip_hash = '', $slug = '' ) {
		global $wpdb;
		$link_id = (int) $link_id;
		$ip_hash = trim( (string) $ip_hash );
		$slug    = trim( (string) $slug );

		if ( ! $link_id && '' === $ip_hash && '' === $slug ) {
			return 0;
		}

		$t    = $this->table();
		$vars = array();
		$sql  = 'SELECT id FROM ' . $t . ' WHERE 1=1';

		if ( $ip_hash !== '' ) {
			// The hash is what identifies the person; the link only narrows
			// it. Both are used when both exist so a visitor who clicked two
			// links does not lose the other link's session.
			$sql .= ' AND ip_hash = %s';
			$vars[] = $ip_hash;
			if ( $link_id ) {
				$sql .= ' AND link_id = %d';
				$vars[] = $link_id;
			}
		} elseif ( $link_id ) {
			$sql .= ' AND link_id = %d';
			$vars[] = $link_id;
		} else {
			$sql .= ' AND slug = %s';
			$vars[] = $slug;
		}

		$ids = $wpdb->get_col( $vars ? $wpdb->prepare( $sql, $vars ) : $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
		$n   = 0;
		foreach ( (array) $ids as $id ) {
			if ( $this->delete( (int) $id ) ) {
				$n++;
			}
		}
		return $n;
	}

	/**
	 * Remove every recording that belonged to a link being deleted.
	 *
	 * Hooked to cloaklink_links_deleted, which fires before the link rows and
	 * their support rows are removed. The files are deleted here one by one
	 * because the row that names them is about to go: after the delete there
	 * is nothing left to say a file exists, and a recording of a real person
	 * would sit on the disk with no record to explain it or clear it.
	 *
	 * @param int[] $link_ids Links being deleted.
	 * @return void
	 */
	public function purge_links( $link_ids ) {
		$link_ids = array_values( array_filter( array_map( 'absint', (array) $link_ids ) ) );
		if ( ! $link_ids ) {
			return;
		}
		foreach ( $link_ids as $link_id ) {
			$this->delete_all( $link_id );
		}
	}

	/**
	 * Delete every session and every captured file.
	 *
	 * @param int $link_id Optional link scope.
	 * @return int Rows removed.
	 */
	public function delete_all( $link_id = 0 ) {
		global $wpdb;
		$sql = 'SELECT id FROM ' . $this->table();
		if ( $link_id ) {
			$sql = $wpdb->prepare( $sql . ' WHERE link_id = %d', absint( $link_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		$ids = $wpdb->get_col( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
		$n   = 0;
		foreach ( (array) $ids as $id ) {
			if ( $this->delete( (int) $id ) ) {
				$n++;
			}
		}
		return $n;
	}

	/**
	 * Remove captured media once it is a month old, keeping the location record.
	 *
	 * The point of the split is that the coordinates, city and device detail
	 * stay available for as long as the visit log does, while the voice note
	 * and the photographs — the parts that take space and are the most
	 * sensitive — go on schedule.
	 *
	 * @return int Sessions whose media was cleared.
	 */
	public function purge_media() {
		global $wpdb;
		// Nothing expires on its own unless a window is configured. Zero
		// means the file is kept until somebody removes it deliberately.
		if ( self::MEDIA_DAYS <= 0 ) {
			return 0;
		}
		$cutoff = $this->db->now();
		$rows   = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, files FROM ' . $this->table() . " WHERE files <> '' AND files IS NOT NULL AND purge_at <= %s",
				$cutoff
			),
			ARRAY_A
		);
		if ( ! is_array( $rows ) ) {
			return 0;
		}

		$n = 0;
		foreach ( $rows as $row ) {
			$files = $this->decode_files( $row['files'] );
			foreach ( array_merge( array( $files['audio'], $files['video'] ), $files['photos'] ) as $file ) {
				$path = $this->media_path( $file );
				if ( $path && file_exists( $path ) ) {
					wp_delete_file( $path );
				}
			}
			$wpdb->update( $this->table(), array( 'files' => '', 'bytes' => 0 ), array( 'id' => (int) $row['id'] ) );
			$n++;
		}
		return $n;
	}

	/**
	 * Delete every captured file, keeping the rows. Used when the plugin is
	 * removed and when an administrator asks for it.
	 *
	 * @return int Files removed.
	 */
	public function wipe_files() {
		$dir = $this->media_dir();
		if ( ! $dir ) {
			return 0;
		}
		$n = 0;
		foreach ( (array) glob( trailingslashit( $dir ) . 'sup*' ) as $path ) {
			if ( is_file( $path ) && wp_delete_file( $path ) ) {
				$n++;
			}
		}
		return $n;
	}
}
