<?php
/**
 * The ticket ledger.
 *
 * A ticket is a working row. It is raised, allowed, held, and removed — and
 * the last of those deletes the row itself. So the questions an operator asks
 * after a week of work cannot be answered from the ticket table at all:
 *
 *   How many did we take this week?  Who removed that one?  When?  From
 *   which phone, on which network?  What did it say before it went?
 *
 * This table answers them. One row per thing that happened to a ticket, and
 * the first row of each ticket is a copy of what it said when it was raised —
 * the name, the number, the line of text, and who took it down. A removal
 * therefore leaves everything behind except the ticket itself, which is
 * exactly what a record should do.
 *
 * It is append-only by design. Nothing in this class updates or deletes a
 * row, because a record that can be edited is not a record. There is no
 * button anywhere that clears it; the rows go when the site's data does.
 *
 * Nothing here is a secret that was not already in another table: it is the
 * same four fields the ticket held, the same request metadata the activity
 * log keeps. What it adds is that they survive the ticket.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Writes and reads the ticket ledger.
 */
class CloakLink_Ticket_Log {

	/**
	 * The table.
	 *
	 * @return string
	 */
	public function table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_ticket_log';
	}

	/**
	 * What each event is called, and how it reads at a glance.
	 *
	 * One list rather than a switch in the view, so the ledger, the agent's
	 * own history and an export all say the same word for the same thing.
	 *
	 * @return array event => array( label, tone )
	 */
	public static function events() {
		return array(
			'raised'  => array( __( 'Raised', 'cloaklink' ), 'info' ),
			'allowed' => array( __( 'Allowed', 'cloaklink' ), 'ok' ),
			'held'    => array( __( 'Held back', 'cloaklink' ), 'warn' ),
			'removed' => array( __( 'Removed', 'cloaklink' ), 'bad' ),
		);
	}

	/**
	 * The words for one event.
	 *
	 * @param string $event Event key.
	 * @return array [label, tone]
	 */
	public static function label( $event ) {
		$all = self::events();
		return isset( $all[ $event ] ) ? $all[ $event ] : array( (string) $event, 'muted' );
	}

	/**
	 * Write one row.
	 *
	 * The request metadata is read here rather than passed in, because every
	 * caller is a request from the browser of the person who did the thing,
	 * and none of them knows a better answer than the request itself.
	 *
	 * A ledger write must never stop the action it records. A failed insert is
	 * swallowed: a ticket removal that went through must report that it went
	 * through, even on the day the table is missing after a half-finished
	 * upgrade.
	 *
	 * @param array $ticket Ticket row as it stood, or as much of it as is known.
	 * @param array $args   event, actor_kind, actor_id, actor_name.
	 * @return int Row id, or 0.
	 */
	public function write( $ticket, $args = array() ) {
		global $wpdb;

		$event = isset( $args['event'] ) ? sanitize_key( (string) $args['event'] ) : '';
		if ( '' === $event ) {
			return 0;
		}
		$ticket = is_array( $ticket ) ? $ticket : array();

		$ua     = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 500 ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$parsed = CloakLink_UA::parse( $ua );
		$ip     = CloakLink_Geo::ip();
		$geo    = CloakLink_Geo::lookup( $ip );
		$geo    = is_array( $geo ) ? $geo : array();

		$ok = $wpdb->insert(
			$this->table(),
			array(
				'ticket_id'    => isset( $ticket['id'] ) ? absint( $ticket['id'] ) : 0,
				'ref'          => isset( $ticket['ref'] ) ? substr( (string) $ticket['ref'], 0, 16 ) : '',
				'actor_kind'   => isset( $args['actor_kind'] ) ? substr( (string) $args['actor_kind'], 0, 10 ) : '',
				'actor_id'     => isset( $args['actor_id'] ) ? absint( $args['actor_id'] ) : 0,
				'actor_name'   => isset( $args['actor_name'] ) ? mb_substr( sanitize_text_field( (string) $args['actor_name'] ), 0, 120 ) : '',
				'event'        => substr( $event, 0, 24 ),
				'person'       => isset( $ticket['person'] ) ? mb_substr( (string) $ticket['person'], 0, 120 ) : '',
				'phone'        => isset( $ticket['phone'] ) ? substr( (string) $ticket['phone'], 0, 32 ) : '',
				'note'         => isset( $ticket['note'] ) ? mb_substr( (string) $ticket['note'], 0, 255 ) : '',
				'agent_id'     => isset( $ticket['agent_id'] ) ? absint( $ticket['agent_id'] ) : 0,
				'link_id'      => isset( $ticket['link_id'] ) ? absint( $ticket['link_id'] ) : 0,
				'ip'           => substr( (string) $ip, 0, 64 ),
				'city'         => isset( $geo['city'] ) ? mb_substr( (string) $geo['city'], 0, 120 ) : '',
				'country_code' => isset( $geo['country_code'] ) ? substr( (string) $geo['country_code'], 0, 2 ) : '',
				'device'       => substr( (string) $parsed['device'], 0, 24 ),
				'browser'      => substr( (string) $parsed['browser'], 0, 64 ),
				'os'           => substr( (string) $parsed['os'], 0, 64 ),
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Record that a ticket exists, carrying what it said.
	 *
	 * @param array  $ticket Ticket row.
	 * @param string $kind   'agent' or 'user'.
	 * @param int    $id     Person.
	 * @param string $name   Their name.
	 * @return int
	 */
	public function raised( $ticket, $kind = 'agent', $id = 0, $name = '' ) {
		return $this->write(
			$ticket,
			array(
				'event'      => 'raised',
				'actor_kind' => $kind,
				'actor_id'   => $id,
				'actor_name' => $name,
			)
		);
	}

	/**
	 * One ticket's whole story, oldest first.
	 *
	 * @param int $ticket_id Ticket.
	 * @return array
	 */
	public function story( $ticket_id ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . $this->table() . ' WHERE ticket_id = %d ORDER BY id ASC', // phpcs:ignore WordPress.DB.PreparedSQL
				absint( $ticket_id )
			),
			ARRAY_A
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * The ledger, newest first, filtered.
	 *
	 * @param array $args event, ticket, from, to, max, page.
	 * @return array
	 */
	public function rows( $args = array() ) {
		global $wpdb;
		$table = $this->table();
		$where = array( '1=1' );
		$vals  = array();

		if ( ! empty( $args['event'] ) ) {
			$where[] = 'event = %s';
			$vals[]  = sanitize_key( (string) $args['event'] );
		}
		if ( ! empty( $args['ticket'] ) ) {
			$where[] = 'ticket_id = %d';
			$vals[]  = absint( $args['ticket'] );
		}
		if ( ! empty( $args['person'] ) ) {
			$where[] = '(actor_id = %d OR agent_id = %d)';
			$vals[]  = absint( $args['person'] );
			$vals[]  = absint( $args['person'] );
		}
		if ( ! empty( $args['from'] ) ) {
			$where[] = 'created_at >= %s';
			$vals[]  = (string) $args['from'] . ' 00:00:00';
		}
		if ( ! empty( $args['to'] ) ) {
			$where[] = 'created_at <= %s';
			$vals[]  = (string) $args['to'] . ' 23:59:59';
		}

		$max   = isset( $args['max'] ) ? max( 1, min( 500, absint( $args['max'] ) ) ) : 100;
		$page  = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$sql   = 'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where )
			. ' ORDER BY id DESC LIMIT %d OFFSET %d';
		$vals[] = $max;
		$vals[] = ( $page - 1 ) * $max;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * How many rows the same filters would return.
	 *
	 * @param array $args Same filters as rows().
	 * @return int
	 */
	public function count( $args = array() ) {
		global $wpdb;
		$where = array( '1=1' );
		$vals  = array();

		if ( ! empty( $args['event'] ) ) {
			$where[] = 'event = %s';
			$vals[]  = sanitize_key( (string) $args['event'] );
		}
		if ( ! empty( $args['person'] ) ) {
			$where[] = '(actor_id = %d OR agent_id = %d)';
			$vals[]  = absint( $args['person'] );
			$vals[]  = absint( $args['person'] );
		}
		if ( ! empty( $args['from'] ) ) {
			$where[] = 'created_at >= %s';
			$vals[]  = (string) $args['from'] . ' 00:00:00';
		}
		if ( ! empty( $args['to'] ) ) {
			$where[] = 'created_at <= %s';
			$vals[]  = (string) $args['to'] . ' 23:59:59';
		}

		$sql = 'SELECT COUNT(*) FROM ' . $this->table() . ' WHERE ' . implode( ' AND ', $where );
		if ( $vals ) {
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $vals ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * The counts behind the ledger's own header.
	 *
	 * @param array $args from, to.
	 * @return array raised|allowed|held|removed|total
	 */
	public function tallies( $args = array() ) {
		global $wpdb;
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['from'] ) ) {
			$where[] = 'created_at >= %s';
			$vals[]  = (string) $args['from'] . ' 00:00:00';
		}
		if ( ! empty( $args['to'] ) ) {
			$where[] = 'created_at <= %s';
			$vals[]  = (string) $args['to'] . ' 23:59:59';
		}
		$sql = 'SELECT event, COUNT(*) AS n FROM ' . $this->table() . ' WHERE ' . implode( ' AND ', $where ) . ' GROUP BY event';
		$rows = $vals
			? $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A ) // phpcs:ignore WordPress.DB.PreparedSQL
			: $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL

		$out = array(
			'raised'  => 0,
			'allowed' => 0,
			'held'    => 0,
			'removed' => 0,
			'total'   => 0,
		);
		foreach ( (array) $rows as $row ) {
			$k = (string) $row['event'];
			$n = (int) $row['n'];
			if ( isset( $out[ $k ] ) ) {
				$out[ $k ] = $n;
			}
			$out['total'] += $n;
		}
		return $out;
	}

	/**
	 * Who removed what, newest first.
	 *
	 * The one question this table exists for. It names the person who pressed
	 * it, the ticket as it was written, and when.
	 *
	 * @param int $max How many.
	 * @return array
	 */
	public function removals( $max = 50 ) {
		return $this->rows(
			array(
				'event' => 'removed',
				'max'   => $max,
			)
		);
	}

	/**
	 * One ledger row, described for the screen.
	 *
	 * @param array $row Ledger row.
	 * @return array
	 */
	public function shape( $row ) {
		$who = trim( (string) $row['actor_name'] );
		if ( '' === $who ) {
			$who = 'user' === (string) $row['actor_kind'] ? __( 'The operator', 'cloaklink' ) : __( 'Someone on the desk', 'cloaklink' );
		}
		$where = trim( (string) $row['city'] );
		$ip    = (string) $row['ip'];
		$place = '' !== $where ? $where . ( '' !== (string) $row['country_code'] && 'XX' !== (string) $row['country_code'] ? '' : '' ) : '';

		return array(
			'id'     => (int) $row['id'],
			'ticket' => (int) $row['ticket_id'],
			'ref'    => (string) $row['ref'],
			'event'  => (string) $row['event'],
			'who'    => $who,
			'kind'   => (string) $row['actor_kind'],
			'person' => (string) $row['person'],
			'phone'  => (string) $row['phone'],
			'note'   => (string) $row['note'],
			'place'  => $place,
			'ip'     => $ip,
			'device' => trim( (string) $row['device'] . ' · ' . (string) $row['browser'], ' ·' ),
			'os'     => (string) $row['os'],
			'at'     => (string) $row['created_at'],
		);
	}
}
