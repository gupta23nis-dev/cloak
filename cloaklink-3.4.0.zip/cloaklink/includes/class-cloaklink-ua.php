<?php
/**
 * User-agent intelligence.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Parses UA strings into device, OS, browser, model and in-app markers.
 */
class CloakLink_UA {

	/**
	 * Parse a user agent string.
	 *
	 * @param string $ua User agent.
	 * @return array
	 */
	public static function parse( $ua ) {
		$ua = (string) $ua;

		$out = array(
			'device'       => 'desktop',
			'brand'        => '',
			'device_model' => '',
			'os'           => 'Unknown',
			'browser'      => 'Unknown',
			'in_app'       => '',
			'bot'          => 0,
		);

		if ( '' === trim( $ua ) ) {
			$out['device'] = 'unknown';
			return $out;
		}

		if ( preg_match( '/bot|crawler|spider|crawling|facebookexternalhit|preview|slurp|bingpreview|headless|monitor|curl|wget|python-requests|axios/i', $ua ) ) {
			$out['bot']    = 1;
			$out['device'] = 'bot';
			return $out;
		}

		/* Operating system. */
		if ( preg_match( '/Windows NT 10/i', $ua ) ) {
			$out['os'] = 'Windows 10/11';
		} elseif ( preg_match( '/Windows NT 6\.3/i', $ua ) ) {
			$out['os'] = 'Windows 8.1';
		} elseif ( preg_match( '/Windows/i', $ua ) ) {
			$out['os'] = 'Windows';
		} elseif ( preg_match( '/iPhone|iPod/i', $ua ) ) {
			$out['os'] = 'iOS';
		} elseif ( preg_match( '/iPad/i', $ua ) ) {
			$out['os'] = 'iPadOS';
		} elseif ( preg_match( '/Android\s([0-9.]+)/i', $ua, $m ) ) {
			$out['os'] = 'Android ' . $m[1];
		} elseif ( preg_match( '/Android/i', $ua ) ) {
			$out['os'] = 'Android';
		} elseif ( preg_match( '/Mac OS X/i', $ua ) ) {
			$out['os'] = 'macOS';
		} elseif ( preg_match( '/CrOS/i', $ua ) ) {
			$out['os'] = 'ChromeOS';
		} elseif ( preg_match( '/Linux/i', $ua ) ) {
			$out['os'] = 'Linux';
		}

		/* Device class and Android model. */
		if ( preg_match( '/iPad/i', $ua ) ) {
			$out['device'] = 'tablet';
			$out['brand']  = 'Apple';
			$out['device_model'] = 'iPad';
		} elseif ( preg_match( '/Tablet|Tab\b|Nexus 7|Nexus 9|SM-T/i', $ua ) ) {
			$out['device'] = 'tablet';
		} elseif ( preg_match( '/Mobile|iPhone|iPod|Android.*Mobile|Windows Phone/i', $ua ) ) {
			$out['device'] = 'mobile';
		}

		if ( preg_match( '/iPhone/i', $ua ) ) {
			$out['brand'] = 'Apple';
			$out['device_model'] = 'iPhone';
		} elseif ( preg_match( '/Android/i', $ua ) ) {
			// Model token is usually "Android x; Model Build/".
			if ( preg_match( '/Android[^;]*;\s*([^;)]+?)\s*(?:Build|\))/i', $ua, $m ) ) {
				$model = trim( preg_replace( '/\s*(Build\/.*)?$/i', '', $m[1] ) );
				$model = trim( preg_replace( '/^(en-us|en-gb|en|hi-in|mr-in);?/i', '', $model ) );
				$out['device_model'] = $model;
				$out['brand']        = self::brand_from_model( $model );
			}
		} elseif ( preg_match( '/SM-([A-Z0-9]+)/i', $ua, $m ) ) {
			$out['brand']        = 'Samsung';
			$out['device_model'] = 'SM-' . $m[1];
		}

		/* In-app browsers (Instagram / Facebook referrals matter here). */
		if ( preg_match( '/Instagram/i', $ua ) ) {
			$out['in_app'] = 'Instagram';
		} elseif ( preg_match( '/FBAN|FBAV|FB_IAB/i', $ua ) ) {
			$out['in_app'] = 'Facebook';
		} elseif ( preg_match( '/Line\//i', $ua ) ) {
			$out['in_app'] = 'LINE';
		} elseif ( preg_match( '/WhatsApp/i', $ua ) ) {
			$out['in_app'] = 'WhatsApp';
		} elseif ( preg_match( '/Twitter|Twitterbot/i', $ua ) ) {
			$out['in_app'] = 'X';
		}

		/* Browser, in priority order. */
		$browsers = array(
			'Instagram' => '/Instagram/i',
			'Facebook'  => '/FBAN|FBAV/i',
			'Edge'      => '/Edg\/|EdgiOS|EdgA/i',
			'Opera'     => '/OPR\/|Opera/i',
			'Samsung Internet' => '/SamsungBrowser/i',
			'UC Browser'       => '/UCBrowser|UCWEB/i',
			'Chrome'           => '/Chrome\/|CriOS/i',
			'Brave'            => '/Brave/i',
			'Firefox'          => '/Firefox|FxiOS/i',
			'Safari'           => '/Safari/i',
		);
		$out['browser'] = 'Unknown';
		foreach ( $browsers as $name => $pattern ) {
			if ( preg_match( $pattern, $ua ) ) {
				$out['browser'] = $name;
				break;
			}
		}
		if ( preg_match( '/(Chrome|CriOS|Firefox|FxiOS|Version)\/([0-9]+)/i', $ua, $m ) ) {
			$out['browser'] .= ' ' . $m[2];
		}
		if ( $out['in_app'] ) {
			$out['browser'] = $out['in_app'] . ' in-app';
		}

		return $out;
	}

	/**
	 * Guess handset brand from a model string.
	 *
	 * @param string $model Model.
	 * @return string
	 */
	private static function brand_from_model( $model ) {
		$model = strtoupper( (string) $model );
		$map   = array(
			'SM-'  => 'Samsung',
			'PIXEL' => 'Google',
			'ONEPLUS' => 'OnePlus',
			'MI '  => 'Xiaomi',
			'REDMI' => 'Xiaomi',
			'POCO' => 'POCO',
			'M20'  => 'Xiaomi',
			'RMX'  => 'Realme',
			'CPH'  => 'OPPO',
			'V2'   => 'Vivo',
			'INFINIX' => 'Infinix',
			'TECNO' => 'Tecno',
			'NOKIA' => 'Nokia',
			'MOTO' => 'Motorola',
			'XT'   => 'Motorola',
			'LGM'  => 'LG',
			'HUAWEI' => 'Huawei',
			'ANE-LX' => 'Huawei',
		);
		foreach ( $map as $needle => $brand ) {
			if ( false !== strpos( $model, $needle ) ) {
				return $brand;
			}
		}
		return '';
	}

	/**
	 * Human readable device summary.
	 *
	 * @param array $v Visit row.
	 * @return string
	 */
	public static function summary( $v ) {
		$bits = array();
		if ( ! empty( $v['brand'] ) ) {
			$bits[] = $v['brand'];
		}
		if ( ! empty( $v['device_model'] ) && $v['device_model'] !== $v['brand'] ) {
			$bits[] = $v['device_model'];
		}
		if ( ! empty( $v['os'] ) ) {
			$bits[] = $v['os'];
		}
		return $bits ? implode( ' · ', $bits ) : ucfirst( (string) $v['device'] );
	}

	/**
	 * Emoji/icon for a device class.
	 *
	 * @param string $device Device class.
	 * @return string
	 */
	public static function icon( $device ) {
		$map = array(
			'mobile'  => '📱',
			'tablet'  => '📟',
			'desktop' => '💻',
			'bot'     => '🤖',
		);
		return isset( $map[ $device ] ) ? $map[ $device ] : '❓';
	}
}
