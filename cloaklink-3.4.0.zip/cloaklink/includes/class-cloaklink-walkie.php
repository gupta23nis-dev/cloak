<?php
/**
 * Walkie-talkie: short messages between the operator and the case desk.
 *
 * The desk already has tickets, which are formal: a name, a mobile, a decision
 * that makes a link. Most of what actually passes between an operator and the
 * person working the desk is not formal — "call this one again", "the file is
 * the 2023 order, not the 2024 one", "I am stepping out for ten minutes". A
 * ticket queue is the wrong shape for that, and a mail is too slow.
 *
 * So this is a radio, not a mailbox. A thread is either one person talking to
 * the office (a direct line) or several people in one room (a group). Every
 * message is one row; the poll is one query for everything after an id. There
 * is no read receipt to get wrong, because the unread count is the number of
 * rows newer than this person's own position in that thread.
 *
 * Who may talk to whom:
 *   - the operator may open a line with anyone, and make any group;
 *   - an agent may talk to the operator's desk — the line to the office is
 *     opened for them the first time they use it — and to any group they are
 *     a member of;
 *   - an agent may not open a line with another agent. That is a decision
 *     about the desk, not a technical limit: two people who can whisper
 *     privately can also agree to hide a ticket, and the operator would have
 *     no record of it.
 *
 * Sounds are the operator's. Each person may be given their own tone, so a
 * message from the person who handles the urgent work is recognisable across
 * a room without reading the screen; a group has one tone for everybody in it.
 * The tone is described as a small recipe — a waveform, a run of notes and a
 * length — and drawn in the browser, so there is no file to upload and nothing
 * to break when one is missing.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Messages, threads, groups and their tones.
 */
class CloakLink_Walkie {

	const MAX_BODY = 800;

	/** How many messages one screen asks for. */
	const PAGE = 120;

	/** @var CloakLink_DB */
	private $db;

	/** @var CloakLink_Settings */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param CloakLink_DB       $db       Database helper.
	 * @param CloakLink_Settings $settings Settings.
	 */
	public function __construct( $db, $settings ) {
		$this->db       = $db;
		$this->settings = $settings;
	}

	/**
	 * Threads table.
	 *
	 * @return string
	 */
	public function threads_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_radio_threads';
	}

	/**
	 * Members table.
	 *
	 * @return string
	 */
	public function members_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_radio_members';
	}

	/**
	 * Messages table.
	 *
	 * @return string
	 */
	public function messages_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_radio_messages';
	}

	/**
	 * The operator as a participant.
	 *
	 * WordPress users and case-desk agents are two different people records, so
	 * a message needs to say which kind it came from. A neutral id of 0 with
	 * the kind is not enough — an operator id of 3 and an agent id of 3 are two
	 * different people — so the pair is what identifies a sender.
	 *
	 * @param string $kind  'user' or 'agent'.
	 * @param int    $id    Account id.
	 * @param string $name  Display name.
	 * @return array
	 */
	public static function actor( $kind, $id, $name ) {
		return array(
			'kind' => 'agent' === $kind ? 'agent' : 'user',
			'id'   => (int) $id,
			'name' => (string) $name,
		);
	}

	/**
	 * The operator's own actor, from the logged-in WordPress user.
	 *
	 * @return array|null
	 */
	public function me_user() {
		$user = wp_get_current_user();
		if ( ! $user || ! $user->ID ) {
			return null;
		}
		$name = trim( (string) $user->display_name );
		if ( '' === $name ) {
			$name = (string) $user->user_login;
		}
		return self::actor( 'user', (int) $user->ID, $name );
	}

	/**
	 * The signed-in agent, when the case desk is what is asking.
	 *
	 * @return array|null
	 */
	public function me_agent() {
		$agent = cloaklink()->agents->current();
		if ( ! $agent ) {
			return null;
		}
		return self::actor( 'agent', (int) $agent['id'], (string) $agent['name'] );
	}

	/**
	 * Whether this actor is the operator's side.
	 *
	 * @param array $me Actor.
	 * @return bool
	 */
	public static function is_office( $me ) {
		return isset( $me['kind'] ) && 'user' === $me['kind'];
	}

	/**
	 * Every tone this install can play, described rather than recorded.
	 *
	 * Each one is a short recipe the browser draws: a waveform, one to four
	 * notes, and a length. A file would be better sound and worse software —
	 * it can be missing, it can fail to decode, and it has to be uploaded
	 * before the feature works at all.
	 *
	 * @return array
	 */
	/**
	 * The radio's behaviour switches, resolved for the browser.
	 *
	 * These are read from the advanced settings and nowhere else, so a
	 * deployment that changes one changes the radio for every console at
	 * once. Each value is clamped here rather than trusted: the option is
	 * reachable from a form, and a number typed into a form is not a promise.
	 *
	 * @return array
	 */
	public static function radio_config() {
		$adv = function_exists( 'cloaklink' ) ? cloaklink()->adv : null;
		$get = function ( $key, $fallback ) use ( $adv ) {
			if ( ! $adv ) {
				return $fallback;
			}
			$val = $adv->get( $key, $fallback );
			return ( null === $val || '' === $val ) ? $fallback : $val;
		};
		$yes = function ( $key, $fallback ) use ( $adv ) {
			if ( ! $adv ) {
				return (bool) $fallback;
			}
			return $adv->yes( $key );
		};

		$pos = (string) $get( 'radio_who_pos', 'top-right' );
		if ( ! in_array( $pos, array( 'top-right', 'top-left', 'bottom-left' ), true ) ) {
			$pos = 'top-right';
		}

		$stun = (string) $get( 'radio_stun', 'google' );
		$stun_urls = array(
			'google'     => array( 'stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302' ),
			'cloudflare' => array( 'stun:stun.cloudflare.com:3478' ),
			'off'        => array(),
		);
		$ice = isset( $stun_urls[ $stun ] ) ? $stun_urls[ $stun ] : $stun_urls['google'];

		// A relay, when one is configured. Listed after the STUN servers so a
		// direct route is still preferred: a relay costs bandwidth and adds a
		// hop, and is only reached for when no direct route can be found.
		//
		// Without this there is a class of call that always fails silently —
		// two people behind symmetric NATs or a firewall that drops UDP get a
		// connected line, a live track, and no sound. STUN cannot fix that;
		// only a relay carries the media.
		$turn_host = trim( (string) $get( 'radio_turn', '' ) );
		$turn      = null;
		if ( '' !== $turn_host ) {
			if ( 0 !== strpos( $turn_host, 'turn:' ) && 0 !== strpos( $turn_host, 'turns:' ) ) {
				$turn_host = 'turn:' . $turn_host;
			}
			$turn = array(
				'urls'       => $turn_host,
				'username'   => (string) $get( 'radio_turn_user', '' ),
				'credential' => (string) $get( 'radio_turn_pass', '' ),
			);
		}

		return array(
			// Whether a direct line carries voice at all.
			'live'       => $yes( 'radio_live', 1 ),
			// The speaker card, where it sits and how long it stays.
			'whoCard'    => $yes( 'radio_who_card', 1 ),
			'whoPos'     => $pos,
			'whoLinger'  => max( 0, min( 30, (int) $get( 'radio_who_seconds', 2 ) ) ) * 1000,
			// Sounds the radio makes on its own account.
			'cue'        => $yes( 'radio_cue', 1 ),
			'beepEnd'    => $yes( 'radio_beep_end', 1 ),
			// How the key behaves.
			'mode'       => in_array( (string) $get( 'radio_ptt_mode', 'hold' ), array( 'hold', 'latch', 'handsfree' ), true )
				? (string) $get( 'radio_ptt_mode', 'hold' )
				: 'hold',
			// Microphone constraints. Null means "let the browser choose",
			// which is what an untouched install does.
			'echo'       => $yes( 'radio_echo', 1 ),
			'noise'      => $yes( 'radio_noise', 1 ),
			'gain'       => $yes( 'radio_gain', 1 ),
			'volume'     => max( 20, min( 100, (int) $get( 'radio_volume', 100 ) ) ) / 100,
			// How long a handshake is given before it is rebuilt. Zero is off.
			'retryMs'    => max( 0, min( 60, (int) $get( 'radio_retry', 12 ) ) ) * 1000,
			// The address-discovery servers, and how often the handshake is
			// asked for.
			'ice'        => $ice,
			// The relay entry, as one object rather than a URL: a TURN server
			// without its credentials is a server that refuses.
			'turn'       => $turn,
			'pollMs'     => max( 500, min( 5000, (int) $get( 'radio_poll_ms', 1000 ) ) ),
			// Behaviour around a press.
			'ring'       => $yes( 'radio_ring', 0 ),
			'autoAnswer' => $yes( 'radio_auto_answer', 1 ),
			'muteBlur'   => $yes( 'radio_mute_on_blur', 1 ),
			'meter'      => $yes( 'radio_show_meter', 1 ),
			'groupLive'  => $yes( 'radio_group_live', 0 ),
		);
	}

	/**
	 * The signal table's retention, in hours.
	 *
	 * A handshake older than this was addressed to a browser that has gone.
	 * Two hours is the shipped value: long enough for a phone that slept
	 * mid-call to come back to a line that still knows it, short enough that
	 * the table never grows past one shift.
	 *
	 * @return int
	 */
	public static function signal_retention() {
		$adv = function_exists( 'cloaklink' ) ? cloaklink()->adv : null;
		if ( ! $adv ) {
			return 2;
		}
		return max( 1, min( 24, (int) $adv->get( 'radio_history', 2 ) ) );
	}

	public static function tones() {
		return array(
			// The set's own vocabulary, retuned for the desk theme.
			//
			// Every one of these is a figure a station radio makes rather
			// than a phone notification: two or three notes, on a triangle or
			// a sine, none of them longer than a third of a second. The keys
			// are unchanged, so an operator's stored preference still names
			// the same sound it always did — only the sound is different.
			'chirp'   => array( __( 'Chirp', 'cloaklink' ), 'triangle', array( 784, 1046.5 ), 0.09 ),
			'double'  => array( __( 'Double beep', 'cloaklink' ), 'sine', array( 698.46, 698.46 ), 0.10 ),
			'rising'  => array( __( 'Rising', 'cloaklink' ), 'triangle', array( 523.25, 659.25, 783.99 ), 0.10 ),
			'falling' => array( __( 'Falling', 'cloaklink' ), 'triangle', array( 783.99, 659.25, 523.25 ), 0.10 ),
			'triple'  => array( __( 'Triple', 'cloaklink' ), 'sine', array( 880, 880, 880 ), 0.075 ),
			'deep'    => array( __( 'Deep', 'cloaklink' ), 'sine', array( 261.63, 196.00 ), 0.17 ),
			'bright'  => array( __( 'Bright', 'cloaklink' ), 'triangle', array( 1174.66, 1396.91 ), 0.08 ),
			'pulse'   => array( __( 'Pulse', 'cloaklink' ), 'sine', array( 622.25, 622.25, 622.25, 622.25 ), 0.055 ),
		);
	}

	/**
	 * Every tone, keyed, as the browser wants them.
	 *
	 * @return array
	 */
	public static function tones_json() {
		$out = array();
		foreach ( array_keys( self::tones() ) as $key ) {
			$out[ $key ] = self::tone( $key );
		}
		return $out;
	}

	/**
	 * A tone as the browser needs it.
	 *
	 * @param string $name Tone key.
	 * @return array
	 */
	public static function tone( $name ) {
		$all  = self::tones();
		$name = isset( $all[ $name ] ) ? $name : 'chirp';
		return array_merge(
			array( 'key' => $name, 'label' => $all[ $name ][0] ),
			array(
				'wave'  => $all[ $name ][1],
				'notes' => $all[ $name ][2],
				'gap'   => $all[ $name ][3],
			)
		);
	}

	/**
	 * The default tone for everybody, from the operator's settings.
	 *
	 * @return string
	 */
	public function default_tone() {
		$tone = sanitize_key( (string) $this->settings->get( 'radio_tone', 'chirp' ) );
		$all  = self::tones();
		return isset( $all[ $tone ] ) ? $tone : 'chirp';
	}

	/**
	 * The tone for one person, falling back to the desk's own.
	 *
	 * @param int    $agent_id Agent id, or 0 for the operator.
	 * @param string $mine     Tone stored on the account, if any.
	 * @return array
	 */
	public function tone_for( $agent_id, $mine = '' ) {
		$mine = sanitize_key( (string) $mine );
		$all  = self::tones();
		if ( '' !== $mine && isset( $all[ $mine ] ) ) {
			return self::tone( $mine );
		}
		return self::tone( $this->default_tone() );
	}

	/**
	 * Whether the radio is switched on at all.
	 *
	 * @return bool
	 */
	public function enabled() {
		return (bool) $this->settings->get( 'radio_on', 1 );
	}

	/**
	 * Whether an actor is a member of a thread.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor.
	 * @return bool
	 */
	public function is_member( $thread_id, $me ) {
		global $wpdb;
		if ( ! $thread_id || ! $me ) {
			return false;
		}
		$found = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . $this->members_table() . ' WHERE thread_id = %d AND actor_kind = %s AND actor_id = %d', // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $thread_id,
				(string) $me['kind'],
				(int) $me['id']
			)
		);
		return (bool) $found;
	}

	/**
	 * A thread's row.
	 *
	 * @param int $id Thread id.
	 * @return array|null
	 */
	public function get_thread( $id ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . $this->threads_table() . ' WHERE id = %d', absint( $id ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		return $row ? $row : null;
	}

	/**
	 * Every thread this actor can see, newest activity first.
	 *
	 * A direct line is opened on demand: nobody creates one, somebody simply
	 * writes into it. That is what `ensure_direct()` is for, and it is why an
	 * operator opening the radio already sees every agent — the threads exist
	 * as soon as they are needed and are hidden until they have a message.
	 *
	 * @param array $me   Actor.
	 * @param bool  $all  Include threads with no messages yet.
	 * @return array
	 */
	public function threads_for( $me, $all = false ) {
		global $wpdb;
		if ( ! $me ) {
			return array();
		}
		$m = $this->members_table();
		$t = $this->threads_table();
		$g = $this->messages_table();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT th.*, mb.last_seen, mb.actor_kind, mb.actor_id
				FROM {$m} mb INNER JOIN {$t} th ON th.id = mb.thread_id
				WHERE mb.actor_kind = %s AND mb.actor_id = %d
				ORDER BY th.last_at DESC, th.id DESC LIMIT 80", // phpcs:ignore WordPress.DB.PreparedSQL
				(string) $me['kind'],
				(int) $me['id']
			),
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();

		$out = array();
		foreach ( $rows as $row ) {
			$id   = (int) $row['id'];
			$info = $this->describe( $row, $me );

			// A brand-new direct line with nothing in it is a name in a list,
			// not a conversation. It is kept (the operator's list is built from
			// these) but flagged, and the view decides whether to draw it. An
			// agent's own line is never skipped: it is the only one they have,
			// and an empty radio is still a radio they can press.
			$info['empty'] = empty( $row['last_at'] ) || '0000-00-00 00:00:00' === (string) $row['last_at'];
			if ( ! $all && $info['empty'] && self::is_office( $me ) ) {
				continue;
			}

			$info['unread'] = $this->unread_count( $id, $me, (string) $row['last_seen'] );
			$info['last_seen'] = (string) $row['last_seen'];
			$out[] = $info;
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return strcmp( (string) $b['last_at'], (string) $a['last_at'] );
			}
		);

		return $out;
	}

	/**
	 * Turn a thread row into what a screen needs to draw it.
	 *
	 * The name of a direct line is the *other* person: the operator sees the
	 * agent's name, the agent sees "the office". That asymmetry is deliberate —
	 * a desk with five agents must not show all five the same heading.
	 *
	 * @param array $row Thread row.
	 * @param array $me  Actor.
	 * @return array
	 */
	/**
	 * "3m", "2h", "5d" — computed against the site's clock.
	 *
	 * @param string $moment Stored DATETIME.
	 * @return string
	 */
	private function human_age( $moment ) {
		if ( '' === $moment || 0 === strpos( $moment, '0000-00-00' ) ) {
			return '';
		}
		$then = strtotime( $moment . ' UTC' );
		$now  = strtotime( current_time( 'mysql', true ) . ' UTC' );
		if ( ! $then || ! $now ) {
			return '';
		}
		$s = max( 0, $now - $then );
		if ( $s < 60 ) {
			return __( 'now', 'cloaklink' );
		}
		if ( $s < 3600 ) {
			/* translators: %d: minutes */
			return sprintf( __( '%dm', 'cloaklink' ), (int) floor( $s / 60 ) );
		}
		if ( $s < 86400 ) {
			/* translators: %d: hours */
			return sprintf( __( '%dh', 'cloaklink' ), (int) floor( $s / 3600 ) );
		}
		/* translators: %d: days */
		return sprintf( __( '%dd', 'cloaklink' ), (int) floor( $s / 86400 ) );
	}

	public function describe( $row, $me ) {
		$id   = (int) $row['id'];
		$kind = (string) $row['kind'];

		$info = array(
			'id'         => $id,
			'kind'       => $kind,
			'name'       => (string) $row['name'],
			'last_at'    => (string) $row['last_at'],
			// The stored moment is the site's wall clock. The browser's clock
			// and its timezone are its own, so the "how long ago" is worked out
			// here, where both sides of the subtraction are in the same zone.
			'ago'        => $this->human_age( (string) $row['last_at'] ),
			'last_body'  => (string) $row['last_body'],
			'last_kind'  => (string) $row['last_kind'],
			'last_by'    => (string) $row['last_by'],
			'tone'       => (string) $row['tone'],
			'members'    => array(),
			'peer'       => 0,
			'unread'     => 0,
		);

		if ( 'direct' === $kind ) {
			$peer = $this->direct_peer( $id, $me );
			$info['peer'] = $peer ? (int) $peer['id'] : 0;
			if ( $peer ) {
				$info['name'] = self::is_office( $me )
					? (string) $peer['name']
					: __( 'The office', 'cloaklink' );
				$info['peer_kind'] = (string) $peer['kind'];

				// A direct line sounds like the person on the other end. That
				// is what makes a per-agent tone worth setting: the office can
				// hear which agent is calling without looking at the screen,
				// and an agent hears the office's own tone.
				$their = 'agent' === $info['peer_kind']
					? (string) cloaklink()->agents->radio_tone( (int) $peer['id'] )
					: '';
				$info['tone'] = $this->tone_for( (int) $peer['id'], $their )['key'];
			}
		} else {
			if ( '' === trim( $info['name'] ) ) {
				$info['name'] = __( 'Group', 'cloaklink' );
			}
			$info['tone'] = '' !== $info['tone'] ? $info['tone'] : $this->default_tone();
		}

		return $info;
	}

	/**
	 * The other person on a direct line.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor.
	 * @return array|null
	 */
	public function direct_peer( $thread_id, $me ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT actor_kind, actor_id, actor_name FROM ' . $this->members_table() . ' WHERE thread_id = %d AND NOT ( actor_kind = %s AND actor_id = %d ) LIMIT 1', // phpcs:ignore WordPress.DB.PreparedSQL
				(int) $thread_id,
				(string) $me['kind'],
				(int) $me['id']
			),
			ARRAY_A
		);
		if ( ! $row ) {
			return null;
		}
		return array(
			'kind' => (string) $row['actor_kind'],
			'id'   => (int) $row['actor_id'],
			'name' => (string) $row['actor_name'],
		);
	}

	/**
	 * Messages newer than a position in a thread.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor.
	 * @param string $since    ISO moment, or '' for the last page.
	 * @return array
	 */
	public function messages( $thread_id, $me, $since = '' ) {
		global $wpdb;
		if ( ! $this->is_member( $thread_id, $me ) ) {
			return array();
		}
		$table = $this->messages_table();

		$sql = 'SELECT * FROM ' . $table . ' WHERE thread_id = %d';
		$args = array( (int) $thread_id );
		if ( '' !== $since ) {
			$sql .= ' AND ( created_at > %s OR ( created_at = %s AND id > %d ) )';
			$args[] = $since;
			$args[] = $since;
			$args[] = isset( $_POST['since_id'] ) ? absint( $_POST['since_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		}
		$sql .= ' ORDER BY id DESC LIMIT %d';
		$args[] = '' !== $since ? 40 : self::PAGE;

		$rows = $wpdb->get_results(
			call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $args ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$rows = is_array( $rows ) ? $rows : array();
		$rows = array_reverse( $rows );

		$out = array();
		foreach ( $rows as $row ) {
			$out[] = $this->shape_message( $row, $me );
		}
		return $out;
	}

	/**
	 * One message, as the browser needs it.
	 *
	 * @param array $row Message row.
	 * @param array $me  Actor.
	 * @return array
	 */
	public function shape_message( $row, $me ) {
		$mine = ( (string) $row['from_kind'] === (string) $me['kind'] && (int) $row['from_id'] === (int) $me['id'] );
		return array(
			'id'     => (int) $row['id'],
			'body'   => (string) $row['body'],
			'kind'   => (string) $row['kind'],
			'from'   => (string) $row['from_name'],
			'fromId' => (int) $row['from_id'],
			'mine'   => $mine,
			'at'     => CloakLink_Admin::stamp( $row['created_at'], 'g:i A' ),
			'day'    => CloakLink_Admin::stamp( $row['created_at'], 'j M' ),
			'raw'    => (string) $row['created_at'],
			'seq'    => (int) $row['id'],
			'clip'   => isset( $row['clip'] ) && '' !== (string) $row['clip']
				? add_query_arg(
					array(
						'action' => 'cloaklink_radio',
						'what'   => 'clip',
						'id'     => (int) $row['id'],
					),
					admin_url( 'admin-ajax.php' )
				)
				: '',
			'secs'   => isset( $row['secs'] ) ? (int) $row['secs'] : 0,
		);
	}

	/**
	 * How many messages in a thread arrived after this person last looked.
	 *
	 * @param int    $thread_id Thread id.
	 * @param array  $me        Actor.
	 * @param string $last_seen ISO moment.
	 * @return int
	 */
	public function unread_count( $thread_id, $me, $last_seen ) {
		global $wpdb;
		$table = $this->messages_table();
		$sql   = 'SELECT COUNT(*) FROM ' . $table . ' WHERE thread_id = %d AND NOT ( from_kind = %s AND from_id = %d )';
		$args  = array( (int) $thread_id, (string) $me['kind'], (int) $me['id'] );
		if ( '' !== $last_seen && '0000-00-00 00:00:00' !== $last_seen ) {
			$sql   .= ' AND created_at > %s';
			$args[] = $last_seen;
		}
		return (int) $wpdb->get_var(
			call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $args ) ) // phpcs:ignore WordPress.DB.PreparedSQL
		);
	}

	/**
	 * Everything unread across every thread, for the topbar badge.
	 *
	 * @param array $me Actor.
	 * @return int
	 */
	public function unread_total( $me ) {
		$n = 0;
		foreach ( $this->threads_for( $me ) as $t ) {
			$n += (int) $t['unread'];
		}
		return $n;
	}

	/**
	 * Find or open the direct line between two people.
	 *
	 * A thread is "direct" and has exactly two members. It is keyed by the
	 * pair, sorted, in `name` so the lookup is one comparison and two people
	 * cannot end up with two lines to each other by creating them at the same
	 * moment from different screens.
	 *
	 * @param array $a Actor.
	 * @param array $b Actor.
	 * @return int Thread id, or 0.
	 */
	public function ensure_direct( $a, $b ) {
		global $wpdb;
		if ( ! $a || ! $b ) {
			return 0;
		}
		$key = $this->pair_key( $a, $b );

		$found = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . $this->threads_table() . " WHERE kind = 'direct' AND name = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$key
			)
		);
		if ( $found ) {
			return (int) $found;
		}

		$now = current_time( 'mysql' );
		$ok  = $wpdb->insert(
			$this->threads_table(),
			array(
				'kind'       => 'direct',
				'name'       => $key,
				'tone'       => '',
				'created_by' => (string) $a['kind'] . ':' . (int) $a['id'],
				'created_at' => $now,
				'last_at'    => '0000-00-00 00:00:00',
			)
		);
		if ( ! $ok ) {
			return 0;
		}
		$id = (int) $wpdb->insert_id;

		foreach ( array( $a, $b ) as $who ) {
			$wpdb->insert(
				$this->members_table(),
				array(
					'thread_id'  => $id,
					'actor_kind' => (string) $who['kind'],
					'actor_id'   => (int) $who['id'],
					'actor_name' => (string) $who['name'],
					'last_seen'  => '0000-00-00 00:00:00',
					'joined_at'  => $now,
				)
			);
		}

		return $id;
	}

	/**
	 * A stable key for a pair of actors.
	 *
	 * @param array $a Actor.
	 * @param array $b Actor.
	 * @return string
	 */
	private function pair_key( $a, $b ) {
		$one = (string) $a['kind'] . ':' . (int) $a['id'];
		$two = (string) $b['kind'] . ':' . (int) $b['id'];
		$pair = array( $one, $two );
		sort( $pair );
		return implode( '|', $pair );
	}

	/**
	 * Make a group.
	 *
	 * @param array  $me      Actor doing it.
	 * @param string $name    Group name.
	 * @param array  $agent_ids Agent ids to include.
	 * @param string $tone    Tone key for the group.
	 * @return int|WP_Error Thread id.
	 */
	public function create_group( $me, $name, $agent_ids, $tone = '' ) {
		global $wpdb;

		if ( ! self::is_office( $me ) ) {
			return new WP_Error( 'not_office', __( 'Only the office can make a group.', 'cloaklink' ) );
		}
		$name = sanitize_text_field( (string) $name );
		if ( '' === trim( $name ) ) {
			return new WP_Error( 'name', __( 'Give the group a name.', 'cloaklink' ) );
		}
		$name = mb_substr( $name, 0, 80 );

		$all = self::tones();
		$tone = sanitize_key( (string) $tone );
		if ( ! isset( $all[ $tone ] ) ) {
			$tone = $this->default_tone();
		}

		$now = current_time( 'mysql' );
		$ok  = $wpdb->insert(
			$this->threads_table(),
			array(
				'kind'       => 'group',
				'name'       => $name,
				'tone'       => $tone,
				'created_by' => (string) $me['kind'] . ':' . (int) $me['id'],
				'created_at' => $now,
				'last_at'    => '0000-00-00 00:00:00',
			)
		);
		if ( ! $ok ) {
			return new WP_Error( 'db', __( 'The group could not be saved.', 'cloaklink' ) );
		}
		$id = (int) $wpdb->insert_id;

		$this->add_member( $id, $me );
		foreach ( array_unique( array_map( 'absint', (array) $agent_ids ) ) as $agent_id ) {
			if ( $agent_id < 1 ) {
				continue;
			}
			$agent = cloaklink()->agents->get( $agent_id );
			if ( ! $agent ) {
				continue;
			}
			$this->add_member( $id, self::actor( 'agent', $agent_id, (string) $agent['name'] ) );
		}

		return $id;
	}

	/**
	 * Put somebody in a thread, once.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $who       Actor.
	 * @return void
	 */
	public function add_member( $thread_id, $who ) {
		global $wpdb;
		if ( $this->is_member( $thread_id, $who ) ) {
			return;
		}
		$wpdb->insert(
			$this->members_table(),
			array(
				'thread_id'  => (int) $thread_id,
				'actor_kind' => (string) $who['kind'],
				'actor_id'   => (int) $who['id'],
				'actor_name' => (string) $who['name'],
				'last_seen'  => '0000-00-00 00:00:00',
				'joined_at'  => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Add or remove people from a group.
	 *
	 * The operator is always in it: a group with nobody from the office is a
	 * room where agents talk where nobody can hear them.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor doing it.
	 * @param array $agent_ids The full set of agents who should be in it.
	 * @return bool
	 */
	public function set_group_members( $thread_id, $me, $agent_ids ) {
		global $wpdb;
		$thread = $this->get_thread( $thread_id );
		if ( ! $thread || 'group' !== (string) $thread['kind'] || ! self::is_office( $me ) ) {
			return false;
		}

		$want = array();
		foreach ( array_unique( array_map( 'absint', (array) $agent_ids ) ) as $agent_id ) {
			if ( $agent_id < 1 ) {
				continue;
			}
			$agent = cloaklink()->agents->get( $agent_id );
			if ( $agent ) {
				$want[ 'agent:' . $agent_id ] = self::actor( 'agent', $agent_id, (string) $agent['name'] );
			}
		}
		$want[ 'user:' . (int) $me['id'] ] = $me;

		$current = $this->members( $thread_id );
		foreach ( $current as $one ) {
			$key = (string) $one['kind'] . ':' . (int) $one['id'];
			if ( ! isset( $want[ $key ] ) ) {
				$wpdb->delete(
					$this->members_table(),
					array(
						'thread_id'  => (int) $thread_id,
						'actor_kind' => (string) $one['kind'],
						'actor_id'   => (int) $one['id'],
					)
				);
			}
		}
		foreach ( $want as $who ) {
			$this->add_member( $thread_id, $who );
		}

		return true;
	}

	/**
	 * The people in a thread.
	 *
	 * @param int $thread_id Thread id.
	 * @return array
	 */
	public function members( $thread_id ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare( 'SELECT * FROM ' . $this->members_table() . ' WHERE thread_id = %d ORDER BY actor_kind ASC, actor_id ASC', absint( $thread_id ) ), // phpcs:ignore WordPress.DB.PreparedSQL
			ARRAY_A
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'kind' => (string) $row['actor_kind'],
				'id'   => (int) $row['actor_id'],
				'name' => (string) $row['actor_name'],
			);
		}
		return $out;
	}

	/**
	 * Rename a group and set its tone.
	 *
	 * @param int    $thread_id Thread id.
	 * @param array  $me        Actor.
	 * @param string $name      New name, or '' to leave it.
	 * @param string $tone      Tone key, or '' to leave it.
	 * @return bool
	 */
	public function update_group( $thread_id, $me, $name = '', $tone = '' ) {
		global $wpdb;
		$thread = $this->get_thread( $thread_id );
		if ( ! $thread || 'group' !== (string) $thread['kind'] || ! self::is_office( $me ) ) {
			return false;
		}
		$data = array();
		if ( '' !== trim( (string) $name ) ) {
			$data['name'] = mb_substr( sanitize_text_field( (string) $name ), 0, 80 );
		}
		$all = self::tones();
		if ( '' !== (string) $tone && isset( $all[ sanitize_key( (string) $tone ) ] ) ) {
			$data['tone'] = sanitize_key( (string) $tone );
		}
		if ( ! $data ) {
			return true;
		}
		return false !== $wpdb->update( $this->threads_table(), $data, array( 'id' => (int) $thread_id ) );
	}

	/**
	 * Remove a group entirely.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor.
	 * @return bool
	 */
	public function delete_group( $thread_id, $me ) {
		global $wpdb;
		$thread = $this->get_thread( $thread_id );
		if ( ! $thread || 'group' !== (string) $thread['kind'] || ! self::is_office( $me ) ) {
			return false;
		}
		$wpdb->delete( $this->messages_table(), array( 'thread_id' => (int) $thread_id ) );
		$wpdb->delete( $this->members_table(), array( 'thread_id' => (int) $thread_id ) );
		$wpdb->delete( $this->threads_table(), array( 'id' => (int) $thread_id ) );
		return true;
	}

	/**
	 * Write a message.
	 *
	 * @param int    $thread_id Thread id.
	 * @param array  $me        Actor.
	 * @param string $body      What they said.
	 * @param string $kind      'text', 'call' or 'note'.
	 * @return int|WP_Error Message id.
	 */
	public function send( $thread_id, $me, $body, $kind = 'text', $clip = '', $secs = 0 ) {
		global $wpdb;

		if ( ! $this->is_member( $thread_id, $me ) ) {
			return new WP_Error( 'not_member', __( 'You are not in that conversation.', 'cloaklink' ) );
		}
		$body = trim( wp_strip_all_tags( (string) $body ) );
		$clip = sanitize_file_name( (string) $clip );
		if ( '' === $body && '' === $clip ) {
			return new WP_Error( 'empty', __( 'Nothing to send.', 'cloaklink' ) );
		}
		$body = mb_substr( $body, 0, self::MAX_BODY );

		$kind = in_array( $kind, array( 'text', 'call', 'note' ), true ) ? $kind : 'text';
		if ( '' !== $clip ) {
			$kind = 'voice';
		}
		$now = current_time( 'mysql' );

		$ok = $wpdb->insert(
			$this->messages_table(),
			array(
				'thread_id' => (int) $thread_id,
				'from_kind' => (string) $me['kind'],
				'from_id'   => (int) $me['id'],
				'from_name' => (string) $me['name'],
				'kind'      => $kind,
				'body'      => $body,
				'clip'      => '' !== $clip ? $clip : '',
				'secs'      => max( 0, min( 300, (int) $secs ) ),
				'created_at' => $now,
			)
		);
		if ( ! $ok ) {
			return new WP_Error( 'db', __( 'The message could not be saved.', 'cloaklink' ) );
		}
		$id = (int) $wpdb->insert_id;

		$wpdb->update(
			$this->threads_table(),
			array(
				'last_at'   => $now,
				'last_body' => mb_substr( '' !== $body ? $body : '🎙 ' . __( 'Voice note', 'cloaklink' ), 0, 190 ),
				'last_kind' => $kind,
				'last_by'   => (string) $me['name'],
			),
			array( 'id' => (int) $thread_id )
		);

		// The sender has certainly seen their own message.
		$wpdb->update(
			$this->members_table(),
			array( 'last_seen' => $now ),
			array(
				'thread_id'  => (int) $thread_id,
				'actor_kind' => (string) $me['kind'],
				'actor_id'   => (int) $me['id'],
			)
		);

		return $id;
	}

	/**
	 * Mark a thread read up to now.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor.
	 * @return void
	 */
	public function mark_seen( $thread_id, $me ) {
		global $wpdb;
		if ( ! $this->is_member( $thread_id, $me ) ) {
			return;
		}
		$wpdb->update(
			$this->members_table(),
			array( 'last_seen' => current_time( 'mysql' ) ),
			array(
				'thread_id'  => (int) $thread_id,
				'actor_kind' => (string) $me['kind'],
				'actor_id'   => (int) $me['id'],
			)
		);
	}

	/**
	 * Open the line an agent has with the office, creating it if needed.
	 *
	 * @param array $agent_actor Agent actor.
	 * @return int Thread id, or 0.
	 */
	public function office_line( $agent_actor ) {
		$office = $this->office_actor();
		if ( ! $office || ! $agent_actor ) {
			return 0;
		}
		return $this->ensure_direct( $office, $agent_actor );
	}

	/**
	 * The operator account a line goes to.
	 *
	 * The first account that may open the console, so a desk with one operator
	 * has one place for its messages. The name on the thread is "the office"
	 * for an agent regardless of who that is.
	 *
	 * @return array|null
	 */
	public function office_actor() {
		$user = wp_get_current_user();
		if ( $user && $user->ID ) {
			return $this->me_user();
		}
		// No operator is signed in — this is the agent's poll. Pick the first
		// user who could run the panel, which is how the office is defined.
		$admins = get_users(
			array(
				'capability' => apply_filters( 'cloaklink_capability', 'manage_options' ),
				'number'     => 1,
				'orderby'    => 'ID',
				'order'      => 'ASC',
				'fields'     => array( 'ID', 'display_name', 'user_login' ),
			)
		);
		if ( ! $admins ) {
			return null;
		}
		$one = $admins[0];
		$name = trim( (string) $one->display_name );
		return self::actor( 'user', (int) $one->ID, '' !== $name ? $name : (string) $one->user_login );
	}

	/* ---------------------------------------------------------------------
	 * The one endpoint both sides talk to
	 * ------------------------------------------------------------------ */

	/**
	 * Who is asking: the signed-in operator, or the signed-in agent.
	 *
	 * Both panels call the same endpoint because both need the same four
	 * answers — what threads do I have, what is in this one, say this, mark
	 * this read. Only one of the two will ever be signed in on a request, so
	 * the caller never has to say which it is.
	 *
	 * @return array|null
	 */
	public function caller() {
		// Which console is asking decides who is asking. The desk sends
		// `where=desk`; anything else is the operator's panel. That matters
		// because a machine can hold both a WordPress login and an agent
		// session at once — the person who signs in as an agent to see the
		// desk should be the agent there, and the operator on their own panel,
		// with neither identity leaking into the other's messages.
		// phpcs:ignore WordPress.Security.NonceVerification
		$where = isset( $_REQUEST['where'] ) ? sanitize_key( wp_unslash( $_REQUEST['where'] ) ) : '';
		$desk  = ( 'desk' === $where );

		if ( $desk ) {
			$agent = $this->me_agent();
			if ( $agent ) {
				return $agent;
			}
		}
		if ( current_user_can( apply_filters( 'cloaklink_capability', 'manage_options' ) ) ) {
			$me = $this->me_user();
			if ( $me ) {
				return $me;
			}
		}
		if ( ! $desk ) {
			$agent = $this->me_agent();
			if ( $agent ) {
				return $agent;
			}
		}
		return null;
	}

	/**
	 * Where a voice note is kept.
	 *
	 * The same private folder the documents use: outside the web root's
	 * uploads path, guarded by .htaccess, and served only through a handler
	 * that has already checked who is asking.
	 *
	 * @return string
	 */
	public function clips_dir() {
		$uploads = wp_upload_dir();
		if ( empty( $uploads['basedir'] ) ) {
			return '';
		}
		$dir = trailingslashit( $uploads['basedir'] ) . 'cloaklink-private/radio';
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return '';
		}
		$guard = trailingslashit( dirname( dirname( $dir ) ) ) . '.htaccess';
		if ( ! file_exists( $guard ) && ! file_exists( trailingslashit( dirname( dirname( $dir ) ) ) . 'web.config' ) ) {
			@file_put_contents( $guard, "Deny from all\n" ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		return $dir;
	}

	/**
	 * Save an uploaded clip, returning its stored file name.
	 *
	 * @param array $file $_FILES entry.
	 * @return string|WP_Error
	 */
	private function save_clip( $file ) {
		if ( empty( $file ) || ! isset( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'nofile', __( 'The recording did not arrive.', 'cloaklink' ) );
		}
		if ( ! empty( $file['error'] ) ) {
			return new WP_Error( 'upload', __( 'The recording could not be uploaded.', 'cloaklink' ) );
		}
		// Two minutes of Opus is well under this; anything larger is not a
		// voice note and has no business in the private folder.
		if ( (int) $file['size'] > 6 * MB_IN_BYTES ) {
			return new WP_Error( 'big', __( 'That recording is too long.', 'cloaklink' ) );
		}
		$dir = $this->clips_dir();
		if ( '' === $dir ) {
			return new WP_Error( 'dir', __( 'The private folder could not be created.', 'cloaklink' ) );
		}

		$ext  = strtolower( pathinfo( (string) $file['name'], PATHINFO_EXTENSION ) );
		$ext  = in_array( $ext, array( 'webm', 'ogg', 'oga', 'm4a', 'mp4', 'mp3', 'wav' ), true ) ? $ext : 'webm';
		$name = 'r-' . wp_generate_password( 20, false ) . '.' . $ext;

		if ( ! @move_uploaded_file( $file['tmp_name'], trailingslashit( $dir ) . $name ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new WP_Error( 'move', __( 'The recording could not be saved.', 'cloaklink' ) );
		}
		@chmod( trailingslashit( $dir ) . $name, 0640 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		return $name;
	}

	/**
	 * Stream one clip to somebody who is allowed to hear it.
	 *
	 * Only a member of the thread the clip was sent in may fetch it. That is
	 * the whole check, and it is made here rather than by the URL: a URL that
	 * is its own authorisation leaks the moment somebody pastes it.
	 *
	 * @return void Never returns.
	 */
	private function stream_clip() {
		$me = $this->caller();
		if ( ! $me ) {
			status_header( 403 );
			exit;
		}
		// phpcs:disable WordPress.Security.NonceVerification
		$id = isset( $_REQUEST['id'] ) ? absint( $_REQUEST['id'] ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification
		if ( ! $id ) {
			status_header( 404 );
			exit;
		}

		global $wpdb;
		$row = $wpdb->get_row(
			call_user_func_array(
				array( $wpdb, 'prepare' ),
				array( 'SELECT * FROM ' . $this->messages_table() . ' WHERE id = %d', $id )
			),
			ARRAY_A
		);

		if ( ! $row || '' === (string) $row['clip'] || ! $this->is_member( (int) $row['thread_id'], $me ) ) {
			status_header( 404 );
			exit;
		}

		$path = trailingslashit( $this->clips_dir() ) . sanitize_file_name( (string) $row['clip'] );
		if ( ! $path || ! is_file( $path ) ) {
			status_header( 404 );
			exit;
		}

		$ext  = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$mime = array(
			'webm' => 'audio/webm',
			'ogg'  => 'audio/ogg',
			'oga'  => 'audio/ogg',
			'm4a'  => 'audio/mp4',
			'mp4'  => 'audio/mp4',
			'mp3'  => 'audio/mpeg',
			'wav'  => 'audio/wav',
		);
		$type = isset( $mime[ $ext ] ) ? $mime[ $ext ] : 'application/octet-stream';

		nocache_headers();
		header( 'Content-Type: ' . $type );
		header( 'Content-Length: ' . (string) filesize( $path ) );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Accept-Ranges: none' );
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/**
	 * The signalling table.
	 *
	 * @return string
	 */
	public function signal_table() {
		global $wpdb;
		return $wpdb->prefix . 'cloak_radio_signal';
	}

	/**
	 * Who else is on a thread, as actors.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        The caller, excluded from the answer.
	 * @return array
	 */
	public function peers( $thread_id, $me ) {
		global $wpdb;
		$rows = $wpdb->get_results(
			call_user_func_array(
				array( $wpdb, 'prepare' ),
				array(
					'SELECT actor_kind, actor_id, actor_name FROM ' . $this->members_table() . ' WHERE thread_id = %d',
					(int) $thread_id,
				)
			),
			ARRAY_A
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			if ( (string) $row['actor_kind'] === (string) $me['kind'] && (int) $row['actor_id'] === (int) $me['id'] ) {
				continue;
			}
			$out[] = array(
				'kind'   => (string) $row['actor_kind'],
				'id'     => (int) $row['actor_id'],
				'name'   => (string) $row['actor_name'],
				// The face on the "who is talking" card. An agent may have
				// uploaded one; the office has none and falls back to their
				// initials, which is the same card with a different mark.
				'avatar' => 'agent' === (string) $row['actor_kind']
					? cloaklink()->agents->avatar_url( (int) $row['actor_id'] )
					: '',
			);
		}
		return $out;
	}

	/**
	 * Leave a signal for somebody on a thread.
	 *
	 * A signal is a few hundred bytes of SDP or one ICE candidate, meant for
	 * exactly one reader and useful for a few seconds. It is checked for
	 * membership both ways, and a caller can only address somebody who is
	 * actually on the same line.
	 *
	 * @param array  $me        Sender.
	 * @param int    $thread_id Thread.
	 * @param string $kind      'offer' | 'answer' | 'ice' | 'bye'.
	 * @param string $payload   JSON string.
	 * @param string $to_kind   Recipient kind, or '' for everybody else.
	 * @param int    $to_id     Recipient id, or 0.
	 * @return bool|WP_Error
	 */
	public function signal_put( $me, $thread_id, $kind, $payload, $to_kind = '', $to_id = 0 ) {
		global $wpdb;

		if ( ! $this->is_member( $thread_id, $me ) ) {
			return new WP_Error( 'not_member', __( 'You are not on that line.', 'cloaklink' ) );
		}
		$kind = sanitize_key( $kind );
		if ( ! in_array( $kind, array( 'offer', 'answer', 'ice', 'bye' ), true ) ) {
			return new WP_Error( 'bad_kind', __( 'That is not a radio signal.', 'cloaklink' ) );
		}

		// A payload longer than this is not SDP; it is somebody stuffing the
		// table. 64 KB is several times a full offer.
		$payload = (string) $payload;
		if ( strlen( $payload ) > 65536 ) {
			return new WP_Error( 'too_big', __( 'That signal is too large.', 'cloaklink' ) );
		}

		$to_kind = sanitize_key( (string) $to_kind );
		$to_kind = in_array( $to_kind, array( 'user', 'agent' ), true ) ? $to_kind : '';
		$to_id   = absint( $to_id );

		if ( '' !== $to_kind && $to_id ) {
			$ok = false;
			foreach ( $this->peers( $thread_id, $me ) as $peer ) {
				if ( $peer['kind'] === $to_kind && (int) $peer['id'] === $to_id ) {
					$ok = true;
					break;
				}
			}
			if ( ! $ok ) {
				return new WP_Error( 'nobody', __( 'That person is not on this line.', 'cloaklink' ) );
			}
		}

		$now = current_time( 'mysql', true );
		$wpdb->insert(
			$this->signal_table(),
			array(
				'thread_id'  => (int) $thread_id,
				'from_kind'  => (string) $me['kind'],
				'from_id'    => (int) $me['id'],
				'to_kind'    => $to_kind,
				'to_id'      => $to_id,
				'sig_kind'   => $kind,
				'payload'    => $payload,
				'created_at' => $now,
			)
		);

		// Anything over two minutes old was addressed to a browser that has
		// since gone. Sweeping on write keeps the table at the size of one
		// conversation without a cron.
		$wpdb->query(
			call_user_func_array(
				array( $wpdb, 'prepare' ),
				array(
					'DELETE FROM ' . $this->signal_table() . " WHERE created_at < %s",
					gmdate( 'Y-m-d H:i:s', time() - ( self::signal_retention() * 3600 ) ),
				)
			)
		);

		return true;
	}

	/**
	 * Everything waiting for this caller, newest last.
	 *
	 * @param array $me        Caller.
	 * @param int   $thread_id Thread.
	 * @param int   $after     Only signals newer than this id.
	 * @return array
	 */
	public function signal_get( $me, $thread_id, $after = 0 ) {
		global $wpdb;

		// A thread of 0 means "every line I am on". The radio is always
		// listening, not only while the dock is open on one conversation, so
		// the browser asks once for everything addressed to it rather than
		// once per line — a desk with six agents would otherwise poll six
		// times a second to hear one of them.
		$thread_id = (int) $thread_id;
		if ( $thread_id > 0 && ! $this->is_member( $thread_id, $me ) ) {
			return array();
		}

		if ( $thread_id > 0 ) {
			$rows = $wpdb->get_results(
				call_user_func_array(
					array( $wpdb, 'prepare' ),
					array(
						'SELECT * FROM ' . $this->signal_table() . "
						WHERE thread_id = %d AND id > %d
						  AND NOT ( from_kind = %s AND from_id = %d )
						  AND ( ( to_kind = %s AND to_id = %d ) OR ( to_kind = '' AND to_id = 0 ) )
						ORDER BY id ASC LIMIT 60",
						$thread_id,
						(int) $after,
						(string) $me['kind'],
						(int) $me['id'],
						(string) $me['kind'],
						(int) $me['id'],
					)
				),
				ARRAY_A
			);
		} else {
			// Every line this person is on, in one answer. The radio listens
			// on the whole desk rather than on the conversation on screen: a
			// press from somebody whose dock has not been opened is exactly
			// the call that must not be missed.
			$mtable = $this->members_table();
			$sql    = 'SELECT s.* FROM ' . $this->signal_table() . ' s'
				. ' INNER JOIN ' . $mtable . ' mb ON mb.thread_id = s.thread_id'
				. ' WHERE mb.actor_kind = %s AND mb.actor_id = %d'
				. ' AND s.id > %d'
				. ' AND NOT ( s.from_kind = %s AND s.from_id = %d )'
				. " AND ( ( s.to_kind = %s AND s.to_id = %d ) OR ( s.to_kind = '' AND s.to_id = 0 ) )"
				. ' ORDER BY s.id ASC LIMIT 60';
			$rows   = $wpdb->get_results(
				call_user_func_array(
					array( $wpdb, 'prepare' ),
					array(
						$sql,
						(string) $me['kind'],
						(int) $me['id'],
						(int) $after,
						(string) $me['kind'],
						(int) $me['id'],
						(string) $me['kind'],
						(int) $me['id'],
					)
				),
				ARRAY_A
			);
		}

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'id'     => (int) $row['id'],
				'thread' => (int) $row['thread_id'],
				'kind'   => (string) $row['sig_kind'],
				'from'   => array(
					'kind' => (string) $row['from_kind'],
					'id'   => (int) $row['from_id'],
				),
				'data'   => (string) $row['payload'],
			);
		}
		return $out;
	}

	/**
	 * The endpoint.
	 *
	 * @return void Never returns.
	 */
	public function ajax() {
		$me = $this->caller();
		if ( ! $me ) {
			wp_send_json_error( array( 'message' => 'signed_out' ), 403 );
		}
		if ( ! $this->enabled() ) {
			wp_send_json_error( array( 'message' => 'off' ), 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification
		// Read from the request, not the body: a voice note is fetched by an
		// <audio> element, which can only make a GET.
		$what = isset( $_REQUEST['what'] ) ? sanitize_key( wp_unslash( $_REQUEST['what'] ) ) : 'feed'; // phpcs:ignore WordPress.Security.NonceVerification
		$tid  = isset( $_POST['thread'] ) ? absint( $_POST['thread'] ) : 0;
		// phpcs:enable WordPress.Security.NonceVerification

		if ( 'clip' === $what ) {
			$this->stream_clip();
			return;
		}

		switch ( $what ) {
			case 'mutes':
				// The people this desk does not want to hear, saved from the
				// same button that mutes them on a speaker card.
				//
				// Stored where the settings page already reads it, so the two
				// doors cannot disagree: the field on Settings and the mute
				// button on the card are one list. Only agents can be named —
				// the office has no account row — and anything that is not a
				// number is dropped rather than refused, because a radio must
				// not stop working over a preference.
				if ( 'agent' !== (string) $me['kind'] ) {
					wp_send_json_error( array( 'message' => 'not_an_agent' ), 403 );
				}
				// phpcs:ignore WordPress.Security.NonceVerification
				$raw = isset( $_POST['ids'] ) ? (string) wp_unslash( $_POST['ids'] ) : '';
				$ids = array();
				foreach ( preg_split( '/[^0-9]+/', $raw ) as $one ) {
					$one = (int) $one;
					if ( $one > 0 ) {
						$ids[] = $one;
					}
				}
				$ids = array_values( array_unique( $ids ) );

				$prefs                      = cloaklink()->adv->prefs( (int) $me['id'] );
				$prefs['radio_mute_list']   = implode( ',', $ids );
				cloaklink()->adv->save_prefs( (int) $me['id'], $prefs );

				wp_send_json_success( array( 'muted' => $ids ) );
				return;

			case 'signal':
			case 'signal_get':
				// Live push-to-talk. The audio never passes through WordPress:
				// these two calls only carry the handshake that lets two
				// browsers find each other, and then the sound is peer to peer.
				// phpcs:disable WordPress.Security.NonceVerification
				$sig_tid  = isset( $_POST['thread'] ) ? absint( $_POST['thread'] ) : 0;
				$sig_after = isset( $_POST['after'] ) ? absint( $_POST['after'] ) : 0;
				$sig_kind = isset( $_POST['sig'] ) ? sanitize_key( wp_unslash( $_POST['sig'] ) ) : '';
				$sig_data = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$sig_tk   = isset( $_POST['to_kind'] ) ? sanitize_key( wp_unslash( $_POST['to_kind'] ) ) : '';
				$sig_ti   = isset( $_POST['to_id'] ) ? absint( $_POST['to_id'] ) : 0;
				// phpcs:enable WordPress.Security.NonceVerification

				if ( 'signal' === $what ) {
					$put = $this->signal_put( $me, $sig_tid, $sig_kind, $sig_data, $sig_tk, $sig_ti );
					if ( is_wp_error( $put ) ) {
						wp_send_json_error( array( 'message' => $put->get_error_message() ), 400 );
					}
					wp_send_json_success( array( 'ok' => 1 ) );
				}
				wp_send_json_success( array( 'signals' => $this->signal_get( $me, $sig_tid, $sig_after ) ) );
				return;

			case 'thread':
				$since = isset( $_POST['since'] ) ? sanitize_text_field( wp_unslash( $_POST['since'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
				$this->mark_seen( $tid, $me );
				wp_send_json_success(
					array(
						'thread'   => $this->view_thread( $tid, $me ),
						'messages' => $this->messages( $tid, $me, $since ),
					)
				);
				return;

			case 'send':
				// Stored notes are closed.
				//
				// The radio is a walkie-talkie: hold the key, speak, let go,
				// and the sound is gone. A message that is written or
				// recorded and kept is a different product, and having both
				// in one dock made the live key look like the odd one out.
				// Nothing new is accepted here; anything already stored is
				// still readable through the feed below, so this closes the
				// door without destroying what is behind it.
				wp_send_json_error( array( 'message' => 'voice_only' ), 400 );
				return;
				// phpcs:disable WordPress.Security.NonceVerification
				$body = isset( $_POST['body'] ) ? wp_unslash( $_POST['body'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
				$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : 'text'; // phpcs:ignore WordPress.Security.NonceVerification
				$secs = isset( $_POST['secs'] ) ? absint( $_POST['secs'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
				$clip = '';
				if ( ! empty( $_FILES['clip'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
					$clip = $this->save_clip( $_FILES['clip'] ); // phpcs:ignore WordPress.Security.NonceVerification
					if ( is_wp_error( $clip ) ) {
						wp_send_json_error( array( 'message' => $clip->get_error_message() ), 400 );
					}
				}
				$id = $this->send( $tid, $me, $body, $kind, $clip, $secs );
				if ( is_wp_error( $id ) ) {
					wp_send_json_error( array( 'message' => $id->get_error_message() ), 400 );
				}
				wp_send_json_success(
					array(
						'messages' => $this->messages( $tid, $me, '' ),
						'thread'   => $this->view_thread( $tid, $me ),
					)
				);
				return;

			case 'open':
				// Open (or find) the line to somebody. An agent may only open
				// the one to the office; an operator may open any.
				$kind = isset( $_POST['who_kind'] ) ? sanitize_key( wp_unslash( $_POST['who_kind'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
				$who  = isset( $_POST['who_id'] ) ? absint( $_POST['who_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
				$thread = $this->open_line( $me, $kind, $who );
				if ( is_wp_error( $thread ) ) {
					wp_send_json_error( array( 'message' => $thread->get_error_message() ), 403 );
				}
				wp_send_json_success(
					array(
						'thread'   => $this->view_thread( $thread, $me ),
						'messages' => $this->messages( $thread, $me, '' ),
						// The floating key opens a line from any page, where the
						// dock may never have fetched a feed: it needs to know
						// who it is and which console this is before it can
						// build a peer connection.
						'me'       => $me,
						'isOffice' => self::is_office( $me ),
					)
				);
				return;

			case 'seen':
				$this->mark_seen( $tid, $me );
				wp_send_json_success( array( 'unread' => $this->unread_total( $me ) ) );
				return;

			case 'group_create':
			case 'group_update':
			case 'group_delete':
			case 'tone_set':
				if ( ! self::is_office( $me ) ) {
					wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
				}
				$this->admin_action( $what, $me );
				return;

			case 'feed':
			default:
				wp_send_json_success( $this->feed( $me ) );
				return;
		}
	}

	/**
	 * Everything the radio panel needs in one answer.
	 *
	 * @param array $me Actor.
	 * @return array
	 */
	public function feed( $me ) {
		// An agent has exactly one line worth having — the one to the office —
		// and making them press something to create it is a step that only
		// exists because of how threads are stored. It is opened here instead,
		// so the desk loads with a live radio rather than an empty one.
		if ( ! self::is_office( $me ) ) {
			$office = $this->office_actor();
			if ( $office ) {
				$this->ensure_direct( $me, $office );
			}
		}

		$threads = $this->threads_for( $me, self::is_office( $me ) );

		// Which lines are live push-to-talk, and who is on the other end of
		// each. The browser listens on all of them, not only on the one the
		// dock happens to be showing: somebody pressing the key while this end
		// is reading a ticket must still be heard. Sending the peers here
		// means that is possible before any line has been opened.
		$live_on = (bool) $this->settings->get( 'radio_live', 1 );
		$live    = array();
		foreach ( $threads as $i => $t ) {
			if ( 'direct' !== (string) $t['kind'] ) {
				continue;
			}
			$threads[ $i ]['live']  = $live_on;
			$threads[ $i ]['peers'] = $live_on ? $this->peers( (int) $t['id'], $me ) : array();
			$live[] = array(
				'id'    => (int) $t['id'],
				'name'  => (string) $t['name'],
				'tone'  => (string) $t['tone'],
				'peers' => $threads[ $i ]['peers'],
			);
		}

		$out     = array(
			'threads' => $threads,
			'live'    => $live,
			'unread'  => $this->unread_total( $me ),
			'tone'    => self::tone( $this->default_tone() ),
			'isOffice' => self::is_office( $me ),
			'roster'  => self::is_office( $me ) ? $this->roster() : array(),
			'groups'  => array(),
			// Who I am, and what this radio can do. The live channel needs
			// both ends to agree on which of them offers first, which is
			// settled by comparing these two values.
			'me'      => array( 'kind' => (string) $me['kind'], 'id' => (int) $me['id'], 'name' => (string) $me['name'] ),
		);
		foreach ( $threads as $t ) {
			if ( 'group' === $t['kind'] ) {
				$out['groups'][] = array(
					'id'      => (int) $t['id'],
					'name'    => (string) $t['name'],
					'tone'    => (string) $t['tone'],
					'members' => $this->members( (int) $t['id'] ),
				);
			}
		}
		return $out;
	}

	/**
	 * A thread, with the facts a header needs.
	 *
	 * @param int   $thread_id Thread id.
	 * @param array $me        Actor.
	 * @return array|null
	 */
	public function view_thread( $thread_id, $me ) {
		$thread = $this->get_thread( $thread_id );
		if ( ! $thread || ! $this->is_member( $thread_id, $me ) ) {
			return null;
		}
		$info            = $this->describe( $thread, $me );
		$info['members'] = $this->members( $thread_id );
		$info['tone']    = 'group' === $thread['kind'] ? (string) $thread['tone'] : '';

		// A direct line is live push-to-talk. A group is a written noticeboard:
		// a room of five people all transmitting at once is noise, not a radio,
		// so groups keep the note they already had.
		$info['live']  = ( 'direct' === (string) $thread['kind'] && (bool) $this->settings->get( 'radio_live', 1 ) );
		$info['peers'] = $info['live'] ? $this->peers( $thread_id, $me ) : array();

		// The browser needs its own key before it can build a connection: the
		// two ends decide between them which one backs off when both offer at
		// once, and they can only reach opposite answers if both know who they
		// are. The feed carries it, but a line can be opened from the floating
		// key on a page that has not loaded a feed yet, so it is repeated here.
		$info['me'] = array( 'kind' => (string) $me['kind'], 'id' => (int) $me['id'] );

		return $info;
	}

	/**
	 * Open the line between the caller and somebody else.
	 *
	 * @param array  $me   Actor.
	 * @param string $kind 'user' or 'agent'.
	 * @param int    $id   Account id.
	 * @return int|WP_Error
	 */
	public function open_line( $me, $kind, $id ) {
		// The guard has to run before the kind is normalised: an empty kind
		// would otherwise become "agent" and fall through to "that person is
		// not on the desk".
		$want = (string) $kind;
		$kind = 'user' === $kind ? 'user' : 'agent';
		$id   = (int) $id;

		// No target at all means "my own line". An agent has exactly one — the
		// office — and with the dock shut they never chose a line to open, so
		// the server answers the only sensible one instead of an error.
		if ( '' === $want && ! $id ) {
			if ( ! self::is_office( $me ) ) {
				$office = $this->office_actor();
				if ( ! $office ) {
					return new WP_Error( 'nobody', __( 'The office has no account to radio.', 'cloaklink' ) );
				}
				return $this->ensure_direct( $me, $office );
			}
			// An operator with no target: the line they used last, and if they
			// have never opened one, the first desk that is actually staffed.
			// The floating key works from any page, so there is nowhere for a
			// "pick a line" prompt to appear — the server picks for them.
			$threads = $this->threads_for( $me, true );
			foreach ( $threads as $t ) {
				if ( 'direct' === (string) $t['kind'] ) {
					return (int) $t['id'];
				}
			}

			$live = null;
			$any  = null;
			foreach ( $this->roster() as $one ) {
				if ( null === $any ) {
					$any = $one;
				}
				if ( ! empty( $one['live'] ) ) {
					$live = $one;
					break;
				}
			}
			$pick = $live ? $live : $any;
			if ( ! $pick ) {
				return new WP_Error( 'nobody', __( 'No agent has been added to the desk yet.', 'cloaklink' ) );
			}
			return $this->ensure_direct( $me, self::actor( 'agent', (int) $pick['id'], (string) $pick['name'] ) );
		}

		if ( self::is_office( $me ) ) {
			if ( 'agent' === $kind ) {
				$agent = cloaklink()->agents->get( $id );
				if ( ! $agent ) {
					return new WP_Error( 'nobody', __( 'That person is not on the desk.', 'cloaklink' ) );
				}
				return $this->ensure_direct( $me, self::actor( 'agent', $id, (string) $agent['name'] ) );
			}
			return new WP_Error( 'nobody', __( 'That is not a desk account.', 'cloaklink' ) );
		}

		// An agent reaches the office and nobody else. The rule is deliberate:
		// two agents who can whisper privately can also agree to bury a ticket
		// without the operator ever seeing it.
		$office = $this->office_actor();
		if ( ! $office ) {
			return new WP_Error( 'nobody', __( 'The office has no account to radio.', 'cloaklink' ) );
		}
		return $this->ensure_direct( $me, $office );
	}

	/**
	 * The group and tone actions, for the operator only.
	 *
	 * @param string $what Action.
	 * @param array  $me   Actor.
	 * @return void Never returns.
	 */
	private function admin_action( $what, $me ) {
		// phpcs:disable WordPress.Security.NonceVerification
		$tid = isset( $_POST['thread'] ) ? absint( $_POST['thread'] ) : 0;
		$ids = isset( $_POST['agents'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['agents'] ) ) : array();
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$tone = isset( $_POST['tone'] ) ? sanitize_key( wp_unslash( $_POST['tone'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification

		if ( 'group_create' === $what ) {
			$made = $this->create_group( $me, $name, $ids, $tone );
			if ( is_wp_error( $made ) ) {
				wp_send_json_error( array( 'message' => $made->get_error_message() ), 400 );
			}
			wp_send_json_success( $this->feed( $me ) );
		}

		if ( 'group_update' === $what ) {
			$this->update_group( $tid, $me, $name, $tone );
			if ( isset( $_POST['agents'] ) ) {
				$this->set_group_members( $tid, $me, $ids );
			}
			wp_send_json_success( $this->feed( $me ) );
		}

		if ( 'group_delete' === $what ) {
			$this->delete_group( $tid, $me );
			wp_send_json_success( $this->feed( $me ) );
		}

		if ( 'tone_set' === $what ) {
			// One person's tone, or the desk's default when no agent is named.
			$agent_id = isset( $_POST['agent'] ) ? absint( $_POST['agent'] ) : 0;
			$all      = self::tones();
			$tone     = isset( $all[ $tone ] ) ? $tone : '';
			if ( $agent_id ) {
				cloaklink()->agents->set_radio_tone( $agent_id, $tone );
			} else {
				$this->settings->set_values( array( 'radio_tone' => '' !== $tone ? $tone : 'chirp' ) );
			}
			wp_send_json_success( $this->feed( $me ) );
		}

		wp_send_json_error( array( 'message' => 'unknown' ), 400 );
	}

	/**
	 * The desk's roster: everybody an operator can radio.
	 *
	 * @return array
	 */
	public function roster() {
		$out = array();
		foreach ( cloaklink()->agents->all() as $agent ) {
			$tone = $this->tone_for( (int) $agent['id'], isset( $agent['radio_tone'] ) ? (string) $agent['radio_tone'] : '' );
			$out[] = array(
				'id'     => (int) $agent['id'],
				'name'   => (string) $agent['name'],
				'role'   => (string) $agent['role'],
				'status' => (string) $agent['status'],
				'live'   => false,
				'tone'   => $tone,
			);
		}

		// Presence, so the roster can say who is at a desk right now.
		$presence = cloaklink()->agent_log->presence();
		foreach ( $out as $i => $one ) {
			$out[ $i ]['live'] = ! empty( $presence[ $one['id'] ]['live'] );
		}

		return $out;
	}
}
