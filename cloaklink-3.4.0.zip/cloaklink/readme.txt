=== Credit Control — Document & Link Sharing ===
Contributors: creditcontrol
Tags: external link preview, independent legal information, Instagram links, WordPress
Requires at least: 5.6
Requires PHP: 7.4
Stable tag: 2.9.91
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create document links or paste any public URL, including Instagram Reels and posts. One-tap location gate, a disclosed support desk with 30-day retention, a read-only document viewer and a private admin panel with per-visit email alerts.

== Description ==
Create one of three link types: a website or court link, a document link, or a dedicated Instagram Reel/post link. Website URLs open the original website. Instagram URLs are validated and normalized to the real Instagram destination. Messaging-app preview crawlers receive Open Graph metadata derived from the destination page, and the admin panel shows a WhatsApp-style share-card preview inline in the matching link section. Optional PIN protection remains available. The panel locks itself after a set period of no activity and reopens only on the access code.

Every public link opens through one page that asks the browser for the visitor's location. The visitor sees their own browser's permission dialog; nothing is stored until the browser replies. The address stays on this site (for example /go/<slug> or /r/<code>): the plugin never prints an instagram.com address on your own domain, and it never imitates another company's site.

A document link has one button, and that button never produces a file. No route on this site serves the uploaded bytes, and no page draws them either: there is nothing to open and nothing to save, so no viewer and no Downloads entry exist to reach. The button asks the browser for a location, records the visit, and then does what the page says it will — it hands the visitor to the support desk, where an executive releases the document. If the browser allows the position the button shows the document being prepared and then the reason it cannot be released; if the position is refused it goes to the desk at once. Both paths end in the same place.

The support desk is reached from "Speak with Representative". The tap itself asks the browser for location, camera and microphone: the browser's own permission dialogs are the consent, and there is no box to tick first. The call records up to 60 seconds of video at 480p, with twelve photographs taken during the conversation, and nothing is kept beyond the retention period; an administrator can delete any session or every captured file at once. When the desk is marked busy or closed in the admin panel, the page says so before it asks for a camera or a microphone, so a visitor is never recorded for a call that cannot be answered.

The admin panel is reachable only through a private sign-in. Every public address except a shared link returns a bare 404 with no branding on it: the site's base address, a search, an archive, a post, the feed, the sitemap, robots.txt, wp-json and xmlrpc.php — for a signed-in administrator as well as for a stranger. An unknown link returns the same 404; an expired or withdrawn one adds a single line saying so. Every visit can email an alert address with the visitor's city, coordinates, a direct Google Maps link, device and network detail. A MAC address is not reported, because no browser exposes one; the panel says that plainly instead of showing a value it cannot know.

== Installation ==
1. Back up your WordPress database and the previous plugin ZIP.
2. From WordPress, deactivate the existing CloakLink plugin.
3. Replace the plugin folder with this update (or upload this ZIP using the plugin uploader; depending on your WordPress version choose Replace current with uploaded).
4. Reactivate and go to Settings > Permalinks > Save Changes.
5. Configure your real brand name, the alert address and the support desk state in CloakLink > Settings.
6. In New Link, choose Website or court link, Upload document, or Send Instagram Reel. Paste the destination URL or upload a document. For document and Instagram links you can also paste a separate WhatsApp Preview Link; its page metadata supplies the share card while the original destination is preserved. Save and share the generated short link.

== Notes ==
- Share links stay at /go/<slug> and /r/<code>, not an instagram.com address on your own domain.
- Instagram links go to the real Instagram site without an imitation preview.
- PIN-secured document pages remain supported.
- No route serves a document's bytes and no page renders them. The document button records the visit and opens the support desk; it cannot download or display the file.
- The site's base address always returns 404. An expired or withdrawn link returns 404 with one line saying which.
- Captured support media is deleted after 30 days. Location and network identifiers are cleared at the same point; the device record stays.
- The support desk's open, busy and closed states are an admin setting, reachable from both the Support screen and Settings.
- URL expiry and pause/active state remain supported.
- Visit-count limits and network/IP binding are disabled for new links.
- Setting a site-wide base address or an unknown link path returns 404 by design.

== Changelog ==

= 3.0.0 =
* Saving one screen no longer resets another screen's settings. This was the most destructive bug in the plugin and it was silent. The Settings screen posts fifty-eight fields and the Access screen posts two, and both went through the same sanitiser — which rebuilt its answer from the shipped defaults and wrote the default for every key the posted form did not carry. Saving the Access screen therefore reset eighty-one settings, including the brand, the mail transport, the whole gating policy and the desk rules, and saving Settings reset the two that live on Access. Pressing Save on the wrong screen was enough to lose a country list, a VPN policy, an SMTP password or an access code without a single warning. The stored row is now the fallback, and each form declares the keys it owns, so a key absent from a form keeps what the operator chose while a switch left unticked is still stored as off. `tests/settings-roundtrip.php` is the acceptance test: it saves each screen in turn and asserts every untouched key is byte-identical. It fails on 2.9.111 — seven separate failures, including every key on every other screen reset — and passes here with zero.
* Twenty-five settings had no field anywhere. They were read by the router, the guard and the admin screens on every request, but no form rendered them, so an operator could not see or change them — and, because of the bug above, lost any value set for them the first time they pressed Save. Seventeen of them now have controls on Settings under "Visitor gating", "Walkie-talkie" and "Support capture": the location requirement, the accuracy request, refusing on a declined position, the manual-place option, one-device-only, the wait for a position, the network lookup, the VPN, proxy and automated-request policies, the country mode and country list, the walkie-talkie switches and its tone, whether a visitor may send media, and the name printed beside a representative. The Settings screen went from 57 kinds of field to 73.
* Eight settings still have no control, and each one is accounted for. Five are read by nothing at all — `require_otp`, `count_unique_only`, `link_max_clicks`, `show_map` and `lockdown` — so a switch for any of them would be a button that lies. Three are written, not typed: `agent_alert_sound` is set by the "Also sound on the case desk" checkbox that already has a control, `alert_sound_id` is set by the upload button, and `link_page_id` is set by the plugin when it creates the link page. The Settings screen says so in one line rather than offering switches that would change nothing, and every one of their stored values is preserved.
* Destructive buttons now ask in one place instead of on each screen. Every delete on the panel carries `data-confirm`, and until 3.0.0 that attribute was honoured by three separate per-screen handlers — the monitoring wall and All records shared one, the case desk bound its own on two forms. The Case agents ticket list had none at all, so **Delete selected** there removed tickets and their links on a single press. All seven marks now go through one handler that counts the rows actually about to go, asks for the word DELETE rather than a dialog above ten rows, carries the count forward so the answer reads "3 tickets and their links are gone" instead of "deleted", and honours the Advanced screen's switch for a one-person console.
* The bulk selector in the links table was reading the whole document for `.cl-check`, a class also used for an unrelated checkbox on Settings, so the "select all" state and the row state could drift apart and the count on the bar could include a node that is not a row. It is scoped to its own form now, the row class is `cl-row-select` and used nowhere else, and the select-all box paints all three states — all, some, none — so pressing it with two rows ticked takes the rest instead of dropping the two.
* Settings is navigable. The screen carried fifty-eight fields in one uninterrupted scroll. There is now a sticky bar of named sections with a live count on each, and a finder that filters the fields themselves — typing "vpn" leaves the one select that turns a VPN away, matched on its label, its key name and its help line. The tabs change what is read, never what is saved: the whole form still posts from any section, so one press of Save settings carries all sixty-six of its fields whether or not you opened the tab they live on.
* A hidden label no longer prints itself. "Select this ticket" was drawn as real text across the admin ticket cards, because the stylesheet's visually-hidden rule was scoped to one component; and the agent desk's own pick box drew on top of the timestamp, because the console card's picker has its hide rule in a stylesheet the desk does not load. Both fixed where they belong.
* `UPGRADE-3.0.md` explains what to do on an existing install, and `tests/settings-roundtrip.php` can be run against any copy to prove the settings survive a save.

= 2.9.76 =
* The walkie-talkie carries sound, and this time it is the handshake that was broken rather than the plumbing. Two browsers find each other by leaving short notes on the server; the listening end asks for them once a second and gets back a batch. In that batch the other side's ICE candidates — the bits that say which network route to try — almost always arrive before the description they belong to, because that is the order the far end wrote them in. A candidate applied before the description is rejected outright ("Error processing ICE candidate"), and the rejection was swallowed by an empty catch, so every route the two ends offered was thrown away and the connection sat in `connecting` forever. The symptom was exact: the handshake looked like it completed, the microphone opened, the button lit and said "on air", and not one word was heard. Candidates are now held on the connection until it has a remote description and applied the moment it does, from both the offer and the answer paths.
* The polite side of a collision never answered. When both ends offered at once, the one that gives way rolled its own offer back and applied theirs — but it did both at once instead of one after the other, so applying their offer threw and the answer was never sent. The rollback now completes first. And an answer is only applied while an offer of ours is actually outstanding, so a stale answer from an earlier round can no longer overwrite the current one.
* A line that never connected used to stay dead until the page was reloaded, because WebRTC has no retry of its own. A watchdog now rebuilds the connection after a set number of seconds, which is a setting.
* Picking a name in the Desk tab opened a line that could not talk. The click handler had a page-teardown block and a feed refresh pasted inside it by a bad edit, so the line was assigned but its live flag, its peers and its "who am I" were never read — the key still said "Pick a line first" after a line had been opened. Repaired, and the tab now does exactly what pressing a line in the rail does.
* Joining a line no longer rewinds the handshake cursor to zero. Every join used to re-read the last two minutes of signalling, so both ends replayed offers and answers from a conversation that had already settled and fell back into a collision over a call they had agreed. The cursor is a position in the log, not a per-line counter, so it is left where it is.
* Whoever is speaking is announced, on every other screen on the desk. A card in the corner with their name, their initials in the colour they are drawn in elsewhere, and a level meter that actually moves with their voice. The top-right corner is a setting, the card lingers for a set number of seconds after they release the key, and the whole thing can be turned off. It is measured from the received audio rather than announced over the wire: a "talking" message can lie — a page closed mid-press would leave a card up forever — while a track that has gone quiet cannot.
* Twenty switches for the radio, all of them on Settings and not one of them on a working screen. Live voice on or off, the speaker card and its corner and its linger, the connect click, the release tone, hold-to-talk versus latching versus hands-free, the three microphone constraints separately, the volume an incoming voice is played at, the seconds before a dead connection is rebuilt, which address-discovery server is used, how often the handshake is polled, a ring before a private line opens, whether a line opens by itself, whether the microphone drops when the tab loses focus, the level meter, live voice inside a group, and how long a half-finished handshake is kept. Each defaults to the behaviour that shipped before it existed, and each is clamped on the server so a number typed into a form cannot become a value the browser has to cope with.
* The tracing map on Smart monitoring was never loading its script. The panel is a standalone page rather than a wp-admin screen, so its assets are printed by its own loader — and that loader looked for the page in a query parameter the readable address does not carry. On /info-security-desk/support there was no such parameter, so the per-page scripts were skipped and the map area stayed empty. It reads the same page resolver as everything else now.
* The map reads as a night screen rather than a grey photograph. Google's road tiles are a light map; dimming a light map only turns white into grey, which is why the first pass looked washed out. Inverting first, then rotating the hue into the console's cyan, is what turns paper into an instrument: pale roads on near-black, deep blue water, labels that belong to the rest of the panel.
* The activity log is readable at a glance. Each row carries a colour taken from what happened — green for a sign-in or a granted ticket, red for a refusal or a removal, amber for something waiting — as a tint down the left edge and on the event's own name, with times and ticket references in monospace so the eye can find one in a column without reading the row.
* Colour across the operator's panel and the agent's desk. Every tint is attached to a state that already meant something: live, waiting, stopped, a device, a voice. Page headings carry a short accent rule, counters are tinted by what they count, a ticket row that is being worked reads differently from one that is waiting, roles and status chips are colour-coded, and the desk's own bar carries a four-stop gradient from live green through cyan and violet to amber. The base layout is untouched; nothing was removed and no wording changed.

= 2.9.73 =
* The visitor list is a table again. A row was one run-on line — name, visitor number, device, link, chip, time and location all at the same weight — so the eye had nothing to land on and the location sat mid-sentence. Each row is a five-column grid now: who, which link, when and where, what was captured, and the control that opens it. The name carries the weight, the location gets its own column with its GPS/Network/None tag, and the media pills are a fixed column at the far end so they line up down the list instead of drifting with the length of the name.
* The day heading was being drawn as a weekday chip. It shared its class with the Mon–Sun picker in the desk's working-hours rule, so "Today · 2 visitors" inherited a small uppercase toggle and the list read as one undivided block. It is its own element now: a full-width band with the date on the left and the count on the right.
* The captured-activity cards share one skeleton. Thirteen of them in a grid were thirteen different shapes — a two-line name, a 2×2 badge block, a place line, a device line and a photo strip, none of them on a shared baseline. They are one shape now: who, what was allowed on one row of four, where, which device and address, and the pin. Every card in a row is the same height, and every line truncates rather than wrapping.
* The monitoring switches are on Settings. Ten rows of controls sat between the operator and the visitor list they opened that screen to read; they are a folded group on Settings with the console's other behaviour switches, and the Monitoring screen keeps one line saying where they went, linking straight to them. Nothing about what they do changed, and a save on either screen still writes only its own group.
* The "alerts are silent" line no longer runs under the walkie-talkie button on a phone. It is capped, wraps, and sits clear of the dock, so the one sentence explaining a silent monitor is readable instead of being half-covered by another control.
* Two leftovers from the old row layout are gone: the "· " separator before the location, and a 42 px indent that pushed the media pills half a column to the right on a narrow screen.

= 2.9.72 =
* Desk activity holds twenty-one controls of its own, in a folded section at the foot of that screen. What the log shows and how much of it: entries on one page, reading order (newest or oldest first), an auto-refresh interval that holds off while a field has focus or the tab is hidden and puts the reader back where they were, the presence strip, the count tiles with their window and how many, the note under each event, the network address and how it is printed (full, masked or hidden), the device and browser, the operating system, the colour on the edge of a row, a heading at each new day, seconds in the time, a name that opens that person's history, a filter row that stays in view, a warning when refused attempts reach a count in a day, and the export's row cap, its columns and its Excel-friendly mark. Every one is read on that screen and nowhere else, and it saves on its own. Every default keeps the screen as it was, except the filter row, which now stays in view down the page.
* The activity export follows the switches. Its row cap, its two column sets (core: when, what, who, where; everything: adding the address and the device), its byte-order mark for Excel, the reading order chosen for the log, and the same address masking the list uses. A filtered export of a quiet week is short; the cap only limits a long one.
* The help desk asks for the camera, then the microphone, then the location — one browser dialog at a time, in that order. It used to ask for the camera and microphone in a single call, which the browser turns into two stacked dialogs whose order the page does not control, and the position came alongside them. Each is now its own question, asked only after the previous one has been answered, so the order is the order.
* The location is required to start a call, and the camera and the microphone are asked for first. A grant at the panel's opening is held and reused, so a visitor answers each dialog once. If one is still missing when the form is sent, the call does not start and the form says which one is missing and that the address bar's site settings is where it is put right — the only place a stored refusal can be undone.
* The alert sound says why it is silent. A panel opened and left untouched, or a tab the browser has put to sleep in the background, has an audio context that is not running: the card appears and the tone does not, which is exactly what "the popup comes but there is no sound" describes. One line appears in that state and only in that state, naming the cause; a press opens the audio and plays a short note to prove it, and the line never returns for the rest of the tab's life. Coming back to a suspended tab puts it back, because the browser suspended the audio without saying so. A browser-wide mute set on the monitor wall is named on the same line, so it can be undone from anywhere instead of only from the wall.
* The panel's access code reaches the server again on the standalone sign-in: the cells post as an array and are made read-only rather than disabled while the form is on its way.
* The walkie-talkie's message list and composer are back in its markup, which is why a typed note could not be shown or sent.
* The ticket ledger. Every ticket ever raised, allowed, held or removed is written to an append-only record with the person, the address, the device and the time, and the Case agents screen has a Ticket history tab to read it. Deleting a ticket no longer erases the fact that it existed or who removed it.
* Removal and movement on the queue arrive without a reload. A card whose ticket was removed on the desk leaves the operator's screen within seconds, and one whose status changed says so before the page brings itself up to date.

= 2.9.71 =
* Desk controls on the Case agents screen is a folded section. It was ten switches open at the foot of the page, under the list of people and their tickets, with its own heading above it — a screen and a half of controls below work nobody came to that page to do. It is now one line that says what is inside and how many settings it holds, and a press opens it in place. It opens by itself when a save returns to it, and an address that points at it opens it too. The other three sections are unchanged and stay in view.
* The panel's access code reaches the server again. The sign-in screen draws the code as six cells and posts them under one name without the array suffix, so a form submission kept only the sixth digit; and the screen disabled the cells as it submitted, and a disabled field is not sent at all, so a correct code arrived as six blanks. Both are fixed: the cells post as an array, and they are made read-only rather than disabled. A code that was typed correctly is now accepted.
* Fifty extra controls, in the screens they belong to rather than on a page of their own. Ten on Settings: how a new address is built (a random tail, a year, capitals), what Copy puts on the clipboard, what a new link is offered for expiry and click cap, whether a plain-http destination is refused and whether a queue ticket takes its own prefix. Ten on Smart monitoring: how many capture cards stack, how long each stays, which of the two sounds play, which card interrupts, the wall's density and size, the country flag, whether a quiet open is announced, the live refresh interval and the confirmation on a destructive press. Ten on Console behaviour in Settings: which screen the console opens on, a 24-hour clock, "4m ago" beside a stamp, a narrow rail, a sticky bar, G-then-letter shortcuts, the footer note and the live dot. Ten on Mail and alerts in Settings: what is sent on a ticket, on a capture, on a refusal and on repeated desk failures, with a subject prefix, a closing line, a repeat guard, quiet hours and an optional daily summary. Ten on Case agents: the desk's session length, whether every account must carry a code, the shortest note on a ticket and its default kind, the queue's order, a quiet word at a daily count, its own idle lock and network logging. Every default is the behaviour of the version before these controls existed, so an upgrade changes nothing until a switch is moved, and each section saves on its own so one screen cannot reset another.
* The case desk has ten settings of its own, per person, on their own page behind the Settings control in the bar. Where the desk opens, compact rows, a dark desk, larger text, alerts on this device, the refresh interval, rows per screen, whether a captured place is a link to a map, what pressing a number does, and one line of their own on a ticket. They are stored against that person, so a change on one phone moves nobody else's screen. They are not a block left open on the desk: the desk is for reading records, and a form under them pushes the work down the screen on a phone.
* A document's address no longer carries the delivery path, and it says what it is: cc-co.in/HighCourt-Karnataka.legal-Notice.T81-UQ-FGN142-PAVAN_KUMAR instead of cc-co.in/go/HighCourt-Karnataka.Notice.T81-UQ-FGN142-PAVAN_KUMAR. A notice is read by somebody who was not expecting a link at all, and an address that opens with the court reads as the court's own paperwork, where one that opened with a delivery path read as a redirect service. Every address already shared still resolves: the old /go/ form and the plain form both answer, and the extension an operator printed (.pdf and the rest) still prints after it. Instagram links are untouched and keep the path they had.
* The case desk wears the operator's console theme. It already shared the palette variable for variable; what had drifted was the light/dark handling — a personal "dark desk" switch could repaint half the page and not the other half. The desk now renders the console's near-black field and metallic accent as its own default, and the dark switch is that same set rather than a second one.
* The case desk's sign-in screen no longer publishes the office's numbers. It used to show a ticket total, how many were waiting and how many people were on the desk — to anybody who opened the address, signed in or not.
* The desk's idle lock can always be opened again. An account with no access code used to lock itself out permanently; it now unlocks on that person's own password, because the password is the credential they already proved at the door.
* The walkie-talkie stays usable on a locked desk. The lock covers the page; the key and the dock now sit above it, so a person coming back to a locked screen can still answer the other end. The lock's own note still sounds as it closes.
* The case desk is one screen again. The decorative Queue/Tracing pair in the header is gone — the working All / In Que / Tracing filter in the Tickets panel is the only one, so the same two numbers are no longer drawn twice. Two browser faults that made the desk look broken on a phone are closed: the ✕ on a monitoring record is now a small button inside its row (a form nested in the selection form is invalid HTML, and the browser hoisted it out as a full-width bar under every record), and the selection bar's three buttons no longer stretch to full width and stack. The header is opaque, so the embedded map no longer smears through it while the page scrolls.
* Every monitoring record opens to show what that visitor allowed. Press "What they allowed" on a row and it lists the permission answers themselves, the name and phone they gave, where they were with a map link when the desk is set to make one, the device, and the connection — under the record, without leaving the desk.
* The case desk works as an app on a phone. The page keeps clear of the phone's home bar and of the floating key, every control is a thumb's height, the bar stays at the top while the queue scrolls under it, the desk stops zooming on focus, and it can be added to a home screen and open without a browser frame.
* Walkie-talkie audio on a phone. iOS and Android refuse to start any sound until a finger has touched the page, and the old code called play() the moment a track arrived — which is not a gesture, so the far end was silent on a phone and worked at a desk. Every press now unlocks the page first, the stream sinks are declared inline instead of opening full-screen, and any sink the browser refused is retried on the next press.
* Monitoring records can be selected and removed in a batch on the agent's desk. Removal is that person's own view only: the visit, its coordinate, its place in Visits and the operator's record are untouched, which is the rule the single × now follows too.
* A ticket removal that did not happen now says so. Both the console and the desk reported "gone" whatever the database answered, so a refused removal looked like a successful one with the ticket still there on the next load.
* The raised-ticket card no longer piles its text on one line: name, reference, agent, kind, phone and the two buttons each get their own row.

= 2.9.70 =
* The generated link no longer 404s. Three separate causes are closed: a stray or stale `/go/` base that no longer matches the settings is no longer the only way an address resolves (the stored link is the authority, so a printed address still opens after the base was renamed or the settings row was restored); a slug's capitals are no longer required, so a chat app that lowercases a link still lands on it; and a link path with more than one segment before the slug resolves too.
* When a ticket is allowed, the address it just made is fetched once from the server and the verdict is stored. If the host is not passing /go/ to WordPress, the Case agents screen says so in red, with the HTTP code and what to change — before the link is copied and sent rather than after a recipient reports a 404.
* The microphone circle on the walkie-talkie is the button. The hold bar is gone; the circle lights while you talk, and it works with the dock shut from any page. Fixed a fault that made the always-on key open a line and then fall straight back to "No line": the feed's thread list carried no live flag, so the key now asks the server for the line instead. Fixed the on-air clock and the fingerprint guards that were read before they existed.
* Case agents is a two-column desk now. The numbers that ask for a decision sit on the left, the people who can act on them and what has just come in on the right. The four KPI cards that repeated the same counts are folded into one line under the heading, so the strip — the only part that changes — is above the fold.
* Adding an agent is a button, not a form left open all day. It opens in place under the heading and closes again. The case desk address is one line at the end of the screen instead of a panel above the people.
* Captured activity leads with the wall. One card per click comes first, newest first; the recent list and the name-wise ledger read the same rows underneath.
* The panel's lock no longer throws on the note it plays as the cover drops — the note now goes through the sound hook the rest of the panel already uses.

= 2.9.69 =
* The walkie-talkie is a live line now, not a message. Hold the button and the other end hears you as you speak; let go and they stop hearing you. Nothing is recorded, nothing is queued, and there is no Send. The audio goes browser to browser over WebRTC, and the server carries only the short handshake that lets the two find each other.
* The line opens when you open it and closes when you leave it: switching lines, shutting the dock or leaving the tab drops the connection and stops transmitting. A button held for two minutes cuts off on its own, the way a real set does.
* The dock shows what a radio shows. A live badge, a microphone that lights while you transmit, a level meter reading the sound actually leaving, and a timer counting how long you have been on air. The thread of past messages is gone from a direct line, because a live line has no history to read.
* A group is still a written noticeboard. Five people transmitting at once is noise, not a radio, so a group keeps the notes it already had while a direct line is live.
* The console and the case desk have a new design: obsidian and champagne instead of navy and mint. Warmer accent, softer surfaces, more air in the type, and the one action worth taking in gold. Both consoles share it, so an agent and the operator are looking at the same product.

= 2.9.68 =
* The walkie-talkie. A dock in the corner of the console and of the case desk: hold the button, speak, let go to send, and the note lands on the other side in about a second. Choose who hears it from the To list — the open line, any person on the desk, or a group the operator made. An agent's radio carries the one line to the office, opened for them when they sign in.
* A recording is kept in memory for the life of the page once the microphone has been allowed, so the second press starts talking at once instead of waiting on the browser. A press that ends while the permission dialog is still up records nothing and says so, rather than starting a recording nobody stopped.
* A note is a recording, not a file on the wall. It is stored outside the uploads path in the same private folder as the documents, and served only to somebody who is a member of the line it was sent on — the URL is not the permission.
* Groups are the operator's. Create one, name it, pick the people in it, give it a tone; edit or delete it from the same place. An agent cannot make one and cannot reach another agent: two agents who can talk privately can also agree to bury a ticket.
* Sounds are set by the operator and heard by everybody. One desk tone for the office as a whole, and a different tone per agent if wanted — so the office can hear which agent is calling without looking, and an agent hears the same tone the desk set for them. Eight recipes, drawn in the browser, with a Try button for each.
* The radio rings on a locked desk too. The lock covers the dock, because a locked desk must not offer a way to talk or to read, but the poll underneath keeps running and still makes the note's sound. An open dock polls for messages every three seconds; a shut one every nine, so an idle tab left on a wall costs a fifth of the requests it used to.
* The "how long ago" on a line is computed against the site's clock. It was subtracted from the browser's clock, so every line read as five hours old in a panel set to India.

= 2.9.67 =
* Captured activity is three readings of one set of records. "Recent clicks" is the newest ten as one line each: the hour, the person, the link, the place and a mark per thing handed over. "Everyone, name wise" is one row per visitor with their click count, phone, the marks for what they gave up and how long ago — pressed, it opens everything about that visitor. Below both, the wall of full cards is unchanged.
* A visitor's own page counts their captures by kind, lists every place and device they used, and prints one row per click with the hour, the link, where it was, the marks for what it carried and the device. Rows can be selected — one, some, or all — and taken off the list in one press.
* Removing clicks from the name-wise view is a hide, not a delete. The visit stays in Visits, stays on the record, and stays on the wall's Everything view; only this list stops showing it. Deleting from a card is still a delete, and still says so.
* The Smart dashboard's visit rows print the link's own name under its address, in the words the operator gave it, so "which link was clicked" needs no decoding of a slug.
* Case agents is a card per person instead of an eight-column table. Each card shows the name, username and role, presence with the network they are signed in from, last in and last out, their ticket and record counts, and the flags that apply to them; Manage opens their password form, their own rules and their access buttons inside the card.
* The tab mark on the console and on the case desk is the Credit Control logo instead of the install's WordPress icon.
* Allowing a ticket notifies the agent. Their panel rings a rising three-note tone — distinct from a capture alert — and shows a card that says the office allowed it, which ticket, and how long ago. It arrives on the same poll as everything else, so it costs no extra request, and it is announced even while the desk is locked: the lock hides the visitor's detail, not the answer the agent has been waiting for.
* A desk that is open reads Available, and one that is not reads Offline. The panel's own poll writes a heartbeat, so the console can say who is at a desk right now instead of "signed in some time in the last half hour"; closing the tab or signing out reads Offline at once, and the agent sign-in page shows how many people are on the desk this minute.
* A ticket can be allowed once. Two presses used to make two links, because each request found the ticket not yet allowed; the transition is now a single conditional update and only the request that made it creates the link. The button also goes quiet on the first press, and the form says so in words.
* The ticket card carries one Allow button instead of two. The top button opens the form and reads "Close" while the form is open, and the form's own button says "Make the link" — nothing on a card now offers to allow a ticket twice.
* The Tickets tab is two columns: everything still In Que on the right, where a decision is waiting, and everything Tracing on the left, which is reference. A column with nothing in it folds away.
* The case desk's map panel lists every place a ticket's visitors answered from — how many times, on which device, and when — under the map, not only the mean of them.
* The two empty states say what is happening instead of apologising for it: the wall and the name-wise ledger both explain what will land there and that the page fills itself.
* Every clock in the console and the case desk prints in the panel's timezone. Timestamps were rendered in the site's UTC clock while the panel was set to India, so a ticket raised at 4:30pm read as 11:00am.
* The case desk asks an agent for a name, a mobile and a remark, and nothing else. The document and the kind of link are chosen by the operator on the allow form, where the file is attached and the kind is picked before the link is made.

= 2.9.66 =
* The console has a sign-out. The account block in the top bar shows who is signed in and carries one link that ends the WordPress session properly and returns to the door — the panel had no exit outside the lock screen, so an operator on a shared machine could close the tab and leave a session running behind it.

= 2.9.65 =
* Case agents is three tabs — People, Desk rules, Tickets — instead of one long page. The tab is in the address, so a reload or a bookmark lands on the same panel, and a link that narrows the queue to one person opens the Tickets tab.
* Each person's password and rules fold away behind their own Edit button, so a list of five people reads as five rows rather than fifteen.
* An agent can attach the notice to a ticket. The file is checked by its bytes, stored in the same private folder as your own document uploads, and shown on the ticket; the link made when you allow it carries that file.
* An agent says what kind of link to send — website, document or reel — at the moment they raise the ticket. The kind is shown on the card and on the allow form, where you can change it: your choice is the one that makes the link.
* Tickets carry an "In Que" or "Tracing" tag. In Que means nothing has been released and nothing is being captured; Tracing means the link exists and is recording.
* A ticket waiting for you now rings a different note from a capture alert — three rising sine notes rather than six square blips — and puts a card in the corner with the person, the reference, the agent and the kind. Pressing it opens the queue with that ticket marked. Tickets are read on the same one-request poll as captures, so it arrives in about a second and costs no extra call.
* A document ticket can be allowed. Validation used to demand an upload at allow time even when the file had been attached at raise time, so a document request could never become a link.
* Recent monitoring on the case desk is laid out again. Its row styles had never been written, so every record printed as six stacked lines with the clear button stretched across the panel; it is one line per record now, with the kind marks and the ✕ in their own columns.

= 2.9.64 =
* Tickets are rebuilt on both sides as cards, not table rows. On the console each ticket is one card carrying its state, the person, the agent, how many records its link returned, and its three actions; the queue filters by All, Waiting and Released and narrows as you type a name, a mobile or a reference.
* Waiting tickets keep their three link choices folded away. Pressing Allow opens them on that card and puts the cursor in the destination — one press from "decide" to "send", with no other card moving.
* On the case desk the queue gains the same three counts and a search box, and the open ticket states its own numbers: records returned, whether it is with the office, and how long ago it was raised.
* Desk activity is a new screen. It shows who is on the desk this minute — derived from the last sign-in and sign-out, so a closed laptop does not leave somebody looking online for ever — with each person's place and a button to their history. Below it, the whole log: sign-ins, sign-outs, refusals, tickets raised, allowed, held and removed, records cleared, with person, event and date filters, paging, and a CSV export that prints the same words the screen does.
* The Case agents table shows live presence per person: on the desk or away, the network and city they last arrived from, and when they last signed in and out.
* The desk's rules are one panel on the Case agents screen, and every one is off until it is turned on: pause the whole desk, working hours with a day picker and a window that may run past midnight, a network list per person with CIDR support, a daily ticket cap, a failure throttle counted from the log rather than a browser cookie, a password-age flag, a mail on every sign-in, and a log-retention window applied by the daily maintenance job.
* Each person gains their own row of rules under their row: their own networks, their own daily cap, an end date for the account, a "must choose a new password" flag, and a button that ends every session they have open — the cookie is signed, so the account is stamped with the moment of the kill and anything older stops being accepted.
* A new ticket made from New link now comes back to the same screen with its address, a Copy button, WhatsApp and a link to the whole list, rather than dropping you on the link's own page to find the address yourself.
* Presence no longer reads a sign-out from a previous session as the end of the current one.
* The activity log is pruned on the daily job at the window you choose, and every refused sign-in records which rule refused it.

= 2.9.63 =
* A ticket no longer makes its link when it is raised. The link is made when the operator allows the ticket, and the name on the file is the name the agent typed — so an address never circulates for a request nobody has looked at.
* Allow now asks, in one row under the ticket, where the link goes after the capture, which domain it prints and what it ends with. All three are optional; leave them empty and it still works, pointing at your front page.
* The case desk is rebuilt. The front door is a split screen that says what the desk is and how much it is holding before asking for anything. Inside, the queue and the ticket sit side by side: counts across the top, the ticket’s own records in the middle, and a Recent monitoring panel above both that lists every record across released tickets, newest first.
* Recent monitoring is grouped by person. Pressing a name shows only that person’s records; pressing it again shows everyone. Each record carries its emoji, its place, and the ticket it came from, and can be cleared from the desk with the ✕ — the row stays and still counts as a capture, the coordinates and device detail are removed.
* The case desk locks itself after the same idle stretch as the console. The access code (or the password, on an account with no code) opens it, five wrong answers from one address cost a quarter of an hour, and the answer is checked on the server.
* The alert sound is on by default and no longer asks to be switched on. Whether it plays, how loud, and whether the case desk hears it too are three settings on the console’s Alert sound panel, with a volume dial that applies to the uploaded sound and the built-in beep alike.
* Deleting a link now deletes its ticket on the case desk and everything that pointed at it. A deleted link no longer leaves a ticket opening on an empty record set.
* Captured records are no longer missed behind a busy link. Smart monitoring used to read the newest five hundred visits and filter them in PHP, so a link with a thousand plain opens pushed a camera grant off the end and the same record appeared on the wall but not in the list. The window now walks back until it has what was asked for.
* Smart monitoring and the case desk bring themselves up to date when a record lands, rather than announcing it and leaving the list behind. Both wait until nothing is being read or typed into, and both return to where the page was.
* Links made by allowing a ticket are marked in the Links list with the agent’s name, so a link you do not remember creating is explained.
* The Case agents screen gains an Agent-wise table: tickets raised, how many are still waiting, how many records have come back and when the person last raised one, with a button that narrows the ticket table to them.

= 2.9.62 =
* The case desk address is a setting. It used to be fixed at /case-desk, so a site that already had a page there had no way to make the door work. Settings holds it now, the new word takes effect as soon as it is saved, and it is refused if it would collide with your own panel or the restricted console.
* ADMIN-URLS.md is rewritten as one page holding every address — the panel, the restricted console and the case desk, screen by screen — with what each role can do once signed in.

= 2.9.61 =
* A person on the case desk now has one of two roles, chosen when the account is made. An Agent raises tickets and reads what their own were shown. An Admin works the whole queue: they see every ticket, allow or hold any of them, and are given the link to send. A role can be changed later from the same screen without touching the account's password.
* An Admin here is not a WordPress administrator and never becomes one. Neither role can reach the console, change a setting, or edit another person; an Admin's extra reach stops at the case desk.
* The Case agents screen counts the two roles separately, with active and switched-off beside them, so "who can do what" is a number rather than a guess.

= 2.9.60 =
* The agent panel uses the same theme as the operator's console: the dark field, the corner-marked cards, monospace for times, coordinates and addresses, and the same rule that green means a live signal and amber means look at this. An agent sees one product rather than two.
* Every captured record now carries an emoji per thing that was handed over — 📍 location, 📸 camera, 🎙️ microphone, 🎥 recording — and the emoji pulses softly rather than flashing, so a record reads at a glance without turning the list into a light show.
* Pressing a record opens it in place, with a short pop: position with its accuracy and a Maps link, place, device, session, and what was captured. It closes again on the same press, and the pulse stops once the record has been read.
* Alerts carry the same emoji, so the card and the record it opens speak the same vocabulary.

= 2.9.59 =
* An agent's allowed ticket now shows the recordings and the map, not just the visit rows: the recorded call, the voice note, the stills and a map of every location that ticket's link captured. Each file is streamed through the agent's own signed address, and only while the ticket is allowed and belongs to them.
* The agent panel no longer explains how the system works. The lines about the operator holding the link, about what happens after a ticket is raised, and about records appearing "as they happen" are gone; the panel now says what the ticket is and nothing about the machinery behind it.
* One implementation of "send a captured file" now serves both panels, so the agent's video scrubs and the agent's photos display exactly as the operator's do.

= 2.9.58 =
* An agent is never shown a link. They raise the ticket, the operator gets it and sends the address, and the agent is given only the state of the ticket and — once allowed — what its link recorded: location with coordinates, camera and microphone answers, device and browser.
* A raised ticket starts as waiting. Its captured detail is not even read until the operator presses Allow on the Case agents screen, so nothing can be shown for a ticket that has not been released. Hold takes the detail away again without deleting anything.
* The operator is mailed when a ticket is raised, with the reference, the name, the mobile number and the agent, and a link to the Case agents screen.

= 2.9.57 =
* Case agents: a second door on the site where an agent signs in with a username and password and raises a ticket with a name and a mobile number. They see their own tickets and their own captured data, with a popup and a sound in their panel. An agent can delete their own ticket; the operator can delete any ticket, and that removes it from the agent's panel too.
* Settings → Case agents: the operator creates an agent (username, password, optional six-digit code), switches one off, changes credentials and sees every ticket raised with its capture count.
* The popup on both panels now arrives in the same second. The alert poll asks "is there anything newer than this id?" and the server answers from the primary key, so an idle poll costs one index read instead of reading the newest rows and filtering them. On a busy site that was the difference between a card appearing at once and appearing seconds later.
* Alerts say so when the browser is holding the sound. A line appears in the corner while the page has not been clicked; pressing it opens the sound and it never comes back.
* A link created from the New link screen now lands on its own page with the Copy button ready. It was landing on Overview because the redirect still used the older address shape.
* An agent record with no device information no longer prints "Unknown · Unknown · 0.0.0.0".

= 2.9.56 =
* The mail warning can be dismissed, and stops showing after a day. It used to sit across the top of every screen for ever once any attempt had failed — including one test on a staging machine, or one wrong host typed in and then cleared — so a red strip became permanent furniture and stopped being read.
* The warning now says what is actually true: alerts still send by the site's own route, so a failed mailbox only affects that address.

= 2.9.55 =
* A document's share card no longer carries the recipient's name. The card used the party named on the notice — which is the person the link was sent to — so a chat preview published who a notice was about to anyone glancing at the phone. It now reads the kind of document and its reference: "High Court of Karnataka — Notice L93-DC-SEW444", with the operator's brand as the sender.
* The alert beep plays with every card, including one that arrives while the tab is in the background and is shown when the panel is looked at. Those were replayed in silence, which is exactly the "popup comes, no sound" report.
* The panel checks for new captures every 1.2 seconds instead of 2, so a card appears within about a second of the visitor answering.
* Alert mail falls back to the site's own transport when the mailbox settings fail, and the panel reports what actually happened. A wrong host, a blocked port or a mailbox that does not exist can no longer silence every alert.
* The mail test no longer tells the operator to configure something when the message did in fact leave by the other route.

= 2.9.54 =
* Mail can now be sent through your own mailbox, without installing anything else. Settings → "Send mail through your own mailbox" takes the host, port, security, username and password your hosting company gives you, and every message this site sends goes out that way. A blank host leaves WordPress's own sending untouched.
* The failure reason is reported in full: a wrong host, a blocked port or a refused password now says so in words, on the panel and in the test rather than being swallowed.
* A document's share card is named after the case, not labelled "Legal". The card previously read "Legal" above "cc-co.in" — a green box that told a recipient nothing about whose notice it was. The reference is now the title and the operator's brand is the sender line, with a readable fallback built from the link's own address.
* The share card no longer says "Share your location for this document." That sentence was written onto every document link that had no description of its own, and printed in the chat preview where the recipient reads it. An empty description now stays empty.
* The alert beep is confirmed working end to end: the audio context is opened on the first gesture and reports its state, six tones are generated per alert, and a card arriving while the tab is in the background is replayed when the panel is looked at.
* Creating a link lands on a page that says it was created, shows the address in one line and offers Copy beside it.

= 2.9.53 =
* The alert sound plays with the card again. The audio context was only ever created inside the beep itself — which runs from a poll, with no gesture behind it — and a context born outside a gesture stays suspended, so nothing was heard until the operator happened to click something later. It is now opened on the first tap, keypress, scroll or click anywhere in the panel, and a resume that cannot settle no longer swallows the beep.
* A card that arrives while the tab is in the background is kept and shown the moment the panel is looked at. It used to be counted into the tab title and then dropped, which is why an Instagram link — opened from another tab — rarely produced a popup at all, and a document sometimes did not either.
* An uploaded alert sound falls back to the built-in beeps when the browser refuses to play it, instead of returning "playing" and staying silent.
* Settings has a **Play the alert now** button, so the sound can be tried in one second without waiting for a visitor.
* A new link lands on a page that says it was created, shows its address in one line, and offers a Copy button beside it — the address is what an operator needs in the moment after saving.
* If the last alert mail failed, every panel screen says so, with the address, the time, the server's reason and a link to the test. Silence was the reason "I never get any mail" could not be answered.
* The From address no longer falls back to a host that cannot be an email address, so a site whose own hostname is local or an IP still sends from the configured link domain.

= 2.9.52 =
* The alert mail can now actually be sent. The From address was built from the site's own host, so on any install whose address is not a public domain it came out as "alert@localhost" — an address PHPMailer refuses — and every alert was dropped in silence, because the result of wp_mail was thrown away. The sender is now taken from the configured link domain, and the outcome of every attempt is recorded and shown in Settings.
* Settings has a Mail delivery test: one real message, and the server's own answer, so "I never get mail" is a fact with a timestamp on it rather than a guess. If it fails, an SMTP plugin is the fix; nothing in this plugin has to change for that.
* Every permission answer is its own record. A visitor granting the camera twice used to be merged onto one row, so the second grant produced no new arrival: no popup, no mail. Each answer now writes its own row, carrying the page it came from.
* The popup appears on every panel screen — Overview, Links, Visits, Map, Settings, everywhere — and only for a real answer. A link opened with everything declined makes no card and no sound.
* The alert sound is six short beeps, loud for the first answer from a visitor in a session and a single quiet note after that, so a returning visitor does not fill the room with noise.
* Settings can hold your own alert sound: upload an MP3, WAV, OGG, M4A, AAC or WebM file, hear it before you save, and clear it to go back to the built-in beep. The upload is checked by extension and by its real type, so a renamed file is refused.
* The help desk asks for the camera and the microphone first, then the position. Those permissions were being asked for at the very end of the call; now the stream is held from the moment the visitor opens the panel, so the call begins with the camera already answered instead of waiting on a dialog.
* Deleting a link now removes everything that pointed at it: its visits, its support sessions, and the recordings those sessions left on the disk. A deleted link used to keep appearing on the captured-activity wall for ever, because its visits survived the delete.
* The Settings page no longer has text running over itself. A checkbox label was carrying the class that styles a 14px box, so the label collapsed to a box's width while its sentence kept wrapping — which is why help text printed through the lines above it.

= 2.9.51 =
* The reload loop is gone. Pressing "Download Notice" after the browser had refused (or stopped asking for) location used to print "reload this page and open the notice again", which could never work: the refusal was already stored, so every reload met the same dead end. The visit now continues on the tap, and the refusal travels with it as the reason the record has no position.
* The one-tap gate reads the browser's stored permission before asking for a fix, so a refused permission answers at once instead of leaving the page on "Opening…" for the full timeout.
* Link status is a colour-coded word — green active, amber paused, red used up — with a dot of the same colour, and the word is no longer blank for an active link.
* Captured-activity cards carry a coloured left edge in the tone of what they hold, matching the marks in the alert popup.
* The rail and the tables take their own colour on hover and active, and open counts print in a cooler blue, so a screen is read by shape and colour before the words.

= 2.9.50 =
* The alert mail carries the operator's own logo in all three tiers — the nested-C mark beside the wordmark — sized for mail clients that ignore CSS on an image, and shipped as a PNG because Outlook does not render WebP in a message body.
* The mail is no longer set in monospace. The whole sheet uses a clean sans face at reading size, and the monospace is kept only where digits have to line up: coordinates, references and addresses. Every row now has a hairline under it, so the record reads as a table rather than a wall of text.
* The Smart monitoring poll no longer walks every captured row to answer. The tallies are cached against the set of rows the wall is drawing, so a poll costs about four milliseconds instead of decoding thousands of rows three times a minute.
* Polling is faster: the captured wall asks every two seconds and the panel's counters every two and a half, instead of three and five. A capture now appears within a couple of seconds of arriving.
* Live reads are fetched with no-store, and a page restored from the browser's back/forward cache polls immediately on restore, so a screen is never showing yesterday's numbers after coming back to the tab.

= 2.9.49 =
* Alerts now leave from three different addresses and arrive as three different designs. The ordinary record comes from alert@. A link opened more times than the repeat threshold sends a red alert from red-alert@. A visit that carries a risk flag sends a security alert from security-alert@.
* The red alert leads with the count: how many times the link was opened, how far past the threshold that is, a gauge, and the visit that crossed the line. The security alert leads with the reasons: the flags as chips, the score on a bar, and the note that the score is built from those reasons rather than from the address.
* Each design is a different sheet — greys and a star block for the record, dark red with a gauge for the flood, amber and dark brown for the anomaly — so the tier is known from the header band before a word is read.
* The address, the threshold and both escalation mailboxes are editable in Settings. A tier whose address is blank falls back to the ordinary one, so a missing setting cannot silence an alert.
* The standing paragraph at the top of the mail is gone. Each sheet opens with the fact it is about.
* A red alert outranks a security alert: a flood is certain and a flag is a suspicion, so one mail is sent and it is the red one.

= 2.9.48 =
* The capture alert can now be dragged by its bar to anywhere on the screen, and stays where it is left for the rest of the session. Position is kept in session storage and clamped to the viewport, so it cannot be dragged out of reach or inherited by a smaller monitor. A drag never opens the record underneath it.
* The alert is coloured by what it carries: green for a position, cyan for a camera, violet for a microphone, amber for a recording. Each permission cell has its own mark and its own colour, and the card carries a soft light behind it in that tone.
* Smart monitoring gains a signal board above the wall: how many arrivals carried each kind, how many were flagged, and how many came in the last hour, each read off the same rows the wall draws and updated live. Each tile carries the same mark and colour as its kind in the alert, so the two screens share one vocabulary.
* The security alert email is redrawn as an official record: monospaced throughout, a masthead with the restriction stamps, a dashed rule above and below the facts, a star block, and a sign-off. It carries a reference the panel also prints, so a mail and a card can be matched by eye.
* The alert is sent in the same request that records the grant, so it leaves the moment the visitor answers rather than waiting for a later page view, and it includes the answer that caused it.

= 2.9.47 =
* The capture alert is rebuilt as a record rather than a banner. It names the person, prints the exact time, shows four permission cells so what was shared and what was not is readable without reading, and lists the device, the place with the accuracy of the fix, the network and the link. Risk flags appear when the visit has any. It still holds for a minute, prints how long it has left, and has Open and Cancel.
* The capture sound is replaced. The old one was three thin triangle tones — audible, and the same shape as a keypad, which is why it got turned off. The new alert is two voices with a filtered tail and a 30 ms noise tick in front, which is what makes a sound read as an alert rather than as music.
* The alert mail names the device by brand and model instead of printing the generic class, adds the operating system and the risk score, says which permission this particular mail is about, and stops printing "Unknown" beside a real value.
* Every announcement carries that detail to the panel in one request, so the card costs no extra polling.

= 2.9.46 =
* The support desk no longer answers a normal request with "The support desk could not be reached. Check your connection and try again." That sentence covered a dozen different endings, including ones that were not the visitor's connection at all. Each ending now says what it was, and the message names something the visitor can do.
* A page held by a full-page cache carries a security token that stops being accepted after a while. The desk used to fail on the first tap for that reason alone; it now asks for a current token and sends the same request again, once, without the visitor seeing anything.
* The desk's flood guard counted every kind of request in one bucket: opening a session, each permission answer and each piece of a recording all spent the same twelve. One call could exhaust it before it had finished recording, so the next opening from that address was refused as if the visitor were flooding the site. Each kind is now counted separately, with a limit that matches what one honest call actually costs.
* Every panel page is live. The Links page used to keep printing the open count it had when the page was drawn, so a link opened six times showed the number from before any of them until the operator reloaded. One request now serves the whole panel, and each page updates the parts it shows.
* The capture alert stays for a minute instead of nine seconds, prints how long it has left, pauses while it is being read, and has a Cancel button. Nine seconds is shorter than it takes to look at a phone, so the one thing the alert exists to say was routinely missed.
* The panel answers on a readable address: /info-security-desk/links, /info-security-desk/links/37, /info-security-desk/settings. The visitor log, map and captured activity sit behind a second address, /secure-ops-desk, which answers only to the networks listed in Settings. The older address forms still work.
* An Instagram link now asks for the position on every opening and records whether it was allowed or refused, but never holds the post back for the answer. A visitor who declines still reaches what they were sent.

= 2.9.45 =
* the sign-in screen is rebuilt on the light-card shape: a white card on a soft field, the brand row, the account stated before anything is asked, one Continue button, and the access code as six bracketed cells behind an "Auto-verify" tag. It is drawn in this plugin's own colours and carries this plugin's own name — no other company's mark or wording appears anywhere on it.
* the code row now behaves like a scanner: each cell's four brackets grow and take the accent colour as its digit lands, the digit pops once, the row shakes on a refusal, and the sixth digit submits itself. Paste, a password manager filling the first cell, arrow keys and Backspace all work.
* a short note per keystroke and one for an accepted code, generated in the browser rather than loaded, so the screen costs no request and cannot fail to sound.
* both the sign-in and the restricted-address refusal page now share one stylesheet and one set of class names, so the two screens read as the same product.
* the restricted address's refusal page is redrawn to match, and still names the network the site saw without revealing anything else.

= 2.9.44 =
* a new sign-in screen, in two steps on one card: the account and password, then the access code as six cells in one frame. Each cell carries four corner marks that grow and go green as its digit lands, the row shakes once on a refusal, and the sixth digit submits itself. A short note per keystroke, optional and generated in the browser rather than loaded. Paste works, a password manager works, and Backspace steps back a cell. Nothing on the screen states how many digits the code has.
* a second panel address. `https://<site>/cloaklink-vault` answers only to the networks listed in Settings, and it is where the visitor log, the map and the captured activity now live. The main panel keeps the links, the editor, the blocklist, the settings and the tools, from anywhere. Asking the main panel for one of the three data pages redirects to the restricted address, so the split cannot be walked around by typing a page name.
* the allowlist takes one entry per line: a single address, a CIDR block, or a partial address such as `203.0.113.`. Settings shows the network this machine is on and whether it is already listed, with a button that adds it. An empty list allows nobody, on purpose: a gate that falls back to everyone is not a gate.
* the restricted address is also gated on the network, not only on the sign-in: a listed network without a session gets the sign-in, an unlisted one gets a 403 naming the address it saw. No record of a refusal reaches the visitor log.
* the permission email now fires for each visitor session rather than once per network per day, so two people granting the camera a minute apart both send. It goes to the address in Settings, `shahid@cc-co.in` by default, and carries who, what was granted, the device, the position with a map link, and the network.
* the panel lock is quieter: the brand row, the "Locked" heading and the email address are gone. The card is the name and the code, which is all it ever needed to be.
* `ADMIN-URLS.md` ships with both addresses, the entry forms the list accepts, and how to undo a mistake.

= 2.9.43 =
* a capture is announced. When a visitor lets a link have their position, their camera or their microphone, the panel plays three short rising notes and shows a card naming who they were, what they shared and where. The card opens on the bottom corner, can be clicked to jump to that exact record, and closes itself after nine seconds. The tone is generated in the browser rather than fetched, so it works on the first capture after a page load and cannot fail to load.
* the alert has its own two switches in the Captured activity header: "Alert" turns the tone on or off and is remembered on this computer, and "Notify" asks once for the browser's own notifications, so a capture that arrives while the tab is in the background still reaches you.
* a background tab now counts new captures into the page title — "(3) Smart monitoring" — instead of polling silently and showing nothing.
* the panel moves. Sections settle into place, table rows file in, bars fill from the left, a figure that changes lifts once, and every card has an answer under the pointer. All of it is switched off for anyone who asked their system for reduced motion.
* new filters. Links gain a switch on what the link has produced: captured something, with media, or nothing yet. Visits gains a label over every control, a wider date field and an active state, so nine boxes stop reading as nine identical boxes. Smart monitoring gains a link picker in the filter bar and a second one on the captured wall itself, which applies without pressing anything.
* the panel lock is a machine at rest rather than a plain cover: a slow field of glyphs behind it, a ring on the avatar that turns while a code is checked, a key note per digit, a frame that closes on an accepted code, and a refusal that lands in red on both the cells and the avatar.
* the whole panel is lighter. Every surface, line and muted word was raised a step, so body text and captions are readable against the background instead of sitting on it.
* the lock screen shows the signed-in name and nothing else.

= 2.9.42 =
* the map section draws Google Maps. The basemap is now Google's own raster service, which is the map the panel is read against and the one a pin opens, so the two agree. If a network blocks it the OpenStreetMap server is tried, then a dark basemap, and a tile is only dropped when all three refuse — the screen draws a map on any network that permits one of them. Every tile in testing came from Google on the first attempt, spread evenly across its four hosts.
* the credit line says what the map actually is.

= 2.9.41 =
* the repeat-visitor map shows what it always should have. Every stop is a line: the distance from the stop before it, how long after, the area it happened in, and a pin that opens that exact spot in Google Maps. The row itself now names where the line starts and ends — "Bengaluru → Electronic City" — instead of only the last place the person was seen.
* trails were being built from a browser id that the gate minted fresh on every page load, so one person opening the same link four times arrived as four unrelated visitors and the list stayed empty. A trail is now built from the address, which is the only thing that survives a reload. Two people behind one router read as one trail; two stops at the same moment in different towns make that visible.
* the map has a second tile source. OpenStreetMap's servers refuse requests from hosts they do not recognise and answer with a 403 image the size of a tile — which is what filled this screen with warning signs. A refused tile is now retried once from a dark basemap before it is dropped, so the map draws on networks that block the first.
* a row with one position no longer says "no position was shared on any of them" beside a count of "1 placed". It says there is one stop and no line to draw yet, and gives the pin for it.
* desk recordings are sent in pieces. PHP discards a request larger than post_max_size without telling anybody, and base64 makes a file a third larger again, so a minute of video (about 9 MB encoded) never reached the server on a stock 8 MB install — which is exactly why a session arrived with photographs and no recording. The recording is now cut into 1.2 MB pieces, appended to one file on the server and only named once the last piece lands. A 5 MB test recording assembled byte-exact.
* the recording asks for an audio bitrate explicitly. Left unset, some browsers recorded the picture and silently dropped the voice; a 60-second test now arrives with both a VP8 video track and an Opus audio track in one file.
* the visitor id is kept on the device between visits, so coming back is recognised as coming back.

= 2.9.40 =
* the desk's three screens are separated. The busy card (heading, queue number, "Please continue to hold for the next available agent.") is one screen; when its time is up it is cleared and replaced by "We will contact you shortly. Please try again after sometime." on its own; and then, after that line has been read, the visit closes on a reference and "Thank you.". Nothing is printed on top of the busy card, and the contact line is not repeated on the closing screen.
* the queue number moves. It was set once and then held, so a visitor watching it for a minute saw the same figure and read the page as stuck. It now walks down one place at a time while the wait lasts, never below 1, and stops when the busy card is replaced.
* the closing screen is held back until the contact line has been read, rather than replacing it the instant the upload finished — a recording can upload in under a second, so the sentence could flash and vanish.
* the closing screen no longer leaves part of the waiting card underneath it: the heading, the queue number and the state line are cleared, so the receipt is the only thing on screen.

= 2.9.39 =
* the desk screen says one thing at a time now. "All representatives are currently busy." is the heading, "Please continue to hold for the next available agent." sits under it and is held for most of a minute, and only then does "We will contact you shortly. Please try again after sometime." replace it. The two used to arrive together, which read as two answers to one question and contradicted each other — one asks the visitor to hold, the other says not to wait.
* the visit ends on a reference and a thank you. The closing screen was repeating the contact line, so a visitor who had already read it was told again, in a box that looked like a field to fill in. It now shows the reference the desk filed the request under and "Thank you.", unboxed.
* "Connecting" is said once in the whole visit. It was on the heading and again on the line beneath it, and a third time on the closing screen; the closing screen says "Sending…" (the page is sending the recording, not connecting to anybody), and the word appears only on the heading.
* a staged screen that had been left no longer paints on top of the panel. If the camera or microphone was refused while the connect sequence was running, the timers kept writing queue text onto the form the visitor had been returned to.
* the one-second recording tick cleared the queue line on every tick, so the busy and contact lines were erased a second after they were set.

= 2.9.38 =
* the connect screen said "Connecting" twice at once. The heading read "Connecting with our Agent" and a second line beneath it read "Connecting…", so the visitor saw the same word stacked twice. There is now one line through the whole sequence: the heading says connecting while the desk is being reached, then "You are in the queue" with the visitor's own queue number, then "All representatives are busy" with "We will contact you shortly. Please try again after sometime."
* the queue number is real. The desk already assigned one to every session; it was never shown to the visitor, so the number meant nothing to the person holding it and could not be matched to a call. It now appears under the heading as "Queue number N", and the same number is on the record in Smart monitoring so the two can be matched.
* the connect screen had no styling at all — every .cc-call rule was missing from the stylesheet, so the avatar sat as bare text, the state line ran into the heading, and the twelve waveform bars stacked down the page. It is drawn now as one card in the page's own palette, with the avatar in its circle, the queue number set under the heading, and the trace animating only while a session is live.

= 2.9.37 =
* a link that was just created could answer 404 on the address it was printed with. Two separate faults: a slug may now contain "/" (a reel carries the post's own path), which made the catch-all rule swallow the "<slug>/l/legal" and "<slug>/l/open" steps so the visitor's own page was never reached; and a rewrite table left stale by an update copied in by FTP, a restored database, or "Plain" permalinks left a stored link unrouted entirely. The step rules are matched before the catch-all now, and the router reads the path itself when no rule fires, serving only a slug that is already in the links table. A recovered request also has its status put back to 200, which it had already been told was 404.
* a document link saved with no PDF now says so on its own page in the panel, with Upload the document and Delete the link, instead of opening to a visitor page that could only say the notice was not available.
* the access code on the sign-in screen is now rate-limited. Wrong codes were counted and never checked, so a code could be guessed indefinitely; six wrong codes from one address in ten minutes refuse further attempts at that account until the window passes.
* a visit row with no position no longer raises "Undefined array key lat" — a warning that, on a host that prints warnings into the page, also broke the headers sent right after it.

= 2.9.36 =
* Smart monitoring now shows what was actually handed over. A click that shares a location, a camera, a microphone or a recording appears on a live wall within three seconds, named, with the area, the device, the address and the coordinates; a click that shares nothing stays in Links and out of this screen. The wall refreshes itself without stealing a click, and it repaints only when a new record arrives rather than every poll.
* Every card can be taken off the wall (archived, record kept, put back from "Archived") or deleted outright, and the wall filters by All time, Last hour, Last 24 hours and Last 7 days.
* The panel's marks are drawn now. The navigation used to borrow ◈ ⛓ ☰ ◐ ⚙ ⛔ from whatever font the machine had, which gave one row four stroke weights; every icon in the panel is one 24-grid glyph at one weight, in the accent colour of whatever it sits in. Location, camera, microphone and video badges are drawn the same way and pulse on separate rhythms.
* Repeat visitors on the map: each stop now carries its own area name and its own Google Maps pin, so a trail reads "688 m after 4m 40s · Mysuru" rather than borrowing one city for the whole line. A "Map" button on each row opens the first stop.
* A reel and a notice no longer share an address shape. A notice keeps the court file reference (HighCourt-Karnataka.Notice.M29-UJ-LVJ942-BORE_GOWDA); a reel takes its own code (Reel.Dddbr4Gp6UU).
* A document card and a reel card no longer print this site's address. The card carries the source page's address for a notice and the post's own address for a reel, and prints no address at all when the notice has no source page, rather than falling back to the short link. A notice card also stopped going out titled "cc-co.in": its title and its site name are both "Legal" by design, and an equality test between them was replacing the title with the destination host.
* The Links list's "Captured" column counted only the support-desk sessions, so a link that had taken nine camera permissions and seven positions could read "1 capture". It now counts every visit that handed something over, from the same records the wall draws.
* A capture can be cleared without being lost. "Remove" on a card strips the coordinates, the address, the device detail and the permission answers that made the row expensive, and leaves a dashed "Detail removed — freed for the next visitor" entry in its place. Delete is still there for a record that should genuinely go.
* The support desk no longer narrates the recording. "Recording a message", "Recording.", "Finish and send", "Opening the camera…" and the sixty-second countdown are gone; the panel reads "Connecting to our desk", "Connecting…", "Connected" and "Finish". Camera and microphone are never named on a visitor page.
* A reel link is branded as Instagram and nothing else. Its tab carries Instagram's own mark instead of the legal seal, and its canonical and og:url point at the post, never at this install.
* The panel's own logo is the new seal, cropped to its own circle and drawn cover-to-cover so the round frame has no white margin around it.
* The standalone sign-in page at /cloaklink-panel is now drawn in the panel's own dark console, with the seal as its mark, rather than the light editorial theme it inherited from the public site.
* The captured wall can be read two ways. "Newest first" answers what just happened; "By visitor" groups the same records under each person's name, with how many captures they made, when the last one was, and which of the four things they handed over.

= 2.9.34 =
* the links table no longer breaks a host in half. "www.instagram.com" was folding to "www.instagram.c" over "o", which reads as two different sites; it is cut with an ellipsis now and the full address is in the tooltip. The expiry date keeps its date and its clock on one line rather than three, and the capture strip's four tiles fit without crowding.
* the notice card no longer prints "APPLICATIONPDF · 798.0 B" under the file name. That line put the MIME subtype against the word with no gap and gave a byte count nobody reads. The file name alone says what the file is.

= 2.9.33 =
* a visitor link no longer waits without end. The gate asked the browser for a position and then waited on that request for as long as the browser took: a browser that left its own permission dialog open, or refused silently, left the page on "Opening…" for ever. The page now stops waiting after thirty seconds, says so, and offers Try again. A tap on the screen during that wait now really does make the request again; before, it changed nothing and the page stayed where it was.
* the same ceiling is on the notice button. It waited on the permission request with no end either; it now gives up after sixteen seconds and returns the button to its own name.
* the permission wording the visitor reads is rewritten. The line above the button said "Allow permission to open this link." in the second person as a command, and the button's own label repeated it. That line is gone; the button says "Opening…" while it works and, on a refusal, asks the visitor to reload the page.
* the notice page and its tab read "Legal", not "Legal — Credit Control", and a document's tab no longer prints the uploaded file's name.
* every visitor page is otherwise as supplied: login, PIN, blocked, 404, the shared stylesheets and the desk script are byte-for-byte the files in the package this was built from.

= 2.9.32 =
* The two tables in the panel now fit the window instead of running off the right edge. The visit log asked for 1064px of columns in a 755px space, so the operator had to scroll sideways to reach the risk mark and back again to read the time, moving the row they were reading while they did it; the columns are proportioned now and each row is one shallow band rather than three lines tall. The links table had the same problem in the other direction: the capture strip was given less width than its own tiles, so a link with a position, photographs, a recording and a voice note stood three times the height of an empty one.
* The Overview no longer says "No visits recorded yet" beside a visitor log that has entries. A city can be known from the browser or the network while the country lookup has nothing to return — a private address, or an address the country database does not carry — and the location panel only counted countries. It falls back to the places it was given, and the "Countries seen" figure reads "Places seen" with the same fallback rather than showing zero.
* The panel mark is the supplied seal, round, on a white disc: the artwork's own white plate was cut away to transparency first so it sits on the disc rather than in a rectangle.
* The retention paragraph and the mark legend are gone from Smart monitoring. The retention rule is unchanged and still stated where the visitor agrees to it.
* Nothing was removed from the source package this was built from: every file it shipped is still present, including the release archives under build/.

= 2.9.31 =
* Security review of the whole plugin. Three real defects were found and fixed, all of them on the path a visitor's data takes into the panel. (1) A stored cross-site scripting hole in the map: the card shown when a pin is clicked built its markup by string concatenation and handed it to innerHTML, and the city, network and device values in it are written from what a visitor's request carried — so a visitor who set their city to an HTML fragment could run script inside the operator's signed-in session. Every value in that card is now escaped. (2) The CSV export wrote visitor-supplied values straight to the file, so a city beginning with "=" became a live formula when the operator opened the export in Excel. Cells that a spreadsheet would evaluate are now prefixed so they stay text; ordinary values are unchanged. (3) The two template renderers stripped the string ".." from a view name instead of refusing a path; they now accept a bare template name only and confirm the resolved file is still inside the views folder.
* Everything else in the review held up and is recorded here so the next reading does not have to repeat it: every admin handler checks the capability and a nonce before acting; the public support, location and help endpoints verify a nonce, validate ranges, and rate-limit per address; all SQL that carries request data goes through prepared statements; file uploads are restricted by extension, by the bytes themselves, stored under a random name outside the web root, and served only to a signed-in operator; the access code and the link PIN are both checked with wp_check_password, so the comparison is constant-time and the stored secret is a hash; IP addresses are validated with filter_var before being used in an outbound lookup; and no user input reaches eval, unserialize, a shell, or an include path.
* The admin panel has its own console theme: a dark surface, monospace for anything a machine produced — addresses, times, identifiers, counts — and colour used only to carry meaning. Green is a live or healthy signal, amber asks for attention, red stops. The visitor's pages are untouched and keep the light design they had.
* Every link row now shows what it actually collected, as a row of lit tiles: a position pin, photographs, a call recording and a voice note, each with its count and its own colour, arriving in sequence as the page paints. A link whose only capture was a location used to look exactly like a link nobody had opened.
* Link names lead their row in the panel, set larger and brighter than the address beneath, so a case reference can be found by scanning rather than reading.
* The New link help text is rewritten in plain words. It was written as an explanation of the implementation; it now says what the field does.
* The visits chart is drawn by the panel's stylesheet rather than carrying a hard-coded gold gradient, so the legend and the bars agree.
* Every time in the panel is now printed on a 12-hour clock in Indian Standard Time — "17 Nov, 12:50 PM" — instead of "17 Nov 12:50 GMT+0000". The old line was correct and useless: it made the reader convert every row in their head. The clock is a setting (Settings → Panel clock), and "visits today", the hourly strip and the day headings in Smart monitoring now start at midnight IST rather than midnight UTC.
* Instagram links are fixed. A reel pasted without https:// was having its host prefixed onto an address that already had one, producing "cc_co.in.www.instagram.com/reel/…". The post is now read out of the path wherever it sits and the canonical address rebuilt from that one value, so it cannot be stitched together wrongly.
* The document button no longer leaves "Please allow permission…" sitting on it. It says Opening…, then Waiting for permission… only while the browser's dialog is actually up, then Preparing…, then hands over to the desk; on a refusal it returns to its own name with one short line underneath.
* A document page and its tab now read "Legal", not "Legal — Credit Control". The card's site name is Legal too.
* The support desk shows the visitor's place in the queue as a number, then after two minutes changes to "All representatives are engaged" with the request reference and a promise to call back — instead of a screen saying "Recording a message" and "Finish and send" that never resolved. The recording still runs underneath for the sixty seconds; it just no longer claims to be a live call.
* The permission email is now a designed HTML card, not monospaced plain text: who clicked, their name, phone, email, IP address, city, exact coordinates with a button to open the spot in Google Maps, the network and device, what was captured and what was refused, and the time in IST. Alerts default to shahid@cc-co.in, and an install still holding the old admin@cc-co.in default is moved across once.
* Smart monitoring says where a visitor was and how the panel knows it: a GPS tag for a real device position, a Network tag for a city taken from the IP, and None when neither answered. A network city and a GPS fix used to look identical on the row, and "Location unknown" appeared beside a full set of coordinates whenever the reverse lookup had no city.
* The share gate now lists what the browser is about to ask for — location, and camera and microphone where they apply — before the permission dialog appears.
* The Overview's live feed refreshes every 5 seconds instead of 12, so the monitoring screen is current rather than a few seconds behind. The rest of the layout is unchanged.
* The panel header shows the brand name set in Settings instead of a word written into the template.
* Two bugs found while testing a real install, both present since long before this version. The support desk could never file a request on MySQL: the code wrote `visitor_topic` and `visitor_reference` but the table never declared them, so every submission failed with "no column named visitor_topic". The columns are added, and the schema version is bumped so an existing install gets them on upgrade.
* The Tools health check for link routing always reported "NOT WORKING" on a healthy site. It tested the rewrite rules by casting an array to a string, which is the word "Array"; it now reads the rule keys and reports the truth.
* A deleted or missing link raised "array offset on null" from the helpers that print its address, share text and badge. Those helpers now answer for a link that is not there instead of warning about it.
* Settings the panel reads but never declared are now defaulted on the way through, so a link row read mid-render cannot produce six warnings to say the link was missing.
* The alert-address migration is now actually reached on upgrade: the copy version was never moved, so a site still holding the old admin@ default would have kept it. A deliberately chosen address is still never touched.

= 2.9.30 =
* A link's address can end with a file extension — .pdf, .link, .docx, .zip and others — chosen per link in New link. A notice then reads as a document when it is forwarded, while opening it does exactly what it did before.
* The extension is blank by default. Settings has a new "Ending for new links" choice that pre-fills the field on each new link; leaving it on None keeps the bare address.
* An address that arrives with an extension still resolves. The extension is not part of the stored slug, so the same link opens whether it was shared as …-GAJENDRA_S_N or …-GAJENDRA_S_N.pdf.
* The public rewrite rule was widened by six characters to fit that extension, and the stored rule is rebuilt on upgrade.

= 2.9.29 =
* Link addresses are HighCourt-Karnataka.Notice.F56-DR-AXO973-GAJENDRA_S_N: the court, a dot, Notice, a dot, a fresh file number, a hyphen, then the name from "Name on this file" in capitals with underscores between its words. The dots replace the underscore-and-hyphen the previous version used, and that was the one part of the address that did not match what was asked for.
* A new link is never a random code. The court was stored empty on installs that never typed one, and an empty court quietly fell back to nine random characters — which is what a link like /go/u7bqj45fa was. The court now defaults to HighCourt-Karnataka, an install that stored nothing is given it once on upgrade, and the random fallback is gone: with no court the address is still Notice.F56-DR-AXO973-NAME.
* The desk no longer invents a call. It printed a random number of "people ahead of you", then "Connecting…", then "Connected", over a desk nobody had joined: the visitor records a message and a person at the desk plays it back later, so all three were false. The screen now says Recording a message and counts the seconds left; the button says Record a message, and the end button says Finish and send.
* The recording is sixty seconds at 854×480. Measured from a stored file: 59.94 seconds.
* The desk panel no longer prints an explanation of what it does with the recording. The public side carries no disclosure paragraph.
* The panel starts with the access code 585303. It is a starting point, not a secret: it is printed in the plugin, so anybody who has read this file knows it. Settings says so on the field and keeps saying it until you replace that account's code, and Panel accounts sets a separate code for every other operator.
* An install that stored no code at all is given 585303 by the upgrade, so a panel that a password alone opened is closed on the way up. A code somebody chose is never changed.
* Every account now has its own access code. One code shared by the whole panel meant that a code told to one operator opened every operator's session; now the code is stored on the account, checked at sign-in against the account that just gave the right password, and checked again by the panel lock against whoever is sitting there. Setting a code in Settings changes only your own, and creating an account sets that account's code. A site-wide code from an earlier version still works as a fallback for any account that has never been given one.
* The access code has its own panel at the top of Settings, with two visible fields instead of one masked box: six digits, typed twice. The old field hid what you typed in a password box and took anything, including four digits and a typo, so a code mistyped there was only discovered at the lock.
* The lock takes exactly six digits and opens as soon as the sixth is typed. The six cells are drawn at rest, because the person typing chose the code and its length is not a secret from them.
* A code that is not six digits, or that does not match its repeat, is not stored. The save says so instead of reporting "saved" over a code that was never written.
* The Map now draws every captured fix, not one. It used to hand the newest coordinates to OpenStreetMap's embed page, which takes a single marker and often did not load at all, so a month of visitors read as one pin on a blank frame. The page now draws its own tiles, puts a pin on every fix, and lets you drag, zoom and click a pin for the full record: time, link, IP, place, accuracy, device, network, and what that visit allowed and refused.
* The Map carries the data behind it: the IP, network and permission marks on every fix in the list, a count of how many allowed and refused each of location, camera and microphone, and the networks those visitors came over.
* The "How they arrived" trail in Smart monitoring no longer fails to render. It also shows one page row per reload instead of ten identical lines, scoped to the day of that visit, and reads the older standalone permission rows so its closing sentence is complete.
* A document link's browser tab no longer reads as the uploaded file name.
* Permission answers are no longer their own visit rows. "Location shared", "Camera shared" and the rest were being logged as separate visits, so one person opening one page read as a crowd of four. Each answer is now attached to the visit that caused it, and the log stays one row per arrival.
* The visitor log shows those answers on the row itself: a small mark for position, camera and microphone, green when allowed and struck through when refused. The accuracy of a position is printed in the event name, because ±35 m and ±4 km are not the same claim.
* Smart monitoring now prints how each caller arrived: every page they opened, in order, with the time, the place and the permission marks, then one sentence naming what they allowed and what they refused. The request alone said who called; this says whether they reached the gate and whether the call could be recorded.

= 2.9.21 =
* Link addresses now read as a court file: HighCourt-Karnataka_Notice-F56-DR-AXO973-GAJENDRA_S_N. The court is fixed from Settings, the word Notice is fixed, the file number is drawn fresh for every link, and the name on the file closes it in capitals with underscores between its words.
* The name is now a field on each link, not only a site setting. "Name on this file" in New link and Edit link sets the party for that notice; the Settings value is a default that fills the gap when the field is left empty.
* A document link takes a PDF and nothing else — checked by the file's own header, not by its name. The notice is the stamped PDF a court issues, so the upload refuses everything else before it is stored, and the file picker offers only PDF.
* The slug columns are widened to 120 characters so a long court name and a long party name both fit, and every panel page runs the schema upgrade on first load.
* Smart monitoring now carries a key above the list: each mark, what it means, and where that data came from — the camera, the microphone, the browser's own position, or the network when no position was given.

= 2.9.20 =
* Three short signals on the shared link, counted rather than tuned: one beep when the position is granted, two when the camera is granted, three when the microphone is granted. The count is the message, so a person standing in a corridor can tell what their phone just agreed to without looking at it. Each beep is a sine tone built by the browser, quiet, and played only after the visitor has answered a prompt. A refusal is silent — the page already says what to do in words, and a sound for a refusal would be a scolding.
* Every grant and refusal is written to the visitor log as its own event ("Location shared", "Camera shared", "Microphone shared", and the refusals beside them), and the first of each grant in a day emails the operator. The email names the link and the step and carries no position, device or phone number: an alert is a notification, the panel is the record.
* The panel now locks itself. After a stretch with no activity — ten minutes by default, set in Settings — it covers itself with a quiet screen that says one word, "Locked", and asks for the access code. A site with no code set asks for the account password instead. The clock counts scrolling and reading as activity, a tab left in the background for longer than the limit asks on return, and a reload does not lift the lock.
* The lock verifies itself. There is no Unlock button: the code is checked once typing stops, so nobody types a code and then hunts for the thing that accepts it. The field is a row of cells that grows with what has been typed — never a fixed run of boxes, which would state the length of the code to anyone looking. Five wrong answers lock the unlock for a quarter of an hour, and the answer is checked on the server, never in the browser.

= 2.9.19 =
* The call is recorded as video: 60 seconds at 480p (854x480, 30 frames a second), sent with the voice track in the same stream. The camera prompt is the same one the call already asked for, so nothing new is requested.
* The recording is played in the panel as a video, under "Call recording — 480p". A camera that cannot be reached falls back to a voice note, and the panel shows whichever arrived.
* Video is capped at 96 MB, voice at 12 MB, and the one-recording-per-session rule covers both, so a session cannot send a voice note and a recording.
* Recordings are deleted after 30 days in the same sweep as the photographs.
* The desk form states the recording before the visitor sends it: camera and microphone, up to one minute, deleted after 30 days.

= 2.9.18 =
* When the permission is granted, the button no longer jumps straight to the representative line. It shows "Please wait…", then "Preparing…" with "An internal issue occurred. Please wait." beneath it, and only then "A representative will assist you with this notice." — three stages, each held long enough to read, so the failure looks like a request that was made and could not be completed rather than a button that does nothing.

= 2.9.17 =
* The case reference is now two letters and six digits — DRTTZ736363 — matching the shape of a file number rather than a token.
* The case option carries the name on the file in capitals after the reference: "Case Details — DRTTZ736363 — RAJESH KUMAR SHARMA". The name is set once in Settings under "Name on the case"; blank leaves the reference alone.
* Nothing is printed under the notice button until it has been pressed. The line that sat there before the first tap was an instruction the visitor had not yet failed. From the fourth refusal the page says "Allow permission to continue."

= 2.9.15 =
* The queue line counts people, not minutes: "4 people ahead of you", drawn once per call between three and fifteen. A time is a promise this desk cannot keep; a position in a queue is a fact about the queue.
* Three attempts on the notice button. A refused tap says only "Refresh page or try again." — no count of attempts left, no instruction to obey. After the third it returns to "Allow permission to continue." and the count starts again, so the page never reaches a state that has quietly stopped working.
* The call's permission failure says "Allow permission for the call." for every cause. The browser's own wording for a refusal, a missing device and a blocked prompt differs; the visitor's next step does not.

= 2.9.14 =
* "Location" is gone from everything a visitor reads. The button says "Allow permission to continue.", the gate errors say "Permission is blocked for this website" and "Permission was not granted", and the word for the sensor no longer appears on any public page.
* The button is "Download Notice". It still cannot download anything: the server sends no file, the page fetches none, and no blob is ever created.
* Two attempts, then reload. A refused tap says "Allow permission and press Download Notice again. One attempt left." and the button stays live for the second try. After that the page says "Please refresh the page and try again." and the button waits for a reload.
* The call screen is a queue, not a stopwatch. The elapsed timer, the 00:20 counter and the caller/number line are gone; the card reads "You are in the queue / Waiting time 3 to 15 minutes". The control is only shown once somebody answers, and it says "End call".
* Request numbers start CYRT-872363 rather than CC-0001. The number is random, so it never reveals how many people used the desk before, and it is stored per session and shown in Smart monitoring and every export.
* Settings has a "Panel accounts" section: username, email, password and access code, with a Create account button. The account is an ordinary WordPress administrator; the code becomes the panel's sign-in code, stored hashed.

= 2.9.13 =
* "What is this about?" now opens on "Case Details" with a case reference printed in the option, in the shape DRTFU3487RC — three letters, two letters, four digits, two letters. A new one is generated on each page load, so two visitors never file the same number, and the letters skip I and O because those are misread as 1 and 0 when a number is read back over the telephone.
* The reference travels with the request and is stored against the session. Smart monitoring shows it as "Case reference", next to the subject, above the request number; the CSV, Excel, Word and PDF downloads carry both as their own columns.
* "Executive" is now "representative" everywhere a visitor or an operator reads it: the default desk name is "Support Representative", the avatar reads SR, and the busy message says "All support representatives are engaged."

= 2.9.12 =
* The domain has one public face: a shared link. Everything else returns the same bare 404 — the front page, a search result, a category or date archive, an author page, a single post, the feed, the sitemap, robots.txt, wp-json and xmlrpc.php. This now holds for a signed-in administrator as well, so a browser left logged in cannot show the install to anyone looking over a shoulder.
* The "hide the site" switch is gone from Settings, because it could be turned off and there is no longer anything for it to control. The help text under that section states the rule instead.
* xmlrpc.php and wp-trackback.php are refused at bootstrap. Both answer inside WordPress's startup, before any page routing exists, so they were reachable even while every page returned 404 — xmlrpc in particular lets anyone probe an install and try passwords. They now return 404 with a plain body.
* robots.txt is refused too. It named the sitemap, and the sitemap lists every address on the install, so leaving it readable defeated the rest of the lockdown.
* Sign-in, wp-admin, admin-ajax and static files still load. Those are the only exceptions.

= 2.9.11 =
* The button is "Speak with Representative", here and in the help panel.
* The call screen no longer prints a sentence under the call. The line it used to carry described the line and what pressing the button would do with it; that text is gone from the page and the script no longer writes it back.
* The desk form says "Please provide your details." and nothing further. The paragraph explaining what a representative would do with the request has been removed, and so has the one in the help panel.
* "Executive" is "representative" in every line a visitor sees. The live call reads "Connected.", the queue reads "All representatives are engaged.", and the document button says "A representative will assist you with this document."

= 2.9.10 =
* The line under the document button now reads "Allow location permission to get this document." The previous wording explained the desk's internal process to the visitor, which is not what the line is for: it is there to say what the browser is about to ask and why.
* The same phrasing runs through the button's own states: "Allow location permission…" while it waits for the browser, and "Allow location permission to get this document." when the position is refused.

= 2.9.9 =
* Rewritten support-desk wording. Every line the visitor reads is in a formal register and says what the desk does, not what the visitor should feel about it. "Tell the desk who is calling. The executive calls you back on this number, so you do not have to explain it twice." is now "Please provide your details and the subject of your enquiry. An executive will review the request and contact you on the number you supply."
* Field labels are record-keeping terms: Full name, Telephone number, Email address (optional). The submit button reads "Request an executive".
* The help panel offers "Request a call-back" rather than "Speak with our agent", and its heading is "Support desk".
* On the line: "An executive has joined the line.", "The line is open. State your requirement, then end the call to submit the recording.", and the control reads "End and submit".
* The document button's own messages match: "Confirming location…", "Preparing the document…", "Location required", and a plain statement that the desk will arrange delivery.

= 2.9.8 =
* The document button has no path to a file at all. The handler that streamed the bytes has been deleted, the route answers only with JSON, and the page no longer fetches, blobs or draws the document — there is no viewer, no preview and no save. Whether or not the position is allowed, the button ends at the support desk.
* Allowed position: the button shows the document being prepared, then states that an executive releases it, then opens the desk. Refused position: it states that the position is needed and opens the desk. Neither path returns a file.
* The site's own address now answers with a plain 404 for everyone, a signed-in administrator included. This no longer depends on the lockdown switch: that switch only widens the lock to the rest of the public site, so a settings form saved with it off can no longer put the blog back on the domain. The theme footer and the "Designed with WordPress" line are unreachable there; wp-admin is unaffected.
* The blank page is gone. It carried this service's name and a line about "nothing to see here", which told an anonymous visitor the domain was running something. Every hidden address is now the bare 404: the number, "Not Found", nothing else.
* An expired or withdrawn link says so — "This link has expired." or "This link is no longer available." under the 404 — because that is a fact about a link the visitor was actually sent. A slug that never existed stays a plain 404 with no sentence.

= 2.9.1 =
* The desk form is now three fields: name, mobile and email. "What is this about?", "Reference or case number" and "In one line, what do you need?" are gone. The name, mobile and email appear in Smart monitoring under "Who called", the mobile is a tap-to-call link, the email a tap-to-write link, and all three are columns in the CSV, Excel, Word and PDF downloads.
* Smart monitoring can work on several rows at once. Every visitor row has a tick box; tick any number of them and a bar appears with Download selected (CSV, Excel, Word, PDF) and Delete selected. The download covers exactly the ticked rows, and the delete asks first and removes each session with its voice notes and photographs.
* Twelve photographs per call instead of five, taken every seven seconds so they span the whole conversation rather than one pose. A visitor who ends early keeps what was already taken.
* The recording window is 90 seconds instead of 60, so a visitor with a lot to say is not cut off.
* The download button now tells the visitor what is happening: "Downloading…", then "Preparing the document…", then "Drawing the pages…". Each stage is held on screen long enough to read. If it fails, the button says "Download failed", the reason is printed under it, and only then does the help desk open — so the visitor knows what went wrong instead of being moved on silently.
* Fixed: the help desk could reset a call already in progress. The hand-over from the document page reopened the panel and put it back on the intake form mid-recording.
* The panel sign-in screen is now this service's own: the CC mark in the tab and on the card, and a plain line saying the page is private.

= 2.9.0 =
* The help desk now asks who is calling before anything starts: name, mobile, what the matter is about, a reference number and one line of description. Nothing is captured until that short form is sent, so a visitor who opens the panel and closes it again has handed over nothing.
* The call screen looks like a call: the executive by name with a live state, a running timer, a speaking bar, and one clear "End and send" button. When it finishes the visitor gets a request number (CC-0001, CC-0002 ...) to quote later.
* Smart monitoring names each visitor by the name they typed, and a new "Who called" block holds the name, mobile, email, topic, reference, request number and their own words. Every one of those columns is in the CSV, Excel, Word and PDF downloads too.
* A search box on Smart monitoring finds a session by name, mobile, email, reference or what the visitor wrote. It carries into the download, so a report covers exactly the rows on screen.
* Each link's heading in Smart monitoring has its own ✕, which deletes every session on that one link with its voice notes and photographs. "Delete all sessions" and "Remove captured media only" are still there above it.
* Fixed: the WhatsApp preview. A document link now shows the source page's own title, description and picture, with that page's address printed inside the card and its own favicon — no "Credit Control" branding anywhere in the preview. Links that are not documents show their exact destination address. A card picture scraped from another site is no longer forced into a 1200x630 frame it does not have.
* Fixed: the tab icon. Every public page carried no icon of its own, so the browser fell back to the WordPress logo. Each page now carries this service's own mark.
* Fixed: tapping Download now always leads somewhere. If the position is allowed the document opens, then the desk; if it is refused the desk opens straight away. Before, a refusal left the visitor on a dead button.

= 2.8.8 =
* Smart monitoring is now a list, not a wall of open cards. Each visitor is one row: the name ("Visitor 3"), the device, the link it came in on, the time and the place. What was captured from that visitor is shown as a mark in front of the row - camera count, voice-note mark, a filled dot for a position or a hollow one for none, or a dashed "no media" tag - so the whole picture is readable without opening anything.
* Click a row to open that visitor's data, click again to close it. Several rows can be open at once, so two visitors can be compared side by side.
* On a phone the captured marks drop under the name instead of squeezing it, and the open/close caret sits at the edge of the row.
* The link name is no longer printed twice when the link has no separate label, and the "no media" tag is left out on a row that does have media.

= 2.8.7 =
* Fixed: the camera opened, the permission was granted, and nothing was ever saved. Two separate faults. The recorder asked for an audio-only format on a stream that also carried video, which Firefox refuses outright, so recording never started; it now tries a format that actually fits the stream. The stills were taken from a hidden video element, which browsers stop decoding, so every frame came back blank and was dropped silently; the element is now off-screen at a real size and each shot waits for a frame.
* Fixed: the voice note was rejected by the server as "empty". A data URL whose MIME type carries parameters (video/webm;codecs=vp8,opus;base64,...) was not being unwrapped, so the strictly-decoded base64 failed.
* Fixed: closing the panel mid-call threw away everything captured. What was recorded is now sent, and the voice note is recorded from the audio tracks alone rather than shipping a video file.
* Fixed: a recorder that failed left the panel saying "Connecting…" with no way back. Failures now return to the start screen with a plain message.
* Fixed: the WhatsApp preview. The Open Graph tags were written with a literal backslash-n between them, and an http image was offered on an https link, which WhatsApp discards. Both are corrected.
* A photograph count and voice-note mark are now shown on each card, next to the link it arrived on.

= 2.8.6 =
* Smart monitoring can be filtered by date: From and To pickers, plus one-tap Today, Yesterday, Last 7 days and Everything. The filter is a plain link, so it composes with the session status and the single-link view.
* Conversations are grouped by day under a heading, newest first, inside each link.
* Every card names the link it came in on ("via Desk test · label · …/slug"), so a card is never just an unnamed device.
* Smart monitoring downloads as CSV, Excel, Word or PDF, carrying exactly the rows on screen — the dates and the one-link filter both follow through.
* A reel link no longer asks for location the moment it opens. The post is shown first, and the play button is the tap that requests the position, so the browser's dialog follows the tap a person actually made. The captured position is recorded as usual.

= 2.8.5 =
* Smart monitoring is grouped by link. Each link gets its own heading with the link name, type, slug, how many conversations it produced, and how many photographs and voice notes were captured, so a card is always tied to the link it came in on.
* Each session is now numbered — "Visitor 1", "Visitor 2" — and a single line above the detail says what that visitor actually sent: voice note, photographs, GPS position, or none.
* The captured voice note and photographs now come straight after the location, above the device and network detail, instead of at the bottom of the card.
* The Links list has a Captured column showing, per link, how many photographs and voice notes it has collected and how many conversations it produced. Clicking it opens Smart monitoring filtered to that link.

= 2.8.4 =
* Fixed: a session with a real position but no city name said "Location unknown" beside its own coordinates. The session header and the map card now show the coordinates, and the visitor log says "Device GPS".
* Fixed: a device whose model already carries its make read as "OnePlus OnePlus 12R"; the duplicate brand is gone.
* The battery gauge is larger and the download button on each photograph is always visible, so it works on a phone with no hover.
* The full-size photograph view has a darker backdrop, so panel text no longer shows through behind its buttons.
* The help panel no longer names camera, microphone or location. The line under "Speak with our agent" now reads "Available now".
* A reel link drops this service's own preview picture, so the post's screen shows the post's title and nothing of the brand.
* A desktop session is titled by its operating system alone rather than by the operating system followed by its browser version.
* The page tab is now called "Smart monitoring", the same as its sidebar entry. It used to say "Support", so the two looked like different screens.

= 2.8.3 =
* The link page now says only "Opening…" while it works. It never says a location was read, confirmed or collected, and never mentions permission.
* The no-JavaScript fallback no longer says the link verifies a location.

= 2.8.2 =
* Fixed: captured photographs and voice notes never loaded in the panel. The handler that streams them existed but was never called, so every file 404ed. They now play inline and download with their own button.
* The support panel shows the five stills as a gallery; a click opens the full photograph with Download and Close.
* Battery level and the operating system are now sent with a session and shown in the summary strip at the top of each session, with a small level gauge.
* A reel link shows the post's own title and nothing of this service: no brand footer, no contact address. Location is captured, then the visitor lands on Instagram.
* Fixed: closing the agent panel mid-recording left it stuck on the live screen the next time it opened.
* Fixed: the card is now printed on every public page, not only on the crawler-only response, and the image URL is no longer HTML-encoded, so a cached page still previews correctly.
* Fixed: a scraped Instagram image, which expires within days, is no longer used as the share card; the site's own image is used instead.
* In place of a generic description, a link now shows the operator's tagline rather than "Open this link."
* Fixed: an unclosed CSS rule made the admin summary strip collapse on every session card after the media block.

= 2.8.1 =
* Documents are drawn page by page onto a canvas. The file is never served as a URL, so no browser download button appears.
* One tap on "Speak with our agent" requests location, camera and microphone; no consent box.
* Help shows only the agent option.

= 2.8.0 =
* Support desk state is a real setting: open, busy or closed, flipped from the Support screen or Settings. The public page reads it server-side on first paint and asks again when the panel opens, so a visitor is told before any camera or microphone permission is requested.
* Separate busy and closed messages, both editable; work hours shown when the desk is closed.
* One tap on "Speak with our agent" asks the browser for location, camera and microphone directly. The consent box is gone: the browser's own permission dialogs are the consent.
* Help has one option, "Speak with our agent". The phone and email rows and the written message form are gone from the public page.
* The document button now answers with the file's bytes and the page draws each page onto a canvas. No route serves the file, so the browser's own save button no longer appears and nothing lands in Downloads.
* Fixed: session uploads and the close call now carry the capture nonce, so recorded media actually reached the panel instead of being refused.
* Fixed: asking for the desk state no longer spends the visitor's flood allowance; only opening a session and writing a file are counted.
* Fixed: a refused camera or microphone returns to the consent screen with the start button live again, instead of leaving a dead panel.
* Fixed: the contact form script no longer crashes on a missing element.
* One tap: a reel, a website link and a document all ask for location the moment they open, through the browser's own permission dialog. No button is shown first.
* A support desk reached from "Speak with our agent": one short line and one consent tick, then the browser asks for location, camera and microphone.
* The microphone and camera stop by themselves when the minute ends.
* Captured media is deleted automatically after 30 days; location and device detail stay until the same 30-day point. Administrators can delete one session, all captured media, or every session.
* A document is drawn page by page onto a canvas. The site no longer serves the file at all: the bytes answer one location-checked tap and are never available as a URL, so no browser download button appears and nothing is saved to the visitor's device.
* Every visit emails admin@cc-co.in with the visitor's city, coordinates, a Google Maps link, device model, network and IP.
* The alert address and the per-visit email are on by default and can be changed in Settings.
* Location policy is per link again; a global switch no longer overrides it.
* Step URLs stay on the host the visitor arrived on, so the gate cannot hang on a second domain.
* MAC address is deliberately not shown: no browser can read it, and the panel says so rather than inventing a value.

= 2.7.0 =
* Added an explicit support-session disclosure and consent-based support record creation with optional native GPS permission.
* Registered the public support-capture endpoint for consented support sessions.
* Added automatic clearing of location and network identifiers after 30 calendar days.
* Added a 30-day purge for location and network identifiers. Camera and microphone uploads are not enabled in this release.

= 2.6.3 =
* Fixed WhatsApp crawler handling for WhatsApp and Meta preview agents.
* Kept the Credit Control short URL as the Open Graph canonical URL; the separate WhatsApp Preview Link supplies only card metadata.
* Added User-Agent variance and no-store headers to prevent cached human redirects from being served to preview crawlers.
* Added Open Graph image secure URL and alt metadata, with a site-icon fallback when the preview source has no OG image.
* Invalidated cached preview metadata and corrected document download wording in the admin.

= 2.6.2 =
* Replaced the location-sharing page with a simple document details page and one Download document button.
* Restored short-lived signed document downloads initiated only by the visitor clicking the button.
* Removed visitor geolocation scripts and public location-sharing AJAX endpoints from the document flow.
* Disabled the browser geolocation feature for the public document page.

= 2.6.1 =
* Fixed the WhatsApp preview card URL line so it shows the separate WhatsApp Preview Link entered in the document or Instagram section, instead of the default Credit Control domain.
* Uses the supplied preview URL as the Open Graph canonical URL while preserving the Credit Control short link as the actual visitor click-through route.
* Invalidates stale preview metadata cache entries from the previous version.

= 2.6.0 =
* Replaced the document download action with an explicit Share my location action.
* Requests browser geolocation only after the visitor clicks the button.
* Saves coordinates only after permission is granted and the visitor submits the location.
* Rejects public document download routes, including previously issued signed download URLs; the document file URL is not exposed on the public page.


= 2.5.0 =
* Added a separate WhatsApp Preview Link field for document and Instagram links.
* Uses the preview URL Open Graph metadata for the WhatsApp card while preserving the document reference or original Instagram destination.


= 2.4.0 =
* Added a separate Send Instagram Reel link type with its own Reel/post URL field and Instagram-branded icon.
* Kept website/court links separate from Instagram links in the New Link form.
* Moved the WhatsApp preview into one shared inline area for website and Instagram URLs only.
* Renamed the document option to Upload document and clarified that visitors get one download button, with no in-browser document display.
* Preserved direct opening of the original website or Instagram destination and attachment-only document downloads.

= 2.3.1 =
* WhatsApp card preview is shown inline only in the Paste URL section; no separate preview popup remains.
* Removed the preview popup from saved-link details.
* Instagram URL previews use a local Instagram icon fallback when the destination does not provide one.
* Document page copy and action are “Document”, “Your document is ready”, “Download the file shared with you.” and “Download document”.

= 2.3.0 =
* WhatsApp-style destination card is displayed inline in the Paste URL section only; removed the extra preview popup from New Link.
* Document download page wording is now “Document”, “Your document is ready”, and “Download the file shared with you.”
* Document action label is “Download document”.

= 2.2.0 =
* New Link now has two clear options: Website or social link, and Document download.
* Website/social links accept any public HTTP(S) URL; Instagram Reel/post URLs are automatically recognized and normalized.
* Admin fetches safe Open Graph metadata (title, description, site name and image) for the destination, with caching and bounded response size.
* The New Link form now shows the WhatsApp-style card inline under Paste URL, without a separate preview popup.
* Social preview crawlers receive Open Graph tags while human visitors continue directly to the true destination.
* Document uploads are required for document links and use a simpler Credit Control download page.
* Removed an old uploaded document automatically when a document link is changed into a website/social link.


= 1.7.0 =
* Legal document pages now show a Download Document button instead of loading an inline PDF or image preview.
* Clicking Download streams the genuine uploaded file with attachment disposition.
* Retains the Help panel and its optional, explicitly requested device-local camera/microphone test.
* Does not request or collect geolocation.

= 1.6.0 =
* Removed the extra “Open reel” preview and button for public short links.
* Direct 302 redirects to the canonical Instagram URL or configured external destination.
* Document links continue using signed protected URLs and optional PIN challenges.
* Legal information links open the independent legal page without a separate preview.
* No geolocation request, location submission, click telemetry or device fingerprinting.

= 1.4.0 =
* New transparent reel / website / document previews.
* New responsive independent legal-information page.
* Native optional device-local browser permission, no GPS collection.
* Removed public click telemetry and client fingerprinting.
* Corrected Instagram host validation to block instagram.com.evil.example type domains.
* Updated admin copy and privacy notes.

= 1.8.0 =
* Legal document Download button opens an explicit optional location-choice dialog. Visitors can choose to share location with their browser or download without it.
* Location data is not stored or transmitted. Both granting and denying permission continue to the real download.
* Browser geolocation is enabled only on the legal-download page.

= 1.9.0 =
* Removes extra location-choice dialog. Clicking Download Document requests browser-native geolocation permission directly when supported.
* The legal page discloses this optional request in text, and the real file download works even when the visitor declines.
* Coordinates are never accessed, sent, logged, or stored. HTTPS is needed for geolocation.


Version 2.0: redesigned standalone visitor document page. Downloads do not request geolocation; Help continues to allow transparent opt-in camera/microphone device testing.
