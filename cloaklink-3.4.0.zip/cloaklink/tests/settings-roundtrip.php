<?php
/**
 * Regression test: saving one screen must not change another screen's settings.
 *
 * This is the acceptance test for the worst defect in 2.9.x. CloakLink_Settings
 * ::sanitize() built its answer from defaults() and wrote the shipped default
 * for every key the posted form did not carry. Two screens post through that
 * one function — Settings (58 fields) and Access (2 fields) — so saving the
 * Access screen reset 81 settings, and saving Settings reset the two that live
 * on Access, plus everything with no field anywhere at all.
 *
 * Run it from the plugin folder:
 *
 *     php tests/settings-roundtrip.php
 *
 * It needs WordPress loaded, so it looks for wp-load.php by walking up from
 * this file, or takes the path in CL_WP_LOAD. It works on the real option row
 * and restores it byte-for-byte when it finishes, so it is safe to run on a
 * live site — but it is still a test, so run it on a copy you can lose.
 *
 * Exit code 0 means every screen preserved every key it does not own.
 *
 * @package CloakLink
 */

$wp_load = getenv( 'CL_WP_LOAD' );
if ( ! $wp_load ) {
	$dir = __DIR__;
	for ( $i = 0; $i < 12; $i++ ) {
		$dir = dirname( $dir );
		if ( file_exists( $dir . '/wp-load.php' ) ) {
			$wp_load = $dir . '/wp-load.php';
			break;
		}
	}
}
if ( ! $wp_load || ! file_exists( $wp_load ) ) {
	fwrite( STDERR, "Could not find wp-load.php. Set CL_WP_LOAD to its path.\n" );
	exit( 2 );
}
require $wp_load;

if ( ! class_exists( 'CloakLink_Settings' ) ) {
	fwrite( STDERR, "CloakLink_Settings is not loaded — is the plugin active?\n" );
	exit( 2 );
}

$settings = cloaklink()->settings;
$defaults = CloakLink_Settings::defaults();
$original = get_option( CloakLink_Settings::OPTION, array() );

// The ownership registry only exists from 3.0.0. On an older build the test
// still runs, with an empty registry, so that it reports "these keys were
// destroyed" instead of dying on a missing method. A fatal would hide the very
// defect this file exists to catch.
$has_registry = method_exists( 'CloakLink_Settings', 'form_keys' );
if ( ! $has_registry ) {
	$form_keys = function ( $form ) {
		return array();
	};
	$reachable = function () {
		return array();
	};
} else {
	$form_keys = array( 'CloakLink_Settings', 'form_keys' );
	$reachable = array( 'CloakLink_Settings', 'reachable_keys' );
}

// A realistic operator row: every key set to a valid, non-default value. A
// key left at its default would pass even with the bug, because resetting it
// to the default would be a no-op.
$row = array(
	'brand_name'            => 'Shahid Legal',
	'brand_tagline'         => 'Operations',
	'brand_note'            => 'A note.',
	'brand_phone'           => '+91 99999 99999',
	'brand_email'           => 'ops@example.com',
	'notify_email'          => 'alerts@example.com',
	'share_card_image'      => 'https://example.com/card.jpg',
	'extra_domains'         => array( 'a.example.com' ),
	'base_path'             => 'l',
	'link_domain'           => 'links.example.com',
	'link_page_id'          => 0,
	'require_location'      => 1,
	'gps_timeout'           => 40,
	'gps_high_accuracy'     => 1,
	'block_on_deny'         => 1,
	'allow_manual_location' => 1,
	'require_otp'           => 1,
	'count_unique_only'     => 1,
	'link_expiry_hours'     => 12,
	'max_file_mb'           => 9,
	'link_max_clicks'       => 5,
	'vpn_policy'            => 'block',
	'proxy_policy'          => 'block',
	'country_mode'          => 'allow',
	'country_list'          => array( 'IN', 'AE' ),
	'bot_policy'            => 'block',
	'single_device'         => 1,
	'rate_limit'            => 60,
	'retention_days'        => 365,
	'email_on_click'        => 1,
	'smtp_host'             => 'smtp.example.com',
	'smtp_port'             => 465,
	'smtp_user'             => 'mailer',
	'smtp_pass'             => 'not-a-real-password',
	'smtp_secure'           => 'ssl',
	'smtp_from_email'       => 'from@example.com',
	'red_alert_email'       => 'red@example.com',
	'security_alert_email'  => 'sec@example.com',
	'repeat_alert_after'    => 25,
	'alert_sound_id'        => 77,
	'alert_on'              => 0,
	'radio_on'              => 0,
	'radio_live'            => 0,
	'radio_tone'            => 'rising',
	'alert_volume'          => 35,
	'agent_alert_sound'     => 0,
	'share_message'         => 'Shared from {url}',
	'panel_slug'            => 'ops-desk',
	'agent_slug'            => 'agent-room',
	'desk_ip_lock'          => 1,
	'desk_hours_on'         => 1,
	'desk_hours_from'       => '06:30',
	'desk_hours_to'         => '20:15',
	'desk_hours_days'       => '1,2,3,4,5',
	'desk_quota_on'         => 1,
	'desk_quota_day'        => 40,
	'desk_fail_on'          => 1,
	'desk_fail_max'         => 4,
	'desk_fail_minutes'     => 30,
	'desk_pw_days'          => 45,
	'desk_pause'            => 0,
	'desk_log_days'         => 180,
	'desk_notify_login'     => 1,
	'panel_standalone'      => 0,
	'idle_lock_minutes'     => 25,
	'case_name'             => 'High Court',
	'slug_prefix'           => 'Notice',
	'default_extension'     => '.pdf',
	'audit_log'             => 1,
	'geo_api'               => 'ipapi',
	'show_map'              => 0,
	'mask_ip'               => 1,
	'lockdown'              => 1,
	'support_capture'       => 1,
	'support_name'          => 'Desk Lead',
	'desk_status'           => 'busy',
	'desk_busy_message'     => 'Busy message.',
	'desk_hours'            => 'Mon-Fri 06:00-20:00',
	'desk_closed_message'   => 'Closed message.',
	'panel_timezone'        => 'Asia/Dubai',
	'ip_lock_enabled'       => 1,
	'ip_lock_list'          => '203.0.113.7',
	'ip_lock_page'          => 'lock-page',
);

// Keys that are set by code rather than typed into a field, and are therefore
// expected to appear in no form. They are named here rather than filtered out
// silently, so that adding another one is a visible decision:
//
//   link_page_id      written by ensure_link_page() — the holder page's id.
//   alert_sound_id    written by the sound-upload handler — an attachment id.
//   panel_access_code written by set_user_code() — a password hash.
$internal = array( 'link_page_id', 'alert_sound_id', 'panel_access_code' );

/**
 * Compare a stored row against the expected one.
 *
 * @param array    $expected  Row that should still be intact.
 * @param array    $stored    Row actually in the option.
 * @param string[] $skip      Keys this scenario deliberately sent, or internal.
 * @return array key => array( expected, actual )
 */
function cl_roundtrip_diff( $expected, $stored, $skip ) {
	$bad = array();
	foreach ( $expected as $key => $want ) {
		if ( in_array( $key, $skip, true ) ) {
			continue;
		}
		if ( ! array_key_exists( $key, $stored ) ) {
			$bad[ $key ] = array( $want, '(missing)' );
			continue;
		}
		if ( $stored[ $key ] !== $want ) {
			$bad[ $key ] = array( $want, $stored[ $key ] );
		}
	}
	return $bad;
}

$failures  = 0;
$scenarios = array();

// 1. The Access screen: two keys, and it must not touch the other 82.
$scenarios[] = array(
	'label' => 'Access screen save',
	'post'  => array(
		'ip_lock_enabled' => 1,
		'ip_lock_list'    => '203.0.113.7',
		'cl_form_keys'    => implode( ',', $form_keys( 'access' ) ),
	),
	'skip'  => array( 'ip_lock_enabled', 'ip_lock_list' ),
);

// 2. The Settings screen, saved with every switch left unticked. Declared
//    switches must go to 0; every key on another screen must not move.
$settings_post = array( 'cl_form_keys' => implode( ',', $form_keys( 'settings' ) ) );
$scenarios[]   = array(
	'label' => 'Settings screen save, all switches off',
	'post'  => $settings_post,
	'skip'  => $reachable(), // every owned key may legitimately change
);

// 3. A partial post with no declaration at all, as an older form would send.
//    Nothing is declared, so nothing may be destroyed: a key that is not in
//    the post is not this form's business.
$scenarios[] = array(
	'label' => 'Undeclared single-key save',
	'post'  => array( 'brand_name' => 'Shahid Legal' ),
	'skip'  => array( 'brand_name' ),
);

// 4. An empty post — a handler that saves with no fields at all must be a
//    no-op for every key.
$scenarios[] = array(
	'label' => 'Empty post',
	'post'  => array(),
	'skip'  => array(),
);

echo "CloakLink settings round-trip test\n";
echo str_repeat( '=', 60 ) . "\n";
echo 'Plugins: ' . count( $defaults ) . " setting keys in defaults()\n";
echo 'Reachable from a form: ' . count( $reachable() ) . "\n\n";

foreach ( $scenarios as $scenario ) {
	update_option( CloakLink_Settings::OPTION, $row, false );
	$settings->save( $scenario['post'] );
	$stored = get_option( CloakLink_Settings::OPTION, array() );
	$bad    = cl_roundtrip_diff( $row, $stored, array_merge( $scenario['skip'], $internal ) );

	if ( $bad ) {
		$failures++;
		echo 'FAIL  ' . $scenario['label'] . ' — ' . count( $bad ) . " key(s) changed\n";
		foreach ( $bad as $key => $pair ) {
			echo sprintf( "        %-24s %s -> %s\n", $key, json_encode( $pair[0] ), json_encode( $pair[1] ) );
		}
	} else {
		echo 'ok    ' . $scenario['label'] . "\n";
	}
}

// 5. A declared switch must still be able to go from on to off. This is the
//    other half of the fix: preserving absent keys must not make a checkbox
//    impossible to clear.
update_option( CloakLink_Settings::OPTION, array_merge( $row, array( 'mask_ip' => 1, 'audit_log' => 1 ) ), false );
$settings->save( array( 'cl_form_keys' => implode( ',', $form_keys( 'settings' ) ) ) );
$stored = get_option( CloakLink_Settings::OPTION, array() );
if ( 0 === (int) $stored['mask_ip'] && 0 === (int) $stored['audit_log'] ) {
	echo "ok    Declared switches can be turned off\n";
} else {
	$failures++;
	echo 'FAIL  Declared switches could not be turned off: mask_ip=' . json_encode( $stored['mask_ip'] ) . ' audit_log=' . json_encode( $stored['audit_log'] ) . "\n";
}

// 6. And an undeclared key must survive that same save.
if ( 'alerts@example.com' === (string) $stored['notify_email'] && 'smtp.example.com' === (string) $stored['smtp_host'] ) {
	echo "ok    Other-screen keys survived the switch save\n";
} else {
	$failures++;
	echo "FAIL  Other-screen keys were lost: notify_email=" . json_encode( $stored['notify_email'] ) . ' smtp_host=' . json_encode( $stored['smtp_host'] ) . "\n";
}

// 7. Every key in defaults() must be either reachable from a real form, set by
//    code, or knowingly unenforced. Three categories, named rather than
//    inferred, so a key cannot quietly join the third one:
//
//      reachable  — a field exists; the operator can see and change it.
//      internal   — code writes it; no field is correct.
//      unenforced — stored, preserved, and read by nothing on the request
//                   path. A control for it would be a switch that does
//                   nothing, so it is deliberately not rendered. The list is
//                   short and each entry says why.
// 8. A form that declares a key must actually render it, and a key may be
//    declared on two forms only when BOTH of them render it.
//
//    This is the check that catches the subtle half of the original bug. A
//    key declared on a form that does not render it is read as "the operator
//    unticked it" by that form's save, which writes the empty answer over a
//    checkbox that lives somewhere else. desk_hours_days was emptied by
//    pressing Save settings for exactly that reason: it was listed under the
//    settings form, but its checkboxes are in the desk-rules form below.
//
//    Two keys — ip_lock_enabled and ip_lock_list — really are on both the
//    Settings panel and the Access panel, and both screens do render fields
//    for them, so sharing is correct there. The test proves that rather than
//    forbidding it.
if ( $has_registry ) {
	$views = array(
		// The settings screen holds several <form> elements and each one posts
		// on its own. A field inside the desk-rules form is NOT a field of the
		// settings form, so the template is cut at the form boundaries and the
		// region that carries the settings form's own hidden trigger is taken.
		'settings' => array(
			'path'   => __DIR__ . '/../views/admin/settings.php',
			'marker' => 'cloaklink_settings',
		),
		'access'   => array(
			'path'   => __DIR__ . '/../views/admin/access.php',
			'marker' => 'cloaklink_settings',
		),
	);
	$renders = array();
	foreach ( $views as $form_name => $spec ) {
		if ( ! file_exists( $spec['path'] ) ) {
			continue;
		}
		$src   = file_get_contents( $spec['path'] );
		$parts = preg_split( '#</?form\b#i', $src );
		$own   = '';
		foreach ( $parts as $part ) {
			// The chunk holding this form's action value is this form's body.
			if ( false !== strpos( $part, 'value="' . $spec['marker'] . '"' ) ) {
				$own .= $part;
			}
		}
		$renders[ $form_name ] = '' !== $own ? $own : $src;
	}

	$phantom = array();
	foreach ( CloakLink_Settings::form_keys() as $form_name => $keys ) {
		if ( ! isset( $renders[ $form_name ] ) ) {
			continue;
		}
		foreach ( $keys as $key ) {
			if ( false === strpos( $renders[ $form_name ], 'cl[' . $key . ']' ) ) {
				$phantom[] = $form_name . '.' . $key;
			}
		}
	}
	if ( $phantom ) {
		$failures++;
		echo "FAIL  Declared on a form that does not render it (that form will blank it):\n";
		foreach ( $phantom as $one ) {
			echo '        ' . $one . "\n";
		}
	} else {
		echo "ok    Every declared key is rendered by every form that declares it\n";
	}
}

$unenforced = array(
	// Read nowhere on the request path; the enforced click cap lives on each
	// link's own record (CloakLink_Links::at_capacity) rather than here.
	'link_max_clicks',
	// No code verifies a one-time code at the link.
	'require_otp',
	// The "N Device" figure counts every visit regardless of this key.
	'count_unique_only',
	// The monitoring screen draws its map unconditionally.
	'show_map',
	// The router's lockdown path runs unconditionally; nothing gates it.
	'lockdown',
);
$unexplained = array_values(
	array_diff(
		array_diff( array_keys( $defaults ), $reachable() ),
		array_merge( $internal, $unenforced )
	)
);
if ( $unexplained ) {
	$failures++;
	echo 'FAIL  Keys with no form and no stated reason: ' . implode( ', ', $unexplained ) . "\n";
} else {
	echo "ok    Every setting key is reachable, internal, or documented as unenforced\n";
}
// And the unenforced ones must still survive a save of any screen.
update_option( CloakLink_Settings::OPTION, array_merge( $row, array( 'link_max_clicks' => 5, 'require_otp' => 1, 'count_unique_only' => 1, 'show_map' => 0, 'lockdown' => 0 ) ), false );
$settings->save( array( 'ip_lock_enabled' => 1, 'cl_form_keys' => implode( ',', $form_keys( 'access' ) ) ) );
$stored = get_option( CloakLink_Settings::OPTION, array() );
$kept   = 0 === (int) $stored['show_map'] && 0 === (int) $stored['lockdown'] && 1 === (int) $stored['require_otp'] && 5 === (int) $stored['link_max_clicks'];
if ( $kept ) {
	echo "ok    Unenforced keys keep their stored values through a save\n";
} else {
	$failures++;
	echo 'FAIL  Unenforced keys were changed: show_map=' . json_encode( $stored['show_map'] ) . ' lockdown=' . json_encode( $stored['lockdown'] ) . ' require_otp=' . json_encode( $stored['require_otp'] ) . ' link_max_clicks=' . json_encode( $stored['link_max_clicks'] ) . "\n";
}

update_option( CloakLink_Settings::OPTION, $original, false );

echo "\n";
if ( $failures ) {
	echo $failures . " FAILURE(S)\n";
	exit( 1 );
}
echo "All checks passed. Option row restored.\n";
exit( 0 );
