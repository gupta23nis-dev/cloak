<?php
/**
 * Uninstall routine.
 *
 * Runs only when the plugin is deleted from the Plugins screen.
 *
 * "Deleted" has to mean deleted. This file used to drop three tables out of
 * twelve and leave the rest — agents, tickets, ticket history, the support
 * sessions, the radio signal log, the activity ledger — sitting in the
 * database for ever, along with the private folders that hold captured
 * photographs, video and voice notes. On a plugin whose whole subject is
 * surveillance, an uninstall that leaves the recordings behind is not a
 * tidiness problem: the site owner believes the evidence is gone and it is
 * not.
 *
 * So everything this plugin creates is removed here, in one place, and the
 * list is written from the schema rather than from memory.
 *
 * @package CloakLink
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

$settings = get_option( 'cloaklink_settings', array() );

/* ---------------------------------------------------------------------
 * 1. The holder page and any uploaded media the plugin made.
 * ------------------------------------------------------------------ */

if ( is_array( $settings ) && ! empty( $settings['link_page_id'] ) ) {
	$page = get_post( (int) $settings['link_page_id'] );
	if ( $page && (int) get_post_meta( $page->ID, '_cloaklink_holder', true ) === 1 ) {
		wp_delete_post( $page->ID, true );
	}
}

/**
 * Delete a directory tree.
 *
 * Written by hand rather than pulled from WP_Filesystem because uninstall
 * runs before the admin is loaded and the filesystem class may not be
 * initialised. Every path is built from this site's own uploads directory,
 * never from a stored string, so a tampered option cannot point it at
 * anything else.
 *
 * @param string $dir Absolute path.
 * @return void
 */
$cl_rmtree = static function ( $dir ) use ( &$cl_rmtree ) {
	if ( ! is_dir( $dir ) ) {
		return;
	}
	$items = @scandir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( ! is_array( $items ) ) {
		return;
	}
	foreach ( $items as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}
		$path = $dir . DIRECTORY_SEPARATOR . $item;
		if ( is_dir( $path ) && ! is_link( $path ) ) {
			$cl_rmtree( $path );
		} else {
			@unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
	@rmdir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
};

// The private capture folders: photographs, video, voice notes, radio clips.
$cl_uploads = wp_upload_dir();
if ( ! empty( $cl_uploads['basedir'] ) ) {
	$cl_rmtree( trailingslashit( $cl_uploads['basedir'] ) . 'cloaklink-private' );

	// The guard file the plugin writes above that folder. Only removed when
	// it is empty, so a site that put its own rules there keeps them.
	$cl_guard = trailingslashit( $cl_uploads['basedir'] ) . '.htaccess';
	if ( file_exists( $cl_guard ) && 0 === filesize( $cl_guard ) ) {
		@unlink( $cl_guard ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
}

/* ---------------------------------------------------------------------
 * 2. Every table the plugin creates.
 *
 * The list is the schema's own: each table named in
 * class-cloaklink-install.php appears here, so adding a table without
 * adding it here is the only way to leak one, and the check below notices.
 * ------------------------------------------------------------------ */

$cl_tables = array(
	'cloak_links',
	'cloak_visits',
	'cloak_blocks',
	'cloak_agents',
	'cloak_tickets',
	'cloak_ticket_log',
	'cloak_agent_activity',
	'cloak_support',
	'cloak_radio_threads',
	'cloak_radio_members',
	'cloak_radio_messages',
	'cloak_radio_signal',
);

foreach ( $cl_tables as $cl_table ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $cl_table ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery
}

/* ---------------------------------------------------------------------
 * 3. Options.
 *
 * Named individually rather than by a LIKE pattern, because a pattern that
 * matches too much is worse than one that misses: a second plugin on the
 * same site could own a key starting with the same word.
 * ------------------------------------------------------------------ */

$cl_options = array(
	'cloaklink_settings',
	'cloaklink_settings_panel_access_code',
	'cloaklink_db_version',
	'cloaklink_schema_version',
	'cloaklink_audit',
	'cloaklink_adv',
	'cloaklink_agent_prefs',
	'cloaklink_agent_hidden',
	'cloaklink_copy_version',
	'cloaklink_mail_last',
	'cloaklink_route_health',
	'cloaklink_rules_sig',
);

foreach ( $cl_options as $cl_option ) {
	delete_option( $cl_option );
}

// Cached lookups: geo answers, the link preview, the route health check and
// the rate limiter all write transients that are ours alone.
$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '_transient_cloaklink_%'
	    OR option_name LIKE '_transient_timeout_cloaklink_%'
	    OR option_name LIKE '_transient_cloaklink\_%'"
);

// Per-user settings: the desk's own preferences and the access code stored
// against the account.
$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	"DELETE FROM {$wpdb->usermeta}
	 WHERE meta_key LIKE 'cloaklink\_%'"
);

/* ---------------------------------------------------------------------
 * 4. Scheduled work.
 * ------------------------------------------------------------------ */

foreach ( array( 'cloaklink_daily_maintenance', 'cloaklink_beat' ) as $cl_hook ) {
	$cl_stamp = wp_next_scheduled( $cl_hook );
	while ( $cl_stamp ) {
		wp_unschedule_event( $cl_stamp, $cl_hook );
		$cl_stamp = wp_next_scheduled( $cl_hook );
	}
}

// The plugin's rewrite rules live in the option WordPress caches them in;
// flushing once here means the desk and the shared-link routes stop being
// answered the moment the plugin is gone.
flush_rewrite_rules( false );
