<?php
/**
 * Network access: which machines may open the second panel.
 *
 * This is the allowlist on its own screen. Settings still holds it, because
 * the form there saves everything at once; this page exists so the one list
 * that can lock an operator out of their own console has a place of its own,
 * with the entries laid out as entries rather than as lines of text to edit
 * by hand.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_s       = $settings->all();
$cl_my_ip   = CloakLink_Guard::ip();
$cl_listed  = CloakLink_Guard::listed( $cl_my_ip );
$cl_lock_on = ! empty( $cl_s['ip_lock_enabled'] );
$cl_vault   = home_url( '/' . $cl_s['ip_lock_page'] );

// One entry per line, comments dropped: the list is stored normalised, so
// printing it back exactly as stored is what an operator saved.
$cl_entries = array();
foreach ( preg_split( '/\r\n|\r|\n/', (string) $cl_s['ip_lock_list'] ) as $cl_line ) {
	$cl_line = trim( (string) $cl_line );
	if ( '' !== $cl_line ) {
		$cl_entries[] = $cl_line;
	}
}
$cl_used = 0;
$cl_seen = isset( $cl_s['ip_lock_seen'] ) && is_array( $cl_s['ip_lock_seen'] ) ? $cl_s['ip_lock_seen'] : array();
?>

<div class="cl-pagehead">
	<div>
		<h2 class="cl-pagehead__t"><?php esc_html_e( 'Network access', 'cloaklink' ); ?></h2>
		<p class="cl-pagehead__s"><?php esc_html_e( 'The second panel opens only to the machines listed here. Everything else is refused before a sign-in form is drawn.', 'cloaklink' ); ?></p>
	</div>
	<span class="cl-badge <?php echo $cl_lock_on ? 'cl-badge--ok' : 'cl-badge--warn'; ?>">
		<?php echo $cl_lock_on ? esc_html__( 'Second panel on', 'cloaklink' ) : esc_html__( 'Second panel off', 'cloaklink' ); ?>
	</span>
</div>

<div class="cl-grid cl-grid--2">

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'This machine', 'cloaklink' ); ?></h2>
		</header>
		<div class="cl-panel__body">
			<div class="cl-ipnow<?php echo $cl_listed ? ' is-ok' : ' is-warn'; ?>">
				<span class="cl-ipnow__dot" aria-hidden="true"></span>
				<span class="cl-ipnow__t">
					<?php esc_html_e( 'Requests from this machine carry', 'cloaklink' ); ?>
					<code><?php echo esc_html( $cl_my_ip ); ?></code>
				</span>
			</div>
			<p class="cl-help">
				<?php
				echo $cl_listed
					? esc_html__( 'That address is on the list, so this machine can open the second panel.', 'cloaklink' )
					: esc_html__( 'That address is not on the list. If you mean to use the second panel from here, register it below — and do it from here, where you are signed in.', 'cloaklink' );
				?>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-inline-form">
				<input type="hidden" name="action" value="cloaklink_access">
				<input type="hidden" name="cl_do" value="add">
				<input type="hidden" name="cl_entry" value="<?php echo esc_attr( $cl_my_ip ); ?>">
				<?php wp_nonce_field( 'cloaklink_access' ); ?>
				<button type="submit" class="cl-btn cl-btn--primary cl-btn--sm"><?php esc_html_e( 'Register this machine', 'cloaklink' ); ?></button>
			</form>

			<p class="cl-help cl-help--quiet">
				<?php esc_html_e( 'Registration is written to the saved list. If the second panel is switched off, registering adds the address but does not switch it on.', 'cloaklink' ); ?>
			</p>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'The second door', 'cloaklink' ); ?></h2>
		</header>
		<div class="cl-panel__body">
			<p class="cl-help">
				<?php esc_html_e( 'The second panel is a different address on the same site. It holds the visitor log, the map and the captured activity. The main panel keeps the links, the editor, the blocklist and these settings, and answers to any operator who can sign in.', 'cloaklink' ); ?>
			</p>
			<p class="cl-static cl-static--code"><?php echo esc_html( $cl_vault ); ?></p>
			<?php if ( $cl_lock_on ) : ?>
				<p class="cl-help cl-help--quiet"><?php esc_html_e( 'A machine that is not on this list sees an "Unauthorized Device" page there. It offers no sign-in form and says nothing about what is inside.', 'cloaklink' ); ?></p>
			<?php else : ?>
				<p class="cl-help cl-help--warn"><?php esc_html_e( 'The second panel is switched off, so that address answers nobody — not even a listed machine. Turn it on below once at least one address is registered.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

</div>

<form class="cl-form cl-form--settings" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<input type="hidden" name="action" value="cloaklink_settings">
	<input type="hidden" name="cl_access_page" value="1">
	<?php wp_nonce_field( 'cloaklink_settings' ); ?>

	<?php
	// This screen carries two settings and must touch only those two.
	// Before 3.0.0 it posted through the same sanitiser as Settings, which
	// treated every key this form does not render as "reset to the shipped
	// default" — pressing Save here wiped eighty-one settings, including the
	// brand, the mail transport and the whole gating policy. Declaring the
	// two keys it owns is what makes that impossible.
	?>
	<input type="hidden" name="cl[cl_form_keys]" value="<?php echo esc_attr( implode( ',', CloakLink_Settings::form_keys( 'access' ) ) ); ?>">

	<section class="cl-panel cl-panel--full">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Registered machines and networks', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note"><?php echo esc_html( sprintf( /* translators: %d: number of entries */ _n( '%d entry', '%d entries', count( $cl_entries ), 'cloaklink' ), count( $cl_entries ) ) ); ?></p>
		</header>
		<div class="cl-panel__body">

			<div class="cl-field cl-field--wide">
				<label class="cl-checkrow" for="cl-ip-lock">
					<input type="checkbox" id="cl-ip-lock" name="cl[ip_lock_enabled]" value="1" <?php checked( $cl_lock_on ); ?>>
					<span><?php esc_html_e( 'Open the second panel, and only to the list below', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'While this is off, the second panel answers nobody at all. The main panel is unaffected either way.', 'cloaklink' ); ?></p>
			</div>

			<div class="cl-field cl-field--wide">
				<label class="cl-label" for="cl-ip-list"><?php esc_html_e( 'Allowed addresses', 'cloaklink' ); ?></label>
				<textarea class="cl-input cl-textarea cl-mono" id="cl-ip-list" name="cl[ip_lock_list]" rows="8" spellcheck="false" placeholder="203.0.113.7&#10;203.0.113.0/24&#10;2001:db8::/32&#10;# one entry per line"><?php echo esc_textarea( $cl_s['ip_lock_list'] ); ?></textarea>
				<p class="cl-help">
					<?php esc_html_e( 'One entry per line. A full address allows one machine; a block such as 203.0.113.0/24 allows a range; a partial address such as 203.0.113. allows everything beginning with it; an IPv6 block works the same way. Lines beginning with # are ignored. An empty list allows nobody.', 'cloaklink' ); ?>
				</p>
			</div>

			<?php if ( $cl_lock_on && ! $cl_listed ) : ?>
				<p class="cl-help cl-help--warn"><?php esc_html_e( 'The second panel is on and this machine is not on the list, so it will refuse you. Register this machine above, or add your address here, before you save.', 'cloaklink' ); ?></p>
			<?php endif; ?>

			<div class="cl-actions">
				<button type="submit" class="cl-btn cl-btn--primary"><?php esc_html_e( 'Save access list', 'cloaklink' ); ?></button>
			</div>
		</div>
	</section>

	<section class="cl-panel cl-panel--full">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Refused attempts', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note"><?php esc_html_e( 'Every address that asked for the second panel and was turned away.', 'cloaklink' ); ?></p>
		</header>
		<div class="cl-panel__body">
			<?php if ( ! $cl_seen ) : ?>
				<p class="cl-empty"><?php esc_html_e( 'No refused attempts have been recorded.', 'cloaklink' ); ?></p>
			<?php else : ?>
				<table class="cl-table cl-table--tight">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Address', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'First seen', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Last seen', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Attempts', 'cloaklink' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $cl_seen as $cl_ip => $cl_when ) : ?>
							<?php
							if ( ! is_array( $cl_when ) ) {
								continue;
							}
							$cl_first = isset( $cl_when['first'] ) ? (int) $cl_when['first'] : 0;
							$cl_last  = isset( $cl_when['last'] ) ? (int) $cl_when['last'] : 0;
							$cl_hits  = isset( $cl_when['hits'] ) ? (int) $cl_when['hits'] : 0;
							?>
							<tr>
								<td><code><?php echo esc_html( $cl_ip ); ?></code></td>
								<td><?php echo esc_html( $cl_first ? wp_date( 'j M Y, g:i A', $cl_first, $admin->tz() ) : '—' ); ?></td>
								<td><?php echo esc_html( $cl_last ? wp_date( 'j M Y, g:i A', $cl_last, $admin->tz() ) : '—' ); ?></td>
								<td><strong><?php echo esc_html( number_format_i18n( $cl_hits ) ); ?></strong></td>
								<td class="cl-td-actions">
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-inline-form">
										<input type="hidden" name="action" value="cloaklink_access">
										<input type="hidden" name="cl_do" value="allow">
										<input type="hidden" name="cl_entry" value="<?php echo esc_attr( $cl_ip ); ?>">
										<?php wp_nonce_field( 'cloaklink_access' ); ?>
										<button type="submit" class="cl-btn cl-btn--ghost cl-btn--sm"><?php esc_html_e( 'Register', 'cloaklink' ); ?></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-inline-form">
					<input type="hidden" name="action" value="cloaklink_access">
					<input type="hidden" name="cl_do" value="forget">
					<?php wp_nonce_field( 'cloaklink_access' ); ?>
					<button type="submit" class="cl-btn cl-btn--ghost cl-btn--sm"><?php esc_html_e( 'Clear this list', 'cloaklink' ); ?></button>
				</form>
			<?php endif; ?>
			<p class="cl-help cl-help--quiet">
				<?php esc_html_e( 'A refusal records the address and the time only. Nothing about the request, the visitor or the page is kept.', 'cloaklink' ); ?>
			</p>
		</div>
	</section>

</form>
