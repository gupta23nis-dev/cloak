<?php
/**
 * Your account: the two secrets that open this panel.
 *
 * Two fields, and one of them is proof.
 *
 * The screen exists because of a specific failure: someone was told "that
 * password is not correct" while their password was in fact correct — the
 * refusal had come from the access code, which was the six digits shipped in
 * the plugin, which nobody had ever been told to change. The person did what
 * anybody would do, went looking for a place to reset the password, and there
 * was none on this side of the panel at all.
 *
 * So: the password and the code, both changeable here, both requiring the
 * current password. Requiring it is not ceremony. Panel sessions are long and
 * a tab left open in an office is exactly what the lock screen exists for; if
 * this page took a session as proof of identity, whoever next sat down at that
 * tab could set a password of their own and keep the account.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_notice = isset( $_GET['cl_notice'] ) ? sanitize_key( wp_unslash( $_GET['cl_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

$cl_me      = wp_get_current_user();
$cl_ini     = mb_strtoupper( mb_substr( (string) $cl_me->display_name, 0, 1 ) );
$cl_has_own = CloakLink_Login::user_has_code( (int) $cl_me->ID );
$cl_site    = (string) $settings->get( 'panel_access_code', '' );
$cl_uses_site = ! $cl_has_own && '' !== $cl_site;

$cl_notes = array(
	'saved'    => array( 'ok', __( 'Your account is updated. Use the new details the next time you sign in.', 'cloaklink' ) ),
	'pass'     => array( 'ok', __( 'Your password is changed. Every other session on this account has been signed out.', 'cloaklink' ) ),
	'code'     => array( 'ok', __( 'Your access code is changed.', 'cloaklink' ) ),
	'both'     => array( 'ok', __( 'Your password and access code are changed. Every other session on this account has been signed out.', 'cloaklink' ) ),
	'cleared'  => array( 'ok', __( 'Your own access code is removed. The site-wide code applies to this account again.', 'cloaklink' ) ),
	'current'  => array( 'bad', __( 'Your current password was not correct, so nothing was changed. It is asked for so that a tab left open cannot be re-keyed by whoever sits down at it.', 'cloaklink' ) ),
	'passmatch' => array( 'bad', __( 'Those two passwords are not the same, or the new one is shorter than eight characters. Nothing was changed.', 'cloaklink' ) ),
	'codenum'  => array( 'bad', __( 'An access code is six digits, typed twice. Nothing was changed.', 'cloaklink' ) ),
	'codecurrent' => array( 'bad', __( 'Your current access code was not correct, so nothing was changed.', 'cloaklink' ) ),
	'nothing'  => array( 'bad', __( 'Nothing was changed: both the password and the code fields were empty.', 'cloaklink' ) ),
);
$cl_note = isset( $cl_notes[ $cl_notice ] ) ? $cl_notes[ $cl_notice ] : null;
?>

<p class="cl-help">
	<?php esc_html_e( 'The two things that open this panel. They belong to you alone — changing one here changes nothing on anybody else’s account.', 'cloaklink' ); ?>
</p>

<?php if ( $cl_note ) : ?>
	<div class="cl-flash cl-flash--<?php echo esc_attr( $cl_note[0] ); ?>" role="status"><?php echo esc_html( $cl_note[1] ); ?></div>
<?php endif; ?>

<?php
// The one warning worth putting on this page: an install whose operator is
// still on the shipped code is one whose third factor is printed in the
// plugin's own source. It is not a secret, and saying so here — where the
// fix is two fields away — is the only place it can be acted on.
?>
<?php if ( $cl_uses_site ) : ?>
	<div class="cl-flash cl-flash--bad" role="status">
		<?php esc_html_e( 'This account has no access code of its own, so the site-wide code applies — including the shipped 585303 if it was never changed. Set your own below.', 'cloaklink' ); ?>
	</div>
<?php endif; ?>

<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-account-form" autocomplete="off">
	<input type="hidden" name="action" value="cloaklink_account">
	<?php wp_nonce_field( 'cloaklink_account' ); ?>

	<section class="cl-panel cl-panel--full">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php echo esc_html( $cl_me->display_name ); ?></h2>
			<p class="cl-panel__note">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: username */
						__( 'Signed in as %s', 'cloaklink' ),
						(string) $cl_me->user_login
					)
				);
				?>
			</p>
		</header>

		<div class="cl-panel__body">

			<div class="cl-field">
				<label class="cl-label" for="cl-acct-current"><?php esc_html_e( 'Your current password', 'cloaklink' ); ?></label>
				<?php
				// Deliberately NOT autocomplete="current-password".
				//
				// That hint told the browser to fill this with the password it
				// has saved for this site, and a saved password is often one
				// from before it was last changed. The form then submits a
				// password the account no longer has, the check fails, and it
				// reads as "my correct password is being refused" — with the
				// field shown as filled, so nothing looks wrong.
				//
				// Browsers also style a filled password field (Chrome tints it
				// yellow), which is what makes it visible that the value was
				// not typed. Off, the field starts empty and can only contain
				// what the person puts there.
				?>
				<input class="cl-input" id="cl-acct-current" name="cl_current" type="password" autocomplete="off" spellcheck="false" autocapitalize="none" required>
				<p class="cl-help"><?php esc_html_e( 'Type it — your browser may have filled this with an older password it saved, which would be refused. It proves the person typing is the account holder and not somebody who found this tab open.', 'cloaklink' ); ?></p>
			</div>

			<div class="cl-field cl-field--wide">
				<h3 class="cl-label"><?php esc_html_e( 'Change a secret', 'cloaklink' ); ?></h3>
			</div>

			<div class="cl-field">
				<label class="cl-label" for="cl-acct-pass"><?php esc_html_e( 'New password', 'cloaklink' ); ?></label>
				<div class="cl-inline">
					<input class="cl-input" id="cl-acct-pass" name="cl_pass" type="password" minlength="8" autocomplete="new-password" placeholder="<?php esc_attr_e( 'leave empty to keep', 'cloaklink' ); ?>">
					<input class="cl-input" id="cl-acct-pass2" name="cl_pass2" type="password" minlength="8" autocomplete="new-password" aria-label="<?php esc_attr_e( 'New password, again', 'cloaklink' ); ?>" placeholder="<?php esc_attr_e( 'the same again', 'cloaklink' ); ?>">
				</div>
				<p class="cl-help">
					<?php esc_html_e( 'Eight characters or more. Changing it signs out every other device on this account, which is what you want if a password may have been seen by somebody else.', 'cloaklink' ); ?>
				</p>
			</div>

			<div class="cl-field">
				<label class="cl-label" for="cl-acct-code"><?php esc_html_e( 'New access code', 'cloaklink' ); ?></label>
				<div class="cl-inline">
					<input class="cl-input cl-input--small" id="cl-acct-code" name="cl_code" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" spellcheck="false" placeholder="<?php echo $cl_has_own ? esc_attr__( 'new code', 'cloaklink' ) : esc_attr__( '6 digits', 'cloaklink' ); ?>">
					<input class="cl-input cl-input--small" id="cl-acct-code2" name="cl_code2" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" spellcheck="false" aria-label="<?php esc_attr_e( 'New access code, again', 'cloaklink' ); ?>" placeholder="<?php esc_attr_e( 'again', 'cloaklink' ); ?>">
				</div>
				<p class="cl-help">
					<?php esc_html_e( 'Six digits, typed twice. This is the second field on the sign-in page, after your password, and it is what the panel asks for when it locks itself.', 'cloaklink' ); ?>
				</p>
				<?php if ( $cl_has_own ) : ?>
					<div class="cl-field">
						<label class="cl-label" for="cl-acct-code-now"><?php esc_html_e( 'Your current access code', 'cloaklink' ); ?></label>
						<input class="cl-input cl-input--small" id="cl-acct-code-now" name="cl_code_now" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" spellcheck="false" placeholder="••••••">
						<p class="cl-help"><?php esc_html_e( 'Asked for so that a panel somebody else is sitting at cannot be re-keyed. Not needed to remove the code.', 'cloaklink' ); ?></p>
					</div>
				<?php endif; ?>
				<?php if ( $cl_has_own ) : ?>
					<label class="cl-checkrow" for="cl-acct-code-clear">
						<input type="checkbox" id="cl-acct-code-clear" name="cl_code_clear" value="1">
						<span><?php esc_html_e( 'Remove my code and fall back to the site-wide one', 'cloaklink' ); ?></span>
					</label>
				<?php endif; ?>
			</div>

		</div>

		<div class="cl-panel__foot">
			<button type="submit" class="cl-btn cl-btn--go"><?php esc_html_e( 'Save my account', 'cloaklink' ); ?></button>
			<a class="cl-btn" href="<?php echo esc_url( wp_lostpassword_url( CloakLink_Admin::url( 'overview' ) ) ); ?>"><?php esc_html_e( 'I have forgotten my password', 'cloaklink' ); ?></a>
		</div>
	</section>
</form>
