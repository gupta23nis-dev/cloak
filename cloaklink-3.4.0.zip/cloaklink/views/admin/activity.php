<?php
/**
 * Desk activity.
 *
 * The operator's answer to "who was on the desk, from where, and what did they
 * do". Everything on this screen comes out of one table that is written by the
 * actions themselves, never by the browser: a row exists because a sign-in
 * succeeded, a ticket was raised, a record was cleared. It records actions and
 * not data — a row says a ticket was raised and which one, never the visitor's
 * name — so deleting a ticket leaves a truthful record of the decision without
 * a second copy of the thing that was deleted.
 *
 * Two questions shape the layout. The first is present tense: who is on the
 * desk this minute. That is the strip at the top, derived from the last sign-in
 * and the last sign-out, so it stays right when somebody closes a laptop
 * without signing out. The second is past tense: what happened, in what order,
 * narrowed to one person or one kind of event. That is the list.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_log     = cloaklink()->agent_log;
$cl_agents  = cloaklink()->agents;
$cl_all     = $cl_agents->all();
$cl_presence = $cl_log->presence();
$cl_events  = CloakLink_Agent_Log::events();

// The switches the operator set for this screen. Every one of them is read
// here and nowhere else, and the defaults are the screen exactly as it was
// before the group existed — so an untouched install looks unchanged.
$cl_adv       = cloaklink()->adv;
$cl_per       = max( 10, min( 500, (int) $cl_adv->get( 'act_per_page', 60 ) ) );
$cl_order     = 'oldest' === $cl_adv->get( 'act_order', 'newest' ) ? 'oldest' : 'newest';
$cl_refresh   = max( 0, min( 300, (int) $cl_adv->get( 'act_autorefresh', 0 ) ) );
$cl_presence_on = $cl_adv->yes( 'act_presence' );
$cl_kpis_on   = $cl_adv->yes( 'act_kpis' );
$cl_kpi_days  = max( 1, min( 365, (int) $cl_adv->get( 'act_kpi_days', 7 ) ) );
$cl_kpi_count = max( 1, min( 14, (int) $cl_adv->get( 'act_kpi_count', 6 ) ) );
$cl_detail_on = $cl_adv->yes( 'act_show_detail' );
$cl_device_on = $cl_adv->yes( 'act_show_device' );
$cl_system_on = $cl_adv->yes( 'act_show_system' );
$cl_tone_on   = $cl_adv->yes( 'act_tone' );
$cl_dayheads  = $cl_adv->yes( 'act_day_heads' );
$cl_seconds   = $cl_adv->yes( 'act_seconds' );
$cl_namelink  = $cl_adv->yes( 'act_person_link' );
$cl_sticky    = $cl_adv->yes( 'act_sticky_filters' );
$cl_ip_style  = (string) $cl_adv->get( 'act_ip_style', 'full' );
if ( ! $cl_adv->yes( 'act_show_ip' ) ) {
	$cl_ip_style = 'hidden';
}
$cl_watch_at  = max( 0, min( 100, (int) $cl_adv->get( 'act_refused_watch', 0 ) ) );
$cl_time_fmt  = $cl_seconds ? 'H:i:s' : 'H:i';
// How far back the shape of the shift is drawn. A day is the unit a desk is
// worked in; a week is what a rota is planned against.
$cl_hours     = max( 6, min( 168, (int) $cl_adv->get( 'act_series_hours', 24 ) ) );

// The filters. A person, a kind of event and a date range — the three ways an
// operator narrows this list, and the only three the table can answer without
// scanning it in PHP.
$cl_who  = isset( $_GET['who'] ) ? absint( $_GET['who'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$cl_ev   = isset( $_GET['ev'] ) ? sanitize_key( wp_unslash( $_GET['ev'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_page = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification

if ( ! isset( $cl_events[ $cl_ev ] ) ) {
	$cl_ev = '';
}
if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $cl_from ) ) {
	$cl_from = '';
}
if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $cl_to ) ) {
	$cl_to = '';
}

$cl_filters = array(
	'agent_id' => $cl_who,
	'event'    => $cl_ev,
	'from'     => $cl_from,
	'to'       => $cl_to,
);

$cl_rows  = $cl_log->rows(
	array_merge(
		$cl_filters,
		array(
			'max'   => $cl_per,
			'page'  => $cl_page,
			'order' => $cl_order,
		)
	)
);
$cl_total = $cl_log->count( $cl_filters );

// Names, once, so a row can print a person without a query each.
$cl_names = array();
$cl_roles = array();
foreach ( $cl_all as $cl_a ) {
	$cl_names[ (int) $cl_a['id'] ] = (string) $cl_a['name'];
	$cl_roles[ (int) $cl_a['id'] ] = (string) $cl_a['role'];
}

// Who is on the desk right now. Counted from the same presence map every other
// screen reads, so "2 online" here and "2 online" on Case agents can never be
// two different numbers.
$cl_live = array();
foreach ( $cl_presence as $cl_pid => $cl_p ) {
	if ( ! empty( $cl_p['live'] ) ) {
		$cl_live[ (int) $cl_pid ] = $cl_p;
	}
}

// A one-week tally, for the strip under the presence. It is per event and per
// person, which is what makes it worth showing: "eleven tickets raised" is a
// fact about the desk, and "one person raised nine of them" is a fact about a
// person.
$cl_tally  = $cl_log->tally( $cl_kpi_days );
$cl_by_ev  = array();
foreach ( $cl_tally as $cl_tid => $cl_evs ) {
	foreach ( $cl_evs as $cl_ek => $cl_n ) {
		if ( ! isset( $cl_by_ev[ $cl_ek ] ) ) {
			$cl_by_ev[ $cl_ek ] = 0;
		}
		$cl_by_ev[ $cl_ek ] += (int) $cl_n;
	}
}
arsort( $cl_by_ev );
$cl_by_ev = array_slice( $cl_by_ev, 0, $cl_kpi_count, true );

// The shape of the shift, and the people in it.
//
// The tiles say how many of each event. These answer the two questions that
// follow and that a count cannot: when is this desk busy, and who is doing
// the work. Both are read from the same table over the same window, so the
// chart and the figures above it can never disagree.
$cl_series  = $cl_log->series( $cl_hours );
$cl_peak    = 1;
foreach ( $cl_series as $cl_s ) {
	$cl_peak = max( $cl_peak, (int) $cl_s['total'] );
}
$cl_leaders = $cl_log->leaders( $cl_kpi_days, 6 );
$cl_dormant = $cl_log->dormant();

// How much of the window is work that went through, and how much is a door
// being pushed at. Two figures, one ratio: it is the number that decides
// whether the rest of the screen needs reading at all.
$cl_sum_ok = 0;
$cl_sum_no = 0;
foreach ( $cl_series as $cl_s ) {
	$cl_sum_ok += (int) $cl_s['ok'];
	$cl_sum_no += (int) $cl_s['no'];
}
$cl_sum_all = max( 1, $cl_sum_ok + $cl_sum_no );
$cl_ok_pct  = (int) round( 100 * $cl_sum_ok / $cl_sum_all );

$cl_busiest = array( 'label' => '', 'total' => 0 );
foreach ( $cl_series as $cl_s ) {
	if ( (int) $cl_s['total'] > (int) $cl_busiest['total'] ) {
		$cl_busiest = $cl_s;
	}
}

$cl_pages = max( 1, (int) ceil( $cl_total / $cl_per ) );

/**
 * The address a filtered view lives at, keeping the filters that are on.
 *
 * @param array $over Overrides.
 * @return string
 */
$cl_base = function ( $over = array() ) use ( $cl_who, $cl_ev, $cl_from, $cl_to ) {
	$args = array_filter(
		array_merge(
			array(
				'who'  => $cl_who,
				'ev'   => $cl_ev,
				'from' => $cl_from,
				'to'   => $cl_to,
			),
			$over
		),
		function ( $v ) {
			return '' !== $v && 0 !== $v;
		}
	);
	return CloakLink_Admin::url( 'activity' ) . ( $args ? '?' . http_build_query( $args ) : '' );
};
?>

<div class="cl-pagehead">
	<div>
		<h2 class="cl-pagehead__t"><?php esc_html_e( 'Desk activity', 'cloaklink' ); ?></h2>
		<p class="cl-pagehead__s"><?php esc_html_e( 'Every sign-in, sign-out and decision on the case desk, with the network and the device it came from.', 'cloaklink' ); ?></p>
	</div>
	<span class="cl-badge <?php echo $cl_live ? 'cl-badge--ok' : 'cl-badge--warn'; ?>">
		<span class="cl-dot <?php echo $cl_live ? 'is-ok' : ''; ?>" aria-hidden="true"></span>
		<?php
		echo esc_html(
			sprintf(
				/* translators: %d: number of people signed in */
				_n( '%d on the desk now', '%d on the desk now', count( $cl_live ), 'cloaklink' ),
				count( $cl_live )
			)
		);
		?>
	</span>
</div>

<?php if ( $cl_live && $cl_presence_on ) : ?>
	<section class="cl-panel cl-panel--full cl-now">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'On the desk now', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note"><?php esc_html_e( 'Signed in, and not signed out since.', 'cloaklink' ); ?></p>
		</header>
		<div class="cl-now__row">
			<?php foreach ( $cl_live as $cl_pid => $cl_p ) : ?>
				<?php
				$cl_ago = $cl_p['in'] ? human_time_diff( strtotime( (string) $cl_p['in'] ), current_time( 'timestamp' ) ) : '';
				$cl_nm  = isset( $cl_names[ $cl_pid ] ) ? $cl_names[ $cl_pid ] : __( 'Removed account', 'cloaklink' );
				?>
				<article class="cl-now__p">
					<span class="cl-now__av" aria-hidden="true"><?php echo esc_html( mb_substr( $cl_nm, 0, 1 ) ); ?></span>
					<div class="cl-now__in">
						<b><?php echo esc_html( $cl_nm ); ?></b>
						<span><?php echo esc_html( '' !== $cl_p['city'] ? $cl_p['city'] : ( '' !== $cl_p['ip'] ? $cl_p['ip'] : __( 'area not named', 'cloaklink' ) ) ); ?></span>
					</div>
					<span class="cl-now__since"><?php echo esc_html( sprintf( /* translators: %s: time ago */ __( '%s in', 'cloaklink' ), $cl_ago ) ); ?></span>
					<a class="cl-now__lnk" href="<?php echo esc_url( $cl_base( array( 'who' => $cl_pid ) ) ); ?>"><?php esc_html_e( 'History', 'cloaklink' ); ?></a>
				</article>
			<?php endforeach; ?>
		</div>
	</section>
<?php endif; ?>

<?php
// A door being tried against. The count is read from the log itself rather
// than kept as a second counter, so it cannot drift from the rows below it.
$cl_refused = $cl_watch_at > 0 ? $cl_log->refusals( 24 ) : 0;
?>
<?php if ( $cl_watch_at > 0 && $cl_refused >= $cl_watch_at ) : ?>
	<section class="cl-panel cl-panel--full cl-watchout" id="cl-watchout">
		<p class="cl-watchout__t">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of refused attempts */
					_n( '%d refused attempt in the last day', '%d refused attempts in the last day', $cl_refused, 'cloaklink' ),
					$cl_refused
				)
			);
			?>
		</p>
		<p class="cl-watchout__s">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: the operator's warning threshold */
					__( 'The warning is set at %d. Read the refusals below before the next shift.', 'cloaklink' ),
					$cl_watch_at
				)
			);
			?>
		</p>
		<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( $cl_base( array( 'ev' => 'signin_failed' ) ) ); ?>"><?php esc_html_e( 'See refused sign-ins', 'cloaklink' ); ?></a>
	</section>
<?php endif; ?>

<?php if ( $cl_kpis_on ) : ?>
<section class="cl-kpis cl-kpis--tight">
	<?php
	$cl_cards = array();
	foreach ( $cl_by_ev as $cl_ek => $cl_n ) {
		list( $cl_lbl, $cl_tone ) = CloakLink_Agent_Log::label( $cl_ek );
		$cl_cards[] = array( $cl_lbl, $cl_n, $cl_tone );
	}
	if ( ! $cl_cards ) {
		$cl_cards[] = array( __( 'Nothing logged yet', 'cloaklink' ), 0, 'muted' );
	}
	foreach ( $cl_cards as $cl_c ) :
		?>
		<article class="cl-kpi">
			<p class="cl-kpi__label"><?php echo esc_html( $cl_c[0] ); ?></p>
			<p class="cl-kpi__value cl-kpi__value--<?php echo esc_attr( $cl_c[2] ); ?>"><?php echo esc_html( number_format_i18n( (int) $cl_c[1] ) ); ?></p>
			<p class="cl-kpi__foot">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of days */
						_n( 'in the last day', 'in the last %d days', $cl_kpi_days, 'cloaklink' ),
						$cl_kpi_days
					)
				);
				?>
			</p>
		</article>
	<?php endforeach; ?>
</section>
<?php endif; ?>

<section class="cl-panel cl-panel--full" id="cl-shift">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'The shape of the shift', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of hours */
					__( 'every hour in the last %d, whether or not anything happened in it', 'cloaklink' ),
					$cl_hours
				)
			);
			?>
		</p>
		<span class="cl-shift__peak">
			<?php
			if ( (int) $cl_busiest['total'] > 0 ) {
				echo esc_html(
					sprintf(
						/* translators: 1: hour label, 2: number of entries */
						__( 'busiest %1$s — %2$s entries', 'cloaklink' ),
						(string) $cl_busiest['label'],
						number_format_i18n( (int) $cl_busiest['total'] )
					)
				);
			} else {
				esc_html_e( 'nothing logged in the window', 'cloaklink' );
			}
			?>
		</span>
	</header>
	<div class="cl-panel__body cl-shift__body">
		<?php
		// The bars.
		//
		// Every hour is drawn, including the empty ones. A chart that omits
		// its quiet hours compresses eight dead hours into nothing and makes
		// three bars look like a busy day. The height is a percentage of the
		// busiest hour, so the tallest bar always reaches the top and the rest
		// are read against it rather than against an arbitrary scale.
		//
		// The stack is work that went through at the bottom, waiting in the
		// middle, refusals on top — the order the eye reads: how it went, then
		// how much of it went wrong.
		?>
		<div class="cl-shift" role="img" aria-label="<?php esc_attr_e( 'Entries per hour in the log window', 'cloaklink' ); ?>">
			<?php foreach ( $cl_series as $cl_i => $cl_s ) : ?>
				<?php
				$cl_tot = (int) $cl_s['total'];
				$cl_h   = $cl_tot > 0 ? max( 3, (int) round( 100 * $cl_tot / $cl_peak ) ) : 0;
				$cl_ok  = (int) $cl_s['ok'];
				$cl_wn  = (int) $cl_s['warn'];
				$cl_nb  = (int) $cl_s['no'];
				$cl_den = max( 1, $cl_tot );
				// A tick label every few hours only. One per column is a
				// smudge at any width a laptop has.
				$cl_tick = ( 0 === ( $cl_i % max( 1, (int) ceil( count( $cl_series ) / 8 ) ) ) );
				?>
				<span class="cl-shift__col<?php echo $cl_tot > 0 ? ' has-data' : ''; ?>"
					title="<?php echo esc_attr( sprintf( /* translators: 1: hour, 2: total, 3: done, 4: waiting, 5: refused */ __( '%1$s — %2$d entries: %3$d done, %4$d waiting, %5$d refused', 'cloaklink' ), (string) $cl_s['label'], $cl_tot, $cl_ok, $cl_wn, $cl_nb ) ); ?>">
					<span class="cl-shift__bar" style="--cl-h:<?php echo esc_attr( (string) $cl_h ); ?>%">
						<?php if ( $cl_tot > 0 ) : ?>
							<i class="is-no" style="height:<?php echo esc_attr( (string) ( 100 * $cl_nb / $cl_den ) ); ?>%"></i>
							<i class="is-warn" style="height:<?php echo esc_attr( (string) ( 100 * $cl_wn / $cl_den ) ); ?>%"></i>
							<i class="is-ok" style="height:<?php echo esc_attr( (string) ( 100 * $cl_ok / $cl_den ) ); ?>%"></i>
						<?php endif; ?>
					</span>
					<span class="cl-shift__tick"><?php echo $cl_tick ? esc_html( (string) $cl_s['label'] ) : ''; ?></span>
				</span>
			<?php endforeach; ?>
		</div>

		<div class="cl-shift__keys">
			<span class="cl-shift__key is-ok"><?php esc_html_e( 'done', 'cloaklink' ); ?></span>
			<span class="cl-shift__key is-warn"><?php esc_html_e( 'waiting', 'cloaklink' ); ?></span>
			<span class="cl-shift__key is-no"><?php esc_html_e( 'refused', 'cloaklink' ); ?></span>
			<span class="cl-shift__key is-ratio">
				<b><?php echo esc_html( (string) $cl_ok_pct ); ?>%</b>
				<?php esc_html_e( 'of it went through', 'cloaklink' ); ?>
			</span>
		</div>
	</div>
</section>

<?php if ( $cl_leaders ) : ?>
<section class="cl-panel cl-panel--full" id="cl-people">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Who is doing the work', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of days */
					_n( 'most active in the last day', 'most active in the last %d days', $cl_kpi_days, 'cloaklink' ),
					$cl_kpi_days
				)
			);
			?>
		</p>
	</header>
	<div class="cl-panel__body cl-panel__body--flush">
		<ul class="cl-people">
			<?php
			$cl_top = max( 1, (int) ( $cl_leaders[0]['n'] ?? 1 ) );
			foreach ( $cl_leaders as $cl_l ) :
				$cl_lid  = (int) $cl_l['id'];
				$cl_lnm  = isset( $cl_names[ $cl_lid ] ) ? $cl_names[ $cl_lid ] : __( 'Removed account', 'cloaklink' );
				$cl_is_live = isset( $cl_live[ $cl_lid ] );
				$cl_last = isset( $cl_dormant[ $cl_lid ] ) ? (string) $cl_dormant[ $cl_lid ] : '';
				$cl_pct  = (int) round( 100 * (int) $cl_l['n'] / $cl_top );
				?>
				<li class="cl-people__one<?php echo $cl_is_live ? ' is-live' : ''; ?>">
					<span class="cl-people__av" aria-hidden="true"><?php echo esc_html( mb_substr( $cl_lnm, 0, 1 ) ); ?></span>
					<span class="cl-people__nm">
						<b><?php echo esc_html( $cl_lnm ); ?></b>
						<span>
							<?php
							if ( $cl_is_live ) {
								esc_html_e( 'at a desk now', 'cloaklink' );
							} elseif ( '' !== $cl_last ) {
								echo esc_html(
									sprintf(
										/* translators: %s: time ago */
										__( 'last action %s ago', 'cloaklink' ),
										human_time_diff( strtotime( $cl_last ), current_time( 'timestamp' ) )
									)
								);
							} else {
								esc_html_e( 'nothing in the window', 'cloaklink' );
							}
							?>
						</span>
					</span>
					<span class="cl-people__bar" aria-hidden="true"><i style="--cl-w:<?php echo esc_attr( (string) $cl_pct ); ?>%"></i></span>
					<span class="cl-people__n"><b><?php echo esc_html( number_format_i18n( (int) $cl_l['n'] ) ); ?></b> <?php esc_html_e( 'actions', 'cloaklink' ); ?></span>
					<?php if ( (int) $cl_l['no'] > 0 ) : ?>
						<span class="cl-people__no" title="<?php esc_attr_e( 'Refused attempts on this account', 'cloaklink' ); ?>"><?php echo esc_html( number_format_i18n( (int) $cl_l['no'] ) ); ?> <?php esc_html_e( 'refused', 'cloaklink' ); ?></span>
					<?php endif; ?>
					<a class="cl-people__lnk" href="<?php echo esc_url( $cl_base( array( 'who' => $cl_lid ) ) ); ?>"><?php esc_html_e( 'History', 'cloaklink' ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php endif; ?>

<section class="cl-panel cl-panel--full" id="cl-log">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'The log', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of rows */
					_n( '%d entry', '%d entries', $cl_total, 'cloaklink' ),
					$cl_total
				)
			);
			?>
		</p>
		<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( $cl_base( array( 'cl_export' => 'activity' ) ), 'cloaklink_export', 'cl_nonce' ) ); ?>"><?php esc_html_e( 'Export CSV', 'cloaklink' ); ?></a>
	</header>

	<form class="cl-logfilter<?php echo $cl_sticky ? ' cl-logfilter--sticky' : ''; ?>" method="get" action="<?php echo esc_url( CloakLink_Admin::url( 'activity' ) ); ?>">
		<label class="cl-field">
			<span class="cl-label"><?php esc_html_e( 'Person', 'cloaklink' ); ?></span>
			<select class="cl-input" name="who">
				<option value="0"><?php esc_html_e( 'Everyone', 'cloaklink' ); ?></option>
				<?php foreach ( $cl_all as $cl_a ) : ?>
					<option value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>" <?php selected( $cl_who, (int) $cl_a['id'] ); ?>>
						<?php echo esc_html( $cl_a['name'] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="cl-field">
			<span class="cl-label"><?php esc_html_e( 'Event', 'cloaklink' ); ?></span>
			<select class="cl-input" name="ev">
				<option value=""><?php esc_html_e( 'Everything', 'cloaklink' ); ?></option>
				<?php foreach ( $cl_events as $cl_key => $cl_meta ) : ?>
					<option value="<?php echo esc_attr( $cl_key ); ?>" <?php selected( $cl_ev, $cl_key ); ?>>
						<?php echo esc_html( $cl_meta[0] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="cl-field">
			<span class="cl-label"><?php esc_html_e( 'From', 'cloaklink' ); ?></span>
			<input class="cl-input" type="date" name="from" value="<?php echo esc_attr( $cl_from ); ?>">
		</label>

		<label class="cl-field">
			<span class="cl-label"><?php esc_html_e( 'To', 'cloaklink' ); ?></span>
			<input class="cl-input" type="date" name="to" value="<?php echo esc_attr( $cl_to ); ?>">
		</label>

		<div class="cl-logfilter__acts">
			<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Apply', 'cloaklink' ); ?></button>
			<?php if ( $cl_who || $cl_ev || $cl_from || $cl_to ) : ?>
				<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( CloakLink_Admin::url( 'activity' ) ); ?>"><?php esc_html_e( 'Clear', 'cloaklink' ); ?></a>
			<?php endif; ?>
		</div>
	</form>

	<?php if ( ! $cl_rows ) : ?>
		<p class="cl-empty"><?php esc_html_e( 'Nothing in the log for that. A sign-in writes the first entry.', 'cloaklink' ); ?></p>
	<?php else : ?>
		<div class="cl-log<?php echo $cl_dayheads ? ' cl-log--days' : ''; ?><?php echo $cl_device_on ? '' : ' cl-log--nodev'; ?>">
			<?php
			$cl_prevday = '';
			foreach ( $cl_rows as $cl_r ) :
				$cl_day = CloakLink_Admin::stamp( $cl_r['created_at'], 'Y-m-d' );

				// A heading only where the day turns. The first row needs one as
				// much as any later row, because the list may start mid-week, so
				// the empty first value is not a day and always prints.
				if ( $cl_dayheads && $cl_day !== $cl_prevday ) :
					?>
					<h3 class="cl-log__day">
						<span><?php echo esc_html( CloakLink_Admin::stamp( $cl_r['created_at'], 'l, j F Y' ) ); ?></span>
					</h3>
					<?php
				endif;
				$cl_prevday = $cl_day;

				list( $cl_lbl, $cl_tone ) = CloakLink_Agent_Log::label( (string) $cl_r['event'] );
				$cl_rid  = (int) $cl_r['agent_id'];
				$cl_rnm  = isset( $cl_names[ $cl_rid ] ) ? $cl_names[ $cl_rid ] : '';
				$cl_place = trim( (string) $cl_r['city'] . ( '' !== (string) $cl_r['city'] && '' !== (string) $cl_r['country_code'] ? ', ' : '' ) . (string) $cl_r['country_code'] );
				$cl_ip   = CloakLink_Agent_Log::ip_for_display( (string) $cl_r['ip'], $cl_ip_style );
				?>
				<article class="cl-log__r<?php echo $cl_tone_on ? ' cl-log__r--' . esc_attr( $cl_tone ) : ''; ?>">
					<span class="cl-log__t" aria-hidden="true">
						<b><?php echo esc_html( CloakLink_Admin::stamp( $cl_r['created_at'], $cl_time_fmt ) ); ?></b>
						<i><?php echo esc_html( CloakLink_Admin::stamp( $cl_r['created_at'], 'j M' ) ); ?></i>
					</span>

					<span class="cl-log__ev">
						<b><?php echo esc_html( $cl_lbl ); ?></b>
						<?php if ( $cl_detail_on && '' !== (string) $cl_r['detail'] ) : ?>
							<i><?php echo esc_html( $cl_r['detail'] ); ?></i>
						<?php endif; ?>
					</span>

					<span class="cl-log__who">
						<?php if ( '' !== $cl_rnm ) : ?>
							<?php if ( $cl_namelink ) : ?>
								<a href="<?php echo esc_url( $cl_base( array( 'who' => $cl_rid ) ) ); ?>"><?php echo esc_html( $cl_rnm ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $cl_rnm ); ?>
							<?php endif; ?>
						<?php else : ?>
							<span class="cl-dim"><?php esc_html_e( 'No account', 'cloaklink' ); ?></span>
						<?php endif; ?>
					</span>

					<span class="cl-log__from">
						<?php echo esc_html( '' !== $cl_place ? $cl_place : __( 'area not named', 'cloaklink' ) ); ?>
						<?php if ( '' !== $cl_ip ) : ?>
							<i class="cl-mono"><?php echo esc_html( $cl_ip ); ?></i>
						<?php endif; ?>
					</span>

					<?php if ( $cl_device_on ) : ?>
						<span class="cl-log__dev">
							<?php
							$cl_dev = array_filter(
								array(
									(string) $cl_r['device'],
									(string) $cl_r['browser'],
									$cl_system_on ? (string) $cl_r['os'] : '',
								)
							);
							echo esc_html( $cl_dev ? implode( ' · ', $cl_dev ) : '—' );
							?>
						</span>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>

		<?php if ( $cl_pages > 1 ) : ?>
			<nav class="cl-pager" aria-label="<?php esc_attr_e( 'Log pages', 'cloaklink' ); ?>">
				<?php if ( $cl_page > 1 ) : ?>
					<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( $cl_base( array( 'paged' => $cl_page - 1 ) ) ); ?>"><?php esc_html_e( 'Newer', 'cloaklink' ); ?></a>
				<?php endif; ?>
				<span class="cl-pager__n">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: current page, 2: total pages */
							__( 'Page %1$d of %2$d', 'cloaklink' ),
							$cl_page,
							$cl_pages
						)
					);
					?>
				</span>
				<?php if ( $cl_page < $cl_pages ) : ?>
					<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( $cl_base( array( 'paged' => $cl_page + 1 ) ) ); ?>"><?php esc_html_e( 'Older', 'cloaklink' ); ?></a>
				<?php endif; ?>
			</nav>
		<?php endif; ?>
	<?php endif; ?>
</section>

<?php
// The switches for this screen live at its foot, as they do on every other
// screen: under the work, folded, so the reading is not interrupted by the
// controls that shape it.
cloaklink()->adv->render_group(
	'activity',
	__( 'Desk activity controls', 'cloaklink' ),
	__( 'How the record is read, printed and exported.', 'cloaklink' ),
	'activity',
	true
);
?>
