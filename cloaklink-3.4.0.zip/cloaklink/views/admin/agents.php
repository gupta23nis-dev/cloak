<?php
/**
 * Case agents.
 *
 * The operator's side of the desk the agents use. It has three jobs and no
 * more: create an agent (a username, a password, and optionally a six-digit
 * code), switch one off or remove one, and see every ticket raised, with the
 * count of what its link captured.
 *
 * Removing a ticket here removes it from the agent's panel as well, because
 * both screens read the same row. Removing an agent takes their tickets and
 * the links those tickets made: a link whose owner no longer exists is a link
 * nobody can see or clear from either side.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_agents = cloaklink()->agents;
$cl_all    = $cl_agents->all();
$cl_tix    = $cl_agents->all_tickets();
$cl_counts = $cl_agents->counts();

// Who is on the desk right now, and when each person last arrived and left.
// One read for the whole table: the presence map is built from the activity
// log's newest sign-in and sign-out per person, which is the same answer the
// Desk activity screen shows.
$cl_pres = cloaklink()->agent_log->presence();
$cl_policy = cloaklink()->agent_policy;
$cl_paused_any = $cl_policy->desk_paused();

// How much each ticket's link has captured, in one query for the whole table.
$cl_per_link = $cl_agents->capture_counts( wp_list_pluck( $cl_tix, 'link_id' ) );
foreach ( $cl_tix as $cl_i => $cl_row ) {
	$cl_tix[ $cl_i ]['captures'] = isset( $cl_per_link[ (int) $cl_row['link_id'] ] ) ? (int) $cl_per_link[ (int) $cl_row['link_id'] ] : 0;
}
$cl_by_agent = array();
foreach ( $cl_tix as $cl_row ) {
	$cl_aid = (int) $cl_row['agent_id'];
	if ( ! isset( $cl_by_agent[ $cl_aid ] ) ) {
		$cl_by_agent[ $cl_aid ] = array(
			'name'     => '' !== (string) $cl_row['agent_name'] ? (string) $cl_row['agent_name'] : __( 'Removed agent', 'cloaklink' ),
			'total'    => 0,
			'waiting'  => 0,
			'captured' => 0,
			'last'     => '',
		);
	}
	$cl_by_agent[ $cl_aid ]['total']++;
	if ( ! $cl_agents->is_allowed( $cl_row ) ) {
		$cl_by_agent[ $cl_aid ]['waiting']++;
	}
	$cl_by_agent[ $cl_aid ]['captured'] += (int) $cl_row['captures'];
	if ( '' === $cl_by_agent[ $cl_aid ]['last'] ) {
		$cl_by_agent[ $cl_aid ]['last'] = (string) $cl_row['created_at'];
	}
}
uasort(
	$cl_by_agent,
	function ( $a, $b ) {
		return $b['total'] <=> $a['total'];
	}
);

$cl_hello  = isset( $_GET['cl_agent_msg'] ) ? sanitize_key( wp_unslash( $_GET['cl_agent_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

$cl_words = CloakLink_Admin::agent_words();

$cl_msg = isset( $cl_words[ $cl_hello ] ) ? $cl_words[ $cl_hello ] : null;

// How many the last action actually covered, where the handler reported it.
// "The selected tickets are gone" leaves an operator counting the list to be
// sure nothing else went with them; "3 tickets are gone" does not.
$cl_gone = isset( $_GET['cl_gone'] ) ? absint( $_GET['cl_gone'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
if ( $cl_msg && $cl_gone > 0 && 'tickets_deleted' === $cl_hello ) {
	$cl_msg[1] = sprintf(
		/* translators: %d: how many tickets were removed */
		_n( '%d ticket and its link are gone, on both sides.', '%d tickets and their links are gone, on both sides.', $cl_gone, 'cloaklink' ),
		$cl_gone
	);
}

$cl_desk = $cl_agents->url();
?>

<div class="cl-pagehead cl-pagehead--tight">
	<div>
		<h2 class="cl-pagehead__t"><?php esc_html_e( 'Case agents', 'cloaklink' ); ?></h2>
		<p class="cl-pagehead__s">
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: admins, 2: agents, 3: how many can sign in */
					__( '%1$d admin · %2$d agents · %3$d can sign in now', 'cloaklink' ),
					(int) $cl_counts['admins'],
					(int) $cl_counts['agents'],
					(int) $cl_counts['active']
				)
			);
			?>
		</p>
	</div>
	<span class="cl-badge <?php echo $cl_counts['active'] ? 'cl-badge--ok' : 'cl-badge--warn'; ?>">
		<?php echo esc_html( sprintf( /* translators: 1: active people, 2: total people */ __( '%1$d of %2$d active', 'cloaklink' ), (int) $cl_counts['active'], (int) $cl_counts['total'] ) ); ?>
	</span>
</div>

<?php if ( $cl_msg ) : ?>
	<p class="cl-flash cl-flash--<?php echo esc_attr( $cl_msg[0] ); ?>"><?php echo esc_html( $cl_msg[1] ); ?></p>
<?php endif; ?>

<?php
// Three tabs, because the screen had grown into one long page: creating a
// person, the rules that govern the desk, and the queue itself are three
// different jobs, done at three different times. Stacking them meant the
// operator scrolled past two screens of other work to reach the third.
$cl_tab = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

// The ticket ledger, read once for the whole screen.
//
// This is the record that outlives a ticket. A ticket row is deleted when
// somebody removes it, and the removal is the moment an operator most wants
// to be able to look up afterwards — who did it, when, from where, and what
// the ticket said. The tab below prints it; the counts on the tab come from
// the same read, so the header and the list cannot disagree.
$cl_ticket_log = cloaklink()->ticket_log;
$cl_ledger_from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_ledger_to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_ledger_what = isset( $_GET['what'] ) ? sanitize_key( wp_unslash( $_GET['what'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_ledger_who  = isset( $_GET['who'] ) ? absint( $_GET['who'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$cl_ledger_args = array_filter(
	array(
		'from'   => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $cl_ledger_from ) ? $cl_ledger_from : '',
		'to'     => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $cl_ledger_to ) ? $cl_ledger_to : '',
		'event'  => in_array( $cl_ledger_what, array( 'raised', 'allowed', 'held', 'removed' ), true ) ? $cl_ledger_what : '',
		'person' => $cl_ledger_who,
	)
);
$cl_ledger      = $cl_ticket_log ? $cl_ticket_log->tallies( $cl_ledger_args ) : array( 'total' => 0, 'raised' => 0, 'allowed' => 0, 'held' => 0, 'removed' => 0 );
$cl_ledger_rows = $cl_ticket_log ? $cl_ticket_log->rows( array_merge( $cl_ledger_args, array( 'max' => 200 ) ) ) : array();
if ( ! in_array( $cl_tab, array( 'people', 'rules', 'tickets', 'history' ), true ) ) {
	// A link that narrows the queue to one person is asking for the queue.
	$cl_tab = isset( $_GET['agent'] ) ? 'tickets' : 'people'; // phpcs:ignore WordPress.Security.NonceVerification
}

// The desk at a glance. It is the same question whatever tab is open: who is
// at a desk right now, what is waiting on the office, and what has come back
// in the last hour. Everything here is read, not asked — the numbers and the
// names, nothing that needs a decision.
$cl_desk_live = array();
foreach ( (array) $cl_pres as $cl_dp_id => $cl_dp ) {
	if ( ! empty( $cl_dp['live'] ) ) {
		$cl_desk_live[ (int) $cl_dp_id ] = $cl_dp;
	}
}

$cl_desk_waiting = 0;
$cl_desk_tracing = 0;
$cl_desk_recent  = 0;
$cl_desk_people  = array();

// Links that are live right now. A link that has expired, been stopped or
// been deleted is not carrying anybody, so it is not one of these.
$cl_desk_active_links = (int) cloaklink()->db->count_links( array( 'status' => 'active' ) );
foreach ( $cl_all as $cl_a_row ) {
	$cl_desk_people[ (int) $cl_a_row['id'] ] = (string) $cl_a_row['name'];
}
$cl_desk_now = current_time( 'timestamp' );
foreach ( (array) $cl_tix as $cl_dr ) {
	if ( $cl_agents->is_allowed( $cl_dr ) ) {
		$cl_desk_tracing++;
	} else {
		$cl_desk_waiting++;
	}
	$cl_when = strtotime( (string) $cl_dr['created_at'] );
	if ( $cl_when && ( $cl_desk_now - $cl_when ) < 3600 ) {
		$cl_desk_recent++;
	}
}

// The most recent captures on the whole desk, so this strip and the agent's
// own panel never disagree about what has just come in.
$cl_desk_visits = cloaklink()->db->recent_visits( 0, 4 );
?>
<section class="cl-deskstrip">
	<header class="cl-deskstrip__head">
		<h3 class="cl-deskstrip__t">
			<span class="cl-deskstrip__pulse" aria-hidden="true"></span>
			<?php esc_html_e( 'Smart monitoring desk', 'cloaklink' ); ?>
		</h3>
		<span class="cl-deskstrip__live"><?php echo esc_html( sprintf( /* translators: %d: people at a desk */ _n( '%d at a desk now', '%d at a desk now', count( $cl_desk_live ), 'cloaklink' ), count( $cl_desk_live ) ) ); ?></span>
	</header>

	<div class="cl-deskstrip__body">
		<!-- The three numbers that ask for a decision, then the people who
		     can act on them. Everything else about the desk lives in the
		     tabs below; this strip exists to answer "is anything waiting on
		     me, and is anybody there to take it". -->
		<div class="cl-deskstrip__side">
			<div class="cl-deskstrip__cell<?php echo $cl_desk_waiting ? ' is-hot' : ''; ?>">
				<p class="cl-deskstrip__n"><?php echo esc_html( number_format_i18n( $cl_desk_waiting ) ); ?></p>
				<p class="cl-deskstrip__l"><?php esc_html_e( 'In que', 'cloaklink' ); ?></p>
			</div>
			<div class="cl-deskstrip__cell">
				<p class="cl-deskstrip__n"><?php echo esc_html( number_format_i18n( $cl_desk_tracing ) ); ?></p>
				<p class="cl-deskstrip__l"><?php esc_html_e( 'Tracing', 'cloaklink' ); ?></p>
				<?php
				// How many links are live right now, said in the unit an
				// operator actually thinks in — devices standing on them.
				// A link that has expired or been stopped is not carrying
				// anybody, so it is not counted.
				?>
				<p class="cl-deskstrip__dev"><?php echo esc_html( sprintf( /* translators: %d: number of active links */ _n( '%d Device', '%d Devices', $cl_desk_active_links, 'cloaklink' ), $cl_desk_active_links ) ); ?></p>
			</div>
			<div class="cl-deskstrip__cell">
				<p class="cl-deskstrip__n"><?php echo esc_html( number_format_i18n( $cl_desk_recent ) ); ?></p>
				<p class="cl-deskstrip__l"><?php esc_html_e( 'This hour', 'cloaklink' ); ?></p>
			</div>
		</div>

		<div class="cl-deskstrip__side cl-deskstrip__side--right">
			<?php
			// The head already says how many are at a desk, so the body does
			// not repeat it: either there are names to show, or there is
			// nothing to say and the space belongs to what just came in.
			if ( $cl_desk_live ) :
				?>
				<div class="cl-deskstrip__people">
					<?php foreach ( array_slice( $cl_desk_live, 0, 6, true ) as $cl_dp_id => $cl_dp ) : ?>
						<?php
						$cl_dp_name = isset( $cl_desk_people[ (int) $cl_dp_id ] ) ? $cl_desk_people[ (int) $cl_dp_id ] : __( 'Removed', 'cloaklink' );
						?>
						<span class="cl-deskstrip__who" title="<?php echo esc_attr( $cl_dp_name ); ?>">
							<span class="cl-deskstrip__av" aria-hidden="true"><?php echo esc_html( mb_substr( $cl_dp_name, 0, 1 ) ); ?></span>
							<?php echo esc_html( $cl_dp_name ); ?>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $cl_desk_visits ) : ?>
				<span class="cl-deskstrip__feed-h"><?php esc_html_e( 'Last captures', 'cloaklink' ); ?></span>
				<ul class="cl-deskstrip__feed">
					<?php foreach ( array_slice( (array) $cl_desk_visits, 0, 3 ) as $cl_dv ) : ?>
						<li>
							<?php
							$cl_dv_title = (string) $cl_dv['slug'];
							foreach ( (array) $cl_tix as $cl_dt ) {
								if ( (int) $cl_dt['link_id'] === (int) $cl_dv['link_id'] && '' !== (string) $cl_dt['person'] ) {
									$cl_dv_title = (string) $cl_dt['person'];
									break;
								}
							}
							?>
							<b><?php echo esc_html( $cl_dv_title ); ?></b>
							<span><?php echo esc_html( CloakLink_Admin::stamp( $cl_dv['created_at'], 'g:i A' ) ); ?></span>
							<em><?php echo esc_html( '' !== (string) $cl_dv['city'] ? $cl_dv['city'] : __( 'area not named', 'cloaklink' ) ); ?></em>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</div>
</section>

<?php
// The tabs. Each one is a real address (?view=...), so a reload, a bookmark
// and a message saying "look at the tickets" all land on the same panel.
//
// They were anchors: pressing one jumped down a page that was drawing all
// four sections at once, so the operator scrolled through People, the tickets
// and the whole ticket ledger to reach the one thing they asked for. Only the
// chosen panel is rendered visible now; the rest are one press away.
$cl_tabs = array(
	'people'  => array( __( 'People', 'cloaklink' ), number_format_i18n( count( $cl_all ) ) ),
	'tickets' => array( __( 'Tickets', 'cloaklink' ), number_format_i18n( count( $cl_tix ) ) ),
	'history' => array( __( 'History', 'cloaklink' ), number_format_i18n( $cl_ledger['total'] ) ),
);
?>
<nav class="cl-jump cl-jump--tabs" aria-label="<?php esc_attr_e( 'Case agents sections', 'cloaklink' ); ?>">
	<?php foreach ( $cl_tabs as $cl_tkey => $cl_tdef ) : ?>
		<a class="cl-jump__b<?php echo $cl_tkey === $cl_tab ? ' is-on' : ''; ?>"
			href="<?php echo esc_url( CloakLink_Admin::url( 'agents', array( 'view' => $cl_tkey ) ) ); ?>"
			aria-current="<?php echo $cl_tkey === $cl_tab ? 'page' : 'false'; ?>"
			aria-selected="<?php echo $cl_tkey === $cl_tab ? 'true' : 'false'; ?>">
			<span class="cl-jump__t"><?php echo esc_html( $cl_tdef[0] ); ?></span>
			<span class="cl-jump__n"><?php echo esc_html( $cl_tdef[1] ); ?></span>
		</a>
	<?php endforeach; ?>
	<?php
	// The answer to "where did all of it go". The ticket tabs above show the
	// requests; All records shows what those requests actually brought back,
	// across every link at once, with a search. It is a page of its own
	// rather than a fourth tab because it is not about any one ticket.
	?>
	<a class="cl-jump__b cl-jump__b--out" href="<?php echo esc_url( CloakLink_Admin::url( 'records' ) ); ?>">
		<span class="cl-jump__t"><?php esc_html_e( 'All records', 'cloaklink' ); ?></span>
		<span class="cl-jump__n"><?php esc_html_e( 'every capture', 'cloaklink' ); ?></span>
	</a>
	<a class="cl-jump__b cl-jump__b--out" href="<?php echo esc_url( CloakLink_Admin::url( 'settings' ) . '#cl-deskrules' ); ?>">
		<span class="cl-jump__t"><?php esc_html_e( 'Desk rules', 'cloaklink' ); ?></span>
		<?php if ( $cl_paused_any ) : ?>
			<span class="cl-jump__flag"><?php esc_html_e( 'paused', 'cloaklink' ); ?></span>
		<?php endif; ?>
	</a>
</nav>

<div class="cl-tabpanel" data-panel="people" id="cl-sec-people"<?php echo 'people' === $cl_tab ? '' : ' hidden'; ?>>

<!-- The agents -->
<?php
// One card per person.
//
// This was an eight-column table, and the table was the problem: a row that
// has to carry a name, a username, a role, a code, a presence, two
// timestamps, a status and four buttons cannot be read across on a laptop,
// and every row's edit form and rules form had to be folded out of it as a
// second table row. A card holds the same facts and reads top to bottom —
// who they are, what they can do, where they are now, what to do about it —
// and the forms open inside the card they belong to.
if ( ! function_exists( 'cl_agent_num' ) ) {
	/**
	 * A number, or a dash when it is nothing.
	 *
	 * @param int $n Number.
	 * @return string
	 */
	function cl_agent_num( $n ) {
		$n = (int) $n;
		return $n > 0 ? number_format_i18n( $n ) : '—';
	}
}
?>
<section class="cl-people" id="cl-people">

	<?php if ( ! $cl_all ) : ?>
		<div class="cl-panel__body"><p class="cl-empty"><?php esc_html_e( 'No agents yet. Add one above, and the door is ready.', 'cloaklink' ); ?></p></div>
	<?php else : ?>
		<div class="cl-people__grid">
			<?php foreach ( $cl_all as $cl_a ) : ?>
				<?php
				$cl_live_a = 'active' === (string) $cl_a['status'];
				$cl_is_adm = cloaklink()->agents->is_admin( $cl_a );
				$cl_p      = isset( $cl_pres[ (int) $cl_a['id'] ] ) ? $cl_pres[ (int) $cl_a['id'] ] : null;
				$cl_on     = $cl_p && ! empty( $cl_p['live'] );
				$cl_quot   = isset( $cl_a['quota'] ) ? (int) $cl_a['quota'] : 0;
				$cl_exp    = isset( $cl_a['expires_at'] ) ? (string) $cl_a['expires_at'] : '';
				$cl_force  = ! empty( $cl_a['must_change'] );
				$cl_pwage  = $cl_policy->password_age( $cl_a );
				$cl_own     = isset( $cl_by_agent[ (int) $cl_a['id'] ] ) ? $cl_by_agent[ (int) $cl_a['id'] ] : null;
				$cl_init_a = '';
				foreach ( preg_split( '/\s+/', trim( (string) $cl_a['name'] ) ) as $cl_word ) {
					if ( '' !== $cl_word ) {
						$cl_init_a .= mb_strtoupper( mb_substr( $cl_word, 0, 1 ) );
					}
					if ( mb_strlen( $cl_init_a ) >= 2 ) {
						break;
					}
				}
				if ( '' === $cl_init_a ) {
					$cl_init_a = mb_strtoupper( mb_substr( (string) $cl_a['username'], 0, 1 ) );
				}
				?>
				<article class="cl-person2<?php echo $cl_live_a ? '' : ' is-off'; ?>" data-person="<?php echo (int) $cl_a['id']; ?>">

					<header class="cl-person2__top">
						<span class="cl-person2__av<?php echo $cl_on ? ' is-now' : ''; ?>" aria-hidden="true"><?php echo esc_html( $cl_init_a ); ?></span>
						<div class="cl-person2__id">
							<h3 class="cl-person2__name"><?php echo esc_html( $cl_a['name'] ); ?></h3>
							<p class="cl-person2__user"><code class="cl-mono"><?php echo esc_html( $cl_a['username'] ); ?></code></p>
						</div>
						<span class="cl-person2__role <?php echo $cl_is_adm ? 'is-adm' : 'is-agent'; ?>">
							<?php echo $cl_is_adm ? esc_html__( 'Admin', 'cloaklink' ) : esc_html__( 'Agent', 'cloaklink' ); ?>
						</span>
					</header>

					<div class="cl-person2__facts">
						<div class="cl-person2__fact">
							<span class="cl-person2__k"><?php esc_html_e( 'Right now', 'cloaklink' ); ?></span>
							<span class="cl-person2__v">
								<?php if ( $cl_on ) : ?>
									<span class="cl-here is-now"><span class="cl-dot is-ok" aria-hidden="true"></span><?php esc_html_e( 'Available', 'cloaklink' ); ?></span>
								<?php else : ?>
									<span class="cl-here is-off"><span class="cl-dot" aria-hidden="true"></span><?php esc_html_e( 'Offline', 'cloaklink' ); ?></span>
								<?php endif; ?>
							</span>
						</div>
						<div class="cl-person2__fact">
							<span class="cl-person2__k"><?php esc_html_e( 'Last in', 'cloaklink' ); ?></span>
							<span class="cl-person2__v cl-mono">
								<?php
								if ( $cl_p && '' !== (string) $cl_p['in'] ) {
									echo esc_html( CloakLink_Admin::stamp( $cl_p['in'], 'j M, H:i' ) );
								} elseif ( ! empty( $cl_a['last_login'] ) ) {
									echo esc_html( CloakLink_Admin::stamp( $cl_a['last_login'], 'j M, H:i' ) );
								} else {
									echo '<span class="cl-dim">—</span>';
								}
								?>
							</span>
						</div>
						<div class="cl-person2__fact">
							<span class="cl-person2__k"><?php esc_html_e( 'Last out', 'cloaklink' ); ?></span>
							<span class="cl-person2__v cl-mono">
								<?php echo ( $cl_p && '' !== (string) $cl_p['out'] ) ? esc_html( CloakLink_Admin::stamp( $cl_p['out'], 'j M, H:i' ) ) : '<span class="cl-dim">—</span>'; ?>
							</span>
						</div>
						<div class="cl-person2__fact">
							<span class="cl-person2__k"><?php esc_html_e( 'Signed in from', 'cloaklink' ); ?></span>
							<span class="cl-person2__v cl-mono">
								<?php
								if ( $cl_on && '' !== (string) $cl_p['ip'] ) {
									echo esc_html( trim( (string) $cl_p['city'] . ( '' !== (string) $cl_p['city'] ? ' · ' : '' ) . (string) $cl_p['ip'] ) );
								} else {
									echo '<span class="cl-dim">—</span>';
								}
								?>
							</span>
						</div>
					</div>

					<div class="cl-person2__nums">
						<span><b><?php echo esc_html( cl_agent_num( $cl_own ? $cl_own['total'] : 0 ) ); ?></b><?php esc_html_e( 'tickets', 'cloaklink' ); ?></span>
						<span><b><?php echo esc_html( cl_agent_num( $cl_own ? $cl_own['waiting'] : 0 ) ); ?></b><?php esc_html_e( 'in que', 'cloaklink' ); ?></span>
						<span><b><?php echo esc_html( cl_agent_num( $cl_own ? $cl_own['captured'] : 0 ) ); ?></b><?php esc_html_e( 'records', 'cloaklink' ); ?></span>
					</div>

					<div class="cl-person2__flags">
						<span class="cl-status <?php echo $cl_live_a ? 'cl-status--active' : 'cl-status--paused'; ?>">
							<?php echo $cl_live_a ? esc_html__( 'Active', 'cloaklink' ) : esc_html__( 'Switched off', 'cloaklink' ); ?>
						</span>
						<?php if ( '' !== (string) $cl_a['code_hash'] ) : ?>
							<span class="cl-tix__tag"><?php esc_html_e( 'Code set', 'cloaklink' ); ?></span>
						<?php endif; ?>
						<?php if ( $cl_quot ) : ?>
							<span class="cl-tix__tag"><?php echo esc_html( sprintf( /* translators: %d: daily cap */ __( 'Cap %d/day', 'cloaklink' ), $cl_quot ) ); ?></span>
						<?php endif; ?>
						<?php if ( '' !== (string) $cl_a['ip_lock'] ) : ?>
							<span class="cl-tix__tag"><?php esc_html_e( 'Network locked', 'cloaklink' ); ?></span>
						<?php endif; ?>
						<?php if ( $cl_exp && '0000-00-00 00:00:00' !== $cl_exp ) : ?>
							<span class="cl-tix__tag"><?php echo esc_html( sprintf( /* translators: %s: date */ __( 'Ends %s', 'cloaklink' ), CloakLink_Admin::stamp( $cl_exp, 'j M Y' ) ) ); ?></span>
						<?php endif; ?>
					</div>

					<div class="cl-person2__acts">
						<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" data-edit-toggle="<?php echo (int) $cl_a['id']; ?>" aria-expanded="false" aria-controls="cl-more-<?php echo (int) $cl_a['id']; ?>"><?php esc_html_e( 'Manage', 'cloaklink' ); ?></button>
						<?php if ( $cl_own ) : ?>
							<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( add_query_arg( array( 'view' => 'tickets', 'agent' => (int) $cl_a['id'] ), CloakLink_Admin::url( 'agents' ) ) . '#cl-tickets' ); ?>"><?php esc_html_e( 'Their tickets', 'cloaklink' ); ?></a>
						<?php endif; ?>
						<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( add_query_arg( array( 'who' => (int) $cl_a['id'] ), CloakLink_Admin::url( 'activity' ) ) ); ?>"><?php esc_html_e( 'Activity', 'cloaklink' ); ?></a>
					</div>

					<div class="cl-person2__more" id="cl-more-<?php echo (int) $cl_a['id']; ?>" data-edit-for="<?php echo (int) $cl_a['id']; ?>" hidden>

						<div class="cl-person2__block">
							<h4 class="cl-person2__h"><?php esc_html_e( 'Sign-in details', 'cloaklink' ); ?></h4>
							<form class="cl-person2__form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
								<input type="hidden" name="action" value="cloaklink_agent_action">
								<input type="hidden" name="cl_action" value="update">
								<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>">
								<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
								<label class="cl-label" for="cl-pw-<?php echo esc_attr( (string) $cl_a['id'] ); ?>"><?php esc_html_e( 'New password', 'cloaklink' ); ?></label>
								<input class="cl-input cl-input--sm" id="cl-pw-<?php echo esc_attr( (string) $cl_a['id'] ); ?>" name="cl_password" type="text" minlength="8" placeholder="<?php esc_attr_e( 'leave empty to keep', 'cloaklink' ); ?>">
								<label class="cl-label" for="cl-cd-<?php echo esc_attr( (string) $cl_a['id'] ); ?>"><?php esc_html_e( 'Access code', 'cloaklink' ); ?></label>
								<input class="cl-input cl-input--sm" id="cl-cd-<?php echo esc_attr( (string) $cl_a['id'] ); ?>" name="cl_code" type="text" inputmode="numeric" maxlength="6" placeholder="<?php esc_attr_e( 'six digits, or empty', 'cloaklink' ); ?>">
								<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Save', 'cloaklink' ); ?></button>
							</form>
						</div>

						<div class="cl-person2__block">
							<h4 class="cl-person2__h"><?php esc_html_e( 'Only for this person', 'cloaklink' ); ?></h4>
							<form class="cl-person2__form cl-person2__form--rules" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
								<input type="hidden" name="action" value="cloaklink_agent_action">
								<input type="hidden" name="cl_action" value="rules">
								<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>">
								<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>

								<label class="cl-label" for="cl-ipl-<?php echo esc_attr( (string) $cl_a['id'] ); ?>"><?php esc_html_e( 'Their networks', 'cloaklink' ); ?></label>
								<input class="cl-input cl-input--sm cl-input--mono" id="cl-ipl-<?php echo esc_attr( (string) $cl_a['id'] ); ?>" name="cl_ip_lock" type="text" value="<?php echo esc_attr( (string) $cl_a['ip_lock'] ); ?>" placeholder="<?php esc_attr_e( 'any network', 'cloaklink' ); ?>" title="<?php esc_attr_e( 'Addresses or CIDR blocks, separated by spaces. Empty means any network.', 'cloaklink' ); ?>">

								<label class="cl-label" for="cl-qt-<?php echo esc_attr( (string) $cl_a['id'] ); ?>"><?php esc_html_e( 'Daily cap', 'cloaklink' ); ?></label>
								<input class="cl-input cl-input--sm cl-input--num" id="cl-qt-<?php echo esc_attr( (string) $cl_a['id'] ); ?>" name="cl_quota" type="number" min="0" max="9999" value="<?php echo esc_attr( (string) $cl_quot ); ?>" placeholder="0">

								<label class="cl-label" for="cl-ex-<?php echo esc_attr( (string) $cl_a['id'] ); ?>"><?php esc_html_e( 'Account ends', 'cloaklink' ); ?></label>
								<input class="cl-input cl-input--sm" id="cl-ex-<?php echo esc_attr( (string) $cl_a['id'] ); ?>" name="cl_expires" type="date" value="<?php echo esc_attr( '' !== $cl_exp && '0000-00-00 00:00:00' !== $cl_exp ? CloakLink_Admin::stamp( $cl_exp, 'Y-m-d' ) : '' ); ?>">

								<label class="cl-check">
									<input type="checkbox" name="cl_must_change" value="1" <?php checked( $cl_force ); ?>>
									<span><?php esc_html_e( 'Must choose a new password', 'cloaklink' ); ?></span>
								</label>

								<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Save', 'cloaklink' ); ?></button>
								<span class="cl-help cl-help--inline">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: number of days */
											__( 'Password is %s old.', 'cloaklink' ),
											sprintf(
												/* translators: %d: days */
												_n( '%d day', '%d days', $cl_pwage, 'cloaklink' ),
												$cl_pwage
											)
										)
									);
									?>
								</span>
							</form>
						</div>

						<div class="cl-person2__block cl-person2__block--warn">
							<h4 class="cl-person2__h"><?php esc_html_e( 'Access and sessions', 'cloaklink' ); ?></h4>
							<div class="cl-person2__row">
								<form class="cl-inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="cloaklink_agent_action">
									<input type="hidden" name="cl_action" value="role">
									<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>">
									<input type="hidden" name="cl_role" value="<?php echo $cl_is_adm ? 'agent' : 'admin'; ?>">
									<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
									<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit"><?php echo $cl_is_adm ? esc_html__( 'Make agent', 'cloaklink' ) : esc_html__( 'Make admin', 'cloaklink' ); ?></button>
								</form>

								<form class="cl-inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="cloaklink_agent_action">
									<input type="hidden" name="cl_action" value="status">
									<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>">
									<input type="hidden" name="cl_status" value="<?php echo $cl_live_a ? 'paused' : 'active'; ?>">
									<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
									<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit"><?php echo $cl_live_a ? esc_html__( 'Switch off', 'cloaklink' ) : esc_html__( 'Switch on', 'cloaklink' ); ?></button>
								</form>

								<form class="cl-inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'End every session this person has open? They will have to sign in again.', 'cloaklink' ) ); ?>">
									<input type="hidden" name="action" value="cloaklink_agent_action">
									<input type="hidden" name="cl_action" value="cut">
									<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>">
									<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
									<button class="cl-btn cl-btn--ghost cl-btn--danger cl-btn--sm" type="submit"><?php echo $cl_on ? esc_html__( 'Sign out everywhere', 'cloaklink' ) : esc_html__( 'End their sessions', 'cloaklink' ); ?></button>
								</form>

								<form class="cl-inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Remove this agent? Their tickets and the links those tickets made are removed too.', 'cloaklink' ) ); ?>">
									<input type="hidden" name="action" value="cloaklink_agent_action">
									<input type="hidden" name="cl_action" value="delete">
									<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_a['id'] ); ?>">
									<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
									<button class="cl-btn cl-btn--ghost cl-btn--danger cl-btn--sm" type="submit"><?php esc_html_e( 'Remove person', 'cloaklink' ); ?></button>
								</form>
							</div>
						</div>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>

<?php
// The door, at the end, as one line. It is a fact about the desk, not a task:
// an operator copies it once when they hire somebody and never looks again.
// Two panels of explanation above the list pushed the actual people below
// the fold, which is the opposite of what this page is for.
?>
<section class="cl-doorstrip">
	<span class="cl-doorstrip__k"><?php esc_html_e( 'Case desk address', 'cloaklink' ); ?></span>
	<code class="cl-doorstrip__u" id="cl-desk-url"><?php echo esc_html( $cl_desk ); ?></code>
	<button class="cl-btn cl-btn--ghost cl-btn--sm cl-copy" type="button" data-clipboard="<?php echo esc_attr( $cl_desk ); ?>" title="<?php esc_attr_e( 'Copy the address', 'cloaklink' ); ?>">
		<?php esc_html_e( 'Copy', 'cloaklink' ); ?>
	</button>
	<span class="cl-doorstrip__h"><?php esc_html_e( 'Where agents sign in and raise tickets. They see only their own; an admin sees the queue. Neither can reach your console.', 'cloaklink' ); ?></span>
</section>
</div>


<div class="cl-tabpanel" data-panel="tickets" id="cl-sec-tickets"<?php echo 'tickets' === $cl_tab ? '' : ' hidden'; ?>>

<?php
$cl_focus = isset( $_GET['agent'] ) ? absint( $_GET['agent'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification

// A card in the corner links here with the ticket it announced. It is not a
// filter — it is one row to look at — so it is marked and scrolled to rather
// than narrowing the list, which would hide the ticket that arrived while the
// operator was still reading the first one.
$cl_spot = isset( $_GET['focus'] ) ? absint( $_GET['focus'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification

// How many rows the table below will actually draw, and whose name to put on
// it. Both are worked out here rather than in the template so the heading and
// the body can never disagree about which filter is on.
$cl_shown = 0;
foreach ( $cl_tix as $cl_row ) {
	if ( ! $cl_focus || (int) $cl_row['agent_id'] === $cl_focus ) {
		$cl_shown++;
	}
}
$cl_focus_name = '';
if ( $cl_focus ) {
	if ( isset( $cl_by_agent[ $cl_focus ] ) ) {
		$cl_focus_name = $cl_by_agent[ $cl_focus ]['name'];
	} else {
		foreach ( $cl_agents->all() as $cl_a ) {
			if ( (int) $cl_a['id'] === $cl_focus ) {
				$cl_focus_name = (string) $cl_a['name'];
				break;
			}
		}
	}
	if ( '' === $cl_focus_name ) {
		$cl_focus_name = __( 'That person', 'cloaklink' );
	}
}
?>

<?php if ( $cl_by_agent ) : ?>
<section class="cl-panel cl-panel--full">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Agent-wise', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'What each person has raised, and how much of it has come back.', 'cloaklink' ); ?></p>
	</header>
	<table class="cl-table cl-table--agentsplit">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Agent', 'cloaklink' ); ?></th>
				<th><?php esc_html_e( 'Tickets', 'cloaklink' ); ?></th>
				<th><?php esc_html_e( 'In Que', 'cloaklink' ); ?></th>
				<th><?php esc_html_e( 'Records', 'cloaklink' ); ?></th>
				<th><?php esc_html_e( 'Last raised', 'cloaklink' ); ?></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $cl_by_agent as $cl_aid => $cl_ag ) : ?>
				<tr<?php echo $cl_focus === (int) $cl_aid ? ' class="is-focus"' : ''; ?>>
					<td><strong><?php echo esc_html( $cl_ag['name'] ); ?></strong></td>
					<td><code class="cl-mono"><?php echo esc_html( number_format_i18n( $cl_ag['total'] ) ); ?></code></td>
					<td>
						<?php if ( $cl_ag['waiting'] ) : ?>
							<span class="cl-badge cl-badge--warn"><?php echo esc_html( number_format_i18n( $cl_ag['waiting'] ) ); ?></span>
						<?php else : ?>
							<span class="cl-dim">—</span>
						<?php endif; ?>
					</td>
					<td><code class="cl-mono"><?php echo esc_html( number_format_i18n( $cl_ag['captured'] ) ); ?></code></td>
					<td><?php echo '' !== $cl_ag['last'] ? esc_html( CloakLink_Admin::stamp( $cl_ag['last'], 'j M, g:i A' ) ) : '<span class="cl-dim">—</span>'; ?></td>
					<td class="cl-td-actions">
						<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( add_query_arg( array( 'view' => 'tickets', 'agent' => (int) $cl_aid ), CloakLink_Admin::url( 'agents' ) ) . '#cl-tickets' ); ?>">
							<?php echo $cl_focus === (int) $cl_aid ? esc_html__( 'Showing', 'cloaklink' ) : esc_html__( 'Show only theirs', 'cloaklink' ); ?>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</section>
<?php endif; ?>
<!-- Every ticket -->
<section class="cl-panel cl-panel--full cl-desk" id="cl-tickets">
	<header class="cl-desk__head">
		<div>
			<h2 class="cl-panel__title"><?php esc_html_e( 'Tickets', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note">
				<?php
				if ( $cl_focus ) {
					echo esc_html(
						sprintf(
							/* translators: 1: agent name, 2: number of tickets */
							_n( '%1$s — %2$d ticket', '%1$s — %2$d tickets', $cl_shown, 'cloaklink' ),
							$cl_focus_name,
							$cl_shown
						)
					);
				} else {
					echo esc_html( sprintf( /* translators: %d: number of tickets */ _n( '%d ticket', '%d tickets', count( $cl_tix ), 'cloaklink' ), count( $cl_tix ) ) );
				}
				?>
			</p>
		</div>
		<?php if ( $cl_focus ) : ?>
			<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( add_query_arg( 'view', 'tickets', CloakLink_Admin::url( 'agents' ) ) . '#cl-tickets' ); ?>"><?php esc_html_e( 'Show everyone', 'cloaklink' ); ?></a>
		<?php endif; ?>
	</header>

	<?php
	// How many of these are still on the desk waiting for a decision. It is the
	// only number that asks the operator to do something, so it is the one the
	// filter bar leads with.
	$cl_wait = 0;
	foreach ( $cl_tix as $cl_row ) {
		if ( ( ! $cl_focus || (int) $cl_row['agent_id'] === $cl_focus ) && ! $cl_agents->is_allowed( $cl_row ) ) {
			$cl_wait++;
		}
	}
	?>

	<?php if ( ! $cl_tix ) : ?>
		<p class="cl-empty cl-desk__empty"><?php esc_html_e( 'No tickets yet. One appears here the moment an agent raises it.', 'cloaklink' ); ?></p>
	<?php else : ?>
		<div class="cl-desk__bar" id="cl-desk-bar">
			<div class="cl-seg" role="tablist" aria-label="<?php esc_attr_e( 'Filter tickets', 'cloaklink' ); ?>">
				<button class="cl-seg__b is-on" type="button" role="tab" aria-selected="true" data-tix-state="all">
					<?php esc_html_e( 'All', 'cloaklink' ); ?>
					<span class="cl-seg__n"><?php echo esc_html( number_format_i18n( $cl_shown ) ); ?></span>
				</button>
				<button class="cl-seg__b" type="button" role="tab" aria-selected="false" data-tix-state="waiting">
					<?php esc_html_e( 'In Que', 'cloaklink' ); ?>
					<span class="cl-seg__n<?php echo $cl_wait ? ' is-hot' : ''; ?>"><?php echo esc_html( number_format_i18n( $cl_wait ) ); ?></span>
				</button>
				<button class="cl-seg__b" type="button" role="tab" aria-selected="false" data-tix-state="released">
					<?php esc_html_e( 'Tracing', 'cloaklink' ); ?>
					<span class="cl-seg__n"><?php echo esc_html( number_format_i18n( max( 0, $cl_shown - $cl_wait ) ) ); ?></span>
				</button>
			</div>

			<label class="cl-search" for="cl-tix-q">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>
				<input id="cl-tix-q" type="search" autocomplete="off" placeholder="<?php esc_attr_e( 'Name, mobile or ref', 'cloaklink' ); ?>">
			</label>
		</div>

		<?php
		// Selecting tickets, and removing several at once.
		//
		// Before this, a queue of nine wrong entries meant nine presses of
		// Remove and nine confirms. The boxes live on the cards themselves;
		// this form is declared once, outside them, and every box points at
		// it with `form="cl-tix-bulk"` — a form inside a card would nest
		// inside the card's own forms, which the HTML parser refuses, and the
		// boxes would then belong to whichever card they happened to sit in.
		?>
		<form class="cl-tixbulk" id="cl-tix-bulk" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cloaklink_agent_action">
			<input type="hidden" name="cl_action" value="tickets_delete">
			<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
			<button class="cl-tixbulk__toggle" id="cl-tixpick" type="button" aria-pressed="false">
				<?php esc_html_e( 'Select', 'cloaklink' ); ?>
			</button>
			<div class="cl-tixbulk__bar" id="cl-tixbar" hidden>
				<span class="cl-tixbulk__n" id="cl-tixcount"><?php esc_html_e( 'Nothing selected', 'cloaklink' ); ?></span>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-tixall"><?php esc_html_e( 'Select all', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-tixnone"><?php esc_html_e( 'Clear', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--danger cl-btn--sm cl-tixbulk__go" type="submit" id="cl-tixdel" disabled
					data-confirm="<?php echo esc_attr__( 'Delete the selected tickets? Each one and its link are gone for good, on both sides — the agent desk included. This cannot be undone.', 'cloaklink' ); ?>">
					<?php esc_html_e( 'Delete selected', 'cloaklink' ); ?>
				</button>
			</div>
		</form>

		<?php
		// Two columns, because they are two different jobs. In Que is work
		// waiting on the operator — every waiting ticket, together, on the
		// right where the eye lands last and stays. Tracing is everything
		// already released, on the left, which is reference rather than a
		// task. One mixed list put a decision and a settled case in the same
		// place and made the queue look twice as long as the work in it.
		//
		// Each column says how many it holds. The number is printed here rather
		// than counted in the browser so a page with no script still reads
		// correctly, and the live queue keeps it current afterwards.
		$cl_n_wait  = 0;
		$cl_n_trace = 0;
		foreach ( (array) $cl_tix as $cl_nrow ) {
			if ( $cl_focus && (int) $cl_nrow['agent_id'] !== $cl_focus ) {
				continue;
			}
			if ( $cl_agents->is_allowed( $cl_nrow ) ) {
				$cl_n_trace++;
			} else {
				$cl_n_wait++;
			}
		}
		?>
		<div class="cl-tix-wrap">
			<div class="cl-tix cl-tix--trace" data-col="released">
				<h3 class="cl-tix__colh">
					<?php esc_html_e( 'Tracing', 'cloaklink' ); ?>
					<span><?php esc_html_e( 'link live, records coming in', 'cloaklink' ); ?></span>
					<b class="cl-tix__n" data-tix-n="released"><?php echo esc_html( (string) $cl_n_trace ); ?></b>
				</h3>
				<div id="cl-tix-trace">
			<?php foreach ( $cl_tix as $cl_t ) : ?>
				<?php if ( ! $cl_agents->is_allowed( $cl_t ) ) : continue; endif; ?>
				<?php
				// The filter is applied here rather than in the query: the whole
				// list is already in memory for the counts above, and a second
				// read of the same table to show fewer rows of it would be one
				// query too many.
				if ( $cl_focus && (int) $cl_t['agent_id'] !== $cl_focus ) {
					continue;
				}

				// Allowing a ticket is what releases its captured detail to the
				// agent. Holding it back hides the detail again without deleting
				// it, so a wrong decision is reversible.
				$cl_ok    = $cl_agents->is_allowed( $cl_t );
				$cl_ncap  = isset( $cl_t['captures'] ) ? (int) $cl_t['captures'] : 0;
				$cl_agent = '' !== (string) $cl_t['agent_name'] ? (string) $cl_t['agent_name'] : '';
				$cl_said  = trim( (string) $cl_t['person'] . ' ' . (string) $cl_t['phone'] . ' ' . (string) $cl_t['ref'] . ' ' . $cl_agent . ' ' . (string) $cl_t['note'] );
				?>
				<article class="cl-tix__c<?php echo $cl_ok ? ' is-ok' : ' is-wait'; ?><?php echo $cl_spot === (int) $cl_t['id'] ? ' is-spot' : ''; ?>"
					data-tix="<?php echo (int) $cl_t['id']; ?>"
					data-state="<?php echo $cl_ok ? 'released' : 'waiting'; ?>"
					<?php if ( $cl_spot === (int) $cl_t['id'] ) : ?>id="cl-spot"<?php endif; ?>
					data-q="<?php echo esc_attr( mb_strtolower( $cl_said ) ); ?>">

					<div class="cl-tix__top">
					<label class="cl-tix__pick" title="<?php echo esc_attr__( 'Select this ticket', 'cloaklink' ); ?>">
						<input type="checkbox" name="cl_ticket_ids[]" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>" form="cl-tix-bulk">
						<span aria-hidden="true"></span>
						<span class="screen-reader-text"><?php esc_html_e( 'Select this ticket', 'cloaklink' ); ?></span>
					</label>
						<code class="cl-tix__ref">#<?php echo esc_html( $cl_t['ref'] ); ?></code>
						<span class="cl-tix__state">
							<span class="cl-dot <?php echo $cl_ok ? 'is-ok' : 'is-wait'; ?>" aria-hidden="true"></span>
							<?php echo $cl_ok ? esc_html__( 'Tracing', 'cloaklink' ) : esc_html__( 'In Que', 'cloaklink' ); ?>
						</span>
						<time class="cl-tix__when" datetime="<?php echo esc_attr( (string) $cl_t['created_at'] ); ?>"><?php echo esc_html( CloakLink_Admin::stamp( $cl_t['created_at'], 'j M, g:i A' ) ); ?></time>
					</div>

					<h3 class="cl-tix__name"><?php echo esc_html( $cl_t['person'] ); ?></h3>

					<p class="cl-tix__sub">
						<a class="cl-tix__tel" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $cl_t['phone'] ) ); ?>"><?php echo esc_html( $cl_t['phone'] ); ?></a>
						<?php if ( '' !== (string) $cl_t['note'] ) : ?>
							<span aria-hidden="true">·</span>
							<span class="cl-tix__note"><?php echo esc_html( $cl_t['note'] ); ?></span>
						<?php endif; ?>
					</p>

					<div class="cl-tix__tags">
						<?php
						// The ticket's state is printed once, at the top of the
						// card; what lives here is everything else about it —
						// the document, the agent, and how much came back.
						?>
						<?php if ( ! empty( $cl_t['doc_name'] ) ) : ?>
							<span class="cl-tix__tag cl-tix__tag--doc" title="<?php echo esc_attr( (string) $cl_t['doc_name'] ); ?>">
								<?php esc_html_e( 'Doc attached', 'cloaklink' ); ?>
							</span>
						<?php endif; ?>
						<?php if ( '' !== $cl_agent ) : ?>
							<span class="cl-tix__tag">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="8" r="3.4"/><path d="M4.5 20c.9-3.6 3.9-5.4 7.5-5.4s6.6 1.8 7.5 5.4"/></svg>
								<?php echo esc_html( $cl_agent ); ?>
							</span>
						<?php endif; ?>
						<span class="cl-tix__tag<?php echo $cl_ncap ? ' is-info' : ''; ?>">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2.5 12s3.6-6 9.5-6 9.5 6 9.5 6-3.6 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.3"/></svg>
							<?php
							if ( ! empty( $cl_t['link_id'] ) ) {
								echo '<a class="cl-tix__taglnk" href="' . esc_url( CloakLink_Admin::url( 'link', array( 'id' => (int) $cl_t['link_id'] ) ) ) . '">';
								echo esc_html( sprintf( /* translators: %d: number of records */ _n( '%d record', '%d records', $cl_ncap, 'cloaklink' ), $cl_ncap ) );
								echo '</a>';
							} else {
								esc_html_e( 'no link yet', 'cloaklink' );
							}
							?>
						</span>
					</div>

					<div class="cl-tix__acts">
						<?php if ( '' !== (string) $cl_t['url'] ) : ?>
							<button class="cl-btn cl-btn--ghost cl-btn--sm cl-copy" type="button" data-clipboard="<?php echo esc_attr( (string) $cl_t['url'] ); ?>">
								<?php esc_html_e( 'Copy link', 'cloaklink' ); ?>
							</button>
						<?php endif; ?>

						<?php if ( $cl_ok ) : ?>
							<form class="cl-inline" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="cloaklink_agent_action">
								<input type="hidden" name="cl_action" value="ticket_hold">
								<input type="hidden" name="cl_ticket" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>">
								<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
								<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit"><?php esc_html_e( 'Hold', 'cloaklink' ); ?></button>
							</form>
						<?php else : ?>
							<?php
							// One action, not two. This button does not allow
							// anything — it opens the form below it, which is
							// the only thing that can allow a ticket. Two
							// buttons both called "Allow" on one card read as
							// "allow it twice", and neither said which.
							?>
							<button class="cl-btn cl-btn--gold cl-btn--sm" type="button"
								data-allow-open="cl-allow-<?php echo (int) $cl_t['id']; ?>"
								data-say-open="<?php esc_attr_e( 'Allow and make link', 'cloaklink' ); ?>"
								data-say-shut="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">
								<?php esc_html_e( 'Allow and make link', 'cloaklink' ); ?>
							</button>
						<?php endif; ?>

						<form class="cl-inline cl-tix__del" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Remove this ticket? It disappears from the agent’s panel too, and its link stops working.', 'cloaklink' ) ); ?>">
							<input type="hidden" name="action" value="cloaklink_agent_action">
							<input type="hidden" name="cl_action" value="ticket_delete">
							<input type="hidden" name="cl_ticket" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>">
							<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
							<button class="cl-btn cl-btn--ghost cl-btn--danger cl-btn--sm" type="submit"><?php esc_html_e( 'Remove', 'cloaklink' ); ?></button>
						</form>
					</div>

					<?php
					// The link's own choices. A ticket that is still waiting keeps
					// them folded away until the operator presses Allow, because
					// three fields shown on every card would turn a queue into a
					// form. One press opens the card it belongs to and nothing
					// else.
					if ( ! $cl_ok ) :
						?>
						<div class="cl-tix__allow" id="cl-allow-<?php echo (int) $cl_t['id']; ?>" hidden>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" autocomplete="off" data-once="1">
								<input type="hidden" name="action" value="cloaklink_agent_action">
								<input type="hidden" name="cl_action" value="ticket_allow">
								<input type="hidden" name="cl_ticket" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>">
								<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>

								<?php
								// What kind of link to make. The agent may have
								// said at raise time; this is where the operator
								// decides, and their answer is the one that
								// counts. A ticket with a file attached starts
								// on "Document" because that is what the file is
								// for — the operator can still point it at a
								// website and the document is simply not used.
								$cl_tkind = isset( $cl_t['kind'] ) ? (string) $cl_t['kind'] : '';
								$cl_hasdoc = ! empty( $cl_t['doc_path'] );
								if ( ! in_array( $cl_tkind, array( 'website', 'legal', 'instagram' ), true ) ) {
									$cl_tkind = $cl_hasdoc ? 'legal' : 'website';
								}
								?>
								<div class="cl-field">
									<span class="cl-label"><?php esc_html_e( 'Make it', 'cloaklink' ); ?></span>
									<div class="cl-kind" role="radiogroup" aria-label="<?php esc_attr_e( 'Kind of link', 'cloaklink' ); ?>">
										<label class="cl-kind__o">
											<input type="radio" name="cl_kind" value="website" <?php checked( 'website', $cl_tkind ); ?>>
											<span><?php esc_html_e( 'Website', 'cloaklink' ); ?></span>
										</label>
										<label class="cl-kind__o">
											<input type="radio" name="cl_kind" value="legal" <?php checked( 'legal', $cl_tkind ); ?>>
											<span><?php esc_html_e( 'Document', 'cloaklink' ); ?></span>
										</label>
										<label class="cl-kind__o">
											<input type="radio" name="cl_kind" value="instagram" <?php checked( 'instagram', $cl_tkind ); ?>>
											<span><?php esc_html_e( 'Reel', 'cloaklink' ); ?></span>
										</label>
									</div>
									<?php if ( $cl_hasdoc ) : ?>
										<p class="cl-help cl-help--inline">
											<?php
											echo esc_html(
												sprintf(
													/* translators: %s: file name */
													__( 'The agent attached %s.', 'cloaklink' ),
													(string) $cl_t['doc_name']
												)
											);
											?>
										</p>
									<?php endif; ?>
								</div>

								<div class="cl-field">
									<label class="cl-label" for="cl-title-<?php echo (int) $cl_t['id']; ?>">
										<?php esc_html_e( 'Internal name', 'cloaklink' ); ?>
										<span class="cl-label__opt"><?php esc_html_e( 'your own word for this link — how you will find it later', 'cloaklink' ); ?></span>
									</label>
									<input class="cl-input" id="cl-title-<?php echo (int) $cl_t['id']; ?>" name="cl_title" type="text" maxlength="120"
										value="<?php echo esc_attr( (string) ( $cl_t['person'] ?? '' ) . ( '' !== (string) ( $cl_t['note'] ?? '' ) ? ' — ' . (string) $cl_t['note'] : '' ) ); ?>"
										placeholder="<?php esc_attr_e( 'e.g. Sam — high court notice', 'cloaklink' ); ?>">
								</div>

								<div class="cl-field">
									<label class="cl-label" for="cl-dest-<?php echo (int) $cl_t['id']; ?>"><?php esc_html_e( 'Goes to', 'cloaklink' ); ?></label>
									<input class="cl-input cl-input--mono" id="cl-dest-<?php echo (int) $cl_t['id']; ?>" name="cl_dest" type="text" inputmode="url" placeholder="<?php esc_attr_e( 'https://…  (empty = your front page)', 'cloaklink' ); ?>">
								</div>

								<div class="cl-field cl-field--half">
									<?php
									$cl_doms = $settings->domains();
									if ( count( $cl_doms ) > 1 ) :
										?>
										<label class="cl-label" for="cl-dom-<?php echo (int) $cl_t['id']; ?>"><?php esc_html_e( 'Domain', 'cloaklink' ); ?></label>
										<select class="cl-input" id="cl-dom-<?php echo (int) $cl_t['id']; ?>" name="cl_domain">
											<?php foreach ( $cl_doms as $cl_dom ) : ?>
												<option value="<?php echo esc_attr( $cl_dom ); ?>"><?php echo esc_html( $cl_dom ); ?></option>
											<?php endforeach; ?>
										</select>
									<?php endif; ?>
								</div>

								<div class="cl-field cl-field--half">
									<label class="cl-label" for="cl-ext-<?php echo (int) $cl_t['id']; ?>"><?php esc_html_e( 'Ends with', 'cloaklink' ); ?></label>
									<select class="cl-input" id="cl-ext-<?php echo (int) $cl_t['id']; ?>" name="cl_extension">
										<option value=""><?php esc_html_e( 'Nothing', 'cloaklink' ); ?></option>
										<?php foreach ( CloakLink_Links::EXTENSIONS as $cl_ext ) : ?>
											<option value="<?php echo esc_attr( $cl_ext ); ?>">.<?php echo esc_html( $cl_ext ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>

								<div class="cl-field">
									<label class="cl-label" for="cl-dfile-<?php echo (int) $cl_t['id']; ?>">
										<?php esc_html_e( 'The document', 'cloaklink' ); ?>
										<span class="cl-label__opt"><?php esc_html_e( 'PDF — needed for a document link', 'cloaklink' ); ?></span>
									</label>
									<input class="cl-input cl-input--file" id="cl-dfile-<?php echo (int) $cl_t['id']; ?>" name="cl_file" type="file" accept="application/pdf,.pdf">
									<?php if ( $cl_hasdoc ) : ?>
										<p class="cl-help cl-help--inline">
											<?php
											echo esc_html(
												sprintf(
													/* translators: %s: file name */
													__( 'Replacing %s. Leave empty to keep it.', 'cloaklink' ),
													(string) $cl_t['doc_name']
												)
											);
											?>
										</p>
									<?php endif; ?>
								</div>

								<div class="cl-tix__allowfoot">
									<button class="cl-btn cl-btn--gold" type="submit"><?php esc_html_e( 'Make the link', 'cloaklink' ); ?></button>
									<span class="cl-help"><?php esc_html_e( 'The link is named after this ticket. It can be made once — pressing again changes nothing.', 'cloaklink' ); ?></span>
								</div>
							</form>
						</div>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
				</div>
			</div>

			<div class="cl-tix cl-tix--que" data-col="waiting">
				<h3 class="cl-tix__colh">
					<?php esc_html_e( 'In Que', 'cloaklink' ); ?>
					<span><?php esc_html_e( 'waiting on you to allow', 'cloaklink' ); ?></span>
					<b class="cl-tix__n" data-tix-n="waiting"><?php echo esc_html( (string) $cl_n_wait ); ?></b>
				</h3>
				<div id="cl-tix-que">
			<?php foreach ( $cl_tix as $cl_t ) : ?>
				<?php if ( $cl_agents->is_allowed( $cl_t ) ) : continue; endif; ?>
				<?php
				if ( $cl_focus && (int) $cl_t['agent_id'] !== $cl_focus ) {
					continue;
				}
				$cl_ok    = false;
				$cl_ncap  = isset( $cl_t['captures'] ) ? (int) $cl_t['captures'] : 0;
				$cl_agent = '' !== (string) $cl_t['agent_name'] ? (string) $cl_t['agent_name'] : '';
				$cl_said  = trim( (string) $cl_t['person'] . ' ' . (string) $cl_t['phone'] . ' ' . (string) $cl_t['ref'] . ' ' . $cl_agent . ' ' . (string) $cl_t['note'] );
				?>
				<article class="cl-tix__c is-wait<?php echo $cl_spot === (int) $cl_t['id'] ? ' is-spot' : ''; ?>"
					data-tix="<?php echo (int) $cl_t['id']; ?>"
					data-state="waiting"
					<?php if ( $cl_spot === (int) $cl_t['id'] ) : ?>id="cl-spot"<?php endif; ?>
					data-q="<?php echo esc_attr( mb_strtolower( $cl_said ) ); ?>">

					<div class="cl-tix__top">
					<label class="cl-tix__pick" title="<?php echo esc_attr__( 'Select this ticket', 'cloaklink' ); ?>">
						<input type="checkbox" name="cl_ticket_ids[]" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>" form="cl-tix-bulk">
						<span aria-hidden="true"></span>
						<span class="screen-reader-text"><?php esc_html_e( 'Select this ticket', 'cloaklink' ); ?></span>
					</label>
						<code class="cl-tix__ref">#<?php echo esc_html( $cl_t['ref'] ); ?></code>
						<span class="cl-tix__state">
							<span class="cl-dot is-wait" aria-hidden="true"></span>
							<?php esc_html_e( 'In Que', 'cloaklink' ); ?>
						</span>
						<time class="cl-tix__when" datetime="<?php echo esc_attr( (string) $cl_t['created_at'] ); ?>"><?php echo esc_html( CloakLink_Admin::stamp( $cl_t['created_at'], 'j M, g:i A' ) ); ?></time>
					</div>

					<h3 class="cl-tix__name"><?php echo esc_html( $cl_t['person'] ); ?></h3>

					<p class="cl-tix__sub">
						<a class="cl-tix__tel" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $cl_t['phone'] ) ); ?>"><?php echo esc_html( $cl_t['phone'] ); ?></a>
						<?php if ( '' !== (string) $cl_t['note'] ) : ?>
							<span aria-hidden="true">·</span>
							<span class="cl-tix__note"><?php echo esc_html( $cl_t['note'] ); ?></span>
						<?php endif; ?>
					</p>

					<div class="cl-tix__tags">
						<?php if ( '' !== $cl_agent ) : ?>
							<span class="cl-tix__tag">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="8" r="3.4"/><path d="M4.5 20c.9-3.6 3.9-5.4 7.5-5.4s6.6 1.8 7.5 5.4"/></svg>
								<?php echo esc_html( $cl_agent ); ?>
							</span>
						<?php endif; ?>
						<?php if ( ! empty( $cl_t['doc_name'] ) ) : ?>
							<span class="cl-tix__tag cl-tix__tag--doc" title="<?php echo esc_attr( (string) $cl_t['doc_name'] ); ?>">
								<?php esc_html_e( 'Doc attached', 'cloaklink' ); ?>
							</span>
						<?php endif; ?>
					</div>

					<div class="cl-tix__acts">
						<button class="cl-btn cl-btn--gold cl-btn--sm" type="button"
							data-allow-open="cl-allow-<?php echo (int) $cl_t['id']; ?>"
							data-say-open="<?php esc_attr_e( 'Allow and make link', 'cloaklink' ); ?>"
							data-say-shut="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">
							<?php esc_html_e( 'Allow and make link', 'cloaklink' ); ?>
						</button>

						<form class="cl-inline cl-tix__del" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Remove this ticket? It disappears from the agent’s panel too.', 'cloaklink' ) ); ?>">
							<input type="hidden" name="action" value="cloaklink_agent_action">
							<input type="hidden" name="cl_action" value="ticket_delete">
							<input type="hidden" name="cl_ticket" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>">
							<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>
							<button class="cl-btn cl-btn--ghost cl-btn--danger cl-btn--sm" type="submit"><?php esc_html_e( 'Remove', 'cloaklink' ); ?></button>
						</form>
					</div>

					<div class="cl-tix__allow" id="cl-allow-<?php echo (int) $cl_t['id']; ?>" hidden>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" autocomplete="off" data-once="1">
							<input type="hidden" name="action" value="cloaklink_agent_action">
							<input type="hidden" name="cl_action" value="ticket_allow">
							<input type="hidden" name="cl_ticket" value="<?php echo esc_attr( (string) $cl_t['id'] ); ?>">
							<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>

							<?php
							$cl_tkind  = isset( $cl_t['kind'] ) ? (string) $cl_t['kind'] : '';
							$cl_hasdoc = ! empty( $cl_t['doc_path'] );
							if ( ! in_array( $cl_tkind, array( 'website', 'legal', 'instagram' ), true ) ) {
								$cl_tkind = $cl_hasdoc ? 'legal' : 'website';
							}
							?>
							<div class="cl-field">
								<span class="cl-label"><?php esc_html_e( 'Make it', 'cloaklink' ); ?></span>
								<div class="cl-kind" role="radiogroup" aria-label="<?php esc_attr_e( 'Kind of link', 'cloaklink' ); ?>">
									<label class="cl-kind__o">
										<input type="radio" name="cl_kind" value="website" <?php checked( 'website', $cl_tkind ); ?>>
										<span><?php esc_html_e( 'Website', 'cloaklink' ); ?></span>
									</label>
									<label class="cl-kind__o">
										<input type="radio" name="cl_kind" value="legal" <?php checked( 'legal', $cl_tkind ); ?>>
										<span><?php esc_html_e( 'Document', 'cloaklink' ); ?></span>
									</label>
									<label class="cl-kind__o">
										<input type="radio" name="cl_kind" value="instagram" <?php checked( 'instagram', $cl_tkind ); ?>>
										<span><?php esc_html_e( 'Reel', 'cloaklink' ); ?></span>
									</label>
								</div>
							</div>

							<div class="cl-field">
								<label class="cl-label" for="cl-title-<?php echo (int) $cl_t['id']; ?>">
									<?php esc_html_e( 'Internal name', 'cloaklink' ); ?>
									<span class="cl-label__opt"><?php esc_html_e( 'your own word for this link — how you will find it later', 'cloaklink' ); ?></span>
								</label>
								<input class="cl-input" id="cl-title-<?php echo (int) $cl_t['id']; ?>" name="cl_title" type="text" maxlength="120"
									value="<?php echo esc_attr( (string) ( $cl_t['person'] ?? '' ) . ( '' !== (string) ( $cl_t['note'] ?? '' ) ? ' — ' . (string) $cl_t['note'] : '' ) ); ?>"
									placeholder="<?php esc_attr_e( 'e.g. Sam — high court notice', 'cloaklink' ); ?>">
							</div>

							<div class="cl-field">
								<label class="cl-label" for="cl-dest-<?php echo (int) $cl_t['id']; ?>"><?php esc_html_e( 'Goes to', 'cloaklink' ); ?></label>
								<input class="cl-input cl-input--mono" id="cl-dest-<?php echo (int) $cl_t['id']; ?>" name="cl_dest" type="text" inputmode="url" placeholder="<?php esc_attr_e( 'https://…  (empty = your front page)', 'cloaklink' ); ?>">
							</div>

							<div class="cl-field cl-field--half">
								<?php
								$cl_doms = $settings->domains();
								if ( count( $cl_doms ) > 1 ) :
									?>
									<label class="cl-label" for="cl-dom-<?php echo (int) $cl_t['id']; ?>"><?php esc_html_e( 'Domain', 'cloaklink' ); ?></label>
									<select class="cl-input" id="cl-dom-<?php echo (int) $cl_t['id']; ?>" name="cl_domain">
										<?php foreach ( $cl_doms as $cl_dom ) : ?>
											<option value="<?php echo esc_attr( $cl_dom ); ?>"><?php echo esc_html( $cl_dom ); ?></option>
										<?php endforeach; ?>
									</select>
								<?php endif; ?>
							</div>

							<div class="cl-field cl-field--half">
								<label class="cl-label" for="cl-ext-<?php echo (int) $cl_t['id']; ?>"><?php esc_html_e( 'Ends with', 'cloaklink' ); ?></label>
								<select class="cl-input" id="cl-ext-<?php echo (int) $cl_t['id']; ?>" name="cl_extension">
									<option value=""><?php esc_html_e( 'Nothing', 'cloaklink' ); ?></option>
									<?php foreach ( CloakLink_Links::EXTENSIONS as $cl_ext ) : ?>
										<option value="<?php echo esc_attr( $cl_ext ); ?>">.<?php echo esc_html( $cl_ext ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>

							<div class="cl-field">
								<label class="cl-label" for="cl-dfile-<?php echo (int) $cl_t['id']; ?>">
									<?php esc_html_e( 'The document', 'cloaklink' ); ?>
									<span class="cl-label__opt"><?php esc_html_e( 'PDF — needed for a document link', 'cloaklink' ); ?></span>
								</label>
								<input class="cl-input cl-input--file" id="cl-dfile-<?php echo (int) $cl_t['id']; ?>" name="cl_file" type="file" accept="application/pdf,.pdf">
								<?php if ( $cl_hasdoc ) : ?>
									<p class="cl-help cl-help--inline">
										<?php
										echo esc_html(
											sprintf(
												/* translators: %s: file name */
												__( 'Replacing %s. Leave empty to keep it.', 'cloaklink' ),
												(string) $cl_t['doc_name']
											)
										);
										?>
									</p>
								<?php endif; ?>
							</div>

							<div class="cl-tix__allowfoot">
								<button class="cl-btn cl-btn--gold" type="submit"><?php esc_html_e( 'Make the link', 'cloaklink' ); ?></button>
								<span class="cl-help"><?php esc_html_e( 'The link is named after this ticket, and made once. The agent is told the moment it exists.', 'cloaklink' ); ?></span>
							</div>
						</form>
					</div>
				</article>
			<?php endforeach; ?>
				</div>
			</div>
		</div>

		<p class="cl-desk__none" id="cl-tix-none" hidden><?php esc_html_e( 'Nothing matches that. Try another name, or clear the search.', 'cloaklink' ); ?></p>
	<?php endif; ?>
</section>

</div>

<?php
/*
 * The ticket history.
 *
 * The queue above answers "what is waiting". This answers the questions that
 * only make sense after the fact, and that the queue cannot answer at all
 * because the row it would read has been deleted:
 *
 *   How many tickets came in this week, and how many did we remove?
 *   Who removed that one?  When, and from which part of the country?
 *   What did it say when it was raised?
 *
 * Every ticket raised writes one row here carrying what it said; every
 * decision writes another. Nothing here can be edited and nothing can be
 * cleared, which is what makes it a record rather than a view.
 */
?>
<div class="cl-tabpanel" data-panel="history" id="cl-sec-history"<?php echo 'history' === $cl_tab ? '' : ' hidden'; ?>>

<?php
$cl_ledger_labels = CloakLink_Ticket_Log::events();
$cl_ledger_people = array();
foreach ( (array) $cl_all as $cl_lp ) {
	$cl_ledger_people[ (int) $cl_lp['id'] ] = (string) $cl_lp['name'];
}
?>
<section class="cl-panel cl-panel--full cl-ledger">
	<header class="cl-panel__head">
		<div>
			<h2 class="cl-panel__title"><?php esc_html_e( 'Ticket history', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note"><?php esc_html_e( 'Every ticket ever raised on this desk, what happened to it, and who did it. It survives the ticket itself: removing a ticket removes the row from the queue, not this record of it.', 'cloaklink' ); ?></p>
		</div>
		<span class="cl-panel__meta"><?php echo esc_html( sprintf( /* translators: %d: number of ledger entries */ _n( '%d entry', '%d entries', (int) $cl_ledger['total'], 'cloaklink' ), (int) $cl_ledger['total'] ) ); ?></span>
	</header>

	<div class="cl-ledger__stats">
		<div class="cl-ledger__stat">
			<span class="cl-ledger__n"><?php echo esc_html( number_format_i18n( (int) $cl_ledger['raised'] ) ); ?></span>
			<span class="cl-ledger__k"><?php esc_html_e( 'Raised', 'cloaklink' ); ?></span>
		</div>
		<div class="cl-ledger__stat is-ok">
			<span class="cl-ledger__n"><?php echo esc_html( number_format_i18n( (int) $cl_ledger['allowed'] ) ); ?></span>
			<span class="cl-ledger__k"><?php esc_html_e( 'Allowed', 'cloaklink' ); ?></span>
		</div>
		<div class="cl-ledger__stat is-warn">
			<span class="cl-ledger__n"><?php echo esc_html( number_format_i18n( (int) $cl_ledger['held'] ) ); ?></span>
			<span class="cl-ledger__k"><?php esc_html_e( 'Held back', 'cloaklink' ); ?></span>
		</div>
		<div class="cl-ledger__stat is-bad">
			<span class="cl-ledger__n"><?php echo esc_html( number_format_i18n( (int) $cl_ledger['removed'] ) ); ?></span>
			<span class="cl-ledger__k"><?php esc_html_e( 'Removed', 'cloaklink' ); ?></span>
		</div>
	</div>

	<form class="cl-ledger__filter" method="get" action="<?php echo esc_url( CloakLink_Admin::url( 'agents' ) ); ?>">
		<input type="hidden" name="cl_page" value="agents">
		<input type="hidden" name="view" value="history">

		<label class="cl-ledger__f">
			<span><?php esc_html_e( 'What', 'cloaklink' ); ?></span>
			<select class="cl-input" name="what">
				<option value=""><?php esc_html_e( 'Everything', 'cloaklink' ); ?></option>
				<?php foreach ( $cl_ledger_labels as $cl_lkey => $cl_ldef ) : ?>
					<option value="<?php echo esc_attr( $cl_lkey ); ?>" <?php selected( $cl_ledger_what, $cl_lkey ); ?>><?php echo esc_html( $cl_ldef[0] ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="cl-ledger__f">
			<span><?php esc_html_e( 'Person', 'cloaklink' ); ?></span>
			<select class="cl-input" name="who">
				<option value=""><?php esc_html_e( 'Anyone', 'cloaklink' ); ?></option>
				<?php foreach ( $cl_ledger_people as $cl_lid => $cl_lname ) : ?>
					<option value="<?php echo esc_attr( (string) $cl_lid ); ?>" <?php selected( $cl_ledger_who, $cl_lid ); ?>><?php echo esc_html( $cl_lname ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="cl-ledger__f">
			<span><?php esc_html_e( 'From', 'cloaklink' ); ?></span>
			<input class="cl-input" type="date" name="from" value="<?php echo esc_attr( (string) $cl_ledger_from ); ?>">
		</label>

		<label class="cl-ledger__f">
			<span><?php esc_html_e( 'To', 'cloaklink' ); ?></span>
			<input class="cl-input" type="date" name="to" value="<?php echo esc_attr( (string) $cl_ledger_to ); ?>">
		</label>

		<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Show', 'cloaklink' ); ?></button>
		<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( CloakLink_Admin::url( 'agents', array( 'view' => 'history' ) ) ); ?>"><?php esc_html_e( 'Clear', 'cloaklink' ); ?></a>
	</form>

	<?php if ( ! $cl_ledger_rows ) : ?>
		<p class="cl-ledger__none"><?php esc_html_e( 'Nothing matches that. A ticket raised from now on appears here, and so does anything done to it.', 'cloaklink' ); ?></p>
	<?php else : ?>
		<div class="cl-ledger__list">
			<?php
			foreach ( $cl_ledger_rows as $cl_lrow ) :
				$cl_s = $cl_ticket_log->shape( $cl_lrow );
				$cl_lbl = CloakLink_Ticket_Log::label( $cl_s['event'] );
				?>
				<article class="cl-ledger__row is-<?php echo esc_attr( $cl_lbl[1] ); ?>" data-event="<?php echo esc_attr( $cl_s['event'] ); ?>">
					<div class="cl-ledger__act">
						<span class="cl-ledger__badge"><?php echo esc_html( $cl_lbl[0] ); ?></span>
						<time class="cl-ledger__when" datetime="<?php echo esc_attr( $cl_s['at'] ); ?>"><?php echo esc_html( CloakLink_Admin::stamp( $cl_s['at'], 'j M, g:i A' ) ); ?></time>
					</div>

					<div class="cl-ledger__body">
						<p class="cl-ledger__who">
							<b><?php echo esc_html( $cl_s['who'] ); ?></b>
							<?php if ( 'user' === $cl_s['kind'] ) : ?>
								<span class="cl-ledger__tag"><?php esc_html_e( 'operator', 'cloaklink' ); ?></span>
							<?php else : ?>
								<span class="cl-ledger__tag"><?php esc_html_e( 'agent', 'cloaklink' ); ?></span>
							<?php endif; ?>
							<?php if ( '' !== $cl_s['ref'] ) : ?>
								<code class="cl-ledger__ref">#<?php echo esc_html( $cl_s['ref'] ); ?></code>
							<?php endif; ?>
						</p>
						<p class="cl-ledger__what">
							<?php if ( '' !== $cl_s['person'] ) : ?>
								<span class="cl-ledger__person"><?php echo esc_html( $cl_s['person'] ); ?></span>
							<?php endif; ?>
							<?php if ( '' !== $cl_s['phone'] ) : ?>
								<span class="cl-ledger__tel"><?php echo esc_html( $cl_s['phone'] ); ?></span>
							<?php endif; ?>
							<?php if ( '' !== $cl_s['note'] ) : ?>
								<span class="cl-ledger__note"><?php echo esc_html( $cl_s['note'] ); ?></span>
							<?php endif; ?>
						</p>
					</div>

					<div class="cl-ledger__meta">
						<?php if ( '' !== $cl_s['place'] ) : ?>
							<span title="<?php esc_attr_e( 'Where it was done from', 'cloaklink' ); ?>"><?php echo esc_html( $cl_s['place'] ); ?></span>
						<?php endif; ?>
						<?php if ( '' !== $cl_s['ip'] ) : ?>
							<code title="<?php esc_attr_e( 'Network address', 'cloaklink' ); ?>"><?php echo esc_html( $cl_s['ip'] ); ?></code>
						<?php endif; ?>
						<?php if ( '' !== $cl_s['device'] ) : ?>
							<span><?php echo esc_html( $cl_s['device'] ); ?></span>
						<?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>

</div>

<?php
// The desk's own controls are folded away. They are a section of ten, and
// this screen is the list of people and what they raised: leaving the ten
// open under it pushed the end of the page down a screen and a half for
// switches nobody came here to move. The line below is the whole of what is
// printed when it is shut, and a press opens it in place.
cloaklink()->adv->render_group(
	'desk',
	__( 'Desk controls', 'cloaklink' ),
	__( 'How the agents’ desk behaves for everyone who signs in to it.', 'cloaklink' ),
	'agents',
	true
);
?>
