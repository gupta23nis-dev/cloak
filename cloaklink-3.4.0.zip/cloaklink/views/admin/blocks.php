<?php
/**
 * Blocklist management.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_blocks = $cl_db->get_blocks();
$cl_notice = isset( $_GET['cl_block'] ) ? sanitize_key( wp_unslash( $_GET['cl_block'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
?>

<div class="cl-grid cl-grid--side">

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Excluded networks and countries', 'cloaklink' ); ?></h2>
			<span class="cl-panel__hint"><?php echo esc_html( sprintf( /* translators: %s: number */ __( '%s entries', 'cloaklink' ), number_format_i18n( count( $cl_blocks ) ) ) ); ?></span>
		</header>
		<div class="cl-panel__body cl-panel__body--flush">
			<?php if ( $cl_blocks ) : ?>
				<div class="cl-table-wrap">
					<table class="cl-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Scope', 'cloaklink' ); ?></th>
								<th><?php esc_html_e( 'Value', 'cloaklink' ); ?></th>
								<th><?php esc_html_e( 'Reason', 'cloaklink' ); ?></th>
								<th><?php esc_html_e( 'Hits', 'cloaklink' ); ?></th>
								<th><?php esc_html_e( 'Added', 'cloaklink' ); ?></th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $cl_blocks as $cl_b ) :
								$cl_b = array_merge(
									array(
										'id'         => 0,
										'scope'      => '',
										'value'      => '',
										'reason'     => '',
										'hits'       => 0,
										'created_at' => '',
									),
									is_array( $cl_b ) ? $cl_b : array()
								);
								?>
								<tr>
									<td><span class="cl-badge cl-badge--muted"><?php echo esc_html( strtoupper( (string) $cl_b['scope'] ) ); ?></span></td>
									<td><code><?php echo esc_html( (string) $cl_b['value'] ); ?></code></td>
									<td><?php echo $cl_b['reason'] ? esc_html( (string) $cl_b['reason'] ) : '<span class="cl-muted">—</span>'; ?></td>
									<td><?php echo esc_html( number_format_i18n( (int) $cl_b['hits'] ) ); ?></td>
									<td><?php echo esc_html( $admin->ago( (string) $cl_b['created_at'] ) ); ?></td>
									<td>
										<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
											<input type="hidden" name="action" value="cloaklink_block_action">
											<input type="hidden" name="cl_action" value="remove">
											<input type="hidden" name="id" value="<?php echo esc_attr( $cl_b['id'] ); ?>">
											<?php wp_nonce_field( 'cloaklink_block_action' ); ?>
											<button class="cl-iconbtn cl-iconbtn--bad" type="submit" title="<?php esc_attr_e( 'Remove', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'close', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
										</form>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'No exclusions. Every visitor reaches your gate.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<aside class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Add an entry', 'cloaklink' ); ?></h2>
		</header>
		<div class="cl-panel__body">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cloaklink_block_action">
				<?php wp_nonce_field( 'cloaklink_block_action' ); ?>

				<div class="cl-field">
					<label class="cl-label" for="cl-block-scope"><?php esc_html_e( 'Scope', 'cloaklink' ); ?></label>
					<select class="cl-input" id="cl-block-scope" name="scope">
						<option value="ip"><?php esc_html_e( 'IP address', 'cloaklink' ); ?></option>
						<option value="country"><?php esc_html_e( 'Country code', 'cloaklink' ); ?></option>
					</select>
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-block-value"><?php esc_html_e( 'Value', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-block-value" name="value" placeholder="203.0.113.9 / IN">
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-block-reason"><?php esc_html_e( 'Reason', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-block-reason" name="reason" placeholder="<?php esc_attr_e( 'e.g. repeated misuse', 'cloaklink' ); ?>">
				</div>
				<button class="cl-btn cl-btn--gold cl-btn--wide" type="submit"><?php esc_html_e( 'Add to blocklist', 'cloaklink' ); ?></button>
			</form>
			<p class="cl-help"><?php esc_html_e( 'Blocked visitors see a generic “not available” message and are logged. Prefer this over deleting visit history.', 'cloaklink' ); ?></p>
		</div>
	</aside>

</div>
