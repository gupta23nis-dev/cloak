<?php
/**
 * Edit link form.
 *
 * The same form as New link, drawn against an existing row: new.php itself is
 * written to serve both, and this file is the view the "edit" route resolves
 * to. It exists because it did not before — the routes table has always listed
 * "edit", the Links screen and every single-link screen have always linked to
 * it, and there was no such template, so render_view() returned early and the
 * operator got a page with a header and nothing under it. Every Edit button in
 * the panel opened a blank screen.
 *
 * The file is a copy rather than an include because the two screens are
 * allowed to diverge later (Edit has a delete button and a history link that
 * New cannot have), and a copy cannot make New stop working.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_is_edit = CloakLink_Admin::current_id();
$cl_link    = $cl_is_edit ? $cl_db->get_link( $cl_is_edit ) : null;
$cl_errors  = array();

// Field errors, left behind by a rejected save.
//
// They arrive through a transient that is deleted the moment it is read, so
// reloading the page does not resurrect a message about a form the operator
// has since fixed — and, unlike the JSON blob that used to ride in the query
// string, nothing of the plugin's wording ends up in a URL that gets pasted
// into a ticket.
$cl_err_key = 'cloaklink_form_errors_' . get_current_user_id();
$cl_errors  = get_transient( $cl_err_key );
if ( ! is_array( $cl_errors ) ) {
	$cl_errors = array();
} else {
	delete_transient( $cl_err_key );
}
// The older form of the address is still honoured, so a bookmarked or
// half-loaded /new?cl_error=... from before this change still explains
// itself instead of silently losing its message.
if ( ! $cl_errors && ! empty( $_GET['cl_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	$cl_decoded = json_decode( rawurldecode( wp_unslash( $_GET['cl_error'] ) ), true ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
	if ( is_array( $cl_decoded ) ) {
		$cl_errors = $cl_decoded;
	}
}

$cl_v = array(
	'title'       => $cl_link ? $cl_link['title'] : '',
	'label'       => $cl_link ? $cl_link['label'] : '',
	'link_type'   => $cl_link && in_array( $cl_link['link_type'], array( 'legal', 'instagram' ), true ) ? $cl_link['link_type'] : 'redirect',
	'destination' => $cl_link ? ( ( 'instagram' === $cl_link['link_type'] && ! empty( $cl_link['media_url'] ) ) ? $cl_link['media_url'] : $cl_link['destination'] ) : '',
	'media_url'   => $cl_link ? $cl_link['media_url'] : '',
	'page_title'  => $cl_link ? $cl_link['page_title'] : '',
	'whatsapp_preview_url' => $cl_link && ! empty( $cl_link['meta']['whatsapp_preview_url'] ) ? (string) $cl_link['meta']['whatsapp_preview_url'] : '',
	'mode'        => 'off',
	// A new link is offered the operator's own default cap and expiry, both
	// from the Advanced screen. Zero is what the form offered before those
	// switches existed, so an untouched install is unchanged.
	'max_clicks'  => $cl_link ? (int) $cl_link['max_clicks'] : (int) cloaklink()->adv->get( 'new_max_clicks', 0 ),
	'expires_at'  => $cl_link ? $cl_link['expires_at'] : ( (int) cloaklink()->adv->get( 'new_expiry_hours', 0 ) > 0
		? wp_date( 'Y-m-d\TH:i', time() + ( (int) cloaklink()->adv->get( 'new_expiry_hours', 0 ) * HOUR_IN_SECONDS ) )
		: '' ),
	'status'      => $cl_link ? $cl_link['status'] : 'active',
	'notice'      => $cl_link && isset( $cl_link['meta']['notice'] ) ? $cl_link['meta']['notice'] : '',
	'single_use'  => $cl_link && ! empty( $cl_link['meta']['single_use'] ) ? 1 : 0,
	'party_name'  => $cl_link && isset( $cl_link['meta']['party_name'] ) ? (string) $cl_link['meta']['party_name'] : '',
	'extension'   => $cl_link && isset( $cl_link['meta']['extension'] )
		? CloakLink_Links::clean_extension( (string) $cl_link['meta']['extension'] )
		: ( '' !== (string) cloaklink()->adv->get( 'ext_default', '' )
			? CloakLink_Links::clean_extension( (string) cloaklink()->adv->get( 'ext_default', '' ) )
			: CloakLink_Links::clean_extension( (string) $settings->get( 'default_extension', '' ) ) ),
);

$cl_has_pin = $cl_link && ! empty( $cl_link['meta']['pin_hash'] );

$cl_file_name = $cl_link && ! empty( $cl_link['meta']['file_name'] ) ? (string) $cl_link['meta']['file_name'] : '';
$cl_file_size = $cl_link && ! empty( $cl_link['meta']['file_size'] ) ? (int) $cl_link['meta']['file_size'] : 0;

$cl_exp_local = '';
if ( $cl_v['expires_at'] ) {
	$cl_ts = $cl_db->to_ts( $cl_v['expires_at'] );
	// The datetime field is filled in the panel's own clock, so what the
	// operator types back is the same time they were shown.
	$cl_exp_local = $cl_ts ? wp_date( 'Y-m-d\TH:i', $cl_ts, $admin->tz() ) : '';
}
?>

<?php
// The link that was just made, printed on this screen.
//
// The form is where the operator is standing when they press Create, so the
// result of pressing it is printed above the form rather than on a page they
// have to go and find. The address arrives already selected and the Copy
// button is the first thing under it: one press makes a link, one press sends
// it, and no second screen in between.
$cl_made = isset( $_GET['cl_made'] ) ? absint( $_GET['cl_made'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$cl_made_link = $cl_made ? $cl_db->get_link( $cl_made ) : null;
?>
<?php
// A rejected save, summarised where the fields it refers to are.
//
// This banner belongs to the form, not the shell: it promises "the fields are
// marked below", and on a reload — after the transient has been read and
// discarded — there is nothing below to mark. Printing it here means it can
// only appear on the one render that actually carries the errors.
if ( $cl_errors ) :
	$cl_err_n = count( $cl_errors );
	?>
	<div class="cl-flash cl-flash--bad">
		<?php
		echo esc_html(
			sprintf(
				/* translators: %d: number of fields needing attention */
				_n(
					'That form did not save: %d field needs attention. It is marked below, and nothing else you changed was lost.',
					'That form did not save: %d fields need attention. They are marked below, and nothing else you changed was lost.',
					$cl_err_n,
					'cloaklink'
				),
				$cl_err_n
			)
		);
		?>
	</div>
<?php endif; ?>

<?php if ( $cl_made_link ) : ?>
	<?php
	$cl_made_url = $links->link_url( $cl_made_link );
	$cl_made_share = $links->share_text( $cl_made_link );
	?>
	<section class="cl-made" id="cl-made">
		<span class="cl-made__tick" aria-hidden="true">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><path d="M4 12.5 9.5 18 20 6.5"/></svg>
		</span>
		<div class="cl-made__body">
			<p class="cl-made__t"><?php esc_html_e( 'Link ready', 'cloaklink' ); ?></p>
			<p class="cl-made__u">
				<input class="cl-made__in" id="cl-made-url" type="text" readonly value="<?php echo esc_attr( $cl_made_url ); ?>" onclick="this.select(); this.setSelectionRange(0, 99999);">
			</p>
			<p class="cl-made__h"><?php echo esc_html( $cl_made_link['title'] ); ?></p>
		</div>
		<div class="cl-made__acts">
			<button type="button" class="cl-btn cl-btn--gold cl-copy" id="cl-made-copy" data-clipboard="<?php echo esc_attr( $cl_made_url ); ?>"><?php esc_html_e( 'Copy link', 'cloaklink' ); ?></button>
			<a class="cl-btn cl-btn--ghost" target="_blank" rel="noopener" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( $cl_made_share ) ); ?>">WhatsApp</a>
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'links' ) ); ?>"><?php esc_html_e( 'All links', 'cloaklink' ); ?></a>
		</div>
	</section>
<?php endif; ?>

<form class="cl-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="cl-link-form">
	<input type="hidden" name="action" value="cloaklink_link_save">
	<input type="hidden" name="cl[id]" value="<?php echo $cl_link ? esc_attr( $cl_link['id'] ) : '0'; ?>">
	<?php wp_nonce_field( 'cloaklink_link_save' ); ?>

	<div class="cl-form__grid">

		<div class="cl-form__col">
			<section class="cl-panel">
				<header class="cl-panel__head">
					<h2 class="cl-panel__title"><?php esc_html_e( '1 · Link type', 'cloaklink' ); ?></h2>
				</header>
				<div class="cl-panel__body">
					<div class="cl-types">
						<label class="cl-type-card<?php echo 'redirect' === $cl_v['link_type'] ? ' is-checked' : ''; ?>">
							<input type="radio" name="cl[link_type]" value="redirect" <?php checked( 'redirect', $cl_v['link_type'] ); ?> data-type="redirect">
							<span class="cl-type-card__icon">↗</span>
							<span class="cl-type-card__title"><?php esc_html_e( 'Website or court link', 'cloaklink' ); ?></span>
							<span class="cl-type-card__desc"><?php esc_html_e( 'Paste a website or court page. Opens the original destination.', 'cloaklink' ); ?></span>
						</label>
						<label class="cl-type-card<?php echo 'legal' === $cl_v['link_type'] ? ' is-checked' : ''; ?>">
							<input type="radio" name="cl[link_type]" value="legal" <?php checked( 'legal', $cl_v['link_type'] ); ?> data-type="legal">
							<span class="cl-type-card__icon">▤</span>
							<span class="cl-type-card__title"><?php esc_html_e( 'Upload document', 'cloaklink' ); ?></span>
							<span class="cl-type-card__desc"><?php esc_html_e( 'Visitors read it on the page. The file is never sent, so it cannot be saved.', 'cloaklink' ); ?></span>
						</label>
						<label class="cl-type-card<?php echo 'instagram' === $cl_v['link_type'] ? ' is-checked' : ''; ?>">
							<input type="radio" name="cl[link_type]" value="instagram" <?php checked( 'instagram', $cl_v['link_type'] ); ?> data-type="instagram">
							<span class="cl-type-card__icon cl-type-card__icon--instagram"><img src="<?php echo esc_url( CLOAKLINK_URL . 'assets/img/instagram.svg' ); ?>" alt="" width="30" height="30"></span>
							<span class="cl-type-card__title"><?php esc_html_e( 'Send Instagram Reel', 'cloaklink' ); ?></span>
							<span class="cl-type-card__desc"><?php esc_html_e( 'Paste a Reel or post link. Opens directly on Instagram.', 'cloaklink' ); ?></span>
						</label>
					</div>
				</div>
			</section>

			<section class="cl-panel">
				<header class="cl-panel__head">
					<h2 class="cl-panel__title"><?php esc_html_e( '2 · Destination', 'cloaklink' ); ?></h2>
				</header>
				<div class="cl-panel__body">

					<div class="cl-field" data-when="redirect">
						<label class="cl-label" for="cl-destination"><?php esc_html_e( 'Paste URL', 'cloaklink' ); ?></label>
						<input class="cl-input" type="url" id="cl-destination" name="cl[destination]" value="<?php echo esc_attr( 'redirect' === $cl_v['link_type'] ? $cl_v['destination'] : '' ); ?>" placeholder="https://example.com" inputmode="url" autocomplete="off">
						<?php if ( isset( $cl_errors['destination'] ) ) : ?><p class="cl-error"><?php echo esc_html( $cl_errors['destination'] ); ?></p><?php endif; ?>
						<p class="cl-help"><?php esc_html_e( 'Paste the website or court page address.', 'cloaklink' ); ?></p>
					</div>

					<div class="cl-field" data-when="instagram">
						<label class="cl-label" for="cl-instagram-url"><?php esc_html_e( 'Instagram Reel or post URL', 'cloaklink' ); ?></label>
						<input class="cl-input" type="url" id="cl-instagram-url" name="cl[media_url]" value="<?php echo esc_attr( 'instagram' === $cl_v['link_type'] ? $cl_v['media_url'] : '' ); ?>" placeholder="https://www.instagram.com/reel/…" inputmode="url" autocomplete="off">
						<?php if ( isset( $cl_errors['media_url'] ) ) : ?><p class="cl-error"><?php echo esc_html( $cl_errors['media_url'] ); ?></p><?php endif; ?>
						<p class="cl-help"><?php esc_html_e( 'Paste the Reel or post link. It opens on Instagram.', 'cloaklink' ); ?></p>
						<label class="cl-label cl-label--tight" for="cl-instagram-preview-url"><?php esc_html_e( 'WhatsApp Preview Link', 'cloaklink' ); ?></label>
						<input class="cl-input" type="url" id="cl-instagram-preview-url" name="cl[instagram_preview_url]" value="<?php echo esc_attr( 'instagram' === $cl_v['link_type'] ? $cl_v['whatsapp_preview_url'] : '' ); ?>" placeholder="https://example.com/preview" inputmode="url" autocomplete="off">
						<p class="cl-help"><?php esc_html_e( 'Optional. The page used to build the WhatsApp preview card.', 'cloaklink' ); ?></p>
						<?php if ( isset( $cl_errors['whatsapp_preview_url'] ) ) : ?><p class="cl-error"><?php echo esc_html( $cl_errors['whatsapp_preview_url'] ); ?></p><?php endif; ?>
						<div class="cl-preview cl-preview--share" id="cl-instagram-preview-card" data-when="instagram" hidden>
							<div class="cl-preview__heading">WhatsApp preview</div>
							<div class="cl-wa-stage cl-wa-stage--inline"><div class="cl-wa-bubble cl-wa-bubble--inline"><div class="cl-wa-card">
								<img id="cl-instagram-preview-image" class="cl-wa-image" src="" alt="" hidden>
								<div class="cl-wa-card__body"><div class="cl-wa-site"><img id="cl-instagram-preview-icon" src="" alt="" width="20" height="20" hidden><span id="cl-instagram-preview-site"></span></div><strong id="cl-instagram-preview-title"></strong><p id="cl-instagram-preview-description"></p><span id="cl-instagram-preview-host"></span></div>
							</div><div class="cl-wa-url" id="cl-instagram-preview-path"></div></div></div>
						</div>
					</div>

					<div class="cl-preview cl-preview--share" id="cl-url-preview" data-when="redirect" hidden>
						<div class="cl-preview__heading">WhatsApp preview</div>
						<div class="cl-wa-stage cl-wa-stage--inline">
							<div class="cl-wa-bubble cl-wa-bubble--inline">
								<div class="cl-wa-card">
									<img id="cl-preview-image" class="cl-wa-image" src="" alt="" hidden>
									<div class="cl-wa-card__body">
										<div class="cl-wa-site"><img id="cl-preview-icon" src="" alt="" width="20" height="20" hidden><span id="cl-preview-site"></span></div>
										<strong id="cl-preview-title"></strong>
										<p id="cl-preview-description"></p>
										<span id="cl-preview-host"></span>
									</div>
								</div>
								<div class="cl-wa-url" id="cl-preview-path"></div>
							</div>
						</div>
					</div>

					<div class="cl-field">
						<label class="cl-label" for="cl-title">
							<?php esc_html_e( 'Internal name', 'cloaklink' ); ?>
							<span class="cl-label__req"><?php esc_html_e( 'required', 'cloaklink' ); ?></span>
						</label>
						<input class="cl-input" type="text" id="cl-title" name="cl[title]" required maxlength="120" value="<?php echo esc_attr( $cl_v['title'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Sam — high court notice', 'cloaklink' ); ?>">
						<p class="cl-help">
							<?php esc_html_e( 'Your own word for this link. Only you see it, and it is how the link is found again on the wall and in the desk.', 'cloaklink' ); ?>
						</p>
						<?php if ( isset( $cl_errors['title'] ) ) : ?><p class="cl-error"><?php echo esc_html( $cl_errors['title'] ); ?></p><?php endif; ?>
					</div>

					<div class="cl-field">
						<label class="cl-label" for="cl-party-name"><?php esc_html_e( 'Name on this file', 'cloaklink' ); ?></label>
						<input class="cl-input" type="text" id="cl-party-name" name="cl[party_name]" value="<?php echo esc_attr( $cl_v['party_name'] ); ?>" placeholder="<?php esc_attr_e( 'Gajendra S N', 'cloaklink' ); ?>" autocomplete="off" maxlength="80">
						<p class="cl-help">
							<?php esc_html_e( 'Who the notice is addressed to. Added to the end of the link address.', 'cloaklink' ); ?>
						</p>
						<?php if ( '' !== (string) $cl_v['party_name'] && '' !== trim( (string) $settings->get( 'slug_prefix' ) ) ) : ?>
							<p class="cl-static">
								<?php
								// The address this name would produce, drawn fresh.
								// Only a guide for an edit: a saved link keeps the
								// address it was issued with, because that address is
								// already in somebody's hands.
								echo esc_html( $settings->base_url() . '/' . CloakLink_Links::file_slug( (string) $settings->get( 'slug_prefix' ), (string) $cl_v['party_name'] ) );
								?>
							</p>
						<?php endif; ?>
					</div>

					<div class="cl-field">
						<label class="cl-label" for="cl-label"><?php esc_html_e( 'URL name (slug)', 'cloaklink' ); ?></label>
						<?php
						$cl_domains = $settings->domains();
						// A new link starts on the primary domain, not on the install's
						// own host: that is the address the operator actually shares.
						$cl_chosen  = $cl_link && ! empty( $cl_link['meta']['domain'] ) ? (string) $cl_link['meta']['domain'] : (string) $settings->get( 'link_domain', '' );
						if ( ! in_array( $cl_chosen, $cl_domains, true ) ) {
							$cl_chosen = isset( $cl_domains[0] ) ? (string) $cl_domains[0] : '';
						}
						?>
						<?php if ( count( $cl_domains ) > 1 ) : ?>
							<select class="cl-input" id="cl-domain" name="cl[domain]">
								<?php foreach ( $cl_domains as $cl_dom ) : ?>
									<option value="<?php echo esc_attr( $cl_dom ); ?>" <?php selected( $cl_chosen, $cl_dom ); ?>><?php echo esc_html( $cl_dom ); ?></option>
								<?php endforeach; ?>
							</select>
						<?php endif; ?>
						<?php if ( $cl_link ) : ?>
							<span class="cl-static" id="cl-url-static" data-slug="<?php echo esc_attr( $links->url( $cl_link['slug'], $cl_chosen ) ); ?>"><?php echo esc_html( $links->url( $cl_link['slug'], $cl_chosen, $cl_v['extension'], $cl_v['link_type'] ) ); ?></span>
							<p class="cl-help"><?php esc_html_e( 'Slugs are permanent so already-shared links keep working. The domain above only changes how the address is printed.', 'cloaklink' ); ?></p>
						<?php else : ?>
							<span class="cl-static" id="cl-url-static" data-slug="<?php echo esc_attr( $settings->base_url( $cl_chosen ) . '/auto-generated' ); ?>"><?php echo esc_html( $settings->base_url( $cl_chosen ) . '/auto-generated' . ( $cl_v['extension'] ? '.' . $cl_v['extension'] : '' ) ); ?></span>
							<?php // The ending above is the Settings default, so the shape shown is the shape issued. JS keeps it in step while the picker is changed. ?>
							<p class="cl-help"><?php esc_html_e( 'A short unguessable code is generated when you save.', 'cloaklink' ); ?></p>
						<?php endif; ?>

						<label class="cl-label cl-label--tight" for="cl-extension"><?php esc_html_e( 'Ends with (file extension)', 'cloaklink' ); ?></label>
						<select class="cl-input" id="cl-extension" name="cl[extension]">
							<option value=""><?php esc_html_e( 'None — leave the address as it is', 'cloaklink' ); ?></option>
							<?php foreach ( CloakLink_Links::EXTENSIONS as $cl_ext ) : ?>
								<option value="<?php echo esc_attr( $cl_ext ); ?>" <?php selected( $cl_v['extension'], $cl_ext ); ?>>.<?php echo esc_html( $cl_ext ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="cl-help"><?php esc_html_e( 'Optional. Makes the link look like a file, e.g. …-GAJENDRA_S_N.pdf. The link works the same either way.', 'cloaklink' ); ?></p>

						<label class="cl-label cl-label--tight" for="cl-label2"><?php esc_html_e( 'Campaign / label', 'cloaklink' ); ?></label>
						<input class="cl-input" type="text" id="cl-label2" name="cl[label]" value="<?php echo esc_attr( $cl_v['label'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Recovery matter, October batch', 'cloaklink' ); ?>">
					</div>

				</div>
			</section>
		</div>

		<div class="cl-form__col">
			<section class="cl-panel">
				<header class="cl-panel__head">
					<h2 class="cl-panel__title"><?php esc_html_e( '3 · Access rules', 'cloaklink' ); ?></h2>
				</header>
				<div class="cl-panel__body">

					<div class="cl-field">
						<label class="cl-label" for="cl-expiry"><?php esc_html_e( 'Expires at', 'cloaklink' ); ?></label>
						<input class="cl-input" type="datetime-local" id="cl-expiry" name="cl[expiry]" value="<?php echo esc_attr( $cl_exp_local ); ?>">
						<div class="cl-chips" role="group" aria-label="<?php esc_attr_e( 'Quick expiry', 'cloaklink' ); ?>">
							<button type="button" class="cl-chipbtn" data-hours="1">1 h</button>
							<button type="button" class="cl-chipbtn" data-hours="6">6 h</button>
							<button type="button" class="cl-chipbtn" data-hours="24">24 h</button>
							<button type="button" class="cl-chipbtn" data-hours="72">3 d</button>
							<button type="button" class="cl-chipbtn" data-hours="168">7 d</button>
							<button type="button" class="cl-chipbtn" data-hours="0"><?php esc_html_e( 'Never', 'cloaklink' ); ?></button>
						</div>
						<p class="cl-help"><?php esc_html_e( 'The link stops working after this date. Leave empty to use the default from Settings.', 'cloaklink' ); ?></p>
					</div>
					<input type="hidden" name="cl[mode]" value="off">
                    <input type="hidden" name="cl[max_clicks]" value="0">

					<div class="cl-field">
						<label class="cl-label" for="cl-status"><?php esc_html_e( 'Status', 'cloaklink' ); ?></label>
						<select class="cl-input" id="cl-status" name="cl[status]">
							<option value="active" <?php selected( 'active', $cl_v['status'] ); ?>><?php esc_html_e( 'Active', 'cloaklink' ); ?></option>
							<option value="paused" <?php selected( 'paused', $cl_v['status'] ); ?>><?php esc_html_e( 'Paused', 'cloaklink' ); ?></option>
						</select>
					</div>

					<div class="cl-field">
						<label class="cl-label" for="cl-notice"><?php esc_html_e( 'Internal note', 'cloaklink' ); ?></label>
						<textarea class="cl-input" id="cl-notice" name="cl[notice]" rows="3" placeholder="<?php esc_attr_e( 'Internal note for this link.', 'cloaklink' ); ?>"><?php echo esc_textarea( $cl_v['notice'] ); ?></textarea>
					</div>

				</div>
			</section>

			<section class="cl-panel" data-when="legal">
				<header class="cl-panel__head">
					<h2 class="cl-panel__title"><?php esc_html_e( 'Upload document', 'cloaklink' ); ?></h2>
				</header>
				<div class="cl-panel__body">
					<?php if ( $cl_file_name ) : ?>
						<div class="cl-attached">
							<span class="cl-attached__ext"><?php echo esc_html( strtoupper( pathinfo( $cl_file_name, PATHINFO_EXTENSION ) ) ); ?></span>
							<span class="cl-attached__name"><?php echo esc_html( $cl_file_name ); ?></span>
							<span class="cl-attached__size"><?php echo $cl_file_size ? esc_html( size_format( $cl_file_size, 1 ) ) : ''; ?></span>
						</div>
						<label class="cl-checkline">
							<input type="checkbox" name="cl_file_remove" value="1">
							<span><?php esc_html_e( 'Remove this file from the link', 'cloaklink' ); ?></span>
						</label>
						<p class="cl-help"><?php esc_html_e( 'Choosing a new file below replaces this one.', 'cloaklink' ); ?></p>
					<?php endif; ?>

					<div class="cl-field">
						<label class="cl-label" for="cl-file"><?php echo $cl_file_name ? esc_html__( 'Replace the file', 'cloaklink' ) : esc_html__( 'Upload the document', 'cloaklink' ); ?></label>
						<?php if ( isset( $cl_errors['file'] ) ) : ?><p class="cl-error"><?php echo esc_html( $cl_errors['file'] ); ?></p><?php endif; ?>
						<input class="cl-input cl-input--file" id="cl-file" name="cl_file" type="file"
							accept="application/pdf,.pdf">
						<p class="cl-help">
							<?php
							printf(
								/* translators: %d: megabytes */
								esc_html__( 'PDF only, up to %d MB. The file stays private and is never sent to the visitor.', 'cloaklink' ),
								(int) $settings->get( 'max_file_mb', 25 )
							);
							?>
						</p>
					</div>

					<div class="cl-field">
						<label class="cl-label" for="cl-document-preview-url"><?php esc_html_e( 'WhatsApp Preview Link', 'cloaklink' ); ?></label>
						<input class="cl-input" type="url" id="cl-document-preview-url" name="cl[document_preview_url]" value="<?php echo esc_attr( 'legal' === $cl_v['link_type'] ? $cl_v['whatsapp_preview_url'] : '' ); ?>" placeholder="https://example.com/preview" inputmode="url" autocomplete="off">
						<p class="cl-help"><?php esc_html_e( 'Optional. The page this document came from. Used only to build the WhatsApp preview.', 'cloaklink' ); ?></p>
						<?php if ( isset( $cl_errors['whatsapp_preview_url'] ) ) : ?><p class="cl-error"><?php echo esc_html( $cl_errors['whatsapp_preview_url'] ); ?></p><?php endif; ?>
					</div>

					<div class="cl-preview cl-preview--share" id="cl-document-preview-card" data-when="legal" hidden>
						<div class="cl-preview__heading">WhatsApp preview</div>
						<div class="cl-wa-stage cl-wa-stage--inline"><div class="cl-wa-bubble cl-wa-bubble--inline"><div class="cl-wa-card">
							<img id="cl-document-preview-image" class="cl-wa-image" src="" alt="" hidden>
							<div class="cl-wa-card__body"><div class="cl-wa-site"><img id="cl-document-preview-icon" src="" alt="" width="20" height="20" hidden><span id="cl-document-preview-site"></span></div><strong id="cl-document-preview-title"></strong><p id="cl-document-preview-description"></p><span id="cl-document-preview-host"></span></div>
						</div><div class="cl-wa-url" id="cl-document-preview-path"></div></div></div>
					</div>
				</div>
			</section>

			<section class="cl-panel">
				<header class="cl-panel__head">
					<h2 class="cl-panel__title"><?php esc_html_e( 'Access control', 'cloaklink' ); ?></h2>
				</header>
				<div class="cl-panel__body">
					<div class="cl-field">
						<label class="cl-label" for="cl-pin"><?php esc_html_e( 'Access PIN (optional)', 'cloaklink' ); ?></label>
						<input class="cl-input" id="cl-pin" name="cl[pin]" type="text" inputmode="numeric" maxlength="10"
							placeholder="<?php echo $cl_has_pin ? esc_attr__( 'A PIN is set — leave blank to keep it', 'cloaklink' ) : esc_attr__( 'e.g. 4821', 'cloaklink' ); ?>">
						<p class="cl-help"><?php esc_html_e( '4 to 10 digits. The visitor must enter this before the link opens. Send it separately from the link.', 'cloaklink' ); ?></p>
						<?php if ( $cl_has_pin ) : ?>
							<label class="cl-checkline">
								<input type="checkbox" name="cl[pin_remove]" value="1">
								<span><?php esc_html_e( 'Remove the PIN from this link', 'cloaklink' ); ?></span>
							</label>
						<?php endif; ?>
					</div>

				</div>
			</section>

			<section class="cl-panel">
				<div class="cl-panel__body cl-actions">
					<button type="submit" class="cl-btn cl-btn--gold cl-btn--wide"><?php echo $cl_link ? esc_html__( 'Save changes', 'cloaklink' ) : esc_html__( 'Create link', 'cloaklink' ); ?></button>
					<a class="cl-btn cl-btn--ghost cl-btn--wide" href="<?php echo esc_url( CloakLink_Admin::url( 'links' ) ); ?>"><?php esc_html_e( 'Cancel', 'cloaklink' ); ?></a>
				</div>
			</section>

			<?php if ( $cl_link ) : ?>
				<section class="cl-panel">
					<header class="cl-panel__head">
						<h2 class="cl-panel__title"><?php esc_html_e( 'Shared link', 'cloaklink' ); ?></h2>
					</header>
					<div class="cl-panel__body">
						<p class="cl-sharelink" id="cl-sharelink" data-slug="<?php echo esc_attr( $links->url( $cl_link['slug'], $cl_chosen ) ); ?>"><?php echo esc_html( $links->url( $cl_link['slug'], $cl_chosen, $cl_v['extension'], $cl_v['link_type'] ) ); ?></p>
						<button type="button" class="cl-btn cl-btn--ghost cl-btn--wide cl-copy" id="cl-sharelink-copy" data-clipboard="<?php echo esc_attr( $links->url( $cl_link['slug'], $cl_chosen, $cl_v['extension'], $cl_v['link_type'] ) ); ?>"><?php esc_html_e( 'Copy link', 'cloaklink' ); ?></button>
					</div>
				</section>
			<?php endif; ?>
		</div>
	</div>
</form>

