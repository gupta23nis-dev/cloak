<?php
/**
 * Single-link activity.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_id   = CloakLink_Admin::current_id();
$cl_link = $cl_id ? $cl_db->get_link( $cl_id ) : null;

if ( ! $cl_link ) {
	echo '<div class="cl-panel"><div class="cl-panel__body"><p class="cl-empty">' . esc_html__( 'That link no longer exists.', 'cloaklink' ) . '</p></div></div>';
	return;
}

$cl_url    = $links->link_url( $cl_link );
$cl_stats  = $cl_db->link_stats( $cl_link['id'] );
$cl_recent = $cl_db->recent_visits( $cl_link['id'], 20 );
$cl_share  = $links->share_text( $cl_link );
$cl_exp_ts = $cl_db->to_ts( $cl_link['expires_at'] );
$cl_meta   = $cl_link['meta'];
?>

<div class="cl-detail-head">
	<div>
		<p class="cl-eyebrow"><?php echo esc_html( 'instagram' === $cl_link['link_type'] ? __( 'Instagram link', 'cloaklink' ) : ( 'legal' === $cl_link['link_type'] ? __( 'Document link', 'cloaklink' ) : __( 'Website / social link', 'cloaklink' ) ) ); ?></p>
		<h2 class="cl-detail-title"><?php echo esc_html( $cl_link['title'] ); ?></h2>
		<p class="cl-detail-sub"><?php echo esc_html( $cl_link['destination_host'] ); ?> · <?php echo esc_html( $admin->fmt_dt( $cl_link['created_at'] ) ); ?></p>
	</div>
	<div class="cl-detail-actions">
		<?php echo $links->badge( $cl_link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'edit', array( 'id' => $cl_link['id'] ) ) ); ?>"><?php esc_html_e( 'Edit', 'cloaklink' ); ?></a>
		<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( $cl_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open', 'cloaklink' ); ?> ↗</a>
	</div>
</div>

<?php if ( 'legal' === $cl_link['link_type'] && empty( $cl_meta['file_path'] ) ) : ?>
	<?php
	// A document link with no document opens to a page that can only say the
	// notice is not available, whatever the visitor does. Saying so here, on
	// the page the operator lands on after saving, is the only place it can be
	// fixed — so it is said plainly, with the two ways out.
	?>
	<section class="cl-panel cl-panel--warn">
		<div class="cl-panel__body cl-warnrow">
			<div class="cl-warnrow__text">
				<p class="cl-warnrow__title"><?php esc_html_e( 'No document attached', 'cloaklink' ); ?></p>
				<p class="cl-warnrow__body"><?php esc_html_e( 'This address opens a page that has nothing to show. Upload the document, or remove the link.', 'cloaklink' ); ?></p>
			</div>
			<div class="cl-warnrow__acts">
				<a class="cl-btn cl-btn--gold" href="<?php echo esc_url( CloakLink_Admin::url( 'edit', array( 'id' => $cl_link['id'] ) ) ); ?>"><?php esc_html_e( 'Upload the document', 'cloaklink' ); ?></a>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="cloaklink_link_action">
					<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_link['id'] ); ?>">
					<input type="hidden" name="cl_action" value="delete">
					<?php wp_nonce_field( 'cloaklink_link_action' ); ?>
					<button type="submit" class="cl-btn cl-btn--ghost cl-btn--danger"><?php esc_html_e( 'Delete the link', 'cloaklink' ); ?></button>
				</form>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php
// A link that was just made is a link the operator has to send somewhere, and
// the moment they are most likely to want the address is the moment the page
// arrives. So the page says what just happened, shows the address already
// selected, and offers one button that copies it.
$cl_fresh = isset( $_GET['cl_notice'] ) && 'saved' === sanitize_key( wp_unslash( $_GET['cl_notice'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
$cl_created = isset( $_GET['cl_new'] ) && '1' === (string) sanitize_key( wp_unslash( $_GET['cl_new'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
?>
<?php if ( $cl_created ) : ?>
	<section class="cl-created" id="cl-created">
		<span class="cl-created__tick" aria-hidden="true">✓</span>
		<div class="cl-created__body">
			<p class="cl-created__title"><?php esc_html_e( 'Link created. This is its address.', 'cloaklink' ); ?></p>
			<p class="cl-created__url"><code id="cl-created-url"><?php echo esc_html( $cl_url ); ?></code></p>
		</div>
		<div class="cl-created__acts">
			<button type="button" class="cl-btn cl-btn--gold cl-copy" id="cl-created-copy" data-clipboard="<?php echo esc_attr( $cl_url ); ?>"><?php esc_html_e( 'Copy link', 'cloaklink' ); ?></button>
			<a class="cl-btn cl-btn--ghost" target="_blank" rel="noopener" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( $cl_share ) ); ?>">WhatsApp</a>
		</div>
	</section>
<?php endif; ?>

<section class="cl-panel cl-panel--share">
	<div class="cl-panel__body">
		<div class="cl-sharerow">
			<input class="cl-input cl-input--mono" type="text" readonly value="<?php echo esc_attr( $cl_url ); ?>" id="cl-share-url">
			<button type="button" class="cl-btn cl-btn--gold cl-copy" data-clipboard="<?php echo esc_attr( $cl_url ); ?>"><?php esc_html_e( 'Copy', 'cloaklink' ); ?></button>
			<a class="cl-btn cl-btn--ghost" target="_blank" rel="noopener" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( $cl_share ) ); ?>">WhatsApp</a>
			<a class="cl-btn cl-btn--ghost" target="_blank" rel="noopener" href="<?php echo esc_url( 'mailto:?subject=' . rawurlencode( $cl_link['title'] ) . '&body=' . rawurlencode( $cl_share ) ); ?>"><?php esc_html_e( 'Email', 'cloaklink' ); ?></a>
		</div>
	</div>
</section>


<section class="cl-kpis cl-kpis--tight">
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Total events', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['total'] ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Opened', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['opens'] ) ); ?></p>
		<p class="cl-kpi__foot"><?php echo esc_html( sprintf( /* translators: %s: number */ __( '%s unique networks', 'cloaklink' ), number_format_i18n( $cl_stats['unique'] ) ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Blocked', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['blocked'] ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Countries', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['countries'] ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Expiry', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value cl-kpi__value--sm"><?php echo $cl_exp_ts ? esc_html( $admin->fmt_dt( $cl_link['expires_at'], 'short' ) ) : esc_html__( 'Never', 'cloaklink' ); ?></p>
		<?php if ( $cl_exp_ts ) : ?>
			<p class="cl-kpi__foot"><?php echo esc_html( human_time_diff( time(), $cl_exp_ts ) ); ?> <?php esc_html_e( 'left', 'cloaklink' ); ?></p>
		<?php endif; ?>
	</article>
</section>

<div class="cl-grid cl-grid--side">
	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Activity', 'cloaklink' ); ?></h2>
		</header>
		<div class="cl-panel__body cl-panel__body--flush">
			<div class="cl-table-wrap">
				<table class="cl-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Time', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Event', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Device', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Location', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'GPS', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Network', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Risk', 'cloaklink' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						if ( $cl_recent ) {
							foreach ( $cl_recent as $cl_row ) {
								echo $admin->visit_row_html( $cl_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
						} else {
							echo '<tr><td colspan="7" class="cl-empty">' . esc_html__( 'No activity yet.', 'cloaklink' ) . '</td></tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
		<footer class="cl-panel__foot">
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'visits', array( 'id' => $cl_link['id'] ) ) ); ?>"><?php esc_html_e( 'Full log for this link', 'cloaklink' ); ?> →</a>
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( $admin->export_url( 'csv', $cl_link['id'] ) ); ?>"><?php esc_html_e( 'Download CSV', 'cloaklink' ); ?></a>
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( $admin->export_url( 'pdf', $cl_link['id'] ) ); ?>"><?php esc_html_e( 'Download PDF', 'cloaklink' ); ?></a>
		</footer>
	</section>

	<aside class="cl-panel cl-panel--facts">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Configuration', 'cloaklink' ); ?></h2>
		</header>
		<dl class="cl-facts">
			<dt><?php esc_html_e( 'Slug', 'cloaklink' ); ?></dt>
			<dd><code><?php echo esc_html( $cl_link['slug'] . ( $links->extension( $cl_link ) ? '.' . $links->extension( $cl_link ) : '' ) ); ?></code></dd>
			<dt><?php esc_html_e( 'Destination', 'cloaklink' ); ?></dt>
			<dd class="cl-break"><?php echo esc_html( $cl_link['destination'] ); ?></dd>
			<?php if ( $cl_link['media_url'] ) : ?>
				<dt><?php esc_html_e( 'Instagram', 'cloaklink' ); ?></dt>
				<dd class="cl-break"><?php echo esc_html( $cl_link['media_url'] ); ?></dd>
			<?php endif; ?>
			<dt><?php esc_html_e( 'Location', 'cloaklink' ); ?></dt>
			<dd><?php echo esc_html( 'require' === $cl_link['mode'] ? __( 'Required', 'cloaklink' ) : ( 'optional' === $cl_link['mode'] ? __( 'Requested', 'cloaklink' ) : __( 'Skipped', 'cloaklink' ) ) ); ?></dd>
			<dt><?php esc_html_e( 'Openings', 'cloaklink' ); ?></dt>
			<dd><?php echo esc_html( number_format_i18n( (int) $cl_link['click_count'] ) . ( (int) $cl_link['max_clicks'] ? ' / ' . number_format_i18n( (int) $cl_link['max_clicks'] ) : '' ) ); ?></dd>
			<dt><?php esc_html_e( 'Label', 'cloaklink' ); ?></dt>
			<dd><?php echo $cl_link['label'] ? esc_html( $cl_link['label'] ) : '—'; ?></dd>
			<dt><?php esc_html_e( 'Owner', 'cloaklink' ); ?></dt>
			<dd><?php echo esc_html( get_the_author_meta( 'display_name', (int) $cl_link['created_by'] ) ); ?></dd>
			<dt><?php esc_html_e( 'Created', 'cloaklink' ); ?></dt>
			<dd><?php echo esc_html( $admin->fmt_dt( $cl_link['created_at'] ) ); ?></dd>
			<dt><?php esc_html_e( 'Last visit', 'cloaklink' ); ?></dt>
			<dd><?php echo esc_html( $cl_stats['last'] ? $admin->fmt_dt( $cl_stats['last'] ) : '—' ); ?></dd>
			<?php if ( ! empty( $cl_link['meta']['pin_hash'] ) ) : ?>
				<dt><?php esc_html_e( 'PIN', 'cloaklink' ); ?></dt>
				<dd><span class="cl-badge cl-badge--ok"><?php esc_html_e( 'Required', 'cloaklink' ); ?></span></dd>
			<?php endif; ?>
			<?php if ( ! empty( $cl_link['meta']['single_use'] ) ) : ?>
				<dt><?php esc_html_e( 'Single use', 'cloaklink' ); ?></dt>
				<dd>
					<?php if ( ! empty( $cl_link['meta']['locked_hash'] ) ) : ?>
						<span class="cl-badge cl-badge--muted"><?php esc_html_e( 'Locked to first visitor', 'cloaklink' ); ?></span>
						<?php if ( ! empty( $cl_link['meta']['locked_at'] ) ) : ?>
							<small class="cl-muted"><?php echo esc_html( $admin->fmt_dt( $cl_link['meta']['locked_at'], 'short' ) ); ?></small>
						<?php endif; ?>
					<?php else : ?>
						<span class="cl-badge cl-badge--muted"><?php esc_html_e( 'Waiting for first open', 'cloaklink' ); ?></span>
					<?php endif; ?>
				</dd>
			<?php endif; ?>
		</dl>
		<footer class="cl-panel__foot cl-panel__foot--split">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cloaklink_link_action">
				<input type="hidden" name="id" value="<?php echo esc_attr( $cl_link['id'] ); ?>">
				<?php wp_nonce_field( 'cloaklink_link_action' ); ?>
				<button type="submit" class="cl-btn cl-btn--ghost" name="cl_action" value="<?php echo 'paused' === $cl_link['status'] ? 'resume' : 'pause'; ?>">
					<?php echo 'paused' === $cl_link['status'] ? esc_html__( 'Resume link', 'cloaklink' ) : esc_html__( 'Pause link', 'cloaklink' ); ?>
				</button>
				<?php if ( ! empty( $cl_link['meta']['locked_hash'] ) ) : ?>
					<button type="submit" class="cl-btn cl-btn--ghost" name="cl_action" value="unlock" title="<?php esc_attr_e( 'Allow the link to be opened on a new device', 'cloaklink' ); ?>">
						<?php esc_html_e( 'Reset lock', 'cloaklink' ); ?>
					</button>
				<?php endif; ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Delete this link and all its visit records?', 'cloaklink' ) ); ?>">
				<input type="hidden" name="action" value="cloaklink_link_action">
				<input type="hidden" name="id" value="<?php echo esc_attr( $cl_link['id'] ); ?>">
				<?php wp_nonce_field( 'cloaklink_link_action' ); ?>
				<button type="submit" class="cl-btn cl-btn--danger" name="cl_action" value="delete"><?php esc_html_e( 'Delete', 'cloaklink' ); ?></button>
			</form>
		</footer>
	</aside>
</div>

<?php
$cl_points = $admin->map_points( $cl_link['id'], 12 );
$cl_last   = $cl_points ? $cl_points[0] : null;
?>

<?php if ( $cl_last ) : ?>
<section class="cl-panel cl-panel--map">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Location map', 'cloaklink' ); ?></h2>
		<span class="cl-panel__hint"><?php esc_html_e( 'latest verified fix', 'cloaklink' ); ?></span>
	</header>
	<div class="cl-panel__body cl-panel__body--flush">
		<?php echo $admin->map_embed( $cl_last['lat'], $cl_last['lng'], 300 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<div class="cl-mapmeta">
			<div>
				<strong><?php echo esc_html( $cl_last['city'] ? $cl_last['city'] . ', ' : '' ); ?><?php echo esc_html( $cl_last['country'] ); ?></strong>
				<span><?php echo esc_html( $cl_last['when'] ); ?> · <?php echo esc_html( $cl_last['device'] ); ?> · <?php echo esc_html( $cl_last['ip'] ); ?></span>
			</div>
			<a class="cl-btn cl-btn--gold cl-btn--sm" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $admin->map_url( $cl_last['lat'], $cl_last['lng'] ) ); ?>">
				<?php esc_html_e( 'Open in Google Maps', 'cloaklink' ); ?> ↗
			</a>
		</div>
		<?php if ( count( $cl_points ) > 1 ) : ?>
			<ul class="cl-maplist">
				<?php foreach ( $cl_points as $cl_p ) : ?>
					<li>
						<a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $admin->map_url( $cl_p['lat'], $cl_p['lng'] ) ); ?>">
							<span class="cl-maplist__pin" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'position', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
							<span class="cl-maplist__place"><?php echo esc_html( $cl_p['city'] ? $cl_p['city'] : $cl_p['country'] ); ?></span>
							<span class="cl-maplist__coords"><?php echo esc_html( $cl_p['lat'] . ', ' . $cl_p['lng'] ); ?></span>
							<span class="cl-maplist__when"><?php echo esc_html( $cl_p['when'] ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>
<?php endif; ?>

<?php if ( ! empty( $cl_meta['place'] ) ) : ?>
	<p class="cl-help cl-help--foot"><?php echo esc_html( sprintf( /* translators: %s: place name */ __( 'Last resolved place: %s', 'cloaklink' ), $cl_meta['place'] ) ); ?></p>
<?php endif; ?>
