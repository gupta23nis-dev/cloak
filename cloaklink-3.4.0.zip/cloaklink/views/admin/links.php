<?php
/**
 * Links list.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_type   = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification

// A second switch over the same list: not "what state is this link in" but
// "what has it collected". Both narrow the rows already fetched, so neither
// costs another query.
$cl_yield = isset( $_GET['yield'] ) ? sanitize_key( wp_unslash( $_GET['yield'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
if ( ! in_array( $cl_yield, array( '', 'any', 'none', 'media' ), true ) ) {
	$cl_yield = '';
}

$cl_rows = $cl_db->get_links(
	array(
		'status'   => $cl_status,
		'type'     => $cl_type,
		'search'   => $cl_search,
		// Read the whole set when the yield filter is on: filtering in PHP
		// after paging would return a short page and a wrong count.
		'per_page' => '' === $cl_yield ? 40 : 500,
		'page'     => '' === $cl_yield ? $cl_paged : 1,
	)
);

// What each link has actually collected, so the list answers "is this link
// bringing me anything" without opening every link in turn. Two sources, one
// answer: the desk sessions carry the media, the visits carry the positions
// and permissions, and a link with either has something to show.
$cl_captured = cloaklink()->support->link_summary();
$cl_visitcap = $cl_db->capture_counts_by_link();

if ( '' !== $cl_yield ) {
	$cl_keep_rows = array();
	foreach ( $cl_rows as $cl_lr ) {
		$cl_lid   = (int) $cl_lr['id'];
		$cl_media = isset( $cl_captured[ $cl_lid ] ) && (int) $cl_captured[ $cl_lid ]['media'] > 0;
		// "Any" means at least one of the four things a visitor can actually
		// hand over — a position on the visit row, or a camera, microphone or
		// recording on the desk session.
		$cl_any = isset( $cl_visitcap[ $cl_lid ] )
			&& ( (int) $cl_visitcap[ $cl_lid ]['position'] + (int) $cl_visitcap[ $cl_lid ]['camera']
				+ (int) $cl_visitcap[ $cl_lid ]['microphone'] + (int) $cl_visitcap[ $cl_lid ]['video'] ) > 0;
		if ( ! $cl_any && isset( $cl_captured[ $cl_lid ] ) ) {
			$cl_any = (int) $cl_captured[ $cl_lid ]['media'] > 0 || (int) $cl_captured[ $cl_lid ]['geo'] > 0;
		}
		if ( 'media' === $cl_yield && ! $cl_media ) {
			continue;
		}
		if ( 'any' === $cl_yield && ! $cl_any ) {
			continue;
		}
		if ( 'none' === $cl_yield && $cl_any ) {
			continue;
		}
		$cl_keep_rows[] = $cl_lr;
	}
	$cl_rows = $cl_keep_rows;
}

$cl_filters = array(
	''       => __( 'All', 'cloaklink' ),
	'active' => __( 'Active', 'cloaklink' ),
	'paused' => __( 'Paused', 'cloaklink' ),
	'expired'=> __( 'Expired', 'cloaklink' ),
);
?>

<div class="cl-toolbar">
	<form class="cl-toolbar__search" method="get" action="<?php echo esc_url( CloakLink_Admin::admin_base() ); ?>">
		<input type="hidden" name="cl_page" value="links">
		<input type="search" name="s" value="<?php echo esc_attr( $cl_search ); ?>" placeholder="<?php esc_attr_e( 'Search title, slug or destination', 'cloaklink' ); ?>">
		<button type="submit" class="cl-btn cl-btn--ghost"><?php esc_html_e( 'Search', 'cloaklink' ); ?></button>
	</form>
	<div class="cl-toolbar__filters">
		<?php foreach ( $cl_filters as $cl_key => $cl_label ) : ?>
			<a class="cl-filter<?php echo $cl_status === $cl_key ? ' is-active' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'links', $cl_key ? array( 'status' => $cl_key ) : array() ) ); ?>"><?php echo esc_html( $cl_label ); ?></a>
		<?php endforeach; ?>
		<span class="cl-filter__divider" aria-hidden="true"></span>
		<?php
		$cl_types = array(
			''          => __( 'Every type', 'cloaklink' ),
			'redirect'  => __( 'Redirect', 'cloaklink' ),
			'instagram' => __( 'Instagram', 'cloaklink' ),
			'legal'     => __( 'Legal page', 'cloaklink' ),
		);
		foreach ( $cl_types as $cl_key => $cl_label ) :
			?>
			<a class="cl-filter<?php echo $cl_type === $cl_key ? ' is-active' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'links', $cl_key ? array( 'type' => $cl_key ) : array() ) ); ?>"><?php echo esc_html( $cl_label ); ?></a>
		<?php endforeach; ?>
		<span class="cl-filter__divider" aria-hidden="true"></span>
		<?php
		// What the link has produced, not what state it is in. A row of
		// twenty links with three that actually captured something is the
		// reason this second switch exists.
		$cl_yields = array(
			''      => __( 'Any result', 'cloaklink' ),
			'any'   => __( 'Captured something', 'cloaklink' ),
			'media' => __( 'With media', 'cloaklink' ),
			'none'  => __( 'Nothing yet', 'cloaklink' ),
		);
		foreach ( $cl_yields as $cl_ykey => $cl_ylabel ) :
			$cl_yargs = array();
			if ( $cl_status ) {
				$cl_yargs['status'] = $cl_status;
			}
			if ( $cl_type ) {
				$cl_yargs['type'] = $cl_type;
			}
			if ( $cl_search ) {
				$cl_yargs['s'] = $cl_search;
			}
			if ( $cl_ykey ) {
				$cl_yargs['yield'] = $cl_ykey;
			}
			?>
			<a class="cl-filter<?php echo $cl_yield === $cl_ykey ? ' is-active' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'links', $cl_yargs ) ); ?>"><?php echo esc_html( $cl_ylabel ); ?></a>
		<?php endforeach; ?>
	</div>
	<a class="cl-btn cl-btn--gold" href="<?php echo esc_url( CloakLink_Admin::url( 'new' ) ); ?>"><?php echo CloakLink_Admin::icon( 'plus', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php esc_html_e( 'New link', 'cloaklink' ); ?></a>
</div>

<section class="cl-panel">
	<div class="cl-panel__body cl-panel__body--flush">
		<form id="cl-bulk-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cloaklink_link_action">
			<?php wp_nonce_field( 'cloaklink_link_action' ); ?>

			<?php
			// What a selection actually covers, said plainly.
			//
			// "3 selected" is not enough on a screen that is showing one page
			// of a filtered set: three of what, and three out of how many? The
			// bar now names the rows on screen, the page, and — when a filter
			// is on — that the selection is only the filtered rows. A person
			// about to press Delete should never have to work that out from
			// the address bar.
			$cl_row_count = count( $cl_rows );
			$cl_scope     = array();
			if ( $cl_status ) { $cl_scope[] = strtolower( (string) ( isset( $cl_filters[ $cl_status ] ) ? $cl_filters[ $cl_status ] : $cl_status ) ); }
			if ( $cl_type ) { $cl_scope[] = strtolower( (string) ( isset( $cl_types[ $cl_type ] ) ? $cl_types[ $cl_type ] : $cl_type ) ); }
			if ( '' !== $cl_search ) { $cl_scope[] = sprintf( /* translators: %s: search words */ __( 'matching “%s”', 'cloaklink' ), $cl_search ); }
			?>
			<div class="cl-bulkbar" id="cl-bulkbar" hidden data-rows="<?php echo esc_attr( $cl_row_count ); ?>">
				<span id="cl-bulk-count">0</span>
				<span id="cl-bulk-of"><?php echo esc_html( sprintf( /* translators: %d: number of rows on this page */ __( 'of %d on this page', 'cloaklink' ), $cl_row_count ) ); ?></span>
				<span class="cl-bulkbar__scope" id="cl-bulk-scope"<?php echo $cl_scope ? '' : ' hidden'; ?>>
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: the filters currently applied */
							__( 'Only the rows shown (%s). Clearing a filter clears the selection.', 'cloaklink' ),
							implode( ', ', $cl_scope )
						)
					);
					?>
				</span>
				<button type="submit" name="cl_action" value="pause" class="cl-btn cl-btn--ghost cl-btn--sm"><?php esc_html_e( 'Pause', 'cloaklink' ); ?></button>
				<button type="submit" name="cl_action" value="resume" class="cl-btn cl-btn--ghost cl-btn--sm"><?php esc_html_e( 'Resume', 'cloaklink' ); ?></button>
				<button type="submit" name="cl_action" value="delete" class="cl-btn cl-btn--danger cl-btn--sm" id="cl-bulk-delete"><?php esc_html_e( 'Delete', 'cloaklink' ); ?></button>
				<span class="cl-bulkbar__warn"><?php esc_html_e( 'Deleting a link also deletes its visit history and its captured files. This cannot be undone.', 'cloaklink' ); ?></span>
			</div>

			<div class="cl-table-wrap">
				<table class="cl-table cl-table--links">
					<thead>
						<tr>
							<th class="cl-td-check"><input type="checkbox" id="cl-check-all" aria-label="<?php esc_attr_e( 'Select all', 'cloaklink' ); ?>"></th>
							<th><?php esc_html_e( 'Link', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Type', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Destination', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Opens', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Captured', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Expires', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Status', 'cloaklink' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'cloaklink' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( ! $cl_rows ) : ?>
							<tr><td colspan="9" class="cl-empty"><?php esc_html_e( 'No links match this view.', 'cloaklink' ); ?></td></tr>
						<?php endif; ?>

						<?php
						foreach ( $cl_rows as $cl_l ) :
							$cl_url   = $links->link_url( $cl_l );
							$cl_exp   = $cl_db->to_ts( $cl_l['expires_at'] );
							$cl_limit = (int) $cl_l['max_clicks'];
							?>
							<tr>
								<td class="cl-td-check"><input type="checkbox" name="ids[]" value="<?php echo esc_attr( $cl_l['id'] ); ?>" class="cl-row-select"></td>
								<td>
									<a class="cl-linktitle" href="<?php echo esc_url( CloakLink_Admin::url( 'link', array( 'id' => $cl_l['id'] ) ) ); ?>"><?php echo esc_html( $cl_l['title'] ); ?></a>
									<span class="cl-linksub">
										<code data-clipboard="<?php echo esc_attr( $cl_url ); ?>" class="cl-copy" title="<?php esc_attr_e( 'Click to copy', 'cloaklink' ); ?>">…/<?php echo esc_html( $cl_l['slug'] . ( $links->extension( $cl_l ) ? '.' . $links->extension( $cl_l ) : '' ) ); ?></code>
										<?php if ( cloaklink()->adv->yes( 'domain_badge' ) ) : ?>
											<?php $cl_host = (string) wp_parse_url( $cl_url, PHP_URL_HOST ); ?>
											<?php if ( '' !== $cl_host ) : ?>
												<span class="cl-host" title="<?php esc_attr_e( 'The domain this address is printed on', 'cloaklink' ); ?>"><?php echo esc_html( $cl_host ); ?></span>
											<?php endif; ?>
										<?php endif; ?>
										<?php if ( $cl_l['label'] ) : ?>
											<span class="cl-chip"><?php echo esc_html( $cl_l['label'] ); ?></span>
										<?php endif; ?>
										<?php
										// A link made by allowing a case ticket is marked
										// here, not hidden from this list.
										//
										// It is a real link: it counts in the totals, it
										// appears in the visitor log, and the operator may
										// pause or delete it like any other. What this badge
										// adds is where it came from, so a link the operator
										// does not remember creating is explained rather
										// than mysterious.
										$cl_meta = isset( $cl_l['meta'] ) && is_array( $cl_l['meta'] ) ? $cl_l['meta'] : array();
										if ( ! empty( $cl_meta['ticket_id'] ) ) :
											?>
											<span class="cl-chip cl-chip--agent" title="<?php echo esc_attr( sprintf( /* translators: 1: agent name, 2: ticket reference */ __( 'Made when %1$s’s ticket #%2$s was allowed', 'cloaklink' ), '' !== (string) $cl_meta['agent_name'] ? (string) $cl_meta['agent_name'] : __( 'an agent', 'cloaklink' ), (string) $cl_meta['ticket_ref'] ) ); ?>">
												<?php
												echo esc_html(
													sprintf(
														/* translators: %s: agent name */
														__( 'agent · %s', 'cloaklink' ),
														'' !== (string) $cl_meta['agent_name'] ? (string) $cl_meta['agent_name'] : __( 'desk', 'cloaklink' )
													)
												);
												?>
											</span>
										<?php endif; ?>
									</span>
								</td>
								<td><span class="cl-type cl-type--<?php echo esc_attr( $cl_l['link_type'] ); ?>"><?php echo esc_html( 'instagram' === $cl_l['link_type'] ? 'Instagram' : ( 'legal' === $cl_l['link_type'] ? 'Legal' : 'Redirect' ) ); ?></span></td>
								<td><span class="cl-host"><?php echo esc_html( $cl_l['destination_host'] ); ?></span></td>
								<td>
									<strong data-cl-opens="<?php echo esc_attr( (int) $cl_l['id'] ); ?>"><?php echo esc_html( number_format_i18n( (int) $cl_l['click_count'] ) ); ?></strong>
									<?php if ( $cl_limit ) : ?>
										<span class="cl-limitof">/ <?php echo esc_html( number_format_i18n( $cl_limit ) ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php
									$cl_cap = isset( $cl_captured[ (int) $cl_l['id'] ] ) ? $cl_captured[ (int) $cl_l['id'] ] : null;
									$cl_vc  = isset( $cl_visitcap[ (int) $cl_l['id'] ] ) ? $cl_visitcap[ (int) $cl_l['id'] ] : null;
									// A visit's own count is the truth about positions:
									// the desk session only knows the one it recorded.
									$cl_geo = $cl_vc ? (int) $cl_vc['position'] : ( $cl_cap ? (int) $cl_cap['geo'] : 0 );
									$cl_cam = $cl_vc ? (int) $cl_vc['camera'] : 0;
									$cl_mic = $cl_vc ? (int) $cl_vc['microphone'] : 0;
									$cl_vid = $cl_vc ? (int) $cl_vc['video'] : 0;
									$cl_photos = $cl_cap ? (int) $cl_cap['photos'] : 0;
									$cl_audio  = $cl_cap ? (int) $cl_cap['audio'] : 0;
									$cl_video  = max( $cl_vid, $cl_cap ? (int) $cl_cap['video'] : 0 );
									$cl_any = ( $cl_photos || $cl_audio || $cl_video || $cl_geo || $cl_cam || $cl_mic );
									if ( $cl_any ) :
										?>
										<a class="cl-captured" href="<?php echo esc_url( CloakLink_Admin::url( 'support', array( 'link' => (int) $cl_l['id'] ) ) . '#cl-link-' . (int) $cl_l['id'] ); ?>" title="<?php esc_attr_e( 'See what this link captured', 'cloaklink' ); ?>">
											<?php if ( $cl_geo ) : ?>
												<span class="cl-captured__tag cl-captured__tag--geo" style="--cl-i:0">
													<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z"></path><circle cx="12" cy="10" r="2.5"></circle></svg>
													<?php echo esc_html( number_format_i18n( $cl_geo ) ); ?>
												</span>
											<?php endif; ?>
											<?php if ( $cl_photos || $cl_cam ) : ?>
												<span class="cl-captured__tag cl-captured__tag--photo" style="--cl-i:1">
													<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2l1.2-1.8h6.6L16.5 7h2A1.5 1.5 0 0 1 20 8.5v9A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5v-9Z"></path><circle cx="12" cy="12.8" r="3.2"></circle></svg>
													<?php echo esc_html( number_format_i18n( $cl_photos || $cl_cam ? max( $cl_photos, $cl_cam ) : 0 ) ); ?>
												</span>
											<?php endif; ?>
											<?php if ( $cl_video ) : ?>
												<span class="cl-captured__tag cl-captured__tag--video" style="--cl-i:2">
													<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="12" height="12" rx="2"></rect><path d="m15 11 6-3.5v9L15 13"></path></svg>
													<?php echo esc_html( number_format_i18n( $cl_video ) ); ?>
												</span>
											<?php endif; ?>
											<?php if ( $cl_audio || $cl_mic ) : ?>
												<span class="cl-captured__tag cl-captured__tag--audio" style="--cl-i:3">
													<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"></rect><path d="M5 11a7 7 0 0 0 14 0"></path><path d="M12 18v3"></path></svg>
													<?php echo esc_html( number_format_i18n( max( $cl_audio, $cl_mic ) ) ); ?>
												</span>
											<?php endif; ?>
										</a>
										<span class="cl-captured__n">
											<?php
											$cl_ccount = $cl_vc ? (int) $cl_vc['visits'] : ( $cl_cap ? (int) $cl_cap['sessions'] : 0 );
											if ( $cl_ccount ) {
												printf(
													/* translators: %s: number of captures */
													esc_html( _n( '%s capture', '%s captures', $cl_ccount, 'cloaklink' ) ),
													esc_html( number_format_i18n( $cl_ccount ) )
												);
											}
											?>
										</span>
									<?php elseif ( $cl_cap ) : ?>
										<span class="cl-muted"><?php
											printf(
												/* translators: %s: number of conversations */
												esc_html( _n( '%s conversation, no media', '%s conversations, no media', (int) $cl_cap['sessions'], 'cloaklink' ) ),
												esc_html( number_format_i18n( (int) $cl_cap['sessions'] ) )
											);
										?></span>
									<?php else : ?>
										<span class="cl-muted">—</span>
									<?php endif; ?>
								</td>
								<td><?php echo $cl_exp ? esc_html( $admin->fmt_dt( $cl_l['expires_at'], 'short' ) ) : '<span class="cl-muted">' . esc_html__( 'never', 'cloaklink' ) . '</span>'; ?></td>
								<td><?php echo $links->badge( $cl_l ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
								<td class="cl-td-actions">
									<button type="button" class="cl-iconbtn cl-copy" data-clipboard="<?php echo esc_attr( $cl_url ); ?>" title="<?php esc_attr_e( 'Copy link', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'copy', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
									<a class="cl-iconbtn" href="<?php echo esc_url( CloakLink_Admin::url( 'edit', array( 'id' => $cl_l['id'] ) ) ); ?>" title="<?php esc_attr_e( 'Edit', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'edit', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
									<button type="submit" class="cl-iconbtn" name="cl_action" value="<?php echo 'paused' === $cl_l['status'] ? 'resume' : 'pause'; ?>" formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onclick="document.getElementById('cl-single-id').value='<?php echo esc_attr( $cl_l['id'] ); ?>'" title="<?php esc_attr_e( 'Pause or resume', 'cloaklink' ); ?>">
										<?php echo CloakLink_Admin::icon( 'paused' === $cl_l['status'] ? 'play' : 'pause', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
									</button>
									<button type="submit" class="cl-iconbtn cl-iconbtn--bad" name="cl_action" value="delete" onclick="document.getElementById('cl-single-id').value='<?php echo esc_attr( $cl_l['id'] ); ?>'" title="<?php esc_attr_e( 'Delete', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'trash', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<input type="hidden" name="id" id="cl-single-id" value="">
		</form>
	</div>
</section>

<?php if ( count( $cl_rows ) >= 40 ) : ?>
	<div class="cl-pager">
		<?php if ( $cl_paged > 1 ) : ?>
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( add_query_arg( 'paged', $cl_paged - 1 ) ); ?>">← <?php esc_html_e( 'Previous', 'cloaklink' ); ?></a>
		<?php endif; ?>
		<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( add_query_arg( 'paged', $cl_paged + 1 ) ); ?>"><?php esc_html_e( 'Next', 'cloaklink' ); ?> →</a>
	</div>
<?php endif; ?>
