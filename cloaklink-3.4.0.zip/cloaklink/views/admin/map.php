<?php
/**
 * Map of every captured location.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification
$cl_f = array(
	'link_id' => CloakLink_Admin::current_id(),
	'country' => isset( $_GET['country'] ) ? strtoupper( sanitize_key( wp_unslash( $_GET['country'] ) ) ) : '',
	'from'    => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
	'to'      => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
);
// phpcs:enable WordPress.Security.NonceVerification

$cl_rows   = $cl_db->get_geo_visits( array_merge( $cl_f, array( 'per_page' => 500 ) ) );
$cl_trails = $cl_db->location_trails( array( 'link_id' => $cl_f['link_id'], 'from' => $cl_f['from'], 'to' => $cl_f['to'], 'per_page' => 1000 ) );
$cl_links  = $cl_db->link_options();
$cl_latest = $cl_rows ? $cl_rows[0] : null;

// Every fixed point, with what the panel knows about the visitor behind it.
// The map is drawn from this list, so a pin and its card are the same record:
// there is no second query that could disagree with the first.
$cl_fixes    = array();
$cl_allowed  = array();
$cl_refused  = array();
$cl_networks = array();

foreach ( $cl_rows as $cl_r ) {
	$cl_ex = $cl_db->decode( isset( $cl_r['extra'] ) ? $cl_r['extra'] : '' );
	$cl_ex = is_array( $cl_ex ) ? $cl_ex : array();
	$cl_ok = isset( $cl_ex['granted'] ) && is_array( $cl_ex['granted'] ) ? $cl_ex['granted'] : array();
	$cl_no = isset( $cl_ex['refused'] ) && is_array( $cl_ex['refused'] ) ? $cl_ex['refused'] : array();
	foreach ( $cl_ok as $cl_one ) {
		$cl_allowed[ $cl_one ] = isset( $cl_allowed[ $cl_one ] ) ? $cl_allowed[ $cl_one ] + 1 : 1;
	}
	foreach ( $cl_no as $cl_one ) {
		$cl_refused[ $cl_one ] = isset( $cl_refused[ $cl_one ] ) ? $cl_refused[ $cl_one ] + 1 : 1;
	}
	if ( '' !== (string) $cl_r['isp'] ) {
		$cl_networks[ $cl_r['isp'] ] = isset( $cl_networks[ $cl_r['isp'] ] ) ? $cl_networks[ $cl_r['isp'] ] + 1 : 1;
	}

	$cl_place_bits = array_filter( array( (string) $cl_r['city'], (string) $cl_r['region'], (string) $cl_r['country_name'] ) );
	$cl_net_bits   = array_filter( array( (string) $cl_r['isp'], (string) $cl_r['asn'] ? 'AS' . $cl_r['asn'] : '' ) );
	$cl_fixes[]    = array(
		'lat'      => (float) $cl_r['lat'],
		'lng'      => (float) $cl_r['lng'],
		'accuracy' => (int) $cl_r['accuracy'],
		'when'     => $admin->fmt_dt( $cl_r['created_at'] ),
		'slug'     => (string) $cl_r['slug'],
		// The panel's mask setting is honoured here as everywhere else, so
		// the map never shows more of an address than the log does.
		'ip'       => $admin->setting( 'mask_ip' ) ? $admin->mask_ip( (string) $cl_r['ip'] ) : (string) $cl_r['ip'],
		'place'    => $cl_place_bits ? implode( ', ', $cl_place_bits ) : '',
		'device'   => trim( CloakLink_UA::icon( $cl_r['device'] ) . ' ' . CloakLink_UA::summary( $cl_r ) ),
		'network'  => $cl_net_bits ? implode( ' · ', $cl_net_bits ) : '',
		'allowed'  => $cl_ok ? implode( ', ', $cl_ok ) : '',
		'refused'  => $cl_no ? implode( ', ', $cl_no ) : '',
	);
}

// Which of these pins belong to the same person, and in what order. The map
// draws a line through them, so a repeat visitor reads as one path instead of
// scattered dots that happen to sit near each other. The pairing is made on
// the exact coordinate, which is what both lists carry.
$cl_trail_of = array();
foreach ( $cl_trails as $cl_ti => $cl_t ) {
	if ( count( $cl_t['points'] ) < 2 ) {
		continue;
	}
	foreach ( $cl_t['points'] as $cl_pi => $cl_pt ) {
		$cl_stamp = number_format( $cl_pt['lat'], 6, '.', '' ) . ',' . number_format( $cl_pt['lng'], 6, '.', '' );
		$cl_trail_of[ $cl_stamp ] = array( (string) $cl_ti, $cl_pi + 1, count( $cl_t['points'] ) );
	}
}
foreach ( $cl_fixes as $cl_i => $cl_one ) {
	$cl_stamp = number_format( $cl_one['lat'], 6, '.', '' ) . ',' . number_format( $cl_one['lng'], 6, '.', '' );
	if ( isset( $cl_trail_of[ $cl_stamp ] ) ) {
		$cl_fixes[ $cl_i ]['trail'] = $cl_trail_of[ $cl_stamp ][0];
		$cl_fixes[ $cl_i ]['step']  = $cl_trail_of[ $cl_stamp ][1];
		$cl_fixes[ $cl_i ]['steps'] = $cl_trail_of[ $cl_stamp ][2];
	}
}
arsort( $cl_networks );
?>

<div class="cl-toolbar cl-toolbar--wrap">
	<form class="cl-filters" method="get" action="<?php echo esc_url( CloakLink_Admin::admin_base() ); ?>">
		<input type="hidden" name="cl_page" value="map">
		<select name="id" class="cl-input cl-input--sm">
			<option value="0"><?php esc_html_e( 'All links', 'cloaklink' ); ?></option>
			<?php foreach ( $cl_links as $cl_o ) : ?>
				<option value="<?php echo esc_attr( $cl_o['id'] ); ?>" <?php selected( $cl_f['link_id'], (int) $cl_o['id'] ); ?>><?php echo esc_html( $cl_o['label'] ? $cl_o['label'] . ' — ' . $cl_o['slug'] : $cl_o['title'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<input class="cl-input cl-input--sm" type="text" name="country" value="<?php echo esc_attr( $cl_f['country'] ); ?>" placeholder="<?php esc_attr_e( 'Country code', 'cloaklink' ); ?>" maxlength="2">
		<input class="cl-input cl-input--sm" type="date" name="from" value="<?php echo esc_attr( $cl_f['from'] ); ?>">
		<input class="cl-input cl-input--sm" type="date" name="to" value="<?php echo esc_attr( $cl_f['to'] ); ?>">
		<button type="submit" class="cl-btn cl-btn--gold"><?php esc_html_e( 'Apply', 'cloaklink' ); ?></button>
		<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'map' ) ); ?>"><?php esc_html_e( 'Reset', 'cloaklink' ); ?></a>
	</form>
	<p class="cl-countline"><?php echo esc_html( sprintf( /* translators: %s: number */ __( '%s located visits', 'cloaklink' ), number_format_i18n( count( $cl_rows ) ) ) ); ?></p>
</div>

<?php
// A trail is one person, not one click. The rows that carry a position are
// already on the map above; what a map cannot say is that the pins belong to
// the same person, in this order, this far apart, this far apart in time.
$cl_moves = array();
foreach ( $cl_trails as $cl_t ) {
	if ( $cl_t['clicks'] > 1 ) {
		$cl_moves[] = $cl_t;
	}
}
$cl_moves = array_slice( $cl_moves, 0, 40 );

/**
 * A distance a person can picture: metres under a kilometre, else km.
 *
 * @param int $m Metres.
 * @return string
 */
$cl_dist = static function ( $m ) {
	$m = (int) $m;
	if ( $m < 1000 ) {
		return $m . ' m';
	}
	return number_format_i18n( round( $m / 1000, $m < 10000 ? 1 : 0 ) ) . ' km';
};

/**
 * A gap a person can picture: 45s, 6m, 2h 10m.
 *
 * @param int $secs Seconds.
 * @return string
 */
$cl_gap = static function ( $secs ) {
	$secs = max( 0, (int) $secs );
	if ( $secs < 60 ) {
		return $secs . 's';
	}
	if ( $secs < 3600 ) {
		return (int) floor( $secs / 60 ) . 'm ' . ( $secs % 60 ) . 's';
	}
	$h = (int) floor( $secs / 3600 );
	$m = (int) floor( ( $secs % 3600 ) / 60 );
	return $h . 'h ' . $m . 'm';
};
?>

<?php
// The live board.
//
// The tower above the desk answers "where is the traffic". This answers the
// other half of the same question and answers it only for now: who is on a
// line at this moment, with their address, their handset and their place,
// whether or not they allowed anything; and which agents are actually at a
// desk. Nothing backdated is in it — an entry leaves on its own when its
// activity stops — so a quiet board is empty rather than full of yesterday.
$cl_netlive = $admin->network_live_html();
?>
<section class="cl-panel cl-netwrap" id="cl-netlive-wrap">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title">
			<span class="cl-caps__dot" aria-hidden="true"></span>
			<?php esc_html_e( 'On the network now', 'cloaklink' ); ?>
		</h2>
		<span class="cl-panel__hint"><?php esc_html_e( 'live — entries leave on their own when activity stops', 'cloaklink' ); ?></span>
		<span class="cl-netlive__stamp" id="cl-netlive-stamp"></span>
	</header>
	<div class="cl-panel__body cl-panel__body--flush" id="cl-netlive-body">
		<?php echo $cl_netlive; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in network_live_markup(). ?>
	</div>
</section>

<section class="cl-panel cl-trails">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Repeat visitors — where each one went', 'cloaklink' ); ?></h2>
		<span class="cl-panel__hint"><?php esc_html_e( 'one line per person, one hop per click', 'cloaklink' ); ?></span>
	</header>
	<div class="cl-panel__body cl-panel__body--flush">
		<?php if ( $cl_moves ) : ?>
			<ul class="cl-trail-list">
				<?php foreach ( $cl_moves as $cl_i => $cl_t ) : ?>
					<?php
					// The gaps between clicks that carry no fix are still gaps
					// between clicks: they are counted, never shown as travel.
					$cl_placed = count( $cl_t['points'] );
					?>
					<li class="cl-trail-row" style="--cl-i:<?php echo esc_attr( min( 12, $cl_i ) ); ?>">
						<div class="cl-trail-row__head">
							<span class="cl-trail-row__who">
								<span class="cl-trail-row__ping" aria-hidden="true"></span>
								<?php
								// Where the line starts, and where it ends when
								// that is somewhere else. One name alone said
								// only the last place the person was seen, which
								// read as the start of a journey it was not.
								$cl_from = '' !== (string) $cl_t['from'] ? (string) $cl_t['from'] : (string) $cl_t['place'];
								$cl_to   = (string) $cl_t['to'];
								if ( '' !== $cl_to && $cl_to !== $cl_from ) {
									echo esc_html( $cl_from . ' → ' . $cl_to );
								} else {
									echo esc_html( '' !== $cl_from ? $cl_from : __( 'No place name', 'cloaklink' ) );
								}
								?>
							</span>
							<span class="cl-trail-row__slug cl-mono"><?php echo esc_html( $cl_t['slug'] ); ?></span>
							<span class="cl-trail-row__nums">
								<b><?php echo esc_html( number_format_i18n( $cl_t['clicks'] ) ); ?></b> <?php esc_html_e( 'clicks', 'cloaklink' ); ?>
								<span class="cl-trail-row__sep">·</span>
								<b><?php echo esc_html( number_format_i18n( $cl_placed ) ); ?></b> <?php esc_html_e( 'placed', 'cloaklink' ); ?>
								<?php if ( $cl_t['total_m'] > 0 ) : ?>
									<span class="cl-trail-row__sep">·</span>
									<b><?php echo esc_html( $cl_dist( $cl_t['total_m'] ) ); ?></b> <?php esc_html_e( 'apart', 'cloaklink' ); ?>
								<?php endif; ?>
							</span>
							<?php if ( $cl_t['points'] ) : ?>
								<?php $cl_first = $cl_t['points'][0]; ?>
								<a class="cl-trail-row__map" href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $cl_first['lat'] . ',' . $cl_first['lng'] ) ); ?>" target="_blank" rel="noopener noreferrer" title="<?php esc_attr_e( 'Open the first stop in Google Maps', 'cloaklink' ); ?>">
									<span aria-hidden="true"><?php echo CloakLink_Admin::icon( 'map', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Map', 'cloaklink' ); ?>
								</a>
							<?php endif; ?>
						</div>
						<?php if ( $cl_t['hops'] ) : ?>
							<ol class="cl-trail-hops">
								<?php foreach ( $cl_t['hops'] as $cl_h ) : ?>
									<li>
										<span class="cl-trail-hops__arrow" aria-hidden="true">↳</span>
										<span class="cl-trail-hops__dist"><?php echo esc_html( $cl_dist( $cl_h['metres'] ) ); ?></span>
										<span class="cl-trail-hops__in"><?php esc_html_e( 'after', 'cloaklink' ); ?></span>
										<span class="cl-trail-hops__time"><?php echo esc_html( $cl_gap( $cl_h['secs'] ) ); ?></span>
										<?php if ( '' !== (string) $cl_h['place'] ) : ?>
											<span class="cl-trail-hops__area"><?php echo esc_html( $cl_h['place'] ); ?></span>
										<?php endif; ?>
										<a class="cl-trail-hops__pin" href="<?php echo esc_url( $cl_h['maps'] ); ?>" target="_blank" rel="noopener noreferrer" title="<?php esc_attr_e( 'Open this stop in Google Maps', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Open this stop in Google Maps', 'cloaklink' ); ?>">
											<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z"></path><circle cx="12" cy="10" r="2.4"></circle></svg>
										</a>
									</li>
								<?php endforeach; ?>
							</ol>
						<?php elseif ( 1 === count( $cl_t['points'] ) ) : ?>
							<?php
							// One fix and no second one: there is no hop to draw,
							// but saying "no position was shared" over a row that
							// says "1 placed" contradicts the row itself.
							$cl_only = $cl_t['points'][0];
							?>
							<p class="cl-trail-row__note cl-trail-row__note--one">
								<?php esc_html_e( 'One position shared, so there is no line to draw yet.', 'cloaklink' ); ?>
								<a class="cl-trail-hops__pin" href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $cl_only['lat'] . ',' . $cl_only['lng'] ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Open this stop in Google Maps', 'cloaklink' ); ?>">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s7-6.1 7-11a7 7 0 1 0-14 0c0 4.9 7 11 7 11Z"></path><circle cx="12" cy="10" r="2.4"></circle></svg>
								</a>
							</p>
						<?php else : ?>
							<p class="cl-trail-row__note"><?php esc_html_e( 'Opened more than once, but no position was shared on any of them.', 'cloaklink' ); ?></p>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p class="cl-empty"><?php esc_html_e( 'No visitor has opened a link more than once yet. Trails appear here when someone comes back.', 'cloaklink' ); ?></p>
		<?php endif; ?>
	</div>
</section>

<div class="cl-grid cl-grid--map">

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Captured locations', 'cloaklink' ); ?></h2>
			<span class="cl-panel__hint"><?php esc_html_e( 'click any pin to open Google Maps', 'cloaklink' ); ?></span>
		</header>
		<div class="cl-panel__body cl-panel__body--flush">
			<?php if ( $cl_fixes ) : ?>
				<div id="cl-map" class="cl-mapview"
					data-fixes="<?php echo esc_attr( wp_json_encode( $cl_fixes ) ); ?>"
					role="application"
					aria-label="<?php esc_attr_e( 'Map of captured visitor locations', 'cloaklink' ); ?>"></div>
				<div class="cl-mapview__legend">
					<span><i class="cl-mapview__dot"></i> <?php esc_html_e( 'A fix where the visitor allowed location', 'cloaklink' ); ?></span>
					<span><i class="cl-mapview__dot cl-mapview__dot--plain"></i> <?php esc_html_e( 'A fix with no permission answer', 'cloaklink' ); ?></span>
					<span class="cl-mapview__hint"><?php esc_html_e( 'Drag to move, scroll to zoom, click a pin for the full record.', 'cloaklink' ); ?></span>
				</div>
				<p class="cl-mapview__credit"><?php esc_html_e( 'Map data © Google', 'cloaklink' ); ?></p>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'No coordinates captured yet. Locations appear here as soon as a visitor allows location access.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Latest fixes', 'cloaklink' ); ?></h2>
			<?php if ( $cl_latest ) : ?>
				<a class="cl-panel__link" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $admin->map_url( $cl_latest['lat'], $cl_latest['lng'], true ) ); ?>"><?php esc_html_e( 'Directions', 'cloaklink' ); ?> ↗</a>
			<?php endif; ?>
		</header>
		<div class="cl-panel__body cl-panel__body--flush">
			<?php if ( $cl_rows ) : ?>
				<ul class="cl-geolist">
					<?php foreach ( array_slice( $cl_rows, 0, 100 ) as $cl_r ) : ?>
						<?php $cl_place = array_filter( array( $cl_r['city'], $cl_r['region'], $cl_r['country_name'] ) ); ?>
						<li>
							<a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url( $admin->map_url( $cl_r['lat'], $cl_r['lng'] ) ); ?>">
								<span class="cl-maplist__pin" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'position', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
								<span class="cl-geolist__body">
									<span class="cl-geolist__place"><?php echo esc_html( $cl_place ? implode( ', ', $cl_place ) : __( 'Coordinates only (no city name)', 'cloaklink' ) ); ?></span>
									<span class="cl-geolist__meta">
										<?php echo esc_html( $admin->fmt_dt( $cl_r['created_at'], 'short' ) ); ?>
										· <?php echo esc_html( CloakLink_UA::icon( $cl_r['device'] ) . ' ' . $cl_r['device'] ); ?>
										· <?php echo esc_html( $cl_r['slug'] ); ?>
									</span>
									<span class="cl-geolist__meta cl-geolist__meta--net">
										<?php /* translators: %s: the address the request came from */ ?>
										<span><b><?php esc_html_e( 'IP', 'cloaklink' ); ?></b> <span class="cl-mono"><?php echo esc_html( $admin->setting( 'mask_ip' ) ? $admin->mask_ip( (string) $cl_r['ip'] ) : (string) $cl_r['ip'] ); ?></span></span>
										<?php if ( '' !== (string) $cl_r['isp'] ) : ?>
											<span><b><?php esc_html_e( 'Network', 'cloaklink' ); ?></b> <?php echo esc_html( $cl_r['isp'] ); ?></span>
										<?php endif; ?>
										<?php echo $admin->permission_marks( $cl_r ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside ?>
									</span>
								</span>
								<span class="cl-geolist__coords">
									<?php echo esc_html( $cl_r['lat'] . ', ' . $cl_r['lng'] ); ?>
									<?php if ( $cl_r['accuracy'] ) : ?>
										<em>±<?php echo esc_html( $cl_r['accuracy'] ); ?>m</em>
									<?php endif; ?>
								</span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'Nothing to show yet.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</div>
	</section>
</div>

<?php
// What the map cannot draw: how many of these people answered a permission
// question, and which networks they came over. A pin says where; these two
// strips say whether the position was handed over and who carried it.
$cl_perm_names = array(
	'position'   => __( 'Location', 'cloaklink' ),
	'camera'     => __( 'Camera', 'cloaklink' ),
	'microphone' => __( 'Microphone', 'cloaklink' ),
);
?>
<div class="cl-mapview__stats">
	<div class="cl-mapview__stat">
		<p class="cl-mapview__stat-title"><?php esc_html_e( 'What they allowed', 'cloaklink' ); ?></p>
		<ul class="cl-mapview__stat-list">
			<?php foreach ( $cl_perm_names as $cl_pk => $cl_pn ) : ?>
				<?php
				$cl_yes = isset( $cl_allowed[ $cl_pk ] ) ? (int) $cl_allowed[ $cl_pk ] : 0;
				$cl_not = isset( $cl_refused[ $cl_pk ] ) ? (int) $cl_refused[ $cl_pk ] : 0;
				?>
				<li>
					<span><?php echo esc_html( $cl_pn ); ?></span>
					<span class="cl-mapview__stat-yes"><?php echo esc_html( sprintf( /* translators: %d: count */ __( '%d allowed', 'cloaklink' ), $cl_yes ) ); ?></span>
					<span class="cl-mapview__stat-no"><?php echo esc_html( sprintf( /* translators: %d: count */ __( '%d refused', 'cloaklink' ), $cl_not ) ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
		<p class="cl-help"><?php esc_html_e( 'Each answer is counted once per visit. A link that never asked for the camera shows nothing here for it.', 'cloaklink' ); ?></p>
	</div>
	<div class="cl-mapview__stat">
		<p class="cl-mapview__stat-title"><?php esc_html_e( 'Networks carrying them', 'cloaklink' ); ?></p>
		<?php if ( $cl_networks ) : ?>
			<ul class="cl-mapview__stat-list cl-mapview__stat-list--net">
				<?php foreach ( array_slice( $cl_networks, 0, 6, true ) as $cl_isp => $cl_n ) : ?>
					<li>
						<span><?php echo esc_html( $cl_isp ); ?></span>
						<span class="cl-mapview__stat-yes"><?php echo esc_html( number_format_i18n( $cl_n ) ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p class="cl-help"><?php esc_html_e( 'No network name was returned for these addresses.', 'cloaklink' ); ?></p>
		<?php endif; ?>
	</div>
</div>
