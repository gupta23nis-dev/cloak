<?php
/**
 * Overview dashboard.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_db      = $admin->_db();
$cl_stats   = $cl_db->global_stats();
$cl_series  = $cl_db->daily_series( 14 );
$cl_latest  = $cl_db->get_visits( array( 'per_page' => 14 ) );
$cl_blocks  = $cl_db->top_countries( 6 );
$cl_places  = $cl_blocks ? array() : $cl_db->top_places( 6 );
$cl_devices = $cl_db->device_split();
$cl_refs    = $cl_db->top_referrers( 5 );
$cl_links   = $cl_db->get_links( array( 'per_page' => 6, 'orderby' => 'click_count' ) );
$cl_hours   = $cl_db->hourly_today();
$cl_total_dev = 0;
foreach ( $cl_devices as $cl_d ) {
	$cl_total_dev += (int) $cl_d['c'];
}

/*
 * The band above everything.
 *
 * Its numbers are read from the same rows the panels below read, so the two
 * can never disagree — a band that said "3 captured" over a wall that showed
 * four would be worse than no band at all. What the band adds is order: the
 * live question first, the historical one after.
 */
// The queue an operator is actually holding: tickets that have been raised
// and not yet decided. Read from the agents table rather than the ledger,
// because the ledger is history and the queue is work.
$cl_tickets_open = 0;
if ( cloaklink()->agents ) {
	$cl_tc = cloaklink()->agents->ticket_counts();
	$cl_tickets_open = isset( $cl_tc['pending'] ) ? (int) $cl_tc['pending'] : 0;
}

// Captures in the monitoring table, and how many of those are still open —
// a visitor who was asked for a camera and has not answered is the one that
// wants looking at, and it is the only number here that is a request.
$cl_cap_stats = cloaklink()->support ? cloaklink()->support->stats() : array( 'open' => 0, 'media' => 0, 'total' => 0 );
$cl_open_caps = isset( $cl_cap_stats['open'] ) ? (int) $cl_cap_stats['open'] : 0;

// Today's openings, from the same figure the KPI row shows, so the band and
// the row beneath it cannot say two different things about one day.
$cl_last_hour = (int) $cl_stats['visits_today'];

// "Watching" means something arrived recently enough that the desk is
// still the place to be. Five minutes is the same window the live feed
// uses for its own dot, so the two never contradict each other.
$cl_last_stamp = isset( $cl_stats['last_visit'] ) ? strtotime( (string) $cl_stats['last_visit'] . ' UTC' ) : 0;
$cl_band_pulse = $cl_last_stamp && ( time() - $cl_last_stamp ) < 300;

$cl_band_reading = '';
if ( $cl_last_hour > 0 ) {
	$cl_band_reading = sprintf(
		/* translators: %s: number of openings today */
		_n( '%s opening today.', '%s openings today.', $cl_last_hour, 'cloaklink' ),
		number_format_i18n( $cl_last_hour )
	);
	if ( (int) $cl_stats['high_risk'] > 0 ) {
		$cl_band_reading .= ' ' . sprintf(
			/* translators: %s: number of high risk visits */
			_n( '%s visitor is flagged high risk.', '%s visitors are flagged high risk.', (int) $cl_stats['high_risk'], 'cloaklink' ),
			number_format_i18n( (int) $cl_stats['high_risk'] )
		);
	}
} else {
	$cl_band_reading = __( 'Quiet for now. Nothing has been opened today.', 'cloaklink' );
}

$cl_band = array(
	'pulse'   => $cl_band_pulse,
	'today'   => (int) $cl_stats['visits_today'],
	'ago'     => $cl_last_stamp ? sprintf(
		/* translators: %s: human time difference, e.g. "4 minutes" */
		__( 'last activity %s ago', 'cloaklink' ),
		human_time_diff( $cl_last_stamp, time() )
	) : __( 'nothing yet', 'cloaklink' ),
	'reading' => $cl_band_reading,
	'tiles'   => array(
		array(
			'key'   => 'live',
			'value' => $cl_last_hour,
			'label' => __( 'Last hour', 'cloaklink' ),
			'foot'  => __( 'openings', 'cloaklink' ),
			'tone'  => '',
			'href'  => CloakLink_Admin::url( 'visits' ),
		),
		array(
			'key'   => 'captured',
			'value' => $cl_open_caps,
			'label' => __( 'Captures', 'cloaklink' ),
			'foot'  => __( 'waiting on a visitor', 'cloaklink' ),
			'tone'  => 'gold',
			'href'  => CloakLink_Admin::url( 'support' ),
		),
		array(
			'key'   => 'tickets',
			'value' => $cl_tickets_open,
			'label' => __( 'Waiting', 'cloaklink' ),
			'foot'  => __( 'tickets in the queue', 'cloaklink' ),
			'tone'  => $cl_tickets_open > 0 ? 'warn' : '',
			'href'  => CloakLink_Admin::url( 'agents' ),
		),
		array(
			'key'   => 'risk',
			'value' => (int) $cl_stats['high_risk'],
			'label' => __( 'Flagged', 'cloaklink' ),
			'foot'  => __( 'high risk', 'cloaklink' ),
			'tone'  => (int) $cl_stats['high_risk'] > 0 ? 'risk' : '',
			'href'  => CloakLink_Admin::url( 'visits' ),
		),
	),
	'new_link' => CloakLink_Admin::url( 'new' ),
);
?>
<?php $this->render_view( 'partials/watchband', array( 'cl_band' => $cl_band ) ); ?>

<section class="cl-kpis">
	<article class="cl-kpi cl-kpi--gold">
		<p class="cl-kpi__label"><?php esc_html_e( 'Visits today', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value" id="cl-kpi-today"><?php echo esc_html( number_format_i18n( $cl_stats['visits_today'] ) ); ?></p>
		<p class="cl-kpi__foot"><?php echo esc_html( $admin->ago( $cl_stats['last_visit'] ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Total visits', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value" id="cl-kpi-total"><?php echo esc_html( number_format_i18n( $cl_stats['visits_total'] ) ); ?></p>
		<p class="cl-kpi__foot"><?php echo esc_html( sprintf( /* translators: %s: number */ __( '%s unique networks', 'cloaklink' ), number_format_i18n( $cl_stats['unique_total'] ) ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Active links', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['links_active'] ) ); ?></p>
		<p class="cl-kpi__foot"><?php echo esc_html( sprintf( /* translators: %s: number */ __( '%s total created', 'cloaklink' ), number_format_i18n( $cl_stats['links_total'] ) ) ); ?></p>
	</article>
	<?php // A country code needs a public address to resolve against; a city can
	// arrive from the browser or the network without one, so the count falls
	// back to places rather than reading zero beside a panel that lists them. ?>
	<?php $cl_by_country = $cl_stats['countries'] > 0; ?>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php echo esc_html( $cl_by_country ? __( 'Countries seen', 'cloaklink' ) : __( 'Places seen', 'cloaklink' ) ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_by_country ? $cl_stats['countries'] : $cl_stats['places'] ) ); ?></p>
		<p class="cl-kpi__foot"><?php echo esc_html( $cl_by_country ? __( 'from network lookup', 'cloaklink' ) : __( 'from visitor and network data', 'cloaklink' ) ); ?></p>
	</article>
	<article class="cl-kpi cl-kpi--alert">
		<p class="cl-kpi__label"><?php esc_html_e( 'High risk', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['high_risk'] ) ); ?></p>
		<p class="cl-kpi__foot"><?php echo esc_html( sprintf( /* translators: %s: number */ __( '%s blocked attempts', 'cloaklink' ), number_format_i18n( $cl_stats['blocked_total'] ) ) ); ?></p>
	</article>
</section>

<div class="cl-grid cl-grid--2">

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Visits — last 14 days', 'cloaklink' ); ?></h2>
			<span class="cl-panel__hint"><?php esc_html_e( 'green bar = one day’s openings', 'cloaklink' ); ?></span>
		</header>
		<div class="cl-panel__body">
			<?php echo $admin->sparkline( $cl_series ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<div class="cl-hourblock">
				<p class="cl-hourblock__label"><?php esc_html_e( 'Today by hour', 'cloaklink' ); ?></p>
				<?php echo $admin->hour_strip( $cl_hours ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Where visitors are', 'cloaklink' ); ?></h2>
			<a class="cl-panel__link" href="<?php echo esc_url( CloakLink_Admin::url( 'visits' ) ); ?>"><?php esc_html_e( 'Visitor log', 'cloaklink' ); ?> →</a>
		</header>
		<div class="cl-panel__body">
			<?php if ( $cl_blocks || $cl_places ) : ?>
				<ul class="cl-bars">
					<?php
					// A country row when the address carries one; otherwise the
					// city the visitor's browser or network supplied. Either way
					// the bar answers "where are these people".
					$cl_rows = array();
					foreach ( $cl_blocks as $cl_b ) {
						$cl_rows[] = array( $cl_b['country_name'] ? $cl_b['country_name'] : $cl_b['country_code'], (int) $cl_b['c'] );
					}
					foreach ( $cl_places as $cl_p ) {
						$cl_rows[] = array( $cl_p['city'], (int) $cl_p['c'] );
					}
					$cl_max = 1;
					foreach ( $cl_rows as $cl_one ) {
						$cl_max = max( $cl_max, $cl_one[1] );
					}
					foreach ( $cl_rows as $cl_one ) :
						$cl_pct = round( ( $cl_one[1] / $cl_max ) * 100 );
						?>
						<li class="cl-bars__row">
							<span class="cl-bars__name"><?php echo esc_html( $cl_one[0] ); ?></span>
							<span class="cl-bars__track"><span class="cl-bars__fill" style="width:<?php echo esc_attr( $cl_pct ); ?>%"></span></span>
							<span class="cl-bars__val"><?php echo esc_html( number_format_i18n( $cl_one[1] ) ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'No visits recorded yet. Share a link to start collecting data.', 'cloaklink' ); ?></p>
			<?php endif; ?>

			<?php if ( $cl_devices ) : ?>
				<div class="cl-devices">
					<?php foreach ( $cl_devices as $cl_dev ) : ?>
						<?php $cl_pct = $cl_total_dev ? round( ( (int) $cl_dev['c'] / $cl_total_dev ) * 100 ) : 0; ?>
						<span class="cl-devices__item">
							<?php echo esc_html( CloakLink_UA::icon( $cl_dev['device'] ) ); ?>
							<?php echo esc_html( ucfirst( $cl_dev['device'] ) ); ?>
							<strong><?php echo esc_html( $cl_pct . '%' ); ?></strong>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>

</div>

<section class="cl-panel">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Live activity', 'cloaklink' ); ?></h2>
		<span class="cl-panel__hint" id="cl-live-stamp">
			<?php
			printf(
				/* translators: %s: time */
				esc_html__( 'live · updated %s', 'cloaklink' ),
				esc_html( wp_date( 'g:i:s A', time(), $admin->tz() ) )
			);
			?>
		</span>
	</header>
	<div class="cl-panel__body cl-panel__body--flush">
		<div class="cl-table-wrap">
			<table class="cl-table cl-table--live">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Time', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Event / link', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Device', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Location', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'GPS', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Network', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Risk', 'cloaklink' ); ?></th>
					</tr>
				</thead>
				<tbody id="cl-live-body">
					<?php
					if ( $cl_latest ) {
						foreach ( $cl_latest as $cl_row ) {
							echo $admin->visit_row_html( $cl_row, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
					} else {
						echo '<tr><td colspan="7" class="cl-empty">' . esc_html__( 'Waiting for the first visit.', 'cloaklink' ) . '</td></tr>';
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</section>

<div class="cl-grid cl-grid--2">

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Most opened links', 'cloaklink' ); ?></h2>
			<a class="cl-panel__link" href="<?php echo esc_url( CloakLink_Admin::url( 'links' ) ); ?>"><?php esc_html_e( 'All links', 'cloaklink' ); ?> →</a>
		</header>
		<div class="cl-panel__body cl-panel__body--flush">
			<?php if ( $cl_links ) : ?>
				<ul class="cl-list">
					<?php foreach ( $cl_links as $cl_l ) : ?>
						<li class="cl-list__row">
							<a class="cl-list__main" href="<?php echo esc_url( CloakLink_Admin::url( 'link', array( 'id' => $cl_l['id'] ) ) ); ?>">
								<span class="cl-list__title"><?php echo esc_html( $cl_l['title'] ); ?></span>
								<span class="cl-list__sub">/<?php echo esc_html( $cl_l['slug'] ); ?> · <?php echo esc_html( $cl_l['destination_host'] ? $cl_l['destination_host'] : __( 'in-page', 'cloaklink' ) ); ?></span>
							</a>
							<span class="cl-list__right">
								<?php echo $links->badge( $cl_l ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<strong><?php echo esc_html( number_format_i18n( (int) $cl_l['click_count'] ) ); ?></strong>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'No links yet.', 'cloaklink' ); ?> <a href="<?php echo esc_url( CloakLink_Admin::url( 'new' ) ); ?>"><?php esc_html_e( 'Create the first one', 'cloaklink' ); ?></a>.</p>
			<?php endif; ?>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Traffic sources', 'cloaklink' ); ?></h2>
		</header>
		<div class="cl-panel__body">
			<?php if ( $cl_refs ) : ?>
				<ul class="cl-refs">
					<?php foreach ( $cl_refs as $cl_r ) : ?>
						<li><span class="cl-refs__host"><?php echo esc_html( (string) wp_parse_url( $cl_r['referrer'], PHP_URL_HOST ) ); ?></span><span><?php echo esc_html( number_format_i18n( (int) $cl_r['c'] ) ); ?></span></li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'Direct or messaging-app traffic only so far.', 'cloaklink' ); ?></p>
			<?php endif; ?>

			<div class="cl-quick">
				<a class="cl-quick__item" href="<?php echo esc_url( CloakLink_Admin::url( 'new' ) ); ?>">
					<span aria-hidden="true"><?php echo CloakLink_Admin::icon( 'plus', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Create link', 'cloaklink' ); ?>
				</a>
				<a class="cl-quick__item" href="<?php echo esc_url( CloakLink_Admin::url( 'visits' ) ); ?>">
					<span aria-hidden="true"><?php echo CloakLink_Admin::icon( 'visits', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Visitor log', 'cloaklink' ); ?>
				</a>
				<a class="cl-quick__item" href="<?php echo esc_url( CloakLink_Admin::url( 'map' ) ); ?>">
					<span aria-hidden="true"><?php echo CloakLink_Admin::icon( 'map', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Location map', 'cloaklink' ); ?>
				</a>
				<a class="cl-quick__item" href="<?php echo esc_url( CloakLink_Admin::url( 'settings' ) ); ?>">
					<span aria-hidden="true"><?php echo CloakLink_Admin::icon( 'settings', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Rules', 'cloaklink' ); ?>
				</a>
				<a class="cl-quick__item" href="<?php echo esc_url( CloakLink_Admin::url( 'tools' ) ); ?>">
					<span aria-hidden="true"><?php echo CloakLink_Admin::icon( 'tools', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Export', 'cloaklink' ); ?>
				</a>
			</div>
		</div>
	</section>

</div>
