<?php
/**
 * Panel shell: header, navigation rail, notice bar.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

// Icon names, not characters: every mark in the rail is a drawn 24-grid
// glyph, so the row has one weight and one size instead of nine characters
// borrowed from whatever font the machine happens to have.
$cl_nav = array(
	'overview' => array( __( 'Overview', 'cloaklink' ), 'overview' ),
	'links'    => array( __( 'Links', 'cloaklink' ), 'links' ),
	'new'      => array( __( 'New link', 'cloaklink' ), 'plus' ),
	'visits'   => array( __( 'Visits', 'cloaklink' ), 'visits' ),
	'map'      => array( __( 'Map', 'cloaklink' ), 'map' ),
	// The same words as the sidebar entry, so the two never look like
	// two different screens.
	'support'  => array( __( 'Smart monitoring', 'cloaklink' ), 'monitoring' ),
	// Everything that was ever handed over, without the monitoring screen's
	// live framing. The desk asked for one place to look something up in
	// after the fact, and this is it.
	'records'  => array( __( 'All records', 'cloaklink' ), 'visits' ),
	'agents'   => array( __( 'Case agents', 'cloaklink' ), 'monitoring' ),
	'activity' => array( __( 'Desk activity', 'cloaklink' ), 'activity' ),
	'blocks'   => array( __( 'Blocklist', 'cloaklink' ), 'block' ),
	'settings' => array( __( 'Settings', 'cloaklink' ), 'settings' ),
	// Its own section rather than a field buried in Settings: which machines
	// may reach the second panel is the one setting an operator needs to find
	// in a hurry, usually while standing at a different desk.
	'access'   => array( __( 'Network access', 'cloaklink' ), 'access' ),
	'tools'    => array( __( 'Tools', 'cloaklink' ), 'tools' ),
	// Last, and it is the only entry about the person rather than the desk.
	'account'  => array( __( 'Your account', 'cloaklink' ), 'who' ),
);

$cl_active = $page;
if ( in_array( $page, array( 'new', 'edit' ), true ) ) {
	$cl_active = 'links';
}
if ( 'link' === $page ) {
	$cl_active = 'links';
}

$cl_stats = $admin->stats();
?>
<div class="wrap cl-wrap <?php echo esc_attr( cloaklink()->adv->body_class() ); ?>">

	<div class="cl-topbar">
		<div class="cl-topbar__brand">
			<span class="cl-logo"><?php echo CloakLink_Admin::logo( '', 42 ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in logo(). ?></span>
			<div>
				<h1 class="cl-title">Credit Control</h1>
				<p class="cl-subtitle"><?php echo esc_html( $route[1] ); ?></p>
			</div>
		</div>
		<div class="cl-topbar__meta">
			<?php if ( cloaklink()->adv->yes( 'live_dot' ) ) : ?>
				<span class="cl-live-dot" id="cl-live-dot" title="<?php esc_attr_e( 'Live monitoring', 'cloaklink' ); ?>"></span>
			<?php endif; ?>
			<span class="cl-topbar__stat"><strong id="cl-stat-today"><?php echo esc_html( number_format_i18n( $cl_stats['visits_today'] ) ); ?></strong> <?php esc_html_e( 'historical visits today', 'cloaklink' ); ?></span>
			<span class="cl-topbar__stat"><strong><?php echo esc_html( number_format_i18n( $cl_stats['links_active'] ) ); ?></strong> <?php esc_html_e( 'active links', 'cloaklink' ); ?></span>
			<a class="cl-topbar__btn" href="<?php echo esc_url( CloakLink_Admin::url( 'new' ) ); ?>"><?php esc_html_e( 'Create link', 'cloaklink' ); ?></a>

			<?php
			// Who is signed in, and the way out.
			//
			// The panel had no sign-out at all outside the lock screen: an
			// operator on a shared machine could close the tab and leave a
			// WordPress session behind it. The exit is WordPress's own, so it
			// ends the session properly rather than only covering the screen —
			// and it goes back to the door, not to the site's front page.
			$cl_me     = wp_get_current_user();
			$cl_ini    = mb_strtoupper( mb_substr( (string) $cl_me->display_name, 0, 1 ) );
			$cl_out_to = home_url( '/' . cloaklink()->login->path() );
			?>
			<div class="cl-who">
				<span class="cl-who__av" aria-hidden="true"><?php echo esc_html( '' !== $cl_ini ? $cl_ini : '·' ); ?></span>
				<span class="cl-who__n">
					<a class="cl-who__link" href="<?php echo esc_url( CloakLink_Admin::url( 'account' ) ); ?>" title="<?php esc_attr_e( 'Your password and access code', 'cloaklink' ); ?>">
						<b><?php echo esc_html( $cl_me->display_name ); ?></b>
						<i><?php echo esc_html( __( 'Operator', 'cloaklink' ) ); ?></i>
					</a>
				</span>
				<a class="cl-who__out" href="<?php echo esc_url( wp_logout_url( $cl_out_to ) ); ?>" title="<?php esc_attr_e( 'Sign out of the panel', 'cloaklink' ); ?>">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><path d="M14 4h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-5"/><path d="M10 16l-4-4 4-4"/><path d="M6 12h10"/></svg>
					<span><?php esc_html_e( 'Sign out', 'cloaklink' ); ?></span>
				</a>
			</div>
		</div>
	</div>

	<nav class="cl-nav" aria-label="<?php esc_attr_e( 'Credit Control sections', 'cloaklink' ); ?>">
		<?php
		// Inside the restricted console every link stays on the restricted
		// address: dropping to the open one for a section that holds visitor
		// data would make the gate a suggestion.
		$cl_vault_base = isset( $vault_url ) && '' !== $vault_url ? $vault_url : '';
		?>
		<?php foreach ( $cl_nav as $cl_key => $cl_item ) : ?>
			<?php
			$cl_vault_section = in_array( $cl_key, array( 'support', 'visits', 'map', 'overview' ), true );
			// The vault takes the same readable shape as the main panel, so a
			// page reached there has an address worth bookmarking rather than
			// a query string hanging off the door.
			$cl_href          = '' !== $cl_vault_base
				? trailingslashit( $cl_vault_base ) . rawurlencode( $cl_key )
				: CloakLink_Admin::url( $cl_key );
			// A section that is not part of the restricted console is left out
			// entirely rather than linking back to the open door.
			if ( '' !== $cl_vault_base && ! $cl_vault_section ) {
				continue;
			}
			?>
			<a class="cl-nav__item<?php echo $cl_active === $cl_key ? ' is-active' : ''; ?>" href="<?php echo esc_url( $cl_href ); ?>">
				<span class="cl-nav__icon" aria-hidden="true"><?php echo CloakLink_Admin::icon( $cl_item[1], 15 ); // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG. ?></span>
				<span><?php echo esc_html( $cl_item[0] ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>

	<?php
	// The shipped code, on every screen until it is gone.
	//
	// 585303 is written into the plugin, so it is published the moment the
	// plugin is. It has to stay valid on a fresh install or a new operator is
	// locked out of their own console before they can set anything — but it
	// must not go unnoticed either, because an operator who never opens the
	// Access panel never learns their door opens to a number on the internet.
	//
	// The notice that was here before lived on the Settings screen alone: the
	// one place a person who already knows about it would look. It is drawn
	// from this partial now, which every console screen includes, so the
	// warning is genuinely everywhere rather than on the page that needed it
	// least. It is not dismissable — a banner you can close is a banner that
	// was read once and will not be seen again on the day it matters.
	if ( function_exists( 'cloaklink' ) && cloaklink()->login && ! CloakLink_Login::user_has_code( get_current_user_id() ) ) :
		$cl_codepage = CloakLink_Admin::url( 'settings' ) . '#cl-security';
		?>
		<div class="cl-flash cl-flash--bad cl-flash--stock" role="status">
			<strong><?php esc_html_e( 'This account still uses the shipped access code 585303.', 'cloaklink' ); ?></strong>
			<?php esc_html_e( 'It is printed in the plugin, so anyone who has read the source knows it. Set your own six digits and this notice will stop.', 'cloaklink' ); ?>
			<a class="cl-flash__go" href="<?php echo esc_url( $cl_codepage ); ?>"><?php esc_html_e( 'Change it now', 'cloaklink' ); ?></a>
		</div>
	<?php endif; ?>

	<?php if ( 'saved' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Changes saved.', 'cloaklink' ); ?></div>
	<?php elseif ( 'deleted' === $notce || 'nothing_gone' === $notce ) : ?>
		<?php
		// How many, said in the number that actually went.
		//
		// "The link and its visit history were deleted" was true for one row
		// and true for forty, which is exactly the kind of message that stops
		// being read. The count comes from the DELETE's own rowcount, and
		// cl_asked says how many were ticked — so the sentence can admit it
		// when some of them were already gone.
		$cl_n     = isset( $_GET['cl_count'] ) ? max( 0, (int) $_GET['cl_count'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$cl_asked = isset( $_GET['cl_asked'] ) ? max( 0, (int) $_GET['cl_asked'] ) : $cl_n; // phpcs:ignore WordPress.Security.NonceVerification
		$cl_lost  = max( 0, $cl_asked - $cl_n );
		?>
		<?php if ( $cl_n ) : ?>
			<div class="cl-flash cl-flash--ok">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of links deleted */
						_n(
							'%d link and its visit history were deleted.',
							'%d links and their visit history were deleted.',
							$cl_n,
							'cloaklink'
						),
						$cl_n
					)
				);
				?>
				<?php if ( $cl_lost ) : ?>
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: number already gone, 2: number selected */
							_n(
								'%1$d of the %2$d selected had already gone, so nothing changed for it.',
								'%1$d of the %2$d selected had already gone, so nothing changed for them.',
								$cl_lost,
								'cloaklink'
							),
							$cl_lost,
							$cl_asked
						)
					);
					?>
				<?php endif; ?>
			</div>
		<?php else : ?>
			<div class="cl-flash cl-flash--bad">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number selected */
						_n(
							'Nothing was deleted: the %d selected link is no longer there. It may have been removed in another tab. The list below is the current one.',
							'Nothing was deleted: none of the %d selected links are there any more. They may have been removed in another tab. The list below is the current one.',
							$cl_asked,
							'cloaklink'
						),
						$cl_asked
					)
				);
				?>
			</div>
		<?php endif; ?>
	<?php elseif ( 'duplicated' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'The copy is open below, unsaved till you press Save. It starts unpaused and without a click limit, so check those before you send it.', 'cloaklink' ); ?></div>
	<?php elseif ( 'done' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Done.', 'cloaklink' ); ?></div>
	<?php elseif ( 'error' === $notce ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'That action could not be completed.', 'cloaklink' ); ?></div>
	<?php elseif ( 'upload_error' === $notce ) : ?>
		<div class="cl-flash cl-flash--bad"><?php echo esc_html( isset( $_GET['cl_msg'] ) ? rawurldecode( (string) wp_unslash( $_GET['cl_msg'] ) ) : __( 'The document could not be stored.', 'cloaklink' ) ); // phpcs:ignore WordPress.Security.NonceVerification ?></div>
	<?php elseif ( 'mail_ok' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'The mail transport accepted the test message. If it does not arrive in a few minutes, the recipient server or its spam filter is holding it — check that first, then the sending domain.', 'cloaklink' ); ?></div>
	<?php elseif ( 'mail_fail' === $notce ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'The mail transport refused the test message. Fill in your mailbox details under “Send mail through your own mailbox” above, save, and run the test again.', 'cloaklink' ); ?></div>
	<?php elseif ( 'media_repaired' === $notce ) : ?>
		<?php
		// Reported in the two numbers that actually happened: how many files
		// got their reference back, and how many could not be placed. A run
		// that fixed nothing because there was nothing to fix is a success,
		// not a silence.
		$cl_fixed    = isset( $_GET['cl_fixed'] ) ? absint( $_GET['cl_fixed'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$cl_skipped  = isset( $_GET['cl_skipped'] ) ? absint( $_GET['cl_skipped'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$cl_orphaned = isset( $_GET['cl_orphaned'] ) ? absint( $_GET['cl_orphaned'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		?>
		<div class="cl-flash cl-flash--ok">
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: number re-attached, 2: number left alone */
					_n(
						'%1$d file re-attached to its session. %2$d left alone.',
						'%1$d files re-attached to their sessions. %2$d left alone.',
						$cl_fixed,
						'cloaklink'
					),
					$cl_fixed,
					$cl_skipped
				)
			);
			?>
			<?php if ( $cl_orphaned ) : ?>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of files */
						_n(
							'%d file names a session that has been deleted. There is no record left to attach it to, so it stays on disk untouched — the file is still evidence even when its record is gone.',
							'%d files name a session that has been deleted. There is no record left to attach them to, so they stay on disk untouched — the files are still evidence even when their record is gone.',
							$cl_orphaned,
							'cloaklink'
						),
						$cl_orphaned
					)
				);
				?>
			<?php endif; ?>
			<?php if ( $cl_skipped ) : ?>
				<?php esc_html_e( 'A file left alone has a name that does not identify a session, so nothing can be said about which record it belongs to. It has not been touched.', 'cloaklink' ); ?>
			<?php endif; ?>
		</div>
	<?php elseif ( 'sound_library' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'The sound library is saved. Each event now plays what its row says — a file you chose, or the built-in figure if the row has none.', 'cloaklink' ); ?></div>
	<?php elseif ( 'sound_saved' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Your alert sound is saved. The next permission a visitor grants will play it.', 'cloaklink' ); ?></div>
	<?php elseif ( 'sound_cleared' === $notce ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'The alert sound was cleared. The panel is back to its built-in beep.', 'cloaklink' ); ?></div>
	<?php elseif ( 'sound_none' === $notce ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'No file was chosen. Pick an MP3, WAV, OGG or M4A file and try again.', 'cloaklink' ); ?></div>
	<?php elseif ( 'sound_bad' === $notce ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'That file could not be used as an alert sound. MP3, WAV, OGG, M4A, AAC and WebM audio are accepted.', 'cloaklink' ); ?></div>
	<?php elseif ( 'code_error' === $notce ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'The rest was saved, but the access code was not changed: it takes six digits, typed the same way twice.', 'cloaklink' ); ?></div>
	<?php endif; ?>

	<?php
	// If the last alert mail failed, say so on every screen.
	//
	// A silent transport was the whole reason "I never get any mail" could not
	// be answered: the alert swallowed its own error, so the panel looked
	// healthy while nothing left the site. This banner is the one place that
	// says otherwise, and it names the fix.
	$cl_mail_last = cloaklink()->support->mail_last();
	// Only a recent failure is worth a banner.
	//
	// This used to show for ever, so one test on a staging machine — or one
	// broken SMTP host typed in and then cleared — left a red strip across the
	// top of every screen long after the cause was gone. A warning that cannot
	// be dismissed and never ages out stops being read, and then the real one
	// is missed. A day is long enough to catch somebody's attention and short
	// enough that the panel is not permanently branded by an old mistake.
	$cl_mail_when = ! empty( $cl_mail_last['time'] ) ? strtotime( (string) $cl_mail_last['time'] ) : 0;
	$cl_mail_recent = $cl_mail_when && ( time() - $cl_mail_when ) < DAY_IN_SECONDS;
	$cl_mail_dismissed = isset( $_COOKIE['cl_mail_notice_off'] ) && '1' === (string) $_COOKIE['cl_mail_notice_off']; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $cl_mail_recent && ! $cl_mail_dismissed && isset( $cl_mail_last['ok'] ) && ! $cl_mail_last['ok'] ) :
		?>
		<div class="cl-flash cl-flash--bad" id="cl-mail-notice">
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: address, 2: time, 3: reason */
					__( 'The last alert mail to %1$s at %2$s was refused.%3$s Alerts still send by the site’s own route, so this only affects that mailbox. Fix it under Settings → Send mail through your own mailbox, or dismiss this.', 'cloaklink' ),
					(string) $cl_mail_last['to'],
					(string) $cl_mail_last['time'],
					! empty( $cl_mail_last['reason'] ) ? ' ' . $cl_mail_last['reason'] : ''
				)
			);
			?>
			<a class="cl-flash__link" href="<?php echo esc_url( CloakLink_Admin::url( 'settings' ) ); ?>#cl-mail-test"><?php esc_html_e( 'Test it', 'cloaklink' ); ?></a>
			<button type="button" class="cl-flash__x" id="cl-mail-notice-x" title="<?php esc_attr_e( 'Hide this warning', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Hide this warning', 'cloaklink' ); ?>">×</button>
		</div>
	<?php endif; ?>

	<?php if ( 'created' === $account ) : ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'The account was created. Sign in with it at the panel address.', 'cloaklink' ); ?></div>
	<?php elseif ( 'missing' === $account ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'A username and a password are both required.', 'cloaklink' ); ?></div>
	<?php elseif ( 'exists' === $account ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'That username is already taken. Choose another.', 'cloaklink' ); ?></div>
	<?php elseif ( 'email_exists' === $account ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'That email address already belongs to an account.', 'cloaklink' ); ?></div>
	<?php elseif ( 'failed' === $account ) : ?>
		<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'The account could not be created.', 'cloaklink' ); ?></div>
	<?php endif; ?>

	<?php if ( ! empty( $_GET['flushed'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
		<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Permalinks rebuilt.', 'cloaklink' ); ?></div>
	<?php endif; ?>
	<div class="cl-body">
