<?php
/**
 * Panel footer.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_compliance = (string) $admin->setting( 'brand_note' );
?>
	</div><!-- .cl-body -->

	<footer class="cl-foot">
		<?php if ( cloaklink()->adv->yes( 'footer_hint' ) ) : ?>
			<p class="cl-foot__note"><?php echo esc_html( $cl_compliance ); ?></p>
		<?php endif; ?>
		<p class="cl-foot__meta">
			CloakLink <?php echo esc_html( CLOAKLINK_VERSION ); ?>
			· <?php echo esc_html( sprintf( /* translators: %s: host name */ __( 'links served from %s', 'cloaklink' ), $admin->site_host() ) ); ?>
			· <a href="<?php echo esc_url( CloakLink_Admin::url( 'tools' ) ); ?>"><?php esc_html_e( 'Health check', 'cloaklink' ); ?></a>
		</p>
	</footer>
</div><!-- .cl-wrap -->
