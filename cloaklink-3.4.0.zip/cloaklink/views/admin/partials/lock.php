<?php
/**
 * Panel idle lock.
 *
 * A signed-in WordPress session lasts for days. This covers the panel after a
 * stretch with no activity and opens only on the access code, so a tab left
 * open in an office is not readable by whoever walks past the desk.
 *
 * The form verifies itself. There is no Unlock button: a code screen with a
 * button invites a person to type their code and then hunt for the thing that
 * accepts it, and the field already knows when it is full. The length is never
 * stated — the field takes what is typed, and the answer comes from the
 * server.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_lock = isset( $cl_lock_cfg ) ? $cl_lock_cfg : array();
$cl_kind = isset( $cl_lock['needs'] ) && 'password' === $cl_lock['needs'] ? 'password' : 'code';
$cl_who  = isset( $cl_lock['name'] ) ? (string) $cl_lock['name'] : '';
$cl_mail = isset( $cl_lock['email'] ) ? (string) $cl_lock['email'] : '';
$cl_init = '' !== $cl_who ? strtoupper( substr( $cl_who, 0, 1 ) ) : '◆';
?>
<div class="cl-lock" id="cl-lock" hidden>
	<?php
	// Three layers behind the panel, all decorative: a slow field of falling
	// glyphs, a grid, and one scan line. They give the cover something to be
	// already doing while it waits, so a locked panel reads as a machine at
	// work rather than a page that failed to load. Reduced motion removes all
	// three; nothing informational is carried by them.
	?>
	<canvas class="cl-lock__rain" id="cl-lock-rain" aria-hidden="true"></canvas>
	<div class="cl-lock__grid" aria-hidden="true"></div>
	<div class="cl-lock__scan" aria-hidden="true"></div>

	<div class="cl-lock__panel" role="dialog" aria-modal="true" aria-labelledby="cl-lock-title">

		<?php
		// A viewfinder frame, drawn in CSS, around a card that holds exactly
		// two things: who is sitting here, and the key they must give. Every
		// other line — a brand row, a "Locked" heading, a paragraph of
		// explanation — was furniture on a screen somebody looks at for two
		// seconds.
		?>
		<span class="cl-lock__tick cl-lock__tick--tl" aria-hidden="true"></span>
		<span class="cl-lock__tick cl-lock__tick--tr" aria-hidden="true"></span>
		<span class="cl-lock__tick cl-lock__tick--bl" aria-hidden="true"></span>
		<span class="cl-lock__tick cl-lock__tick--br" aria-hidden="true"></span>

		<h2 class="cl-lock__title cl-lock__title--sr" id="cl-lock-title">
			<?php echo esc_html( sprintf( /* translators: %s: account name */ __( 'Access code for %s', 'cloaklink' ), '' !== $cl_who ? $cl_who : __( 'this account', 'cloaklink' ) ) ); ?>
		</h2>

		<div class="cl-lock__account">
			<span class="cl-lock__avatar-wrap" aria-hidden="true">
				<span class="cl-lock__ring"></span>
				<span class="cl-lock__avatar"><?php echo esc_html( $cl_init ); ?></span>
			</span>
			<span class="cl-lock__who">
				<span class="cl-lock__name"><?php echo esc_html( '' !== $cl_who ? $cl_who : __( 'Signed in', 'cloaklink' ) ); ?></span>
				<?php if ( '' !== $cl_mail ) : ?>
					<span class="cl-lock__mail"><?php echo esc_html( $cl_mail ); ?></span>
				<?php endif; ?>
			</span>
			<span class="cl-lock__seal" aria-hidden="true">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="10.5" width="17" height="10.5" rx="2.4"/><path d="M7.5 10.5V7.2a4.5 4.5 0 0 1 9 0v3.3"/></svg>
			</span>
		</div>

		<form class="cl-lock__form" id="cl-lock-form" novalidate>
			<label class="cl-lock__label" for="cl-lock-code">
				<span><?php echo 'password' === $cl_kind ? esc_html__( 'Password', 'cloaklink' ) : esc_html__( 'Access code', 'cloaklink' ); ?></span>
				<span class="cl-lock__auto" aria-hidden="true"><i></i><?php esc_html_e( 'Auto', 'cloaklink' ); ?></span>
			</label>

			<?php
			// The code row.
			//
			// This was a row that grew one cell per character typed, so it
			// never stated the length. It also never looked like a field: at
			// rest it was one lone box in the middle of a wide frame, which
			// is exactly how it was reported. A panel locked for a stretch of
			// no activity is not the place to be subtle — the operator wants
			// to put their code in and get back to work.
			//
			// So: six cells, always, filled with the digit as it is typed.
			// The whole row is one password input underneath; the cells are
			// how it is drawn, not how it is entered, so paste, a password
			// manager and the keyboard all behave normally.
			?>
			<div class="cl-lock__cellwrap">
				<div class="cl-lock__cells" id="cl-lock-cells" aria-hidden="true">
					<?php for ( $cl_i = 0; $cl_i < 6; $cl_i++ ) : ?>
						<i data-i="<?php echo (int) $cl_i; ?>"></i>
					<?php endfor; ?>
				</div>
			</div>

			<input
				class="cl-lock__input"
				id="cl-lock-code"
				name="cl_lock_code"
				type="password"
				autocomplete="<?php echo 'password' === $cl_kind ? 'current-password' : 'off'; ?>"
				inputmode="<?php echo 'password' === $cl_kind ? 'text' : 'numeric'; ?>"
				autocapitalize="none"
				spellcheck="false"
				aria-describedby="cl-lock-note"
				required>

			<div class="cl-lock__progress" id="cl-lock-progress">
				<span class="cl-lock__track"><i id="cl-lock-fill"></i></span>
			</div>

			<p class="cl-lock__note" id="cl-lock-note" role="status" aria-live="polite"></p>
		</form>

		<p class="cl-lock__foot">
			<a class="cl-lock__out" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 4h3.2A1.8 1.8 0 0 1 20 5.8v12.4a1.8 1.8 0 0 1-1.8 1.8H15"/><path d="M10 8.4 6.4 12l3.6 3.6"/><path d="M6.4 12h8.2"/></svg>
				<?php esc_html_e( 'Sign out', 'cloaklink' ); ?>
			</a>
			<span class="cl-lock__hint"><?php esc_html_e( 'Panel locked after a stretch of no activity.', 'cloaklink' ); ?></span>
		</p>
	</div>
</div>
