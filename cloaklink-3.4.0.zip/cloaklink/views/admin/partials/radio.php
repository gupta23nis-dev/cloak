<?php
/**
 * The walkie-talkie, on the console.
 *
 * A dock fixed to the bottom-right of every screen: a rail of lines on the
 * left, the open conversation on the right. It is deliberately not a page —
 * the operator needs it while reading a ticket, and a page would mean leaving
 * the ticket to answer a message about it.
 *
 * The markup is the empty shell. Everything inside it is drawn from the feed,
 * because the same component has to work on a screen loaded ten minutes ago
 * and on a screen the agent desk has just opened; a server-rendered list would
 * be wrong the moment a message arrived.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_radio_on = (bool) cloaklink()->settings->get( 'radio_on', 1 );
if ( ! $cl_radio_on ) {
	return;
}

$cl_radio_unread = cloaklink()->walkie->unread_total( cloaklink()->walkie->me_user() );
?>
<div class="cl-radio" id="cl-radio" data-open="0">

	<button class="cl-radio__fab" id="cl-radio-fab" type="button" aria-expanded="false" aria-controls="cl-radio-panel" title="<?php esc_attr_e( 'Walkie-talkie', 'cloaklink' ); ?>">
		<span class="cl-radio__fab-ico" aria-hidden="true">
			<svg class="cl-walkie" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.2 7.4h9.3a2.6 2.6 0 0 1 2.6 2.6v9.6a2.2 2.2 0 0 1-2.2 2.2H8.4a2.2 2.2 0 0 1-2.2-2.2z" opacity=".28"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" d="M6.2 8.6A2.4 2.4 0 0 1 8.6 6.2h6.6a2.4 2.4 0 0 1 2.4 2.4v10a1.9 1.9 0 0 1-1.9 1.9H8.1a1.9 1.9 0 0 1-1.9-1.9z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M16.4 6.4V2.4"/><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M9.2 9.6h4.4M9.2 11.6h4.4"/><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M10.1 17.4h2.6"/><path fill="currentColor" d="M18.7 9.6h1.5a.8.8 0 0 1 .8.8v5.1a.8.8 0 0 1-.8.8h-1.5z"/></svg>
		</span>
		<span class="cl-radio__fab-t"><?php esc_html_e( 'Radio', 'cloaklink' ); ?></span>
		<span class="cl-radio__fab-n" id="cl-radio-fab-n"<?php echo $cl_radio_unread ? '' : ' hidden'; ?>><?php echo esc_html( number_format_i18n( $cl_radio_unread ) ); ?></span>
	</button>

	<!-- The always-on microphone. It is not inside the panel: an operator or an
	     agent should be able to key the line from whatever screen they are
	     reading, without opening the radio first. Hold it and you are on air;
	     the dock is for choosing who hears you. -->
	<button class="cl-radio__key" id="cl-radio-key" type="button" aria-pressed="false" title="<?php esc_attr_e( 'Hold to talk', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Hold to talk', 'cloaklink' ); ?>">
		<span class="cl-radio__key-ico" aria-hidden="true">
			<?php
			// A handset, not a microphone.
			//
			// The key was drawn as a studio microphone, which is the mark for
			// recording something and keeping it. This key does the opposite:
			// hold it and the room hears you, let go and it is gone. The same
			// walkie-talkie glyph the dock opens with says that without a
			// label, which is what a person glancing at it needs.
			?>
			<svg class="cl-walkie" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.2 7.4h9.3a2.6 2.6 0 0 1 2.6 2.6v9.6a2.2 2.2 0 0 1-2.2 2.2H8.4a2.2 2.2 0 0 1-2.2-2.2z" opacity=".28"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" d="M6.2 8.6A2.4 2.4 0 0 1 8.6 6.2h6.6a2.4 2.4 0 0 1 2.4 2.4v10a1.9 1.9 0 0 1-1.9 1.9H8.1a1.9 1.9 0 0 1-1.9-1.9z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M16.4 6.4V2.4"/><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M9.2 9.6h4.4M9.2 11.6h4.4"/><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M10.1 17.4h2.6"/><path fill="currentColor" d="M18.7 9.6h1.5a.8.8 0 0 1 .8.8v5.1a.8.8 0 0 1-.8.8h-1.5z"/></svg>
		</span>
		<span class="cl-radio__key-ring" aria-hidden="true"></span>
		<span class="cl-radio__key-t" id="cl-radio-key-t"><?php esc_html_e( 'Hold to talk', 'cloaklink' ); ?></span>
	</button>

	<section class="cl-radio__panel" id="cl-radio-panel" aria-label="<?php esc_attr_e( 'Walkie-talkie', 'cloaklink' ); ?>" hidden>
		<header class="cl-radio__head">
			<div>
				<h2 class="cl-radio__title"><?php esc_html_e( 'Walkie-talkie', 'cloaklink' ); ?></h2>
				<p class="cl-radio__sub" id="cl-radio-sub"><?php esc_html_e( 'One line to each person on the desk.', 'cloaklink' ); ?></p>
			</div>
			<div class="cl-radio__hactions">
				<span class="cl-radio__live" id="cl-radio-live"><span class="cl-dot" aria-hidden="true"></span><?php esc_html_e( 'Live', 'cloaklink' ); ?></span>
				<button class="cl-radio__x" id="cl-radio-close" type="button" aria-label="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">✕</button>
			</div>
		</header>

		<div class="cl-radio__body">
			<aside class="cl-radio__rail">
				<div class="cl-radio__tabs" role="tablist">
					<button class="cl-radio__tab is-on" type="button" role="tab" aria-selected="true" data-rtab="lines"><?php esc_html_e( 'Lines', 'cloaklink' ); ?></button>
					<button class="cl-radio__tab" type="button" role="tab" aria-selected="false" data-rtab="roster"><?php esc_html_e( 'Desk', 'cloaklink' ); ?></button>
					<button class="cl-radio__tab" type="button" role="tab" aria-selected="false" data-rtab="settings"><?php esc_html_e( 'Sounds', 'cloaklink' ); ?></button>
				</div>

				<div class="cl-radio__pane" data-rpane="lines">
					<input class="cl-radio__find" id="cl-radio-find" type="search" autocomplete="off" placeholder="<?php esc_attr_e( 'Find a line', 'cloaklink' ); ?>">
					<div class="cl-radio__lines" id="cl-radio-lines">
						<p class="cl-radio__none"><?php esc_html_e( 'Loading…', 'cloaklink' ); ?></p>
					</div>
				</div>

				<div class="cl-radio__pane" data-rpane="roster" hidden>
					<p class="cl-radio__hint"><?php esc_html_e( 'Everyone on the desk. Press a name to open a private line.', 'cloaklink' ); ?></p>
					<div class="cl-radio__lines" id="cl-radio-roster">
						<p class="cl-radio__none"><?php esc_html_e( 'Loading…', 'cloaklink' ); ?></p>
					</div>
					<button class="cl-radio__new" id="cl-radio-newgroup" type="button"><?php esc_html_e( '+ New group', 'cloaklink' ); ?></button>
				</div>

				<div class="cl-radio__pane" data-rpane="settings" hidden>
					<p class="cl-radio__hint"><?php esc_html_e( 'The tone that sounds when a line is keyed. Everybody hears the sender’s tone.', 'cloaklink' ); ?></p>
					<label class="cl-radio__lab" for="cl-radio-deftone"><?php esc_html_e( 'Desk tone', 'cloaklink' ); ?></label>
					<select class="cl-radio__sel" id="cl-radio-deftone"></select>
					<div class="cl-radio__tones" id="cl-radio-roleroster"></div>
				</div>
			</aside>

			<div class="cl-radio__main" id="cl-radio-main">
				<div class="cl-radio__empty" id="cl-radio-hero">
					<span class="cl-radio__empty-ico" aria-hidden="true">📻</span>
					<p><b><?php esc_html_e( 'Pick a line, hold the key and talk.', 'cloaklink' ); ?></b></p>
					<p><?php esc_html_e( 'A private line to one agent, or a group for the whole shift. Choose who hears it, hold the key while you speak, and let go to stop. Nothing is recorded.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-radio__thread" id="cl-radio-thread" hidden>
					<header class="cl-radio__thead">
						<span class="cl-radio__avat" id="cl-radio-avat" aria-hidden="true"></span>
						<div class="cl-radio__tinfo">
							<h3 class="cl-radio__tname" id="cl-radio-tname">—</h3>
							<p class="cl-radio__tsub" id="cl-radio-tsub">—</p>
						</div>
						<div class="cl-radio__tacts" id="cl-radio-tacts"></div>
					</header>
					<div class="cl-radio__stage" id="cl-radio-stage">
						<p class="cl-radio__live-badge" id="cl-radio-live-badge"><span class="cl-radio__wave" aria-hidden="true"><i></i><i></i><i></i><i></i></span><?php esc_html_e( 'Live line', 'cloaklink' ); ?></p>
						<button class="cl-radio__mic" id="cl-radio-mic" type="button" aria-pressed="false" aria-label="<?php esc_attr_e( 'Hold to talk', 'cloaklink' ); ?>">
							<svg class="cl-walkie" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.2 7.4h9.3a2.6 2.6 0 0 1 2.6 2.6v9.6a2.2 2.2 0 0 1-2.2 2.2H8.4a2.2 2.2 0 0 1-2.2-2.2z" opacity=".28"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" d="M6.2 8.6A2.4 2.4 0 0 1 8.6 6.2h6.6a2.4 2.4 0 0 1 2.4 2.4v10a1.9 1.9 0 0 1-1.9 1.9H8.1a1.9 1.9 0 0 1-1.9-1.9z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M16.4 6.4V2.4"/><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M9.2 9.6h4.4M9.2 11.6h4.4"/><path fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" d="M10.1 17.4h2.6"/><path fill="currentColor" d="M18.7 9.6h1.5a.8.8 0 0 1 .8.8v5.1a.8.8 0 0 1-.8.8h-1.5z"/></svg>
							<span class="cl-radio__meter" id="cl-radio-meter" aria-hidden="true"></span>
						</button>
						<p class="cl-radio__stage-t" id="cl-radio-stage-t"><?php esc_html_e( 'Hold the button. They hear you as you speak.', 'cloaklink' ); ?></p>
						<p class="cl-radio__stage-s"><?php esc_html_e( 'Nothing is recorded and nothing is sent afterwards — this is a live line, like a radio.', 'cloaklink' ); ?></p>
						<button class="cl-radio__hear" id="cl-radio-hear" type="button" hidden><?php esc_html_e( 'Tap here once to let the sound through', 'cloaklink' ); ?></button>

						<?php
						// The line, measured.
						//
						// Every value below is read from the live connection
						// or from the signalling request itself: the browser's
						// own getStats() report, the ICE machinery's own state
						// and the timestamp of the last successful poll. None
						// of it is estimated, and every row says where it came
						// from — a diagnostics panel that invents a number is
						// worse than no panel, because it is believed.
						//
						// It is closed by default and lives under the key, so
						// it is there when a call sounds wrong and out of the
						// way when it does not.
						?>
						<details class="cl-radio__diag" id="cl-radio-diag">
							<summary class="cl-radio__diag-sum">
								<?php esc_html_e( 'Line diagnostics', 'cloaklink' ); ?>
								<span class="cl-radio__diag-state" id="cl-radio-diag-state">—</span>
							</summary>
							<dl class="cl-radio__diag-list" id="cl-radio-diag-list">
								<dt><?php esc_html_e( 'Signalling', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-signal"><?php esc_html_e( 'Not asked yet.', 'cloaklink' ); ?></dd>

								<dt><?php esc_html_e( 'ICE state', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-ice"><?php esc_html_e( 'No connection yet.', 'cloaklink' ); ?></dd>

								<dt><?php esc_html_e( 'Candidates', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-cand">—</dd>

								<dt><?php esc_html_e( 'Route', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-route">—</dd>

								<dt><?php esc_html_e( 'Codec', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-codec">—</dd>

								<dt><?php esc_html_e( 'Received', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-bytes">—</dd>

								<dt><?php esc_html_e( 'Round trip', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-rtt">—</dd>

								<dt><?php esc_html_e( 'Packet loss', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-loss">—</dd>

								<dt><?php esc_html_e( 'Jitter', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-jitter">—</dd>

								<dt><?php esc_html_e( 'Your microphone', 'cloaklink' ); ?></dt>
								<dd id="cl-radio-d-mic">—</dd>
							</dl>
							<div class="cl-radio__diag-foot">
								<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-radio-diag-refresh"><?php esc_html_e( 'Measure again', 'cloaklink' ); ?></button>
								<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-radio-diag-copy"><?php esc_html_e( 'Copy for a support note', 'cloaklink' ); ?></button>
								<span class="cl-help" id="cl-radio-diag-msg" role="status"></span>
							</div>
							<p class="cl-help"><?php esc_html_e( 'Read live from this browser’s own WebRTC report and from this line’s signalling request. Refresh it while the line is open; a value shown as “—” has not been measured yet rather than measured as zero.', 'cloaklink' ); ?></p>
						</details>
					</div>

					<?php
					// The notes on this line, and the box that writes one.
					//
					// These two were missing from the markup while the script
					// still asked for both by id: a note that arrived had
					// nowhere to be drawn, and a person had no field to type
					// in. The radio looked alive — it joined the line and
					// lit its badge — and could not carry a single message.
					?>
					<?php
					// No typing box.
					//
					// The radio had a text field under the line and a send
					// button beside it, which made the dock read as a chat
					// window with a microphone bolted on — and a written note
					// is the one thing a walkie-talkie does not do. Hold the
					// key, speak, let go. What is said is heard while it is
					// said and nothing is stored to be read later.
					//
					// The list stays: it names who is on the line and what the
					// line is doing, which is what a person looks at when the
					// key is not being held.
					?>
					<div class="cl-radio__msgs" id="cl-radio-msgs">
						<p class="cl-radio__none"><?php esc_html_e( 'Hold the key and speak. This line carries voice only.', 'cloaklink' ); ?></p>
					</div>
				</div>
			</div>
		</div>
	</section>
	</div>

<div class="cl-radio__modal" id="cl-radio-modal" hidden>
	<div class="cl-radio__dialog" role="dialog" aria-modal="true" aria-labelledby="cl-radio-mtitle">
		<h3 class="cl-radio__mtitle" id="cl-radio-mtitle"><?php esc_html_e( 'New group', 'cloaklink' ); ?></h3>
		<form id="cl-radio-gform" autocomplete="off">
			<label class="cl-radio__lab" for="cl-radio-gname"><?php esc_html_e( 'Name', 'cloaklink' ); ?></label>
			<input class="cl-radio__input" id="cl-radio-gname" type="text" maxlength="80" placeholder="<?php esc_attr_e( 'Night shift', 'cloaklink' ); ?>">
			<label class="cl-radio__lab"><?php esc_html_e( 'Tone for this group', 'cloaklink' ); ?></label>
			<select class="cl-radio__sel" id="cl-radio-gtone"></select>
			<label class="cl-radio__lab"><?php esc_html_e( 'Who is in it', 'cloaklink' ); ?></label>
			<div class="cl-radio__gpeople" id="cl-radio-gpeople"></div>
			<div class="cl-radio__mfoot">
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-radio-gcancel"><?php esc_html_e( 'Cancel', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Save group', 'cloaklink' ); ?></button>
			</div>
		</form>
	</div>
</div>
