<?php
/**
 * Smart monitoring: the band at the top of the console.
 *
 * The overview opens with five totals, and none of them answers the only
 * question an operator actually has at nine in the morning: is anything
 * happening, and does it want me? A wall of historical figures answers
 * "what has this desk done", which is the question you ask at the end of a
 * month, not the one you ask while a link is live.
 *
 * So this band goes first. It is four things, left to right:
 *
 *   the pulse     whether the desk is watching right now, and when the last
 *                 thing was seen. The dot is the one element on the console
 *                 that is allowed to move on its own, because it is saying
 *                 "I am still listening" and a still picture cannot say that.
 *
 *   the reading   one sentence in plain words about the last hour, built from
 *                 the same numbers the tiles carry. A person who reads only
 *                 this line is not misinformed.
 *
 *   the tiles     live now, captured, ticket queue, flagged. Each is a door:
 *                 the number is a count, and pressing it opens the screen that
 *                 lists what it is counting. A figure nobody can act on is
 *                 decoration.
 *
 *   the door      one primary act — get a link out — because the commonest
 *                 reason to open this panel is that somebody needs a link
 *                 right now.
 *
 * Everything here is either already live (the tiles are updated by the same
 * poll that drives the rest of the board) or cheap enough to compute on the
 * first paint. Nothing in it is stale by the time it is read.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_band_pulse   = ! empty( $cl_band['pulse'] );
$cl_band_ago     = isset( $cl_band['ago'] ) ? (string) $cl_band['ago'] : '';
$cl_band_reading = isset( $cl_band['reading'] ) ? (string) $cl_band['reading'] : '';
$cl_band_tiles   = isset( $cl_band['tiles'] ) ? $cl_band['tiles'] : array();
$cl_band_new     = isset( $cl_band['new_link'] ) ? $cl_band['new_link'] : CloakLink_Admin::url( 'new' );
?>
<section class="cl-watch" aria-labelledby="cl-watch-t">
	<div class="cl-watch__head">
		<?php
		// Three states, not two.
		//
		// "Idle" over a line saying eleven things arrived today is a
		// contradiction, and a reader who sees one stops trusting the number
		// as well as the word. The dot is about the last few minutes; the
		// figures are about the day. So when there is a day's work but no
		// recent arrival, the band says so — working, not watching — and the
		// dot is steady rather than dark.
		$cl_band_warm = ! $cl_band_pulse && ! empty( $cl_band['today'] );
		$cl_band_word = $cl_band_pulse
			? __( 'Watching', 'cloaklink' )
			: ( $cl_band_warm ? __( 'Working', 'cloaklink' ) : __( 'Idle', 'cloaklink' ) );
		$cl_band_mod = $cl_band_pulse ? ' is-live' : ( $cl_band_warm ? ' is-warm' : '' );
		?>
		<div class="cl-watch__pulse<?php echo esc_attr( $cl_band_mod ); ?>">
			<span class="cl-watch__dot" aria-hidden="true"></span>
			<span class="cl-watch__state">
				<b id="cl-watch-t"><?php echo esc_html( $cl_band_word ); ?></b>
				<?php if ( '' !== $cl_band_ago ) : ?>
					<em><?php echo esc_html( $cl_band_ago ); ?></em>
				<?php endif; ?>
			</span>
		</div>

		<p class="cl-watch__reading"><?php echo esc_html( $cl_band_reading ); ?></p>

		<a class="cl-watch__act" href="<?php echo esc_url( $cl_band_new ); ?>">
			<?php esc_html_e( 'New link', 'cloaklink' ); ?>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
		</a>
	</div>

	<?php if ( $cl_band_tiles ) : ?>
		<ul class="cl-watch__tiles">
			<?php foreach ( $cl_band_tiles as $cl_tile ) :
				$cl_t_tone  = isset( $cl_tile['tone'] ) ? (string) $cl_tile['tone'] : '';
				$cl_t_href  = isset( $cl_tile['href'] ) ? (string) $cl_tile['href'] : '';
				$cl_t_key   = isset( $cl_tile['key'] ) ? (string) $cl_tile['key'] : '';
				$cl_t_value = isset( $cl_tile['value'] ) ? $cl_tile['value'] : 0;
				$cl_t_label = isset( $cl_tile['label'] ) ? (string) $cl_tile['label'] : '';
				$cl_t_foot  = isset( $cl_tile['foot'] ) ? (string) $cl_tile['foot'] : '';
				?>
				<li class="cl-watch__tile<?php echo '' !== $cl_t_tone ? ' cl-watch__tile--' . esc_attr( $cl_t_tone ) : ''; ?>">
					<a class="cl-watch__link" href="<?php echo esc_url( $cl_t_href ); ?>">
						<span class="cl-watch__n"<?php echo '' !== $cl_t_key ? ' id="cl-watch-' . esc_attr( $cl_t_key ) . '"' : ''; ?>><?php echo esc_html( number_format_i18n( (int) $cl_t_value ) ); ?></span>
						<span class="cl-watch__l"><?php echo esc_html( $cl_t_label ); ?></span>
						<?php if ( '' !== $cl_t_foot ) : ?>
							<span class="cl-watch__f"><?php echo esc_html( $cl_t_foot ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</section>
