<?php
/**
 * One record, in full.
 *
 * A capture is a visit row. That is where the device, the place, the answers
 * the browser gave and the extra the desk filed all live — the support session
 * beside it holds the files and the form the visitor typed. This page joins
 * the two, so it can answer everything a card can only hint at: who this was,
 * what they handed over, where they were standing, what the handset reported,
 * what they typed, and every page that led here.
 *
 * It is a normal panel screen and keeps the rail, the radio and the lock. The
 * id in the address is the visit, so a record can be bookmarked, opened in a
 * second tab, or sent to a colleague.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification
$cl_id  = CloakLink_Admin::current_id();
$cl_row = $cl_id ? $cl_db->get_visit( $cl_id ) : null;
$cl_sup = cloaklink()->support;

if ( ! $cl_row ) {
	?>
	<div class="cl-panel">
		<div class="cl-panel__body">
			<p class="cl-empty"><?php esc_html_e( 'That record no longer exists. It may have been cleared, or removed with the link it belonged to.', 'cloaklink' ); ?></p>
			<p><a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'support' ) ); ?>"><?php esc_html_e( 'Back to smart monitoring', 'cloaklink' ); ?></a></p>
		</div>
	</div>
	<?php
	return;
}

$cl_cap   = $cl_db->capture_of( $cl_row );
$cl_link  = ! empty( $cl_row['link_id'] ) ? $cl_db->get_link( (int) $cl_row['link_id'] ) : null;
$cl_extra = $cl_db->decode( isset( $cl_row['extra'] ) ? $cl_row['extra'] : '' );
$cl_extra = is_array( $cl_extra ) ? $cl_extra : array();

// The session the desk filed for the same link, which is where the files and
// the typed form are. It is matched the same way capture_media_html() finds
// it, so the page and the card can never disagree about which file is whose.
$cl_session = null;
$cl_files   = array( 'photos' => array(), 'audio' => '', 'video' => '' );

if ( ! empty( $cl_row['link_id'] ) ) {
	$cl_cands = $cl_sup->sessions_for_link( (int) $cl_row['link_id'] );

	// A link can file more than one session — every visit that reached the
	// desk form opens its own. The files belong to the session, so the right
	// one to show is the one whose visitor is this record's visitor, matched
	// on the hashed address, and only then by recency. Falling back to "the
	// newest session for the link" would put somebody else's photograph on
	// this page, which on a document desk is worse than showing nothing.
	$cl_hash = trim( (string) ( isset( $cl_row['ip_hash'] ) ? $cl_row['ip_hash'] : '' ) );
	if ( '' !== $cl_hash ) {
		$cl_own = array();
		foreach ( (array) $cl_cands as $cl_cand ) {
			if ( trim( (string) $cl_cand['ip_hash'] ) === $cl_hash ) {
				$cl_own[] = $cl_cand;
			}
		}
		if ( $cl_own ) {
			$cl_cands = $cl_own;
		}
	}
	foreach ( (array) $cl_cands as $cl_cand ) {
		$cl_m = isset( $cl_cand['manifest'] ) && is_array( $cl_cand['manifest'] )
			? $cl_cand['manifest']
			: $cl_sup->decode_files( isset( $cl_cand['files'] ) ? $cl_cand['files'] : '' );
		if ( ! is_array( $cl_m ) ) {
			continue;
		}
		$cl_any = false;
		foreach ( array( 'audio', 'video' ) as $cl_k ) {
			if ( ! empty( $cl_m[ $cl_k ] ) ) {
				$cl_p = $cl_sup->media_path( (string) $cl_m[ $cl_k ] );
				if ( '' !== $cl_p && file_exists( $cl_p ) ) {
					$cl_any = true;
					break;
				}
			}
		}
		if ( ! $cl_any && ! empty( $cl_m['photos'] ) && is_array( $cl_m['photos'] ) ) {
			foreach ( $cl_m['photos'] as $cl_ph ) {
				$cl_p = $cl_sup->media_path( (string) $cl_ph );
				if ( '' !== $cl_p && file_exists( $cl_p ) ) {
					$cl_any = true;
					break;
				}
			}
		}
		// The first session with a file on disk wins. Until one is found the
		// newest is kept as a fallback, because its typed form is still true
		// even when the media folder has been swept.
		if ( ! $cl_session ) {
			$cl_session = $cl_cand;
			$cl_files   = $cl_m;
		}
		if ( $cl_any ) {
			$cl_session = $cl_cand;
			$cl_files   = $cl_m;
			break;
		}
	}
}

// The name. A visit row carries the name the desk wrote on it; otherwise it
// comes from the session beside it.
$cl_vname  = trim( (string) ( isset( $cl_row['visitor_name'] ) ? $cl_row['visitor_name'] : '' ) );
$cl_vphone = '';
$cl_vmail  = '';
if ( $cl_session ) {
	if ( '' === $cl_vname ) {
		$cl_vname = trim( (string) $cl_session['visitor_name'] );
	}
	$cl_vphone = trim( (string) $cl_session['visitor_phone'] );
	$cl_vmail  = trim( (string) $cl_session['visitor_email'] );
}

/**
 * One signed door for every file on this page.
 *
 * The console's own handler, with the same nonce the monitoring screen uses,
 * so a stream started here and a download started there are one kind of
 * request.
 *
 * @param string $which    photo|audio|video.
 * @param int    $index    Photo index.
 * @param bool   $download Saved copy rather than a stream.
 * @return string
 */
$cl_media = function ( $which, $index = 0, $download = false ) use ( $cl_session ) {
	$args = array(
		'cloaklink_media' => 1,
		'session'         => (int) $cl_session['id'],
		'file'            => (string) $which,
	);
	if ( 'photo' === $which ) {
		$args['n'] = (int) $index;
	}
	if ( $download ) {
		$args['dl'] = 1;
	}
	return wp_nonce_url( add_query_arg( $args, CloakLink_Admin::admin_base() ), 'cloaklink_media' );
};

$cl_photo_urls = array();
foreach ( (array) $cl_files['photos'] as $cl_i => $cl_fname ) {
	if ( '' === (string) $cl_fname ) {
		continue;
	}
	$cl_p = $cl_sup->media_path( (string) $cl_fname );
	if ( '' !== $cl_p && file_exists( $cl_p ) ) {
		$cl_photo_urls[ (int) $cl_i ] = $cl_media( 'photo', (int) $cl_i );
	}
}
$cl_has_video = $cl_session && '' !== (string) $cl_files['video'];
$cl_has_audio = $cl_session && '' !== (string) $cl_files['audio'];

// Where, once, in the three-way distinction the wall draws: a device fix, a
// network guess, or nothing.
$cl_place_bits = array_filter(
	array(
		trim( (string) $cl_row['city'] ),
		trim( (string) $cl_row['region'] ),
		trim( (string) ( '' !== (string) $cl_row['country_name'] ? $cl_row['country_name'] : $cl_row['country_code'] ) ),
	)
);
$cl_place   = $cl_place_bits ? implode( ', ', $cl_place_bits ) : '';
$cl_has_pos = '' !== (string) $cl_row['lat'] && '' !== (string) $cl_row['lng'];
$cl_geo     = $cl_has_pos
	? number_format_i18n( (float) $cl_row['lat'], 5 ) . ', ' . number_format_i18n( (float) $cl_row['lng'], 5 )
	: '';
$cl_acc = (int) $cl_row['accuracy'];

$cl_device = trim( implode( ' ', array_filter( array( (string) $cl_row['brand'], (string) $cl_row['device_model'] ) ) ) );
if ( '' === $cl_device ) {
	$cl_device = 'desktop' === (string) $cl_row['device'] ? __( 'Desktop computer', 'cloaklink' ) : __( 'Unidentified device', 'cloaklink' );
}

// The four things a visitor can hand over, each in one of three states. The
// capture answers the first question — did it happen — and the trail answers
// the second — was it given, or was it refused.
$cl_trail   = $cl_session ? $cl_sup->trail( $cl_session ) : array( 'rows' => array(), 'granted' => array(), 'refused' => array() );
$cl_granted = array_values( array_unique( array_merge( (array) $cl_trail['granted'], (array) ( isset( $cl_extra['granted'] ) && is_array( $cl_extra['granted'] ) ? $cl_extra['granted'] : array() ) ) ) );
$cl_refused = array_values( array_unique( array_merge( (array) $cl_trail['refused'], (array) ( isset( $cl_extra['refused'] ) && is_array( $cl_extra['refused'] ) ? $cl_extra['refused'] : array() ) ) ) );

$cl_allow = array();
foreach ( array(
	'position'   => array( __( 'Location', 'cloaklink' ), 'position' ),
	'camera'     => array( __( 'Camera', 'cloaklink' ), 'camera' ),
	'microphone' => array( __( 'Microphone', 'cloaklink' ), 'microphone' ),
	'video'      => array( __( 'Video', 'cloaklink' ), 'video' ),
) as $cl_key => $cl_meta ) {
	$cl_allow[ $cl_key ] = array(
		'label' => $cl_meta[0],
		'icon'  => $cl_meta[1],
		'given' => ! empty( $cl_cap[ $cl_key ] ),
		'held'  => in_array( $cl_key, $cl_refused, true ) && in_array( $cl_key, $cl_granted, true ) === false,
	);
}

$cl_status  = (string) $cl_row['status'];
$cl_is_live = in_array( $cl_status, array( 'open', 'capture' ), true );
$cl_removed = ! empty( $cl_extra['removed'] );

// Everything the handset said about itself, in one list, so the page states
// each fact exactly once.
$cl_facts = array();
foreach ( array(
	__( 'Model', 'cloaklink' )     => $cl_device,
	__( 'System', 'cloaklink' )    => (string) $cl_row['os'],
	__( 'Browser', 'cloaklink' )   => (string) $cl_row['browser'],
	__( 'Kind', 'cloaklink' )      => (string) $cl_row['device'],
	__( 'Screen', 'cloaklink' )    => (string) $cl_row['screen'],
	__( 'Viewport', 'cloaklink' )  => (string) $cl_row['viewport'],
	__( 'Language', 'cloaklink' )  => (string) $cl_row['lang'],
	__( 'Time zone', 'cloaklink' ) => (string) $cl_row['tz'],
) as $cl_lbl => $cl_val ) {
	if ( '' !== trim( (string) $cl_val ) ) {
		$cl_facts[ $cl_lbl ] = (string) $cl_val;
	}
}

$cl_net = array();
foreach ( array(
	__( 'Address', 'cloaklink' )  => (string) $cl_row['ip'],
	__( 'Network', 'cloaklink' )  => (string) $cl_row['isp'],
	__( 'Operator', 'cloaklink' ) => (string) $cl_row['asn'],
	__( 'Country', 'cloaklink' )  => (string) ( '' !== (string) $cl_row['country_name'] ? $cl_row['country_name'] : $cl_row['country_code'] ),
	__( 'Referrer', 'cloaklink' ) => (string) $cl_row['referrer'],
	__( 'Campaign', 'cloaklink' ) => (string) $cl_row['campaign'],
) as $cl_lbl => $cl_val ) {
	if ( '' !== trim( (string) $cl_val ) ) {
		$cl_net[ $cl_lbl ] = (string) $cl_val;
	}
}

$cl_flags = array();
if ( ! empty( $cl_row['is_proxy'] ) ) {
	$cl_flags[] = __( 'Proxy', 'cloaklink' );
}
if ( ! empty( $cl_row['is_vpn'] ) ) {
	$cl_flags[] = __( 'VPN', 'cloaklink' );
}
if ( $cl_removed ) {
	$cl_flags[] = __( 'Detail cleared', 'cloaklink' );
}

$cl_file_n = count( $cl_photo_urls ) + ( $cl_has_video ? 1 : 0 ) + ( $cl_has_audio ? 1 : 0 );
?>

<div class="cl-rec">

	<?php /* ---- Head ---- */ ?>
	<div class="cl-rec__head">
		<div class="cl-rec__id">
			<p class="cl-eyebrow">
				<a href="<?php echo esc_url( CloakLink_Admin::url( 'support' ) ); ?>"><?php esc_html_e( 'Smart monitoring', 'cloaklink' ); ?></a>
				<span aria-hidden="true">/</span>
				<?php esc_html_e( 'Record', 'cloaklink' ); ?>
			</p>
			<h2 class="cl-rec__title"><?php echo esc_html( '' !== $cl_vname ? $cl_vname : __( 'No name given', 'cloaklink' ) ); ?></h2>
			<p class="cl-rec__sub">
				<span class="cl-rec__stamp"><?php echo esc_html( CloakLink_Admin::stamp( $cl_row['created_at'], 'j M Y, g:i A' ) ); ?></span>
				<span class="cl-rec__sep" aria-hidden="true">·</span>
				<span><?php echo esc_html( $cl_device ); ?></span>
				<?php if ( '' !== $cl_place ) : ?>
					<span class="cl-rec__sep" aria-hidden="true">·</span>
					<span><?php echo esc_html( $cl_place ); ?></span>
				<?php endif; ?>
				<span class="cl-rec__pill <?php echo $cl_is_live ? 'is-live' : 'is-done'; ?>">
					<?php echo $cl_is_live ? esc_html__( 'Live', 'cloaklink' ) : esc_html__( 'Finished', 'cloaklink' ); ?>
				</span>
				<?php foreach ( $cl_flags as $cl_flag ) : ?>
					<span class="cl-rec__flag"><?php echo esc_html( $cl_flag ); ?></span>
				<?php endforeach; ?>
			</p>
		</div>

		<div class="cl-rec__acts">
			<?php if ( $cl_link ) : ?>
				<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'link', array( 'id' => (int) $cl_link['id'] ) ) ); ?>">
					<?php esc_html_e( 'The link', 'cloaklink' ); ?>
				</a>
			<?php endif; ?>
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'visits', array( 'id' => (int) $cl_row['link_id'] ) ) ); ?>">
				<?php esc_html_e( 'Every visit', 'cloaklink' ); ?>
			</a>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-inline"
				data-cl-confirm="<?php echo esc_attr( __( 'Clear this record? Its detail is removed from the monitoring screen. The record itself stays.', 'cloaklink' ) ); ?>">
				<input type="hidden" name="action" value="cloaklink_capture_action">
				<input type="hidden" name="cl_action" value="remove">
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) $cl_row['id'] ); ?>">
				<input type="hidden" name="cl_back_args[show]" value="all">
				<?php wp_nonce_field( 'cloaklink_capture_action' ); ?>
				<button type="submit" class="cl-btn cl-btn--ghost cl-btn--danger"><?php esc_html_e( 'Clear record', 'cloaklink' ); ?></button>
			</form>
		</div>
	</div>

	<?php /* ---- The four tiles ---- */ ?>
	<div class="cl-rec__allow">
		<?php foreach ( $cl_allow as $cl_key => $cl_a ) : ?>
			<?php
			$cl_state = $cl_a['given'] ? 'is-given' : ( $cl_a['held'] ? 'is-held' : 'is-none' );
			$cl_word  = $cl_a['given'] ? __( 'Given', 'cloaklink' ) : ( $cl_a['held'] ? __( 'Refused', 'cloaklink' ) : __( 'Not asked', 'cloaklink' ) );
			?>
			<div class="cl-rec__tile <?php echo esc_attr( $cl_state ); ?>">
				<span class="cl-rec__tileico" aria-hidden="true"><?php echo CloakLink_Admin::capture_icon( $cl_a['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- a static SVG from this plugin. ?></span>
				<span class="cl-rec__tilelabel"><?php echo esc_html( $cl_a['label'] ); ?></span>
				<span class="cl-rec__tileword"><?php echo esc_html( $cl_word ); ?></span>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="cl-rec__grid">

		<?php /* ---- The files, first: they are the evidence ---- */ ?>
		<section class="cl-rec__card cl-rec__card--files">
			<h3 class="cl-rec__h">
				<?php esc_html_e( 'What they handed over', 'cloaklink' ); ?>
				<?php if ( $cl_file_n ) : ?>
					<span class="cl-rec__hcount"><?php echo esc_html( (string) $cl_file_n ); ?></span>
				<?php endif; ?>
			</h3>

			<?php if ( $cl_has_video ) : ?>
				<figure class="cl-rec__film">
					<video controls preload="metadata" playsinline
						<?php if ( $cl_photo_urls ) : ?>poster="<?php echo esc_url( $cl_photo_urls[ array_key_first( $cl_photo_urls ) ] ); ?>"<?php endif; ?>
						src="<?php echo esc_url( $cl_media( 'video' ) ); ?>"></video>
					<figcaption>
						<span><?php esc_html_e( 'Screen recording', 'cloaklink' ); ?></span>
						<a href="<?php echo esc_url( $cl_media( 'video', 0, true ) ); ?>"><?php esc_html_e( 'Download', 'cloaklink' ); ?></a>
					</figcaption>
				</figure>
			<?php endif; ?>

			<?php if ( $cl_has_audio ) : ?>
				<div class="cl-rec__voice">
					<span class="cl-rec__voicelabel"><?php esc_html_e( 'Voice', 'cloaklink' ); ?></span>
					<audio controls preload="metadata" src="<?php echo esc_url( $cl_media( 'audio' ) ); ?>"></audio>
					<a class="cl-rec__voicedl" href="<?php echo esc_url( $cl_media( 'audio', 0, true ) ); ?>"><?php esc_html_e( 'Download', 'cloaklink' ); ?></a>
				</div>
			<?php endif; ?>

			<?php if ( $cl_photo_urls ) : ?>
				<div class="cl-rec__gallery">
					<?php foreach ( $cl_photo_urls as $cl_i => $cl_purl ) : ?>
						<a class="cl-rec__frame" href="<?php echo esc_url( $cl_purl ); ?>" target="_blank" rel="noopener noreferrer">
							<img src="<?php echo esc_url( $cl_purl ); ?>" alt="<?php echo esc_attr( sprintf( /* translators: %d: photograph number */ __( 'Photograph %d', 'cloaklink' ), $cl_i + 1 ) ); ?>" loading="lazy">
							<span class="cl-rec__framei"><?php echo esc_html( (string) ( $cl_i + 1 ) ); ?></span>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! $cl_file_n ) : ?>
				<p class="cl-rec__none"><?php esc_html_e( 'Nothing was handed over on this record.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</section>

		<?php /* ---- Where ---- */ ?>
		<section class="cl-rec__card">
			<h3 class="cl-rec__h"><?php esc_html_e( 'Where they were', 'cloaklink' ); ?></h3>

			<?php if ( $cl_has_pos ) : ?>
				<div class="cl-rec__mapwrap">
					<iframe class="cl-rec__mapframe" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
						src="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( (string) $cl_row['lat'] . ',' . (string) $cl_row['lng'] ) . '&z=15&output=embed' ); ?>"
						title="<?php esc_attr_e( 'A map of where this record was captured', 'cloaklink' ); ?>"></iframe>
					<span class="cl-rec__cross" aria-hidden="true"></span>
				</div>
			<?php endif; ?>

			<dl class="cl-rec__facts">
				<div>
					<dt><?php esc_html_e( 'Place', 'cloaklink' ); ?></dt>
					<dd><?php echo esc_html( '' !== $cl_place ? $cl_place : __( 'Not named', 'cloaklink' ) ); ?></dd>
				</div>
				<?php if ( '' !== $cl_geo ) : ?>
					<div>
						<dt><?php esc_html_e( 'Coordinates', 'cloaklink' ); ?></dt>
						<dd>
							<code><?php echo esc_html( $cl_geo ); ?></code>
							<?php if ( $cl_acc > 0 ) : ?>
								<span class="cl-rec__muted">±<?php echo esc_html( number_format_i18n( $cl_acc ) ); ?> m</span>
							<?php endif; ?>
						</dd>
					</div>
				<?php endif; ?>
			</dl>

			<?php if ( '' !== $cl_geo ) : ?>
				<a class="cl-rec__map" href="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( (string) $cl_row['lat'] . ',' . (string) $cl_row['lng'] ) ); ?>" target="_blank" rel="noopener">
					<span class="cl-rec__mapgrid" aria-hidden="true"></span>
					<span class="cl-rec__maptext">
						<b><?php esc_html_e( 'Open in Maps', 'cloaklink' ); ?></b>
						<i><?php echo esc_html( '' !== $cl_place ? $cl_place : $cl_geo ); ?></i>
					</span>
					<span class="cl-rec__maparrow" aria-hidden="true">↗</span>
				</a>
			<?php endif; ?>
		</section>

		<?php /* ---- The handset ---- */ ?>
		<section class="cl-rec__card">
			<h3 class="cl-rec__h"><?php esc_html_e( 'The handset', 'cloaklink' ); ?></h3>
			<?php if ( $cl_facts ) : ?>
				<dl class="cl-rec__facts">
					<?php foreach ( $cl_facts as $cl_lbl => $cl_val ) : ?>
						<div>
							<dt><?php echo esc_html( $cl_lbl ); ?></dt>
							<dd><?php echo esc_html( $cl_val ); ?></dd>
						</div>
					<?php endforeach; ?>
				</dl>
			<?php else : ?>
				<p class="cl-rec__none"><?php esc_html_e( 'The browser reported nothing about the device.', 'cloaklink' ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $cl_row['ua'] ) ) : ?>
				<p class="cl-rec__ua"><?php echo esc_html( (string) $cl_row['ua'] ); ?></p>
			<?php endif; ?>
		</section>

		<?php /* ---- The connection ---- */ ?>
		<section class="cl-rec__card">
			<h3 class="cl-rec__h"><?php esc_html_e( 'The connection', 'cloaklink' ); ?></h3>
			<?php if ( $cl_net ) : ?>
				<dl class="cl-rec__facts">
					<?php foreach ( $cl_net as $cl_lbl => $cl_val ) : ?>
						<div>
							<dt><?php echo esc_html( $cl_lbl ); ?></dt>
							<dd><?php echo esc_html( $cl_val ); ?></dd>
						</div>
					<?php endforeach; ?>
				</dl>
			<?php else : ?>
				<p class="cl-rec__none"><?php esc_html_e( 'No network detail was recorded.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</section>

		<?php /* ---- What they typed ---- */ ?>
		<section class="cl-rec__card">
			<h3 class="cl-rec__h"><?php esc_html_e( 'What they told you', 'cloaklink' ); ?></h3>
			<?php $cl_said = ( '' !== $cl_vname || '' !== $cl_vphone || '' !== $cl_vmail ); ?>
			<?php if ( $cl_said ) : ?>
				<dl class="cl-rec__facts">
					<div>
						<dt><?php esc_html_e( 'Name', 'cloaklink' ); ?></dt>
						<dd><?php echo esc_html( '' !== $cl_vname ? $cl_vname : __( 'Not given', 'cloaklink' ) ); ?></dd>
					</div>
					<?php if ( '' !== $cl_vphone ) : ?>
						<div>
							<dt><?php esc_html_e( 'Phone', 'cloaklink' ); ?></dt>
							<dd>
								<?php if ( cloaklink()->adv->yes( 'mask_phones' ) ) : ?>
									<?php echo esc_html( '••••••' . substr( preg_replace( '/\D/', '', $cl_vphone ), -4 ) ); ?>
								<?php else : ?>
									<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $cl_vphone ) ); ?>"><?php echo esc_html( $cl_vphone ); ?></a>
								<?php endif; ?>
							</dd>
						</div>
					<?php endif; ?>
					<?php if ( '' !== $cl_vmail ) : ?>
						<div>
							<dt><?php esc_html_e( 'Email', 'cloaklink' ); ?></dt>
							<dd><a href="mailto:<?php echo esc_attr( $cl_vmail ); ?>"><?php echo esc_html( $cl_vmail ); ?></a></dd>
						</div>
					<?php endif; ?>
					<?php if ( $cl_session && '' !== trim( (string) $cl_session['visitor_topic'] ) ) : ?>
						<div>
							<dt><?php esc_html_e( 'Topic', 'cloaklink' ); ?></dt>
							<dd><?php echo esc_html( (string) $cl_session['visitor_topic'] ); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ( $cl_session && '' !== trim( (string) $cl_session['visitor_reference'] ) ) : ?>
						<div>
							<dt><?php esc_html_e( 'Reference', 'cloaklink' ); ?></dt>
							<dd><code><?php echo esc_html( (string) $cl_session['visitor_reference'] ); ?></code></dd>
						</div>
					<?php endif; ?>
				</dl>
			<?php else : ?>
				<p class="cl-rec__none"><?php esc_html_e( 'They did not fill in the desk form.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</section>

		<?php /* ---- The link ---- */ ?>
		<section class="cl-rec__card cl-rec__card--wide">
			<h3 class="cl-rec__h"><?php esc_html_e( 'The link they opened', 'cloaklink' ); ?></h3>
			<?php if ( $cl_link ) : ?>
				<dl class="cl-rec__facts cl-rec__facts--inline">
					<div>
						<dt><?php esc_html_e( 'Name', 'cloaklink' ); ?></dt>
						<dd><?php echo esc_html( (string) $cl_link['title'] ); ?></dd>
					</div>
					<?php if ( '' !== trim( (string) $cl_row['slug'] ) ) : ?>
						<div>
							<dt><?php esc_html_e( 'Address', 'cloaklink' ); ?></dt>
							<dd><code><?php echo esc_html( (string) $cl_row['slug'] ); ?></code></dd>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $cl_row['page_url'] ) ) : ?>
						<div>
							<dt><?php esc_html_e( 'Page', 'cloaklink' ); ?></dt>
							<dd><code><?php echo esc_html( (string) $cl_row['page_url'] ); ?></code></dd>
						</div>
					<?php endif; ?>
					<?php if ( isset( $cl_row['dwell'] ) && (int) $cl_row['dwell'] > 0 ) : ?>
						<div>
							<dt><?php esc_html_e( 'Time on page', 'cloaklink' ); ?></dt>
							<dd><?php echo esc_html( sprintf( /* translators: %s: duration in seconds */ __( '%s seconds', 'cloaklink' ), number_format_i18n( (int) $cl_row['dwell'] ) ) ); ?></dd>
						</div>
					<?php endif; ?>
				</dl>
				<a class="cl-rec__more" href="<?php echo esc_url( CloakLink_Admin::url( 'link', array( 'id' => (int) $cl_link['id'] ) ) ); ?>"><?php esc_html_e( 'Everything this link has recorded', 'cloaklink' ); ?> →</a>
			<?php else : ?>
				<p class="cl-rec__none"><?php esc_html_e( 'The link this came through has since been deleted. The record was kept.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</section>

		<?php /* ---- The trail ---- */ ?>
		<section class="cl-rec__card cl-rec__card--wide">
			<h3 class="cl-rec__h">
				<?php esc_html_e( 'What happened, in order', 'cloaklink' ); ?>
				<?php if ( ! empty( $cl_trail['rows'] ) ) : ?>
					<span class="cl-rec__hcount"><?php echo esc_html( (string) count( $cl_trail['rows'] ) ); ?></span>
				<?php endif; ?>
			</h3>
			<?php if ( empty( $cl_trail['rows'] ) ) : ?>
				<p class="cl-rec__none"><?php esc_html_e( 'The pages behind this record have been cleared or aged out.', 'cloaklink' ); ?></p>
			<?php else : ?>
				<ol class="cl-rec__trail">
					<?php foreach ( $cl_trail['rows'] as $cl_t ) : ?>
						<li class="cl-rec__step" data-event="<?php echo esc_attr( (string) $cl_t['event'] ); ?>">
							<span class="cl-rec__stepdot" aria-hidden="true"></span>
							<span class="cl-rec__steptime"><?php echo esc_html( CloakLink_Admin::stamp( $cl_t['created_at'], 'g:i:s A' ) ); ?></span>
							<span class="cl-rec__stepevent"><?php echo esc_html( ucfirst( str_replace( '_', ' ', (string) $cl_t['event'] ) ) ); ?></span>
							<?php if ( ! empty( $cl_t['path'] ) ) : ?>
								<code class="cl-rec__steppath"><?php echo esc_html( (string) $cl_t['path'] ); ?></code>
							<?php endif; ?>
							<?php if ( (int) $cl_t['repeat'] > 1 ) : ?>
								<span class="cl-rec__steprep">×<?php echo esc_html( number_format_i18n( (int) $cl_t['repeat'] ) ); ?></span>
							<?php endif; ?>
							<?php if ( ! empty( $cl_t['extra_marks'] ) ) : ?>
								<span class="cl-rec__stepmarks"><?php echo esc_html( (string) $cl_t['extra_marks'] ); ?></span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ol>
			<?php endif; ?>
		</section>

	</div>
</div>
