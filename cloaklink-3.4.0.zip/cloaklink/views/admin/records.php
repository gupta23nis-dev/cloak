<?php
/**
 * All records: every capture, on one list.
 *
 * Smart monitoring is a desk. It is built around what is happening now — a
 * live wall, a queue, an alert tone — and that is the right shape for a
 * screen somebody watches. It is the wrong shape for the other question,
 * which is asked later and with a name: "what did this person hand over, and
 * when".
 *
 * So this page is the archive. Same rows, same card, no live framing: a
 * search over the visitor's name, the reference, the city, the address and
 * the link; a date range; the link; and a switch for the cards that were
 * taken off the wall. Nothing is invented here and nothing is summarised
 * away — it reads the same rows the monitoring wall reads, so the two can
 * never disagree about what a person gave.
 *
 * Deleting is offered here and only here, and it is the real thing: cleared
 * records keep a stub, whereas this removes the visit. A bulk selection is
 * there because pruning a run of one agent's own test clicks is the reason
 * the page exists.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification
$cl_search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$cl_show   = isset( $_GET['show'] ) ? sanitize_key( wp_unslash( $_GET['show'] ) ) : 'kept';
if ( ! in_array( $cl_show, array( 'kept', 'archived', 'all' ), true ) ) {
	$cl_show = 'kept';
}
$cl_link_focus = isset( $_GET['link'] ) ? absint( $_GET['link'] ) : 0;
$cl_from       = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
$cl_to         = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
$cl_note       = isset( $_GET['cl_records'] ) ? sanitize_key( wp_unslash( $_GET['cl_records'] ) ) : '';
// phpcs:enable WordPress.Security.NonceVerification

$cl_day = function ( $raw ) {
	$raw = trim( (string) $raw );
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m ) ) {
		return '';
	}
	return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $raw : '';
};
$cl_from = $cl_day( $cl_from );
$cl_to   = $cl_day( $cl_to );

$cl_rows = $cl_db->captured_visits(
	array(
		'link_id' => $cl_link_focus,
		'from'    => $cl_from,
		'to'      => $cl_to,
		'show'    => $cl_show,
		// The archive is allowed to be long. Sixty is one screenful of the
		// monitoring wall; here an operator is looking something up, and a
		// hard ceiling would hide the record they came for.
		'max'     => 300,
	)
);

// The names the cards print for a link, built once.
$cl_names = array();
foreach ( $cl_db->get_links( array( 'per_page' => 400 ) ) as $cl_l ) {
	$cl_names[ (int) $cl_l['id'] ] = array(
		'name'  => '' !== trim( (string) $cl_l['title'] ) ? (string) $cl_l['title'] : (string) $cl_l['slug'],
		'slug'  => (string) $cl_l['slug'],
		'label' => (string) $cl_l['label'],
		'type'  => (string) $cl_l['link_type'],
	);
}

$cl_people = cloaklink()->support->visitor_names( $cl_link_focus );

// The search is applied here rather than in SQL because the fields it covers
// do not all live in one column: the name is on the support session, the
// reference and the city on the visit, the link title in another table. One
// pass in PHP over an already-bounded set is honest and cheap.
$cl_hay = function ( $row ) use ( $cl_names, $cl_people ) {
	$bits = array(
		(string) ( isset( $row['city'] ) ? $row['city'] : '' ),
		(string) ( isset( $row['region'] ) ? $row['region'] : '' ),
		(string) ( isset( $row['country_name'] ) ? $row['country_name'] : '' ),
		(string) ( isset( $row['ip'] ) ? $row['ip'] : '' ),
		(string) ( isset( $row['slug'] ) ? $row['slug'] : '' ),
		(string) ( isset( $row['referrer'] ) ? $row['referrer'] : '' ),
	);
	$lid = (int) ( isset( $row['link_id'] ) ? $row['link_id'] : 0 );
	if ( isset( $cl_names[ $lid ] ) ) {
		$bits[] = (string) $cl_names[ $lid ]['name'];
		$bits[] = (string) $cl_names[ $lid ]['label'];
	}
	$who = cloaklink()->support->name_for( $row, $cl_people );
	if ( $who ) {
		$bits[] = (string) $who['name'];
	}
	return mb_strtolower( implode( ' ', $bits ) );
};

$cl_shown = array();
if ( '' !== $cl_search ) {
	$cl_q = mb_strtolower( $cl_search );
	foreach ( $cl_rows as $cl_r ) {
		if ( false !== mb_strpos( $cl_hay( $cl_r ), $cl_q ) ) {
			$cl_shown[] = $cl_r;
		}
	}
} else {
	$cl_shown = $cl_rows;
}

$cl_back = array(
	'cl_page' => 'records',
	's'       => $cl_search,
	'show'    => $cl_show,
	'link'    => $cl_link_focus,
	'from'    => $cl_from,
	'to'      => $cl_to,
);
?>

<div class="cl-panel cl-records">
	<?php
	// The archive's own masthead.
	//
	// A panel head says "All records" and hands straight over to a filter bar,
	// which is correct and reads like a database. This screen is the one an
	// operator arrives at with a name and no idea what to expect, so the top
	// of it now says how much is behind it at a glance — how many records,
	// how many on the wall, how many taken down, how much of it moved today —
	// before any of the fields they have to fill in.
	//
	// Every figure here is counted from the same rows the grid draws, so the
	// numbers and the cards can never disagree.
	$cl_onwall = 0;
	$cl_offwall = 0;
	$cl_today = 0;
	$cl_today_floor = strtotime( gmdate( 'Y-m-d' ) . ' 00:00:00' );
	foreach ( $cl_shown as $cl_tally_row ) {
		if ( ! empty( $cl_tally_row['hidden'] ) ) {
			$cl_offwall++;
		} else {
			$cl_onwall++;
		}
		$cl_row_ts = $cl_db->to_ts( (string) $cl_tally_row['created_at'] );
		if ( $cl_row_ts && $cl_row_ts >= $cl_today_floor ) {
			$cl_today++;
		}
	}
	$cl_total = count( $cl_shown );
	?>
	<header class="cl-records__hero">
		<div class="cl-records__hero-main">
			<p class="cl-records__kicker">
				<span class="cl-records__kicker-dot" aria-hidden="true"></span>
				<?php esc_html_e( 'Archive', 'cloaklink' ); ?>
			</p>
			<h2 class="cl-records__hero-t"><?php esc_html_e( 'All records', 'cloaklink' ); ?></h2>
			<p class="cl-records__hero-s">
				<?php esc_html_e( 'Every capture, including the ones taken off the wall. Search by name, reference, city, address or link.', 'cloaklink' ); ?>
			</p>
		</div>

		<div class="cl-records__hero-stats" role="group" aria-label="<?php esc_attr_e( 'Record totals', 'cloaklink' ); ?>">
			<span class="cl-records__stat" data-stat="total">
				<b><?php echo esc_html( number_format_i18n( $cl_total ) ); ?></b>
				<span><?php echo esc_html( _n( 'record', 'records', $cl_total, 'cloaklink' ) ); ?></span>
			</span>
			<span class="cl-records__stat cl-records__stat--live" data-stat="onwall">
				<b><?php echo esc_html( number_format_i18n( $cl_onwall ) ); ?></b>
				<span><?php esc_html_e( 'on the wall', 'cloaklink' ); ?></span>
			</span>
			<span class="cl-records__stat cl-records__stat--mute" data-stat="offwall">
				<b><?php echo esc_html( number_format_i18n( $cl_offwall ) ); ?></b>
				<span><?php esc_html_e( 'taken down', 'cloaklink' ); ?></span>
			</span>
			<span class="cl-records__stat cl-records__stat--today" data-stat="today">
				<b><?php echo esc_html( number_format_i18n( $cl_today ) ); ?></b>
				<span><?php esc_html_e( 'today', 'cloaklink' ); ?></span>
			</span>
		</div>
	</header>

	<?php
	// The number that actually went.
	//
	// "Those records were deleted" was printed for one tick and for forty,
	// and it was printed even when every ticked row had already gone. Both
	// numbers come from the handler, so the sentence can be exact and can
	// admit the difference.
	$cl_rn     = isset( $_GET['cl_count'] ) ? max( 0, (int) $_GET['cl_count'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$cl_rasked = isset( $_GET['cl_asked'] ) ? max( 0, (int) $_GET['cl_asked'] ) : $cl_rn; // phpcs:ignore WordPress.Security.NonceVerification
	$cl_rmiss  = max( 0, $cl_rasked - $cl_rn );
	?>
	<?php
	// A single card's own controls, answered on the screen they were pressed
	// on.
	//
	// The ✕, the archive mark and the restore mark all posted from this page
	// and all came back to it, but only "deleted" had a sentence written for
	// it — and even that one only in the plural-count shape the bulk bar
	// uses. Archiving a record from the archive therefore removed it from the
	// list with no line saying so, which is indistinguishable from a delete
	// that did nothing.
	$cl_single = array(
		'removed'  => array( 'ok', __( 'Detail cleared. The record is still here, and the visitor log still has it.', 'cloaklink' ) ),
		'archived' => array( 'ok', __( 'Taken off the wall. It is still on this list under “Taken off the wall”.', 'cloaklink' ) ),
		'restored' => array( 'ok', __( 'Put back on the wall.', 'cloaklink' ) ),
	);
	?>
	<?php if ( isset( $cl_single[ $cl_note ] ) ) : ?>
		<div class="cl-flash cl-flash--<?php echo esc_attr( $cl_single[ $cl_note ][0] ); ?>">
			<?php echo esc_html( $cl_single[ $cl_note ][1] ); ?>
		</div>
	<?php elseif ( 'gone' === $cl_note ) : ?>
		<div class="cl-flash cl-flash--bad">
			<?php esc_html_e( 'Nothing was deleted: that record had already gone. The list below is the current one.', 'cloaklink' ); ?>
		</div>
	<?php endif; ?>
	<?php if ( 'deleted' === $cl_note || 'none' === $cl_note ) : ?>
		<?php if ( $cl_rn ) : ?>
			<div class="cl-flash cl-flash--ok">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of records deleted */
						_n(
							'%d record deleted, with every file captured under it.',
							'%d records deleted, with every file captured under them.',
							$cl_rn,
							'cloaklink'
						),
						$cl_rn
					)
				);
				?>
				<?php if ( $cl_rmiss ) : ?>
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: number already gone, 2: number selected */
							__( '%1$d of the %2$d selected had already gone.', 'cloaklink' ),
							$cl_rmiss,
							$cl_rasked
						)
					);
					?>
				<?php endif; ?>
			</div>
		<?php else : ?>
			<div class="cl-flash cl-flash--bad">
				<?php
				echo esc_html(
					$cl_rasked
						? sprintf(
							/* translators: %d: number selected */
							_n(
								'Nothing was deleted: the %d selected record is no longer there. The list below is the current one.',
								'Nothing was deleted: none of the %d selected records are there any more. The list below is the current one.',
								$cl_rasked,
								'cloaklink'
							),
							$cl_rasked
						)
						: __( 'Nothing was selected, so nothing was deleted.', 'cloaklink' )
				);
				?>
			</div>
		<?php endif; ?>
	<?php endif; ?>

	<form class="cl-records__filters" method="get" action="<?php echo esc_url( CloakLink_Admin::admin_base() ); ?>">
		<input type="hidden" name="cl_page" value="records">

		<label class="cl-records__f">
			<span><?php esc_html_e( 'Search', 'cloaklink' ); ?></span>
			<input type="search" name="s" value="<?php echo esc_attr( $cl_search ); ?>" placeholder="<?php esc_attr_e( 'name, city, address, link…', 'cloaklink' ); ?>">
		</label>

		<label class="cl-records__f">
			<span><?php esc_html_e( 'Link', 'cloaklink' ); ?></span>
			<select name="link">
				<option value="0"><?php esc_html_e( 'All links', 'cloaklink' ); ?></option>
				<?php foreach ( $cl_names as $cl_lid => $cl_l ) : ?>
					<option value="<?php echo esc_attr( (string) $cl_lid ); ?>" <?php selected( $cl_link_focus, (int) $cl_lid ); ?>>
						<?php echo esc_html( '' !== $cl_l['label'] ? $cl_l['label'] . ' — ' . $cl_l['name'] : $cl_l['name'] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="cl-records__f">
			<span><?php esc_html_e( 'From', 'cloaklink' ); ?></span>
			<input type="date" name="from" value="<?php echo esc_attr( $cl_from ); ?>">
		</label>

		<label class="cl-records__f">
			<span><?php esc_html_e( 'To', 'cloaklink' ); ?></span>
			<input type="date" name="to" value="<?php echo esc_attr( $cl_to ); ?>">
		</label>

		<label class="cl-records__f">
			<span><?php esc_html_e( 'Show', 'cloaklink' ); ?></span>
			<select name="show">
				<option value="kept" <?php selected( $cl_show, 'kept' ); ?>><?php esc_html_e( 'On the wall', 'cloaklink' ); ?></option>
				<option value="archived" <?php selected( $cl_show, 'archived' ); ?>><?php esc_html_e( 'Taken off the wall', 'cloaklink' ); ?></option>
				<option value="all" <?php selected( $cl_show, 'all' ); ?>><?php esc_html_e( 'Everything', 'cloaklink' ); ?></option>
			</select>
		</label>

		<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Apply', 'cloaklink' ); ?></button>
		<?php if ( '' !== $cl_search || $cl_link_focus || '' !== $cl_from || '' !== $cl_to || 'kept' !== $cl_show ) : ?>
			<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( CloakLink_Admin::url( 'records' ) ); ?>"><?php esc_html_e( 'Reset', 'cloaklink' ); ?></a>
		<?php endif; ?>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="cl-records-form">
		<input type="hidden" name="action" value="cloaklink_capture_action">
		<input type="hidden" name="cl_records_back" value="1">
		<?php
		// The filters travel with the action, so deleting a record does not
		// silently drop the operator back to an unfiltered list. Every field
		// is registered on the handler's side as a known key.
		foreach ( $cl_back as $cl_bk => $cl_bv ) :
			if ( '' === (string) $cl_bv || 0 === $cl_bv ) {
				continue;
			}
			?>
			<input type="hidden" name="cl_back_args[<?php echo esc_attr( $cl_bk ); ?>]" value="<?php echo esc_attr( (string) $cl_bv ); ?>">
		<?php endforeach; ?>
		<?php wp_nonce_field( 'cloaklink_capture_action' ); ?>

		<div class="cl-pickbar" id="cl-pickbar">
			<?php
			// The way to delete more than one record at a time.
			//
			// This said only "Select", which is a word about selection, not
			// about deletion — so an operator looking for a way to remove a
			// record found a control that described something else, and the
			// deletion it leads to was two presses away behind a word they
			// had no reason to press. The label now says what the control is
			// for, the glyph says it removes, and the count appears on the
			// button itself once anything is ticked.
			?>
			<button class="cl-btn cl-btn--ghost cl-btn--sm cl-pickbar__toggle" type="button" id="cl-pick-toggle" aria-pressed="false">
				<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16"/><path d="M9.5 7V5.2A1.2 1.2 0 0 1 10.7 4h2.6a1.2 1.2 0 0 1 1.2 1.2V7"/><path d="M6.4 7v11.6A1.4 1.4 0 0 0 7.8 20h8.4a1.4 1.4 0 0 0 1.4-1.4V7"/><path d="M10.4 10.6v6M13.6 10.6v6"/></svg>
				<span><?php esc_html_e( 'Delete records', 'cloaklink' ); ?></span>
			</button>
			<span class="cl-pickbar__hint"><?php esc_html_e( 'or press ✕ on a single card', 'cloaklink' ); ?></span>
			<div class="cl-pickbar__run" id="cl-pickrun" hidden>
				<span class="cl-pickbar__n" id="cl-pickn"><?php esc_html_e( 'Nothing selected', 'cloaklink' ); ?></span>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-pickall"><?php esc_html_e( 'Select all', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-picknone"><?php esc_html_e( 'Clear', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--danger cl-btn--sm" type="submit" name="cl_action" value="bulk_delete" id="cl-pickdelete" disabled
					data-confirm="<?php echo esc_attr__( 'Delete every selected record for good? The visit, its detail and its captured files go. This cannot be undone.', 'cloaklink' ); ?>">
					<?php esc_html_e( 'Delete selected', 'cloaklink' ); ?>
				</button>
			</div>
		</div>
	</form>

	<?php
	// The grid sits outside the form on purpose.
	//
	// Every card carries controls of its own — the remove form, the ✕, the
	// record link — and a <form> cannot legally contain another. Wrapping the
	// grid put 109 forms inside this one, and the browser, which cannot nest
	// them, silently closed this form at the first card: the Delete selected
	// button then belonged to no form at all, and pressing it did nothing.
	// The checkboxes join this form the way the wall's do, by the `form`
	// attribute on each input, so nothing has to be wrapped.
	//
	// The scope is handed over before the first card is drawn. Each card's own
	// controls post their own form, and they have to know this is the archive
	// and which filters were on — otherwise the ✕ deleted the record and then
	// landed the operator on Smart monitoring, which reads as "delete does not
	// work" because the row is gone from a screen they were never on.
	$admin->set_capture_scope(
		array(
			'link' => $cl_link_focus,
			'from' => $cl_from,
			'to'   => $cl_to,
			'show' => $cl_show,
			's'    => $cl_search,
		)
	);
	?>
	<div class="cl-records__grid" id="cl-records-grid" data-count="<?php echo esc_attr( (string) count( $cl_shown ) ); ?>">
		<?php
		$cl_i = 0;
		foreach ( $cl_shown as $cl_row ) :
			?>
			<div class="cl-records__one" style="--cl-i:<?php echo esc_attr( (string) min( 24, $cl_i ) ); ?>">
				<?php
				// The monitoring screen's own card, unchanged: same picture,
				// same marks, same record link. This page is a different
				// entry point, not a different view of the data.
				$cl_seen = 0;
				echo $admin->capture_card_html( $cl_row, $cl_names, array(), null, null ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside capture_card_html().
				?>
			</div>
			<?php
			$cl_i++;
		endforeach;
		?>
	</div>

	<?php // Always in the DOM, so the live refresh can show it when a filter stops matching. ?>
	<p class="cl-empty cl-records__none"<?php echo $cl_shown ? ' hidden' : ''; ?>>
		<span aria-hidden="true">◎</span>
		<?php esc_html_e( 'No record matches that. Widen the dates, clear the search, or switch “Show” to Everything.', 'cloaklink' ); ?>
	</p>
</div>
