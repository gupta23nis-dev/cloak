<?php
/**
 * Settings screen.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_s = $settings->all();

// An agent form posted from this screen comes back here with one of the
// shared codes. The list is the same one the desk page reads, so a code
// cannot mean one thing on one page and nothing on the other.
$cl_hello = isset( $_GET['cl_agent_msg'] ) ? sanitize_key( wp_unslash( $_GET['cl_agent_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_words = CloakLink_Admin::agent_words();
$cl_msg   = isset( $cl_words[ $cl_hello ] ) ? $cl_words[ $cl_hello ] : null;

// The desk's rules moved here from the Case agents page: nine switches and
// the numbers behind them are configuration, and the desk page is for reading
// what is happening, not for changing how it may happen.
$cl_policy      = cloaklink()->agent_policy;
$cl_paused_any  = $cl_policy->desk_paused();
$cl_days        = array(
	1 => __( 'Mon', 'cloaklink' ),
	2 => __( 'Tue', 'cloaklink' ),
	3 => __( 'Wed', 'cloaklink' ),
	4 => __( 'Thu', 'cloaklink' ),
	5 => __( 'Fri', 'cloaklink' ),
	6 => __( 'Sat', 'cloaklink' ),
	7 => __( 'Sun', 'cloaklink' ),
);
$cl_on_days = array_filter( array_map( 'absint', explode( ',', (string) $cl_policy->value( 'desk_hours_days' ) ) ) );
$cl_paused  = $cl_paused_any;
?>

<?php if ( $cl_msg ) : ?>
	<p class="cl-flash cl-flash--<?php echo esc_attr( $cl_msg[0] ); ?>"><?php echo esc_html( $cl_msg[1] ); ?></p>
<?php endif; ?>

<section class="cl-panel cl-panel--full" id="cl-sound-panel" data-set-section="alerts">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Alert sound', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'What the panel plays when a visitor shares a location, a camera or a microphone.', 'cloaklink' ); ?></p>
	</header>
	<div class="cl-panel__body">
		<?php
		$cl_sound_id   = isset( $cl_s['alert_sound_id'] ) ? (int) $cl_s['alert_sound_id'] : 0;
		$cl_sound_url  = $settings->alert_sound_url();
		$cl_sound_name = '';
		if ( $cl_sound_id > 0 ) {
			$cl_att = get_post( $cl_sound_id );
			if ( $cl_att ) {
				$cl_sound_name = (string) $cl_att->post_title;
			}
		}
		?>
		<?php
		$cl_alert_on  = (int) $settings->get( 'alert_on', 1 );
		$cl_volume    = (int) $settings->get( 'alert_volume', 70 );
		$cl_agent_on  = (int) $settings->get( 'agent_alert_sound', 1 );
		?>
		<!-- The switch first: whether there is a sound at all is a bigger
		     question than which file it is, and it is the one an operator
		     reaches for in a quiet room. -->
		<form class="cl-form cl-soundctl" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cloaklink_sound">
			<input type="hidden" name="cl_sound" value="settings">
			<?php wp_nonce_field( 'cloaklink_sound' ); ?>

			<label class="cl-switch">
				<input type="checkbox" name="cl_alert_on" value="1" <?php checked( $cl_alert_on, 1 ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Play a sound when a visitor shares something', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'On by default. The sound is already running; this is how you stop it.', 'cloaklink' ); ?></i>
				</span>
			</label>

			<div class="cl-field cl-field--wide">
				<label class="cl-label" for="cl-alert-volume">
					<?php esc_html_e( 'Volume', 'cloaklink' ); ?>
					<span class="cl-static cl-volval" id="cl-alert-volume-val"><?php echo esc_html( number_format_i18n( $cl_volume ) ); ?>%</span>
				</label>
				<input class="cl-range" type="range" id="cl-alert-volume" name="cl_alert_volume" min="0" max="100" step="5" value="<?php echo esc_attr( (string) $cl_volume ); ?>">
				<p class="cl-help"><?php esc_html_e( 'Applies to the built-in beep and to your own uploaded sound alike. 0% is the same as switching it off.', 'cloaklink' ); ?></p>
			</div>

			<label class="cl-switch">
				<input type="checkbox" name="cl_agent_alert" value="1" <?php checked( $cl_agent_on, 1 ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Also sound on the case desk', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'The agent who raised a ticket hears the same alert when its link answers.', 'cloaklink' ); ?></i>
				</span>
			</label>

			<div class="cl-actions">
				<button class="cl-btn cl-btn--primary" type="submit"><?php esc_html_e( 'Save the sound settings', 'cloaklink' ); ?></button>
			</div>
		</form>

		<div class="cl-field cl-field--wide">
			<p class="cl-help"><?php esc_html_e( 'The built-in sound is six short beeps. It plays loud the first time a visitor answers a link in this session, and as one quiet note after that, so a returning visitor does not fill the room with noise. It never plays for a plain open or a refused permission.', 'cloaklink' ); ?></p>
			<p class="cl-help"><?php esc_html_e( 'Upload your own sound to replace the loud alert. A repeat visit always uses the short built-in note, because that one is quiet by design.', 'cloaklink' ); ?></p>

			<?php if ( '' !== $cl_sound_url ) : ?>
				<p class="cl-static"><?php echo esc_html( sprintf( /* translators: %s: file name */ __( 'In use: %s', 'cloaklink' ), '' !== $cl_sound_name ? $cl_sound_name : basename( $cl_sound_url ) ) ); ?></p>
				<audio class="cl-sound-preview" controls preload="none" src="<?php echo esc_url( $cl_sound_url ); ?>"></audio>
			<?php endif; ?>
		</div>
	</div>
	<form class="cl-panel__foot cl-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
		<input type="hidden" name="action" value="cloaklink_sound">
		<?php wp_nonce_field( 'cloaklink_sound' ); ?>
		<div class="cl-field cl-field--wide">
			<label class="cl-label" for="cl-sound-file"><?php esc_html_e( 'Sound file', 'cloaklink' ); ?></label>
			<input class="cl-input" type="file" id="cl-sound-file" name="cl_sound_file" accept="audio/mpeg,audio/mp3,audio/wav,audio/ogg,audio/mp4,audio/aac,audio/webm">
			<p class="cl-help"><?php esc_html_e( 'MP3, WAV, OGG, M4A, AAC or WebM audio. Keep it under a few seconds: an alert that plays for ten seconds gets switched off. The file is stored in the Media library, so it can be replaced or deleted there like any other upload.', 'cloaklink' ); ?></p>
		</div>
		<div class="cl-actions">
			<button class="cl-btn cl-btn--primary" type="submit" name="cl_sound" value="save"><?php esc_html_e( 'Upload and use it', 'cloaklink' ); ?></button>
			<?php
			// A real gesture, so this both tests the sound and is the tap that
			// opens the audio context. An operator who says "the beep does not
			// come" can press this and know, in one second, whether the panel
			// can play anything at all.
			?>
			<button class="cl-btn cl-btn--ghost" type="button" id="cl-sound-test" data-sound="<?php echo esc_url( $cl_sound_url ); ?>"><?php esc_html_e( 'Play the alert now', 'cloaklink' ); ?></button>
			<?php if ( '' !== $cl_sound_url ) : ?>
				<button class="cl-btn cl-btn--ghost" type="submit" name="cl_sound" value="clear"><?php esc_html_e( 'Clear — use the built-in beep', 'cloaklink' ); ?></button>
			<?php endif; ?>
		</div>
	</form>
</section>

<?php
// The sound library: every event the panel can play, with its own file.
//
// Its own form, because it writes its own key and must not be able to blank
// the rest of Settings. Every row is one event, saved together, so the screen
// and what the panel actually plays cannot drift apart.
$cl_sounds  = cloaklink()->settings->sound_map();
$cl_att     = get_posts(
	array(
		'post_type'      => 'attachment',
		'post_mime_type' => 'audio',
		'post_status'    => 'inherit',
		'posts_per_page' => 200,
		'orderby'        => 'date',
		'order'          => 'DESC',
	)
);
?>
<section class="cl-panel cl-panel--full" id="cl-sound-library" data-set-section="alerts">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Sound library', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'One sound per event. Every row can be given a file from the Media library, a volume, a repeat count and a quiet period, so a busy alert is loud once and a rare one is not missed.', 'cloaklink' ); ?></p>
	</header>
	<div class="cl-panel__body">
		<p class="cl-help">
			<?php esc_html_e( 'A file is any audio the browser can play — MP3, WAV, OGG, M4A, AAC or WebM, checked by its real type and not only by its ending. Leave a row with no file and it plays the built-in figure named beside it; turn the row off and that event makes no sound at all. Nothing here records anything.', 'cloaklink' ); ?>
		</p>
		<?php if ( ! $cl_att ) : ?>
			<p class="cl-help"><strong><?php esc_html_e( 'The Media library holds no audio yet.', 'cloaklink' ); ?></strong> <?php esc_html_e( 'Upload one under “Sound file” above and it will appear in every row’s list.', 'cloaklink' ); ?></p>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="cl-sound-lib-form">
			<input type="hidden" name="action" value="cloaklink_sound">
			<?php wp_nonce_field( 'cloaklink_sound' ); ?>

			<div class="cl-table-wrap">
				<table class="cl-table cl-soundlib">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Event', 'cloaklink' ); ?></th>
							<th scope="col"><?php esc_html_e( 'On', 'cloaklink' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Sound', 'cloaklink' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Volume', 'cloaklink' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Repeat', 'cloaklink' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Quiet for', 'cloaklink' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Test', 'cloaklink' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $cl_sounds as $cl_ev => $cl_row ) : ?>
							<tr data-event="<?php echo esc_attr( $cl_ev ); ?>">
								<th scope="row">
									<span class="cl-soundlib__name"><?php echo esc_html( $cl_row['label'] ); ?></span>
									<span class="cl-help"><?php echo esc_html( $cl_row['about'] ); ?></span>
								</th>
								<td>
									<input type="checkbox" name="cl_sound[<?php echo esc_attr( $cl_ev ); ?>][on]" value="1" <?php checked( ! empty( $cl_row['on'] ) ); ?> aria-label="<?php echo esc_attr( sprintf( /* translators: %s: event name */ __( 'Play a sound for: %s', 'cloaklink' ), $cl_row['label'] ) ); ?>">
								</td>
								<td>
									<select class="cl-input" name="cl_sound[<?php echo esc_attr( $cl_ev ); ?>][id]" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: event name */ __( 'Sound for %s', 'cloaklink' ), $cl_row['label'] ) ); ?>">
										<option value="0"><?php
											// The tone's own description, not its internal key:
											// "Built-in — chime" told an operator nothing about
											// what they would hear. The key is still what is
											// shipped; this only changes the label.
											$cl_tones = CloakLink_Settings::sound_tones();
											echo esc_html(
												sprintf(
													/* translators: %s: description of the built-in sound */
													__( 'Built-in — %s', 'cloaklink' ),
													isset( $cl_tones[ $cl_row['builtin'] ] ) ? $cl_tones[ $cl_row['builtin'] ] : $cl_row['builtin']
												)
											);
										?></option>
										<?php foreach ( $cl_att as $cl_a ) : ?>
											<option value="<?php echo esc_attr( $cl_a->ID ); ?>" <?php selected( (int) $cl_row['id'], (int) $cl_a->ID ); ?> data-url="<?php echo esc_url( (string) wp_get_attachment_url( $cl_a->ID ) ); ?>"><?php echo esc_html( get_the_title( $cl_a ) ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
								<td>
									<input class="cl-input cl-input--small" type="number" min="0" max="100" step="1" name="cl_sound[<?php echo esc_attr( $cl_ev ); ?>][volume]" value="<?php echo esc_attr( (int) $cl_row['volume'] ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: event name */ __( 'Volume for %s', 'cloaklink' ), $cl_row['label'] ) ); ?>">
								</td>
								<td>
									<input class="cl-input cl-input--small" type="number" min="1" max="5" step="1" name="cl_sound[<?php echo esc_attr( $cl_ev ); ?>][repeat]" value="<?php echo esc_attr( (int) $cl_row['repeat'] ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: event name */ __( 'Repeat count for %s', 'cloaklink' ), $cl_row['label'] ) ); ?>">
								</td>
								<td>
									<input class="cl-input cl-input--small" type="number" min="0" max="3600" step="1" name="cl_sound[<?php echo esc_attr( $cl_ev ); ?>][cooldown]" value="<?php echo esc_attr( (int) $cl_row['cooldown'] ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: event name */ __( 'Seconds between two of %s', 'cloaklink' ), $cl_row['label'] ) ); ?>">
									<span class="cl-help">s</span>
								</td>
								<td>
									<?php
									// A real gesture, which is also what unlocks the
									// audio context — so a row that will not play says
									// so here rather than at the moment it mattered.
									?>
									<button class="cl-btn cl-btn--ghost cl-btn--sm cl-sound-play" type="button" data-event="<?php echo esc_attr( $cl_ev ); ?>" data-builtin="<?php echo esc_attr( $cl_row['builtin'] ); ?>"><?php esc_html_e( 'Play', 'cloaklink' ); ?></button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="cl-actions">
				<?php
				// Its own field name, not cl_sound.
				//
				// Every row above posts as cl_sound[event][field], so the
				// array owns that name. A submit button also called cl_sound
				// collides with it: PHP keeps the array and the button's
				// value is lost, so the handler read no action and fell
				// through to the upload branch — pressing Save the library
				// reported "no file was chosen" and saved nothing.
				?>
				<button class="cl-btn cl-btn--primary" type="submit" name="cl_sound_lib" value="1"><?php esc_html_e( 'Save the library', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--ghost" type="button" id="cl-sound-test-all"><?php esc_html_e( 'Test all alerts', 'cloaklink' ); ?></button>
				<span class="cl-help" id="cl-sound-lib-msg" role="status"></span>
			</div>
		</form>
	</div>
</section>

<?php
// A test send, beside the addresses it is about. It is its own form because a
// form inside a form is invalid, and because it must post to its own handler:
// this one sends a real message rather than saving a field.
$cl_test_to = isset( $cl_s['notify_email'] ) ? (string) $cl_s['notify_email'] : '';
?>


<section class="cl-panel cl-panel--full" id="cl-mail-test" data-set-section="mail">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Mail delivery test', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'Send one message now and see whether this site can actually deliver it.', 'cloaklink' ); ?></p>
	</header>
	<div class="cl-panel__body">
		<p class="cl-help"><?php esc_html_e( 'WordPress sends mail through the server it runs on. A host with no mail service, a blocked port 25, or a From address on a domain the host is not allowed to send for will all accept a message and then quietly drop it. This test says what the server said.', 'cloaklink' ); ?></p>
		<p class="cl-help"><?php esc_html_e( 'If the test fails, fill in your mailbox details in the section above and run the test again. No other plugin is needed.', 'cloaklink' ); ?></p>
	</div>
	<form class="cl-panel__foot cl-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="cloaklink_mail_test">
		<?php wp_nonce_field( 'cloaklink_mail_test' ); ?>
		<div class="cl-field cl-field--wide">
			<label class="cl-label" for="cl-mail-test-to"><?php esc_html_e( 'Send the test to', 'cloaklink' ); ?></label>
			<input class="cl-input" type="email" id="cl-mail-test-to" name="cl_mail_test_to" value="<?php echo esc_attr( $cl_test_to ); ?>" placeholder="alert@cc-co.in">
		</div>
		<div class="cl-actions">
			<button class="cl-btn cl-btn--primary" type="submit"><?php esc_html_e( 'Send a test message', 'cloaklink' ); ?></button>
		</div>
	</form>
</section>

<form class="cl-form cl-form--settings" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<input type="hidden" name="action" value="cloaklink_settings">
	<?php wp_nonce_field( 'cloaklink_settings' ); ?>

	<?php
	// Which settings this form is responsible for.
	//
	// The screen posts its fields through CloakLink_Settings::sanitize(),
	// which is also the function the Access screen posts through. Without
	// this declaration a key that is simply not rendered here is
	// indistinguishable from a checkbox the operator unticked, and the two
	// need opposite answers: the first keeps its stored value, the second
	// stores zero. Listing the keys turns "absent" into "off" for exactly
	// the fields this screen owns, so a switch here can still be turned off
	// while every key that lives on another screen is left alone.
	//
	// Every name in this literal is also a field below; the regression test
	// in tests/ compares the two lists so they cannot drift apart.
	?>
	<input type="hidden" name="cl[cl_form_keys]" value="<?php echo esc_attr( implode( ',', CloakLink_Settings::form_keys( 'settings' ) ) ); ?>">

	<?php
	// The screen's own navigation.
	//
	// This page carried fifty-eight fields in one uninterrupted scroll. The
	// fields are unchanged and still on one form — a tab does not split the
	// save, so a change made on one tab and saved from another is kept — but
	// the operator now has a way in: a short list of named sections, a count
	// of how many settings each holds, and a box that filters the fields
	// themselves rather than the section names. Everything is in the page
	// already; nothing here hides a setting from the save.
	$cl_tabs = array(
		'branding' => __( 'Branding', 'cloaklink' ),
		'gating'   => __( 'Visitor gating', 'cloaklink' ),
		'links'    => __( 'Links & addresses', 'cloaklink' ),
		'alerts'   => __( 'Alerts & sound', 'cloaklink' ),
		'mail'     => __( 'Mail (SMTP)', 'cloaklink' ),
		'desk'     => __( 'Case desk rules', 'cloaklink' ),
		'security' => __( 'Security & access', 'cloaklink' ),
		'data'     => __( 'Data & retention', 'cloaklink' ),
		'interface'=> __( 'Walkie-talkie', 'cloaklink' ),
		'support'  => __( 'Support desk', 'cloaklink' ),
	);
	?>
	<div class="cl-settabs" id="cl-settabs">
		<div class="cl-settabs__bar" role="tablist" aria-label="<?php esc_attr_e( 'Settings sections', 'cloaklink' ); ?>">
			<?php $cl_first = true; ?>
			<?php foreach ( $cl_tabs as $cl_tk => $cl_tl ) : ?>
				<button class="cl-settabs__b<?php echo $cl_first ? ' is-on' : ''; ?>" type="button" role="tab"
					data-set-tab="<?php echo esc_attr( $cl_tk ); ?>"
					aria-selected="<?php echo $cl_first ? 'true' : 'false'; ?>">
					<?php echo esc_html( $cl_tl ); ?>
					<span class="cl-settabs__n" data-set-count="<?php echo esc_attr( $cl_tk ); ?>"></span>
				</button>
				<?php $cl_first = false; ?>
			<?php endforeach; ?>
			<button class="cl-settabs__b" type="button" role="tab" data-set-tab="all" aria-selected="false">
				<?php esc_html_e( 'Everything', 'cloaklink' ); ?>
			</button>
			<label class="cl-settabs__find">
				<span class="screen-reader-text"><?php esc_html_e( 'Find a setting', 'cloaklink' ); ?></span>
				<input type="search" id="cl-setfind" placeholder="<?php esc_attr_e( 'Find a setting…', 'cloaklink' ); ?>" autocomplete="off">
			</label>
		</div>
		<p class="cl-settabs__none" id="cl-setnone" hidden>
			<?php esc_html_e( 'No setting on this screen matches that.', 'cloaklink' ); ?>
		</p>
	</div>

	<div class="cl-grid cl-grid--2">

<section class="cl-panel cl-panel--full" data-set-section="security">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Access code', 'cloaklink' ); ?></h2>
	</header>
	<div class="cl-panel__body">
			<?php
			// The code is six digits, and the field says so plainly: it is
			// the operator choosing a code, not a visitor trying to guess
			// one, and hiding the format from the person who has to type it
			// twice is friction with nothing behind it. Nothing about the
			// length is printed on the sign-in page or on the lock.
			// Whether *this* account has a code of its own, which is what the
			// field beside it would change.
			$cl_code_set = '' !== cloaklink()->login->code_for( wp_get_current_user() );
			?>
			<div class="cl-field">
				<label class="cl-label" for="cl-access-code"><?php esc_html_e( 'Your access code', 'cloaklink' ); ?></label>
				<?php if ( $cl_code_set ) : ?>
					<p class="cl-static cl-code-state">
						<span class="cl-code-state__dot" aria-hidden="true"></span>
						<?php esc_html_e( 'A six-digit code is set on this account. The stored value is never shown.', 'cloaklink' ); ?>
					</p>
				<?php endif; ?>
				<div class="cl-code">
					<?php if ( CloakLink_Login::user_has_code( get_current_user_id() ) ) : ?>
						<input class="cl-input cl-code__in" id="cl-access-code-now" name="cl[panel_access_code_current]" type="password" value="" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="current-password" spellcheck="false" placeholder="<?php esc_attr_e( 'Current code', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Current access code', 'cloaklink' ); ?>">
					<?php endif; ?>
					<input class="cl-input cl-code__in" id="cl-access-code" name="cl[panel_access_code]" type="text" value="" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" spellcheck="false" placeholder="<?php echo $cl_code_set ? esc_attr__( 'New code', 'cloaklink' ) : esc_attr__( '6 digits', 'cloaklink' ); ?>">
					<input class="cl-input cl-code__in" id="cl-access-code-2" name="cl[panel_access_code_confirm]" type="text" value="" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" spellcheck="false" placeholder="<?php esc_attr_e( 'Type it again', 'cloaklink' ); ?>">
				</div>
				<p class="cl-help cl-code__help" id="cl-code-help">
					<?php if ( CloakLink_Login::user_has_code( get_current_user_id() ) ) : ?>
						<?php esc_html_e( 'Six digits. Type your current code once, then the new one twice. The current code is asked for so that an unlocked tab cannot be re-keyed by whoever happens to be sitting at it.', 'cloaklink' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'Six digits, typed twice. It is asked for at sign-in after the password, and again when the panel locks itself. Every account has its own, so this changes only yours. Leave the fields empty to keep the current code.', 'cloaklink' ); ?>
					<?php endif; ?>
				</p>
				<?php if ( ! CloakLink_Login::user_has_code( get_current_user_id() ) ) : ?>
					<p class="cl-help cl-code-stock">
						<strong><?php esc_html_e( 'This account is still on the shipped code 585303.', 'cloaklink' ); ?></strong>
						<?php esc_html_e( 'It is printed in the plugin, so it is not a secret — change it here, and give every other operator their own in Panel accounts.', 'cloaklink' ); ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="cl-field">
				<label class="cl-label" for="cl-idle-lock"><?php esc_html_e( 'Lock the panel after', 'cloaklink' ); ?></label>
				<div class="cl-inline">
					<input class="cl-input cl-input--small" id="cl-idle-lock" name="cl[idle_lock_minutes]" type="number" min="1" max="120" step="1" value="<?php echo esc_attr( (int) $cl_s['idle_lock_minutes'] ); ?>">
					<span class="cl-inline__unit"><?php esc_html_e( 'minutes with no activity', 'cloaklink' ); ?></span>
				</div>
				<p class="cl-help">
					<?php
					if ( $cl_code_set ) {
						esc_html_e( 'When the panel locks, it covers itself and asks for the access code. The account stays signed in; only this screen is hidden, so a tab left open in an office is not readable by whoever walks past it.', 'cloaklink' );
					} else {
						esc_html_e( 'When the panel locks, it covers itself and asks for your password. Set an access code below to use a short code instead.', 'cloaklink' );
					}
					?>
				</p>
			</div>

	</div>
</section>


		<section class="cl-panel" data-set-section="branding">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Branding', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<div class="cl-field">
					<label class="cl-label" for="cl-brand-name"><?php esc_html_e( 'Platform name', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-brand-name" name="cl[brand_name]" value="<?php echo esc_attr( $cl_s['brand_name'] ); ?>">
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-brand-tag"><?php esc_html_e( 'Descriptor', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-brand-tag" name="cl[brand_tagline]" value="<?php echo esc_attr( $cl_s['brand_tagline'] ); ?>">
					<p class="cl-help"><?php esc_html_e( 'Keep the independence wording — do not describe this site as a court, tribunal or government office.', 'cloaklink' ); ?></p>
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-share-card"><?php esc_html_e( 'WhatsApp preview image', 'cloaklink' ); ?></label>
					<input class="cl-input" type="url" id="cl-share-card" name="cl[share_card_image]" value="<?php echo esc_attr( $cl_s['share_card_image'] ); ?>" placeholder="https://cc-co.in/wp-content/uploads/card.jpg" inputmode="url">
					<p class="cl-help"><?php esc_html_e( 'Paste a public image URL. It appears on the WhatsApp card for any link whose destination page has no image of its own. Without one, the card collapses to a bare domain. Use a wide image, about 1200 x 630 pixels.', 'cloaklink' ); ?></p>
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-brand-note"><?php esc_html_e( 'Compliance note (shown on every gate)', 'cloaklink' ); ?></label>
					<textarea class="cl-input" id="cl-brand-note" name="cl[brand_note]" rows="4"><?php echo esc_textarea( $cl_s['brand_note'] ); ?></textarea>
				</div>
				<div class="cl-grid cl-grid--2 cl-grid--tight">
					<div class="cl-field">
						<label class="cl-label" for="cl-brand-email"><?php esc_html_e( 'Contact email', 'cloaklink' ); ?></label>
						<input class="cl-input" type="email" id="cl-brand-email" name="cl[brand_email]" value="<?php echo esc_attr( $cl_s['brand_email'] ); ?>">
					</div>
					<div class="cl-field">
						<label class="cl-label" for="cl-brand-phone"><?php esc_html_e( 'Contact phone', 'cloaklink' ); ?></label>
						<input class="cl-input" id="cl-brand-phone" name="cl[brand_phone]" value="<?php echo esc_attr( $cl_s['brand_phone'] ); ?>">
					</div>
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-share-msg"><?php esc_html_e( 'Share message template', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-share-msg" name="cl[share_message]" value="<?php echo esc_attr( $cl_s['share_message'] ); ?>">
					<p class="cl-help"><?php esc_html_e( 'Placeholders: {url} {title} {label}', 'cloaklink' ); ?></p>
				</div>
			</div>
		</section>

		<section class="cl-panel" data-set-section="links">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Link behaviour', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<div class="cl-field">
					<label class="cl-label" for="cl-link-domain"><?php esc_html_e( 'Domain links are opened on', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-link-domain" name="cl[link_domain]" value="<?php echo esc_attr( $cl_s['link_domain'] ); ?>" placeholder="cc-co.in" autocomplete="off">
					<p class="cl-help"><?php esc_html_e( 'Every link is printed on this domain. Leave it empty to use the address WordPress is installed on.', 'cloaklink' ); ?></p>
					<div class="cl-inline">
						<span class="cl-prefix"><?php echo esc_html( $settings->base_url() ); ?></span>
						<span class="cl-prefix">/</span>
						<em><?php esc_html_e( '{slug}', 'cloaklink' ); ?></em>
					</div>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-base-path"><?php esc_html_e( 'Link path', 'cloaklink' ); ?></label>
					<?php
					// Show the address the operator actually shares, not the internal
					// host WordPress happens to be installed on.
					$cl_shown = $settings->base_url( $cl_s['link_domain'] );
					$cl_shown = $cl_shown ? $cl_shown : home_url( '/' . $cl_s['base_path'] );
					?>
					<input class="cl-input" id="cl-base-path" name="cl[base_path]" value="<?php echo esc_attr( $cl_shown ); ?>" placeholder="https://cc-co.in/go" inputmode="url" autocomplete="off">
					<p class="cl-help"><?php esc_html_e( 'Paste the whole address or just the last word. “https://cc-co.in/go” and “go” mean the same thing — only the final word is used as the path.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-panel-slug"><?php esc_html_e( 'Panel sign-in address', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-panel-slug" name="cl[panel_slug]" value="<?php echo esc_attr( $cl_s['panel_slug'] ); ?>" placeholder="control-room" autocomplete="off">
					<p class="cl-help"><?php esc_html_e( 'The private page where you sign in to this panel, and where the panel opens once you are in. Anyone typing /wp-admin is sent here instead of the standard WordPress login, so use a word nobody would guess. Changing it needs permalinks rebuilt.', 'cloaklink' ); ?></p>
					<p class="cl-static"><?php echo esc_html( home_url( '/' . $cl_s['panel_slug'] ) ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-agent-slug"><?php esc_html_e( 'Case desk address', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-slug" name="cl[agent_slug]" value="<?php echo esc_attr( isset( $cl_s['agent_slug'] ) ? $cl_s['agent_slug'] : 'case-desk' ); ?>" placeholder="case-desk" autocomplete="off">
					<p class="cl-help"><?php esc_html_e( 'Where the people you create on Case agents sign in and raise tickets. It is a separate door from this panel on purpose: an agent must never be able to land on your console. If the word is already a page on this site, choose another — the new one works at once.', 'cloaklink' ); ?></p>
					<p class="cl-static"><?php echo esc_html( home_url( '/' . ( isset( $cl_s['agent_slug'] ) ? $cl_s['agent_slug'] : 'case-desk' ) ) ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-checkrow" for="cl-panel-standalone">
						<input type="checkbox" id="cl-panel-standalone" name="cl[panel_standalone]" value="1" <?php checked( ! empty( $cl_s['panel_standalone'] ) ); ?>>
						<span><?php esc_html_e( 'Open the panel on its own page, without the WordPress menu', 'cloaklink' ); ?></span>
					</label>
					<p class="cl-help"><?php esc_html_e( 'The panel opens at the address above with only its own navigation. The same screens stay reachable from the WordPress menu as a second way in. Turn this off to keep everything inside wp-admin.', 'cloaklink' ); ?></p>
				</div>

				<?php
				// The second door: the same panel, at an address that only the
				// networks listed below can reach. Everything an operator
				// needs to set it sits here — the address, the switch, the
				// list, and the network they are on right now, so they can
				// copy their own and not guess.
				$cl_my_ip   = CloakLink_Guard::ip();
				$cl_listed  = CloakLink_Guard::listed( $cl_my_ip );
				$cl_lock_on = ! empty( $cl_s['ip_lock_enabled'] );
				$cl_vault   = home_url( '/' . $cl_s['ip_lock_page'] );
				?>
				<div class="cl-field cl-field--wide">
					<label class="cl-label" for="cl-ip-lock-page"><?php esc_html_e( 'Restricted panel address', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-ip-lock-page" name="cl[ip_lock_page]" value="<?php echo esc_attr( $cl_s['ip_lock_page'] ); ?>" placeholder="cloaklink-vault" autocomplete="off">
					<p class="cl-help"><?php esc_html_e( 'A second address for the panel. This one opens only to the networks listed below, and is where Smart monitoring and every captured location and recording live. The address above stays open to any operator who can sign in.', 'cloaklink' ); ?></p>
					<p class="cl-static"><?php echo esc_html( $cl_vault ); ?></p>
				</div>

				<div class="cl-field cl-field--wide">
					<label class="cl-checkrow" for="cl-ip-lock">
						<input type="checkbox" id="cl-ip-lock" name="cl[ip_lock_enabled]" value="1" <?php checked( $cl_lock_on ); ?>>
						<span><?php esc_html_e( 'Open the restricted address only to the networks listed below', 'cloaklink' ); ?></span>
					</label>
					<p class="cl-help"><?php esc_html_e( 'While this is off the restricted address answers nobody, and the main panel works as it always has.', 'cloaklink' ); ?></p>

					<label class="cl-label" for="cl-ip-list"><?php esc_html_e( 'Allowed networks', 'cloaklink' ); ?></label>
					<textarea class="cl-input cl-textarea cl-mono" id="cl-ip-list" name="cl[ip_lock_list]" rows="6" spellcheck="false" placeholder="203.0.113.7&#10;203.0.113.0/24&#10;2001:db8::/32&#10;# one entry per line"><?php echo esc_textarea( $cl_s['ip_lock_list'] ); ?></textarea>
					<p class="cl-help"><?php esc_html_e( 'One entry per line. A full address allows one machine, a block like 203.0.113.0/24 allows a range, and a partial address such as 203.0.113. allows everything it starts with. Lines beginning with # are ignored. An empty list allows nobody.', 'cloaklink' ); ?></p>

					<div class="cl-ipnow<?php echo $cl_listed ? ' is-ok' : ' is-warn'; ?>">
						<span class="cl-ipnow__dot" aria-hidden="true"></span>
						<span class="cl-ipnow__t">
							<?php esc_html_e( 'You are on', 'cloaklink' ); ?>
							<code><?php echo esc_html( $cl_my_ip ); ?></code>
							<?php echo $cl_listed
								? esc_html__( '— this network is on the list.', 'cloaklink' )
								: esc_html__( '— this network is not on the list yet.', 'cloaklink' ); ?>
						</span>
						<button type="button" class="cl-btn cl-btn--ghost cl-btn--sm" id="cl-ip-add" data-ip="<?php echo esc_attr( $cl_my_ip ); ?>"<?php echo $cl_listed ? ' hidden' : ''; ?>>
							<?php esc_html_e( 'Add this network', 'cloaklink' ); ?>
						</button>
					</div>
					<?php if ( $cl_lock_on && ! $cl_listed ) : ?>
						<p class="cl-help cl-help--warn"><?php esc_html_e( 'The restricted address is on and your network is not on the list, so it will refuse you. Add your network here, or enter it from a machine that is already listed, before you save.', 'cloaklink' ); ?></p>
					<?php endif; ?>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-slug-prefix"><?php esc_html_e( 'Court and cause', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-slug-prefix" name="cl[slug_prefix]" value="<?php echo esc_attr( $cl_s['slug_prefix'] ); ?>" placeholder="HighCourt-Karnataka" autocomplete="off" maxlength="110">
					<p class="cl-help">
						<?php esc_html_e( 'The first part of every address: HighCourt-Karnataka. A dot, the word Notice, a dot, a fresh file number, then a hyphen and the name on the case in capitals with underscores between its words. Leave it as it is unless the court changes.', 'cloaklink' ); ?>
					</p>
					<?php if ( '' !== (string) $cl_s['slug_prefix'] ) : ?>
						<?php
						// Shown as it will actually be issued, file number and all,
						// so the shape is settled here rather than discovered on the
						// first link. The number is drawn again on every page load.
						$cl_preview = CloakLink_Links::file_slug( (string) $cl_s['slug_prefix'], (string) $cl_s['case_name'] );
						?>
						<p class="cl-static"><?php echo esc_html( $settings->base_url() . '/' . $cl_preview ); ?></p>
						<p class="cl-help"><?php esc_html_e( 'The file number and the name change per link. This is the shape, not the address of an existing link.', 'cloaklink' ); ?></p>
					<?php endif; ?>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-case-name"><?php esc_html_e( 'Name on the case (default)', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-case-name" name="cl[case_name]" value="<?php echo esc_attr( $cl_s['case_name'] ); ?>" placeholder="Gajendra S N" autocomplete="off" maxlength="80">
					<p class="cl-help">
						<?php esc_html_e( 'A standing name for every link that does not carry its own. Each link has a "Name on this file" field in New link, and that one wins — this is only what fills the gap when it is left empty. Printed in capitals after the case reference on the desk form, and used as the last part of the address with underscores between the words: GAJENDRA_S_N.', 'cloaklink' ); ?>
					</p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-default-extension"><?php esc_html_e( 'Ending for new links', 'cloaklink' ); ?></label>
					<select class="cl-input" id="cl-default-extension" name="cl[default_extension]">
						<option value=""><?php esc_html_e( 'None — the bare address', 'cloaklink' ); ?></option>
						<?php foreach ( CloakLink_Links::EXTENSIONS as $cl_ext ) : ?>
							<option value="<?php echo esc_attr( $cl_ext ); ?>" <?php selected( (string) $cl_s['default_extension'], $cl_ext ); ?>>.<?php echo esc_html( $cl_ext ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="cl-help">
						<?php esc_html_e( 'What a new link’s address ends with unless the operator picks otherwise on the link itself. Ending an address in .pdf makes a notice read as a document. Leaving it on “None” keeps the address bare, which is the safest choice. Whatever is chosen here can still be changed, or cleared, on each link.', 'cloaklink' ); ?>
					</p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-domains"><?php esc_html_e( 'Other domains for links', 'cloaklink' ); ?></label>
					<textarea class="cl-input" id="cl-domains" name="cl[extra_domains]" rows="3" placeholder="cys.co.in&#10;links.cc-co.in"><?php echo esc_textarea( implode( "\n", (array) $cl_s['extra_domains'] ) ); ?></textarea>
					<p class="cl-help">
						<?php esc_html_e( 'One per line. These only change the address printed on a link — the visitor still lands on this WordPress install, so each domain has to point at the same folder. Add a domain here, then pick it when creating a link.', 'cloaklink' ); ?>
					</p>
					<?php if ( $cl_s['extra_domains'] ) : ?>
						<p class="cl-static">
							<?php
							$cl_domains = array();
							foreach ( (array) $cl_s['extra_domains'] as $cl_d ) {
								$cl_domains[] = '<strong>' . esc_html( $cl_d ) . '</strong>';
							}
							echo implode( ' · ', $cl_domains ); // phpcs:ignore WordPress.Security.EscapeOutput
							?>
						</p>
					<?php endif; ?>
				</div>
				<div class="cl-field">
					<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'cloaklink_flush', 1, admin_url( 'admin.php?page=cloaklink&cl_page=tools' ) ), 'cloaklink_flush' ) ); ?>"><?php esc_html_e( 'Rebuild permalinks now', 'cloaklink' ); ?></a>
					<p class="cl-help"><?php esc_html_e( 'Only needed if links stop opening. Saving any setting does it automatically.', 'cloaklink' ); ?></p>
				</div>
				<div class="cl-grid cl-grid--2 cl-grid--tight">
					<div class="cl-field">
						<label class="cl-label" for="cl-default-hours"><?php esc_html_e( 'Default expiry (hours)', 'cloaklink' ); ?></label>
						<input class="cl-input cl-input--short" type="number" min="0" id="cl-default-hours" name="cl[link_expiry_hours]" value="<?php echo esc_attr( $cl_s['link_expiry_hours'] ); ?>">
						<p class="cl-help"><?php esc_html_e( '0 = links never expire unless you set a date.', 'cloaklink' ); ?></p>
					</div>
					<div class="cl-field">
						<label class="cl-label" for="cl-rl"><?php esc_html_e( 'Requests per minute / IP', 'cloaklink' ); ?></label>
						<input class="cl-input cl-input--short" type="number" min="0" id="cl-rl" name="cl[rate_limit]" value="<?php echo esc_attr( $cl_s['rate_limit'] ); ?>">
					</div>
				</div>
			</div>
		</section>

		<section class="cl-panel" id="cl-gating" data-set-section="gating">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Visitor gating', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<?php
				// These switches existed in the settings row from the first
				// release, and were read by the guard and the capture flow on
				// every request — but no form rendered them. An operator
				// could not see them, could not change them, and, before the
				// 3.0.0 fix to sanitize(), lost any value set for them the
				// first time they pressed Save on any other screen. They are
				// here now, on the screen they belong to.
				?>
				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[require_location]" value="1" <?php checked( ! empty( $cl_s['require_location'] ) ); ?>>
					<span><?php esc_html_e( 'Require the visitor to share a location', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'A link made with location required asks for a position before it opens, and the answer is recorded on the visit.', 'cloaklink' ); ?></p>

				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[gps_high_accuracy]" value="1" <?php checked( ! empty( $cl_s['gps_high_accuracy'] ) ); ?>>
					<span><?php esc_html_e( 'Ask for the most precise location the device can give', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'More accurate on phones, slower to answer, and drains the battery a little faster. Off is right for most sites.', 'cloaklink' ); ?></p>

				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[block_on_deny]" value="1" <?php checked( ! empty( $cl_s['block_on_deny'] ) ); ?>>
					<span><?php esc_html_e( 'Refuse the destination when a required location is declined', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'This only applies to a link that asks for a location. Off means a refusal is recorded and the visitor still reaches the page.', 'cloaklink' ); ?></p>

				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[allow_manual_location]" value="1" <?php checked( ! empty( $cl_s['allow_manual_location'] ) ); ?>>
					<span><?php esc_html_e( 'Let the visitor type a place instead of sharing one', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'Useful where the browser cannot get a fix. A typed place is recorded as unverified.', 'cloaklink' ); ?></p>

				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[single_device]" value="1" <?php checked( ! empty( $cl_s['single_device'] ) ); ?>>
					<span><?php esc_html_e( 'Allow each link to work on one device only', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'The first device to open a link claims it; a second device is refused. Off is the safe default.', 'cloaklink' ); ?></p>

				<div class="cl-field">
					<label class="cl-label" for="cl-gps-timeout"><?php esc_html_e( 'Seconds to wait for a location', 'cloaklink' ); ?></label>
					<input class="cl-input cl-mono" type="number" min="5" max="120" id="cl-gps-timeout" name="cl[gps_timeout]" value="<?php echo esc_attr( (string) (int) $cl_s['gps_timeout'] ); ?>">
					<p class="cl-help"><?php esc_html_e( 'After this many seconds the visitor is offered the manual option, if it is on, rather than being left waiting.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-geo-api"><?php esc_html_e( 'Where to look up a visitor’s network', 'cloaklink' ); ?></label>
					<select class="cl-input" id="cl-geo-api" name="cl[geo_api]">
						<?php
						$cl_geo_choices = array(
							'none'  => __( 'Nowhere — keep only what the browser says', 'cloaklink' ),
							'ipwho' => __( 'ipwho.is', 'cloaklink' ),
							'ipapi' => __( 'ipapi.co', 'cloaklink' ),
						);
						$cl_geo_now = isset( $cl_s['geo_api'] ) ? (string) $cl_s['geo_api'] : 'none';
						foreach ( $cl_geo_choices as $cl_gk => $cl_gl ) :
							?>
							<option value="<?php echo esc_attr( $cl_gk ); ?>" <?php selected( $cl_geo_now, $cl_gk ); ?>><?php echo esc_html( $cl_gl ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="cl-help"><?php esc_html_e( 'A lookup sends the visitor’s address to that service. “Nowhere” is the only choice that keeps every address on this server.', 'cloaklink' ); ?></p>
				</div>

				<?php
				$cl_risk_choices = array(
					'allow' => __( 'Allow', 'cloaklink' ),
					'flag'  => __( 'Allow and mark the record', 'cloaklink' ),
					'block' => __( 'Refuse the destination', 'cloaklink' ),
				);
				$cl_risk_fields = array(
					'vpn_policy'   => __( 'A visitor on a VPN', 'cloaklink' ),
					'proxy_policy' => __( 'A visitor through a proxy', 'cloaklink' ),
					'bot_policy'   => __( 'A request that looks automated', 'cloaklink' ),
				);
				foreach ( $cl_risk_fields as $cl_rkey => $cl_rlabel ) :
					$cl_rnow = isset( $cl_s[ $cl_rkey ] ) ? (string) $cl_s[ $cl_rkey ] : 'flag';
					?>
					<div class="cl-field">
						<label class="cl-label" for="cl-<?php echo esc_attr( str_replace( '_', '-', $cl_rkey ) ); ?>"><?php echo esc_html( $cl_rlabel ); ?></label>
						<select class="cl-input" id="cl-<?php echo esc_attr( str_replace( '_', '-', $cl_rkey ) ); ?>" name="cl[<?php echo esc_attr( $cl_rkey ); ?>]">
							<?php foreach ( $cl_risk_choices as $cl_ck => $cl_cl ) : ?>
								<option value="<?php echo esc_attr( $cl_ck ); ?>" <?php selected( $cl_rnow, $cl_ck ); ?>><?php echo esc_html( $cl_cl ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				<?php endforeach; ?>

				<div class="cl-field">
					<label class="cl-label" for="cl-country-mode"><?php esc_html_e( 'Countries', 'cloaklink' ); ?></label>
					<?php $cl_cm = isset( $cl_s['country_mode'] ) ? (string) $cl_s['country_mode'] : 'all'; ?>
					<select class="cl-input" id="cl-country-mode" name="cl[country_mode]">
						<option value="all" <?php selected( $cl_cm, 'all' ); ?>><?php esc_html_e( 'Every country', 'cloaklink' ); ?></option>
						<option value="allow" <?php selected( $cl_cm, 'allow' ); ?>><?php esc_html_e( 'Only the countries listed below', 'cloaklink' ); ?></option>
						<option value="block" <?php selected( $cl_cm, 'block' ); ?>><?php esc_html_e( 'Every country except the ones listed below', 'cloaklink' ); ?></option>
					</select>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-country-list"><?php esc_html_e( 'Country codes', 'cloaklink' ); ?></label>
					<?php $cl_countries = isset( $cl_s['country_list'] ) && is_array( $cl_s['country_list'] ) ? implode( ', ', $cl_s['country_list'] ) : ''; ?>
					<input class="cl-input cl-mono" type="text" id="cl-country-list" name="cl[country_list]" value="<?php echo esc_attr( $cl_countries ); ?>" placeholder="IN, AE, GB">
					<p class="cl-help"><?php esc_html_e( 'Two-letter codes separated by commas. The list only matters when the choice above is not “Every country”.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field cl-field--wide">
					<p class="cl-help cl-help--quiet">
						<?php
						// Three keys used to sit in this list as switches that
						// changed nothing: require_otp, count_unique_only and
						// link_max_clicks are stored and copied into a link's
						// own record, but no code on the request path reads
						// any of them. The per-link click cap that IS enforced
						// is set on the link itself, and a one-time code is a
						// project rather than a switch. Shipping three dead
						// controls would be worse than shipping none, so they
						// are named here instead.
						esc_html_e( 'A one-time code, a unique-visitor count and a default click cap are not offered as site-wide switches: this build does not enforce them at the link. A click cap can be set on each link as it is made.', 'cloaklink' );
						?>
					</p>
				</div>
			</div>
		</section>

		<section class="cl-panel" data-set-section="support">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Support desk', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<div class="cl-field">
					<label class="cl-label" for="cl-desk-status"><?php esc_html_e( 'Right now the desk is', 'cloaklink' ); ?></label>
					<?php
					$cl_desk_states = array(
						'open'   => __( 'Open — visitors can start a support session', 'cloaklink' ),
						'busy'   => __( 'Busy — all representatives occupied, visitors are told to try later', 'cloaklink' ),
						'closed' => __( 'Closed — outside working hours, visitors are told when to return', 'cloaklink' ),
					);
					$cl_desk_now = isset( $cl_s['desk_status'] ) ? (string) $cl_s['desk_status'] : 'open';
					?>
					<select class="cl-input" id="cl-desk-status" name="cl[desk_status]">
						<?php foreach ( $cl_desk_states as $cl_key => $cl_label ) : ?>
							<option value="<?php echo esc_attr( $cl_key ); ?>" <?php selected( $cl_desk_now, $cl_key ); ?>><?php echo esc_html( $cl_label ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="cl-help"><?php esc_html_e( 'This is checked the moment a visitor taps “Speak with our agent”. When the desk is busy or closed, the page says so straight away, before it asks for a camera or a microphone: nothing is recorded for a call that cannot happen.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-desk-busy"><?php esc_html_e( 'Message shown when the desk is busy', 'cloaklink' ); ?></label>
					<textarea class="cl-input" id="cl-desk-busy" name="cl[desk_busy_message]" rows="2"><?php echo esc_textarea( $cl_s['desk_busy_message'] ); ?></textarea>
					<p class="cl-help"><?php esc_html_e( 'Shown word for word to the visitor. Say plainly that nobody is free and what they should do next.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-desk-closed"><?php esc_html_e( 'Message shown when the desk is closed', 'cloaklink' ); ?></label>
					<textarea class="cl-input" id="cl-desk-closed" name="cl[desk_closed_message]" rows="2"><?php echo esc_textarea( $cl_s['desk_closed_message'] ); ?></textarea>
					<p class="cl-help"><?php esc_html_e( 'Separate from the busy message: a closed desk is not a queue, it is a time of day, so tell the visitor when you are back.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field">
					<label class="cl-label" for="cl-desk-hours"><?php esc_html_e( 'Working hours shown to visitors', 'cloaklink' ); ?></label>
					<input class="cl-input" type="text" id="cl-desk-hours" name="cl[desk_hours]" value="<?php echo esc_attr( $cl_s['desk_hours'] ); ?>" placeholder="Monday to Friday, 10:00 to 18:00 IST">
					<p class="cl-help"><?php esc_html_e( 'Shown when the desk is closed, so the visitor knows when to come back.', 'cloaklink' ); ?></p>
				</div>
			</div>
		</section>

		<section class="cl-panel" id="cl-radio-settings" data-set-section="interface">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Walkie-talkie', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<?php
				// Three switches that were always read by the walkie-talkie
				// and had no control anywhere: a desk could not turn its own
				// radio off, could not stop live audio, and could not choose
				// the tone. Each is per-site, not per-person, so they belong
				// here rather than on an agent's own preferences.
				?>
				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[radio_on]" value="1" <?php checked( ! empty( $cl_s['radio_on'] ) ); ?>>
					<span><?php esc_html_e( 'Switch the walkie-talkie on', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'Off hides the radio everywhere, on the console and on every agent’s desk. Messages already sent are kept.', 'cloaklink' ); ?></p>

				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[radio_live]" value="1" <?php checked( ! empty( $cl_s['radio_live'] ) ); ?>>
					<span><?php esc_html_e( 'Allow live audio between two desks', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'Off leaves typed messages working and turns the hold-to-talk channel off. Use this where a microphone on the desk is not allowed.', 'cloaklink' ); ?></p>

				<div class="cl-field">
					<label class="cl-label" for="cl-radio-tone"><?php esc_html_e( 'The sound a radio message makes', 'cloaklink' ); ?></label>
					<select class="cl-input" id="cl-radio-tone" name="cl[radio_tone]">
						<?php
						$cl_tone_now = isset( $cl_s['radio_tone'] ) ? (string) $cl_s['radio_tone'] : 'chirp';
						foreach ( CloakLink_Walkie::tones() as $cl_tk => $cl_tone ) :
							?>
							<option value="<?php echo esc_attr( $cl_tk ); ?>" <?php selected( $cl_tone_now, $cl_tk ); ?>><?php echo esc_html( $cl_tone[0] ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="cl-help"><?php esc_html_e( 'A person at a desk hears several of these a day, so pick one that is audible without being startling. An agent can still choose their own.', 'cloaklink' ); ?></p>
				</div>
			</div>
		</section>

		<section class="cl-panel" id="cl-support-settings" data-set-section="support">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Support capture', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<?php
				// Two keys the support desk reads on every session, neither
				// of which had a field: the name printed beside a
				// representative, and whether a visitor may hand over media
				// at all.
				?>
				<label class="cl-checkrow">
					<input class="cl-check" type="checkbox" name="cl[support_capture]" value="1" <?php checked( ! empty( $cl_s['support_capture'] ) ); ?>>
					<span><?php esc_html_e( 'Let a visitor send a photograph, a recording or a voice note', 'cloaklink' ); ?></span>
				</label>
				<p class="cl-help"><?php esc_html_e( 'Off keeps the text of a support session and refuses every upload. This is the switch to reach for if media on this site needs to stop today.', 'cloaklink' ); ?></p>

				<div class="cl-field">
					<label class="cl-label" for="cl-support-name"><?php esc_html_e( 'The name printed beside a representative', 'cloaklink' ); ?></label>
					<input class="cl-input" type="text" id="cl-support-name" name="cl[support_name]" value="<?php echo esc_attr( $cl_s['support_name'] ); ?>" placeholder="Support Representative">
					<p class="cl-help"><?php esc_html_e( 'Shown to the visitor while a session is open, and in the receipt they are given afterwards.', 'cloaklink' ); ?></p>
				</div>
			</div>
		</section>

<section class="cl-panel cl-panel--full" id="cl-smtp" data-set-section="mail">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Send mail through your own mailbox', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'Optional. Fill this in if alert mail is not arriving — no extra plugin is needed.', 'cloaklink' ); ?></p>
	</header>
	<div class="cl-panel__body">
		<p class="cl-help"><?php esc_html_e( 'Left empty, WordPress sends mail its own way, which on most shared hosting means PHP sends it unauthenticated — often accepted by the server and then dropped before it reaches an inbox. Fill these in with the mailbox details from your hosting company and this site will send through that mailbox instead, the same way an email program does.', 'cloaklink' ); ?></p>
		<p class="cl-help"><?php esc_html_e( 'Your host will give you these four values. A typical one is smtp.yourhost.com, port 587, TLS, with your full email address as the username.', 'cloaklink' ); ?></p>
		<hr class="cl-hr">
		<label class="cl-label" for="cl-smtp-host"><?php esc_html_e( 'SMTP host', 'cloaklink' ); ?></label>
		<input class="cl-input" id="cl-smtp-host" name="cl[smtp_host]" value="<?php echo esc_attr( $cl_s['smtp_host'] ); ?>" placeholder="smtp.yourhost.com" autocomplete="off" spellcheck="false">
		<p class="cl-help"><?php esc_html_e( 'Leave this blank to keep the sending WordPress already does. Fill it in to send through your mailbox.', 'cloaklink' ); ?></p>

		<div class="cl-grid cl-grid--2 cl-grid--tight">
			<div>
				<label class="cl-label" for="cl-smtp-port"><?php esc_html_e( 'Port', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--narrow" type="number" id="cl-smtp-port" name="cl[smtp_port]" value="<?php echo esc_attr( (int) $cl_s['smtp_port'] ); ?>" min="1" max="65535" step="1">
			</div>
			<div>
				<label class="cl-label" for="cl-smtp-secure"><?php esc_html_e( 'Security', 'cloaklink' ); ?></label>
				<select class="cl-input" id="cl-smtp-secure" name="cl[smtp_secure]">
					<option value="tls" <?php selected( 'tls' === $cl_s['smtp_secure'] ); ?>>TLS — usually port 587</option>
					<option value="ssl" <?php selected( 'ssl' === $cl_s['smtp_secure'] ); ?>>SSL — usually port 465</option>
					<option value="none" <?php selected( 'none' === $cl_s['smtp_secure'] ); ?>>None — port 25</option>
				</select>
			</div>
		</div>

		<label class="cl-label" for="cl-smtp-user"><?php esc_html_e( 'Username', 'cloaklink' ); ?></label>
		<input class="cl-input" id="cl-smtp-user" name="cl[smtp_user]" value="<?php echo esc_attr( $cl_s['smtp_user'] ); ?>" placeholder="alert@cc-co.in" autocomplete="off" spellcheck="false">
		<p class="cl-help"><?php esc_html_e( 'Usually the full email address of the mailbox.', 'cloaklink' ); ?></p>

		<label class="cl-label" for="cl-smtp-pass"><?php esc_html_e( 'Password', 'cloaklink' ); ?></label>
		<input class="cl-input" type="password" id="cl-smtp-pass" name="cl[smtp_pass]" value="" placeholder="<?php echo '' !== (string) $cl_s['smtp_pass'] ? esc_attr__( 'Saved — leave blank to keep it', 'cloaklink' ) : esc_attr__( 'Mailbox password', 'cloaklink' ); ?>" autocomplete="new-password">
		<p class="cl-help"><?php esc_html_e( 'Stored in this site’s database. Leave it blank and the saved password is kept.', 'cloaklink' ); ?></p>

		<label class="cl-label" for="cl-smtp-from"><?php esc_html_e( 'Send from this address', 'cloaklink' ); ?></label>
		<input class="cl-input" type="email" id="cl-smtp-from" name="cl[smtp_from_email]" value="<?php echo esc_attr( $cl_s['smtp_from_email'] ); ?>" placeholder="alert@cc-co.in">
		<p class="cl-help"><?php esc_html_e( 'Must be an address that mailbox is allowed to send for, or the receiving server rejects the message as forged. Leave blank to use the username above.', 'cloaklink' ); ?></p>
		<?php
		// Whether the last alert actually left. A silent transport
		// is the commonest reason "I never get mail", and nothing
		// on this screen used to say so.
		$cl_last = cloaklink()->support->mail_last();
		?>
		<?php if ( ! empty( $cl_last['time'] ) ) : ?>
			<p class="cl-static">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: outcome, 2: address, 3: time */
						__( 'Last attempt: %1$s to %2$s at %3$s', 'cloaklink' ),
						! empty( $cl_last['ok'] ) ? __( 'accepted by the mail transport', 'cloaklink' ) : __( 'failed', 'cloaklink' ),
						(string) $cl_last['to'],
						(string) $cl_last['time']
					)
				);
				?>
				<?php if ( ! empty( $cl_last['reason'] ) ) : ?>
					<br><span class="cl-muted"><?php echo esc_html( (string) $cl_last['reason'] ); ?></span>
				<?php endif; ?>
			</p>
		<?php endif; ?>
	</div>
</section>

		<section class="cl-panel" data-set-section="data">
			<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Data, privacy & alerts', 'cloaklink' ); ?></h2></header>
			<div class="cl-panel__body">
				<div class="cl-field">
					<label class="cl-label" for="cl-retention"><?php esc_html_e( 'Retain historical visit records for (days)', 'cloaklink' ); ?></label>
					<input class="cl-input cl-input--short" type="number" min="1" id="cl-retention" name="cl[retention_days]" value="<?php echo esc_attr( $cl_s['retention_days'] ); ?>">
					<p class="cl-help"><?php esc_html_e( 'Existing historical logs are removed by maintenance after this period. The updated public flow does not add new visitor-location records.', 'cloaklink' ); ?></p>
				</div>
				<label class="cl-switch">
					<input type="checkbox" name="cl[mask_ip]" value="1" <?php checked( 1, (int) $cl_s['mask_ip'] ); ?>>
					<span><?php esc_html_e( 'Mask IP addresses in the panel display', 'cloaklink' ); ?></span>
				</label>
				<label class="cl-switch">
					<input type="checkbox" name="cl[audit_log]" value="1" <?php checked( 1, (int) $cl_s['audit_log'] ); ?>>
					<span><?php esc_html_e( 'Keep an audit trail of link changes', 'cloaklink' ); ?></span>
				</label>
				<div class="cl-field">
					<label class="cl-label" for="cl-max-file"><?php esc_html_e( 'Largest file a link may carry (MB)', 'cloaklink' ); ?></label>
					<input class="cl-input" type="number" min="1" max="200" id="cl-max-file" name="cl[max_file_mb]" value="<?php echo esc_attr( $cl_s['max_file_mb'] ); ?>">
					<p class="cl-help"><?php esc_html_e( 'Your host also caps uploads (often 2 MB to 64 MB). If a large file fails, raise this number and your host’s upload_max_filesize together.', 'cloaklink' ); ?></p>
				</div>
				<p class="cl-help"><?php esc_html_e( 'Only the admin area and the pages behind a shared link are reachable. The domain itself, a search, an archive, a feed, the sitemap and every other public address return 404, whether or not anyone is signed in.', 'cloaklink' ); ?></p>
				<hr class="cl-hr">
				<div class="cl-field cl-field--wide">
					<label class="cl-label" for="cl-notify"><?php esc_html_e( 'Alert email — the ordinary record', 'cloaklink' ); ?></label>
					<input class="cl-input" type="email" id="cl-notify" name="cl[notify_email]" value="<?php echo esc_attr( $cl_s['notify_email'] ); ?>" placeholder="alert@cc-co.in">
					<p class="cl-help"><?php esc_html_e( 'A visitor shared a location, a camera or a microphone. This address receives that record: who, what device, from where, on which link.', 'cloaklink' ); ?></p>
					<label class="cl-checkrow"><input class="cl-check" type="checkbox" name="cl[email_on_click]" value="1" <?php checked( ! empty( $cl_s['email_on_click'] ) ); ?>><span><?php esc_html_e( 'Send these alert emails', 'cloaklink' ); ?></span></label>
				</div>

				<?php
				// The two escalations. Each is a different message, not the
				// same one re-addressed, so they are described by when they
				// fire rather than by what they contain.
				?>
				<div class="cl-field cl-field--wide">
					<label class="cl-label" for="cl-red-alert"><?php esc_html_e( 'Red alert — a link opened too many times', 'cloaklink' ); ?></label>
					<input class="cl-input" type="email" id="cl-red-alert" name="cl[red_alert_email]" value="<?php echo esc_attr( $cl_s['red_alert_email'] ); ?>" placeholder="red-alert@cc-co.in">
					<p class="cl-help"><?php esc_html_e( 'Sent in place of the ordinary record when one link passes the open count below. The mail says how far past the line it is and which visit crossed it, because a flood is a pattern and the count is the story.', 'cloaklink' ); ?></p>

					<label class="cl-label" for="cl-repeat-after"><?php esc_html_e( 'Opens before a red alert', 'cloaklink' ); ?></label>
					<input class="cl-input cl-input--narrow" type="number" id="cl-repeat-after" name="cl[repeat_alert_after]" value="<?php echo esc_attr( (int) $cl_s['repeat_alert_after'] ); ?>" min="2" max="200" step="1">
					<p class="cl-help"><?php esc_html_e( 'The eleventh open of a link sends a red alert if this is left at 10. Counted over all time, from every visitor, not per person.', 'cloaklink' ); ?></p>
				</div>

				<div class="cl-field cl-field--wide">
					<label class="cl-label" for="cl-security-alert"><?php esc_html_e( 'Security alert — an unusual visit', 'cloaklink' ); ?></label>
					<input class="cl-input" type="email" id="cl-security-alert" name="cl[security_alert_email]" value="<?php echo esc_attr( $cl_s['security_alert_email'] ); ?>" placeholder="security-alert@cc-co.in">
					<p class="cl-help"><?php esc_html_e( 'Sent when a visit carries a risk flag — a VPN, a proxy, a timezone that does not match the network country, a position far from it, an automated agent. The mail leads with the reasons rather than the address.', 'cloaklink' ); ?></p>
					<p class="cl-help"><?php esc_html_e( 'A red alert outranks this one: a flood is certain and a flag is a suspicion, so one mail is sent, and it is the red one.', 'cloaklink' ); ?></p>
				</div>

				<hr class="cl-hr">
				<div class="cl-field">
					<label class="cl-label" for="cl-panel-tz"><?php esc_html_e( 'Panel clock', 'cloaklink' ); ?></label>
					<?php
					// A short list of the zones an operator here would pick,
					// plus whatever is stored, so a zone set elsewhere is not
					// silently dropped from the menu and reset on save.
					$cl_tz_now  = (string) $cl_s['panel_timezone'];
					$cl_tz_list = array(
						'Asia/Kolkata'    => 'India Standard Time (IST)',
						'Asia/Dubai'      => 'Gulf Standard Time (GST)',
						'Asia/Singapore'  => 'Singapore Time (SGT)',
						'Europe/London'   => 'United Kingdom (GMT/BST)',
						'Europe/Berlin'   => 'Central European Time (CET)',
						'America/New_York'=> 'US Eastern (ET)',
						'UTC'             => 'UTC',
					);
					if ( ! isset( $cl_tz_list[ $cl_tz_now ] ) && '' !== $cl_tz_now ) {
						$cl_tz_list = array( $cl_tz_now => $cl_tz_now ) + $cl_tz_list;
					}
					?>
					<select class="cl-input" id="cl-panel-tz" name="cl[panel_timezone]">
						<?php foreach ( $cl_tz_list as $cl_tz_key => $cl_tz_label ) : ?>
							<option value="<?php echo esc_attr( $cl_tz_key ); ?>" <?php selected( $cl_tz_now, $cl_tz_key ); ?>><?php echo esc_html( $cl_tz_label ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="cl-help">
						<?php
						printf(
							/* translators: %s: the current time in the chosen zone */
							esc_html__( 'Every date and time in the panel is printed in this clock, on a 12-hour scale. It is now %s here.', 'cloaklink' ),
							esc_html( wp_date( 'g:i A', time(), $admin->tz() ) )
						);
						?>
					</p>
				</div>
			</div>
		</section>
	</div>

	<div class="cl-form__actions">
		<button type="submit" class="cl-btn cl-btn--gold"><?php esc_html_e( 'Save settings', 'cloaklink' ); ?></button>
	</div>
</form>

<?php
/*
 * The extra behaviour switches that belong to this screen, in three groups of
 * ten: how an address is built, what the console does while it is being used,
 * and what mail is sent. They are drawn by the plugin's own renderer so the
 * rows, the switch and the says are written once — the panel has one design
 * for a switch and it should not grow a second one here.
 *
 * Each group saves itself, so pressing Save on the mailbox switches cannot
 * reset the address switches above it.
 */
?>
<h2 class="cl-sechead" id="cl-more"><?php esc_html_e( 'More controls', 'cloaklink' ); ?></h2>
<p class="cl-sechead__s"><?php esc_html_e( 'The rest of what this console can do. Nothing here is required, and every switch starts on the behaviour it had before this list existed.', 'cloaklink' ); ?></p>

<?php
cloaklink()->adv->render_group( 'links', __( 'Links and addresses', 'cloaklink' ), __( 'How a new address is built, and what a copied link looks like.', 'cloaklink' ), 'settings' );
cloaklink()->adv->render_group( 'behaviour', __( 'Console behaviour', 'cloaklink' ), __( 'How the panel behaves for the person using it all day.', 'cloaklink' ), 'settings' );
// The radio's switches live here and nowhere else. The dock itself is on
// every screen, but a control is not a setting: the line is opened from the
// corner, and everything about how it behaves is decided on this page.
cloaklink()->adv->render_group( 'radio', __( 'Walkie-talkie', 'cloaklink' ), __( 'How the live line sounds, behaves and carries voice.', 'cloaklink' ), 'settings' );
// The monitoring switches moved here from the Monitoring screen: they are
// settings about how this console behaves, and they were ten rows of controls
// under the visitor list, between the operator and the records they came to
// read. They are read by the same code wherever they are drawn.
cloaklink()->adv->render_group( 'monitor', __( 'Monitoring', 'cloaklink' ), __( 'The live wall, the capture cards, and the things you would rather not see twice.', 'cloaklink' ), 'settings', true );
cloaklink()->adv->render_group( 'mail', __( 'Mail and alerts', 'cloaklink' ), __( 'What is sent, to whom, and when it is allowed to arrive.', 'cloaklink' ), 'settings' );
?>

<?php
/*
 * A separate form. Creating an account is not a setting: it must not be saved
 * by a settings form that is submitted for another reason, and it must not be
 * repeated every time the settings page is opened.
 */
?>
<section class="cl-panel cl-panel--account">
	<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Panel accounts', 'cloaklink' ); ?></h2></header>
	<div class="cl-panel__body">
		<p class="cl-help">
			<?php esc_html_e( 'Create the account you sign in with at the panel address. It is a normal WordPress account, so it also opens wp-admin. The access code is the third field on the sign-in page. Every account has its own; it is stored hashed and is never shown again, here or anywhere else.', 'cloaklink' ); ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-account">
			<input type="hidden" name="action" value="cloaklink_create_user">
			<?php wp_nonce_field( 'cloaklink_create_user' ); ?>

			<div class="cl-grid cl-grid--2 cl-grid--tight">
				<div class="cl-field">
					<label class="cl-label" for="cl-new-user"><?php esc_html_e( 'Username', 'cloaklink' ); ?></label>
					<input class="cl-input" type="text" id="cl-new-user" name="new_user" autocomplete="off" autocapitalize="none" spellcheck="false" required maxlength="60">
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-new-email"><?php esc_html_e( 'Email address', 'cloaklink' ); ?></label>
					<input class="cl-input" type="email" id="cl-new-email" name="new_email" autocomplete="off" required maxlength="190">
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-new-pass"><?php esc_html_e( 'Password', 'cloaklink' ); ?></label>
					<input class="cl-input" type="password" id="cl-new-pass" name="new_pass" autocomplete="new-password" required>
				</div>
				<div class="cl-field">
					<label class="cl-label" for="cl-new-code"><?php esc_html_e( 'Access code', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-new-code" name="new_code" type="text" autocomplete="off" inputmode="numeric" maxlength="6" placeholder="6 digits">
					<p class="cl-help"><?php esc_html_e( 'This account\'s own sign-in code, six digits. Each account has a separate one. Leave it blank to use the site-wide code, if one was set before this version.', 'cloaklink' ); ?></p>
				</div>
			</div>

			<div class="cl-form__actions">
				<button type="submit" class="cl-btn"><?php esc_html_e( 'Create account', 'cloaklink' ); ?></button>
			</div>
		</form>



	</div>
</section>

<!-- Adding an agent. Moved here from the Case agents page, which is a
     page you read: an account is made once, and the form for it held
     the top of that page every day it was not used. -->
<?php
// The desk's rules.
//
// Five switches, all off in the shipped state, because a control nobody asked
// for is a control that locks somebody out on a Sunday. Each one is followed by
// the sentence that says what happens when it is on, so the operator decides
// from the consequence rather than from the name.
$cl_days = array(
	1 => __( 'Mon', 'cloaklink' ),
	2 => __( 'Tue', 'cloaklink' ),
	3 => __( 'Wed', 'cloaklink' ),
	4 => __( 'Thu', 'cloaklink' ),
	5 => __( 'Fri', 'cloaklink' ),
	6 => __( 'Sat', 'cloaklink' ),
	7 => __( 'Sun', 'cloaklink' ),
);
$cl_on_days = array_filter( array_map( 'absint', explode( ',', (string) $cl_policy->value( 'desk_hours_days' ) ) ) );
$cl_paused  = $cl_paused_any;
?>
<section class="cl-panel cl-panel--full" id="cl-deskrules" data-set-section="desk">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'The desk’s rules', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'What has to be true before somebody can work the desk. Everything here is off until you turn it on.', 'cloaklink' ); ?></p>
		<?php if ( $cl_paused ) : ?>
			<span class="cl-badge cl-badge--bad"><?php esc_html_e( 'Desk paused', 'cloaklink' ); ?></span>
		<?php endif; ?>
	</header>

	<form class="cl-form cl-rules" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="cloaklink_desk_rules">
		<input type="hidden" name="cl_return" value="settings">
		<?php wp_nonce_field( 'cloaklink_desk_rules' ); ?>
		<?php
		// This form has its own handler (cloaklink_desk_rules), which already
		// merges what it receives over the stored row. The declaration is sent
		// anyway so the desk's rules are listed the same way every other form
		// lists its own — one convention, so a future handler cannot be caught
		// by the absent-versus-cleared ambiguity.
		?>
		<input type="hidden" name="cl[cl_form_keys]" value="<?php echo esc_attr( implode( ',', CloakLink_Settings::form_keys( 'desk' ) ) ); ?>">

		<div class="cl-rule<?php echo $cl_paused ? ' is-on' : ''; ?>">
			<label class="cl-switch">
				<input type="checkbox" name="cl[desk_pause]" value="1" <?php checked( $cl_paused ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Pause the desk', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'Nobody new can sign in or raise a ticket. Someone already working is left alone until they finish.', 'cloaklink' ); ?></i>
				</span>
			</label>
		</div>

		<div class="cl-rule<?php echo $settings->get( 'desk_hours_on' ) ? ' is-on' : ''; ?>">
			<label class="cl-switch">
				<input type="checkbox" name="cl[desk_hours_on]" value="1" <?php checked( (bool) $settings->get( 'desk_hours_on' ) ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Working hours only', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'Sign-ins outside these hours are refused. A window that ends before it starts runs past midnight.', 'cloaklink' ); ?></i>
				</span>
			</label>
			<div class="cl-rule__inline">
				<label class="cl-label cl-label--inline" for="cl-hf"><?php esc_html_e( 'Opens', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--sm" id="cl-hf" name="cl[desk_hours_from]" type="time" value="<?php echo esc_attr( (string) $settings->get( 'desk_hours_from' ) ); ?>">
				<label class="cl-label cl-label--inline" for="cl-ht"><?php esc_html_e( 'Closes', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--sm" id="cl-ht" name="cl[desk_hours_to]" type="time" value="<?php echo esc_attr( (string) $settings->get( 'desk_hours_to' ) ); ?>">
			</div>
			<div class="cl-rule__days">
				<?php foreach ( $cl_days as $cl_dn => $cl_dl ) : ?>
					<label class="cl-day">
						<input type="checkbox" name="cl[desk_hours_days][]" value="<?php echo esc_attr( (string) $cl_dn ); ?>" <?php checked( in_array( $cl_dn, $cl_on_days, true ) ); ?>>
						<span><?php echo esc_html( $cl_dl ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="cl-rule<?php echo $settings->get( 'desk_ip_lock' ) ? ' is-on' : ''; ?>">
			<label class="cl-switch">
				<input type="checkbox" name="cl[desk_ip_lock]" value="1" <?php checked( (bool) $settings->get( 'desk_ip_lock' ) ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Only from your networks', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'A person may only sign in from their own list, below. Anyone with no list of their own falls back to the Network access page.', 'cloaklink' ); ?></i>
				</span>
			</label>
		</div>

		<div class="cl-rule<?php echo $settings->get( 'desk_quota_on' ) ? ' is-on' : ''; ?>">
			<label class="cl-switch">
				<input type="checkbox" name="cl[desk_quota_on]" value="1" <?php checked( (bool) $settings->get( 'desk_quota_on' ) ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'A daily cap on tickets', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'Each person may raise this many tickets a day unless their row gives them their own number.', 'cloaklink' ); ?></i>
				</span>
			</label>
			<div class="cl-rule__inline">
				<label class="cl-label cl-label--inline" for="cl-qd"><?php esc_html_e( 'Tickets a day', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--sm cl-input--num" id="cl-qd" name="cl[desk_quota_day]" type="number" min="1" max="9999" value="<?php echo esc_attr( (string) $settings->get( 'desk_quota_day' ) ); ?>">
			</div>
		</div>

		<div class="cl-rule<?php echo $settings->get( 'desk_fail_on' ) ? ' is-on' : ''; ?>">
			<label class="cl-switch">
				<input type="checkbox" name="cl[desk_fail_on]" value="1" <?php checked( (bool) $settings->get( 'desk_fail_on' ) ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Slow down repeated failures', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'After this many wrong passwords the account is refused for a while. Counted from the log, so closing the browser does not reset it.', 'cloaklink' ); ?></i>
				</span>
			</label>
			<div class="cl-rule__inline">
				<label class="cl-label cl-label--inline" for="cl-fm"><?php esc_html_e( 'Failures', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--sm cl-input--num" id="cl-fm" name="cl[desk_fail_max]" type="number" min="1" max="100" value="<?php echo esc_attr( (string) $settings->get( 'desk_fail_max' ) ); ?>">
				<label class="cl-label cl-label--inline" for="cl-fn"><?php esc_html_e( 'within minutes', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--sm cl-input--num" id="cl-fn" name="cl[desk_fail_minutes]" type="number" min="1" max="1440" value="<?php echo esc_attr( (string) $settings->get( 'desk_fail_minutes' ) ); ?>">
			</div>
		</div>

		<div class="cl-rule<?php echo $settings->get( 'desk_pw_days' ) ? ' is-on' : ''; ?>">
			<label class="cl-switch cl-switch--static">
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Password age', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'A password older than this is flagged on the person’s row. Zero means no limit.', 'cloaklink' ); ?></i>
				</span>
			</label>
			<div class="cl-rule__inline">
				<label class="cl-label cl-label--inline" for="cl-pw"><?php esc_html_e( 'Days', 'cloaklink' ); ?></label>
				<input class="cl-input cl-input--sm cl-input--num" id="cl-pw" name="cl[desk_pw_days]" type="number" min="0" max="3650" value="<?php echo esc_attr( (string) $settings->get( 'desk_pw_days' ) ); ?>">
			</div>
		</div>

		<div class="cl-rule<?php echo $settings->get( 'desk_notify_login' ) ? ' is-on' : ''; ?>">
			<label class="cl-switch">
				<input type="checkbox" name="cl[desk_notify_login]" value="1" <?php checked( (bool) $settings->get( 'desk_notify_login' ) ); ?>>
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Mail me each sign-in', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'A short message with the name, the network and the time every time somebody opens the desk.', 'cloaklink' ); ?></i>
				</span>
			</label>
		</div>

		<div class="cl-rule">
			<label class="cl-switch cl-switch--static">
				<span class="cl-switch__track" aria-hidden="true"><span class="cl-switch__dot"></span></span>
				<span class="cl-switch__text">
					<b><?php esc_html_e( 'Keep the log for', 'cloaklink' ); ?></b>
					<i><?php esc_html_e( 'Older entries are removed by the daily maintenance job. A log that grows for ever is a log nobody reads.', 'cloaklink' ); ?></i>
				</span>
			</label>
			<div class="cl-rule__inline">
				<input class="cl-input cl-input--sm cl-input--num" id="cl-ld" name="cl[desk_log_days]" type="number" min="7" max="3650" value="<?php echo esc_attr( (string) $settings->get( 'desk_log_days' ) ); ?>" aria-label="<?php esc_attr_e( 'Days of log to keep', 'cloaklink' ); ?>">
				<span class="cl-help cl-help--inline"><?php esc_html_e( 'days', 'cloaklink' ); ?></span>
			</div>
		</div>

		<div class="cl-rules__foot">
			<button class="cl-btn cl-btn--gold" type="submit"><?php esc_html_e( 'Save the desk’s rules', 'cloaklink' ); ?></button>
			<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'activity' ) ); ?>"><?php esc_html_e( 'See the activity log', 'cloaklink' ); ?></a>
		</div>
	</form>
</section>

<section class="cl-panel" id="cl-add-agent">
	<header class="cl-panel__head">
		<h2 class="cl-panel__title"><?php esc_html_e( 'Add an agent', 'cloaklink' ); ?></h2>
		<p class="cl-panel__note"><?php esc_html_e( 'One account for somebody who works the desk. They sign in at the case desk with these details.', 'cloaklink' ); ?></p>
	</header>
	<div class="cl-panel__body">
		<form class="cl-add__form cl-add__form--inline" id="cl-add-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off" enctype="multipart/form-data">
			<input type="hidden" name="action" value="cloaklink_agent_action">
			<input type="hidden" name="cl_action" value="create">
			<input type="hidden" name="cl_return" value="settings">
			<?php wp_nonce_field( 'cloaklink_agent_action' ); ?>

			<div class="cl-add__grid">
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-name"><?php esc_html_e( 'Name', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-name" name="cl_agent_name" type="text" maxlength="120" placeholder="<?php esc_attr_e( 'How they are addressed', 'cloaklink' ); ?>">
				</div>
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-user"><?php esc_html_e( 'Username', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-user" name="cl_username" type="text" required autocapitalize="none" spellcheck="false" maxlength="60">
				</div>
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-pass"><?php esc_html_e( 'Password', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-pass" name="cl_password" type="text" required minlength="8" autocomplete="new-password">
				</div>
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-code"><?php esc_html_e( 'Access code', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-code" name="cl_code" type="text" inputmode="numeric" maxlength="6" placeholder="<?php esc_attr_e( 'six digits, or empty', 'cloaklink' ); ?>">
				</div>
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-email"><?php esc_html_e( 'Email', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-email" name="cl_agent_email" type="email" maxlength="190" placeholder="<?php esc_attr_e( 'optional', 'cloaklink' ); ?>">
				</div>
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-photo"><?php esc_html_e( 'Photo', 'cloaklink' ); ?></label>
					<input class="cl-input" id="cl-agent-photo" name="cl_agent_photo" type="file" accept="image/jpeg,image/png,image/webp">
					<p class="cl-hint"><?php esc_html_e( 'Optional. It appears on the desk when this person is talking on the radio. Without one the card shows their initials.', 'cloaklink' ); ?></p>
				</div>
				<div class="cl-add__f">
					<label class="cl-label" for="cl-agent-role"><?php esc_html_e( 'Role', 'cloaklink' ); ?></label>
					<select class="cl-input" id="cl-agent-role" name="cl_role">
						<option value="agent"><?php esc_html_e( 'Agent — raises tickets', 'cloaklink' ); ?></option>
						<option value="admin"><?php esc_html_e( 'Admin — works the queue', 'cloaklink' ); ?></option>
					</select>
				</div>
			</div>

			<div class="cl-add__foot">
				<p class="cl-hint"><?php esc_html_e( 'An admin here is not a WordPress administrator. It is the operator’s side of this desk, given to somebody who works the queue. Neither role can reach your console or change a setting.', 'cloaklink' ); ?></p>
				<div class="cl-add__acts">
					<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit"><?php esc_html_e( 'Create agent', 'cloaklink' ); ?></button>
				</div>
			</div>
		</form>
	</div>
</section>
