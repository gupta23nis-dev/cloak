<?php
/**
 * Smart monitoring: support requests, device detail and captured media.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification
$cl_status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
// One search box over the name, mobile and email a visitor typed.
$cl_search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$cl_swiped = isset( $_GET['cl_support'] ) ? sanitize_key( wp_unslash( $_GET['cl_support'] ) ) : '';
// phpcs:enable WordPress.Security.NonceVerification

$cl_support = cloaklink()->support;
$cl_stats   = $cl_support->stats();
// Arriving from the Links list names one link; the whole panel then shows
// that link alone, so a click from the link row lands on the right cards.
$cl_link_focus = isset( $_GET['link'] ) ? absint( $_GET['link'] ) : 0;

/**
 * Turn a date typed or picked in the panel into YYYY-MM-DD, or nothing.
 *
 * Anything else is discarded: a bad date must never narrow the list to
 * nothing, because an empty panel looks like lost data.
 *
 * @param string $raw Raw query value.
 * @return string
 */
$cl_day = function ( $raw ) {
	$raw = trim( (string) $raw );
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $raw, $m ) ) {
		return '';
	}
	return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $raw : '';
};
$cl_from = $cl_day( isset( $_GET['from'] ) ? wp_unslash( $_GET['from'] ) : '' );
$cl_to   = $cl_day( isset( $_GET['to'] ) ? wp_unslash( $_GET['to'] ) : '' );

// The panel prints every timestamp in one fixed zone (IST by default), and
// the day headings have to agree with it. Reading "today" off the server's
// UTC clock made a session from 11pm IST fall under tomorrow's heading.
$cl_today    = wp_date( 'Y-m-d', time(), $admin->tz() );
$cl_yday     = wp_date( 'Y-m-d', strtotime( $cl_today . ' -1 day' ), $admin->tz() );
$cl_date_key = isset( $_GET['when'] ) ? sanitize_key( wp_unslash( $_GET['when'] ) ) : '';
if ( '' === $cl_date_key && '' === $cl_from && '' === $cl_to && isset( $_GET['from'] ) ) {
	$cl_date_key = '';
}
if ( 'today' === $cl_date_key ) {
	$cl_from = $cl_today;
	$cl_to   = $cl_today;
} elseif ( 'yesterday' === $cl_date_key ) {
	$cl_from = $cl_yday;
	$cl_to   = $cl_yday;
} elseif ( 'week' === $cl_date_key ) {
	$cl_from = gmdate( 'Y-m-d', strtotime( $cl_today . ' -6 days' ) );
	$cl_to   = $cl_today;
} elseif ( 'all' === $cl_date_key ) {
	$cl_from = '';
	$cl_to   = '';
}
if ( 'all' !== $cl_date_key && '' !== $cl_from && '' === $cl_to ) {
	$cl_to = $cl_today;
}

// The captured wall has its own quick windows and its own switch: a card
// taken off the wall is archived, not deleted, and the operator has to be
// able to see the archived ones to put one back.
$cl_recent = isset( $_GET['recent'] ) ? absint( $_GET['recent'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$cl_show   = isset( $_GET['show'] ) ? sanitize_key( wp_unslash( $_GET['show'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification
if ( ! in_array( $cl_show, array( 'all', 'kept', 'archived' ), true ) ) {
	$cl_show = 'all';
}
$cl_capnote = isset( $_GET['cl_capture'] ) ? sanitize_key( wp_unslash( $_GET['cl_capture'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

// The wall can be read newest-first or grouped by visitor. Same records,
// two questions: "what just happened" and "who came, and what did they give".
$cl_group = isset( $_GET['group'] ) ? sanitize_key( wp_unslash( $_GET['group'] ) ) : 'time'; // phpcs:ignore WordPress.Security.NonceVerification
if ( ! in_array( $cl_group, array( 'time', 'person' ), true ) ) {
	$cl_group = 'time';
}

$cl_span   = array( 'from' => $cl_from, 'to' => $cl_to, 'link_id' => $cl_link_focus );
$cl_rows   = $cl_support->sessions(
	array(
		'per_page' => 500,
		'status'   => $cl_status,
		'link_id'  => $cl_link_focus,
		'from'     => $cl_from,
		'to'       => $cl_to,
		'search'   => $cl_search,
	)
);
$cl_summary = $cl_support->link_summary( $cl_span );

// Visitors who handed something over without ever opening a session.
//
// The wall at the top of this page draws every captured visit, but the list
// below it is made of support sessions — and a visitor who simply allows the
// location prompt on a link never opens one. They were recorded, counted in
// the tiles, shown on the wall, and then absent from the list the operator
// actually works through. This is that missing set, drawn as the same cards
// the wall uses so the two cannot read as different kinds of record.
$cl_walkins     = array();
$cl_walkin_seen = array();
if ( empty( $cl_status ) || 'walkin' === $cl_status ) {
	$cl_seen_keys = array();
	foreach ( $cl_rows as $cl_r ) {
		$cl_seen_keys[ (int) $cl_r['link_id'] . '|' . (string) $cl_r['ip_hash'] ] = true;
	}
	foreach (
		$cl_db->captured_visits(
			array(
				'link_id' => $cl_link_focus,
				'from'    => $cl_from,
				'to'      => $cl_to,
				'max'     => 60,
				'show'    => 'all',
			)
		) as $cl_w
	) {
		$cl_key = (int) $cl_w['link_id'] . '|' . (string) $cl_w['ip_hash'];
		if ( isset( $cl_seen_keys[ $cl_key ] ) ) {
			continue;
		}

		// One box per visitor, holding everything that visitor gave.
		//
		// The list at the top of this page is the per-click view and it stays
		// that way: every click, newest first, some lines and a mark each.
		// This section is the other view — the *person* — so four clicks by
		// one visitor become one box with all four answers merged onto it.
		// Showing four near-identical boxes here is what made the section look
		// like a duplicate of the list above it rather than the summary of it.
		//
		// The permissions are unioned, and the newest row supplies the place,
		// the device and the coordinates: a visitor who allowed the camera on
		// one click and the microphone on the next has both marks on one card,
		// which is the answer a person actually wants from this section.
		if ( ! isset( $cl_walkins[ $cl_key ] ) ) {
			$cl_walkins[ $cl_key ] = array(
				'row'   => $cl_w,
				'count' => 0,
				'grant' => array(),
			);
		}
		$cl_walkins[ $cl_key ]['count']++;
		$cl_cap_w = $cl_db->capture_of( $cl_w );
		foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $cl_k_w ) {
			if ( ! empty( $cl_cap_w[ $cl_k_w ] ) ) {
				$cl_walkins[ $cl_key ]['grant'][ $cl_k_w ] = true;
			}
		}
		// Which click speaks for the visitor. A row whose detail was cleared
		// has no place, device or coordinates, so it must never be the one a
		// box is drawn from while an earlier click still holds the answer —
		// that is what made a box look empty when the visitor had given
		// everything.
		$cl_wold    = $cl_walkins[ $cl_key ]['row'];
		$cl_wold_ok = empty( $cl_wold['extra'] ) || false === strpos( (string) $cl_wold['extra'], '"removed"' );
		$cl_wnew_ok = empty( $cl_w['extra'] ) || false === strpos( (string) $cl_w['extra'], '"removed"' );
		$cl_wfix    = '' !== (string) $cl_w['lat'] && '' !== (string) $cl_w['lng'];

		if ( ( $cl_wnew_ok && ! $cl_wold_ok )
			|| ( $cl_wnew_ok === $cl_wold_ok && (int) $cl_w['id'] > (int) $cl_wold['id'] )
			|| ( $cl_wnew_ok === $cl_wold_ok && $cl_wfix && ( '' === (string) $cl_wold['lat'] || '' === (string) $cl_wold['lng'] ) ) ) {
			$cl_walkins[ $cl_key ]['row'] = $cl_w;
		}
	}
	$cl_walkins = array_values( $cl_walkins );
}

// Every link, so a card can say which link brought the visitor in. The
// session rows only carry an id, and an id means nothing to a reader.
$cl_link_names = array();
foreach ( $cl_db->get_links( array( 'per_page' => 200 ) ) as $cl_l ) {
	$cl_nm = trim( (string) $cl_l['title'] );
	if ( '' === $cl_nm ) {
		$cl_nm = $cl_l['slug'];
	}
	$cl_link_names[ (int) $cl_l['id'] ] = array(
		'name'  => $cl_nm,
		'slug'  => (string) $cl_l['slug'],
		'type'  => (string) $cl_l['link_type'],
		'label' => trim( (string) $cl_l['label'] ),
	);
}

// The list is grouped by link: same people come in on the same link, so a
// heading per link turns a wall of cards into a set of short, named lists.
$cl_groups = array();
foreach ( $cl_rows as $cl_r ) {
	$cl_groups[ (int) $cl_r['link_id'] ][] = $cl_r;
}
uksort(
	$cl_groups,
	function ( $a, $b ) use ( $cl_summary ) {
		$la = isset( $cl_summary[ $a ]['last'] ) ? $cl_summary[ $a ]['last'] : '';
		$lb = isset( $cl_summary[ $b ]['last'] ) ? $cl_summary[ $b ]['last'] : '';
		return strcmp( $lb, $la );
	}
);
$cl_keep    = (int) CloakLink_Support::MEDIA_DAYS;
$cl_s       = $settings->all();

/**
 * Map a session row to a Google Maps link.
 *
 * @param array $row Session row.
 * @return string
 */
$cl_map_link = function ( $row ) {
	if ( '' === (string) $row['lat'] || '' === (string) $row['lng'] ) {
		return '';
	}
	return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $row['lat'] . ',' . $row['lng'] );
};

/**
 * Signed URL for a captured file.
 *
 * @param int    $id    Session id.
 * @param string $which 'audio', 'video' or 'photo'.
 * @param int    $index Photo index.
 * @return string
 */
$cl_media_url = function ( $id, $which, $index = 0, $download = false ) {
	$args = array(
		'cloaklink_media' => 1,
		'session'         => (int) $id,
		'file'            => $which,
	);
	if ( 'photo' === $which ) {
		$args['n'] = (int) $index;
	}
	if ( $download ) {
		$args['dl'] = 1;
	}
	return wp_nonce_url( add_query_arg( $args, CloakLink_Admin::admin_base() ), 'cloaklink_media' );
};
?>

<?php if ( 'deleted' === $cl_swiped || 'none' === $cl_swiped ) : ?>
	<?php
	$cl_dn     = isset( $_GET['cl_count'] ) ? max( 0, (int) $_GET['cl_count'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$cl_dasked = isset( $_GET['cl_asked'] ) ? max( 0, (int) $_GET['cl_asked'] ) : $cl_dn; // phpcs:ignore WordPress.Security.NonceVerification
	$cl_dmiss  = max( 0, $cl_dasked - $cl_dn );
	?>
	<?php if ( $cl_dn ) : ?>
		<div class="cl-flash cl-flash--ok">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of sessions deleted */
					_n(
						'%d session deleted, with every file it captured.',
						'%d sessions deleted, with every file they captured.',
						$cl_dn,
						'cloaklink'
					),
					$cl_dn
				)
			);
			?>
			<?php if ( $cl_dmiss ) : ?>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: number already gone, 2: number selected */
						__( '%1$d of the %2$d selected had already gone.', 'cloaklink' ),
						$cl_dmiss,
						$cl_dasked
					)
				);
				?>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="cl-flash cl-flash--bad">
			<?php
			echo esc_html(
				$cl_dasked
					? sprintf(
						/* translators: %d: number selected */
						_n(
							'Nothing was deleted: the %d selected session is no longer there. The list below is the current one.',
							'Nothing was deleted: none of the %d selected sessions are there any more. The list below is the current one.',
							$cl_dasked,
							'cloaklink'
						),
						$cl_dasked
					)
					: __( 'Nothing was deleted. Tick at least one session and press Delete selected again.', 'cloaklink' )
			);
			?>
		</div>
	<?php endif; ?>
<?php elseif ( 'wiped' === $cl_swiped ) : ?>
	<div class="cl-flash cl-flash--ok">
		<?php
		$cl_wn = isset( $_GET['cl_count'] ) ? max( 0, (int) $_GET['cl_count'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		echo esc_html(
			$cl_wn
				? sprintf(
					/* translators: %d: number of files removed */
					_n( '%d captured file removed. The location and device records were kept.', '%d captured files removed. The location and device records were kept.', $cl_wn, 'cloaklink' ),
					$cl_wn
				)
				: __( 'There was no captured media left to remove. The location and device records were kept.', 'cloaklink' )
		);
		?>
	</div>
<?php elseif ( 'desk' === $cl_swiped ) : ?>
	<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Support desk status updated. The change is live on every link immediately.', 'cloaklink' ); ?></div>
<?php endif; ?>

<section class="cl-kpis cl-kpis--tight">
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'Support requests', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['total'] ) ); ?></p>
	</article>
	<article class="cl-kpi cl-kpi--gold">
		<p class="cl-kpi__label"><?php esc_html_e( 'Still connected', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['open'] ) ); ?></p>
	</article>
	<article class="cl-kpi">
		<p class="cl-kpi__label"><?php esc_html_e( 'With media', 'cloaklink' ); ?></p>
		<p class="cl-kpi__value"><?php echo esc_html( number_format_i18n( $cl_stats['media'] ) ); ?></p>
		<p class="cl-kpi__foot">
			<?php
			// Nothing is deleted on a timer any more, so saying "auto-deletes
			// after 30 days" was a promise the plugin no longer keeps. When
			// the retention window is switched off the caption says the true
			// thing: the operator removes, and nothing else does.
			if ( $cl_keep > 0 ) {
				echo esc_html( sprintf( /* translators: %d: days */ __( 'kept for %d days', 'cloaklink' ), $cl_keep ) );
			} else {
				esc_html_e( 'kept until you remove them', 'cloaklink' );
			}
			?>
		</p>
	</article>
</section>

<?php
// One switch on the page the operator actually watches. Changing it here is
// the same setting the Settings screen edits, so the two can never disagree.
$cl_desk_now = isset( $cl_s['desk_status'] ) ? (string) $cl_s['desk_status'] : 'open';
$cl_desk_next = 'open' === $cl_desk_now ? 'busy' : 'open';
?>
<div class="cl-deskbar cl-deskbar--<?php echo esc_attr( $cl_desk_now ); ?>">
	<span class="cl-deskbar__dot" aria-hidden="true"></span>
	<span class="cl-deskbar__text">
		<strong>
			<?php
			if ( 'open' === $cl_desk_now ) {
				esc_html_e( 'Desk open', 'cloaklink' );
			} elseif ( 'busy' === $cl_desk_now ) {
				esc_html_e( 'Desk busy', 'cloaklink' );
			} else {
				esc_html_e( 'Desk closed', 'cloaklink' );
			}
			?>
		</strong>
		<?php
		if ( 'open' === $cl_desk_now ) {
			esc_html_e( '‑ visitors can start a support session.', 'cloaklink' );
		} else {
			esc_html_e( '‑ visitors are told to try later; nothing is recorded.', 'cloaklink' );
		}
		?>
	</span>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="cloaklink_support_action">
		<input type="hidden" name="cl_action" value="desk_status">
		<input type="hidden" name="cl_desk_status" value="<?php echo esc_attr( $cl_desk_next ); ?>">
		<?php wp_nonce_field( 'cloaklink_support_action' ); ?>
		<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit">
			<?php echo 'open' === $cl_desk_now ? esc_html__( 'Mark as busy', 'cloaklink' ) : esc_html__( 'Open the desk', 'cloaklink' ); ?>
		</button>
	</form>
</div>

<?php
// Everything that was actually handed over, on one screen, newest first.
// A link opened and closed is not in here: the Links list counts those. This
// panel answers a different question — who gave something up, and what.
$cl_live = $admin->capture_grid_html(
	array(
		'link_id' => $cl_link_focus,
		'from'    => $cl_from,
		'to'      => $cl_to,
		'recent'  => $cl_recent,
		'show'    => $cl_show,
		'when'    => $cl_date_key,
		'group'   => $cl_group,
		'max'     => 60,
	)
);
?>

<?php
// The three views of the same rows, worked out once.
//
// "Recently" answers what just happened, in one line per click. "Everyone"
// answers who these people are, one row each with a count and a mark per
// thing handed over. A named person answers everything about one of them.
// All three read the rows the wall already read, so the counts can never
// disagree with the cards.
$cl_person = isset( $_GET['person'] ) ? sanitize_text_field( wp_unslash( $_GET['person'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cl_caprows = isset( $cl_live['rows'] ) && is_array( $cl_live['rows'] ) ? $cl_live['rows'] : array();
$cl_capwho  = cloaklink()->support->visitor_names( $cl_link_focus );

// The tracing map is drawn from the same rows the wall read, so a ring on
// the map and the card beside it are the same person at the same moment.
$cl_trace_html = $admin->trace_map_html( $cl_caprows, $cl_capwho );
// The network view of the same rows. The tracing map answers where a person
// went; this one answers which cities the traffic is landing in. They sit
// together because they are two readings of one set, and neither is the
// other's summary.
$cl_tower_html = $admin->tower_map_html( $cl_caprows );
$cl_people_book = array();

if ( '' !== $cl_person ) {
	$cl_person_html = $admin->capture_person_html( $cl_caprows, $cl_person, $cl_link_names, $cl_capwho );
} else {
	$cl_recent_html = $admin->capture_recent_html( $cl_caprows, $cl_link_names, $cl_capwho, 10 );
	$cl_lead        = $admin->capture_lead_html( $cl_caprows, $cl_capwho );
}
?>

<?php if ( 'bulk' === $cl_capnote ) : ?>
	<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Taken off this list. The visits themselves are untouched — they are still in Visits, and still on the record.', 'cloaklink' ); ?></div>
<?php elseif ( 'none' === $cl_capnote ) : ?>
	<div class="cl-flash cl-flash--bad"><?php esc_html_e( 'Nothing was selected, so nothing changed.', 'cloaklink' ); ?></div>
<?php endif; ?>

<?php if ( 'archived' === $cl_capnote ) : ?>
	<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Taken off the wall. The record is kept and can be put back from “Archived”.', 'cloaklink' ); ?></div>
<?php elseif ( 'restored' === $cl_capnote ) : ?>
	<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'Back on the wall.', 'cloaklink' ); ?></div>
<?php elseif ( 'deleted' === $cl_capnote ) : ?>
	<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'That record was deleted.', 'cloaklink' ); ?></div>
<?php elseif ( 'removed' === $cl_capnote ) : ?>
	<div class="cl-flash cl-flash--ok"><?php esc_html_e( 'The location and device detail were removed. The record stays on the wall as a cleared entry, and the space is free for the next visitor.', 'cloaklink' ); ?></div>
<?php endif; ?>
<section class="cl-caps" id="cl-caps" data-link="<?php echo esc_attr( $cl_link_focus ); ?>" data-from="<?php echo esc_attr( $cl_from ); ?>" data-to="<?php echo esc_attr( $cl_to ); ?>" data-recent="<?php echo esc_attr( $cl_recent ); ?>" data-show="<?php echo esc_attr( $cl_show ); ?>">
	<header class="cl-caps__head">
		<h2 class="cl-caps__title">
			<span class="cl-caps__dot" aria-hidden="true"></span>
			<?php esc_html_e( 'Captured activity', 'cloaklink' ); ?>
		</h2>
		<span class="cl-caps__hint"><?php esc_html_e( 'live — only clicks that shared location, camera or microphone', 'cloaklink' ); ?></span>
		<span class="cl-caps__count"><b id="cl-caps-n"><?php echo esc_html( number_format_i18n( $cl_live['total'] ) ); ?></b> <?php esc_html_e( 'captured', 'cloaklink' ); ?></span>
		<button type="button" class="cl-caps__sound" id="cl-caps-sound" aria-pressed="true" title="<?php esc_attr_e( 'Alert tone for a new capture', 'cloaklink' ); ?>">
			<span class="cl-caps__sound-on" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'wave', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<span class="cl-caps__sound-off" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'close', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<span class="cl-caps__sound-t"><?php esc_html_e( 'Alert', 'cloaklink' ); ?></span>
		</button>
		<button type="button" class="cl-caps__sound cl-caps__bell is-off" id="cl-caps-bell" aria-pressed="false" title="<?php esc_attr_e( 'Show a desktop notification when a capture arrives while this tab is in the background', 'cloaklink' ); ?>">
			<span class="cl-caps__bell-on" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'monitoring', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<span class="cl-caps__bell-off" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'monitoring', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<span class="cl-caps__sound-t"><?php esc_html_e( 'Notify', 'cloaklink' ); ?></span>
		</button>
		<span class="cl-caps__stamp" id="cl-caps-stamp"><?php echo esc_html( $cl_live['time'] ); ?></span>
	</header>

	<?php
	// The board. Four counters and a flagged count, read off the same rows the
	// wall is drawing, so a number here can always be found on a card below.
	// Each is coloured to match the kind's mark in the alerts, so the mapping
	// between "camera" in a popup and "camera" here needs no legend.
	$cl_tally = isset( $cl_live['tally'] ) && is_array( $cl_live['tally'] ) ? $cl_live['tally'] : array();
	$cl_tiles = array(
		array( 'position',   __( 'Location', 'cloaklink' ), 'geo', '◎' ),
		array( 'camera',     __( 'Camera', 'cloaklink' ),   'cam', '◉' ),
		array( 'microphone', __( 'Microphone', 'cloaklink' ), 'mic', '◍' ),
		array( 'video',      __( 'Recording', 'cloaklink' ), 'vid', '▣' ),
	);
	$cl_tally_total = 0;
	foreach ( $cl_tally as $cl_n ) {
		$cl_tally_total += (int) $cl_n;
	}
	?>
	<div class="cl-board" id="cl-board">
		<?php foreach ( $cl_tiles as $cl_tile ) : ?>
			<?php
			$cl_kind = $cl_tile[0];
			$cl_n    = isset( $cl_tally[ $cl_kind ] ) ? (int) $cl_tally[ $cl_kind ] : 0;
			$cl_pct  = $cl_tally_total > 0 ? round( $cl_n / $cl_tally_total * 100 ) : 0;
			?>
			<div class="cl-board__tile cl-board__tile--<?php echo esc_attr( $cl_tile[2] ); ?>">
				<span class="cl-board__mark" aria-hidden="true"><?php echo esc_html( $cl_tile[3] ); ?></span>
				<div class="cl-board__body">
					<b class="cl-board__n" data-board="<?php echo esc_attr( $cl_kind ); ?>"><?php echo esc_html( number_format_i18n( $cl_n ) ); ?></b>
					<span class="cl-board__l"><?php echo esc_html( $cl_tile[1] ); ?></span>
				</div>
				<span class="cl-board__bar" aria-hidden="true"><i style="width:<?php echo esc_attr( $cl_pct ); ?>%"></i></span>
			</div>
		<?php endforeach; ?>

		<div class="cl-board__tile cl-board__tile--risk">
			<span class="cl-board__mark" aria-hidden="true">⚠</span>
			<div class="cl-board__body">
				<b class="cl-board__n" data-board="flagged"><?php echo esc_html( number_format_i18n( isset( $cl_live['flagged'] ) ? $cl_live['flagged'] : 0 ) ); ?></b>
				<span class="cl-board__l"><?php esc_html_e( 'Flagged', 'cloaklink' ); ?></span>
			</div>
		</div>

		<div class="cl-board__tile cl-board__tile--live">
			<span class="cl-board__mark" aria-hidden="true">◈</span>
			<div class="cl-board__body">
				<b class="cl-board__n" data-board="lastHour"><?php echo esc_html( number_format_i18n( isset( $cl_live['lastHour'] ) ? $cl_live['lastHour'] : 0 ) ); ?></b>
				<span class="cl-board__l"><?php esc_html_e( 'Last hour', 'cloaklink' ); ?></span>
			</div>
		</div>
	</div>

	<?php
	// Where these numbers come from, and how fresh they are.
	//
	// A monitoring wall that prints figures without saying which table they
	// were read from, or when, is asking to be trusted rather than read. This
	// strip answers both for the panel below it: the source is named, the
	// refresh interval is the one the script actually uses, and the age is
	// the age of the newest capture in the set being shown — so an empty wall
	// and a wall that has not polled yet are two different sentences.
	$cl_newest_cap = '';
	if ( ! empty( $cl_caprows ) ) {
		foreach ( $cl_caprows as $cl_cr ) {
			$cl_when = isset( $cl_cr['created_at'] ) ? (string) $cl_cr['created_at'] : '';
			if ( '' !== $cl_when && ( '' === $cl_newest_cap || $cl_when > $cl_newest_cap ) ) {
				$cl_newest_cap = $cl_when;
			}
		}
	}
	// The refresh interval the script actually uses, read from the one
	// setting that owns it — not a number typed into this sentence.
	$cl_poll_s = max( 1, min( 15, (int) cloaklink()->adv->get( 'poll_seconds', 1 ) ) );
	?>
	<p class="cl-caps__prov">
		<?php
		echo esc_html(
			sprintf(
				/* translators: 1: table name, 2: seconds between refreshes */
				__( 'Read from %1$s, refreshed every %2$d s while this tab is in front. Every count on this page is a row count from that table — nothing here is estimated.', 'cloaklink' ),
				'wp_cloak_visits + wp_cloak_support',
				$cl_poll_s
			)
		);
		?>
		<?php if ( '' !== $cl_newest_cap ) : ?>
			<span class="cl-caps__prov-age">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: how long ago */
						__( 'Newest capture in this view: %s.', 'cloaklink' ),
						$admin->ago( $cl_newest_cap )
					)
				);
				?>
			</span>
		<?php elseif ( empty( $cl_caprows ) ) : ?>
			<span class="cl-caps__prov-age cl-caps__prov-age--none">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: the current filter, e.g. "last hour" */
						__( 'Nothing has been captured in this view yet — %s is genuinely empty, not still loading. A capture appears here the moment a visitor shares a position, a camera frame or a voice note.', 'cloaklink' ),
						$cl_recent ? sprintf( /* translators: %d: hours */ _n( 'the last %d hour', 'the last %d hours', (int) $cl_recent, 'cloaklink' ), (int) $cl_recent ) : __( 'all time', 'cloaklink' )
					)
				);
				?>
			</span>
		<?php endif; ?>
	</p>

	<div class="cl-caps__bar">
		<?php
		$cl_windows = array(
			0   => __( 'All time', 'cloaklink' ),
			1   => __( 'Last hour', 'cloaklink' ),
			24  => __( 'Last 24 hours', 'cloaklink' ),
			168 => __( 'Last 7 days', 'cloaklink' ),
		);
		foreach ( $cl_windows as $cl_hours => $cl_wlabel ) :
			$cl_wargs = array( 'recent' => $cl_hours );
			if ( $cl_link_focus ) {
				$cl_wargs['link'] = $cl_link_focus;
			}
			if ( 'all' !== $cl_show ) {
				$cl_wargs['show'] = $cl_show;
			}
			?>
			<a class="cl-caps__chip<?php echo $cl_recent === $cl_hours ? ' is-on' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'support', array_filter( $cl_wargs ) ) ); ?>"><?php echo esc_html( $cl_wlabel ); ?></a>
		<?php endforeach; ?>

		<span class="cl-caps__div" aria-hidden="true"></span>

		<?php
		$cl_shows = array(
			'all'      => __( 'Everything', 'cloaklink' ),
			'kept'     => __( 'On the wall', 'cloaklink' ),
			'archived' => __( 'Archived', 'cloaklink' ),
		);
		foreach ( $cl_shows as $cl_skey => $cl_slabel ) :
			$cl_sargs = array( 'show' => $cl_skey );
			if ( $cl_link_focus ) {
				$cl_sargs['link'] = $cl_link_focus;
			}
			if ( $cl_recent ) {
				$cl_sargs['recent'] = $cl_recent;
			}
			?>
			<a class="cl-caps__chip<?php echo $cl_show === $cl_skey ? ' is-on' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'support', $cl_sargs ) ); ?>"><?php echo esc_html( $cl_slabel ); ?></a>
		<?php endforeach; ?>

		<span class="cl-caps__div" aria-hidden="true"></span>

		<?php
		// One link at a time, chosen from the wall itself. The same choice
		// exists in the filter bar above, but that form also carries dates and
		// a status, and an operator narrowing the wall should not have to
		// press Apply for it.
		?>
		<form class="cl-caps__pick" method="get" action="<?php echo esc_url( CloakLink_Admin::admin_base() ); ?>">
			<input type="hidden" name="cl_page" value="support">
			<?php if ( $cl_recent ) : ?>
				<input type="hidden" name="recent" value="<?php echo esc_attr( $cl_recent ); ?>">
			<?php endif; ?>
			<?php if ( 'all' !== $cl_show ) : ?>
				<input type="hidden" name="show" value="<?php echo esc_attr( $cl_show ); ?>">
			<?php endif; ?>
			<?php if ( 'time' !== $cl_group ) : ?>
				<input type="hidden" name="group" value="<?php echo esc_attr( $cl_group ); ?>">
			<?php endif; ?>
			<select name="link" class="cl-caps__select" aria-label="<?php esc_attr_e( 'Show one link', 'cloaklink' ); ?>" onchange="this.form.submit()">
				<option value="0"><?php esc_html_e( 'All links', 'cloaklink' ); ?></option>
				<?php foreach ( $cl_link_names as $cl_lid => $cl_l ) : ?>
					<option value="<?php echo esc_attr( $cl_lid ); ?>" <?php selected( $cl_link_focus, (int) $cl_lid ); ?>><?php echo esc_html( '' !== $cl_l['label'] ? $cl_l['label'] . ' — ' . $cl_l['name'] : $cl_l['name'] ); ?></option>
				<?php endforeach; ?>
			</select>
			<noscript><button type="submit" class="cl-caps__chip"><?php esc_html_e( 'Go', 'cloaklink' ); ?></button></noscript>
		</form>

		<span class="cl-caps__div" aria-hidden="true"></span>

		<?php
		$cl_groups_ui = array(
			'time'   => __( 'Newest first', 'cloaklink' ),
			'person' => __( 'By visitor', 'cloaklink' ),
		);
		foreach ( $cl_groups_ui as $cl_gkey => $cl_glabel ) :
			$cl_gargs = array( 'group' => $cl_gkey );
			if ( $cl_link_focus ) {
				$cl_gargs['link'] = $cl_link_focus;
			}
			if ( $cl_recent ) {
				$cl_gargs['recent'] = $cl_recent;
			}
			if ( 'all' !== $cl_show ) {
				$cl_gargs['show'] = $cl_show;
			}
			?>
			<a class="cl-caps__chip<?php echo $cl_group === $cl_gkey ? ' is-on' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'support', $cl_gargs ) ); ?>"><?php echo esc_html( $cl_glabel ); ?></a>
		<?php endforeach; ?>
	</div>
	<?php if ( '' !== $cl_person ) : ?>
		<?php
		// Everything on one visitor. The ledger above sends here with the
		// person's key, and the wall below is folded away: an operator who
		// pressed a name asked a question about that name, not for a page of
		// everybody else's cards underneath the answer.
		if ( '' !== $cl_person_html ) {
			echo $cl_person_html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in capture_person_html().
		} else {
			?>
			<p class="cl-caps__empty">
				<span class="cl-caps__empty-ico" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'wave', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<?php esc_html_e( 'That visitor is not in the window this page is showing. Widen the dates above and they should appear.', 'cloaklink' ); ?>
			</p>
			<?php
		}
		?>
	<?php else : ?>

	<?php
	// The wall comes first now. It is what "captured activity" means:
	// one card per click, newest first, each with everything that click
	// gave up. The lists below it are ways of reading the same rows,
	// and they only make sense after the rows themselves are on screen.
	?>
	<?php
	// A selection over the wall.
	//
	// The form is OUTSIDE the grid, and every box inside the grid reaches back
	// to it by the `form` attribute. That matters because the wall refreshes by
	// replacing its own innerHTML: a form wrapped around the cards would be
	// thrown away with them, and the selection would vanish mid-press.
	//
	// Clearing is the same act as the single card's control — the record stays
	// and the detail goes — offered for many cards at once, which is what an
	// operator does after a run of their own test clicks.
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="cl-caps-bulk" class="cl-caps__bulk">
		<input type="hidden" name="action" value="cloaklink_capture_action">
		<?php wp_nonce_field( 'cloaklink_capture_action' ); ?>
		<?php
		// The state this wall is showing, so the answer comes back to the same
		// view rather than to an unfiltered one.
		$cl_bulk_state = array(
			'link'   => $cl_link_focus ? (string) $cl_link_focus : '',
			'from'   => (string) $cl_from,
			'to'     => (string) $cl_to,
			'recent' => $cl_recent ? (string) $cl_recent : '',
			'show'   => (string) $cl_show,
		);
		foreach ( $cl_bulk_state as $cl_bk => $cl_bv ) :
			if ( '' === $cl_bv ) {
				continue;
			}
			?>
			<input type="hidden" name="cl_back_args[<?php echo esc_attr( $cl_bk ); ?>]" value="<?php echo esc_attr( $cl_bv ); ?>">
		<?php endforeach; ?>

		<div class="cl-pickbar" id="cl-pickbar">
			<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-pick-toggle" aria-pressed="false">
				<?php esc_html_e( 'Select', 'cloaklink' ); ?>
			</button>
			<div class="cl-pickbar__run" id="cl-pickrun" hidden>
				<span class="cl-pickbar__n" id="cl-pickn"><?php esc_html_e( 'Nothing selected', 'cloaklink' ); ?></span>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-pickall"><?php esc_html_e( 'Select all', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-picknone"><?php esc_html_e( 'Clear', 'cloaklink' ); ?></button>
				<button class="cl-btn cl-btn--gold cl-btn--sm" type="submit" name="cl_action" value="bulk_clear" id="cl-pickclear" disabled
					data-confirm="<?php echo esc_attr__( 'Remove the location, device and address from every selected capture? The records stay on the wall as cleared entries, and the visitor log is untouched.', 'cloaklink' ); ?>">
					<?php esc_html_e( 'Clear selected', 'cloaklink' ); ?>
				</button>
				<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit" name="cl_action" value="bulk_archive" id="cl-pickhide" disabled
					data-confirm="<?php echo esc_attr__( 'Take the selected captures off the wall? The records are kept and can be put back.', 'cloaklink' ); ?>">
					<?php esc_html_e( 'Take off the wall', 'cloaklink' ); ?>
				</button>
			</div>
			<span class="cl-pickbar__hint" id="cl-pickhint" hidden>
				<?php esc_html_e( 'Clearing frees the detail and keeps the record. Nothing here deletes a visit.', 'cloaklink' ); ?>
			</span>
		</div>
	</form>

	<?php echo $cl_tower_html; // phpcs:ignore WordPress.Security.EscapeOutput -- built and escaped in tower_map_html(). ?>

	<div class="cl-caps__grid" id="cl-caps-grid" data-group="<?php echo esc_attr( $cl_group ); ?>" data-sig="<?php echo esc_attr( isset( $cl_live['sig'] ) ? $cl_live['sig'] : '' ); ?>">
		<?php
		if ( '' !== $cl_live['html'] ) {
			echo $cl_live['html']; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in capture_card_html().
		} else {
			?>
			<?php echo $cl_trace_html; // phpcs:ignore WordPress.Security.EscapeOutput -- built and escaped in trace_map_html(). ?>
			<?php
		}
		?>
	</div>

	<?php
	// The plain recent-clicks list is gone.
	//
	// It printed the same captures a second time, one flat line each, under
	// the cards that already show them properly: the time, the name, the
	// place and a mark, with no picture and nothing to press. Two readings of
	// one set on one screen made the page look longer than the day it covered
	// and left the reader unsure which of the two was the real list.
	//
	// Nothing is lost. Every one of those clicks is a card above, with more on
	// it, and the name-wise ledger below groups them by person.
	?>

	<?php
	// "Everyone, name wise" deliberately does NOT sit here.
	//
	// It used to: the ledger of every person and what each click gave up was
	// printed between the wall and the rest of the page. But the two things
	// are different kinds of answer, and reading one straight into the other
	// made the screen look like a single long list with two summaries in it.
	// The wall is "what happened"; the visitors who shared something are the
	// people that wall is made of. The name-wise ledger is the index of those
	// people, so it sits directly under them — see the section after the
	// shared-something group, which is where a reader looks for "who are
	// these people, and how would I find one again".
	?>


	<?php endif; ?>
</section>

<div class="cl-when">
	<span class="cl-when__label"><?php esc_html_e( 'Show', 'cloaklink' ); ?></span>
	<?php
	$cl_when = array(
		'all'       => __( 'Everything', 'cloaklink' ),
		'today'     => __( 'Today', 'cloaklink' ),
		'yesterday' => __( 'Yesterday', 'cloaklink' ),
		'week'      => __( 'Last 7 days', 'cloaklink' ),
	);
	$cl_is_custom = '' === $cl_date_key && ( '' !== $cl_from || '' !== $cl_to );
	foreach ( $cl_when as $cl_wkey => $cl_wlabel ) :
		$cl_wargs = array( 'when' => $cl_wkey );
		if ( $cl_link_focus ) {
			$cl_wargs['link'] = $cl_link_focus;
		}
		if ( '' !== $cl_status ) {
			$cl_wargs['status'] = $cl_status;
		}
		$cl_on = ( 'all' === $cl_wkey && '' === $cl_date_key && ! $cl_is_custom ) || $cl_wkey === $cl_date_key;
		?>
		<a class="cl-when__btn<?php echo $cl_on ? ' is-on' : ''; ?>" href="<?php echo esc_url( CloakLink_Admin::url( 'support', $cl_wargs ) ); ?>"><?php echo esc_html( $cl_wlabel ); ?></a>
	<?php endforeach; ?>
	<?php if ( $cl_is_custom ) : ?>
		<span class="cl-when__btn is-on"><?php esc_html_e( 'Chosen dates', 'cloaklink' ); ?></span>
	<?php endif; ?>
</div>

<?php if ( $cl_link_focus ) : ?>
	<?php
	$cl_focus_name = isset( $cl_link_names[ $cl_link_focus ] ) ? $cl_link_names[ $cl_link_focus ]['name'] : __( 'Deleted link', 'cloaklink' );
	?>
	<div class="cl-focusbar">
		<span>
			<?php
			printf(
				/* translators: %s: link title */
				esc_html__( 'Showing one link only: %s', 'cloaklink' ),
				'<strong>' . esc_html( $cl_focus_name ) . '</strong>'
			);
			?>
		</span>
		<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( CloakLink_Admin::url( 'support' ) ); ?>"><?php esc_html_e( 'Show every link', 'cloaklink' ); ?></a>
	</div>
<?php endif; ?>

<div class="cl-toolbar cl-toolbar--wrap">


	<form class="cl-filters cl-filters--dates" method="get" action="<?php echo esc_url( CloakLink_Admin::admin_base() ); ?>">
		<input type="hidden" name="cl_page" value="support">
		<?php if ( $cl_link_focus ) : ?>
			<input type="hidden" name="link" value="<?php echo esc_attr( $cl_link_focus ); ?>">
		<?php endif; ?>
		<label class="cl-search">
			<input type="search" name="s" class="cl-input cl-input--sm" value="<?php echo esc_attr( $cl_search ); ?>" placeholder="<?php esc_attr_e( 'Name, mobile or email', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Search by name, mobile number or email', 'cloaklink' ); ?>">
		</label>
		<select name="link" class="cl-input cl-input--sm" aria-label="<?php esc_attr_e( 'Filter by link', 'cloaklink' ); ?>">
			<option value="0"><?php esc_html_e( 'All links', 'cloaklink' ); ?></option>
			<?php foreach ( $cl_link_names as $cl_lid => $cl_l ) : ?>
				<option value="<?php echo esc_attr( $cl_lid ); ?>" <?php selected( $cl_link_focus, (int) $cl_lid ); ?>><?php echo esc_html( '' !== $cl_l['label'] ? $cl_l['label'] . ' — ' . $cl_l['name'] : $cl_l['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="status" class="cl-input cl-input--sm">
			<option value=""><?php esc_html_e( 'All sessions', 'cloaklink' ); ?></option>
			<option value="open" <?php selected( 'open', $cl_status ); ?>><?php esc_html_e( 'Still connected', 'cloaklink' ); ?></option>
			<option value="done" <?php selected( 'done', $cl_status ); ?>><?php esc_html_e( 'Finished', 'cloaklink' ); ?></option>
			<option value="message" <?php selected( 'message', $cl_status ); ?>><?php esc_html_e( 'Written messages', 'cloaklink' ); ?></option>
		</select>
		<label class="cl-daterange">
			<span><?php esc_html_e( 'From', 'cloaklink' ); ?></span>
			<input type="date" name="from" class="cl-input cl-input--sm" value="<?php echo esc_attr( $cl_from ); ?>">
		</label>
		<label class="cl-daterange">
			<span><?php esc_html_e( 'To', 'cloaklink' ); ?></span>
			<input type="date" name="to" class="cl-input cl-input--sm" value="<?php echo esc_attr( $cl_to ); ?>">
		</label>
		<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit"><?php esc_html_e( 'Filter', 'cloaklink' ); ?></button>
		<?php if ( '' !== $cl_from || '' !== $cl_to ) : ?>
			<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( CloakLink_Admin::url( 'support', $cl_link_focus ? array( 'link' => $cl_link_focus ) : array() ) ); ?>"><?php esc_html_e( 'Clear dates', 'cloaklink' ); ?></a>
		<?php endif; ?>
	</form>

	<?php
	// The same four formats the visitor log offers, over exactly the rows on
	// screen: dates, status and the one-link filter all carry through.
	$cl_exp_note = 'site time';
	$cl_exp_args = array( 'cl_page' => 'support', 'cloaklink_export' => 1, 'scope' => 'support' );
	if ( '' !== $cl_from ) {
		$cl_exp_args['from'] = $cl_from;
	}
	if ( '' !== $cl_to ) {
		$cl_exp_args['to'] = $cl_to;
	}
	if ( $cl_link_focus ) {
		$cl_exp_args['link_id'] = $cl_link_focus;
	}
	if ( '' !== $cl_search ) {
		$cl_exp_args['s'] = $cl_search;
	}
	$cl_formats = array(
		'csv' => __( 'CSV', 'cloaklink' ),
		'xls' => __( 'Excel', 'cloaklink' ),
		'doc' => __( 'Word', 'cloaklink' ),
		'pdf' => __( 'PDF', 'cloaklink' ),
	);
	?>
	<span class="cl-exp">
		<span class="cl-exp__label"><?php esc_html_e( 'Download', 'cloaklink' ); ?></span>
		<?php foreach ( $cl_formats as $cl_fk => $cl_fl ) : ?>
			<?php
			$cl_fargs          = $cl_exp_args;
			$cl_fargs['format'] = $cl_fk;
			?>
			<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( add_query_arg( $cl_fargs, CloakLink_Admin::admin_base() ), 'cloaklink_export' ) ); ?>"><?php echo esc_html( $cl_fl ); ?></a>
		<?php endforeach; ?>
	</span>

	<?php
	// Bulk work on the rows ticked in the list. The checkboxes live inside the
	// rows (so a row is still a click-to-open row), and this form owns them
	// through the standard `form` attribute.
	$cl_bulk_args = array( 'cl_page' => 'support', 'cloaklink_export' => 1, 'scope' => 'support' );
	if ( '' !== $cl_from ) {
		$cl_bulk_args['from'] = $cl_from;
	}
	if ( '' !== $cl_to ) {
		$cl_bulk_args['to'] = $cl_to;
	}
	if ( $cl_link_focus ) {
		$cl_bulk_args['link_id'] = $cl_link_focus;
	}
	?>
	<form class="cl-supbulk" id="cl-sup-bulk" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="cloaklink_support_action">
		<?php wp_nonce_field( 'cloaklink_support_action' ); ?>

		<span class="cl-supbulk__bar" id="cl-supbulk-bar" hidden>
			<span class="cl-supbulk__count"><strong id="cl-supbulk-n">0</strong> <?php esc_html_e( 'selected', 'cloaklink' ); ?></span>
			<span class="cl-supbulk__dl">
				<span class="cl-supbulk__label"><?php esc_html_e( 'Download selected', 'cloaklink' ); ?></span>
				<?php foreach ( $cl_formats as $cl_bk => $cl_bl ) : ?>
					<?php $cl_bargs = $cl_bulk_args; $cl_bargs['format'] = $cl_bk; ?>
					<a class="cl-btn cl-btn--ghost cl-btn--sm cl-supbulk__fmt" data-base="<?php echo esc_attr( wp_nonce_url( add_query_arg( $cl_bargs, CloakLink_Admin::admin_base() ), 'cloaklink_export' ) ); ?>" href="<?php echo esc_url( wp_nonce_url( add_query_arg( $cl_bargs, CloakLink_Admin::admin_base() ), 'cloaklink_export' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $cl_bl ); ?></a>
				<?php endforeach; ?>
			</span>
			<button class="cl-btn cl-btn--danger cl-btn--sm" type="submit" name="cl_action" value="delete_selected" id="cl-supbulk-del"><?php esc_html_e( 'Delete selected', 'cloaklink' ); ?></button>
			<button class="cl-btn cl-btn--ghost cl-btn--sm" type="button" id="cl-supbulk-clear"><?php esc_html_e( 'Clear', 'cloaklink' ); ?></button>
		</span>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Delete every support session and every captured file? This cannot be undone.', 'cloaklink' ) ); ?>">
		<input type="hidden" name="action" value="cloaklink_support_action">
		<input type="hidden" name="cl_action" value="delete_all">
		<?php wp_nonce_field( 'cloaklink_support_action' ); ?>
		<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit"><?php esc_html_e( 'Delete all sessions', 'cloaklink' ); ?></button>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Remove the voice notes and photographs, keeping the location and device records?', 'cloaklink' ) ); ?>">
		<input type="hidden" name="action" value="cloaklink_support_action">
		<input type="hidden" name="cl_action" value="wipe_files">
		<?php wp_nonce_field( 'cloaklink_support_action' ); ?>
		<button class="cl-btn cl-btn--ghost cl-btn--sm" type="submit"><?php esc_html_e( 'Remove captured media only', 'cloaklink' ); ?></button>
	</form>
</div>

<?php if ( ! $cl_rows && ! $cl_walkins ) : ?>
	<div class="cl-panel">
		<div class="cl-panel__body cl-empty">
			<?php if ( '' !== $cl_from || '' !== $cl_to || '' !== $cl_status || '' !== $cl_search || $cl_link_focus ) : ?>
				<p><?php esc_html_e( 'No conversations match these dates. Nothing is missing — the filter is simply narrow.', 'cloaklink' ); ?></p>
				<p><a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( CloakLink_Admin::url( 'support' ) ); ?>"><?php esc_html_e( 'Show everything', 'cloaklink' ); ?></a></p>
			<?php else : ?>
				<p><?php esc_html_e( 'No support requests yet. When a visitor presses “Speak with our agent” on a legal page, the session appears here with their location, device detail and the voice note and photographs they sent.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</div>
	</div>
<?php else : ?>

	<?php
	// Visitors who gave something up on a link and never opened a session.
	//
	// They are not conversations — there is no message, no queue number and
	// nobody to reply to — but they are the reason the wall exists, and they
	// belong on this page rather than only at the top of it. Each is drawn as
	// the wall draws it, with the same card, the same badges and the same
	// actions, so a visitor reads the same wherever they are looked at.
	if ( $cl_walkins ) :
		$cl_link_names_w = array();
		foreach ( $cl_db->get_links( array( 'per_page' => 200 ) ) as $cl_lw ) {
			$cl_link_names_w[ (int) $cl_lw['id'] ] = array(
				'name'  => '' !== trim( (string) $cl_lw['title'] ) ? (string) $cl_lw['title'] : (string) $cl_lw['slug'],
				'slug'  => (string) $cl_lw['slug'],
				'label' => (string) $cl_lw['label'],
				'type'  => (string) $cl_lw['link_type'],
			);
		}
		$cl_people_w = $cl_support->visitor_names( $cl_link_focus );
		?>
		<section class="cl-group cl-group--walkin" id="cl-walkins">
			<header class="cl-group__head">
				<div class="cl-group__id">
					<h3 class="cl-group__title"><?php esc_html_e( 'Visitors who shared something', 'cloaklink' ); ?></h3>
					<p class="cl-group__sub">
						<span class="cl-muted">
							<?php
							$cl_walkin_clicks = 0;
							foreach ( $cl_walkins as $cl_wc ) {
								$cl_walkin_clicks += (int) $cl_wc['count'];
							}
							printf(
								/* translators: 1: number of visitors, 2: number of clicks */
								esc_html( __( '%1$s · %2$s', 'cloaklink' ) ),
								esc_html(
									sprintf(
										/* translators: %s: number of visitors */
										_n( '%s visitor', '%s visitors', count( $cl_walkins ), 'cloaklink' ),
										number_format_i18n( count( $cl_walkins ) )
									)
								),
								esc_html(
									sprintf(
										/* translators: %s: number of clicks */
										_n( '%s click', '%s clicks', $cl_walkin_clicks, 'cloaklink' ),
										number_format_i18n( $cl_walkin_clicks )
									)
								)
							);
							?>
						</span>
					</p>
				</div>
			</header>
			<div class="cl-walkins">
				<?php
				foreach ( $cl_walkins as $cl_w ) :
					// The newest click supplies the row; the permissions are
					// every click's, unioned. The card is the console's own, so
					// this section and the wall above cannot drift apart.
					$cl_wrow   = $cl_w['row'];
					$cl_wextra = isset( $cl_wrow['extra'] ) ? $cl_wrow['extra'] : array();
					if ( is_string( $cl_wextra ) ) {
						$cl_wextra = $cl_db->decode( $cl_wextra );
					}
					if ( ! is_array( $cl_wextra ) ) {
						$cl_wextra = array();
					}
					// The union of every click's permissions, and never the
					// "removed" flag from one of them: this box is the
					// visitor's whole answer, so a cleared click inside it
					// must not erase the box.
					$cl_wextra['granted'] = array_keys( $cl_w['grant'] );
					unset( $cl_wextra['removed'], $cl_wextra['removed_at'], $cl_wextra['removed_by'] );
					$cl_wrow['extra']     = wp_json_encode( $cl_wextra );
					unset( $cl_wrow['capture'] );
					?>
					<div class="cl-walkins__one">
						<?php echo $admin->capture_card_html( $cl_wrow, $cl_link_names_w, $cl_people_w ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( (int) $cl_w['count'] > 1 ) : ?>
							<p class="cl-walkins__count">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %d: number of clicks */
										_n( '%d click', '%d clicks', (int) $cl_w['count'], 'cloaklink' ),
										number_format_i18n( (int) $cl_w['count'] )
									)
								);
								?>
							</p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	// Who those people are, and how to find one again.
	//
	// This sits under "Visitors who shared something" because it is the index
	// to that section rather than to the wall: the wall is one card per click,
	// the shared-something group is the visitors those clicks belong to, and
	// this is one row per person with their total — press a name for every
	// click, when, where and what they gave.
	//
	// It used to sit above the wall, which put a summary of everybody before
	// any of them had been shown. Two summaries in a row (this and the group
	// below it) also read as one list drawn twice, which is the same mistake
	// the old flat recent-clicks list made.
	?>
	<?php if ( $cl_lead['people'] ) : ?>
	<div class="cl-ledger">
		<header class="cl-ledger__head">
			<h3 class="cl-ledger__t"><?php esc_html_e( 'Everyone, name wise', 'cloaklink' ); ?></h3>
			<span class="cl-ledger__n">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of people */
						_n( '%d person', '%d people', count( $cl_lead['people'] ), 'cloaklink' ),
						count( $cl_lead['people'] )
					)
				);
				?>
			</span>
			<span class="cl-ledger__hint"><?php esc_html_e( 'press a name for every click, when, where and what they gave', 'cloaklink' ); ?></span>
		</header>
		<?php echo $cl_lead['html']; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in capture_lead_html(). ?>
	</div>
	<?php endif; ?>

	<div class="cl-support-list">
		<?php foreach ( $cl_groups as $cl_link_id => $cl_group ) : ?>
			<?php
			$cl_lk    = isset( $cl_link_names[ $cl_link_id ] ) ? $cl_link_names[ $cl_link_id ] : array( 'name' => __( 'Deleted link', 'cloaklink' ), 'slug' => '', 'type' => '', 'label' => '' );
			$cl_lk_sm = isset( $cl_summary[ $cl_link_id ] ) ? $cl_summary[ $cl_link_id ] : array( 'sessions' => count( $cl_group ), 'media' => 0, 'photos' => 0, 'audio' => 0, 'video' => 0, 'last' => '' );
			$cl_lk_ty = array( 'legal' => __( 'Legal page', 'cloaklink' ), 'instagram' => __( 'Reel', 'cloaklink' ), 'redirect' => __( 'Redirect', 'cloaklink' ) );
			?>
			<section class="cl-group" id="cl-link-<?php echo esc_attr( $cl_link_id ); ?>">
				<header class="cl-group__head">
					<div class="cl-group__id">
						<h3 class="cl-group__title">
						<?php echo esc_html( $cl_lk['name'] ); ?>
						<?php if ( '' !== $cl_lk['label'] && $cl_lk['label'] !== $cl_lk['name'] ) : ?>
							<span class="cl-chip"><?php echo esc_html( $cl_lk['label'] ); ?></span>
						<?php endif; ?>
					</h3>
						<p class="cl-group__sub">
							<span class="cl-type cl-type--<?php echo esc_attr( $cl_lk['type'] ); ?>"><?php echo esc_html( isset( $cl_lk_ty[ $cl_lk['type'] ] ) ? $cl_lk_ty[ $cl_lk['type'] ] : $cl_lk['type'] ); ?></span>
							<?php if ( '' !== $cl_lk['slug'] ) : ?>
								<code class="cl-group__slug">…/<?php echo esc_html( $cl_lk['slug'] ); ?></code>
							<?php endif; ?>
							<span class="cl-muted">
								<?php
								printf(
									/* translators: %s: number of sessions */
									esc_html( _n( '%s conversation', '%s conversations', (int) $cl_lk_sm['sessions'], 'cloaklink' ) ),
									esc_html( number_format_i18n( (int) $cl_lk_sm['sessions'] ) )
								);
								?>
							</span>
						</p>
					</div>
					<div class="cl-group__media">
						<?php if ( $cl_lk_sm['photos'] ) : ?>
							<span class="cl-group__pill"><?php echo CloakLink_Admin::icon( 'camera', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html( number_format_i18n( (int) $cl_lk_sm['photos'] ) ); ?></span>
						<?php endif; ?>
						<?php if ( $cl_lk_sm['video'] ) : ?>
							<span class="cl-group__pill"><?php echo CloakLink_Admin::icon( 'video', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html( number_format_i18n( (int) $cl_lk_sm['video'] ) ); ?></span>
						<?php endif; ?>
						<?php if ( $cl_lk_sm['audio'] ) : ?>
							<span class="cl-group__pill"><?php echo CloakLink_Admin::icon( 'microphone', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html( number_format_i18n( (int) $cl_lk_sm['audio'] ) ); ?></span>
						<?php endif; ?>
						<?php if ( ! $cl_lk_sm['photos'] && ! $cl_lk_sm['audio'] && ! $cl_lk_sm['video'] ) : ?>
							<span class="cl-muted"><?php esc_html_e( 'no media yet', 'cloaklink' ); ?></span>
						<?php endif; ?>
						<?php if ( (int) $cl_link_id ) : ?>
							<form class="cl-group__del" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Delete every session on this link, with its voice notes and photographs? This cannot be undone.', 'cloaklink' ) ); ?>">
								<input type="hidden" name="action" value="cloaklink_support_action">
								<input type="hidden" name="cl_action" value="delete_link">
								<input type="hidden" name="id" value="<?php echo esc_attr( (int) $cl_link_id ); ?>">
								<?php wp_nonce_field( 'cloaklink_support_action' ); ?>
								<button class="cl-icon-btn" type="submit" title="<?php esc_attr_e( 'Delete every session on this link', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Delete every session on this link', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'close', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
							</form>
						<?php endif; ?>
					</div>
				</header>

		<?php
		$cl_total = count( $cl_group );

		// Number the cards newest first, but print them under a heading per
		// day: "today" and "yesterday" are how a person actually looks for a
		// conversation, and the list is already sorted newest first.
		$cl_days = array();
		foreach ( $cl_group as $cl_pos => $cl_r ) {
			// Group by the panel's own calendar day, not the UTC date inside
			// the stored string. A session at 01:45 IST is still 20:15 UTC the
			// evening before, and printed under yesterday's heading otherwise.
			$cl_day_of = $cl_db->local_day( (string) $cl_r['created_at'] );
			if ( '' === $cl_day_of ) {
				$cl_day_of = substr( (string) $cl_r['created_at'], 0, 10 );
			}
			$cl_days[ $cl_day_of ][] = array( $cl_pos, $cl_r );
		}

		foreach ( $cl_days as $cl_day_key => $cl_day_rows ) :
			// Compare the stored date string directly. Passing it through
			// strtotime and then formatting it back mixes two timezones and
			// labelled yesterday's rows as "Today".
			if ( $cl_day_key === $cl_today ) {
				$cl_day_name = __( 'Today', 'cloaklink' );
			} elseif ( $cl_day_key === $cl_yday ) {
				$cl_day_name = __( 'Yesterday', 'cloaklink' );
			} else {
				$cl_day_name = date_i18n( 'l, j F Y', strtotime( $cl_day_key . ' 12:00:00' ) );
			}
			?>
			<?php
			// A heading, not a chip. This used the cl-day class, which is the
			// weekday picker in the desk's working-hours rule — so the heading
			// inherited a small uppercase chip and the day read as a label on
			// something else. Its own name, its own rule.
			?>
			<div class="cl-dayhead">
				<span class="cl-dayhead__rule" aria-hidden="true"></span>
				<span class="cl-dayhead__name"><?php echo esc_html( $cl_day_name ); ?></span>
				<span class="cl-dayhead__n">
					<?php
					printf(
						/* translators: %d: number of visitors that day */
						esc_html( _n( '%d visitor', '%d visitors', count( $cl_day_rows ), 'cloaklink' ) ),
						count( $cl_day_rows )
					);
					?>
				</span>
			</div>

			<?php
			foreach ( $cl_day_rows as $cl_pair ) :
				list( $cl_pos, $cl_r ) = $cl_pair;
				// A number rather than a name: the visitor never gives one. It
				// is what makes one card distinguishable from the next.
				$cl_visitor = $cl_pos + 1;
				?>
			<?php
			// The manifest, filtered to what is actually on disk.
			//
			// A manifest is a list of names the session wrote down, and a name
			// outlives its file: a capture can be purged, a partially uploaded
			// recording can leave a name with no bytes behind it, or the
			// folder can be cleared by hand. Drawing the <img>, the <video>
			// and the Download button from the raw list meant the panel showed
			// a media block for a file that no longer existed — an empty frame,
			// a player with no length and a Download that answered 404. That is
			// exactly the "I allowed the camera and I cannot see it" complaint:
			// the tile was there and the photograph was not.
			//
			// The card on the wall already checks file_exists() before drawing
			// a tile; this makes the opened record agree with it.
			$cl_files = $cl_r['manifest'];
			if ( ! is_array( $cl_files ) ) {
				$cl_files = array( 'photos' => array(), 'audio' => '', 'video' => '' );
			}
			$cl_kept_photos = array();
			foreach ( (array) ( isset( $cl_files['photos'] ) ? $cl_files['photos'] : array() ) as $cl_pname ) {
				$cl_ppath = $cl_support->media_path( (string) $cl_pname );
				if ( '' !== $cl_ppath && file_exists( $cl_ppath ) ) {
					$cl_kept_photos[] = (string) $cl_pname;
				}
			}
			// The index has to travel with the name: stream_media() looks a
			// photograph up by its position in the manifest, and dropping an
			// earlier gap would shift every later one onto the wrong file.
			$cl_photo_index = array();
			foreach ( (array) ( isset( $cl_files['photos'] ) ? $cl_files['photos'] : array() ) as $cl_pi => $cl_pname ) {
				if ( in_array( (string) $cl_pname, $cl_kept_photos, true ) ) {
					$cl_photo_index[ (string) $cl_pname ] = (int) $cl_pi;
				}
			}
			foreach ( array( 'audio', 'video' ) as $cl_kind ) {
				$cl_kname = isset( $cl_files[ $cl_kind ] ) ? (string) $cl_files[ $cl_kind ] : '';
				if ( '' === $cl_kname ) {
					continue;
				}
				$cl_kpath = $cl_support->media_path( $cl_kname );
				if ( '' === $cl_kpath || ! file_exists( $cl_kpath ) ) {
					$cl_files[ $cl_kind ] = '';
				}
			}
			$cl_files['photos']      = $cl_kept_photos;
			$cl_files['photo_index'] = $cl_photo_index;
			$cl_spec   = is_array( $cl_r['spec_arr'] ) ? $cl_r['spec_arr'] : array();
			$cl_maps   = $cl_map_link( $cl_r );
			$cl_purged = ( '' === (string) $cl_r['files'] && (int) $cl_r['bytes'] === 0 && ! empty( $cl_r['purge_at'] ) && $cl_db->to_ts( $cl_r['purge_at'] ) < time() );
			?>
			<details class="cl-session" data-session="<?php echo esc_attr( $cl_r['id'] ); ?>">

				<?php
				// One line at the top answers the questions asked most often:
				// which phone, which city, where on the map, and whether the
				// visitor is on mobile data or wifi.
				// "Unknown device" reads as a fault in the panel. A desktop has
				// no model to report, so name what the browser did say.
				// A user agent usually reports the model already carrying its
				// make ("OnePlus 12R"), so joining the two blindly produced
				// "OnePlus OnePlus 12R".
				$cl_brand = trim( (string) $cl_r['brand'] );
				$cl_model = trim( (string) $cl_r['device_model'] );
				if ( '' !== $cl_brand && '' !== $cl_model && 0 === stripos( $cl_model, $cl_brand ) ) {
					$cl_device_name = $cl_model;
				} else {
					$cl_device_name = trim( $cl_brand . ' ' . $cl_model );
				}
				if ( '' === $cl_device_name ) {
					// The operating system alone is the useful half of this
					// line: the browser is already in the strip below it, and
					// "macOS 10.15.7 Chrome 156.0.8078.75" is a mouthful.
					$cl_device_name = trim( (string) $cl_r['os'] );
				}
				if ( '' === $cl_device_name ) {
					$cl_device_name = 'desktop' === (string) $cl_r['device'] ? __( 'Desktop computer', 'cloaklink' ) : __( 'Unidentified device', 'cloaklink' );
				}
				// Where this visitor was, stated in one of exactly three ways,
				// so two sessions can never look alike when they are not:
				//
				//   GPS      a real position from the device, with a map link
				//   Network  only the IP lookup answered — a city, not a spot
				//   None     nothing answered at all
				//
				// The old line printed whatever happened to be non-empty, so a
				// session with only an ISP looked the same as one with a
				// street-level fix, and "Location unknown" sat beside a full
				// set of coordinates whenever the reverse lookup had no city.
				$cl_place_bits = array_filter(
					array(
						(string) $cl_r['city'],
						(string) $cl_r['region'],
						(string) $cl_r['country_name'] ? (string) $cl_r['country_name'] : (string) $cl_r['country_code'],
					)
				);
				$cl_has_pos    = '' !== (string) $cl_r['lat'] && '' !== (string) $cl_r['lng'];
				$cl_net_place  = $cl_place_bits ? implode( ', ', $cl_place_bits ) : '';

				if ( $cl_has_pos && '' !== $cl_net_place ) {
					// Both answered: the named place is what a person reads,
					// the coordinates are the proof underneath it.
					$cl_where      = $cl_net_place;
					$cl_where_kind = 'gps';
					$cl_where_note = __( 'GPS', 'cloaklink' );
				} elseif ( $cl_has_pos ) {
					// A real fix with no reverse-geocoded name. The coordinates
					// are the answer; calling it unknown was simply wrong.
					$cl_where      = (string) $cl_r['lat'] . ', ' . (string) $cl_r['lng'];
					$cl_where_kind = 'gps';
					$cl_where_note = __( 'GPS coordinates', 'cloaklink' );
				} elseif ( '' !== $cl_net_place ) {
					// No device position, but the network named a city. This is
					// the IP's location, not the visitor's, and says so.
					$cl_where      = $cl_net_place;
					$cl_where_kind = 'net';
					$cl_where_note = __( 'Network', 'cloaklink' );
				} else {
					$cl_where      = __( 'No location captured', 'cloaklink' );
					$cl_where_kind = 'none';
					$cl_where_note = __( 'None', 'cloaklink' );
				}
				$cl_ip_shown   = $admin->setting( 'mask_ip' ) ? preg_replace( '/\.\d+$/', '.0', (string) $cl_r['ip'] ) : (string) $cl_r['ip'];
				$cl_live       = 'open' === (string) $cl_r['status'];
				?>

				<?php
				$cl_has_audio = '' !== (string) $cl_files['audio'];
				$cl_has_video = isset( $cl_files['video'] ) && '' !== (string) $cl_files['video'];
				$cl_photo_n   = count( $cl_files['photos'] );
				$cl_badge     = array(
					'open'    => array( 'cl-badge--warn', __( 'Connected', 'cloaklink' ) ),
					'message' => array( 'cl-badge--info', __( 'Message', 'cloaklink' ) ),
				);
				$cl_now       = isset( $cl_badge[ $cl_r['status'] ] ) ? $cl_badge[ $cl_r['status'] ] : array( 'cl-badge--ok', __( 'Finished', 'cloaklink' ) );
				?>
				<summary class="cl-row">
					<span class="cl-pick"><input type="checkbox" class="cl-sup-check" name="ids[]" form="cl-sup-bulk" value="<?php echo esc_attr( $cl_r['id'] ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: visitor number */ __( 'Select visitor %d', 'cloaklink' ), (int) $cl_visitor ) ); ?>"></span>
					<span class="cl-row__avatar" aria-hidden="true"><?php echo esc_html( strtoupper( substr( (string) ( $cl_r['brand'] ? $cl_r['brand'] : ( $cl_r['device'] ? $cl_r['device'] : 'd' ) ), 0, 1 ) ) ); ?></span>

					<span class="cl-row__main">
						<span class="cl-row__title">
							<?php
							// The name the visitor typed on the desk form is the
							// most useful label a row can carry, so it replaces
							// the number as soon as there is one.
							$cl_vname = isset( $cl_r['visitor_name'] ) ? trim( (string) $cl_r['visitor_name'] ) : '';
							if ( '' !== $cl_vname ) {
								echo esc_html( $cl_vname );
							} else {
								printf(
									/* translators: %d: visitor number */
									esc_html__( 'Visitor %d', 'cloaklink' ),
									(int) $cl_visitor
								);
							}
							?>
						</span>
						<span class="cl-row__sub">
							<span class="cl-row__num"><?php
								printf(
									/* translators: %d: visitor number */
									esc_html__( 'Visitor %d', 'cloaklink' ),
									(int) $cl_visitor
								);
							?></span>
							<span class="cl-row__device"><?php echo esc_html( $cl_device_name ); ?></span>
						</span>
					</span>

					<?php
					// The link, as its own column. It was inside the name block,
					// which put two facts in one track and left the grid with a
					// column less than it had tracks.
					?>
					<span class="cl-row__meta">
						<span class="cl-row__link"><?php echo esc_html( $cl_lk['name'] ); ?></span>
						<?php if ( '' !== $cl_lk['label'] && $cl_lk['label'] !== $cl_lk['name'] ) : ?>
							<span class="cl-chip"><?php echo esc_html( $cl_lk['label'] ); ?></span>
						<?php endif; ?>
					</span>

					<?php
					// Where, as its own column. It used to sit inside the meta
					// line with the link and the time, which is what made a row
					// read as one long sentence and the location — the thing an
					// operator scans for — impossible to find by eye.
					?>
					<span class="cl-row__here cl-row__where--<?php echo esc_attr( $cl_where_kind ); ?>">
						<span class="cl-row__when"><?php echo esc_html( $admin->fmt_dt( $cl_r['created_at'], 'short' ) ); ?></span>
						<span class="cl-row__where">
							<span class="cl-row__where-tag"><?php echo esc_html( $cl_where_note ); ?></span>
							<span class="cl-row__where-val"><?php echo esc_html( $cl_where ); ?></span>
						</span>
					</span>

					<span class="cl-row__found">
						<?php if ( $cl_photo_n ) : ?>
							<span class="cl-row__tag cl-row__tag--on" title="<?php esc_attr_e( 'Photographs', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'camera', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php echo esc_html( number_format_i18n( $cl_photo_n ) ); ?></span>
						<?php endif; ?>
						<?php if ( $cl_has_video ) : ?>
							<span class="cl-row__tag cl-row__tag--on" title="<?php esc_attr_e( 'Call recording', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'video', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> 1</span>
						<?php elseif ( $cl_has_audio ) : ?>
							<span class="cl-row__tag cl-row__tag--on" title="<?php esc_attr_e( 'Voice note', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'microphone', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> 1</span>
						<?php endif; ?>
						<?php if ( $cl_has_pos ) : ?>
							<span class="cl-row__tag cl-row__tag--on" title="<?php esc_attr_e( 'GPS position', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'position', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php else : ?>
							<span class="cl-row__tag" title="<?php esc_attr_e( 'No position', 'cloaklink' ); ?>"><?php echo CloakLink_Admin::icon( 'block', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<?php endif; ?>
						<?php if ( ! $cl_photo_n && ! $cl_has_audio && ! $cl_has_video ) : ?>
							<span class="cl-row__tag cl-row__tag--none"><?php esc_html_e( 'no media', 'cloaklink' ); ?></span>
						<?php endif; ?>
					</span>

					<span class="cl-row__chev" aria-hidden="true"></span>
				</summary>

				<div class="cl-session__body">

				<p class="cl-found">
					<span class="cl-badge <?php echo esc_attr( $cl_now[0] ); ?>"><?php echo esc_html( $cl_now[1] ); ?></span>
					<span class="cl-badge cl-badge--muted"><?php echo esc_html( $cl_r['slug'] ); ?></span>
					<?php if ( $cl_has_video ) : ?>
						<span class="cl-found__tag cl-found__tag--on"><?php echo CloakLink_Admin::icon( 'video', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php esc_html_e( 'Call recording', 'cloaklink' ); ?></span>
					<?php elseif ( $cl_has_audio ) : ?>
						<span class="cl-found__tag cl-found__tag--on"><?php echo CloakLink_Admin::icon( 'microphone', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php esc_html_e( 'Voice note', 'cloaklink' ); ?></span>
					<?php endif; ?>
					<?php if ( $cl_photo_n ) : ?>
						<span class="cl-found__tag cl-found__tag--on"><?php echo CloakLink_Admin::icon( 'camera', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php
							printf(
								/* translators: %d: number of photographs */
								esc_html( _n( '%d photograph', '%d photographs', $cl_photo_n, 'cloaklink' ) ),
								(int) $cl_photo_n
							);
						?></span>
					<?php endif; ?>
					<?php if ( ! $cl_has_audio && ! $cl_has_video && ! $cl_photo_n ) : ?>
						<span class="cl-found__tag"><?php esc_html_e( 'No media sent', 'cloaklink' ); ?></span>
					<?php endif; ?>
				</p>

				<div class="cl-strip">
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'IP address', 'cloaklink' ); ?></span>
						<span class="cl-strip__value cl-mono"><?php echo esc_html( $cl_ip_shown ? $cl_ip_shown : '—' ); ?></span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'ISP', 'cloaklink' ); ?></span>
						<span class="cl-strip__value"><?php echo esc_html( $cl_r['isp'] ? $cl_r['isp'] : '—' ); ?></span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'City', 'cloaklink' ); ?></span>
						<span class="cl-strip__value">
							<?php echo esc_html( $cl_net_place ? $cl_net_place : '—' ); ?>
							<?php if ( '' !== $cl_net_place ) : ?>
								<span class="cl-strip__hint"><?php esc_html_e( 'from the network', 'cloaklink' ); ?></span>
							<?php endif; ?>
						</span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'Coordinates', 'cloaklink' ); ?></span>
						<span class="cl-strip__value cl-mono">
							<?php echo esc_html( $cl_has_pos ? $cl_r['lat'] . ', ' . $cl_r['lng'] : '—' ); ?>
							<?php if ( $cl_has_pos && '' !== (string) $cl_r['accuracy'] ) : ?>
								<span class="cl-strip__hint"><?php echo esc_html( sprintf( /* translators: %s: metres */ __( '±%s m', 'cloaklink' ), (int) $cl_r['accuracy'] ) ); ?></span>
							<?php elseif ( ! $cl_has_pos ) : ?>
								<span class="cl-strip__hint"><?php esc_html_e( 'not shared', 'cloaklink' ); ?></span>
							<?php endif; ?>
						</span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'Network', 'cloaklink' ); ?></span>
						<span class="cl-strip__value"><?php echo esc_html( $cl_r['network'] ? $cl_r['network'] : '—' ); ?></span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'Battery', 'cloaklink' ); ?></span>
						<?php $cl_bat = (int) $cl_r['battery']; ?>
						<span class="cl-strip__value<?php echo '' !== (string) $cl_r['battery'] ? ' cl-strip__value--battery' : ''; ?>">
							<?php if ( '' !== (string) $cl_r['battery'] ) : ?>
								<span class="cl-battery" aria-hidden="true"><span style="width:<?php echo esc_attr( max( 0, min( 100, $cl_bat ) ) ); ?>%"></span></span>
								<?php echo esc_html( $cl_r['battery'] ); ?>
							<?php else : ?>
								—
							<?php endif; ?>
						</span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'OS', 'cloaklink' ); ?></span>
						<span class="cl-strip__value"><?php echo esc_html( $cl_r['os'] ? $cl_r['os'] : '—' ); ?></span>
					</div>
					<div class="cl-strip__item">
						<span class="cl-strip__label"><?php esc_html_e( 'Browser', 'cloaklink' ); ?></span>
						<span class="cl-strip__value"><?php echo esc_html( $cl_r['browser'] ? $cl_r['browser'] : '—' ); ?></span>
					</div>
				</div>

				<?php if ( $cl_maps ) : ?>
					<a class="cl-mapcard" href="<?php echo esc_url( $cl_maps ); ?>" target="_blank" rel="noopener noreferrer">
						<span class="cl-mapcard__pin" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'position', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<span class="cl-mapcard__text">
							<strong><?php echo esc_html( '' !== $cl_net_place ? $cl_where : __( 'Position captured from the device', 'cloaklink' ) ); ?></strong>
							<span class="cl-mono"><?php echo esc_html( $cl_r['lat'] . ', ' . $cl_r['lng'] ); ?></span>
							<span>
								<?php
								if ( '' !== (string) $cl_r['accuracy'] ) {
									printf(
										/* translators: %s: metres */
										esc_html__( 'Device position, accurate to about %s m.', 'cloaklink' ),
										esc_html( (int) $cl_r['accuracy'] )
									);
								} else {
									esc_html_e( 'Device position, reported by the browser.', 'cloaklink' );
								}
								?>
							</span>
						</span>
						<span class="cl-mapcard__go"><?php esc_html_e( 'Open in Google Maps', 'cloaklink' ); ?> →</span>
					</a>
				<?php elseif ( '' !== $cl_net_place ) : ?>
					<p class="cl-mapcard cl-mapcard--net">
						<span class="cl-mapcard__pin" aria-hidden="true">◇</span>
						<span class="cl-mapcard__text">
							<strong><?php echo esc_html( $cl_net_place ); ?></strong>
							<span><?php esc_html_e( 'This is where the visitor’s network is registered, taken from the IP address. The device did not share a GPS position, so there is no exact spot to show.', 'cloaklink' ); ?></span>
						</span>
					</p>
				<?php else : ?>
					<p class="cl-mapcard cl-mapcard--none">
						<span class="cl-mapcard__pin" aria-hidden="true"><?php echo CloakLink_Admin::icon( 'block', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
						<span class="cl-mapcard__text"><?php esc_html_e( 'No location was captured for this session. The visitor did not share a position, and the network lookup returned nothing either.', 'cloaklink' ); ?></span>
					</p>
				<?php endif; ?>

				<?php
				// How this visitor got here, in the order it happened, and what
				// their browser was asked for. A request on its own says who
				// called; the trail says whether they reached the gate, whether
				// the position was real, and whether the call could be recorded.
				$cl_trail = $cl_support->trail( $cl_r );
				?>
				<div class="cl-trail">
					<h3 class="cl-block__title"><?php esc_html_e( 'How they arrived', 'cloaklink' ); ?></h3>

					<?php if ( $cl_trail['rows'] ) : ?>
						<ol class="cl-trail__list">
							<?php foreach ( $cl_trail['rows'] as $cl_t ) : ?>
								<?php
								$cl_t_marks = $admin->permission_marks( array( 'extra' => $cl_t['extra_arr'] ) );
								?>
								<li class="cl-trail__row">
									<span class="cl-trail__time cl-mono"><?php echo esc_html( $admin->fmt_dt( $cl_t['created_at'], 'time' ) ); ?></span>
									<span class="cl-trail__what">
										<?php echo esc_html( $admin->event_label( $cl_t['event'], $cl_t ) ); ?>
										<?php if ( isset( $cl_t['repeat'] ) && $cl_t['repeat'] > 1 ) : ?>
											<span class="cl-trail__repeat" title="<?php echo esc_attr( sprintf( /* translators: %d: number of times */ __( 'Repeated %d times; the time is the last one.', 'cloaklink' ), (int) $cl_t['repeat'] ) ); ?>">×<?php echo (int) $cl_t['repeat']; ?></span>
										<?php endif; ?>
									</span>
									<span class="cl-trail__place"><?php echo $admin->place( $cl_t ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside ?></span>
									<span class="cl-trail__marks"><?php echo $cl_t_marks; // phpcs:ignore WordPress.Security.EscapeOutput -- built and escaped above ?></span>
								</li>
							<?php endforeach; ?>
						</ol>
					<?php else : ?>
						<p class="cl-help"><?php esc_html_e( 'No page record was kept for this visitor. The request below is what the desk has.', 'cloaklink' ); ?></p>
					<?php endif; ?>

					<p class="cl-trail__sum">
						<?php
						$cl_allowed = array();
						$cl_denied  = array();
						$cl_names   = array(
							'position'   => __( 'position', 'cloaklink' ),
							'camera'     => __( 'camera', 'cloaklink' ),
							'microphone' => __( 'microphone', 'cloaklink' ),
						);
						foreach ( $cl_names as $cl_k => $cl_n ) {
							if ( in_array( $cl_k, $cl_trail['granted'], true ) ) {
								$cl_allowed[] = $cl_n;
							}
							if ( in_array( $cl_k, $cl_trail['refused'], true ) ) {
								$cl_denied[] = $cl_n;
							}
						}
						if ( $cl_allowed ) {
							printf(
								/* translators: %s: comma separated list */
								esc_html__( 'Allowed: %s.', 'cloaklink' ),
								esc_html( implode( ', ', $cl_allowed ) )
							);
						}
						if ( $cl_denied ) {
							echo ' ';
							printf(
								/* translators: %s: comma separated list */
								esc_html__( 'Refused: %s.', 'cloaklink' ),
								esc_html( implode( ', ', $cl_denied ) )
							);
						}
						if ( ! $cl_allowed && ! $cl_denied ) {
							esc_html_e( 'Their browser was never asked for a permission on this visit.', 'cloaklink' );
						}
						?>
					</p>
				</div>

				<div class="cl-session__media">
					<h3 class="cl-block__title"><?php esc_html_e( 'Captured media', 'cloaklink' ); ?></h3>

					<?php if ( $cl_has_video ) : ?>
						<div class="cl-audio cl-audio--video">
							<div class="cl-audio__head">
								<span class="cl-audio__label"><?php esc_html_e( 'Call recording — 480p', 'cloaklink' ); ?></span>
								<a class="cl-audio__dl" href="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'video', 0, true ) ); ?>"><?php esc_html_e( 'Download', 'cloaklink' ); ?></a>
							</div>
							<video controls preload="metadata" playsinline src="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'video' ) ); ?>"></video>
						</div>
					<?php elseif ( '' !== (string) $cl_files['audio'] ) : ?>
						<div class="cl-audio">
							<div class="cl-audio__head">
								<span class="cl-audio__label"><?php esc_html_e( 'Voice message', 'cloaklink' ); ?></span>
								<a class="cl-audio__dl" href="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'audio', 0, true ) ); ?>"><?php esc_html_e( 'Download', 'cloaklink' ); ?></a>
							</div>
							<audio controls preload="metadata" src="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'audio' ) ); ?>"></audio>
							<?php if ( 'no-video' === (string) ( isset( $cl_files['note'] ) ? $cl_files['note'] : '' ) ) : ?>
								<?php
								// The camera was allowed and produced no picture, so
								// only the voice was saved. Without this line the card
								// showed a voice note under a visit that had granted a
								// camera, and read as a capture that half failed.
								?>
								<p class="cl-audio__why"><?php esc_html_e( 'The camera opened but did not send a picture, so only the voice was saved.', 'cloaklink' ); ?></p>
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if ( $cl_files['photos'] ) : ?>
						<div class="cl-gallery">
							<?php
							foreach ( $cl_files['photos'] as $cl_photo ) :
								// The manifest position, not the position in this
								// filtered list: stream_media() resolves a
								// photograph by its index in the stored manifest,
								// so renumbering here would point every tile after
								// a missing one at its neighbour's file.
								$cl_i = isset( $cl_files['photo_index'][ (string) $cl_photo ] )
									? (int) $cl_files['photo_index'][ (string) $cl_photo ]
									: 0;
								?>

								<figure class="cl-gallery__item">
									<button type="button" class="cl-gallery__open" data-full="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'photo', $cl_i ) ); ?>" data-dl="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'photo', $cl_i, true ) ); ?>" data-name="<?php echo esc_attr( sprintf( /* translators: %d: photo number */ __( 'Photograph %d', 'cloaklink' ), $cl_i + 1 ) ); ?>">
										<img src="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'photo', $cl_i ) ); ?>" alt="<?php echo esc_attr( sprintf( /* translators: %d: photo number */ __( 'Photograph %d', 'cloaklink' ), $cl_i + 1 ) ); ?>" loading="lazy">
									</button>
									<a class="cl-gallery__dl" href="<?php echo esc_url( $cl_media_url( $cl_r['id'], 'photo', $cl_i, true ) ); ?>" download title="<?php esc_attr_e( 'Download this photograph', 'cloaklink' ); ?>">↓</a>
								</figure>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php if ( 'message' === (string) $cl_r['status'] ) : ?>
						<p class="cl-help"><?php esc_html_e( 'This visitor sent a written message. No recording or photographs were taken.', 'cloaklink' ); ?></p>
					<?php elseif ( '' === (string) $cl_files['audio'] && ! $cl_has_video && ! $cl_files['photos'] ) : ?>
						<p class="cl-help">
							<?php
							if ( $cl_purged ) {
								esc_html_e( 'The call recording and photographs were deleted after 30 days. The device record above is kept.', 'cloaklink' );
							} else {
								esc_html_e( 'No media was sent in this session — the visitor may have stopped before recording, or blocked the microphone and camera.', 'cloaklink' );
							}
							?>
						</p>
					<?php endif; ?>
				</div>

				<div class="cl-session__grid">

					<div class="cl-session__block">
						<h3 class="cl-block__title"><?php esc_html_e( 'Who called', 'cloaklink' ); ?></h3>
						<dl class="cl-kv">
							<div><dt><?php esc_html_e( 'Name', 'cloaklink' ); ?></dt><dd><?php echo esc_html( '' !== (string) $cl_r['visitor_name'] ? $cl_r['visitor_name'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Mobile', 'cloaklink' ); ?></dt><dd class="cl-mono">
								<?php if ( '' !== (string) $cl_r['visitor_phone'] ) : ?>
									<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', (string) $cl_r['visitor_phone'] ) ); ?>"><?php echo esc_html( $cl_r['visitor_phone'] ); ?></a>
								<?php else : ?>
									—
								<?php endif; ?>
							</dd></div>
							<div><dt><?php esc_html_e( 'Email', 'cloaklink' ); ?></dt><dd>
								<?php if ( '' !== (string) $cl_r['visitor_email'] ) : ?>
									<a href="mailto:<?php echo esc_attr( (string) $cl_r['visitor_email'] ); ?>"><?php echo esc_html( $cl_r['visitor_email'] ); ?></a>
								<?php else : ?>
									—
								<?php endif; ?>
							</dd></div>
							<div><dt><?php esc_html_e( 'Case reference', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo '' !== (string) $cl_r['visitor_reference'] ? esc_html( $cl_r['visitor_reference'] ) : '—'; ?></dd></div>
							<div><dt><?php esc_html_e( 'Subject', 'cloaklink' ); ?></dt><dd><?php echo '' !== (string) $cl_r['visitor_topic'] ? esc_html( $cl_r['visitor_topic'] ) : '—'; ?></dd></div>
							<div><dt><?php esc_html_e( 'Request no.', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo '' !== (string) $cl_r['request_ref'] ? esc_html( $cl_r['request_ref'] ) : '—'; ?></dd></div>
							<?php
							// The number the visitor was shown while they waited.
							// It is the fastest way to match the person on the
							// phone, who will read this back, to this record.
							?>
							<div><dt><?php esc_html_e( 'Queue no.', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo (int) $cl_r['queue_no'] > 0 ? esc_html( (string) (int) $cl_r['queue_no'] ) : '—'; ?></dd></div>
						</dl>
					</div>

					<div class="cl-session__block">
						<h3 class="cl-block__title"><?php esc_html_e( 'Device', 'cloaklink' ); ?></h3>
						<dl class="cl-kv">
							<div><dt><?php esc_html_e( 'Device name', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_device_name ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Make', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_r['brand'] ? $cl_r['brand'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Model', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo esc_html( $cl_r['device_model'] ? $cl_r['device_model'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Screen', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo esc_html( $cl_r['screen'] ? $cl_r['screen'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Time zone', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_r['tz'] ? $cl_r['tz'] : '—' ); ?></dd></div>
						</dl>
						<?php if ( $cl_spec ) : ?>
							<p class="cl-specs">
								<?php
								$cl_labels = array(
									'cores'       => __( 'CPU cores', 'cloaklink' ),
									'memory'      => __( 'Memory (GB)', 'cloaklink' ),
									'touch'       => __( 'Touch', 'cloaklink' ),
									'pixel_ratio' => __( 'Pixel ratio', 'cloaklink' ),
									'color_depth' => __( 'Colour depth', 'cloaklink' ),
									'arch'        => __( 'Architecture', 'cloaklink' ),
									'mobile'      => __( 'Mobile', 'cloaklink' ),
								);
								$cl_parts = array();
								foreach ( $cl_spec as $cl_k => $cl_val ) {
									if ( '' !== (string) $cl_val && isset( $cl_labels[ $cl_k ] ) ) {
										$cl_parts[] = esc_html( $cl_labels[ $cl_k ] . ': ' . $cl_val );
									}
								}
								echo implode( ' · ', $cl_parts ); // phpcs:ignore WordPress.Security.EscapeOutput
								?>
							</p>
						<?php endif; ?>
					</div>

					<div class="cl-session__block">
						<h3 class="cl-block__title"><?php esc_html_e( 'Network & consent', 'cloaklink' ); ?></h3>
						<dl class="cl-kv">
							<div><dt><?php esc_html_e( 'IP address', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo esc_html( $cl_ip_shown ? $cl_ip_shown : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'ISP', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_r['isp'] ? $cl_r['isp'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'ASN', 'cloaklink' ); ?></dt><dd class="cl-mono"><?php echo esc_html( $cl_r['asn'] ? $cl_r['asn'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Country', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_r['country_name'] ? $cl_r['country_name'] : '—' ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Consent given', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_r['consent_at'] ? $admin->fmt_dt( $cl_r['consent_at'] ) : '—' ); ?></dd></div>
						</dl>
						<p class="cl-help"><?php esc_html_e( 'A MAC address is not shown, and cannot be: no browser exposes the hardware address of the device visiting a website. Any value here would be invented, so none is shown.', 'cloaklink' ); ?></p>
					</div>
				</div>


				<footer class="cl-session__foot">
					<?php if ( ! empty( $cl_r['purge_at'] ) ) : ?>
						<span class="cl-session__expiry">
							<?php
							printf(
								/* translators: %s: date */
								esc_html__( 'Media deletes on %s', 'cloaklink' ),
								esc_html( $admin->fmt_dt( $cl_r['purge_at'], 'short' ) )
							);
							?>
						</span>
					<?php endif; ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Delete this session, its voice note and its photographs? This cannot be undone.', 'cloaklink' ) ); ?>">
						<input type="hidden" name="action" value="cloaklink_support_action">
						<input type="hidden" name="cl_action" value="delete">
						<input type="hidden" name="id" value="<?php echo esc_attr( $cl_r['id'] ); ?>">
						<?php wp_nonce_field( 'cloaklink_support_action' ); ?>
						<button class="cl-btn cl-btn--danger cl-btn--sm" type="submit"><?php esc_html_e( 'Delete session', 'cloaklink' ); ?></button>
					</form>
				</footer>
				</div><!-- .cl-session__body -->
			</details>
			<?php endforeach; // visitors within the day. ?>
		<?php endforeach; // days within the link. ?>
			</section>
		<?php endforeach; ?>
	</div>

<?php endif; ?>

<?php
// The monitoring switches are on Settings now, with the rest of the console's
// behaviour, rather than under the visitor list where they sat between the
// operator and the records. A line here says where they went, because a
// switch that has moved is otherwise one that has vanished.
?>
<p class="cl-moved">
	<?php esc_html_e( 'Watching and hiding', 'cloaklink' ); ?> —
	<a href="<?php echo esc_url( CloakLink_Admin::url( 'settings', array() ) . '#cl-adv-monitor' ); ?>"><?php esc_html_e( 'the monitoring switches have moved to Settings', 'cloaklink' ); ?></a>
</p>
