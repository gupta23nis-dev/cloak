<?php
/**
 * Tools: exports, diagnostics, maintenance.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_stats  = $cl_db->global_stats();
$cl_audit  = $links->audit( 25 );
$cl_base   = $settings->base_url();
$cl_page   = (int) $settings->get( 'link_page_id' );

// Does the stored rule set actually route a link? Read from the array's own
// keys, which is where a pattern lives — the query value is the other half
// and either match is enough to know the rule is present.
$cl_rules = get_option( 'rewrite_rules' );
$cl_rules_have_slug = false;
// The base path is the operator's to change, so the check reads it rather
// than looking for the literal "go/". A site that renamed the path to
// "notice" used to be told its routing was broken when it was working.
$cl_base = trim( (string) $settings->get( 'base_path' ), '/' );
if ( '' === $cl_base ) {
	$cl_base = 'go';
}
foreach ( (array) $cl_rules as $cl_rule_key => $cl_rule_query ) {
	if ( false !== strpos( (string) $cl_rule_query, 'cloaklink_slug' ) ) {
		$cl_rules_have_slug = true;
		break;
	}
}
$cl_checks = array(
	array(
		'label' => __( 'Pretty permalinks', 'cloaklink' ),
		'ok'    => (bool) get_option( 'permalink_structure' ),
		'note'  => get_option( 'permalink_structure' ) ? get_option( 'permalink_structure' ) : __( 'Plain permalinks are on: links will still work as /?cloaklink_slug=code. Set Permalinks to “Post name” for clean links.', 'cloaklink' ),
	),
	array(
		'label' => __( 'Holder page', 'cloaklink' ),
		'ok'    => $cl_page && get_post( $cl_page ),
		'note'  => $cl_page ? get_permalink( $cl_page ) : __( 'Missing — save settings to recreate', 'cloaklink' ),
	),
	array(
		'label' => __( 'Link routing', 'cloaklink' ),
		// rewrite_rules is an array of pattern => query. Casting it to a
		// string yields the word "Array", so the old check could never find
		// the rule and reported "NOT WORKING" on every healthy install — the
		// one screen an operator opens when links have stopped resolving was
		// the one that always said they had.
		'ok'    => (bool) $cl_rules_have_slug,
		'note'  => $cl_rules_have_slug
			? sprintf( /* translators: %s: base path */ __( 'Active — /%s/<code> is matched by WordPress', 'cloaklink' ), trim( (string) $settings->get( 'base_path' ), '/' ) )
			: __( 'NOT WORKING — links open the theme’s 404 page and nothing is recorded. Press “Rebuild permalinks” below.', 'cloaklink' ),
	),
	array(
		'label' => __( 'Live reachability', 'cloaklink' ),
		// The rules table can be right while the host still answers 404, so
		// this one fetches a real link over HTTP and reports what came back.
		'ok'    => ( function () {
			$h = get_option( 'cloaklink_route_health' );
			return is_array( $h ) && ! empty( $h['ok'] );
		} )(),
		'note'  => ( function () {
			$h = get_option( 'cloaklink_route_health' );
			if ( ! is_array( $h ) ) {
				return __( 'Not checked yet — it runs on the next request after this page.', 'cloaklink' );
			}
			if ( null === $h['ok'] ) {
				return sprintf( /* translators: %s: URL */ __( 'Could not reach %s from the server. That may be a firewall or a loopback block, not a broken link.', 'cloaklink' ), (string) $h['url'] );
			}
			if ( $h['ok'] ) {
				return sprintf( /* translators: 1: HTTP code, 2: URL */ __( 'HTTP %1$d — %2$s reaches WordPress. A recipient opening it will see the link, not a 404.', 'cloaklink' ), (int) $h['code'], (string) $h['url'] );
			}
			return sprintf(
				/* translators: 1: HTTP code, 2: URL */
				__( 'HTTP %1$d on %2$s. The link exists but your server is not passing that address to WordPress — set Permalinks to “Post name”, save, then press Rebuild permalinks.', 'cloaklink' ),
				(int) $h['code'],
				(string) $h['url']
			);
		} )(),
	),
	array(
		'label' => __( 'Table prefix', 'cloaklink' ),
		'ok'    => true,
		'note'  => $cl_db->links_table(),
	),
	array(
		'label' => __( 'Outbound HTTP', 'cloaklink' ),
		'ok'    => ! ( defined( 'WP_HTTP_BLOCK_EXTERNAL' ) && WP_HTTP_BLOCK_EXTERNAL ),
		'note'  => defined( 'WP_HTTP_BLOCK_EXTERNAL' ) && WP_HTTP_BLOCK_EXTERNAL ? __( 'WP_HTTP_BLOCK_EXTERNAL is on: IP lookup and geocoding will not work', 'cloaklink' ) : __( 'Available — IP lookup and reverse geocoding enabled', 'cloaklink' ),
	),
	array(
		'label' => __( 'Daily maintenance', 'cloaklink' ),
		'ok'    => (bool) wp_next_scheduled( CloakLink_Cron::HOOK ),
		'note'  => wp_next_scheduled( CloakLink_Cron::HOOK ) ? wp_date( 'd M Y, g:i A', wp_next_scheduled( CloakLink_Cron::HOOK ), $admin->tz() ) : __( 'Not scheduled', 'cloaklink' ),
	),
);
?>

<div class="cl-grid cl-grid--2">

	<section class="cl-panel">
		<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Download data', 'cloaklink' ); ?></h2></header>
		<div class="cl-panel__body">
			<p class="cl-help"><?php esc_html_e( 'Every export reflects the current filters on this page (all links unless you came from a filtered view). Files open in Excel, Pages or Word, and any PDF reader.', 'cloaklink' ); ?></p>
			<div class="cl-exports">
				<?php
				foreach ( array(
					'csv' => array( __( 'CSV', 'cloaklink' ), __( 'Raw rows for spreadsheets and BI tools', 'cloaklink' ) ),
					'xls' => array( __( 'Excel', 'cloaklink' ), __( 'Styled workbook with summary sheet', 'cloaklink' ) ),
					'doc' => array( __( 'Word', 'cloaklink' ), __( 'Formatted report for case files', 'cloaklink' ) ),
					'pdf' => array( __( 'PDF', 'cloaklink' ), __( 'Print-ready evidence report', 'cloaklink' ) ),
				) as $cl_fmt => $cl_meta ) :
					$cl_url = wp_nonce_url(
						add_query_arg( array( 'cloaklink_export' => 1, 'format' => $cl_fmt ), CloakLink_Admin::admin_base() ),
						'cloaklink_export'
					);
					?>
					<a class="cl-export-card" href="<?php echo esc_url( $cl_url ); ?>">
						<span class="cl-export-card__fmt"><?php echo esc_html( $cl_meta[0] ); ?></span>
						<span class="cl-export-card__desc"><?php echo esc_html( $cl_meta[1] ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
			<div class="cl-inline cl-inline--gap">
				<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'cloaklink_export' => 1, 'format' => 'csv', 'scope' => 'links' ), CloakLink_Admin::admin_base() ), 'cloaklink_export' ) ); ?>"><?php esc_html_e( 'Links CSV', 'cloaklink' ); ?></a>
				<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'cloaklink_export' => 1, 'format' => 'xls', 'scope' => 'links' ), CloakLink_Admin::admin_base() ), 'cloaklink_export' ) ); ?>"><?php esc_html_e( 'Links Excel', 'cloaklink' ); ?></a>
				<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'cloaklink_export' => 1, 'format' => 'csv', 'scope' => 'blocks' ), CloakLink_Admin::admin_base() ), 'cloaklink_export' ) ); ?>"><?php esc_html_e( 'Blocklist CSV', 'cloaklink' ); ?></a>
			</div>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Health check', 'cloaklink' ); ?></h2></header>
		<div class="cl-panel__body cl-panel__body--flush">
			<ul class="cl-checks">
				<?php foreach ( $cl_checks as $cl_c ) : ?>
					<li class="cl-checks__row">
						<span class="cl-checks__dot<?php echo $cl_c['ok'] ? ' is-ok' : ' is-bad'; ?>"></span>
						<span class="cl-checks__label"><?php echo esc_html( $cl_c['label'] ); ?></span>
						<span class="cl-checks__note"><?php echo esc_html( $cl_c['note'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
			<div class="cl-panel__pad">
				<div class="cl-inline cl-inline--gap">
					<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'cloaklink_flush', 1, CloakLink_Admin::url( 'tools' ) ), 'cloaklink_flush' ) ); ?>"><?php esc_html_e( 'Rebuild permalinks', 'cloaklink' ); ?></a>
					<button type="button" class="cl-btn cl-btn--ghost cl-btn--sm" id="cl-test-geo"><?php esc_html_e( 'Test my IP lookup', 'cloaklink' ); ?></button>
				</div>
				<pre class="cl-json" id="cl-test-geo-out" hidden></pre>
				<p class="cl-help"><?php echo esc_html( sprintf( /* translators: %s: URL */ __( 'Public base: %s', 'cloaklink' ), $cl_base . '/{slug}' ) ); ?></p>
			</div>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Data footprint', 'cloaklink' ); ?></h2></header>
		<div class="cl-panel__body">
			<dl class="cl-facts">
				<dt><?php esc_html_e( 'Visit rows', 'cloaklink' ); ?></dt><dd><?php echo esc_html( number_format_i18n( $cl_stats['visits_total'] ) ); ?></dd>
				<dt><?php esc_html_e( 'Links', 'cloaklink' ); ?></dt><dd><?php echo esc_html( number_format_i18n( $cl_stats['links_total'] ) ); ?></dd>
				<dt><?php esc_html_e( 'Retention', 'cloaklink' ); ?></dt><dd><?php echo esc_html( sprintf( /* translators: %s: days */ __( '%s days', 'cloaklink' ), number_format_i18n( (int) $settings->get( 'retention_days' ) ) ) ); ?></dd>
				<dt><?php esc_html_e( 'Last visit', 'cloaklink' ); ?></dt><dd><?php echo esc_html( $cl_stats['last_visit'] ? $admin->fmt_dt( $cl_stats['last_visit'] ) : '—' ); ?></dd>
			</dl>
		</div>
	</section>

	<section class="cl-panel" id="cl-media-health">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Media health', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note"><?php esc_html_e( 'What is on disk, what the database points at, and where the two disagree.', 'cloaklink' ); ?></p>
		</header>
		<div class="cl-panel__body">
			<?php
			// Measured on every read, not cached.
			//
			// A stored verdict goes stale the moment retention runs or a host
			// restores a folder, and a health panel whose number is a day old
			// is worse than none — it tells an operator "all fine" about a
			// directory they have just lost. The walk is over a folder holding
			// one entry per capture, so it is cheap.
			$cl_mh = $admin->media_health();
			?>
			<dl class="cl-facts">
				<dt><?php esc_html_e( 'Files in the folder', 'cloaklink' ); ?></dt>
				<dd><?php echo esc_html( number_format_i18n( $cl_mh['disk_count'] ) ); ?></dd>

				<dt><?php esc_html_e( 'Files the database names', 'cloaklink' ); ?></dt>
				<dd><?php echo esc_html( number_format_i18n( $cl_mh['ref_count'] ) ); ?></dd>

				<dt><?php esc_html_e( 'Named but missing', 'cloaklink' ); ?></dt>
				<dd class="<?php echo $cl_mh['missing'] ? 'cl-bad' : 'cl-good'; ?>">
					<?php echo esc_html( number_format_i18n( $cl_mh['missing'] ) ); ?>
					<?php if ( $cl_mh['missing'] ) : ?>
						<span class="cl-help"><?php esc_html_e( 'Records still name these, but the bytes are gone. Cards say so rather than hiding it.', 'cloaklink' ); ?></span>
					<?php endif; ?>
				</dd>

				<dt><?php esc_html_e( 'On disk but unreferenced', 'cloaklink' ); ?></dt>
				<dd class="<?php echo $cl_mh['orphan'] ? 'cl-warn' : 'cl-good'; ?>">
					<?php echo esc_html( number_format_i18n( $cl_mh['orphan'] ) ); ?>
					<?php if ( $cl_mh['orphan'] ) : ?>
						<span class="cl-help"><?php esc_html_e( 'Nothing points at these. They are kept, never deleted here — the repair below only ever writes references, never removes a file.', 'cloaklink' ); ?></span>
					<?php endif; ?>
				</dd>

				<dt><?php esc_html_e( 'Total size', 'cloaklink' ); ?></dt>
				<dd><?php echo esc_html( size_format( max( 0, (int) $cl_mh['bytes'] ), 1 ) ); ?></dd>

				<dt><?php esc_html_e( 'Oldest capture', 'cloaklink' ); ?></dt>
				<dd><?php echo esc_html( $cl_mh['oldest'] ? $admin->fmt_dt( $cl_mh['oldest'] ) : '—' ); ?></dd>

				<dt><?php esc_html_e( 'Newest capture', 'cloaklink' ); ?></dt>
				<dd><?php echo esc_html( $cl_mh['newest'] ? $admin->fmt_dt( $cl_mh['newest'] ) : '—' ); ?></dd>
			</dl>

			<?php if ( ! $cl_mh['reachable'] ) : ?>
				<p class="cl-help cl-bad"><?php esc_html_e( 'The folder cannot be reached, so everything above reads zero. Check that the uploads folder exists and is writable before trusting these numbers.', 'cloaklink' ); ?></p>
			<?php endif; ?>

			<?php if ( $cl_mh['orphan'] ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cl-actions">
					<input type="hidden" name="action" value="cloaklink_media_repair">
					<?php wp_nonce_field( 'cloaklink_media_repair' ); ?>
					<button type="submit" class="cl-btn cl-btn--ghost">
						<?php esc_html_e( 'Re-attach unreferenced files to their session', 'cloaklink' ); ?>
					</button>
					<span class="cl-help"><?php esc_html_e( 'Names each stray file from the session number in its own name. It never deletes, and never overwrites a reference that already exists.', 'cloaklink' ); ?></span>
				</form>
			<?php endif; ?>
		</div>
	</section>

	<section class="cl-panel" id="cl-headers">
		<header class="cl-panel__head">
			<h2 class="cl-panel__title"><?php esc_html_e( 'Browser hardening', 'cloaklink' ); ?></h2>
			<p class="cl-panel__note"><?php esc_html_e( 'The headers this site sends on a panel page, read from this request rather than assumed.', 'cloaklink' ); ?></p>
		</header>
		<div class="cl-panel__body">
			<?php
			// Read from the response this request is about to send, not from a
			// list of what the plugin intends.
			//
			// A header added in one file can be stripped by a host, a caching
			// proxy or a security plugin — and the panel would go on claiming
			// it. Asking PHP for the list it currently holds is the only
			// answer that means anything, and "not sent" is then reported as
			// not sent.
			$cl_hdrs    = function_exists( 'headers_list' ) ? (array) headers_list() : array();
			$cl_have    = array();
			foreach ( $cl_hdrs as $cl_h ) {
				$cl_parts = explode( ':', (string) $cl_h, 2 );
				if ( count( $cl_parts ) === 2 ) {
					$cl_have[ strtolower( trim( $cl_parts[0] ) ) ] = trim( $cl_parts[1] );
				}
			}
			$cl_want = array(
				'x-frame-options'        => __( 'Stops another site framing the panel and catching your clicks.', 'cloaklink' ),
				'x-content-type-options' => __( 'Stops a browser treating a served file as a different kind of file.', 'cloaklink' ),
				'referrer-policy'        => __( 'Stops the panel address being sent to any site a link points at.', 'cloaklink' ),
				'content-security-policy' => __( 'Names where the panel may be framed from, and forbids plug-ins and a rewritten base address.', 'cloaklink' ),
				'permissions-policy'     => __( 'Limits camera, microphone and location to this site.', 'cloaklink' ),
			);
			?>
			<dl class="cl-facts">
				<?php foreach ( $cl_want as $cl_hk => $cl_why ) : ?>
					<dt><?php echo esc_html( $cl_hk ); ?></dt>
					<dd class="<?php echo isset( $cl_have[ $cl_hk ] ) ? 'cl-good' : 'cl-bad'; ?>">
						<?php echo esc_html( isset( $cl_have[ $cl_hk ] ) ? $cl_have[ $cl_hk ] : __( 'Not sent on this request', 'cloaklink' ) ); ?>
						<span class="cl-help"><?php echo esc_html( $cl_why ); ?></span>
					</dd>
				<?php endforeach; ?>
				<dt>strict-transport-security</dt>
				<dd class="<?php echo isset( $cl_have['strict-transport-security'] ) ? 'cl-good' : 'cl-warn'; ?>">
					<?php
					echo esc_html(
						isset( $cl_have['strict-transport-security'] )
							? $cl_have['strict-transport-security']
							: __( 'Not sent — this request is not over HTTPS, and the header would be ignored on a plain-http page.', 'cloaklink' )
					);
					?>
				</dd>
			</dl>
			<p class="cl-help">
				<?php
				printf(
					/* translators: %s: server software */
					esc_html__( 'Reported by %s for this very request. A header shown as not sent is either a plain-http page (the last row) or something between the site and the browser is removing it — a host’s proxy or a security plug-in is the usual cause.', 'cloaklink' ),
					esc_html( isset( $_SERVER['SERVER_SOFTWARE'] ) ? (string) wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) : PHP_SAPI )
				);
				?>
			</p>
		</div>
	</section>

	<section class="cl-panel">
		<header class="cl-panel__head"><h2 class="cl-panel__title"><?php esc_html_e( 'Audit trail', 'cloaklink' ); ?></h2></header>
		<div class="cl-panel__body cl-panel__body--flush">
			<?php if ( $cl_audit ) : ?>
				<ul class="cl-audit">
					<?php foreach ( $cl_audit as $cl_a ) : ?>
						<li class="cl-audit__row">
							<span class="cl-audit__time"><?php echo esc_html( $cl_a['time'] ); ?></span>
							<span class="cl-audit__action"><?php echo esc_html( str_replace( '_', ' ', $cl_a['action'] ) ); ?></span>
							<span class="cl-audit__meta"><?php echo esc_html( get_the_author_meta( 'display_name', (int) $cl_a['user'] ) ); ?><?php echo ! empty( $cl_a['link_id'] ) ? ' · #' . esc_html( $cl_a['link_id'] ) : ''; ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="cl-empty"><?php esc_html_e( 'No changes recorded yet.', 'cloaklink' ); ?></p>
			<?php endif; ?>
		</div>
	</section>
</div>
