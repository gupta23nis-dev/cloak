<?php
/**
 * Visitor log with filters and paging.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification
$cl_f = array(
	'link_id' => CloakLink_Admin::current_id(),
	'event'   => isset( $_GET['event'] ) ? sanitize_key( wp_unslash( $_GET['event'] ) ) : '',
	'device'  => isset( $_GET['device'] ) ? sanitize_key( wp_unslash( $_GET['device'] ) ) : '',
	'country' => isset( $_GET['country'] ) ? strtoupper( sanitize_key( wp_unslash( $_GET['country'] ) ) ) : '',
	'from'    => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
	'to'      => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
	'search'  => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
	'risk_min'=> isset( $_GET['risk'] ) ? absint( $_GET['risk'] ) : 0,
	'paged'   => isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1,
);
// phpcs:enable WordPress.Security.NonceVerification

$cl_per   = 50;
$cl_rows  = $cl_db->get_visits(
	array(
		'link_id'  => $cl_f['link_id'],
		'event'    => $cl_f['event'],
		'device'   => $cl_f['device'],
		'country'  => $cl_f['country'],
		'from'     => $cl_f['from'],
		'to'       => $cl_f['to'],
		'search'   => $cl_f['search'],
		'risk_min' => $cl_f['risk_min'],
		'per_page' => $cl_per,
		'page'     => $cl_f['paged'],
	)
);
$cl_total  = $cl_db->count_visits( $cl_f );
$cl_pages  = max( 1, (int) ceil( $cl_total / $cl_per ) );
$cl_links  = $cl_db->link_options();
$cl_events = array(
	''        => __( 'Every event', 'cloaklink' ),
	'view'    => __( 'Viewed', 'cloaklink' ),
	'open'    => __( 'Opened', 'cloaklink' ),
	'blocked' => __( 'Blocked', 'cloaklink' ),
);
?>

<div class="cl-toolbar cl-toolbar--wrap">
	<form class="cl-filters" method="get" action="<?php echo esc_url( CloakLink_Admin::admin_base() ); ?>">
		<input type="hidden" name="cl_page" value="visits">

		<label data-label="<?php esc_attr_e( 'Link', 'cloaklink' ); ?>">
		<select name="id" class="cl-input cl-input--sm">
			<option value="0"><?php esc_html_e( 'All links', 'cloaklink' ); ?></option>
			<?php foreach ( $cl_links as $cl_o ) : ?>
				<option value="<?php echo esc_attr( $cl_o['id'] ); ?>" <?php selected( $cl_f['link_id'], (int) $cl_o['id'] ); ?>><?php echo esc_html( $cl_o['label'] ? $cl_o['label'] . ' — ' . $cl_o['slug'] : $cl_o['title'] ); ?></option>
			<?php endforeach; ?>
		</select>
		</label>

		<label data-label="<?php esc_attr_e( 'Event', 'cloaklink' ); ?>">
		<select name="event" class="cl-input cl-input--sm">
			<?php foreach ( $cl_events as $cl_k => $cl_lbl ) : ?>
				<option value="<?php echo esc_attr( $cl_k ); ?>" <?php selected( $cl_f['event'], $cl_k ); ?>><?php echo esc_html( $cl_lbl ); ?></option>
			<?php endforeach; ?>
		</select>
		</label>

		<label data-label="<?php esc_attr_e( 'Device', 'cloaklink' ); ?>">
		<select name="device" class="cl-input cl-input--sm">
			<option value=""><?php esc_html_e( 'Any device', 'cloaklink' ); ?></option>
			<?php foreach ( array( 'mobile' => __( 'Mobile', 'cloaklink' ), 'tablet' => __( 'Tablet', 'cloaklink' ), 'desktop' => __( 'Desktop', 'cloaklink' ), 'bot' => __( 'Bot', 'cloaklink' ) ) as $cl_k => $cl_lbl ) : ?>
				<option value="<?php echo esc_attr( $cl_k ); ?>" <?php selected( $cl_f['device'], $cl_k ); ?>><?php echo esc_html( $cl_lbl ); ?></option>
			<?php endforeach; ?>
		</select>
		</label>

		<label data-label="<?php esc_attr_e( 'Country', 'cloaklink' ); ?>">
		<input class="cl-input cl-input--sm" type="text" name="country" value="<?php echo esc_attr( $cl_f['country'] ); ?>" placeholder="<?php esc_attr_e( 'IN', 'cloaklink' ); ?>" maxlength="2" style="max-width:64px">
		</label>
		<label data-label="<?php esc_attr_e( 'From', 'cloaklink' ); ?>">
		<input class="cl-input cl-input--sm" type="date" name="from" value="<?php echo esc_attr( $cl_f['from'] ); ?>">
		</label>
		<label data-label="<?php esc_attr_e( 'To', 'cloaklink' ); ?>">
		<input class="cl-input cl-input--sm" type="date" name="to" value="<?php echo esc_attr( $cl_f['to'] ); ?>">
		</label>
		<label data-label="<?php esc_attr_e( 'Search', 'cloaklink' ); ?>">
		<input class="cl-input cl-input--sm" type="search" name="s" value="<?php echo esc_attr( $cl_f['search'] ); ?>" placeholder="<?php esc_attr_e( 'IP, city, ISP', 'cloaklink' ); ?>">
		</label>
		<label data-label="<?php esc_attr_e( 'Risk', 'cloaklink' ); ?>">
		<select name="risk" class="cl-input cl-input--sm">
			<option value="0"><?php esc_html_e( 'Any risk', 'cloaklink' ); ?></option>
			<option value="30" <?php selected( $cl_f['risk_min'], 30 ); ?>><?php esc_html_e( '30+ risk', 'cloaklink' ); ?></option>
			<option value="60" <?php selected( $cl_f['risk_min'], 60 ); ?>><?php esc_html_e( '60+ risk', 'cloaklink' ); ?></option>
		</select>
		</label>
		<button type="submit" class="cl-btn cl-btn--gold"><?php esc_html_e( 'Apply', 'cloaklink' ); ?></button>
		<a class="cl-btn cl-btn--ghost" href="<?php echo esc_url( CloakLink_Admin::url( 'visits' ) ); ?>"><?php esc_html_e( 'Reset', 'cloaklink' ); ?></a>
	</form>
</div>

<div class="cl-toolbar cl-toolbar--end">
	<p class="cl-countline"><?php echo esc_html( sprintf( /* translators: 1: shown, 2: total */ __( 'Showing %1$s of %2$s events', 'cloaklink' ), number_format_i18n( count( $cl_rows ) ), number_format_i18n( $cl_total ) ) ); ?></p>
	<div class="cl-export">
		<span class="cl-export__label"><?php esc_html_e( 'Export', 'cloaklink' ); ?>:</span>
		<?php
		$cl_q = array_intersect_key( $cl_f, array_flip( array( 'link_id', 'event', 'device', 'country', 'from', 'to', 'search', 'risk_min' ) ) );
		foreach ( array( 'csv' => 'CSV', 'xls' => 'Excel', 'doc' => 'Word', 'pdf' => 'PDF' ) as $cl_fmt => $cl_lbl ) :
			$cl_exp_url = wp_nonce_url(
				add_query_arg(
					array_merge( array( 'cloaklink_export' => 1, 'format' => $cl_fmt ), $cl_q ),
					admin_url( 'admin-post.php' )
				),
				'cloaklink_export'
			);
			?>
			<a class="cl-btn cl-btn--ghost cl-btn--sm" href="<?php echo esc_url( $cl_exp_url ); ?>"><?php echo esc_html( $cl_lbl ); ?></a>
		<?php endforeach; ?>
	</div>
</div>

<section class="cl-panel">
	<div class="cl-panel__body cl-panel__body--flush">
		<div class="cl-table-wrap">
			<table class="cl-table cl-table--live">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Time', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Event / link', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Device', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Location', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'GPS', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Network', 'cloaklink' ); ?></th>
						<th><?php esc_html_e( 'Risk & flags', 'cloaklink' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					if ( $cl_rows ) {
						foreach ( $cl_rows as $cl_row ) {
							echo $admin->visit_row_html( $cl_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
					} else {
						echo '<tr><td colspan="7" class="cl-empty">' . esc_html__( 'Nothing matches these filters.', 'cloaklink' ) . '</td></tr>';
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</section>

<?php if ( $cl_pages > 1 ) : ?>
	<div class="cl-pager">
		<?php for ( $cl_i = 1; $cl_i <= min( 12, $cl_pages ); $cl_i++ ) : ?>
			<a class="cl-pager__num<?php echo $cl_i === $cl_f['paged'] ? ' is-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'paged', $cl_i ) ); ?>"><?php echo esc_html( $cl_i ); ?></a>
		<?php endfor; ?>
		<?php if ( $cl_pages > 12 ) : ?>
			<span class="cl-muted">… <?php echo esc_html( $cl_pages ); ?></span>
		<?php endif; ?>
	</div>
<?php endif; ?>
