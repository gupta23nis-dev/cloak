<?php
/**
 * The case desk's front door.
 *
 * A split screen: the service on the left, the form on the right. The left
 * half exists because a person who has been told "use the case desk" arrives
 * at an address they do not recognise, on a machine they may not own, and the
 * first thing they need is to be sure they are in the right place. It states
 * what the desk is and how many things it is currently holding — nothing
 * about accounts, nothing about people.
 *
 * Nothing here says which usernames exist. A wrong name and a wrong password
 * are one answer, and the access code is one more field on the same card
 * rather than a second screen: at a desk, the person signing in already knows
 * whether they were given a code, and a screen that decides for them is a
 * screen that can be wrong.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_agents = isset( $GLOBALS['cl_agents'] ) ? $GLOBALS['cl_agents'] : cloaklink()->agents;
$cl_brand  = cloaklink()->router->brand();
$cl_name   = isset( $cl_brand['name'] ) && '' !== trim( (string) $cl_brand['name'] ) ? (string) $cl_brand['name'] : 'Credit Control';
list( $cl_kind, $cl_notice ) = $cl_agents->login_notice();

// No count of the office is read here at all. The screen is reachable by
// anybody who is given the address, so a ticket total on it would be a
// statement about the operator's work to a person who has not signed in.
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#0a1118">
<title><?php echo esc_html( sprintf( /* translators: %s: site name */ __( 'Case desk — %s', 'cloaklink' ), $cl_name ) ); ?></title>
<?php
// The tab mark. A desk that shows the install's WordPress logo in the tab
// is a desk nobody can find among ten open tabs.
$cl_icon_src = CLOAKLINK_URL . 'assets/img/logo.png';
$cl_icon_ver = '';
if ( defined( 'CLOAKLINK_PATH' ) && file_exists( CLOAKLINK_PATH . 'assets/img/logo.png' ) ) {
	$cl_icon_ver = (string) filemtime( CLOAKLINK_PATH . 'assets/img/logo.png' );
}
?>
<link rel="icon" href="<?php echo esc_url( $cl_icon_src . ( $cl_icon_ver ? '?v=' . $cl_icon_ver : '' ) ); ?>" sizes="any">
<link rel="apple-touch-icon" href="<?php echo esc_url( $cl_icon_src ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/agent.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-intel.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-signal.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body class="cl-login cl-login--desk">

<div class="clx-door">

	<!-- What this place is -->
	<aside class="clx-door__side">
		<div class="clx-door__grid" aria-hidden="true"></div>

		<div class="clx-door__brand">
			<span class="clx-door__seal"><?php echo CloakLink_Admin::logo( '', 44 ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in logo(). ?></span>
			<span class="clx-door__names">
				<b><?php echo esc_html( $cl_name ); ?></b>
				<i><?php esc_html_e( 'Case desk', 'cloaklink' ); ?></i>
			</span>
		</div>

		<?php
		// Nothing about the office is printed before somebody has signed in.
		//
		// This half of the door used to carry three numbers — how many tickets
		// exist, how many are waiting, and how many people are on the desk —
		// and any of them was a statement about the office to a person who had
		// not asked for one. The address is not secret; anybody who is given
		// it, or who guesses it, reaches this screen. It now says what the
		// place is and asks for the details, and nothing else.
		?>

		<p class="clx-door__foot">
			<span class="clx-dot" aria-hidden="true"></span>
			<?php
			// One fact, and a true one: the desk logs sign-ins and sign-outs.
			echo esc_html( sprintf( /* translators: %s: date */ __( 'Sign-in recorded · %s', 'cloaklink' ), wp_date( 'j M Y' ) ) );
			?>
		</p>
	</aside>

	<!-- The form -->
	<main class="clx-door__main">
		<div class="clx-door__card">

			<div class="clx-door__head">
				<span class="clx-door__mark"><?php echo CloakLink_Admin::logo( '', 34 ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in logo(). ?></span>
				<div>
					<h2><?php esc_html_e( 'Sign in', 'cloaklink' ); ?></h2>
					<p><?php esc_html_e( 'The details the operator gave you.', 'cloaklink' ); ?></p>
				</div>
			</div>

			<?php if ( '' !== $cl_notice ) : ?>
				<p class="clx-note clx-note--<?php echo esc_attr( $cl_kind ); ?>" role="<?php echo 'error' === $cl_kind ? 'alert' : 'status'; ?>"><?php echo esc_html( $cl_notice ); ?></p>
			<?php endif; ?>

			<?php
			// Post back to the address this form was served on.
			//
			// The configured sign-in address is a clean path. On a host that
			// does not route clean paths that address is a 404, so the page
			// appeared and the password was sent to a page that does not
			// exist — the desk looked like it had broken the moment somebody
			// pressed Sign in. Whatever address reached this form is known to
			// answer, so that is where the form goes back to.
			$cl_post_to = $cl_agents->served_url();
			?>
			<form class="clx-form" method="post" action="<?php echo esc_url( $cl_post_to ); ?>" autocomplete="off">
				<input type="hidden" name="cl_agent_action" value="signin">
				<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>

				<div class="clx-field">
					<label class="clx-label" for="cl-user"><?php esc_html_e( 'Username', 'cloaklink' ); ?></label>
					<input class="clx-input" id="cl-user" name="cl_user" type="text" required autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="username" placeholder="<?php esc_attr_e( 'your.username', 'cloaklink' ); ?>">
				</div>

				<div class="clx-field">
					<label class="clx-label" for="cl-pass"><?php esc_html_e( 'Password', 'cloaklink' ); ?></label>
					<div class="clx-pass">
						<input class="clx-input" id="cl-pass" name="cl_pass" type="password" required autocomplete="current-password" placeholder="••••••••">
						<button class="clx-eye" type="button" data-eye="cl-pass" aria-label="<?php esc_attr_e( 'Show the password', 'cloaklink' ); ?>">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="2.8"/></svg>
						</button>
					</div>
				</div>

				<div class="clx-field">
					<label class="clx-label" for="cl-code">
						<?php esc_html_e( 'Access code', 'cloaklink' ); ?>
						<span class="clx-label__opt"><?php esc_html_e( 'if you were given one', 'cloaklink' ); ?></span>
					</label>
					<input class="clx-input clx-input--code" id="cl-code" name="cl_code" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="one-time-code" placeholder="••••••">
				</div>

				<button class="clx-submit" type="submit">
					<span><?php esc_html_e( 'Open the desk', 'cloaklink' ); ?></span>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg>
				</button>
			</form>

			<p class="clx-door__help">
				<?php esc_html_e( 'No sign-in? Ask the operator to create your account.', 'cloaklink' ); ?>
			</p>
		</div>
	</main>
</div>

<script>
(function () {
	'use strict';
	// One button, one job: let the person see what they typed. A password field
	// on a shared machine is where typos get blamed on the keyboard.
	document.querySelectorAll('[data-eye]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var box = document.getElementById(btn.getAttribute('data-eye'));
			if (!box) {
				return;
			}
			var shown = box.type === 'text';
			box.type = shown ? 'password' : 'text';
			btn.classList.toggle('is-on', !shown);
			btn.setAttribute('aria-label', shown ? 'Show the password' : 'Hide the password');
			box.focus();
		});
	});

	// The code field takes digits only, and a paste of a whole code lands.
	var code = document.getElementById('cl-code');
	if (code) {
		code.addEventListener('input', function () {
			var v = code.value.replace(/\D/g, '').slice(0, 6);
			if (v !== code.value) {
				code.value = v;
			}
		});
	}
})();
</script>
</body>
</html>
