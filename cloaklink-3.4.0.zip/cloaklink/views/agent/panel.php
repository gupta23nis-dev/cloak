<?php
/**
 * The agent's own desk.
 *
 * What a person may do here is deliberately small: raise a ticket, read what
 * its link captured, and — if the operator made them an admin on this desk —
 * allow or hold any ticket and copy its link. They cannot see another
 * agent's tickets, they cannot see the operator's links, and there is nothing
 * on this screen that changes how the plugin works.
 *
 * The captured data is the operator's, shown to the person who raised the
 * ticket and only for that ticket's link. Nothing is cached on this side, so
 * when the operator deletes the ticket or its link the rows and their evidence
 * are gone from here on the next load.
 *
 * Three ideas hold the layout together:
 *
 *   1. The queue is a column on the left and the ticket is the rest of the
 *      page. Reading one is the job; the list is how you get to it.
 *   2. Colour says what a record is before any of its words are read.
 *   3. Every count on the page is a count of real rows read in this request.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_agents = isset( $GLOBALS['cl_agents'] ) ? $GLOBALS['cl_agents'] : cloaklink()->agents;
$cl_agent  = isset( $GLOBALS['cl_agent'] ) ? $GLOBALS['cl_agent'] : $cl_agents->current();

if ( ! $cl_agent ) {
	return;
}

$cl_db    = cloaklink()->db;
$cl_brand = cloaklink()->router->brand();
$cl_name  = isset( $cl_brand['name'] ) && '' !== trim( (string) $cl_brand['name'] ) ? (string) $cl_brand['name'] : 'Credit Control';

// Tickets raised by this person, whoever they are.
//
// A desk "admin" is trusted with how the desk is run; they are not the
// office, and the queue is not theirs. Showing them everybody's cases put
// another agent's visitor on their screen — the exact thing the desk is
// supposed to prevent — so the list, the records under it and the buttons on
// it are now the same for every role. The only thing the role still buys is
// the word Admin beside the person's name.
$cl_is_admin = $cl_agents->is_admin( $cl_agent );
$cl_tickets  = $cl_agents->tickets_for( (int) $cl_agent['id'], false );
$cl_adv      = cloaklink()->adv;
$cl_prefs    = $cl_adv->prefs( (int) $cl_agent['id'] );
// Said on the desk itself now that the ten personal settings live here.
$cl_ok       = isset( $_GET['cl_ok'] ) ? sanitize_key( wp_unslash( $_GET['cl_ok'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

// The ticket open on this load. An id in the address must be in the set this
// person may read, or it is ignored — that check is the whole access rule on
// this screen, and it is made against the list, not against the database.
$cl_open = isset( $_GET['cl_ticket'] ) ? absint( $_GET['cl_ticket'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$cl_view = null;
if ( $cl_open ) {
	foreach ( $cl_tickets as $cl_one ) {
		if ( (int) $cl_one['id'] === $cl_open ) {
			$cl_view = $cl_one;
			break;
		}
	}
}
if ( ! $cl_view && $cl_tickets ) {
	$cl_view = $cl_tickets[0];
}

list( $cl_kind, $cl_notice ) = $cl_agents->login_notice();

// Nothing is read for a ticket the operator has not allowed. The query is not
// run at all rather than run and then hidden: a record that never leaves the
// database cannot be leaked by a later template change.
$cl_allowed = $cl_view ? $cl_agents->is_allowed( $cl_view ) : false;
// An admin-role person may work a queue they did not raise, but the evidence
// under a case belongs to the person who opened it. `$cl_owns` is what decides
// whether this screen may read anything at all; a ticket that is merely on the
// queue shows its facts and its controls and no records.
$cl_owns    = $cl_view ? $cl_agents->may_read( $cl_view, $cl_agent ) : false;
$cl_caps    = ( $cl_allowed && $cl_owns ) ? $cl_agents->captures_for_ticket( $cl_view, 60, $cl_agent ) : array();
$cl_media   = ( $cl_allowed && $cl_owns ) ? $cl_agents->media_for_ticket( $cl_view, 12, $cl_agent ) : array();

// Counts for the strip. Everything here comes from the rows already in hand;
// the only extra read is the per-link capture count, which is one query for
// the whole set.
$cl_pending = 0;
$cl_live    = 0;
$cl_links   = array();
$cl_linked  = 0;
// The links the office has allowed, one per ticket. This is the number the
// desk shows under Tracing as "Devices": an agent only ever sees the links
// that were released to them, never the office's whole set, so a person with
// two allowed tickets reads "2 Devices" and not the site's total.
$cl_active_links = 0;
foreach ( $cl_tickets as $cl_t ) {
	if ( $cl_agents->is_allowed( $cl_t ) ) {
		$cl_linked++;
		$cl_links[] = (int) $cl_t['link_id'];
		$cl_active_links++;
	} else {
		$cl_pending++;
	}
}
$cl_counts = $cl_agents->capture_counts( $cl_links );
foreach ( $cl_counts as $cl_n ) {
	$cl_live += (int) $cl_n;
}

// How many records this ticket carries, so the panel header can say it before
// the list is scrolled.
$cl_here = count( $cl_caps );

// The network picture for this ticket's own records. It is given the rows
// this person is allowed to read and nothing else, so the map can no more
// leak another agent's case than the list beside it — a mast lights because a
// record in hand fell under it, not because a query went looking.
$cl_tower_html = $cl_owns ? cloaklink()->admin->tower_map_html( $cl_caps ) : '';

$cl_emoji = array(
	'position'   => '📍',
	'camera'     => '📸',
	'microphone' => '🎙️',
	'video'      => '🎥',
);
$cl_labels = array(
	'position'   => __( 'Location', 'cloaklink' ),
	'camera'     => __( 'Camera', 'cloaklink' ),
	'microphone' => __( 'Mic', 'cloaklink' ),
	'video'      => __( 'Recording', 'cloaklink' ),
);

// The desk's own monitoring view.
//
// Everything below the ticket: what has come in across every released ticket
// this person may read, newest first, and one row per visitor so a name can be
// pressed to see only that person's records. It is the same data the ticket
// panel above shows, read the other way round — by time and by person rather
// than by case — because those are the two questions somebody working a desk
// actually asks.
// Enough for a history, not a screenful.
//
// Forty was applied before the grouping, so a person who opened the link
// thirty times saw only the part of their thirty that fitted inside
// everybody's newest forty. The window is where "show me everything about
// this visitor" is answered, so it gets the whole set the desk may read.
$cl_recent = $cl_agents->recent_for( $cl_agent, 400 );

// The file, as opposed to the working list.
//
// `recent_for` is the monitoring view: it is what the ✕ on a row and a whole
// selection act on, so a row cleared there disappears from it. That is right
// for a list somebody prunes while working — and wrong for the record of what
// came back. "All records" is that record: the same released tickets, read
// without the cleared rows taken out, so clearing a notification never
// deletes anything from the file.
$cl_records = $cl_agents->records_for( $cl_agent, 40 );

// Where a card's name goes when it is pressed on the desk.
//
// The console has a full record page. The desk does not, and must not link at
// the console's: an agent is not a WordPress user, so that address is a
// sign-in screen they cannot pass. The desk's equivalent is the ticket the
// record belongs to — the fullest thing this person is allowed to read — and
// on the wall it is also where the file itself is drawn. Cards whose row
// carries no ticket get no link rather than a dead one.
$cl_desk_record = function ( $visit_id ) use ( $cl_agents, $cl_recent, $cl_records ) {
	foreach ( array( $cl_records, $cl_recent ) as $cl_set ) {
		foreach ( (array) $cl_set as $cl_one ) {
			if ( (int) $cl_one['id'] === (int) $visit_id && ! empty( $cl_one['cl_ticket']['id'] ) ) {
				return $cl_agents->screen_url( 'panel', array( 'cl_ticket' => (int) $cl_one['cl_ticket']['id'] ) ) . '#clx-shared';
			}
		}
	}
	return '';
};

// Joining facts that repeat themselves.
//
// A visit row states the place as city, region and country, and the region
// often carries the city again: "Bengaluru, Bengaluru, Karnataka, India". The
// handset is the same — brand, model, system and browser overlap, so the same
// words come back twice in one line. Merging several clicks of one person made
// this visible on every card, so every part is split — on commas and on the
// middots the device line uses — and repeated words are dropped once.
$cl_join = function ( $parts, $sep = ', ' ) use ( &$cl_join ) {
	$out   = array();
	$seen  = array();
	foreach ( (array) $parts as $part ) {
		foreach ( preg_split( '/\s*[,·]\s*/u', (string) $part ) as $bit ) {
			$bit = trim( $bit );
			if ( '' === $bit ) {
				continue;
			}
			$key = mb_strtolower( $bit );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = $bit;
		}
	}
	return implode( $sep, $out );
};

// The board's numbers, read off the same rows the monitoring list draws.
//
// Every one of them is a count of a row already in hand for a ticket this
// person raised, so a number on the board can always be found as a line in
// the list below it — and nothing here can count another agent's case,
// because `recent_for` was never given any.
$cl_tally = array( 'position' => 0, 'camera' => 0, 'microphone' => 0, 'video' => 0 );
$cl_flagged = 0;
$cl_hour = 0;
$cl_hour_floor = time() - HOUR_IN_SECONDS;
foreach ( $cl_recent as $cl_b ) {
	$cl_bcap = $cl_db->capture_of( $cl_b );
	foreach ( array_keys( $cl_tally ) as $cl_bk ) {
		if ( ! empty( $cl_bcap[ $cl_bk ] ) ) {
			$cl_tally[ $cl_bk ]++;
		}
	}
	if ( (int) $cl_b['risk'] >= 40 ) {
		$cl_flagged++;
	}
	if ( $cl_db->to_ts( (string) $cl_b['created_at'] ) >= $cl_hour_floor ) {
		$cl_hour++;
	}
}
$cl_tally_total = array_sum( $cl_tally );

// Who, in one pass. The key is the name the visitor gave, or their city when
// they gave none — a person may open a link twice without typing anything, and
// grouping those together by the place they were in is more useful than
// forty nameless rows.
$cl_people = array();
foreach ( $cl_recent as $cl_r ) {
	// A visit row has no visitor name of its own — that belongs to a support
	// session — so the name used here is the name on the ticket the record
	// came from, which is the person the link was about. The city stands in
	// only when the ticket has no name, which cannot happen with a ticket
	// raised on this desk but can with an older row.
	$cl_who = isset( $cl_r['cl_ticket']['person'] ) ? trim( (string) $cl_r['cl_ticket']['person'] ) : '';
	if ( '' === $cl_who ) {
		$cl_who = trim( (string) $cl_r['city'] );
	}
	if ( '' === $cl_who ) {
		$cl_who = __( 'Unnamed visitor', 'cloaklink' );
	}
	$cl_key = mb_strtolower( $cl_who );
	if ( ! isset( $cl_people[ $cl_key ] ) ) {
		$cl_people[ $cl_key ] = array(
			'name'    => $cl_who,
			'count'   => 0,
			'kinds'   => array(),
			'last'    => '',
			'tickets' => array(),
			'places'  => array(),
			'devices' => array(),
			'ips'     => array(),
			'phones'  => array(),
			'rows'    => array(),
		);
	}
	$cl_people[ $cl_key ]['count']++;
	$cl_cap_r = $cl_db->capture_of( $cl_r );
	foreach ( $cl_emoji as $cl_k => $cl_e ) {
		if ( ! empty( $cl_cap_r[ $cl_k ] ) ) {
			$cl_people[ $cl_key ]['kinds'][ $cl_k ] = true;
		}
	}
	if ( '' === $cl_people[ $cl_key ]['last'] ) {
		$cl_people[ $cl_key ]['last'] = (string) $cl_r['created_at'];
	}
	$cl_people[ $cl_key ]['tickets'][ (int) $cl_r['cl_ticket']['id'] ] = (string) $cl_r['cl_ticket']['ref'];

	// Everything the window will say about this person, gathered in the same
	// pass as the count. The places, devices and addresses are sets because a
	// visitor who opened the link three times gave the same answer three
	// times: printing it three times would read as three facts.
	// Each fact on its own, deduplicated across clicks.
	//
	// Storing whole lines and deduplicating those was not enough: two clicks
	// list the same handset in a different order, so the lines differed while
	// naming exactly the same things and the card printed the handset twice.
	// The parts are what repeat, so the parts are what is kept.
	foreach ( array( (string) $cl_r['city'], (string) $cl_r['region'], (string) $cl_r['country_name'] ) as $cl_r_part ) {
		$cl_r_part = trim( $cl_r_part );
		if ( '' !== $cl_r_part ) {
			$cl_people[ $cl_key ]['places'][ mb_strtolower( $cl_r_part ) ] = $cl_r_part;
		}
	}
	// The handset first, then the system and the browser: a person reading a
	// card wants "iPhone 14" before "Safari", and the whole line fits once the
	// repeats are gone.
	foreach ( array( (string) $cl_r['device_model'], (string) $cl_r['brand'], (string) $cl_r['os'], (string) $cl_r['browser'] ) as $cl_r_part ) {
		$cl_r_part = trim( $cl_r_part );
		if ( '' !== $cl_r_part ) {
			$cl_people[ $cl_key ]['devices'][ mb_strtolower( $cl_r_part ) ] = $cl_r_part;
		}
	}
	$cl_r_ip = trim( (string) $cl_r['ip'] );
	if ( '' !== $cl_r_ip ) {
		$cl_people[ $cl_key ]['ips'][ $cl_r_ip ] = true;
	}
	$cl_r_ph = isset( $cl_r['cl_ticket']['phone'] ) ? trim( (string) $cl_r['cl_ticket']['phone'] ) : '';
	if ( '' !== $cl_r_ph ) {
		$cl_people[ $cl_key ]['phones'][ $cl_r_ph ] = true;
	}
	$cl_people[ $cl_key ]['rows'][] = array(
		'row' => $cl_r,
		'cap' => $cl_cap_r,
	);
}
uasort(
	$cl_people,
	function ( $a, $b ) {
		return $b['count'] <=> $a['count'];
	}
);

// Which person the page is narrowed to, from the address. A name rather than
// an id because the visitor has none, and it is compared against the same key
// the split was built with.
$cl_who_key = isset( $_GET['cl_who'] ) ? mb_strtolower( trim( (string) wp_unslash( $_GET['cl_who'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

// The key is compared, never printed: it is matched against the same key the
// split above was built with, and only a name that is in that split can
// narrow anything. An unknown name shows everybody rather than an empty
// screen, which is the failure a mistyped address would otherwise cause.
if ( '' !== $cl_who_key && ! isset( $cl_people[ $cl_who_key ] ) ) {
	$cl_who_key = '';
}

$cl_lock = $cl_agents->lock_config( $cl_agent );
$cl_init = strtoupper( mb_substr( trim( (string) $cl_agent['name'] ), 0, 1 ) );
if ( '' === $cl_init ) {
	$cl_init = 'A';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="theme-color" content="#0a1118">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#0a1118">
<title><?php echo esc_html( sprintf( /* translators: %s: site name */ __( 'Case desk — %s', 'cloaklink' ), $cl_name ) ); ?></title>
<?php
// The tab mark. A desk that shows the install's WordPress logo in the tab
// is a desk nobody can find among ten open tabs.
$cl_icon_src = CLOAKLINK_URL . 'assets/img/logo.png';
$cl_icon_ver = '';
if ( defined( 'CLOAKLINK_PATH' ) && file_exists( CLOAKLINK_PATH . 'assets/img/logo.png' ) ) {
	$cl_icon_ver = (string) filemtime( CLOAKLINK_PATH . 'assets/img/logo.png' );
}
?>
<link rel="icon" href="<?php echo esc_url( $cl_icon_src . ( $cl_icon_ver ? '?v=' . $cl_icon_ver : '' ) ); ?>" sizes="any">
<link rel="apple-touch-icon" href="<?php echo esc_url( $cl_icon_src ); ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="<?php echo esc_attr( $cl_name ); ?> Desk">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/agent.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/tower.css?ver=' . CLOAKLINK_VERSION ); ?>">
<?php
// The house theme, in the head but after every sheet before it. The desk's
// radio sheet is printed at the foot of the body, so it is the one case the
// theme can be beaten by; theme-intel states the radio's own colours with
// !important for exactly that reason, and the sheet carries a matching block
// for the dock at the end.
?>
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-intel.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-signal.css?ver=' . CLOAKLINK_VERSION ); ?>">
<script type="application/json" id="cl-agent-config"><?php
echo wp_json_encode(
	array(
		'ajax'       => admin_url( 'admin-ajax.php' ),
		'panel'      => $cl_agents->screen_url( 'panel', $cl_view ? array( 'cl_ticket' => (int) $cl_view['id'] ) : array() ),
		'alertSound' => (string) cloaklink()->settings->alert_sound_url(),
		// Whether this desk makes a sound at all, and how loud. Both come from
		// the console's alert settings, so the operator and the agents hear the
		// same alert at the same level.
		'alertOn'     => (int) cloaklink()->settings->get( 'agent_alert_sound', 1 ) ? 1 : 0,
		'alertVolume' => max( 0, min( 100, (int) cloaklink()->settings->get( 'alert_volume', 70 ) ) ),
		'lock'       => $cl_lock,
		// The delete question's two buttons, in this site's language.
		'i18n'       => array(
			'remove' => __( 'Remove', 'cloaklink' ),
			'cancel' => __( 'Cancel', 'cloaklink' ),
		),
	)
);
?></script>
</head>
<body class="cl-agent-panel">

<header class="clx-bar">
	<a class="clx-bar__brand" href="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>">
		<?php echo CloakLink_Admin::logo( '', 30 ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in logo(). ?>
		<span>
			<span class="clx-bar__name"><?php echo esc_html( $cl_name ); ?></span>
			<span class="clx-bar__sub"><?php esc_html_e( 'Case desk', 'cloaklink' ); ?></span>
		</span>
	</a>

	<div class="clx-bar__right">
		<span class="clx-live"><span class="clx-dot" aria-hidden="true"></span><?php esc_html_e( 'Live', 'cloaklink' ); ?></span>
		<div class="clx-me">
			<span class="clx-me__av" aria-hidden="true"><?php echo esc_html( $cl_init ); ?></span>
			<span class="clx-me__who">
				<b><?php echo esc_html( $cl_agent['name'] ); ?></b>
				<i><?php echo $cl_is_admin ? esc_html__( 'Admin', 'cloaklink' ) : esc_html__( 'Agent', 'cloaklink' ); ?></i>
			</span>
			<a class="clx-out clx-out--prefs" href="<?php echo esc_url( $cl_agents->screen_url( 'prefs' ) ); ?>" title="<?php esc_attr_e( 'Your own desk settings', 'cloaklink' ); ?>"><?php esc_html_e( 'Settings', 'cloaklink' ); ?></a>
			<a class="clx-out" href="<?php echo esc_url( add_query_arg( 'cl_agent_out', '1', $cl_agents->screen_url( 'panel' ) ) ); ?>"><?php esc_html_e( 'Out', 'cloaklink' ); ?></a>
		</div>
	</div>
</header>

<main class="clx-page">

	<?php
	// Two things this person has to know, said before the work rather than
	// buried in it: their password is old enough to be flagged, or the office
	// has marked the account so that a new one must be chosen. Neither blocks
	// the desk — there is no password-change screen on this side yet — but an
	// operator who asked for it should be able to see that the desk knows.
	$cl_policy_note = cloaklink()->agent_policy->notice( $cl_agent );
	$cl_force_pw    = ! empty( $cl_agent['must_change'] );
	$cl_quota_cap   = (int) cloaklink()->agent_policy->value( 'desk_quota_day' );
	$cl_quota_mine  = isset( $cl_agent['quota'] ) ? (int) $cl_agent['quota'] : 0;
	$cl_quota_here  = cloaklink()->agent_policy->raised_today( $cl_agent );
	$cl_quota_use   = $cl_quota_mine > 0 ? $cl_quota_mine : $cl_quota_cap;
	$cl_quota_on    = (bool) cloaklink()->agent_policy->value( 'desk_quota_on' ) && $cl_quota_use > 0;
	?>
	<?php if ( '' !== $cl_policy_note || $cl_force_pw ) : ?>
		<p class="clx-flag" role="status">
			<span class="clx-flag__dot" aria-hidden="true"></span>
			<?php
			echo esc_html(
				$cl_force_pw
					? __( 'The office has asked for a new password on this account. Ask them to set one for you.', 'cloaklink' )
					: $cl_policy_note
			);
			?>
		</p>
	<?php endif; ?>

	<?php if ( $cl_quota_on ) : ?>
		<?php
		// The cap is stated as a fraction, not as a warning: a person who can
		// see "18 of 25 today" plans their afternoon, and one who is told they
		// are near a limit they cannot see does not.
		$cl_quota_left = max( 0, $cl_quota_use - $cl_quota_here );
		?>
		<p class="clx-flag clx-flag--quota<?php echo $cl_quota_left < 3 ? ' is-low' : ''; ?>" role="status">
			<span class="clx-flag__dot" aria-hidden="true"></span>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: raised today, 2: daily cap */
					__( 'Tickets today: %1$d of %2$d.', 'cloaklink' ),
					$cl_quota_here,
					$cl_quota_use
				)
			);
			?>
		</p>
	<?php endif; ?>

	<?php
	// Recent clicks — the console's own cards, one per click.
	//
	// Recent monitoring below answers "who is this person"; this answers "what
	// did they hand over, on that click". It is the exact card the operator's
	// Smart monitoring screen draws — the four permission tiles, the place,
	// the handset, the address and the pin — because an agent describing a
	// record over the radio has to be describing the same thing the other end
	// is looking at. The builder is the console's, given this desk's media
	// door, so the two screens cannot drift apart.
	//
	// Only the rows of tickets this person may read reach it, and each card
	// carries its own ticket reference, so nothing here can show a case that
	// is not theirs.
	// One card per visitor, not per click.
	//
	// Every permission a visitor allows arrives as its own row, so a person
	// who allowed the location, then the camera, then the microphone made
	// three cards that differed only in which marks were lit — the same
	// person, the same place, the same handset, printed three times down
	// the wall. The card that matters is the one holding every mark, so the
	// rows are gathered by visitor and the newest row that a full set can
	// be taken from speaks for them, carrying the count. "All records"
	// below already works this way; this is the same rule applied to the
	// live list so the two cannot disagree about how many people are on the
	// desk.
	$cl_wall     = array();
	$cl_wall_of  = array();
	foreach ( $cl_recent as $cl_wr ) {
		if ( '' !== $cl_who_key ) {
			$cl_wr_who = isset( $cl_wr['cl_ticket']['person'] ) ? trim( (string) $cl_wr['cl_ticket']['person'] ) : '';
			if ( '' === $cl_wr_who ) {
				$cl_wr_who = trim( (string) $cl_wr['city'] );
			}
			if ( mb_strtolower( $cl_wr_who ) !== $cl_who_key ) {
				continue;
			}
		}
		// The same key the archive uses: the hashed address, falling back to
		// the name and city for a row that carries no hash. Two vents for one
		// person must fold together, and two different people who both left
		// the name blank must not.
		$cl_wr_hash = trim( (string) ( isset( $cl_wr['ip_hash'] ) ? $cl_wr['ip_hash'] : '' ) );
		$cl_wr_key  = '' !== $cl_wr_hash
			? 'h:' . mb_strtolower( $cl_wr_hash )
			: 'n:' . mb_strtolower( (string) ( isset( $cl_wr['cl_ticket']['person'] ) ? $cl_wr['cl_ticket']['person'] : '' ) )
				. '|' . (string) ( isset( $cl_wr['city'] ) ? $cl_wr['city'] : '' );

		if ( ! isset( $cl_wall_of[ $cl_wr_key ] ) ) {
			$cl_wr['cl_clicks'] = 0;
			$cl_wr['cl_marks']  = array();
			$cl_wall_of[ $cl_wr_key ] = count( $cl_wall );
			$cl_wall[] = $cl_wr;
		}
		$cl_wr_at = $cl_wall_of[ $cl_wr_key ];
		$cl_wall[ $cl_wr_at ]['cl_clicks']++;

		// The union of what this visitor handed over, so the card shows
		// every mark they earned rather than only the newest row's.
		$cl_wr_cap = $cl_db->capture_of( $cl_wr );
		foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $cl_wr_k ) {
			if ( ! empty( $cl_wr_cap[ $cl_wr_k ] ) ) {
				$cl_wall[ $cl_wr_at ]['cl_marks'][ $cl_wr_k ] = true;
			}
		}

		// A row with detail beats a newer row without it, exactly as the
		// archive decides it: a cleared row drawn as the face of a visitor
		// makes the card look empty while their real answer sits behind it.
		$cl_wr_fresh_ok = empty( $cl_wr['extra'] ) || false === strpos( (string) $cl_wr['extra'], '"removed"' );
		$cl_wr_held     = $cl_wall[ $cl_wr_at ];
		$cl_wr_held_ok  = empty( $cl_wr_held['extra'] ) || false === strpos( (string) $cl_wr_held['extra'], '"removed"' );
		$cl_wr_has_fix  = '' !== (string) $cl_wr['lat'] && '' !== (string) $cl_wr['lng'];
		if ( ( $cl_wr_fresh_ok && ! $cl_wr_held_ok )
			|| ( $cl_wr_fresh_ok === $cl_wr_held_ok && (int) $cl_wr['id'] > (int) $cl_wr_held['id'] )
			|| ( $cl_wr_fresh_ok === $cl_wr_held_ok && $cl_wr_has_fix
				&& ( '' === (string) $cl_wr_held['lat'] || '' === (string) $cl_wr_held['lng'] ) ) ) {
			$cl_wr['cl_clicks']         = $cl_wall[ $cl_wr_at ]['cl_clicks'];
			$cl_wr['cl_marks']          = $cl_wall[ $cl_wr_at ]['cl_marks'];
			$cl_wall[ $cl_wr_at ] = $cl_wr;
		}

		if ( count( $cl_wall ) >= 24 ) {
			break;
		}
	}
	// The card is drawn from the row that was kept, and that row is the
	// newest one — which is not always the one that knows where the visitor
	// was. A person who allowed the camera after the location left a photo
	// row with no coordinates and a position row with no photo, so the card
	// showed the picture over "No coordinates on this click" while the pin
	// sat on the row beneath it. The same hole swallowed the city and the
	// phone, so the facts are carried across from the visitor's other rows,
	// filling blanks only.
	$cl_wall_facts = array( 'lat', 'lng', 'accuracy', 'city', 'region', 'country_code', 'country_name', 'isp', 'ip', 'visitor_name', 'visitor_phone', 'device_model', 'brand', 'os', 'browser', 'device', 'tz' );
	foreach ( $cl_wall as $cl_wall_i => $cl_wall_one ) {
		$cl_wall_hash = trim( (string) ( isset( $cl_wall_one['ip_hash'] ) ? $cl_wall_one['ip_hash'] : '' ) );
		if ( '' === $cl_wall_hash ) {
			continue;
		}
		foreach ( $cl_recent as $cl_wall_sib ) {
			if ( trim( (string) ( isset( $cl_wall_sib['ip_hash'] ) ? $cl_wall_sib['ip_hash'] : '' ) ) !== $cl_wall_hash ) {
				continue;
			}
			foreach ( $cl_wall_facts as $cl_wall_f ) {
				$have = isset( $cl_wall[ $cl_wall_i ][ $cl_wall_f ] ) ? (string) $cl_wall[ $cl_wall_i ][ $cl_wall_f ] : '';
				$mine = isset( $cl_wall_sib[ $cl_wall_f ] ) ? (string) $cl_wall_sib[ $cl_wall_f ] : '';
				if ( '' === trim( $have ) && '' !== trim( $mine ) ) {
					$cl_wall[ $cl_wall_i ][ $cl_wall_f ] = $cl_wall_sib[ $cl_wall_f ];
				}
			}
		}
	}

	// The union has to reach the card builder, which reads the row's own
	// `capture` key when it is given one.
	foreach ( $cl_wall as $cl_wall_i => $cl_wall_one ) {
		if ( empty( $cl_wall_one['cl_marks'] ) ) {
			continue;
		}
		$cl_wall_cap = $cl_db->capture_of( $cl_wall_one );
		foreach ( array_keys( $cl_wall_one['cl_marks'] ) as $cl_wall_k ) {
			$cl_wall_cap[ $cl_wall_k ] = true;
		}
		$cl_wall[ $cl_wall_i ]['capture'] = $cl_wall_cap;
	}
	?>
	<?php if ( $cl_wall ) : ?>
		<section class="clx-panel clx-clicks" id="cl-recentclick">
			<header class="clx-panel__head">
				<h2 class="clx-panel__title"><?php esc_html_e( 'Recent clicks', 'cloaklink' ); ?></h2>
				<span class="clx-panel__meta">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: number of clicks */
							_n( '%s click', '%s clicks', count( $cl_wall ), 'cloaklink' ),
							number_format_i18n( count( $cl_wall ) )
						)
					);
					?>
				</span>
			</header>
			<div class="clx-wall" id="cl-agent-wall">
				<?php
				foreach ( $cl_wall as $cl_wr ) :
					$cl_wr_owner = isset( $cl_wr['cl_ticket']['id'] ) ? (int) $cl_wr['cl_ticket']['id'] : 0;
					$cl_wr_cap   = $cl_db->capture_of( $cl_wr );
					$cl_wr_lid   = (int) $cl_wr['link_id'];
					$cl_wr_row   = $cl_wr;

					// Every card carries the file its own marks name.
					//
					// It used to print the photograph once per link, on the
					// first card, and leave the rest blank — so a card whose
					// Mic mark was lit showed nothing to press, and the reader
					// had to find the card above it to hear the voice note.
					// The files belong to the link, not the click, but every
					// click on that link handed them over, so every click
					// shows them.
					$cl_wr_has = ! empty( $cl_wr_cap['camera'] ) || ! empty( $cl_wr_cap['video'] ) || ! empty( $cl_wr_cap['microphone'] );

					$cl_wr_names = array(
						$cl_wr_lid => array(
							'name'  => isset( $cl_wr['cl_ticket']['person'] ) ? (string) $cl_wr['cl_ticket']['person'] : '',
							'slug'  => isset( $cl_wr['cl_ticket']['ref'] ) ? (string) $cl_wr['cl_ticket']['ref'] : '',
							'label' => isset( $cl_wr['cl_ticket']['ref'] ) ? (string) $cl_wr['cl_ticket']['ref'] : '',
							'type'  => isset( $cl_wr['cl_ticket']['kind'] ) ? (string) $cl_wr['cl_ticket']['kind'] : '',
						),
					);
					$cl_wr_media = function ( $sid, $which, $index = 0, $download = false ) use ( $cl_agents, $cl_wr_owner ) {
						$url = $cl_agents->media_url( (int) $sid, $cl_wr_owner, (string) $which, (int) $index );
						if ( $download ) {
							$url = add_query_arg( 'dl', 1, $url );
						}
						return $url;
					};
					echo '<div class="clx-wall__one">' . cloaklink()->admin->capture_card_html( $cl_wr_row, $cl_wr_names, array(), $cl_wr_media, $cl_desk_record ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in capture_card_html().
				endforeach;
				?>
			</div>
		</section>
	<?php endif; ?>

			<?php
			// The same cards the operator's wall draws, on this desk.
			//
			// The list below is one line per record, which is right for
			// scanning forty of them. What it is bad at is the question
			// this desk actually asks while the phone is ringing: "who
			// is in front of me, and what have they handed over?" One
			// answer per click, with the four permission marks on it —
			// the same shape the operator sees, so an agent describing a
			// record over the radio is describing the same thing the
			// other end is looking at.
			//
			// Only tickets this person may read reach this array, and
			// every card carries its own ticket reference, so nothing
			// here can show a case that is not theirs.
			$cl_shared = array();
			foreach ( $cl_records as $cl_sh ) {
				// One box per visitor, not per click.
				//
				// A person who allowed the location, then the camera,
				// then the microphone makes three rows, and three
				// cards that each say almost the same thing. What the
				// desk asks while the phone is ringing is "who is in
				// front of me and what have they given me" — so the
				// rows are gathered into one entry per visitor and the
				// permissions are merged. The click count is kept on
				// the card so the merging is stated rather than
				// pretended away.
				$cl_sh_who = isset( $cl_sh['cl_ticket']['person'] ) ? trim( (string) $cl_sh['cl_ticket']['person'] ) : '';
				if ( '' === $cl_sh_who ) {
					$cl_sh_who = trim( (string) $cl_sh['city'] );
				}
				if ( '' === $cl_sh_who ) {
					$cl_sh_who = __( 'Unnamed visitor', 'cloaklink' );
				}
				// What makes two clicks "the same visitor".
				//
				// The name alone is not it. Every visitor who did not type a
				// name is called "Unnamed visitor", so keying on the name
				// silently merged every anonymous visitor on the link into
				// one box — and, once a box could be deleted, one press would
				// have deleted several different people's records. The
				// visitor's hashed address is what the console already uses
				// to tell two visitors apart; the name is only a fallback for
				// a row that carries no hash at all.
				$cl_sh_hash = trim( (string) ( isset( $cl_sh['ip_hash'] ) ? $cl_sh['ip_hash'] : '' ) );
				$cl_sh_key  = '' !== $cl_sh_hash
					? 'h:' . mb_strtolower( $cl_sh_hash )
					: 'n:' . mb_strtolower( $cl_sh_who ) . '|' . (string) ( isset( $cl_sh['city'] ) ? $cl_sh['city'] : '' );

				if ( ! isset( $cl_shared[ $cl_sh_key ] ) ) {
					$cl_shared[ $cl_sh_key ] = array(
						'row'   => $cl_sh,
						'count' => 0,
						'grant' => array(),
						// Every visit this box stands for. One box is one
						// visitor, and one visitor is several rows; deleting
						// the box has to delete all of them. It used to carry
						// only the row that spoke for the visitor, so the
						// other clicks survived the delete and the box came
						// straight back — "I deleted it and it is still
						// there".
						'ids'   => array(),
					);
				}
				$cl_shared[ $cl_sh_key ]['count']++;
				$cl_shared[ $cl_sh_key ]['ids'][] = (int) $cl_sh['id'];
				$cl_sh_cap = $cl_db->capture_of( $cl_sh );
				foreach ( array( 'position', 'camera', 'microphone', 'video' ) as $cl_sh_k ) {
					if ( ! empty( $cl_sh_cap[ $cl_sh_k ] ) ) {
						$cl_shared[ $cl_sh_key ]['grant'][ $cl_sh_k ] = true;
					}
				}
				// Which row speaks for the visitor.
				//
				// Newest is the obvious answer and it is the wrong one:
				// a row whose detail was cleared carries no place, no
				// device and no coordinates, so picking it drew an
				// empty-looking box while the visitor's actual answer
				// sat two rows back. A row with detail beats a newer
				// row without it; between two rows that both have
				// detail, the newer wins.
				$cl_sh_new = $cl_sh;
				$cl_sh_old = $cl_shared[ $cl_sh_key ]['row'];
				$cl_sh_new_ok = empty( $cl_sh_old['extra'] ) || false === strpos( (string) $cl_sh_old['extra'], '"removed"' );
				$cl_sh_row_ok = empty( $cl_sh_new['extra'] ) || false === strpos( (string) $cl_sh_new['extra'], '"removed"' );
				$cl_sh_has_fix = '' !== (string) $cl_sh['lat'] && '' !== (string) $cl_sh['lng'];

				if ( ( $cl_sh_row_ok && ! $cl_sh_new_ok )
					|| ( $cl_sh_row_ok === $cl_sh_new_ok && (int) $cl_sh['id'] > (int) $cl_sh_old['id'] )
					|| ( $cl_sh_row_ok === $cl_sh_new_ok && $cl_sh_has_fix && ( '' === (string) $cl_sh_old['lat'] || '' === (string) $cl_sh_old['lng'] ) ) ) {
					$cl_shared[ $cl_sh_key ]['row'] = $cl_sh;
				}
			}
			$cl_shared = array_slice( array_values( $cl_shared ), 0, 12 );
			?>
			<?php if ( $cl_shared ) : ?>
				<?php
				$cl_shared_names = array();
				foreach ( $cl_records as $cl_shr ) {
					$cl_shr_t = isset( $cl_shr['cl_ticket'] ) ? $cl_shr['cl_ticket'] : array();
					$cl_shared_names[ (int) $cl_shr['link_id'] ] = array(
						'name'  => (string) ( $cl_shr_t['person'] ?? '' ),
						'slug'  => (string) ( $cl_shr_t['ref'] ?? '' ),
						'label' => (string) ( $cl_shr_t['ref'] ?? '' ),
						'type'  => (string) ( $cl_shr_t['kind'] ?? '' ),
					);
				}
				?>
				<section class="clx-panel clx-shared" id="cl-agent-shared">
					<header class="clx-panel__head">
						<h2 class="clx-panel__title"><?php esc_html_e( 'All records', 'cloaklink' ); ?></h2>
						<button class="clx-btn clx-btn--ghost clx-pick-toggle" type="button" id="clx-shpick" aria-pressed="false">
							<?php esc_html_e( 'Select', 'cloaklink' ); ?>
						</button>
						<span class="clx-panel__meta">
							<?php
							echo esc_html(
								sprintf(
									/* translators: 1: number of visitors, 2: number of clicks */
									__( '%1$s · %2$s', 'cloaklink' ),
									sprintf(
										/* translators: %s: number of visitors */
										_n( '%s visitor', '%s visitors', count( $cl_shared ), 'cloaklink' ),
										number_format_i18n( count( $cl_shared ) )
									),
									sprintf(
										/* translators: %s: number of clicks */
										_n( '%s click', '%s clicks', count( $cl_records ), 'cloaklink' ),
										number_format_i18n( count( $cl_records ) )
									)
								)
							);
							?>
						</span>
					</header>
					<form class="clx-sharedform" id="clx-sharedform" method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>">
						<input type="hidden" name="cl_agent_action" value="delete_records">
						<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>
						<div class="clx-selbar" id="clx-shbar" hidden>
							<span class="clx-selbar__n" id="clx-shcount"><?php esc_html_e( 'Nothing selected', 'cloaklink' ); ?></span>
							<div class="clx-selbar__acts">
								<button class="clx-btn clx-btn--ghost" type="button" id="clx-shall"><?php esc_html_e( 'Select all', 'cloaklink' ); ?></button>
								<button class="clx-btn clx-btn--ghost" type="button" id="clx-shnone"><?php esc_html_e( 'Clear selection', 'cloaklink' ); ?></button>
								<button class="clx-btn clx-btn--danger" type="submit" id="clx-shgo" disabled data-confirm="<?php echo esc_attr__( 'Delete these records for good? They are removed from the operator’s wall and from Visits as well. This cannot be undone.', 'cloaklink' ); ?>">
									<?php esc_html_e( 'Delete selected', 'cloaklink' ); ?>
								</button>
							</div>
						</div>
					<div class="cl-walkins">
						<?php foreach ( $cl_shared as $cl_sh_entry ) : ?>
							<?php
							// The merged row is handed to the same card
							// builder the operator's wall uses, with the
							// permissions of every click combined. The
							// card therefore cannot drift from the
							// console's: it is the console's card, given
							// a visitor's whole answer instead of one
							// click's.
							$cl_sh_row = $cl_sh_entry['row'];
							$cl_sh_left = $cl_sh_entry['grant'];
							$cl_sh_extra = isset( $cl_sh_row['extra'] ) ? $cl_sh_row['extra'] : array();
							if ( is_string( $cl_sh_extra ) ) {
								$cl_sh_extra = $cl_db->decode( $cl_sh_extra );
							}
							if ( ! is_array( $cl_sh_extra ) ) {
								$cl_sh_extra = array();
							}
							// The union of every click's permissions,
							// and never the "removed" flag from one
							// of them: this box is the visitor's
							// whole answer, so a cleared click inside
							// it must not erase the box.
							$cl_sh_extra['granted'] = array_keys( $cl_sh_left );
							unset( $cl_sh_extra['removed'], $cl_sh_extra['removed_at'], $cl_sh_extra['removed_by'] );
							$cl_sh_row['extra']    = wp_json_encode( $cl_sh_extra );
							unset( $cl_sh_row['capture'] );
							?>
							<?php
							// One cell per visitor. The pick box and the
							// card have to share a grid cell: as two
							// siblings the box took a column of its own
							// and every card was pushed right by 20px,
							// so the wall read as a broken two-column
							// table instead of a row of cards.
							?>
							<div class="clx-shared__slot">
							<label class="clx-shared__pick" hidden>
								<?php
								// One box, one visitor, every row that
								// visitor made. The checkboxes share one name
								// and one tick means all of them, so deleting
								// the box really deletes the box rather than
								// the single row it was drawn from.
								$cl_sh_ids = ! empty( $cl_sh_entry['ids'] ) ? (array) $cl_sh_entry['ids'] : array( (int) $cl_sh_row['id'] );
								foreach ( $cl_sh_ids as $cl_sh_id ) :
									?>
									<input type="checkbox" name="cl_visit[]" value="<?php echo esc_attr( (string) (int) $cl_sh_id ); ?>" class="clx-shared__row">
								<?php endforeach; ?>
								<span aria-hidden="true"></span>
							</label>
							<div class="clx-shared__one">
								<?php
								// The desk's own media door. An agent has no
								// WordPress session, so the console's
								// admin.php URL would send them to a sign-in
								// page instead of the file; this builds the
								// address the desk handler checks.
								$cl_sh_media = function ( $sid, $which, $index = 0, $download = false ) use ( $cl_agents, $cl_sh_row ) {
									$tid = isset( $cl_sh_row['cl_ticket']['id'] ) ? (int) $cl_sh_row['cl_ticket']['id'] : 0;
									$url = $cl_agents->media_url( (int) $sid, $tid, (string) $which, (int) $index );
									if ( $download ) {
										$url = add_query_arg( 'dl', 1, $url );
									}
									return $url;
								};
								echo cloaklink()->admin->capture_card_html( $cl_sh_row, $cl_shared_names, array(), $cl_sh_media, $cl_desk_record ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in capture_card_html() and built only from this agent's own released tickets.
								?>
								<p class="clx-shared__count">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %d: number of clicks */
											_n( '%d click', '%d clicks', (int) $cl_sh_entry['count'], 'cloaklink' ),
											number_format_i18n( (int) $cl_sh_entry['count'] )
										)
									);
									?>
								</p>
							</div>
							</div>
						<?php endforeach; ?>
					</div>
					</form>
				</section>
			<?php endif; ?>


	<?php
	// Every ticket this person has raised, as one list.
	//
	// The queue panel further down is the working list: it is folded into
	// three states and it is what a person reads while a case is open. This is
	// the file — every case, whatever its state, searchable by name, reference,
	// phone or day, and prunable in bulk. A desk with forty test cases in it
	// cannot be read without a place like this, and there was no place: the
	// only way to find an old ticket was to scroll the queue and remember.
	//
	// It sits above "Your tickets" with the monitoring sections because it is
	// the same kind of thing: the record, not the work in front of you.
	$cl_all_tickets = $cl_agents->tickets_for( (int) $cl_agent['id'], false );
	?>
	<?php if ( $cl_all_tickets ) : ?>
		<section class="clx-panel clx-alltix" id="cl-agent-tickets">
			<header class="clx-panel__head">
				<h2 class="clx-panel__title"><?php esc_html_e( 'All tickets', 'cloaklink' ); ?></h2>
				<span class="clx-panel__meta">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: number of tickets */
							_n( '%s ticket', '%s tickets', count( $cl_all_tickets ), 'cloaklink' ),
							number_format_i18n( count( $cl_all_tickets ) )
						)
					);
					?>
				</span>
				<button class="clx-btn clx-btn--ghost clx-pick-toggle" type="button" id="clx-tixpick" aria-pressed="false">
					<?php esc_html_e( 'Select', 'cloaklink' ); ?>
				</button>
			</header>

			<div class="clx-mfilter clx-tixfilter" id="clx-tixfilter" role="group" aria-label="<?php esc_attr_e( 'Filter tickets', 'cloaklink' ); ?>">
				<input class="clx-qsearch" id="cl-tixsearch" type="search" autocomplete="off" placeholder="<?php esc_attr_e( 'Find a name, a reference or a number', 'cloaklink' ); ?>">
				<input class="clx-qsearch clx-tixdate" id="cl-tixdate" type="date" aria-label="<?php esc_attr_e( 'Only tickets raised on this day', 'cloaklink' ); ?>">
				<button class="clx-btn clx-btn--ghost clx-btn--sm" type="button" id="clx-tixclear" hidden><?php esc_html_e( 'Clear', 'cloaklink' ); ?></button>
			</div>

			<form class="clx-tixform" id="clx-tixform" method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>">
				<input type="hidden" name="cl_agent_action" value="delete_tickets">
				<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>

				<div class="clx-selbar" id="clx-tixbar" hidden>
					<span class="clx-selbar__n" id="clx-tixcount"><?php esc_html_e( 'Nothing selected', 'cloaklink' ); ?></span>
					<div class="clx-selbar__acts">
						<button class="clx-btn clx-btn--ghost" type="button" id="clx-tixall"><?php esc_html_e( 'Select all', 'cloaklink' ); ?></button>
						<button class="clx-btn clx-btn--ghost" type="button" id="clx-tixnone"><?php esc_html_e( 'Clear selection', 'cloaklink' ); ?></button>
						<button class="clx-btn clx-btn--danger" type="submit" id="clx-tixgo" disabled
							data-confirm="<?php echo esc_attr__( 'Delete these tickets? Each one and its link are removed for good, with everything its link captured. This cannot be undone.', 'cloaklink' ); ?>">
							<?php esc_html_e( 'Delete selected', 'cloaklink' ); ?>
						</button>
					</div>
				</div>

				<div class="clx-tixlist" id="clx-tixlist">
					<?php
					foreach ( $cl_all_tickets as $cl_at ) :
						$cl_at_ok    = $cl_agents->is_allowed( $cl_at );
						$cl_at_when  = (string) $cl_at['created_at'];
						$cl_at_day   = substr( $cl_at_when, 0, 10 );
						$cl_at_ref   = isset( $cl_at['ref'] ) ? (string) $cl_at['ref'] : '';
						$cl_at_who   = isset( $cl_at['person'] ) ? trim( (string) $cl_at['person'] ) : '';
						$cl_at_phone = isset( $cl_at['phone'] ) ? (string) $cl_at['phone'] : '';
						$cl_at_note  = isset( $cl_at['note'] ) ? trim( (string) $cl_at['note'] ) : '';
						$cl_at_n     = isset( $cl_at['link_id'] ) && (int) $cl_at['link_id'] && isset( $cl_counts[ (int) $cl_at['link_id'] ] ) ? (int) $cl_counts[ (int) $cl_at['link_id'] ] : 0;
						// The one searchable string, built here so the script
						// has nothing to compose and cannot miss a field.
						$cl_at_blob  = mb_strtolower( $cl_at_who . ' ' . $cl_at_ref . ' ' . $cl_at_phone . ' ' . $cl_at_note . ' ' . CloakLink_Admin::stamp( $cl_at_when, 'j M Y g:i A' ) );
						?>
						<article class="clx-tixrow" data-day="<?php echo esc_attr( $cl_at_day ); ?>" data-find="<?php echo esc_attr( $cl_at_blob ); ?>" data-state="<?php echo $cl_at_ok ? 'on' : 'wait'; ?>">
							<label class="clx-tixrow__pick" hidden>
								<input type="checkbox" name="cl_ticket_ids[]" value="<?php echo esc_attr( (string) $cl_at['id'] ); ?>">
								<span aria-hidden="true"></span>
								<span class="screen-reader-text"><?php esc_html_e( 'Select this ticket', 'cloaklink' ); ?></span>
							</label>
							<span class="clx-tixrow__when"><?php echo esc_html( CloakLink_Admin::stamp( $cl_at_when, 'j M, g:i A' ) ); ?></span>
							<span class="clx-tixrow__who"><?php echo esc_html( '' !== $cl_at_who ? $cl_at_who : __( 'Unnamed', 'cloaklink' ) ); ?></span>
							<span class="clx-tixrow__ref">#<?php echo esc_html( $cl_at_ref ); ?></span>
							<span class="clx-pill <?php echo $cl_at_ok ? 'clx-pill--on' : 'clx-pill--wait'; ?>">
								<?php echo $cl_at_ok ? esc_html__( 'Tracing', 'cloaklink' ) : esc_html__( 'In Que', 'cloaklink' ); ?>
							</span>
							<span class="clx-tixrow__n"><?php echo esc_html( sprintf( /* translators: %d: number of records */ _n( '%d record', '%d records', $cl_at_n, 'cloaklink' ), $cl_at_n ) ); ?></span>
							<a class="clx-tixrow__open" href="<?php echo esc_url( $cl_agents->screen_url( 'panel', array( 'cl_ticket' => (int) $cl_at['id'] ) ) ); ?>"><?php esc_html_e( 'Open', 'cloaklink' ); ?></a>
						</article>
					<?php endforeach; ?>
					<p class="clx-empty" id="clx-tixnone" hidden><?php esc_html_e( 'No ticket matches that.', 'cloaklink' ); ?></p>
				</div>
			</form>
		</section>
	<?php endif; ?>

	<div class="clx-head">
		<div>
			<h1 class="clx-head__t"><?php esc_html_e( 'Your tickets', 'cloaklink' ); ?></h1>
			<p class="clx-head__s">
				<?php esc_html_e( 'Each ticket you raise appears here. The office releases it, and what its link captured is shown once they have.', 'cloaklink' ); ?>
			</p>
		</div>
	</div>

	<?php
	/*
	 * The desk's own state line, above its counters.
	 *
	 * The four counters below answer "how much work do I have". None of them
	 * answers the question an agent asks when they sit down: is anything
	 * moving, and is any of it mine. So the band goes first and says that in
	 * one line — a dot for whether anything has reached this desk in the last
	 * few minutes, a sentence built from the same rows the board counts, and
	 * two doors: the queue the office is holding, and the one thing this desk
	 * is for, raising a case.
	 *
	 * Every figure here is read from `$cl_recent`, which was already loaded
	 * for the monitoring list, so the band costs no query of its own and can
	 * never disagree with the list beneath it.
	 */
	$cl_band_recent = $cl_hour;
	$cl_band_live   = $cl_band_recent > 0;
	$cl_band_warm   = ! $cl_band_live && count( $cl_recent ) > 0;
	$cl_band_word   = $cl_band_live
		? __( 'Live', 'cloaklink' )
		: ( $cl_band_warm ? __( 'Quiet', 'cloaklink' ) : __( 'Nothing yet', 'cloaklink' ) );
	$cl_band_mod    = $cl_band_live ? ' is-live' : ( $cl_band_warm ? ' is-warm' : '' );

	if ( $cl_band_live ) {
		$cl_band_line = sprintf(
			/* translators: 1: records in the last hour, 2: number waiting on the office */
			_n( '%1$s record reached your desk in the last hour. %2$s ticket is with the office.', '%1$s records reached your desk in the last hour. %2$s tickets are with the office.', $cl_band_recent, 'cloaklink' ),
			number_format_i18n( $cl_band_recent ),
			number_format_i18n( $cl_pending )
		);
	} elseif ( $cl_band_warm ) {
		$cl_band_line = sprintf(
			/* translators: %s: total records */
			_n( '%s record on your traced links. Nothing in the last hour.', '%s records on your traced links. Nothing in the last hour.', (int) $cl_live, 'cloaklink' ),
			number_format_i18n( (int) $cl_live )
		);
	} else {
		$cl_band_line = __( 'No records yet. Raise a ticket and the office will release a link for it.', 'cloaklink' );
	}
	?>
	<section class="clx-watch" aria-labelledby="clx-watch-t">
		<div class="clx-watch__head">
			<div class="clx-watch__pulse<?php echo esc_attr( $cl_band_mod ); ?>">
				<span class="clx-watch__dot" aria-hidden="true"></span>
				<b id="clx-watch-t"><?php echo esc_html( $cl_band_word ); ?></b>
			</div>
			<p class="clx-watch__line"><?php echo esc_html( $cl_band_line ); ?></p>
			<a class="clx-watch__act" href="#cl-raise">
				<?php esc_html_e( 'Raise a ticket', 'cloaklink' ); ?>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
			</a>
		</div>
	</section>

	<section class="clx-kpis" aria-label="<?php esc_attr_e( 'At a glance', 'cloaklink' ); ?>">
		<article class="clx-kpi clx-kpi--live">
			<p class="clx-kpi__label"><?php esc_html_e( 'Records', 'cloaklink' ); ?></p>
			<p class="clx-kpi__n"><?php echo esc_html( number_format_i18n( $cl_live ) ); ?></p>
			<p class="clx-kpi__f"><?php esc_html_e( 'across your traced links', 'cloaklink' ); ?></p>
		</article>
		<article class="clx-kpi clx-kpi--wait">
			<p class="clx-kpi__label"><?php esc_html_e( 'In Que', 'cloaklink' ); ?></p>
			<p class="clx-kpi__n"><?php echo esc_html( number_format_i18n( $cl_pending ) ); ?></p>
			<p class="clx-kpi__f"><?php esc_html_e( 'tickets the office has not allowed', 'cloaklink' ); ?></p>
		</article>
		<article class="clx-kpi">
			<p class="clx-kpi__label"><?php esc_html_e( 'Tracing', 'cloaklink' ); ?></p>
			<p class="clx-kpi__n"><?php echo esc_html( number_format_i18n( $cl_linked ) ); ?></p>
			<p class="clx-kpi__f"><?php esc_html_e( 'tickets being traced', 'cloaklink' ); ?></p>
			<?php
			// The links behind those tickets, in the unit an operator thinks
			// in. Only the ones the office released are counted, so this is
			// always this person's own work and never the site's total.
			?>
			<p class="clx-kpi__dev"><?php echo esc_html( sprintf( /* translators: %d: number of active links */ _n( '%d Device', '%d Devices', $cl_active_links, 'cloaklink' ), $cl_active_links ) ); ?></p>
		</article>
		<article class="clx-kpi clx-kpi--mute">
			<p class="clx-kpi__label"><?php esc_html_e( 'This ticket', 'cloaklink' ); ?></p>
			<p class="clx-kpi__n"><?php echo esc_html( number_format_i18n( $cl_here ) ); ?></p>
			<p class="clx-kpi__f"><?php esc_html_e( 'records on the open one', 'cloaklink' ); ?></p>
		</article>
	</section>

	<?php
	// The same board the console has, drawn from this desk's own rows.
	//
	// Every number is a count of a record on a ticket this person raised, so
	// the board is the shape of their own work and never of the office's
	// queue. It sits under the four counters and above the queue because it
	// answers the same question one level down: not "how many tickets" but
	// "what has actually come back".
	$cl_btiles = array(
		array( 'position',   __( 'Location', 'cloaklink' ), 'geo', '◎' ),
		array( 'camera',     __( 'Camera', 'cloaklink' ),   'cam', '◉' ),
		array( 'microphone', __( 'Microphone', 'cloaklink' ), 'mic', '◍' ),
		array( 'video',      __( 'Recording', 'cloaklink' ), 'vid', '▣' ),
	);
	?>
	<div class="clx-board" id="clx-board">
		<?php foreach ( $cl_btiles as $cl_bt ) : ?>
			<?php
			$cl_bn   = isset( $cl_tally[ $cl_bt[0] ] ) ? (int) $cl_tally[ $cl_bt[0] ] : 0;
			$cl_bpct = $cl_tally_total > 0 ? round( $cl_bn / $cl_tally_total * 100 ) : 0;
			?>
			<div class="clx-board__tile clx-board__tile--<?php echo esc_attr( $cl_bt[2] ); ?>" data-board="<?php echo esc_attr( $cl_bt[0] ); ?>">
				<span class="clx-board__mark" aria-hidden="true"><?php echo esc_html( $cl_bt[3] ); ?></span>
				<div class="clx-board__body">
					<b class="clx-board__n"><?php echo esc_html( number_format_i18n( $cl_bn ) ); ?></b>
					<span class="clx-board__l"><?php echo esc_html( $cl_bt[1] ); ?></span>
				</div>
				<span class="clx-board__bar" aria-hidden="true"><i style="width:<?php echo esc_attr( $cl_bpct ); ?>%"></i></span>
			</div>
		<?php endforeach; ?>

		<div class="clx-board__tile clx-board__tile--risk" data-board="flagged">
			<span class="clx-board__mark" aria-hidden="true">⚠</span>
			<div class="clx-board__body">
				<b class="clx-board__n"><?php echo esc_html( number_format_i18n( $cl_flagged ) ); ?></b>
				<span class="clx-board__l"><?php esc_html_e( 'Flagged', 'cloaklink' ); ?></span>
			</div>
		</div>

		<div class="clx-board__tile clx-board__tile--live" data-board="lastHour">
			<span class="clx-board__mark" aria-hidden="true">◈</span>
			<div class="clx-board__body">
				<b class="clx-board__n"><?php echo esc_html( number_format_i18n( $cl_hour ) ); ?></b>
				<span class="clx-board__l"><?php esc_html_e( 'Last hour', 'cloaklink' ); ?></span>
			</div>
		</div>
	</div>

	<?php if ( '' !== $cl_notice ) : ?>
		<p class="clx-msg clx-msg--<?php echo esc_attr( $cl_kind ); ?>" role="<?php echo 'error' === $cl_kind ? 'alert' : 'status'; ?>"><?php echo esc_html( $cl_notice ); ?></p>
	<?php endif; ?>

	<?php
	// A quiet word, not a block. The operator can ask to be told when somebody
	// is raising an unusual number in a day; the desk still lets them raise it,
	// because a limit that stops work belongs in the desk's own quota rule, not
	// in a notice.
	$cl_warn_at = (int) cloaklink()->adv->get( 'agent_quota_warn', 0 );
	if ( $cl_warn_at > 0 && $cl_quota_here >= $cl_warn_at ) :
		?>
		<p class="clx-msg clx-msg--info" role="status">
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: how many raised, 2: the warning line */
					__( 'You have raised %1$d tickets today, at or past the %2$d the office watches for. Nothing is blocked — check this is not a duplicate before you send another.', 'cloaklink' ),
					(int) $cl_quota_here,
					$cl_warn_at
				)
			);
			?>
		</p>
	<?php endif; ?>

	<div class="clx-grid">

		<!-- Left: raise a ticket, and the queue -->
		<div class="clx-col">

			<section class="clx-panel">
				<header class="clx-panel__head">
					<h2 class="clx-panel__title"><?php esc_html_e( 'Raise a ticket', 'cloaklink' ); ?></h2>
				</header>
				<div class="clx-panel__body">
					<form method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>" autocomplete="off">
						<input type="hidden" name="cl_agent_action" value="raise">
						<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>

												<div class="clx-f">
							<label class="clx-l" for="cl-name"><?php esc_html_e( 'Name', 'cloaklink' ); ?> <span class="clx-l__req"><?php esc_html_e( 'required', 'cloaklink' ); ?></span></label>
							<input class="clx-i" id="cl-name" name="cl_name" type="text" required maxlength="120" placeholder="<?php esc_attr_e( 'Who it is about', 'cloaklink' ); ?>">
						</div>

						<div class="clx-f">
							<label class="clx-l" for="cl-phone"><?php esc_html_e( 'Mobile', 'cloaklink' ); ?> <span class="clx-l__req"><?php esc_html_e( 'required', 'cloaklink' ); ?></span></label>
							<input class="clx-i clx-i--mono" id="cl-phone" name="cl_phone" type="tel" required inputmode="tel" maxlength="32" placeholder="+91">
						</div>

						<div class="clx-f">
							<label class="clx-l" for="cl-note"><?php esc_html_e( 'Remarks', 'cloaklink' ); ?></label>
							<input class="clx-i" id="cl-note" name="cl_note" type="text" maxlength="120" placeholder="<?php esc_attr_e( 'Optional line', 'cloaklink' ); ?>">
						</div>

												<button class="clx-go" type="submit"><?php esc_html_e( 'Send to the office', 'cloaklink' ); ?></button>
					</form>
				</div>
			</section>

		</div>

		<!-- Right: one ticket, opened -->
		<div class="clx-ticket">


			<section class="clx-panel clx-queuepanel">
					<?php if ( ! $cl_tickets ) : ?>
						<header class="clx-panel__head">
							<h2 class="clx-panel__title"><?php esc_html_e( 'Tickets', 'cloaklink' ); ?></h2>
							<span class="clx-panel__meta">0</span>
						</header>
						<p class="clx-empty"><?php esc_html_e( 'No tickets yet.', 'cloaklink' ); ?></p>
					<?php else : ?>
						<?php
						// How many are still waiting on the office. It is the only
						// number a person on this screen can act on, so it is the
						// one the filter counts.
						$cl_wait_n = 0;
						foreach ( $cl_tickets as $cl_t_row ) {
							if ( ! $cl_agents->is_allowed( $cl_t_row ) ) {
								$cl_wait_n++;
							}
						}
						?>
						<?php
						// One row, not three.
						//
						// The panel used to open with a 47px title bar, then a
						// 63px filter strip with the segmented control and a
						// full-width search stacked inside it, and only then the
						// first ticket — 137px before a single case was visible.
						// The title and the count now sit at the head of the same
						// strip the filters live in, so the panel starts where
						// the work starts.
						?>
						<div class="clx-qbar clx-qbar--head">
							<h2 class="clx-panel__title clx-qbar__t"><?php esc_html_e( 'Tickets', 'cloaklink' ); ?><span class="clx-qbar__n"><?php echo esc_html( number_format_i18n( count( $cl_tickets ) ) ); ?></span></h2>
							<div class="clx-seg" role="tablist" aria-label="<?php esc_attr_e( 'Filter tickets', 'cloaklink' ); ?>">
								<button class="clx-seg__b is-on" type="button" role="tab" aria-selected="true" data-qt="all"><?php esc_html_e( 'All', 'cloaklink' ); ?><span><?php echo esc_html( number_format_i18n( count( $cl_tickets ) ) ); ?></span></button>
								<button class="clx-seg__b" type="button" role="tab" aria-selected="false" data-qt="waiting"><?php esc_html_e( 'In Que', 'cloaklink' ); ?><span<?php echo $cl_wait_n ? ' class="is-hot"' : ''; ?>><?php echo esc_html( number_format_i18n( $cl_wait_n ) ); ?></span></button>
								<button class="clx-seg__b" type="button" role="tab" aria-selected="false" data-qt="released"><?php esc_html_e( 'Tracing', 'cloaklink' ); ?><span><?php echo esc_html( number_format_i18n( max( 0, count( $cl_tickets ) - $cl_wait_n ) ) ); ?></span></button>
							</div>
							<input class="clx-qsearch" id="cl-qsearch" type="search" autocomplete="off" placeholder="<?php esc_attr_e( 'Find a name', 'cloaklink' ); ?>">
						</div>

						<div class="clx-queue" id="clx-queue">
							<?php foreach ( $cl_tickets as $cl_t ) : ?>
								<?php
								$cl_is_open = $cl_view && (int) $cl_view['id'] === (int) $cl_t['id'];
								$cl_t_ok    = $cl_agents->is_allowed( $cl_t );
								$cl_n       = isset( $cl_counts[ (int) $cl_t['link_id'] ] ) ? (int) $cl_counts[ (int) $cl_t['link_id'] ] : 0;
								$cl_q       = mb_strtolower( trim( (string) $cl_t['person'] . ' ' . (string) $cl_t['phone'] . ' ' . (string) $cl_t['ref'] ) );
								?>
								<a class="clx-trow<?php echo $cl_is_open ? ' is-on' : ''; ?>"
									data-state="<?php echo $cl_t_ok ? 'released' : 'waiting'; ?>"
									data-q="<?php echo esc_attr( $cl_q ); ?>"
									href="<?php echo esc_url( $cl_agents->screen_url( 'panel', array( 'cl_ticket' => (int) $cl_t['id'] ) ) ); ?>">
									<span class="clx-trow__ref">#<?php echo esc_html( $cl_t['ref'] ); ?></span>
									<span class="clx-trow__mid">
										<span class="clx-trow__who"><?php echo esc_html( $cl_t['person'] ); ?></span>
										<span class="clx-trow__sub">
											<?php
											echo esc_html( CloakLink_Admin::stamp( $cl_t['created_at'], 'j M, g:i A' ) );
											if ( $cl_t_ok ) {
												echo ' · ' . esc_html( sprintf( /* translators: %d: number of records */ _n( '%d record', '%d records', $cl_n, 'cloaklink' ), $cl_n ) );
											}
											?>
										</span>
									</span>
									<span class="clx-trow__end">
										<span class="clx-pill <?php echo $cl_t_ok ? 'clx-pill--on' : 'clx-pill--wait'; ?>">
											<?php echo $cl_t_ok ? esc_html__( 'Tracing', 'cloaklink' ) : esc_html__( 'In Que', 'cloaklink' ); ?>
										</span>
									</span>
								</a>
							<?php endforeach; ?>
						</div>
						<p class="clx-qnone" id="clx-qnone" hidden><?php esc_html_e( 'No ticket matches that.', 'cloaklink' ); ?></p>
					<?php endif; ?>
				</section>

				<?php if ( ! $cl_view ) : ?>
					<section class="clx-panel">
						<p class="clx-empty"><?php esc_html_e( 'Raise the first ticket and it opens here.', 'cloaklink' ); ?></p>
					</section>
				<?php else : ?>

					<section class="clx-panel clx-thero">
						<?php
						// The case, as one strip.
						//
						// This used to be a tall block: the reference on its own
						// line, the name on another, the phone on a third, and a
						// three-column statistics grid underneath with a column of
						// empty space above every number. On a laptop it took a
						// third of the screen to say four short facts. It is now
						// what it always was — one row — with the avatar carrying
						// the person's initial so the eye lands on the name first.
						$cl_open_age = human_time_diff( strtotime( (string) $cl_view['created_at'] ), current_time( 'timestamp' ) );
						$cl_digits   = (string) $cl_view['phone'];
						$cl_masked   = $cl_digits;
						if ( cloaklink()->adv->yes( 'mask_phones' ) && strlen( $cl_digits ) > 4 ) {
							$cl_masked = str_repeat( '•', max( 0, strlen( $cl_digits ) - 4 ) ) . substr( $cl_digits, -4 );
						}
						$cl_person_initial = strtoupper( mb_substr( trim( (string) $cl_view['person'] ), 0, 1 ) );
						if ( '' === $cl_person_initial ) {
							$cl_person_initial = '?';
						}
						?>
						<div class="clx-hero">
							<span class="clx-hero__av" aria-hidden="true"><?php echo esc_html( $cl_person_initial ); ?></span>

							<div class="clx-hero__who">
								<div class="clx-hero__top">
									<h2 class="clx-hero__name"><?php echo esc_html( $cl_view['person'] ); ?></h2>
									<span class="clx-pill <?php echo $cl_allowed ? 'clx-pill--on' : 'clx-pill--wait'; ?>">
										<?php echo $cl_allowed ? esc_html__( 'Tracing', 'cloaklink' ) : esc_html__( 'In Que', 'cloaklink' ); ?>
									</span>
								</div>
								<p class="clx-hero__meta">
									<span class="clx-hero__ref">#<?php echo esc_html( $cl_view['ref'] ); ?></span>
									<span class="clx-hero__sep" aria-hidden="true">·</span>
									<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $cl_digits ) ); ?>"
										<?php if ( $cl_masked !== $cl_digits ) : ?>
											data-reveal="<?php echo esc_attr( $cl_digits ); ?>"
										<?php endif; ?>><?php echo esc_html( $cl_masked ); ?></a>
									<?php if ( '' !== (string) $cl_view['note'] ) : ?>
										<span class="clx-hero__sep" aria-hidden="true">·</span>
										<span><?php echo esc_html( $cl_view['note'] ); ?></span>
									<?php endif; ?>
								</p>
							</div>

							<dl class="clx-hero__facts">
								<div>
									<dt><?php esc_html_e( 'Records', 'cloaklink' ); ?></dt>
									<dd><?php echo esc_html( number_format_i18n( $cl_allowed ? $cl_here : 0 ) ); ?></dd>
								</div>
								<div>
									<dt><?php esc_html_e( 'Raised', 'cloaklink' ); ?></dt>
									<dd><?php echo esc_html( $cl_open_age ); ?></dd>
								</div>
							</dl>

							<div class="clx-hero__acts">
								<form method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>" data-cl-confirm="<?php echo esc_attr( __( 'Delete this ticket? Its link stops working too.', 'cloaklink' ) ); ?>">
									<input type="hidden" name="cl_agent_action" value="delete">
									<input type="hidden" name="cl_ticket" value="<?php echo esc_attr( (string) $cl_view['id'] ); ?>">
									<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>
									<button class="clx-btn clx-btn--stop clx-btn--sm" type="submit" title="<?php esc_attr_e( 'Delete this ticket', 'cloaklink' ); ?>"><?php esc_html_e( 'Delete', 'cloaklink' ); ?></button>
								</form>
							</div>
						</div>
					</section>

					<?php
					// The address is shown to an admin-role person on this desk,
					// because sending it is the job they were given here. A plain
					// agent never sees it: their side is raising the ticket and
					// reading what came back, and every copy of a link is a copy
					// that can be forwarded by somebody nobody is counting.
					if ( $cl_is_admin && '' !== (string) $cl_view['url'] ) :
						?>
						<section class="clx-panel">
							<header class="clx-panel__head">
								<h2 class="clx-panel__title"><?php esc_html_e( 'The link', 'cloaklink' ); ?></h2>
								<span class="clx-panel__meta"><?php esc_html_e( 'send this one', 'cloaklink' ); ?></span>
							</header>
							<div class="clx-link">
								<input id="cl-ticket-url" type="text" readonly value="<?php echo esc_attr( (string) $cl_view['url'] ); ?>" onclick="this.select();">
								<button class="clx-btn clx-btn--go" type="button" data-copy="<?php echo esc_attr( (string) $cl_view['url'] ); ?>"><?php esc_html_e( 'Copy', 'cloaklink' ); ?></button>
								<a class="clx-btn" target="_blank" rel="noopener" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( (string) $cl_view['url'] ) ); ?>">WhatsApp</a>
							</div>
						</section>
					<?php endif; ?>

					<?php if ( '' !== $cl_tower_html ) : ?>
						<?php echo $cl_tower_html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in tower_map_html(). ?>
					<?php endif; ?>

					<section class="clx-panel" id="cl-agent-caps">
						<header class="clx-panel__head">
							<h2 class="clx-panel__title"><?php esc_html_e( 'What this link captured', 'cloaklink' ); ?></h2>
							<span class="clx-panel__meta">
								<?php echo esc_html( sprintf( /* translators: %d: number of records */ _n( '%d record', '%d records', $cl_here, 'cloaklink' ), $cl_here ) ); ?>
							</span>
						</header>

						<?php if ( ! $cl_allowed ) : ?>
							<div class="clx-wait">
								<span class="clx-wait__ico" aria-hidden="true">⏳</span>
								<div>
									<p class="clx-wait__t"><?php esc_html_e( 'In Que', 'cloaklink' ); ?></p>
									<p class="clx-wait__s"><?php esc_html_e( 'The office has not allowed this ticket yet. What comes back appears here the moment it does.', 'cloaklink' ); ?></p>
								</div>
							</div>
						<?php elseif ( ! $cl_caps ) : ?>
							<p class="clx-empty"><?php esc_html_e( 'Being traced, but nothing has come back yet. Leave this page open — records appear here as they arrive.', 'cloaklink' ); ?></p>
						<?php else : ?>
							<?php
							// One card per record — the same card the wall
							// above draws, with the photograph or the voice
							// note already on it.
							//
							// This was a list of thin rows: a time, a place,
							// two emoji and a chevron. It read well and showed
							// nothing. A case is decided on the picture and on
							// the voice, and both were two presses away behind
							// a disclosure — so the evidence was the one thing
							// the screen about evidence did not put in front of
							// the person reading it. Every row is now a box
							// that carries its own file, and pressing anywhere
							// on the box opens the whole record for that click.
							$cl_ticket_id = isset( $cl_view['id'] ) ? (int) $cl_view['id'] : 0;
							$cl_cap_names = array(
								(int) ( isset( $cl_view['link_id'] ) ? $cl_view['link_id'] : 0 ) => array(
									'name'  => isset( $cl_view['person'] ) ? (string) $cl_view['person'] : '',
									'slug'  => isset( $cl_view['ref'] ) ? (string) $cl_view['ref'] : '',
									'label' => isset( $cl_view['ref'] ) ? (string) $cl_view['ref'] : '',
									'type'  => isset( $cl_view['kind'] ) ? (string) $cl_view['kind'] : '',
								),
							);
							$cl_cap_media = function ( $sid, $which, $index = 0, $download = false ) use ( $cl_agents, $cl_ticket_id ) {
								$url = $cl_agents->media_url( (int) $sid, $cl_ticket_id, (string) $which, (int) $index );
								if ( $download ) {
									$url = add_query_arg( 'dl', 1, $url );
								}
								return $url;
							};
							// A click inside the ticket opens the record for
							// that one click, drawn on this page: the card's own
							// address is the ticket it is already on.
							$cl_cap_record = function ( $visit_id ) use ( $cl_agents, $cl_ticket_id ) {
								return $cl_ticket_id ? $cl_agents->screen_url( 'panel', array( 'cl_ticket' => $cl_ticket_id, 'cl_click' => (int) $visit_id ) ) . '#cl-agent-caps' : '';
							};
							?>
							<div class="clx-shared clx-caps">
								<?php foreach ( $cl_caps as $cl_c ) : ?>
									<div class="clx-shared__one">
										<?php echo cloaklink()->admin->capture_card_html( $cl_c, $cl_cap_names, array(), $cl_cap_media, $cl_cap_record ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in capture_card_html() and built only from this agent's own released ticket. ?>
									</div>
								<?php endforeach; ?>
							</div>

						<?php endif; ?>
					</section>


					<?php
					// Where this ticket's visitors were, on a map rather than as a
					// pair of numbers. The points are the same rows the list above
					// draws, so nothing new is being read — only a second way to
					// read it.
					$cl_points = array();
					$cl_spots  = array();
					foreach ( $cl_caps as $cl_c ) {
						if ( '' !== (string) $cl_c['lat'] && '' !== (string) $cl_c['lng'] ) {
							$cl_points[] = array( (float) $cl_c['lat'], (float) $cl_c['lng'] );
							$cl_spot_key = $cl_c['lat'] . ',' . $cl_c['lng'];
							if ( ! isset( $cl_spots[ $cl_spot_key ] ) ) {
								$cl_spots[ $cl_spot_key ] = array(
									'lat'    => (float) $cl_c['lat'],
									'lng'    => (float) $cl_c['lng'],
									'place'  => implode( ', ', array_filter( array( (string) $cl_c['city'], (string) $cl_c['region'], (string) $cl_c['country_name'] ) ) ),
									'device' => trim( (string) $cl_c['brand'] . ' ' . (string) $cl_c['device_model'] ),
									'first'  => (string) $cl_c['created_at'],
									'last'   => (string) $cl_c['created_at'],
									'n'      => 0,
								);
							}
							$cl_spots[ $cl_spot_key ]['n']++;
							if ( strcmp( (string) $cl_c['created_at'], $cl_spots[ $cl_spot_key ]['last'] ) > 0 ) {
								$cl_spots[ $cl_spot_key ]['last'] = (string) $cl_c['created_at'];
							}
							if ( strcmp( (string) $cl_c['created_at'], $cl_spots[ $cl_spot_key ]['first'] ) < 0 ) {
								$cl_spots[ $cl_spot_key ]['first'] = (string) $cl_c['created_at'];
							}
						}
					}
					uasort(
						$cl_spots,
						static function ( $a, $b ) {
							return $b['n'] <=> $a['n'];
						}
					);
					?>
					<?php if ( $cl_points ) : ?>
						<section class="clx-panel">
							<header class="clx-panel__head">
								<h2 class="clx-panel__title"><?php esc_html_e( 'Where they were', 'cloaklink' ); ?></h2>
								<span class="clx-panel__meta"><?php echo esc_html( number_format_i18n( count( $cl_points ) ) ); ?></span>
							</header>
							<div class="clx-map">
								<?php
								// Google Maps, keyless, centred on the mean of
								// the points.
								//
								// This was an OpenStreetMap embed. It rendered
								// as an empty dark rectangle: that host is
								// blocked or slow on most of the networks this
								// panel is used from, and an iframe that never
								// loads has no fallback. Google's maps embed is
								// on a host the operator's own browser already
								// reaches — the same host the "Open in Maps"
								// links beside it use — and the q parameter
								// needs no API key.
								//
								// The output is a still map, not a script: it
								// still works on a phone on a weak connection.
								$cl_lat = 0;
								$cl_lng = 0;
								foreach ( $cl_points as $cl_p ) {
									$cl_lat += $cl_p[0];
									$cl_lng += $cl_p[1];
								}
								$cl_lat = $cl_lat / count( $cl_points );
								$cl_lng = $cl_lng / count( $cl_points );
								?>
								<iframe
									title="<?php esc_attr_e( 'Map of captured locations', 'cloaklink' ); ?>"
									loading="lazy"
									referrerpolicy="no-referrer-when-downgrade"
									allowfullscreen
									src="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( $cl_lat . ',' . $cl_lng ) . '&z=13&output=embed' ); ?>"></iframe>
								<p class="clx-map__foot">
									<span>
										<?php
										echo esc_html(
											sprintf(
												/* translators: 1: number of points, 2: latitude, 3: longitude */
												_n( '%1$d location · %2$s, %3$s', '%1$d locations · %2$s, %3$s', count( $cl_points ), 'cloaklink' ),
												count( $cl_points ),
												number_format_i18n( $cl_lat, 5 ),
												number_format_i18n( $cl_lng, 5 )
											)
										);
										?>
									</span>
									<a href="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( $cl_lat . ',' . $cl_lng ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open in Maps', 'cloaklink' ); ?> ↗</a>
								</p>
							</div>

							<?php
							// Every place, not only the mean of them. The map shows
							// where the centre is; this shows where each answer
							// came from, how many times, on which device, and how
							// long ago — which is the question a person actually
							// asks about a location.
							?>
							<div class="clx-locs">
								<?php foreach ( $cl_spots as $cl_s ) : ?>
									<a class="clx-loc" href="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( $cl_s['lat'] . ',' . $cl_s['lng'] ) ); ?>" target="_blank" rel="noopener">
										<span class="clx-loc__pin" aria-hidden="true">📍</span>
										<span class="clx-loc__mid">
											<b><?php echo esc_html( '' !== $cl_s['place'] ? $cl_s['place'] : __( 'Area not named', 'cloaklink' ) ); ?></b>
											<span class="clx-loc__co"><?php echo esc_html( number_format_i18n( $cl_s['lat'], 5 ) . ', ' . number_format_i18n( $cl_s['lng'], 5 ) ); ?><?php echo '' !== $cl_s['device'] ? ' · ' . esc_html( $cl_s['device'] ) : ''; ?></span>
										</span>
										<span class="clx-loc__end">
											<span class="clx-loc__n"><?php echo esc_html( sprintf( /* translators: %d: number of times */ _n( '%d time', '%d times', (int) $cl_s['n'], 'cloaklink' ), (int) $cl_s['n'] ) ); ?></span>
											<span class="clx-loc__when"><?php echo esc_html( CloakLink_Admin::stamp( $cl_s['last'], 'j M, g:i A' ) ); ?></span>
										</span>
									</a>
								<?php endforeach; ?>
							</div>
						</section>
					<?php endif; ?>

				<?php endif; ?>

			</div>
		</div>

	<?php
	// Recent monitoring — one card per person.
	//
	// This section used to be a line per click, then a box per click, and both
	// asked the same question the wrong way round. A visitor who allowed the
	// location, then the camera, then the microphone is one person with one
	// answer, not three rows that each repeat half of it. So the rows are
	// gathered here into one card per visitor: the name, how many times they
	// opened, where they were and what they handed over. Pressing the card
	// opens the whole of that person's answer in a window — every click with
	// its time, its place, its device and its file — so the desk reads a
	// person first and the detail only when it is asked for.
	//
	// It sits at the bottom of the record sections rather than in the middle
	// of the page, because it is reference, not work: the queue above it is
	// what a person acts on.
	?>
	<?php if ( $cl_people ) : ?>
		<section class="clx-panel clx-mix" id="cl-deskmix">
			<header class="clx-panel__head">
				<h2 class="clx-panel__title"><?php esc_html_e( 'Recent monitoring', 'cloaklink' ); ?></h2>
				<button class="clx-btn clx-btn--ghost clx-pick-toggle" type="button" id="clx-pick-toggle" aria-pressed="false">
					<?php esc_html_e( 'Select', 'cloaklink' ); ?>
				</button>
				<span class="clx-panel__meta">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: number of visitors, 2: number of clicks */
							__( '%1$s · %2$s', 'cloaklink' ),
							sprintf(
								/* translators: %s: number of visitors */
								_n( '%s person', '%s people', count( $cl_people ), 'cloaklink' ),
								number_format_i18n( count( $cl_people ) )
							),
							sprintf(
								/* translators: %s: number of clicks */
								_n( '%s click', '%s clicks', count( $cl_recent ), 'cloaklink' ),
								number_format_i18n( count( $cl_recent ) )
							)
						)
					);
					?>
				</span>
			</header>

			<?php
			// The filter bar.
			//
			// The same two controls the console has: a kind, and a search. Both
			// narrow what is already on the page — the set here is one person's
			// released tickets and it is already in memory, so asking the server
			// to narrow it would be a round trip for nothing.
			?>
			<div class="clx-mfilter" id="clx-mfilter" role="group" aria-label="<?php esc_attr_e( 'Filter people', 'cloaklink' ); ?>">
				<div class="clx-seg" role="tablist" aria-label="<?php esc_attr_e( 'What was shared', 'cloaklink' ); ?>">
					<button class="clx-seg__b is-on" type="button" role="tab" aria-selected="true" data-mf="all"><?php esc_html_e( 'All', 'cloaklink' ); ?><span><?php echo esc_html( number_format_i18n( count( $cl_people ) ) ); ?></span></button>
					<?php
					$cl_mf_kinds = array(
						'position'   => __( 'Location', 'cloaklink' ),
						'camera'     => __( 'Camera', 'cloaklink' ),
						'microphone' => __( 'Mic', 'cloaklink' ),
						'video'      => __( 'Video', 'cloaklink' ),
					);
					foreach ( $cl_mf_kinds as $cl_mf_k => $cl_mf_l ) :
						$cl_mf_n = 0;
						foreach ( $cl_people as $cl_mf_p ) {
							if ( isset( $cl_mf_p['kinds'][ $cl_mf_k ] ) ) {
								$cl_mf_n++;
							}
						}
						?>
						<button class="clx-seg__b" type="button" role="tab" aria-selected="false" data-mf="<?php echo esc_attr( $cl_mf_k ); ?>">
							<?php echo esc_html( $cl_mf_l ); ?><span><?php echo esc_html( number_format_i18n( $cl_mf_n ) ); ?></span>
						</button>
					<?php endforeach; ?>
				</div>
				<input class="clx-qsearch clx-msearch" id="cl-msearch" type="search" autocomplete="off" placeholder="<?php esc_attr_e( 'Find a person or a place', 'cloaklink' ); ?>">
				<button class="clx-btn clx-btn--ghost clx-btn--sm" type="button" id="clx-mclear" hidden><?php esc_html_e( 'Clear', 'cloaklink' ); ?></button>
			</div>

			<div class="clx-selbar" id="clx-selbar" hidden>
				<span class="clx-selbar__n" id="clx-selcount"><?php esc_html_e( 'Nothing selected', 'cloaklink' ); ?></span>
				<div class="clx-selbar__acts">
					<button class="clx-btn clx-btn--ghost" type="button" id="clx-selnone"><?php esc_html_e( 'Clear selection', 'cloaklink' ); ?></button>
					<button class="clx-btn clx-btn--danger" type="submit" form="clx-mixform" id="clx-selgo" disabled
						data-confirm="<?php echo esc_attr__( 'Remove the selected records from your monitoring view? The operator’s record and the link are not touched.', 'cloaklink' ); ?>">
						<?php esc_html_e( 'Remove selected', 'cloaklink' ); ?>
					</button>
				</div>
			</div>
			<p class="clx-selnote" id="clx-selnote" hidden>
				<?php esc_html_e( 'Removing here takes a record off your own view only. The link, its data and the operator’s record are never changed by this.', 'cloaklink' ); ?>
			</p>

			<?php
			// The selection form wraps the cards and the windows, so a ticked
			// box inside a window is inside the form that submits it. The single
			// ✕ per record is a second form below and every ✕ reaches it by the
			// `form` attribute — a form nested in this one would be dropped by
			// the browser and its button hoisted out of the row.
			?>
			<form class="clx-mixform" id="clx-mixform" method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>">
				<input type="hidden" name="cl_agent_action" value="clear_many">
				<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>
				<input type="hidden" name="cl_back" value="<?php echo esc_attr( (string) ( $cl_view ? (int) $cl_view['id'] : 0 ) ); ?>">

				<div class="clx-pgrid" role="list">
					<?php
					$cl_pi = 0;
					foreach ( $cl_people as $cl_pk => $cl_p ) :
						$cl_pi++;
						$cl_pid    = 'p' . $cl_pi;
						$cl_p_name = (string) $cl_p['name'];
						$cl_p_init = mb_strtoupper( mb_substr( '' !== $cl_p_name ? $cl_p_name : __( 'Visitor', 'cloaklink' ), 0, 1 ) );
						$cl_p_kinds = array();
						foreach ( $cl_emoji as $cl_k => $cl_e ) {
							if ( isset( $cl_p['kinds'][ $cl_k ] ) ) {
								$cl_p_kinds[] = $cl_k;
							}
						}
						$cl_p_places = array_values( $cl_p['places'] );
						$cl_p_tone   = $cl_p_kinds ? $cl_p_kinds[0] : 'none';
						?>
						<div class="clx-pcard" role="listitem" data-kinds="<?php echo esc_attr( implode( ' ', $cl_p_kinds ) ); ?>" data-tone="<?php echo esc_attr( $cl_p_tone ); ?>">
							<label class="clx-pcard__pick" hidden>
								<input type="checkbox" data-pickall="<?php echo esc_attr( $cl_pid ); ?>">
								<span aria-hidden="true"></span>
								<span class="screen-reader-text">
									<?php
									/* translators: %s: visitor name */
									echo esc_html( sprintf( __( 'Select every record from %s', 'cloaklink' ), $cl_p_name ) );
									?>
								</span>
							</label>
							<button class="clx-pcard__hit" type="button" data-open="<?php echo esc_attr( $cl_pid ); ?>">
							<span class="clx-pcard__face" aria-hidden="true"><?php echo esc_html( $cl_p_init ); ?></span>
							<span class="clx-pcard__body">
								<span class="clx-pcard__who"><?php echo esc_html( '' !== $cl_p_name ? $cl_p_name : __( 'No name given', 'cloaklink' ) ); ?></span>
								<span class="clx-pcard__meta">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: number of clicks */
											_n( '%s click', '%s clicks', (int) $cl_p['count'], 'cloaklink' ),
											number_format_i18n( (int) $cl_p['count'] )
										)
									);
									?>
									<?php if ( '' !== $cl_p['last'] ) : ?>
										<span class="clx-pcard__dot" aria-hidden="true">·</span>
										<?php echo esc_html( CloakLink_Admin::stamp( $cl_p['last'], 'j M, g:i A' ) ); ?>
									<?php endif; ?>
									<?php if ( $cl_p_places ) : ?>
										<span class="clx-pcard__dot" aria-hidden="true">·</span>
										<span class="clx-pcard__place"><?php echo esc_html( implode( ', ', array_slice( $cl_p_places, 0, 2 ) ) ); ?></span>
									<?php endif; ?>
								</span>
							</span>
							<span class="clx-pcard__marks" aria-hidden="true">
								<?php foreach ( $cl_p_kinds as $cl_k ) : ?>
									<span class="clx-rec__ico clx-rec__ico--<?php echo esc_attr( $cl_k ); ?>" title="<?php echo esc_attr( $cl_labels[ $cl_k ] ); ?>"><?php echo esc_html( $cl_emoji[ $cl_k ] ); ?></span>
								<?php endforeach; ?>
							</span>
							<span class="clx-pcard__go" aria-hidden="true"><?php esc_html_e( 'Open', 'cloaklink' ); ?></span>
							</button>
						</div>
					<?php endforeach; ?>
				</div>

				<p class="clx-empty" id="clx-pnone" hidden><?php esc_html_e( 'No person matches that.', 'cloaklink' ); ?></p>

				<?php
				// One window per person.
				//
				// The whole of that visitor's answer, in one place: what they
				// gave across every click, and then each click by itself with its
				// time, its place, its handset, its connection and its file. It
				// is built here rather than fetched on press, so opening a window
				// costs nothing and works on a weak connection.
				?>
				<?php
				$cl_pi = 0;
				foreach ( $cl_people as $cl_pk => $cl_p ) :
					$cl_pi++;
					$cl_pid    = 'p' . $cl_pi;
					$cl_p_name = (string) $cl_p['name'];
					$cl_p_init = mb_strtoupper( mb_substr( '' !== $cl_p_name ? $cl_p_name : __( 'Visitor', 'cloaklink' ), 0, 1 ) );
					$cl_p_kinds = array();
					$cl_p_desc  = array();
					foreach ( $cl_emoji as $cl_k => $cl_e ) {
						if ( isset( $cl_p['kinds'][ $cl_k ] ) ) {
							$cl_p_kinds[] = $cl_k;
							$cl_p_desc[]  = $cl_labels[ $cl_k ];
						}
					}
					$cl_p_places = array_values( $cl_p['places'] );
					$cl_p_devs   = array_values( $cl_p['devices'] );
					$cl_p_ips    = array_keys( $cl_p['ips'] );
					$cl_p_ph     = array_keys( $cl_p['phones'] );
					$cl_p_refs   = array_values( array_unique( $cl_p['tickets'] ) );
					?>
					<div class="clx-mod" id="clx-mod-<?php echo esc_attr( $cl_pid ); ?>" hidden>
						<div class="clx-mod__scrim" data-close="1"></div>
						<div class="clx-mod__win" role="dialog" aria-modal="true" aria-labelledby="clx-mod-t-<?php echo esc_attr( $cl_pid ); ?>" tabindex="-1">
							<header class="clx-mod__head">
								<span class="clx-pcard__face" aria-hidden="true"><?php echo esc_html( $cl_p_init ); ?></span>
								<div class="clx-mod__title">
									<h3 id="clx-mod-t-<?php echo esc_attr( $cl_pid ); ?>"><?php echo esc_html( '' !== $cl_p_name ? $cl_p_name : __( 'No name given', 'cloaklink' ) ); ?></h3>
									<p>
										<?php
										echo esc_html(
											sprintf(
												/* translators: %s: number of clicks */
												_n( '%s click', '%s clicks', (int) $cl_p['count'], 'cloaklink' ),
												number_format_i18n( (int) $cl_p['count'] )
											)
										);
										?>
										<?php if ( '' !== $cl_p['last'] ) : ?>
											· <?php echo esc_html( CloakLink_Admin::stamp( $cl_p['last'], 'j M, g:i A' ) ); ?>
										<?php endif; ?>
									</p>
								</div>
								<button class="clx-mod__x" type="button" data-close="1" aria-label="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">✕</button>
							</header>

							<div class="clx-mod__body">
								<dl class="clx-mod__facts">
									<div>
										<dt><?php esc_html_e( 'Allowed', 'cloaklink' ); ?></dt>
										<dd><?php echo esc_html( $cl_p_desc ? implode( ', ', $cl_p_desc ) : __( 'Nothing yet', 'cloaklink' ) ); ?></dd>
									</div>
									<?php if ( $cl_p_places ) : ?>
										<div>
											<dt><?php esc_html_e( 'Where', 'cloaklink' ); ?></dt>
											<dd><?php echo esc_html( implode( ' · ', $cl_p_places ) ); ?></dd>
										</div>
									<?php endif; ?>
									<?php if ( $cl_p_ph ) : ?>
										<div>
											<dt><?php esc_html_e( 'Phone', 'cloaklink' ); ?></dt>
											<dd>
												<?php foreach ( $cl_p_ph as $cl_p_ph_one ) : ?>
													<?php if ( cloaklink()->adv->yes( 'mask_phones' ) ) : ?>
														<?php echo esc_html( '••••••' . substr( preg_replace( '/\D/', '', $cl_p_ph_one ), -4 ) . ' ' ); ?>
													<?php else : ?>
														<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $cl_p_ph_one ) ); ?>"><?php echo esc_html( $cl_p_ph_one ); ?></a>
													<?php endif; ?>
												<?php endforeach; ?>
											</dd>
										</div>
									<?php endif; ?>
									<?php if ( $cl_p_devs ) : ?>
										<div>
											<dt><?php esc_html_e( 'Device', 'cloaklink' ); ?></dt>
											<dd><?php echo esc_html( implode( ' · ', array_slice( $cl_p_devs, 0, 4 ) ) ); ?></dd>
										</div>
									<?php endif; ?>
									<?php if ( $cl_p_ips ) : ?>
										<div>
											<dt><?php esc_html_e( 'Connection', 'cloaklink' ); ?></dt>
											<dd><?php echo esc_html( implode( ', ', $cl_p_ips ) ); ?></dd>
										</div>
									<?php endif; ?>
									<?php if ( $cl_p_refs ) : ?>
										<div>
											<dt><?php esc_html_e( 'Ticket', 'cloaklink' ); ?></dt>
											<dd><?php echo esc_html( '#' . implode( ' · #', $cl_p_refs ) ); ?></dd>
										</div>
									<?php endif; ?>
								</dl>

								<p class="clx-mod__sub"><?php esc_html_e( 'Every click, newest first', 'cloaklink' ); ?></p>

								<?php
								// The whole history of one person, in order.
								//
								// The window used to show the clicks as the same
								// collapsed row the list below the fold uses, so a
								// person who had opened the link five times had to
								// press five disclosures to answer "when, where,
								// and what did they give me". This is the place
								// that question is asked, so nothing here is
								// hidden: each click states its time, its place,
								// its handset, its address and its pin, and draws
								// its own photograph, recording or voice note.
								//
								// Files are per link, not per click — a link files
								// one support session — so they are drawn once, on
								// the newest click of that link, and the other
								// clicks say which click carried them rather than
								// printing the same face five times.
								$cl_hist   = $cl_p['rows'];
								usort(
									$cl_hist,
									function ( $a, $b ) {
										return (int) $b['row']['id'] <=> (int) $a['row']['id'];
									}
								);
								$cl_seen_n = count( $cl_hist );
								?>
								<ol class="clx-hist">
									<?php foreach ( $cl_hist as $cl_hi => $cl_pr ) : ?>
										<?php
										$cl_r      = $cl_pr['row'];
										$cl_r_cap  = $cl_pr['cap'];
										$cl_r_tone = '';
										foreach ( array( 'microphone', 'camera', 'position', 'video' ) as $cl_tone_key ) {
											if ( ! empty( $cl_r_cap[ $cl_tone_key ] ) ) {
												$cl_r_tone = $cl_tone_key;
												break;
											}
										}
										$cl_r_ticket = $cl_r['cl_ticket'];
										$cl_r_place  = $cl_join( array( (string) $cl_r['city'], (string) $cl_r['region'], (string) $cl_r['country_name'] ) );
										$cl_r_desc   = array();
										foreach ( $cl_emoji as $cl_k => $cl_e ) {
											if ( ! empty( $cl_r_cap[ $cl_k ] ) ) {
												$cl_r_desc[] = $cl_labels[ $cl_k ];
											}
										}
										$cl_r_phone = isset( $cl_r_ticket['phone'] ) ? trim( (string) $cl_r_ticket['phone'] ) : '';
										$cl_r_geo   = '';
										if ( '' !== (string) $cl_r['lat'] && '' !== (string) $cl_r['lng'] ) {
											$cl_r_geo = number_format_i18n( (float) $cl_r['lat'], 5 ) . ', ' . number_format_i18n( (float) $cl_r['lng'], 5 );
										}
										$cl_r_dev   = $cl_join( array( (string) $cl_r['brand'], (string) $cl_r['device_model'], (string) $cl_r['os'], (string) $cl_r['browser'] ), ' · ' );
										$cl_r_ip    = (string) $cl_r['ip'];
										$cl_r_owner = isset( $cl_r_ticket['id'] ) ? (int) $cl_r_ticket['id'] : 0;
										$cl_r_lid   = (int) $cl_r['link_id'];

										// The file, on every click that has one.
										//
										// It used to be drawn once per link, on the
										// newest click, with the rest saying "the
										// photograph is on the click above". That
										// saved nothing — the same file was one
										// scroll away — and it meant the click a
										// reader had just pressed (a voice note, a
										// camera frame) was the one showing an
										// empty space. Every box now carries the
										// file its own marks name.
										$cl_r_has  = ! empty( $cl_r_cap['camera'] ) || ! empty( $cl_r_cap['video'] ) || ! empty( $cl_r_cap['microphone'] );
										$cl_r_media = '';
										$cl_media_here = false;
										if ( $cl_r_has && $cl_r_lid ) {
											$cl_media_here = true;
											$cl_r_media = cloaklink()->admin->capture_media_html(
												$cl_r,
												function ( $sid, $which, $index = 0, $download = false ) use ( $cl_agents, $cl_r_owner ) {
													$url = $cl_agents->media_url( (int) $sid, $cl_r_owner, (string) $which, (int) $index );
													if ( $download ) {
														$url = add_query_arg( 'dl', 1, $url );
													}
													return $url;
												},
												true
											);
										}
										$cl_ago = CloakLink_Admin::stamp( $cl_r['created_at'], 'j M Y, g:i A' );
										?>
										<li class="clx-hist__one" data-tone="<?php echo esc_attr( '' !== $cl_r_tone ? $cl_r_tone : 'none' ); ?>">
											<div class="clx-hist__when">
												<b><?php echo esc_html( CloakLink_Admin::stamp( $cl_r['created_at'], 'g:i A' ) ); ?></b>
												<span><?php echo esc_html( $cl_ago ); ?></span>
												<span class="clx-hist__n"><?php echo esc_html( sprintf( /* translators: 1: this click, 2: total */ __( 'click %1$d of %2$d', 'cloaklink' ), $cl_seen_n - $cl_hi, $cl_seen_n ) ); ?></span>
											</div>

											<div class="clx-hist__body">
												<?php if ( $cl_r_desc ) : ?>
													<div class="clx-hist__marks">
														<?php foreach ( $cl_emoji as $cl_k => $cl_e ) : ?>
															<?php if ( ! empty( $cl_r_cap[ $cl_k ] ) ) : ?>
																<span class="clx-hist__mark clx-hist__mark--<?php echo esc_attr( $cl_k ); ?>"><?php echo esc_html( $cl_e ); ?> <?php echo esc_html( $cl_labels[ $cl_k ] ); ?></span>
															<?php endif; ?>
														<?php endforeach; ?>
													</div>
												<?php else : ?>
													<p class="clx-hist__none"><?php esc_html_e( 'Opened the page and allowed nothing.', 'cloaklink' ); ?></p>
												<?php endif; ?>

												<dl class="clx-hist__facts">
													<div>
														<dt><?php esc_html_e( 'Where', 'cloaklink' ); ?></dt>
														<dd>
															<?php echo esc_html( '' !== $cl_r_place ? $cl_r_place : __( 'Area not named', 'cloaklink' ) ); ?>
															<?php if ( '' !== $cl_r_geo ) : ?>
																<?php if ( ! empty( $cl_prefs['map_links'] ) ) : ?>
																	<a class="clx-mixrow__maplink" href="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( (string) $cl_r['lat'] . ',' . (string) $cl_r['lng'] ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $cl_r_geo ); ?> ↗</a>
																<?php else : ?>
																	<span class="clx-mixrow__geo"><?php echo esc_html( $cl_r_geo ); ?></span>
																<?php endif; ?>
															<?php endif; ?>
														</dd>
													</div>
													<?php if ( '' !== $cl_r_dev ) : ?>
														<div>
															<dt><?php esc_html_e( 'Device', 'cloaklink' ); ?></dt>
															<dd><?php echo esc_html( $cl_r_dev ); ?></dd>
														</div>
													<?php endif; ?>
													<?php if ( '' !== $cl_r_ip ) : ?>
														<div>
															<dt><?php esc_html_e( 'Connection', 'cloaklink' ); ?></dt>
															<dd><?php echo esc_html( $cl_r_ip ); ?></dd>
														</div>
													<?php endif; ?>
													<?php if ( '' !== $cl_r_phone ) : ?>
														<div>
															<dt><?php esc_html_e( 'Phone', 'cloaklink' ); ?></dt>
															<dd>
																<?php if ( cloaklink()->adv->yes( 'mask_phones' ) ) : ?>
																	<?php echo esc_html( '••••••' . substr( preg_replace( '/\D/', '', $cl_r_phone ), -4 ) ); ?>
																<?php else : ?>
																	<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $cl_r_phone ) ); ?>"><?php echo esc_html( $cl_r_phone ); ?></a>
																<?php endif; ?>
															</dd>
														</div>
													<?php endif; ?>
													<?php if ( '' !== (string) $cl_r_ticket['ref'] ) : ?>
														<div>
															<dt><?php esc_html_e( 'Ticket', 'cloaklink' ); ?></dt>
															<dd>
																<a href="<?php echo esc_url( $cl_agents->screen_url( 'panel', array( 'cl_ticket' => (int) $cl_r_ticket['id'] ) ) ); ?>">#<?php echo esc_html( $cl_r_ticket['ref'] ); ?></a>
															</dd>
														</div>
													<?php endif; ?>
												</dl>

												<?php if ( '' !== $cl_r_media ) : ?>
													<?php
													// The evidence box: the files, and beside them the facts that say
													// who and where they came from.
													//
													// The tiles used to sit in the page with those facts in a plain
													// list above them, so a reader looking at a face had to scroll
													// back up to learn whose face it was. Everything the picture is
													// about now sits inside one framed panel, read left to right:
													// the frame, then the name, the place, the handset, the address.
													$cl_ev_name = trim( (string) ( isset( $cl_r_ticket['person'] ) ? $cl_r_ticket['person'] : '' ) );
													if ( '' === $cl_ev_name ) {
														$cl_ev_name = trim( (string) ( isset( $cl_r['visitor_name'] ) ? $cl_r['visitor_name'] : '' ) );
													}
													if ( '' === $cl_ev_name ) {
														$cl_ev_name = __( 'No name given', 'cloaklink' );
													}
													$cl_ev_city = trim( (string) ( isset( $cl_r['city'] ) ? $cl_r['city'] : '' ) );
													?>
													<figure class="clx-ev">
														<figcaption class="clx-ev__head">
															<span class="clx-ev__k"><?php esc_html_e( 'Captured evidence', 'cloaklink' ); ?></span>
															<span class="clx-ev__n"><?php echo esc_html( $cl_ago ); ?></span>
														</figcaption>
														<div class="clx-ev__grid">
															<div class="clx-ev__media"><?php echo $cl_r_media; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside capture_media_html(). ?></div>
															<dl class="clx-ev__facts">
																<div class="clx-ev__fact clx-ev__fact--who">
																	<dt><?php esc_html_e( 'Name', 'cloaklink' ); ?></dt>
																	<dd><?php echo esc_html( $cl_ev_name ); ?></dd>
																</div>
																<div class="clx-ev__fact">
																	<dt><?php esc_html_e( 'City', 'cloaklink' ); ?></dt>
																	<dd><?php echo esc_html( '' !== $cl_ev_city ? $cl_ev_city : ( '' !== $cl_r_place ? $cl_r_place : __( 'Area not named', 'cloaklink' ) ) ); ?></dd>
																</div>
																<div class="clx-ev__fact">
																	<dt><?php esc_html_e( 'Device', 'cloaklink' ); ?></dt>
																	<dd><?php echo esc_html( '' !== $cl_r_dev ? $cl_r_dev : __( 'Not reported', 'cloaklink' ) ); ?></dd>
																</div>
																<div class="clx-ev__fact clx-ev__fact--ip">
																	<dt><?php esc_html_e( 'IP address', 'cloaklink' ); ?></dt>
																	<dd><?php echo esc_html( '' !== $cl_r_ip ? $cl_r_ip : __( 'Not reported', 'cloaklink' ) ); ?></dd>
																</div>
																<?php if ( '' !== $cl_r_geo ) : ?>
																	<div class="clx-ev__fact clx-ev__fact--geo">
																		<dt><?php esc_html_e( 'Position', 'cloaklink' ); ?></dt>
																		<dd>
																			<?php if ( ! empty( $cl_prefs['map_links'] ) ) : ?>
																				<a class="clx-ev__map" href="<?php echo esc_url( 'https://www.google.com/maps?q=' . rawurlencode( (string) $cl_r['lat'] . ',' . (string) $cl_r['lng'] ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $cl_r_geo ); ?> <span aria-hidden="true">↗</span></a>
																			<?php else : ?>
																				<?php echo esc_html( $cl_r_geo ); ?>
																			<?php endif; ?>
																		</dd>
																	</div>
																<?php endif; ?>
															</dl>
														</div>
													</figure>
												<?php endif; ?>

												<div class="clx-hist__acts">
													<button class="clx-mixrow__x" type="submit" form="clx-oneform" name="cl_visit" value="<?php echo esc_attr( (string) $cl_r['id'] ); ?>"
														title="<?php esc_attr_e( 'Clear this record', 'cloaklink' ); ?>" aria-label="<?php esc_attr_e( 'Clear this record', 'cloaklink' ); ?>">✕</button>
												</div>
											</div>
										</li>
									<?php endforeach; ?>
								</ol>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</form>

			<?php
			// The single ✕ on a record. A form of its own, outside the selection
			// form, reached by the `form` attribute from every ✕ above.
			?>
			<form class="clx-oneform" id="clx-oneform" method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>"
				data-cl-confirm="<?php echo esc_attr( __( 'Clear this record from monitoring? The time it happened is kept; its detail is removed.', 'cloaklink' ) ); ?>">
				<input type="hidden" name="cl_agent_action" value="clear_record">
				<input type="hidden" name="cl_back" value="<?php echo esc_attr( (string) ( $cl_view ? (int) $cl_view['id'] : 0 ) ); ?>">
				<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>
			</form>
		</section>
	<?php endif; ?>


	</main>

	<?php
	// The lock. It covers the page after a stretch with no activity and opens only
	// on the access code (or, on an account with no code set, the password), so a
	// desk left signed in in an office is not readable by whoever walks past it.
	?>
	<div class="clx-lock" id="cl-agent-lock" hidden>
		<div class="clx-lock__card" role="dialog" aria-modal="true" aria-labelledby="clx-lock-t">

			<p class="clx-lock__eyebrow">
				<span class="clx-lock__pulse" aria-hidden="true"></span>
				<?php esc_html_e( 'Locked', 'cloaklink' ); ?>
			</p>

			<span class="clx-lock__av" aria-hidden="true"><?php echo esc_html( $cl_lock['init'] ); ?></span>

			<h2 class="clx-lock__who" id="clx-lock-t"><?php echo esc_html( $cl_lock['name'] ); ?></h2>
			<p class="clx-lock__s">
				<?php esc_html_e( 'Access code', 'cloaklink' ); ?>
			</p>

			<?php if ( empty( $cl_lock['has'] ) ) : ?>
				<p class="clx-lock__none">
					<?php esc_html_e( 'No access code is set on this account, so this desk cannot be unlocked here. Ask the operator to set one.', 'cloaklink' ); ?>
				</p>
			<?php else : ?>
				<?php
				// Six cells drawn behind one real field.
				//
				// The field is the thing the browser, the keyboard and a password
				// manager all understand; the cells are what make a six-digit code
				// legible at a glance and let someone see how much they have
				// typed without counting asterisks. A paste of the whole code
				// fills all six at once because it arrives as one input event.
				?>
				<form class="clx-lock__form" id="cl-agent-lock-form" novalidate>
					<div class="clx-lock__cells" id="clx-lock-cells" aria-hidden="true">
						<?php for ( $cl_i = 0; $cl_i < 6; $cl_i++ ) : ?>
							<span class="clx-lock__cell" data-cell="<?php echo (int) $cl_i; ?>"></span>
						<?php endfor; ?>
					</div>
					<input
						class="clx-lock__input"
						id="cl-agent-lock-code"
						type="password"
						inputmode="numeric"
						pattern="[0-9]*"
						maxlength="6"
						autocomplete="off"
						autocapitalize="none"
						spellcheck="false"
						aria-label="<?php esc_attr_e( 'Access code', 'cloaklink' ); ?>"
						aria-describedby="cl-agent-lock-bad"
					>
				</form>
				<p class="clx-lock__bad" id="cl-agent-lock-bad" hidden></p>
				<p class="clx-lock__out">
					<a href="<?php echo esc_url( add_query_arg( 'cl_agent_out', '1', $cl_agents->screen_url( 'panel' ) ) ); ?>"><?php esc_html_e( 'Sign out instead', 'cloaklink' ); ?></a>
				</p>
			<?php endif; ?>
		</div>
	</div>

	<script>
	(function () {
		'use strict';

		/* ---- Copy ---- */
		// A panel whose every action is "send this address" should not make the
		// agent select text by hand, and the selection has to survive the click for
		// the older fallback to work.
		document.querySelectorAll('[data-copy]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var value = btn.getAttribute('data-copy') || '';
				var done = function () {
					var was = btn.textContent;
					btn.textContent = 'Copied';
					btn.classList.add('is-done');
					window.setTimeout(function () {
						btn.textContent = was;
						btn.classList.remove('is-done');
					}, 1400);
				};
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(value).then(done, function () { done(); });
					return;
				}
				var box = document.createElement('textarea');
				box.value = value;
				box.style.position = 'fixed';
				box.style.opacity = '0';
				document.body.appendChild(box);
				box.select();
				try { document.execCommand('copy'); } catch (e) {}
				document.body.removeChild(box);
				done();
			});
		});

		/* ---- The queue's filters ---- */
		// Same three words as the counts above them: all, waiting, released.
		// Drawn from the rows already in the page, so pressing a filter costs
		// nothing and cannot disagree with the numbers on the buttons.
		var queue = document.getElementById('clx-queue');
		if (queue) {
			var rows = Array.prototype.slice.call(queue.querySelectorAll('.clx-trow'));
			var none = document.getElementById('clx-qnone');
			var state = 'all';
			var query = '';

			var applyQueue = function () {
				var shown = 0;
				rows.forEach(function (row) {
					var stateOk = state === 'all' || row.getAttribute('data-state') === state;
					var textOk = !query || (row.getAttribute('data-q') || '').indexOf(query) !== -1;
					var on = stateOk && textOk;
					row.hidden = !on;
					if (on) {
						shown++;
					}
				});
				if (none) {
					none.hidden = shown > 0;
				}
			};

			document.querySelectorAll('[data-qt]').forEach(function (btn) {
				btn.addEventListener('click', function () {
					state = btn.getAttribute('data-qt');
					document.querySelectorAll('[data-qt]').forEach(function (other) {
						var on = other === btn;
						other.classList.toggle('is-on', on);
						other.setAttribute('aria-selected', on ? 'true' : 'false');
					});
					applyQueue();
				});
			});

			var search = document.getElementById('cl-qsearch');
			if (search) {
				search.addEventListener('input', function () {
					query = search.value.trim().toLowerCase();
					applyQueue();
				});
			}
		}

		/* ---- Records open where they stand ---- */
		// The state lives in the element's own `hidden` attribute, so the page is
		// still correct with scripting off: the browser then shows every body
		// permanently rather than nothing at all.
		document.querySelectorAll('.clx-rec__head').forEach(function (head) {
			head.addEventListener('click', function () {
				var card = head.closest('.clx-rec');
				var body = card ? card.querySelector('.clx-rec__body') : null;
				if (!body) {
					return;
				}
				var open = head.getAttribute('aria-expanded') === 'true';
				head.setAttribute('aria-expanded', open ? 'false' : 'true');
				body.hidden = open;
				card.classList.toggle('is-open', !open);

				// Opened for the first time: the blink has done its job on the row,
				// and a record being read should stop pulsing.
				if (!open) {
					card.querySelectorAll('.clx-rec__ico').forEach(function (ico) {
						ico.style.animation = 'none';
					});
				}
			});
		});
	})();
	</script>
	<script>
		window.CLOAKLINK_AGENT = <?php
		echo wp_json_encode(
			array(
				'dark'      => (bool) $cl_adv->pref( (int) $cl_agent['id'], 'dark' ),
				'compact'   => (bool) $cl_adv->pref( (int) $cl_agent['id'], 'compact' ),
				'largeText' => (bool) $cl_adv->pref( (int) $cl_agent['id'], 'large_text' ),
				'refresh'   => (int) $cl_adv->pref( (int) $cl_agent['id'], 'refresh' ),
				'rows'      => (int) $cl_adv->pref( (int) $cl_agent['id'], 'rows' ),
				'phoneApp'  => (string) $cl_adv->pref( (int) $cl_agent['id'], 'phone_app' ),
				'mapLinks'  => (bool) $cl_adv->pref( (int) $cl_agent['id'], 'map_links' ),
			)
		);
		?>;
	</script>
	<?php
	// The sound engine first, and told which instrument this console is.
	//
	// The desk loads its own scripts by hand rather than through the
	// enqueue queue, so the engine is named here too. Without this line the
	// desk would fall back to the office's instrument — two consoles in one
	// room would sound identical, which is exactly what the operator asked
	// to stop.
	?>
	<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/notice.css?ver=' . CLOAKLINK_VERSION ); ?>">
	<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/sound.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
	<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/notice.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
	<script>if (window.CloakSound) { window.CloakSound.setRole('agent'); }</script>
	<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/agent.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
	<?php
	// The tower map needs its own script, and only when there is a map on the
	// page. The sheet was linked here from the start but the script was not,
	// so the desk drew an empty frame with a grid and a sweep and no masts on
	// it — the map looked broken rather than absent.
	if ( '' !== $cl_tower_html ) :
		?>
		<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/admin-tower.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
	<?php endif; ?>
	<?php
	// The walkie-talkie is gone from the desk.
	//
	// It was a floating sheet over the page with its own tone settings, its
	// own poll and its own roster, and what it did in practice was sit on top
	// of the records while an agent was trying to read them. A desk that
	// needs to reach the office has the phone in this app, a ticket, and a
	// ticket's own remark line; a second half-working chat panel beside them
	// was one more thing to check and one more thing that could be ringing.
	// The server side and the old CSS stay where they are so nothing that
	// still references them breaks, but nothing is printed and nothing is
	// loaded on this page any more.
	?>
	</body>
	</html>
