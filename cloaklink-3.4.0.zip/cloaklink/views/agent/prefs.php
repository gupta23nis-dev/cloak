<?php
/**
 * One person's own desk settings.
 *
 * Ten settings, and every one of them changes something this person actually
 * looks at: where they land after signing in, how the rows are sized, whether
 * the desk is dark, and what a press on a number does. They are stored per
 * agent, so a change on one phone never moves anybody else's screen.
 *
 * This is a page of its own rather than a block on the desk. The desk is for
 * reading records, and a form left open under them pushes the work down the
 * screen on a phone — the settings are somewhere to go and come back from.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_agents = isset( $GLOBALS['cl_agents'] ) ? $GLOBALS['cl_agents'] : cloaklink()->agents;
$cl_agent  = isset( $GLOBALS['cl_agent'] ) ? $GLOBALS['cl_agent'] : $cl_agents->current();

if ( ! $cl_agent ) {
	return;
}

$cl_brand = cloaklink()->router->brand();
$cl_name  = isset( $cl_brand['name'] ) && '' !== trim( (string) $cl_brand['name'] ) ? (string) $cl_brand['name'] : 'Credit Control';

$cl_adv    = cloaklink()->adv;
$cl_prefs  = $cl_adv->prefs( (int) $cl_agent['id'] );
$cl_opts   = CloakLink_Adv::agent_options();
$cl_is_adm = $cl_agents->is_admin( $cl_agent );
$cl_ok     = isset( $_GET['cl_ok'] ) ? sanitize_key( wp_unslash( $_GET['cl_ok'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

$cl_init = mb_strtoupper( mb_substr( (string) $cl_agent['name'], 0, 1 ) );
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo $cl_prefs['dark'] ? 'clx-dark' : ''; ?><?php echo $cl_prefs['compact'] ? ' clx-compact' : ''; ?><?php echo $cl_prefs['large_text'] ? ' clx-large' : ''; ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#0a1118">
<title><?php echo esc_html( sprintf( /* translators: %s: site name */ __( 'Your settings — %s', 'cloaklink' ), $cl_name ) ); ?></title>
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/agent.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-intel.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/theme-signal.css?ver=' . CLOAKLINK_VERSION ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/cropper.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body class="cl-agent-panel clx-prefs">

<header class="clx-bar">
	<a class="clx-bar__brand" href="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>">
		<?php echo CloakLink_Admin::logo( '', 30 ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in logo(). ?>
		<span>
			<span class="clx-bar__name"><?php echo esc_html( $cl_name ); ?></span>
			<span class="clx-bar__sub"><?php esc_html_e( 'Your settings', 'cloaklink' ); ?></span>
		</span>
	</a>

	<div class="clx-bar__right">
		<div class="clx-me">
			<span class="clx-me__av" aria-hidden="true"><?php echo esc_html( $cl_init ); ?></span>
			<span class="clx-me__who">
				<b><?php echo esc_html( $cl_agent['name'] ); ?></b>
				<i><?php echo $cl_is_adm ? esc_html__( 'Admin', 'cloaklink' ) : esc_html__( 'Agent', 'cloaklink' ); ?></i>
			</span>
			<a class="clx-out" href="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>"><?php esc_html_e( 'Back to the desk', 'cloaklink' ); ?></a>
		</div>
	</div>
</header>

<main class="clx-page clx-page--prefs">

	<section class="clx-panel">
		<header class="clx-panel__head">
			<h2 class="clx-panel__title"><?php esc_html_e( 'Your desk settings', 'cloaklink' ); ?></h2>
			<span class="clx-panel__meta"><?php esc_html_e( 'Only yours', 'cloaklink' ); ?></span>
		</header>

		<?php if ( 'saved' === $cl_ok ) : ?>
			<p class="clx-msg clx-msg--ok" role="status"><?php esc_html_e( 'Saved. Your desk opens this way from the next page you load.', 'cloaklink' ); ?></p>
		<?php endif; ?>

		<p class="clx-prefs__lede">
			<?php esc_html_e( 'These belong to you, not to the office. Changing one here changes nothing on anybody else’s screen.', 'cloaklink' ); ?>
		</p>

		<?php
		// Your own account: the name the office sees, the picture beside it,
		// the password and the code you sign in with.
		//
		// All four were the operator's to change and only the operator's.
		// That made every one of them a message to somebody else — "please
		// reset my password", "please change my name" — and left a person
		// who could not sign in with no way to say so from inside their own
		// desk. They are self-service now, and every change is written into
		// the desk's activity log so the office still sees what happened.
		//
		// The username is not here and is not changeable by anybody: it is
		// the handle the office uses in the log, and a person rewriting it
		// would rewrite history.
		$cl_avatar = $cl_agents->avatar_url( (int) $cl_agent['id'] );
		?>
		<section class="clx-prefs__me" id="clx-me">
			<header class="clx-prefs__mehead">
				<span class="clx-prefs__meav" aria-hidden="true">
					<?php if ( '' !== $cl_avatar ) : ?>
						<img src="<?php echo esc_url( $cl_avatar ); ?>" alt="">
					<?php else : ?>
						<?php echo esc_html( $cl_init ); ?>
					<?php endif; ?>
				</span>
				<div>
					<h2 class="clx-prefs__met"><?php esc_html_e( 'You', 'cloaklink' ); ?></h2>
					<p class="clx-prefs__mes">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: username */
								__( 'Signed in as %s', 'cloaklink' ),
								(string) $cl_agent['username']
							)
						);
						?>
					</p>
				</div>
			</header>

			<form class="clx-prefs__form" id="clx-meform" method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>" enctype="multipart/form-data" autocomplete="off">
				<input type="hidden" name="cl_agent_action" value="profile">
				<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>

				<div class="clx-prefs__row">
					<div class="clx-prefs__say">
						<label class="clx-prefs__label" for="clx-me-name"><?php esc_html_e( 'Your name', 'cloaklink' ); ?></label>
						<p class="clx-prefs__help"><?php esc_html_e( 'What the office and the other desks see beside your work.', 'cloaklink' ); ?></p>
					</div>
					<div class="clx-prefs__ctl">
						<input class="clx-i" type="text" id="clx-me-name" name="cl_name" maxlength="80" value="<?php echo esc_attr( (string) $cl_agent['name'] ); ?>" placeholder="<?php esc_attr_e( 'Your name', 'cloaklink' ); ?>">
					</div>
				</div>

				<div class="clx-prefs__row">
					<div class="clx-prefs__say">
						<label class="clx-prefs__label" for="clx-me-photo"><?php esc_html_e( 'Your picture', 'cloaklink' ); ?></label>
						<p class="clx-prefs__help"><?php esc_html_e( 'A small square photograph. It appears on the desk, on the radio card and beside your name in the log.', 'cloaklink' ); ?></p>
					</div>
					<div class="clx-prefs__ctl">
						<input class="clx-i clx-i--file" type="file" id="clx-me-photo" name="cl_photo" accept="image/jpeg,image/png,image/webp">
						<?php if ( '' !== $cl_avatar ) : ?>
							<label class="clx-prefs__clear">
								<input type="checkbox" name="cl_photo_clear" value="1">
								<span><?php esc_html_e( 'Remove my picture', 'cloaklink' ); ?></span>
							</label>
						<?php endif; ?>
					</div>
				</div>

				<div class="clx-prefs__row">
					<div class="clx-prefs__say">
						<label class="clx-prefs__label" for="clx-me-pass"><?php esc_html_e( 'New password', 'cloaklink' ); ?></label>
						<p class="clx-prefs__help"><?php esc_html_e( 'Leave it empty to keep the one you have. Eight characters or more.', 'cloaklink' ); ?></p>
					</div>
					<div class="clx-prefs__ctl">
						<input class="clx-i" type="password" id="clx-me-pass" name="cl_pass" minlength="8" autocomplete="new-password" placeholder="<?php esc_attr_e( 'leave empty to keep', 'cloaklink' ); ?>">
						<input class="clx-i" type="password" id="clx-me-pass2" name="cl_pass2" minlength="8" autocomplete="new-password" placeholder="<?php esc_attr_e( 'the same password again', 'cloaklink' ); ?>">
					</div>
				</div>

				<div class="clx-prefs__row">
					<div class="clx-prefs__say">
						<label class="clx-prefs__label" for="clx-me-code"><?php esc_html_e( 'Your access code', 'cloaklink' ); ?></label>
						<p class="clx-prefs__help"><?php esc_html_e( 'The six digits you type after your password. Leave it empty to keep the one you have; clear it on the office screen if the office requires one.', 'cloaklink' ); ?></p>
					</div>
					<div class="clx-prefs__ctl">
						<input class="clx-i clx-i--num" type="text" id="clx-me-code" name="cl_code" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" placeholder="••••••">
					</div>
				</div>

				<div class="clx-prefs__save">
					<button class="clx-btn clx-btn--go" type="submit"><?php esc_html_e( 'Save my account', 'cloaklink' ); ?></button>
				</div>
			</form>
		</section>

		<?php if ( 'me_saved' === $cl_ok ) : ?>
			<p class="clx-msg clx-msg--ok" role="status"><?php esc_html_e( 'Your account is updated.', 'cloaklink' ); ?></p>
		<?php elseif ( 'me_badpass' === $cl_ok ) : ?>
			<p class="clx-msg clx-msg--bad" role="status"><?php esc_html_e( 'Those two passwords are not the same, or the new one is shorter than eight characters. Nothing was changed.', 'cloaklink' ); ?></p>
		<?php elseif ( 'me_badphoto' === $cl_ok ) : ?>
			<p class="clx-msg clx-msg--bad" role="status"><?php esc_html_e( 'That picture could not be used. A JPG, PNG or WebP under 4 MB works.', 'cloaklink' ); ?></p>
		<?php endif; ?>

		<form class="clx-prefs__form" method="post" action="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>" autocomplete="off">
			<input type="hidden" name="cl_agent_action" value="prefs">
			<?php wp_nonce_field( 'cloaklink_agent', '_cl' ); ?>

			<?php foreach ( $cl_opts as $cl_key => $cl_def ) : ?>
				<?php
				$cl_val = isset( $cl_prefs[ $cl_key ] ) ? $cl_prefs[ $cl_key ] : $cl_def['default'];
				$cl_id  = 'clx-pref-' . $cl_key;
				?>
				<div class="clx-prefs__row">
					<div class="clx-prefs__say">
						<label class="clx-prefs__label" for="<?php echo esc_attr( $cl_id ); ?>"><?php echo esc_html( $cl_def['label'] ); ?></label>
						<p class="clx-prefs__help"><?php echo esc_html( $cl_def['help'] ); ?></p>
					</div>
					<div class="clx-prefs__ctl">
						<?php if ( 'bool' === $cl_def['type'] ) : ?>
							<label class="clx-switch">
								<input type="checkbox" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_key ); ?>" value="1" <?php checked( ! empty( $cl_val ) ); ?>>
								<span class="clx-switch__track" aria-hidden="true"><span class="clx-switch__dot"></span></span>
							</label>
						<?php elseif ( 'int' === $cl_def['type'] ) : ?>
							<input class="clx-i clx-i--num" type="number" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_key ); ?>"
								value="<?php echo esc_attr( (string) $cl_val ); ?>"
								min="<?php echo esc_attr( (string) $cl_def['min'] ); ?>" max="<?php echo esc_attr( (string) $cl_def['max'] ); ?>">
						<?php elseif ( 'enum' === $cl_def['type'] ) : ?>
							<select class="clx-i" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_key ); ?>">
								<?php foreach ( $cl_def['choices'] as $cl_ov => $cl_ol ) : ?>
									<option value="<?php echo esc_attr( (string) $cl_ov ); ?>" <?php selected( (string) $cl_val, (string) $cl_ov ); ?>><?php echo esc_html( $cl_ol ); ?></option>
								<?php endforeach; ?>
							</select>
						<?php else : ?>
							<input class="clx-i" type="text" id="<?php echo esc_attr( $cl_id ); ?>" name="<?php echo esc_attr( $cl_key ); ?>" value="<?php echo esc_attr( (string) $cl_val ); ?>" maxlength="120">
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>

			<div class="clx-prefs__save">
				<button class="clx-btn clx-btn--go" type="submit"><?php esc_html_e( 'Save my settings', 'cloaklink' ); ?></button>
				<a class="clx-btn clx-btn--ghost" href="<?php echo esc_url( $cl_agents->screen_url( 'panel' ) ); ?>"><?php esc_html_e( 'Cancel', 'cloaklink' ); ?></a>
			</div>
		</form>
	</section>

</main>

<?php
// The cropper, printed here by hand.
//
// This page is rendered on its own and never goes through the admin enqueue,
// so an enqueued script would simply not be printed. It is loaded after the
// markup it attaches to, and it only does anything when a photo is chosen.
?>
<script src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/cropper.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
<script>
(function () {
	var input = document.getElementById('clx-me-photo');
	if (input && window.CloakCrop) {
		window.CloakCrop.attach(input, { size: 288, maxOut: 720 });
	}
})();
</script>
</body>
</html>
