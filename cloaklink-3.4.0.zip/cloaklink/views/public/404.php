<?php
/**
 * Bare 404 for missing, expired or invalid links.
 *
 * No theme, no menu and no brand block. A page that carries this service's
 * name and a line about "nothing to see here" is still a page from this
 * service: it confirms the domain is running something, and a visitor who
 * mistypes an address learns that much for free. This says only what the
 * request itself already told the visitor — the address is not here.
 *
 * An expired link gets a sentence saying it expired, because that is a fact
 * about a link the visitor was actually given, and leaving them to guess
 * would have them retry a link that will never work again.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_vars = isset( $GLOBALS['cloaklink_view'] ) ? $GLOBALS['cloaklink_view'] : array();
$cl_msg  = isset( $cl_vars['message'] ) ? (string) $cl_vars['message'] : '';

$cl_messages = array(
	'expired' => __( 'This link has expired.', 'cloaklink' ),
	'deleted' => __( 'This link is no longer available.', 'cloaklink' ),
);
$cl_line = '' !== $cl_msg && isset( $cl_messages[ $cl_msg ] ) ? $cl_messages[ $cl_msg ] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow, noarchive">
	<meta name="referrer" content="no-referrer">
	<title>404 Not Found</title>
	<style>
		html,body{height:100%;margin:0;background:#f7f7f8;color:#1b1b1f;
			font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;}
		.wrap{min-height:100%;display:flex;align-items:center;justify-content:center;padding:24px;box-sizing:border-box}
		.card{max-width:420px;text-align:center}
		.code{font-size:64px;line-height:1;letter-spacing:-2px;font-weight:300;color:#9a9aa2;margin:0 0 8px}
		.msg{font-size:15px;margin:0}
		.note{font-size:14px;margin:10px 0 0;color:#5f5f68}
	</style>
</head>
<body>
	<div class="wrap">
		<div class="card">
			<p class="code">404</p>
			<p class="msg">Not Found</p>
			<?php if ( '' !== $cl_line ) : ?>
				<p class="note"><?php echo esc_html( $cl_line ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</body>
</html>
