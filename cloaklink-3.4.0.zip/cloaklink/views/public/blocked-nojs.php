<?php
/**
 * Shown when JavaScript is unavailable but the link needs a location check.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_brand = isset( $GLOBALS['cloaklink_view']['brand'] ) ? $GLOBALS['cloaklink_view']['brand'] : array();
$cl_name  = isset( $cl_brand['name'] ) ? $cl_brand['name'] : 'CloakLink';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<title><?php echo esc_html( $cl_name ); ?></title>
	<?php
	// This service's own mark in the tab. Without it the browser asks the
	// install for /favicon.ico and shows the WordPress logo.
	$cl_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
		. '<rect width="64" height="64" rx="14" fill="#10232e"/>'
		. '<circle cx="32" cy="32" r="17" fill="none" stroke="#c9a86a" stroke-width="2.6" stroke-opacity=".85"/>'
		. '<path d="M40 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round"/>'
		. '<path d="M30 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round" stroke-opacity=".55"/>'
		. '</svg>';
	?>
	<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,<?php echo esc_attr( base64_encode( $cl_icon_svg ) ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/gate.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body class="cl-gate">
<main class="cl-shell">
	<header class="cl-brand">
		<div class="cl-brand__mark" aria-hidden="true">◆</div>
		<div class="cl-brand__text">
			<h1 class="cl-brand__name"><?php echo esc_html( $cl_name ); ?></h1>
			<p class="cl-brand__tag"><?php esc_html_e( 'Independent Legal Information & Resolution Platform', 'cloaklink' ); ?></p>
		</div>
	</header>
	<section class="cl-card">
		<div class="cl-error">
			<h2 class="cl-error__title"><?php esc_html_e( 'JavaScript is required', 'cloaklink' ); ?></h2>
			<p class="cl-error__body"><?php esc_html_e( 'This link could not open. Enable JavaScript, or open the link in a standard mobile browser such as Chrome or Safari.', 'cloaklink' ); ?></p>
			<p class="cl-error__hint"><?php esc_html_e( 'If you are the sender, create a link with location checking turned off for this recipient.', 'cloaklink' ); ?></p>
		</div>
	</section>
</main>
</body>
</html>
