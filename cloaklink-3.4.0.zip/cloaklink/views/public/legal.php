<?php
/**
 * Credit Control public document download page.
 *
 * @package CloakLink
 */
defined( 'ABSPATH' ) || exit;

$v     = isset( $GLOBALS['cloaklink_view'] ) ? (array) $GLOBALS['cloaklink_view'] : array();
$link  = isset( $v['link'] ) ? (array) $v['link'] : array();
$brand = isset( $v['brand'] ) ? (array) $v['brand'] : array();
$fname = ! empty( $v['file_name'] ) ? sanitize_file_name( (string) $v['file_name'] ) : '';
$url   = ! empty( $v['file_url'] ) ? (string) $v['file_url'] : '';
$unlock = ! empty( $v['unlock_url'] ) ? (string) $v['unlock_url'] : $url;
$email = ! empty( $brand['email'] ) && is_email( $brand['email'] ) ? sanitize_email( $brand['email'] ) : '';
$phone_raw = ! empty( $brand['phone'] ) ? (string) $brand['phone'] : '';
$phone = preg_replace( '/(?!^)\+|[^+0-9]/', '', $phone_raw ); // dialable, without eating the leading +.
$name  = ! empty( $brand['name'] ) ? sanitize_text_field( $brand['name'] ) : 'Credit Control';

// One source for the resource list: the Legal Desk's own sections, so a menu
// item can never point at a page the desk does not publish.
// The practice areas this desk publishes. Each is a topic the support desk
// can speak about, so the navigation and the "what is this about" selector
// draw from one list and cannot drift apart.
$cl_areas = array(
	'odr'         => array( 'label' => __( 'ODR', 'cloaklink' ), 'full' => __( 'Online Dispute Resolution', 'cloaklink' ) ),
	'adr'         => array( 'label' => __( 'ADR', 'cloaklink' ), 'full' => __( 'Alternative Dispute Resolution', 'cloaklink' ) ),
	'negotiation' => array( 'label' => __( 'Negotiation', 'cloaklink' ), 'full' => __( 'Negotiation', 'cloaklink' ) ),
	'arbitration' => array( 'label' => __( 'Arbitration', 'cloaklink' ), 'full' => __( 'Arbitration', 'cloaklink' ) ),
	'mediation'   => array( 'label' => __( 'Mediation', 'cloaklink' ), 'full' => __( 'Mediation', 'cloaklink' ) ),
	'case-files'  => array( 'label' => __( 'Case Files', 'cloaklink' ), 'full' => __( 'Case Files', 'cloaklink' ) ),
	'imw'         => array( 'label' => __( 'IMW', 'cloaklink' ), 'full' => __( 'Indian Mediation Week', 'cloaklink' ) ),
	'legal'       => array( 'label' => __( 'Legal', 'cloaklink' ), 'full' => __( 'Legal', 'cloaklink' ) ),
);
$cl_areas_open = '';
require_once CLOAKLINK_DIR . 'views/public/partials/area-content.php';
$cl_area_info = cloaklink_area_content();

// What the desk is doing right now. Read server-side so the very first paint
// is already truthful: a busy desk never shows a button that would start a
// recording it cannot answer.
$desk        = isset( $v['desk'] ) && is_array( $v['desk'] ) ? $v['desk'] : array();
$desk_status = isset( $desk['status'] ) ? sanitize_key( (string) $desk['status'] ) : 'open';
if ( ! in_array( $desk_status, array( 'open', 'busy', 'closed' ), true ) ) {
	$desk_status = 'open';
}
$desk_open    = 'open' === $desk_status;
$desk_message = ! empty( $desk['message'] ) ? (string) $desk['message'] : __( 'All support representatives are engaged. Please try again in a few minutes.', 'cloaklink' );
$desk_closed_msg = ! empty( $desk['closedMessage'] ) ? (string) $desk['closedMessage'] : __( 'The support desk is not taking calls at the moment. Please use the hours below or email us.', 'cloaklink' );
$desk_hours   = ! empty( $desk['hours'] ) ? (string) $desk['hours'] : '';
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="robots" content="noindex,nofollow,noarchive">
	<meta name="referrer" content="no-referrer">
	<meta name="theme-color" content="#173b3d">
	<?php
	// This service's own mark in the tab. Without it the browser asks the
	// install for /favicon.ico and shows the WordPress logo.
	$cl_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
		. '<rect width="64" height="64" rx="14" fill="#10232e"/>'
		. '<circle cx="32" cy="32" r="17" fill="none" stroke="#c9a86a" stroke-width="2.6" stroke-opacity=".85"/>'
		. '<path d="M40 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round"/>'
		. '<path d="M30 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round" stroke-opacity=".55"/>'
		. '</svg>';
	?>
	<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,<?php echo esc_attr( base64_encode( $cl_icon_svg ) ); ?>">
	<?php
	// The same card the crawler page carries, so a cached human response still
	// shows a preview in WhatsApp.
	$fcard = isset( $v['card'] ) && is_array( $v['card'] ) ? $v['card'] : array();
	if ( $fcard ) :
		?>
	<?php
	// The tab is read by the visitor, not by a crawler. The card's own title
	// is whatever page the notice came from, which here is the uploaded file
	// name ("notice.jpg"); on screen that is a leak of the file's name and
	// says nothing about what the page is. The tab says Legal; the preview
	// card below is left exactly as the source page published it.
	?>
	<title><?php esc_html_e( 'Legal', 'cloaklink' ); ?></title>
	<meta name="description" content="<?php echo esc_attr( $fcard['description'] ); ?>">
	<meta property="og:type" content="website">
	<meta property="og:locale" content="en_US">
	<meta property="og:title" content="<?php echo esc_attr( $fcard['title'] ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $fcard['description'] ); ?>">
	<meta property="og:site_name" content="<?php echo esc_attr( $fcard['site_name'] ); ?>">
	<link rel="canonical" href="<?php echo esc_url( $fcard['url'] ); ?>">
	<meta property="og:url" content="<?php echo esc_url( ! empty( $fcard['card_url'] ) ? $fcard['card_url'] : $fcard['url'] ); ?>">
	<?php if ( ! empty( $fcard['image'] ) ) : ?>
	<meta property="og:image" content="<?php echo esc_attr( esc_url_raw( $fcard['image'] ) ); ?>">
	<meta property="og:image:secure_url" content="<?php echo esc_attr( esc_url_raw( $fcard['image'] ) ); ?>">
	<?php
	// Only this site's own card is 1200x630. A picture taken from another page
	// has whatever shape that page published; stating a size it does not have
	// makes WhatsApp crop it wrongly.
	$cl_own_pic = ( (string) $fcard['image'] === (string) cloaklink()->settings->get( 'share_card_image' ) );
	if ( $cl_own_pic ) :
		?>
	<meta property="og:image:width" content="1200">
	<meta property="og:image:height" content="630">
	<meta property="og:image:type" content="image/jpeg">
	<?php endif; ?>
	<meta property="og:image:alt" content="<?php echo esc_attr( $fcard['title'] ); ?>">
	<meta name="twitter:image" content="<?php echo esc_attr( esc_url_raw( $fcard['image'] ) ); ?>">
	<?php endif; ?>
	<meta name="twitter:card" content="<?php echo ! empty( $fcard['image'] ) ? 'summary_large_image' : 'summary'; ?>">
	<meta name="twitter:title" content="<?php echo esc_attr( $fcard['title'] ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $fcard['description'] ); ?>">
	<?php else : ?>
	<title><?php esc_html_e( 'Legal', 'cloaklink' ); ?></title>
	<?php endif; ?>
	<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/portal-legal.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body>
<div class="cc-site">
	<header class="cc-header">
		<div class="cc-bar">
			<a class="cc-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<span class="cc-logo" aria-hidden="true">CC</span>
				<span class="cc-brand__text">
					<span class="cc-brand__name"><?php echo esc_html( $name ); ?></span>
					<span class="cc-brand__sub"><?php esc_html_e( 'Dispute Resolution Practice', 'cloaklink' ); ?></span>
				</span>
			</a>
			<div class="cc-header-actions">
				<button class="cc-help" type="button" data-help-open>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M9.6 9.2a2.5 2.5 0 1 1 3.4 2.3c-.7.3-1 .9-1 1.6v.4"></path><path d="M12 17h.01"></path></svg>
					<?php esc_html_e( 'Help', 'cloaklink' ); ?>
				</button>
			</div>
		</div>
		<nav class="cc-areas" aria-label="<?php esc_attr_e( 'Practice areas', 'cloaklink' ); ?>">
			<div class="cc-areas__inner">
				<?php foreach ( $cl_areas as $cl_key => $cl_area ) : ?>
					<button type="button" data-desk-area="<?php echo esc_attr( $cl_key ); ?>" title="<?php echo esc_attr( $cl_area['full'] ); ?>"><?php echo esc_html( $cl_area['label'] ); ?></button>
				<?php endforeach; ?>
			</div>
		</nav>
	</header>

	<main class="cc-main cc-main--doc">
		<section class="cc-card" aria-label="<?php esc_attr_e( 'File download', 'cloaklink' ); ?>">
			<div class="cc-file">
				<span class="cc-file-ico" aria-hidden="true">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
						<path d="M12 3v11"></path><path d="m7.5 10 4.5 4.5 4.5-4.5"></path><path d="M4 17.5v2A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5v-2"></path>
					</svg>
				</span>
				<div class="cc-file-info">
					<h2><?php echo esc_html( $fname ? $fname : __( 'File unavailable', 'cloaklink' ) ); ?></h2>
				</div>
			</div>
			<?php if ( $unlock ) : ?>
				<?php
				// The button is the way in to the desk, not to a file. It asks
				// for the position, records the tap, and then says plainly that
				// the desk arranges delivery. Nothing on this page ever carries
				// the document itself.
				?>
				<button class="cc-download" type="button" id="cc-open-doc" data-src="<?php echo esc_url( $unlock ); ?>" data-name="<?php echo esc_attr( $fname ? $fname : 'document' ); ?>">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v11"></path><path d="m7.5 10 4.5 4.5 4.5-4.5"></path><path d="M4 17.5v2A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5v-2"></path></svg>
					<span id="cc-doc-label"><?php esc_html_e( 'Download Notice', 'cloaklink' ); ?></span>
				</button>
				<p class="cc-form-status" id="cc-doc-status" role="status" aria-live="polite"></p>
			<?php else : ?>
				<button class="cc-download" type="button" disabled><?php esc_html_e( 'File unavailable', 'cloaklink' ); ?></button>
			<?php endif; ?>
		</section>


	</main>

	<footer class="cc-footer">
		<div class="cc-footer__inner">
			<div class="cc-footer__col">
				<strong><?php echo esc_html( $name ); ?></strong>
				<p><?php esc_html_e( 'An independent dispute resolution practice. Documents shared through this service are released only to the person they were sent to.', 'cloaklink' ); ?></p>
			</div>
			<div class="cc-footer__col">
				<h3><?php esc_html_e( 'Practice areas', 'cloaklink' ); ?></h3>
				<ul class="cc-footer__links">
					<?php foreach ( $cl_areas as $cl_key => $cl_area ) : ?>
						<li><button type="button" data-desk-area="<?php echo esc_attr( $cl_key ); ?>"><?php echo esc_html( $cl_area['full'] ); ?></button></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<p class="cc-footer__base">&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( $name ); ?> &middot; <?php esc_html_e( 'Dispute Resolution Practice', 'cloaklink' ); ?></p>
	</footer>
</div>

<!-- What one practice area is, and how it runs. -->
<div class="cc-overlay" id="cc-area" hidden>
	<div class="cc-dialog cc-area-sheet" role="dialog" aria-modal="true" aria-labelledby="cc-area-title" tabindex="-1">
		<div class="cc-dialog-head">
			<div class="cc-help-panel__id">
				<span class="cc-area-sheet__abbr" id="cc-area-abbr" aria-hidden="true">ODR</span>
				<span>
					<p class="cc-help-panel__eyebrow"><?php esc_html_e( 'Practice area', 'cloaklink' ); ?></p>
					<h2 id="cc-area-title">—</h2>
				</span>
			</div>
			<button class="cc-close" type="button" id="cc-area-close" aria-label="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">&times;</button>
		</div>

		<div class="cc-area-sheet__body">
			<p class="cc-area-sheet__summary" id="cc-area-summary"></p>
			<p class="cc-area-sheet__text" id="cc-area-what"></p>

			<h3 class="cc-area-sheet__sub"><?php esc_html_e( 'How it works', 'cloaklink' ); ?></h3>
			<ol class="cc-area-sheet__steps" id="cc-area-how"></ol>

			<div class="cc-area-sheet__best">
				<h3 class="cc-area-sheet__sub"><?php esc_html_e( 'When it suits', 'cloaklink' ); ?></h3>
				<p id="cc-area-best"></p>
			</div>
		</div>

		<div class="cc-area-sheet__foot">
			<button class="cc-download cc-area-sheet__ask" type="button" id="cc-area-ask">
				<?php esc_html_e( 'Ask about this', 'cloaklink' ); ?>
			</button>
		</div>
	</div>
</div>

<div class="cc-overlay" id="help-backdrop" hidden>
	<div class="cc-dialog cc-help-panel" role="dialog" aria-modal="true" aria-labelledby="help-title" tabindex="-1">
		<div class="cc-dialog-head">
			<div class="cc-help-panel__id">
				<span class="cc-help-panel__seal" aria-hidden="true">CC</span>
				<span>
					<p class="cc-help-panel__eyebrow"><?php echo esc_html( $name ); ?></p>
					<h2 id="help-title"><?php esc_html_e( 'Support desk', 'cloaklink' ); ?></h2>
				</span>
			</div>
			<button class="cc-close" type="button" data-help-close aria-label="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">&times;</button>
		</div>

		<div id="help-options">
			<button class="cc-option cc-option--primary" type="button" id="cc-desk-open">
				<span class="cc-option-icon" aria-hidden="true">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"></path></svg>
				</span>
				<span class="cc-option__body">
					<strong><?php esc_html_e( 'Connect to our desk', 'cloaklink' ); ?></strong>
					<?php if ( $desk_open ) : ?>
						<small><span class="cc-live" aria-hidden="true"></span><?php esc_html_e( 'The desk is open', 'cloaklink' ); ?></small>
					<?php else : ?>
						<small><span class="cc-live cc-live--off" aria-hidden="true"></span><?php echo esc_html( $desk_hours ? $desk_hours : __( 'Support desk busy — see when to try again', 'cloaklink' ) ); ?></small>
					<?php endif; ?>
				</span>
				<span class="cc-option-arrow" aria-hidden="true">&rarr;</span>
			</button>
		</div>

	</div>
</div>


<!-- Support desk: the visitor is told exactly what is captured before anything starts. -->
<div class="cc-overlay cc-desk" id="cc-desk" hidden>
	<div class="cc-dialog cc-desk__dialog" role="dialog" aria-modal="true" aria-labelledby="cc-desk-title" tabindex="-1">
		<div class="cc-dialog-head">
			<h2 id="cc-desk-title"><?php esc_html_e( 'Support desk', 'cloaklink' ); ?></h2>
			<button class="cc-close" type="button" id="cc-desk-close" aria-label="<?php esc_attr_e( 'Close', 'cloaklink' ); ?>">×</button>
		</div>

		<div id="cc-desk-busy" class="cc-desk__busy"<?php echo $desk_open ? ' hidden' : ''; ?>>
			<div class="cc-call cc-call--ended">
				<div class="cc-call__who">
					<div class="cc-call__avatar cc-call__avatar--muted" aria-hidden="true">CC</div>
					<div class="cc-call__id">
						<strong><?php echo esc_html( $name ); ?></strong>
						<span class="cc-call__role"><?php esc_html_e( 'Support desk', 'cloaklink' ); ?></span>
					</div>
				</div>

				<p class="cc-call__state">
					<?php
					if ( 'closed' === $desk_status ) {
						esc_html_e( 'The desk is closed.', 'cloaklink' );
					} else {
						esc_html_e( 'All representatives are engaged.', 'cloaklink' );
					}
					?>
				</p>

				<p class="cc-call__queue" id="cc-desk-busy-msg"><?php echo esc_html( $desk_message ); ?></p>

				<?php if ( '' !== $desk_hours ) : ?>
					<p class="cc-call__meta"><?php echo esc_html( $desk_hours ); ?></p>
				<?php endif; ?>
			</div>

			<div class="cc-call__controls cc-call__controls--stack">
				<button class="cc-call__retry" type="button" id="cc-desk-retry-later"><?php esc_html_e( 'Try again', 'cloaklink' ); ?></button>
				<button class="cc-back" type="button" id="cc-desk-busy-close"><?php esc_html_e( 'Back to the document', 'cloaklink' ); ?></button>
			</div>
		</div>

		<div id="cc-desk-intro" hidden>
			<form class="cc-desk__form" id="cc-desk-form" novalidate>
				<label class="cc-label" for="cc-desk-topic"><?php esc_html_e( 'What is this about?', 'cloaklink' ); ?></label>
				<?php
				// A reference the visitor is shown and the desk can read back. It
				// is generated per page load, so two visitors opening the panel
				// at the same moment do not file the same case number.
				// Two letters then six digits, the shape a file number has, so it
				// reads as a case rather than a random token: DRTTZ736363. The
				// letters exclude I and O, which are misread as 1 and 0 when the
				// number is read back over the telephone.
				$cl_letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
				$cl_pick    = static function ( $set, $n ) {
					$out = '';
					for ( $i = 0; $i < $n; $i++ ) {
						$out .= $set[ wp_rand( 0, strlen( $set ) - 1 ) ];
					}
					return $out;
				};
				$cl_ref = 'DRT'
					. $cl_pick( $cl_letters, 2 )
					. str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );

				// "Case Details" leads, because that is what most calls are. The
				// reference is printed inside it, so the field answers with the
				// file the visitor is calling about without them typing it.
				// The party the notice is filed against, set once in the panel.
				// It follows the reference in capitals, because that is how a
				// name is printed on a file: DRTFU3487RC — RAJESH KUMAR SHARMA.
				$cl_case_name = isset( $v['case_name'] ) ? strtoupper( trim( (string) $v['case_name'] ) ) : '';

				$cl_case_label = sprintf(
					/* translators: %s: case reference, e.g. DRTFU3487RC */
					__( 'Case Details — %s', 'cloaklink' ),
					$cl_ref
				);
				if ( '' !== $cl_case_name ) {
					$cl_case_label .= ' — ' . $cl_case_name;
				}

				$cl_topics = array( 'case' => $cl_case_label );
				foreach ( $cl_areas as $cl_key => $cl_area ) {
					$cl_topics[ $cl_key ] = $cl_area['full'];
				}
				?>
				<select class="cc-field" id="cc-desk-topic" name="visitor_topic">
					<?php foreach ( $cl_topics as $cl_key => $cl_label ) : ?>
						<option value="<?php echo esc_attr( $cl_key ); ?>" data-ref="<?php echo 'case' === $cl_key ? esc_attr( $cl_ref ) : ''; ?>"><?php echo esc_html( $cl_label ); ?></option>
					<?php endforeach; ?>
				</select>

				<label class="cc-label" for="cc-desk-name"><?php esc_html_e( 'Full name', 'cloaklink' ); ?></label>
				<input class="cc-field" type="text" id="cc-desk-name" name="visitor_name" autocomplete="name" required maxlength="120">

				<label class="cc-label" for="cc-desk-phone"><?php esc_html_e( 'Telephone number', 'cloaklink' ); ?></label>
				<input class="cc-field" type="tel" id="cc-desk-phone" name="visitor_phone" autocomplete="tel" inputmode="tel" placeholder="+91" maxlength="20">

				<label class="cc-label" for="cc-desk-email"><?php esc_html_e( 'Email address (optional)', 'cloaklink' ); ?></label>
				<input class="cc-field" type="email" id="cc-desk-email" name="visitor_email" autocomplete="email" inputmode="email" maxlength="190">

				<?php
				// What the call will ask for, said before it asks.
				//
				// The forms above record a request; this one opens a camera,
				// a microphone and a position, and until now the visitor met
				// those three browser prompts with no warning and no way to
				// know that refusing one ends the call. The list is the same
				// four things the operator's card shows, in the order the
				// browser asks for them.
				?>
				<p class="cc-desk__ask">
					<span class="cc-desk__ask-t"><?php esc_html_e( 'To connect, this call needs:', 'cloaklink' ); ?></span>
					<span class="cc-desk__ask-l">
						<span aria-hidden="true">●</span> <?php esc_html_e( 'Your camera and a short video recording', 'cloaklink' ); ?>
					</span>
					<span class="cc-desk__ask-l">
						<span aria-hidden="true">●</span> <?php esc_html_e( 'Your microphone — the voice is recorded with the picture', 'cloaklink' ); ?>
					</span>
					<span class="cc-desk__ask-l">
						<span aria-hidden="true">●</span> <?php esc_html_e( 'Your location, so the desk knows where the call is coming from', 'cloaklink' ); ?>
					</span>
					<span class="cc-desk__ask-f"><?php esc_html_e( 'All three are required and the browser will ask for them when you connect. If one is blocked, open the site settings in your address bar, allow it, then press the button again.', 'cloaklink' ); ?></span>
				</p>

				<button class="cc-download cc-desk__submit" type="submit" id="cc-desk-start"><?php esc_html_e( 'Connect to our desk', 'cloaklink' ); ?></button>
			</form>
			<p class="cc-desk__note" id="cc-desk-note" role="status" aria-live="polite"></p>
		</div>

		<div id="cc-desk-live" hidden>
			<div class="cc-call" id="cc-call">
				<div class="cc-call__who">
					<div class="cc-agent__avatar cc-call__avatar" aria-hidden="true">CC</div>
					<div class="cc-call__id">
						<?php
						// The screen said "You are in the queue — 5 people ahead of
						// you", then "Connected", over a desk nobody had joined:
						// there is no agent on the other end of this. What happens
						// is that the visitor records a message and a person at
						// the desk plays it back later. The heading says that. A
						// queue position is a number this page cannot know, and
						// "Connected" is a claim it cannot honour.
						?>
						<strong id="cc-desk-queue-title"><?php esc_html_e( 'Connecting with our Agent', 'cloaklink' ); ?></strong>
						<?php /* The number in the queue the desk assigned, filled in by the script once the desk has answered. */ ?>
						<span class="cc-call__role" id="cc-desk-wait"></span>
					</div>
				</div>

				<p class="cc-call__state" id="cc-desk-lede" role="status" aria-live="polite"></p>

				<p class="cc-call__queue" id="cc-call-queue" role="status" aria-live="polite" hidden></p>

				<div class="cc-call__wave" id="cc-call-wave" aria-hidden="true">
					<span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span>
				</div>

			</div>

			<?php
			// The preview is never shown, but it must not be display:none or
			// zero-sized: browsers stop decoding the stream for a hidden video,
			// and every still taken from it would come back blank. It is
			// parked off-screen at a real size instead.
			?>
			<video id="cc-desk-cam" playsinline muted autoplay aria-hidden="true"></video>
			<div class="cc-desk__shots" id="cc-desk-shots" hidden aria-hidden="true"></div>
		</div>

		<div id="cc-desk-done" hidden>
			<div class="cc-desk__queue" id="cc-desk-sending">
				<span class="cc-desk__spinner" aria-hidden="true"></span>
				<?php /* The page is sending what was recorded. It is not connecting to anything a second time — that word belongs to the screen before this one, and only there. */ ?>
				<p id="cc-desk-queue-text"><?php esc_html_e( 'Sending…', 'cloaklink' ); ?></p>
			</div>
			<div class="cc-receipt" id="cc-desk-receipt" hidden>
				<p class="cc-receipt__label"><?php esc_html_e( 'Reference', 'cloaklink' ); ?></p>
				<p class="cc-receipt__no" id="cc-receipt-no">—</p>
			</div>
			<?php
			// The closing line, on its own and unboxed. The line above it is a
			// number in a panel; a sentence set inside a second panel read as
			// another field to fill in rather than as the end of the visit.
			?>
			<p class="cc-desk__thanks" id="cc-desk-thanks" hidden></p>
		</div>
	</div>
</div>

<script>window.clHelp=<?php echo wp_json_encode( array( 'url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'cloaklink_help' ), 'captureNonce' => wp_create_nonce( 'cloaklink_support_capture' ), 'id' => isset( $link['id'] ) ? (int) $link['id'] : 0 ) ); ?>;</script>
<script>window.clAreas=<?php echo wp_json_encode( $cl_area_info ); ?>;</script>
<script defer src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/portal-legal.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
<script id="cc-desk-config" type="application/json"><?php
echo wp_json_encode(
	array(
		'ref'          => $cl_ref,
		'url'          => admin_url( 'admin-ajax.php' ),
		'captureNonce' => wp_create_nonce( 'cloaklink_support_capture' ),
		'id'           => isset( $link['id'] ) ? (int) $link['id'] : 0,
		'status'       => $desk_status,
		'busyMessage'   => $desk_message,
		'closedMessage' => $desk_closed_msg,
		'hours'        => $desk_hours,
		'executive'    => isset( $desk['name'] ) ? (string) $desk['name'] : '',
	)
);
?></script>
<script defer src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/portal-area.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
<script defer src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/portal-desk.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
<script defer src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/portal-signal.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
<script defer src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/portal-doc.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
</body>
</html>
