<?php
/**
 * Private sign-in screen for the control panel.
 *
 * Two steps on one card: the account and password, then the access code as
 * six cells. The code is only asked for when the account has one — a panel
 * opened on a password alone must not show an empty step it cannot pass.
 *
 * The code row is six real inputs inside one frame, each with its own corner
 * marks, which light as the digit lands. It submits itself on the sixth
 * character; there is no button to hunt for, and nothing on the page states
 * the length, so the shape of the field is the only hint and that hint
 * belongs to the person who set the code.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_vars      = isset( $GLOBALS['cloaklink_view'] ) ? $GLOBALS['cloaklink_view'] : array();
$cl_brand     = isset( $cl_vars['brand'] ) ? $cl_vars['brand'] : array();
$cl_action    = isset( $cl_vars['action'] ) ? $cl_vars['action'] : wp_login_url();
$cl_redirect  = isset( $cl_vars['redirect'] ) ? $cl_vars['redirect'] : '';
$cl_error     = isset( $cl_vars['error'] ) ? (string) $cl_vars['error'] : '';
$cl_notice    = isset( $cl_vars['notice'] ) ? (string) $cl_vars['notice'] : '';
$cl_need_code = ! empty( $cl_vars['need_code'] );

$cl_name = isset( $cl_brand['name'] ) ? $cl_brand['name'] : 'Credit Control';
$cl_init = strtoupper( mb_substr( trim( $cl_name ), 0, 1 ) );
if ( '' === $cl_init ) {
	$cl_init = 'A';
}

// The account this browser last signed in with, so the code step can name
// the person it is asking for rather than opening on a blank card. Only a
// display name is printed; nothing about the account is otherwise exposed.
$cl_who = '';
if ( is_user_logged_in() ) {
	$cl_who = (string) wp_get_current_user()->display_name;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#f3f6f9">
<title><?php echo esc_html( sprintf( /* translators: %s: site name */ __( 'Sign in — %s', 'cloaklink' ), $cl_name ) ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/login.css?ver=' . CLOAKLINK_VERSION ); ?>">
<?php
// This service's own tab mark: without it the browser shows the WordPress logo.
$cl_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
	. '<rect width="64" height="64" rx="14" fill="#0d2b26"/>'
	. '<circle cx="32" cy="32" r="17" fill="none" stroke="#16e0a1" stroke-width="2.6" stroke-opacity=".85"/>'
	. '<path d="M40 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round"/>'
	. '<path d="M30 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round" stroke-opacity=".55"/>'
	. '</svg>';
?>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,<?php echo esc_attr( base64_encode( $cl_icon_svg ) ); ?>">
</head>
<body class="cl-login">

<main class="cl-card" id="cl-card">

	<div class="cl-brand">
		<span class="cl-squares" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
		<span class="cl-word"><?php echo esc_html( $cl_name ); ?></span>
	</div>

	<h1 class="cl-title"><?php esc_html_e( 'Sign in', 'cloaklink' ); ?></h1>
	<p class="cl-sub"><?php esc_html_e( 'Verify your identity to continue', 'cloaklink' ); ?></p>

	<?php if ( '' !== $cl_notice ) : ?>
		<p class="cl-banner cl-banner--ok" role="status"><?php echo esc_html( $cl_notice ); ?></p>
	<?php endif; ?>
	<?php if ( '' !== $cl_error ) : ?>
		<p class="cl-banner cl-banner--bad" role="alert"><?php echo esc_html( $cl_error ); ?></p>
	<?php endif; ?>

	<form class="cl-form" id="cl-form" method="post" action="<?php echo esc_url( $cl_action ); ?>" autocomplete="on" novalidate>
		<input type="hidden" name="redirect_to" value="<?php echo esc_attr( $cl_redirect ); ?>">
		<input type="hidden" name="testcookie" value="1">

		<!-- Step one: the account -->
		<div class="cl-step is-on" id="cl-step-one">
			<div class="cl-pill">
				<span class="cl-av" aria-hidden="true"><?php echo esc_html( $cl_init ); ?></span>
				<span class="cl-pill__t">
					<b><?php echo '' !== $cl_who ? esc_html( $cl_who ) : esc_html__( 'Your account', 'cloaklink' ); ?></b>
					<span><?php echo esc_html( $cl_name ); ?></span>
				</span>
			</div>

			<label class="cl-label" for="cl-user"><?php esc_html_e( 'Username or email', 'cloaklink' ); ?></label>
			<input class="cl-input" type="text" name="log" id="cl-user" autocomplete="username" autocapitalize="none" spellcheck="false" required>

			<label class="cl-label" for="cl-pass"><?php esc_html_e( 'Password', 'cloaklink' ); ?></label>
			<input class="cl-input" type="password" name="pwd" id="cl-pass" autocomplete="current-password" required>

			<label class="cl-check">
				<input type="checkbox" name="rememberme" value="forever">
				<span><?php esc_html_e( 'Keep me signed in on this device', 'cloaklink' ); ?></span>
			</label>

			<button class="cl-go" type="submit" id="cl-go">
				<?php echo $cl_need_code ? esc_html__( 'Continue', 'cloaklink' ) : esc_html__( 'Sign in', 'cloaklink' ); ?>
			</button>
		</div>

		<!-- Step two: the access code -->
		<?php if ( $cl_need_code ) : ?>
			<div class="cl-step" id="cl-step-two" hidden>

				<?php
				// Who is signing in, stated once and quietly.
				//
				// A second bordered card here repeated the one on step one and
				// made two screens that looked like the same form twice. This is
				// a line, not a card: a mark, the name, and the way back. The
				// way back used to be a button at the very bottom, below the
				// code, where a person who had typed nothing yet could not
				// find it.
				?>
				<div class="cl-scanner">
					<div class="cl-scanner__who">
						<span class="cl-av cl-av--sm" aria-hidden="true"><?php echo esc_html( $cl_init ); ?></span>
						<span class="cl-scanner__id">
							<b><?php echo '' !== $cl_who ? esc_html( $cl_who ) : esc_html__( 'Your account', 'cloaklink' ); ?></b>
							<span><?php echo esc_html( $cl_name ); ?></span>
						</span>
						<button class="cl-scanner__swap" type="button" id="cl-back">
							<?php esc_html_e( 'Change', 'cloaklink' ); ?>
						</button>
					</div>

					<div class="cl-scanner__head">
						<span class="cl-scanner__label"><?php esc_html_e( 'Access code', 'cloaklink' ); ?></span>
						<span class="cl-auto" id="cl-auto"><i aria-hidden="true"></i><?php esc_html_e( 'Auto', 'cloaklink' ); ?></span>
					</div>

					<?php
					// Six real inputs in one frame.
					//
					// Each is a cell with a caret under it rather than four
					// floating brackets: the brackets said "viewfinder" at the
					// size they were drawn and read as scratches at any smaller
					// one, which is how most of this panel is seen. A cell with
					// a line, a digit above it and a tick when it is taken is
					// legible at forty pixels and at four hundred.
					//
					// The six are fixed rather than growing as they are typed:
					// this is the private panel, not the public one, and the
					// person typing was given the code by the operator. A field
					// that changes width under the hand while a code is entered
					// from a message is a field that moves the next digit.
					?>
					<div class="cl-codes" id="cl-codes" role="group" aria-label="<?php esc_attr_e( 'Access code', 'cloaklink' ); ?>">
						<?php for ( $cl_i = 0; $cl_i < 6; $cl_i++ ) : ?>
							<span class="cl-cell" data-i="<?php echo (int) $cl_i; ?>">
								<input
									class="cl-box"
									type="text"
									inputmode="numeric"
									maxlength="1"
									name="cl_access_code[]"
									id="cl-code-<?php echo (int) $cl_i; ?>"
									autocomplete="<?php echo 0 === $cl_i ? 'one-time-code' : 'off'; ?>"
									aria-label="<?php echo esc_attr( sprintf( /* translators: %d: position */ __( 'Access code digit %d', 'cloaklink' ), $cl_i + 1 ) ); ?>"
									<?php echo 0 === $cl_i ? 'aria-describedby="cl-code-help"' : ''; ?>>
								<span class="cl-cell__line" aria-hidden="true"></span>
								<span class="cl-cell__tick" aria-hidden="true">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>
								</span>
							</span>
						<?php endfor; ?>
					</div>

					<p class="cl-helper" id="cl-code-help" role="status" aria-live="polite">
						<span class="cl-spin" aria-hidden="true"></span>
						<span id="cl-code-help-t"><?php esc_html_e( 'The code is checked as you finish it.', 'cloaklink' ); ?></span>
					</p>

					<?php
					// The one thing this screen used to leave unsaid.
					//
					// A code is a second factor, so a person who was never
					// given one is looking at a step with no way through and
					// nothing telling them that is what happened. They then
					// conclude their password is wrong — which is exactly the
					// wrong conclusion, and the one this screen's failure
					// message used to invite.
					//
					// Nothing here names the code. Once signed in, the
					// account page changes it; from outside, only the person
					// who issued it can say what it is.
					?>
					<p class="cl-hint" id="cl-code-why">
						<?php esc_html_e( 'This code is issued by whoever runs this desk, and it is separate from your password. If you were not given one, ask them for it — your password on its own cannot open this page.', 'cloaklink' ); ?>
					</p>
				</div>

				<button class="cl-go" type="submit" id="cl-submit" hidden><?php esc_html_e( 'Sign in', 'cloaklink' ); ?></button>
			</div>
		<?php endif; ?>
	</form>

	<div class="cl-legend">
		<span class="cl-legend__l">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
			<?php esc_html_e( 'Private panel', 'cloaklink' ); ?>
		</span>
		<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Forgot your password?', 'cloaklink' ); ?></a>
	</div>

</main>

<script>
(function () {
	'use strict';

	var form = document.getElementById('cl-form');
	if (!form) {
		return;
	}

	var stepOne = document.getElementById('cl-step-one');
	var stepTwo = document.getElementById('cl-step-two');
	var goBtn   = document.getElementById('cl-go');
	var userEl  = document.getElementById('cl-user');
	var passEl  = document.getElementById('cl-pass');

	/* A short note per keystroke on the code. Generated rather than loaded,
	   so it costs nothing and cannot fail; a browser that has not been
	   clicked yet simply stays silent until it has. */
	var ctx = null;
	function note(hz, len) {
		var Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) {
			return;
		}
		try {
			if (!ctx) {
				ctx = new Ctx();
			}
			if (ctx.state === 'suspended') {
				ctx.resume();
			}
			var at = ctx.currentTime + 0.005;
			var osc = ctx.createOscillator();
			var gain = ctx.createGain();
			osc.type = 'sine';
			osc.frequency.setValueAtTime(hz, at);
			gain.gain.setValueAtTime(0.0001, at);
			gain.gain.exponentialRampToValueAtTime(0.04, at + 0.006);
			gain.gain.exponentialRampToValueAtTime(0.0001, at + (len || 0.07));
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start(at);
			osc.stop(at + (len || 0.07) + 0.02);
		} catch (e) {
			/* A silent screen is still a working screen. */
		}
	}

	/* ---- Step one ---- */
	function toCode() {
		if (!stepTwo) {
			return;
		}
		stepOne.hidden = true;
		stepTwo.hidden = false;
		stepTwo.classList.add('is-on');
		var first = document.getElementById('cl-code-0');
		if (first) {
			first.focus();
		}
	}

	if (stepTwo) {
		// Whether a code is wanted at all is settled on the server, when this
		// page is printed: the step only exists in the markup when some
		// account here could need one. So there is nothing to ask and no
		// request to make — the screen used to ask the server about the name
		// that was typed, and that one question was an anonymous "is this a
		// real account, and does it have a code" oracle.
		//
		// Nothing is stranded by showing the step: check_code() reads the
		// account's own code and falls back to the site-wide one, and an
		// install always has a site-wide code (a blank one is re-seeded on
		// upgrade). So every account on this install does have a code to
		// give.
		function advance() {
			if (passEl && !String(passEl.value || '')) {
				passEl.focus();
				return;
			}
			toCode();
		}

		goBtn.addEventListener('click', function (e) {
			e.preventDefault();
			advance();
		});

		// Enter on the password advances rather than submitting, so the code
		// is not skipped and the form is not posted twice.
		[userEl, passEl].forEach(function (el) {
			if (!el) {
				return;
			}
			el.addEventListener('keydown', function (e) {
				if ('Enter' === e.key) {
					e.preventDefault();
					advance();
				}
			});
		});

		var back = document.getElementById('cl-back');
		if (back) {
			back.addEventListener('click', function () {
				stepTwo.hidden = true;
				stepTwo.classList.remove('is-on');
				stepOne.hidden = false;
				if (passEl) {
					passEl.focus();
				}
			});
		}
	}

	/* ---- Step two ---- */
	var codesEl  = document.getElementById('cl-codes');
	var scanner  = codesEl ? codesEl.closest('.cl-scanner') : null;
	var boxes    = codesEl ? Array.prototype.slice.call(codesEl.querySelectorAll('.cl-box')) : [];
	var cells    = codesEl ? Array.prototype.slice.call(codesEl.querySelectorAll('.cl-cell')) : [];
	var helper   = document.getElementById('cl-code-help');
	var helpTxt  = document.getElementById('cl-code-help-t');
	var submit   = document.getElementById('cl-submit');
	var busy     = false;

	/**
	 * Paint the row from what the inputs hold.
	 *
	 * The panel, not the input, carries the state classes now: a cell's tick
	 * and rule are drawn by its container, and "the code is complete" is a
	 * fact about the row rather than about any one box. Reading it from the
	 * inputs on every change is what keeps a paste, a backspace and a typed
	 * digit all looking the same afterwards.
	 */
	function paint() {
		boxes.forEach(function (box, i) {
			var filled = '' !== box.value;
			box.classList.toggle('is-filled', filled);
			if (cells[i]) {
				cells[i].classList.toggle('is-filled', filled);
			}
		});
		var full = code().length === boxes.length;
		if (scanner) {
			scanner.classList.toggle('is-done', full && !busy);
		}
	}

	function say(text, kind) {
		if (!helper) {
			return;
		}
		helper.className = 'cl-helper' + (kind ? ' is-' + kind : '');
		if (helpTxt) {
			helpTxt.textContent = text || '';
		}
	}

	function code() {
		return boxes.map(function (b) {
			return b.value;
		}).join('');
	}

	function shake() {
		if (!scanner) {
			return;
		}
		scanner.classList.add('is-bad');
		window.setTimeout(function () {
			scanner.classList.remove('is-bad');
		}, 480);
	}

	function send() {
		if (busy || !submit) {
			return;
		}
		busy = true;
		// The cells are made read-only rather than disabled while the form
		// is on its way. A disabled field is not sent with the form at all,
		// so disabling these posted a code of six empty strings and the
		// server refused a code the person had typed correctly.
		boxes.forEach(function (b) {
			b.readOnly = true;
			b.classList.add('is-sending');
		});
		say('Verifying…', 'busy');
		// The form carries the password fields and the hidden test cookie, so
		// this is the ordinary WordPress sign-in: nothing about the code is
		// checked in the browser.
		window.setTimeout(function () {
			submit.click();
		}, 240);
	}

	/** Fill the row from a whole code, as a paste or a password manager gives it. */
	function spread(digits) {
		digits = String(digits || '').replace(/\D/g, '').slice(0, boxes.length);
		if (!digits) {
			return false;
		}
		boxes.forEach(function (b, k) {
			b.value = digits.charAt(k) || '';
		});
		paint();
		var last = Math.min(digits.length, boxes.length) - 1;
		if (boxes[last]) {
			boxes[last].focus();
		}
		return true;
	}

	boxes.forEach(function (box, i) {
		box.addEventListener('input', function () {
			var typed = String(box.value || '');
			var digit = typed.replace(/\D/g, '').slice(-1);

			// A whole code arriving in one cell (a paste the paste handler did
			// not catch, or a code filled in by the browser) is spread rather
			// than truncated to its last digit. Without this, autofill silently
			// kept one digit of six and the panel waited for the rest.
			if (typed.replace(/\D/g, '').length > 1) {
				spread(typed);
				if (code().length === boxes.length) {
					if (scanner) {
						scanner.classList.add('is-ok');
					}
					say('Access granted', 'ok');
					note(1046, 0.14);
					send();
				}
				return;
			}

			box.value = digit;
			paint();
			if (digit) {
				note(660 + i * 40);
				if (i < boxes.length - 1) {
					boxes[i + 1].focus();
				}
			}
			if (code().length === boxes.length) {
				if (scanner) {
					scanner.classList.add('is-ok');
				}
				say('Access granted', 'ok');
				note(1046, 0.14);
				send();
			}
		});

		box.addEventListener('keydown', function (e) {
			if ('Backspace' === e.key && !box.value && i > 0) {
				e.preventDefault();
				boxes[i - 1].value = '';
				boxes[i - 1].focus();
				paint();
				note(520);
			}
			if ('ArrowLeft' === e.key && i > 0) {
				boxes[i - 1].focus();
			}
			if ('ArrowRight' === e.key && i < boxes.length - 1) {
				boxes[i + 1].focus();
			}
			if ('Enter' === e.key) {
				e.preventDefault();
				if (code().length === boxes.length) {
					send();
				}
			}
		});

		box.addEventListener('focus', function () {
			box.select();
		});

		// A code pasted or filled by a password manager arrives in one cell;
		// it is spread across the row here so the screen accepts both ways.
		box.addEventListener('paste', function (e) {
			e.preventDefault();
			var data = (e.clipboardData || window.clipboardData).getData('text') || '';
			if (!spread(data)) {
				return;
			}
			if (code().length === boxes.length) {
				if (scanner) {
					scanner.classList.add('is-ok');
				}
				say('Access granted', 'ok');
				send();
			}
		});
	});

	// The frame is the target, not only the cells: a tap on the padding has
	// to reach the field it belongs to.
	if (codesEl) {
		codesEl.addEventListener('click', function (e) {
			if (e.target && e.target.classList && e.target.classList.contains('cl-box')) {
				return;
			}
			var empty = boxes.filter(function (b) {
				return !b.value;
			})[0] || boxes[boxes.length - 1];
			if (empty) {
				empty.focus();
			}
		});
	}

	// The line under the row says what to do before anything has been typed,
	// so the panel is not a blank strip of boxes with an empty space beneath
	// it. It is replaced the moment the row has something to say.
	if (!helpTxt || !helpTxt.textContent) {
		say('Type the code you were given. It is checked as you finish it.');
	}

	form.addEventListener('submit', function (e) {
		if (stepTwo && !stepTwo.hidden && code().length !== boxes.length) {
			e.preventDefault();
			shake();
			say('Enter the whole code — it checks itself.', 'bad');
		}
	});

	// A code the server refused comes back on a fresh page, so the refusal is
	// announced here rather than left to a small line at the top.
	<?php if ( '' !== $cl_error && $cl_need_code ) : ?>
	if (stepTwo) {
		toCode();
		shake();
		say(<?php echo wp_json_encode( wp_strip_all_tags( $cl_error ) ); ?>, 'bad');
	}
	<?php endif; ?>

	window.addEventListener('load', function () {
		var target = (stepTwo && !stepTwo.hidden && boxes[0]) ? boxes[0] : (userEl || null);
		if (target) {
			window.setTimeout(function () {
				target.focus();
			}, 220);
		}
	});
})();
</script>

</body>
</html>
