<?php
/**
 * What each practice area is, and how it works.
 *
 * Kept in one place so the navigation band, the footer and the panel a
 * visitor opens from them can never describe the same process two ways.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

/**
 * Content for the eight practice areas.
 *
 * @return array
 */
function cloaklink_area_content() {
	return array(
		'odr'         => array(
			'full'    => __( 'Online Dispute Resolution', 'cloaklink' ),
			'summary' => __( 'A negotiation, mediation or arbitration carried out online, from the first notice to the signed record.', 'cloaklink' ),
			'what'    => __(
				'ODR is not a separate kind of process. It is one of the existing ones — negotiation, mediation or arbitration — run through online tools, so that papers, sessions and signatures do not need anyone to travel. A single video call inside an otherwise paper matter is a convenience, not ODR. The label is earned when the case can move without a hearing room.',
				'cloaklink'
			),
			'how'     => array(
				__( 'The claim is filed and the other side is given notice through the platform.', 'cloaklink' ),
				__( 'Papers are exchanged in a shared record, with proof that each party received them.', 'cloaklink' ),
				__( 'Sessions run by video, with a private room for confidential conversations.', 'cloaklink' ),
				__( 'The outcome is signed online and the recording is kept intact.', 'cloaklink' ),
			),
			'best'    => __( 'Small sums, wide distances, and matters where a hearing costs more than the claim.', 'cloaklink' ),
		),
		'adr'         => array(
			'full'    => __( 'Alternative Dispute Resolution', 'cloaklink' ),
			'summary' => __( 'The family of processes that settle a matter without a full trial.', 'cloaklink' ),
			'what'    => __(
				'ADR gathers negotiation, mediation, conciliation and arbitration. They differ in one respect that decides everything else: who decides the outcome. In negotiation and mediation the parties decide, and can only be bound by terms they accepted. In arbitration a tribunal decides, and the award binds them whether they agree with it or not.',
				'cloaklink'
			),
			'how'     => array(
				__( 'The parties choose the process, usually in the contract that created the dispute.', 'cloaklink' ),
				__( 'A neutral is appointed, by agreement or by an institution.', 'cloaklink' ),
				__( 'The matter is heard in private, on a timetable the parties largely control.', 'cloaklink' ),
				__( 'The settlement or award is recorded and, where needed, taken to a court to enforce.', 'cloaklink' ),
			),
			'best'    => __( 'Commercial parties who need speed, privacy, and an outcome shaped around a continuing relationship.', 'cloaklink' ),
		),
		'negotiation' => array(
			'full'    => __( 'Negotiation', 'cloaklink' ),
			'summary' => __( 'Two sides and their advisers reaching terms between themselves.', 'cloaklink' ),
			'what'    => __(
				'Negotiation is the only dispute process that runs whether or not anyone has decided to resolve the dispute. Most matters settle in one. The single most useful preparation is an honest answer to what happens if no deal is reached — that sets the floor or ceiling of everything else.',
				'cloaklink'
			),
			'how'     => array(
				__( 'Ground rules first: who attends, who can agree, and what stays confidential.', 'cloaklink' ),
				__( 'The facts in dispute are established in writing before the numbers are argued.', 'cloaklink' ),
				__( 'Offers are exchanged with the calculation attached, not as bare figures.', 'cloaklink' ),
				__( 'What was agreed is recorded the same day, in language that can be defended later.', 'cloaklink' ),
			),
			'best'    => __( 'Matters where both sides have something the other wants beyond money.', 'cloaklink' ),
		),
		'arbitration' => array(
			'full'    => __( 'Arbitration', 'cloaklink' ),
			'summary' => __( 'A neutral tribunal decides, and the award binds the parties.', 'cloaklink' ),
			'what'    => __(
				'A tribunal’s authority comes from the arbitration agreement and nowhere else. The clause must exist, cover the dispute, and survive whatever has happened to the contract around it. Where it is missing, the award is a nullity however well the hearing was run. Most arbitration litigation is not about the merits — it is about whether the clause did its job.',
				'cloaklink'
			),
			'how'     => array(
				__( 'Notice of arbitration is given and the tribunal is constituted.', 'cloaklink' ),
				__( 'Preliminary issues are settled: jurisdiction, the seat, interim measures, the timetable.', 'cloaklink' ),
				__( 'Statements of claim and defence, document production, and witness statements.', 'cloaklink' ),
				__( 'The hearing is held and a reasoned, signed award is delivered to both sides.', 'cloaklink' ),
			),
			'best'    => __( 'High-value commercial claims where finality matters more than a right of appeal.', 'cloaklink' ),
		),
		'mediation'   => array(
			'full'    => __( 'Mediation', 'cloaklink' ),
			'summary' => __( 'A neutral third party helps the parties build their own settlement.', 'cloaklink' ),
			'what'    => __(
				'The mediator has no power to decide anything, which is why the outcome is one the parties own. The work is to manage a conversation the parties have already failed to have: setting the agenda, hearing each side fully, testing the numbers, and carrying proposals between private sessions.',
				'cloaklink'
			),
			'how'     => array(
				__( 'Intake: the parties, the dispute, and who has authority to settle.', 'cloaklink' ),
				__( 'A joint opening, where each side states its case in front of the other.', 'cloaklink' ),
				__( 'Private sessions, where the real positions usually surface.', 'cloaklink' ),
				__( 'The settlement is written, signed, and enforced where the statute allows.', 'cloaklink' ),
			),
			'best'    => __( 'Disputes where the parties will have to deal with each other again afterwards.', 'cloaklink' ),
		),
		'case-files'  => array(
			'full'    => __( 'Case Files', 'cloaklink' ),
			'summary' => __( 'What a well-kept matter file holds, and why each part matters.', 'cloaklink' ),
			'what'    => __(
				'A matter is won or lost on its file long before it is argued. A file assembled to prove a point is the file that loses: the other side produces the document that was left out, and the exclusion costs more than the document would have. The discipline that serves a party best is the dull one — collect everything, index it, and let counsel decide what to rely on.',
				'cloaklink'
			),
			'how'     => array(
				__( 'Collect the contract, every amendment, and the correspondence that varied it in practice.', 'cloaklink' ),
				__( 'Keep proof of receipt — courier slips, delivery reports, email headers — not just proof of sending.', 'cloaklink' ),
				__( 'Record the dates that decide limitation, because they are counted and not estimated.', 'cloaklink' ),
				__( 'Hold the file where access is granted per matter and withdrawn when it closes.', 'cloaklink' ),
			),
			'best'    => __( 'Anyone assembling a matter for a notice, a mediation or a hearing.', 'cloaklink' ),
		),
		'imw'         => array(
			'full'    => __( 'Indian Mediation Week', 'cloaklink' ),
			'summary' => __( 'A national week of mediation awareness, training and settlement drives.', 'cloaklink' ),
			'what'    => __(
				'Mediation in India does not lack a legal framework; it lacks familiarity. Most parties who could settle have never met a mediator, and many have been told that a settlement is a concession. A dedicated week changes that arithmetic: courts, institutions, law schools and practitioners all run sessions in the same window, and the volume is what carries the message.',
				'cloaklink'
			),
			'how'     => array(
				__( 'Awareness sessions in courts, colleges, industry bodies and resident associations.', 'cloaklink' ),
				__( 'Training and refresher courses for mediators and advocates.', 'cloaklink' ),
				__( 'Settlement drives, where referred matters are listed over consecutive days.', 'cloaklink' ),
				__( 'A settlement drive gives a matter a date — which is usually what was missing.', 'cloaklink' ),
			),
			'best'    => __( 'Parties with a matter already in the system who would rather settle than wait for a listing.', 'cloaklink' ),
		),
		'legal'       => array(
			'full'    => __( 'Legal', 'cloaklink' ),
			'summary' => __( 'The statutes and institutional texts behind the desk.', 'cloaklink' ),
			'what'    => __(
				'Dispute resolution in India runs on a small set of statutes and the rules of the institution administering the file. The Arbitration and Conciliation Act, 1996 governs arbitration and conciliation. The Mediation Act, 2023 gives mediated settlements a statutory footing. The Commercial Courts Act, 2015 requires pre-institution mediation in specified commercial suits, and Section 89 of the Code of Civil Procedure refers parties to ADR.',
				'cloaklink'
			),
			'how'     => array(
				__( 'Read the clause against the statute: what it says, and what the statute adds to it.', 'cloaklink' ),
				__( 'Read the institutional rules, which set the fees, the appointments and the timetable.', 'cloaklink' ),
				__( 'Check limitation before anything else — it is counted from dates, not estimated.', 'cloaklink' ),
				__( 'Statute and rule text should be read at the source, not from a summary.', 'cloaklink' ),
			),
			'best'    => __( 'Orientation before a question is put to a qualified professional with the papers in front of them.', 'cloaklink' ),
		),
	);
}
