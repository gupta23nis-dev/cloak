<?php
/**
 * Inline scene illustrations.
 *
 * Drawn as SVG rather than photographs: nothing to download, nothing to
 * licence, and no person, brand or client is depicted. Each scene is a small
 * editorial vignette that reads at a glance — a consultation across a desk, a
 * document being read, a mediation table.
 *
 * Usage: include this file, then `echo cloaklink_scene( 'desk' );`
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'cloaklink_scene' ) ) {
	/**
	 * Return the markup for one scene.
	 *
	 * @param string $name  Scene key.
	 * @param string $class Extra class names.
	 * @return string
	 */
	function cloaklink_scene( $name, $class = '' ) {
		$scenes = array(
			// A consultation across a desk: two people, a document, a window.
			'desk'   => '
				<svg class="cl-scene" viewBox="0 0 400 260" role="img" aria-label="" preserveAspectRatio="xMidYMid slice">
					<defs>
						<linearGradient id="clsc-wall" x1="0" y1="0" x2="0" y2="1">
							<stop offset="0%" stop-color="#efd9c4"/><stop offset="100%" stop-color="#dcbb9f"/>
						</linearGradient>
						<linearGradient id="clsc-win" x1="0" y1="0" x2="0" y2="1">
							<stop offset="0%" stop-color="#f6efe3"/><stop offset="100%" stop-color="#e3d4bd"/>
						</linearGradient>
					</defs>
					<rect width="400" height="260" fill="url(#clsc-wall)"/>
					<rect x="26" y="20" width="132" height="108" rx="2" fill="url(#clsc-win)" opacity="0.85"/>
					<path d="M92 20v108M26 74h132" stroke="#c9a98c" stroke-width="2"/>
					<rect x="150" y="120" width="230" height="14" fill="#b8916f" opacity="0.55"/>
					<rect x="176" y="134" width="14" height="86" fill="#a87f5e" opacity="0.5"/>
					<rect x="348" y="134" width="14" height="86" fill="#a87f5e" opacity="0.5"/>
					<path d="M60 196c0-24 14-40 34-40s34 16 34 40z" fill="#5c4433"/>
					<circle cx="94" cy="140" r="17" fill="#8d6448"/>
					<path d="M232 196c0-26 15-44 37-44s37 18 37 44z" fill="#37424f"/>
					<circle cx="269" cy="134" r="18" fill="#a6795a"/>
					<rect x="140" y="182" width="86" height="10" rx="2" fill="#f4ede1" transform="rotate(-5 140 182)"/>
					<path d="M150 186h58" stroke="#c3b49f" stroke-width="2"/>
					<path d="M300 186h58" stroke="#c3b49f" stroke-width="2"/>
				</svg>',

			// A hand holding a notice, close up.
			'notice' => '
				<svg class="cl-scene" viewBox="0 0 400 260" role="img" aria-label="" preserveAspectRatio="xMidYMid slice">
					<defs>
						<linearGradient id="clsc-desk" x1="0" y1="0" x2="1" y2="1">
							<stop offset="0%" stop-color="#c99b73"/><stop offset="100%" stop-color="#9d6f4d"/>
						</linearGradient>
					</defs>
					<rect width="400" height="260" fill="url(#clsc-desk)"/>
					<rect x="86" y="30" width="228" height="200" rx="3" fill="#f7f2e8" transform="rotate(-3 200 130)"/>
					<g transform="rotate(-3 200 130)">
						<rect x="112" y="58" width="120" height="9" rx="2" fill="#26303f" opacity="0.75"/>
						<rect x="112" y="80" width="176" height="5" rx="2" fill="#b9b0a0"/>
						<rect x="112" y="94" width="176" height="5" rx="2" fill="#b9b0a0"/>
						<rect x="112" y="108" width="146" height="5" rx="2" fill="#b9b0a0"/>
						<rect x="112" y="122" width="168" height="5" rx="2" fill="#b9b0a0"/>
						<rect x="112" y="146" width="88" height="34" rx="2" fill="#a4343a" opacity="0.14"/>
						<circle cx="272" cy="192" r="21" fill="none" stroke="#a4343a" stroke-width="3" opacity="0.5"/>
					</g>
					<path d="M40 232c22-14 44-18 66-11l40 13H40z" fill="#7a5a41" opacity="0.55"/>
				</svg>',

			// Two sides meeting at a mediation table.
			'meeting' => '
				<svg class="cl-scene" viewBox="0 0 400 260" role="img" aria-label="" preserveAspectRatio="xMidYMid slice">
					<defs>
						<linearGradient id="clsc-room" x1="0" y1="0" x2="0" y2="1">
							<stop offset="0%" stop-color="#ddcbb6"/><stop offset="100%" stop-color="#bda286"/>
						</linearGradient>
					</defs>
					<rect width="400" height="260" fill="url(#clsc-room)"/>
					<ellipse cx="200" cy="214" rx="176" ry="34" fill="#8c6b50" opacity="0.5"/>
					<path d="M52 200c0-26 16-44 38-44s38 18 38 44z" fill="#435064"/>
					<circle cx="90" cy="132" r="19" fill="#95684c"/>
					<path d="M272 200c0-26 16-44 38-44s38 18 38 44z" fill="#4d4436"/>
					<circle cx="310" cy="132" r="19" fill="#a87a5b"/>
					<rect x="150" y="160" width="100" height="52" rx="4" fill="#f2e9db"/>
					<rect x="164" y="174" width="58" height="6" rx="2" fill="#b3a795"/>
					<rect x="164" y="188" width="72" height="6" rx="2" fill="#b3a795"/>
					<circle cx="200" cy="130" r="15" fill="#c9a35a" opacity="0.85"/>
					<path d="M200 118v24M188 130h24" stroke="#f2e9db" stroke-width="2"/>
				</svg>',

			// A lawyer at a desk with case files.
			'lawyer' => '
				<svg class="cl-scene" viewBox="0 0 400 260" role="img" aria-label="" preserveAspectRatio="xMidYMid slice">
					<defs>
						<linearGradient id="clsc-off" x1="0" y1="0" x2="1" y2="1">
							<stop offset="0%" stop-color="#ded0bd"/><stop offset="100%" stop-color="#bda88e"/>
						</linearGradient>
					</defs>
					<rect width="400" height="260" fill="url(#clsc-off)"/>
					<rect x="24" y="26" width="104" height="86" rx="2" fill="#f4ece0" opacity="0.75"/>
					<path d="M76 26v86M24 69h104" stroke="#c6ad92" stroke-width="2"/>
					<rect x="236" y="18" width="140" height="10" rx="3" fill="#8e6f52" opacity="0.55"/>
					<rect x="236" y="34" width="118" height="10" rx="3" fill="#8e6f52" opacity="0.35"/>
					<rect x="236" y="50" width="132" height="10" rx="3" fill="#8e6f52" opacity="0.28"/>
					<path d="M126 214c0-30 18-50 42-50s42 20 42 50z" fill="#3c4657"/>
					<circle cx="168" cy="146" r="21" fill="#a17556"/>
					<path d="M152 152c4-14 26-14 32 0" stroke="#8d6349" stroke-width="3" fill="none"/>
					<rect x="96" y="196" width="150" height="12" fill="#a07f5f" opacity="0.6"/>
					<rect x="112" y="208" width="118" height="42" rx="3" fill="#f6efe3"/>
					<rect x="126" y="220" width="86" height="5" rx="2" fill="#bdb1a0"/>
					<rect x="126" y="232" width="64" height="5" rx="2" fill="#bdb1a0"/>
				</svg>',

			// A phone in hand showing a delivered document.
			'phone'  => '
				<svg class="cl-scene" viewBox="0 0 400 260" role="img" aria-label="" preserveAspectRatio="xMidYMid slice">
					<defs>
						<linearGradient id="clsc-bg" x1="0" y1="0" x2="1" y2="1">
							<stop offset="0%" stop-color="#c9b7a2"/><stop offset="100%" stop-color="#9c8570"/>
						</linearGradient>
					</defs>
					<rect width="400" height="260" fill="url(#clsc-bg)"/>
					<rect x="146" y="24" width="108" height="212" rx="14" fill="#1b2230"/>
					<rect x="152" y="32" width="96" height="196" rx="9" fill="#f6f2e9"/>
					<rect x="176" y="38" width="48" height="5" rx="2" fill="#28313f" opacity="0.5"/>
					<rect x="162" y="58" width="76" height="30" rx="3" fill="#e6dfd1"/>
					<rect x="170" y="66" width="52" height="4" rx="2" fill="#a99f8d"/>
					<rect x="170" y="75" width="38" height="4" rx="2" fill="#a99f8d"/>
					<rect x="162" y="98" width="76" height="46" rx="3" fill="#d9e8d5"/>
					<rect x="170" y="106" width="56" height="4" rx="2" fill="#77906e"/>
					<rect x="170" y="115" width="44" height="4" rx="2" fill="#77906e"/>
					<rect x="162" y="158" width="76" height="20" rx="3" fill="#4a5f45"/>
					<rect x="178" y="165" width="44" height="5" rx="2" fill="#eef3ec"/>
					<path d="M108 150c0-18 12-32 28-32s28 14 28 32z" fill="#7b5f48" opacity="0.9"/>
				</svg>',
		);

		// The two solution cards carry a small interface rather than a scene, so
		// the visitor sees what the service actually looks like.
		$mocks = array(
			'ui-choices' => '
				<span class="cl-ui__bg"></span>
				<span class="cl-ui__sheet">
					<span class="cl-ui__q">' . esc_html__( 'What would you like to do?', 'cloaklink' ) . '</span>
					<span class="cl-ui__row"><span class="cl-ui__dot"></span>' . esc_html__( 'Join our community forum', 'cloaklink' ) . '</span>
					<span class="cl-ui__row cl-ui__row--on"><span class="cl-ui__dot"></span>' . esc_html__( 'Talk to a mediator', 'cloaklink' ) . '</span>
					<span class="cl-ui__row"><span class="cl-ui__dot"></span>' . esc_html__( 'Start your case online', 'cloaklink' ) . '</span>
				</span>',
			'ui-agree'   => '
				<span class="cl-ui__bg"></span>
				<span class="cl-ui__sheet">
					<span class="cl-ui__q">' . esc_html__( 'Settlement Agreement', 'cloaklink' ) . '</span>
					<span class="cl-ui__line"></span>
					<span class="cl-ui__line cl-ui__line--short"></span>
					<span class="cl-ui__row cl-ui__row--on"><span class="cl-ui__tick">&#10003;</span>' . esc_html__( 'I agree', 'cloaklink' ) . '</span>
					<span class="cl-ui__row"><span class="cl-ui__dot"></span>' . esc_html__( 'I disagree', 'cloaklink' ) . '</span>
				</span>',
		);

		if ( isset( $mocks[ $name ] ) ) {
			return '<span class="' . esc_attr( trim( 'cl-art cl-art--ui ' . $class ) ) . '" aria-hidden="true">'
				. '<span class="cl-ui">' . $mocks[ $name ] . '</span></span>';
		}

		$svg = isset( $scenes[ $name ] ) ? $scenes[ $name ] : $scenes['desk'];
		return '<span class="' . esc_attr( trim( 'cl-art ' . $class ) ) . '" aria-hidden="true">' . $svg . '</span>';
	}
}
