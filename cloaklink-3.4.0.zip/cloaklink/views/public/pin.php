<?php
/**
 * PIN screen shown before a protected link opens.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_vars  = isset( $GLOBALS['cloaklink_view'] ) ? $GLOBALS['cloaklink_view'] : array();
$cl_brand = isset( $cl_vars['brand'] ) ? $cl_vars['brand'] : array();
$cl_error = isset( $cl_vars['error'] ) ? (string) $cl_vars['error'] : '';
$cl_ref   = isset( $cl_vars['ref'] ) ? (string) $cl_vars['ref'] : '';

$cl_name = isset( $cl_brand['name'] ) ? $cl_brand['name'] : 'CloakLink';
$cl_tag  = isset( $cl_brand['tagline'] ) ? $cl_brand['tagline'] : '';
$cl_note = isset( $cl_brand['note'] ) ? $cl_brand['note'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#0d1b3e">
<title><?php echo esc_html( $cl_name ); ?></title>
	<?php
	// This service's own mark in the tab. Without it the browser asks the
	// install for /favicon.ico and shows the WordPress logo.
	$cl_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
		. '<rect width="64" height="64" rx="14" fill="#10232e"/>'
		. '<circle cx="32" cy="32" r="17" fill="none" stroke="#c9a86a" stroke-width="2.6" stroke-opacity=".85"/>'
		. '<path d="M40 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round"/>'
		. '<path d="M30 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round" stroke-opacity=".55"/>'
		. '</svg>';
	?>
	<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,<?php echo esc_attr( base64_encode( $cl_icon_svg ) ); ?>">
<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/gate.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body class="cl-gate">

<main class="cl-shell">

	<header class="cl-mast">
		<div class="cl-mast__id">
			<span class="cl-mast__mono" aria-hidden="true">§</span>
			<div class="cl-mast__text">
				<p class="cl-mast__name"><?php echo esc_html( $cl_name ); ?></p>
				<p class="cl-mast__tag"><?php echo esc_html( $cl_tag ); ?></p>
			</div>
		</div>
		<?php if ( $cl_ref ) : ?>
			<div class="cl-mast__ref">
				<span class="cl-mast__ref-label"><?php esc_html_e( 'Reference', 'cloaklink' ); ?></span>
				<span class="cl-mast__ref-value"><?php echo esc_html( $cl_ref ); ?></span>
			</div>
		<?php endif; ?>
	</header>

	<section class="cl-doc">
		<p class="cl-eyebrow"><?php esc_html_e( 'Protected link', 'cloaklink' ); ?></p>
		<h1 class="cl-doc__title"><?php esc_html_e( 'Enter your access PIN', 'cloaklink' ); ?></h1>
		<p class="cl-doc__lede"><?php esc_html_e( 'The sender was given a short code to pass on to you. Enter it below to open this resource.', 'cloaklink' ); ?></p>

		<?php if ( $cl_error ) : ?>
			<div class="cl-error">
				<p class="cl-error__body"><?php echo esc_html( $cl_error ); ?></p>
			</div>
		<?php endif; ?>

		<form method="post" class="cl-pin">
			<label class="cl-pin__label" for="cl-pin"><?php esc_html_e( 'Access PIN', 'cloaklink' ); ?></label>
			<input class="cl-pin__input" id="cl-pin" name="cl_pin" type="text" inputmode="numeric"
				autocomplete="one-time-code" pattern="[0-9]*" maxlength="10"
				placeholder="••••" required autofocus>
			<button type="submit" class="cl-btn cl-btn--gold cl-btn--wide"><?php esc_html_e( 'Unlock link', 'cloaklink' ); ?></button>
		</form>

		<p class="cl-error__hint" style="margin-top:18px">
			<?php esc_html_e( 'The document stays locked after six wrong attempts for ten minutes. If you were not given a PIN, ask the sender for it.', 'cloaklink' ); ?>
		</p>
	</section>

	<footer class="cl-foot">
		<p class="cl-foot__note"><?php echo esc_html( $cl_note ); ?></p>
	</footer>
</main>

</body>
</html>
